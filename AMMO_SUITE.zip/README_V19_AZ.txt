AMMO SUITE V19 — SÜRÜCÜ GƏLİRİ DÜYMƏ SIRASI

Düzəliş:
Sürücü gəliri panelində sağ yuxarı hissədə düymələrin sırası belədir:
Sahibkarlar | Hesabat tarixi | Fayl əlavə et

Quraşdırma:
1. ZIP faylını çıxarın.
2. chrome://extensions səhifəsini açın.
3. Developer mode aktiv edin.
4. Load unpacked seçin.
5. AMMO_SUITE_V19_DRIVER_BUTTON_ORDER qovluğunu göstərin.
