V25.7 TƏQVİM DÜZƏLİŞİ
- PDF xülasə sətrində soldan ilk rəqəm iş günü kimi götürülür.
- Xülasə sətri 40/36/24 saatlıq normalarla yoxlanılır; təqvim tarixləri səhvən seçilmir.
- 2026-cı ilin istehsalat təqvimi daxili ehtiyat baza kimi əlavə edilib.
- May 2026: 17 iş günü.
- Köhnə V25.6 yaddaşında qalmış səhv 21 dəyəri ilk açılışda avtomatik düzəldilir.
