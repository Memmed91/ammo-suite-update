AMMO SUITE V20 — TASKPANEL FAYL DÜZƏLİŞİ

Düzəlişlər:
1. Firebase Storage “Not Found” xətası aradan qaldırılıb. Fayllar Firestore-da təhlükəsiz hissələrə bölünərək saxlanılır.
2. Tapşırığı göndərən admin və tapşırığı alan işçi sənəd, şəkil və səs fayllarını öz kompüterində aça/yükləyə bilir.
3. Əsas AMMO SUITE background.js daxilinə e-poçt göndərmə handler-i əlavə edilib.
4. Tapşırıq e-poçtu iki ünvana, şəkillər məktub daxilində, sənəd/səs isə əlavə kimi göndərilir.

VACİB — FIRESTORE RULES:
modules/taskpanel/firestore.rules faylındakı qaydaları Firebase Console > Firestore Database > Rules bölməsində Publish edin. taskFileChunks kolleksiyası üçün giriş tələb olunur.

VACİB — E-POÇT:
Google Apps Script deployment URL işlək olmalıdır. Endpoint “Not Found” verirsə, modules/taskpanel/Code.gs faylını Apps Script-də Web app kimi yenidən Deploy edin (Execute as: Me, Who has access: Anyone), sonra yeni /exec URL-ni root background.js daxilində TASK_EMAIL_WEB_APP_URL sətrinə yazın. Spam qovluğuna düşmə qərarını Gmail/qarşı tərəfin poçt provayderi verir; proqram bunu tam məcburi idarə edə bilmir. Etibarlılıq üçün göndərən hesabda SPF/DKIM və tanınmış domen istifadə edin.
