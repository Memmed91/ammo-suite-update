AMMO SUITE V27

Düzəlişlər:
1. Borc Xatırladıcıda redaktə edilən məbləğin siyahıda köhnə qalması problemi aradan qaldırıldı; Firestore-dan gələn yenilik UI-da dərhal yenilənir.
2. Ödəniş növü əlavə edildi: “1 dəfəlik ödəniş” və “Hər ay üzrə”.
3. Aylıq və birdəfəlik qeydlərin hesablanması ayrıldı.
4. Ümumi baxış, statistika və hesabatlarda açıq/qalıq məbləğ əsas götürülür.
5. Bütün daxili modullara AMMO loqosunun lacivərd/mavi palitrasına uyğun vahid tema tətbiq edilir.
