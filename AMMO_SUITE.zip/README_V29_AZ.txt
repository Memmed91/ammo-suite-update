AMMO SUITE V29 — AVTOMATİK YENİLƏNMƏ
====================================
- Sabit uzantı ID-si (manifest.json "key"): bjmnogmejhnebbmgkemlflekeobladel
- AMMO-Updater.exe ilə silib-yükləmədən yenilənmə (Windows açılışında + "İndi yenilə" düyməsi)
- Yeni versiya zolağı, Chrome bildirişi, "⟳ Yeniləməni yoxla", sol altda versiya nömrəsi
- Cihaza bağlı giriş (TaxPro kimi). Admin: "💻 Cihazlar və yeniləmə" paneli
- Yeni Firestore qaydaları: FIRESTORE_RULES_AMMO_SUITE.txt (devices, updateAccess)
Ətraflı: TELIMAT_V29_YENILENME_AZ.txt
