const FB = { apiKey: 'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg', projectId: 'konsalting-79c40' };
const ADMIN_EMAILS = ['memmed@ammo.az'];
const $ = (s) => document.querySelector(s);

const DEFAULT_MODULES = {
  gomruk: { id:'gomruk', title:'Gömrük nəzarət', icon:'🚛', url:'modules/gomruk/main.html', order:10, enabled:true, openMode:'iframe', builtin:true },
  taskpanel: { id:'taskpanel', title:'TaskPanel', icon:'✅', url:'modules/taskpanel/index.html', order:20, enabled:true, openMode:'iframe', builtin:true },
  emekhaqqi: { id:'emekhaqqi', title:'Əməkhaqqı', icon:'💼', url:'modules/emekhaqqi/app.html', order:30, enabled:true, openMode:'iframe', builtin:true },
  surucu: { id:'surucu', title:'Sürücü gəliri', icon:'🚚', url:'modules/surucu-gelir/app.html', order:40, enabled:true, openMode:'iframe', builtin:true },
  beyannameUcotu: { id:'beyannameUcotu', title:'Vergi məktubları', icon:'📬', url:'modules/beyanname-ucotu/popup.html', order:50, enabled:true, openMode:'iframe', builtin:true },
  beyannameNezaret: { id:'beyannameNezaret', title:'Bəyannamə nəzarət', icon:'📊', url:'modules/beyanname-nezaret/app.html', order:60, enabled:true, openMode:'iframe', builtin:true },
  menfeet: { id:'menfeet', title:'Mənfəət', icon:'💰', url:'modules/menfeet-html-full/popup.html', order:70, enabled:true, openMode:'iframe', builtin:true },
  links: { id:'links', title:'Linklər', icon:'🔗', url:'modules/links/links.html', order:80, enabled:true, openMode:'iframe', builtin:true },
  hesabatVaxti: { id:'hesabatVaxti', title:'Hesabat Vaxtı', icon:'⏰', url:'modules/hesabat-vaxti/index.html', order:90, enabled:true, openMode:'iframe', builtin:true },
  borcXatirlatici: { id:'borcXatirlatici', title:'Borc Xatırladıcı', icon:'💳', url:'modules/borc-xatirlatici/dashboard.html', order:100, enabled:true, openMode:'iframe', builtin:true },
  malHereketi: { id:'malHereketi', title:'Mal Hərəkəti PRO', icon:'📦', url:'modules/mal-hereketi-pro/app.html', order:110, enabled:true, openMode:'iframe', builtin:true }
};

let modules = {...DEFAULT_MODULES};
let requested = new URLSearchParams(location.search).get('module') || 'gomruk';
let currentModule = requested;
let authenticating = false;
let suiteUnlocked = false;
let currentAuth = null;
let pollTimer = null;
let moduleVersions = {};
let lastModuleSignature = '';
let registryBusy = false;
// V28: istifadəçinin öz panel seçimi (bu kompüterdə) — gizli panellər və sıra
let panelPrefs = { hidden: [], order: {} };
async function loadPanelPrefs(){ try{ const {suitePanelPrefs}=await chrome.storage.local.get('suitePanelPrefs'); if(suitePanelPrefs) panelPrefs={hidden:Array.isArray(suitePanelPrefs.hidden)?suitePanelPrefs.hidden:[],order:suitePanelPrefs.order||{}}; }catch(e){} }
async function savePanelPrefs(){ try{ await chrome.storage.local.set({suitePanelPrefs:panelPrefs}); }catch(e){} }
const isHidden = (id) => panelPrefs.hidden.includes(id);
const orderOf = (m) => (panelPrefs.order[m.id] ?? m.order ?? 100);

async function login(email, password) {
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${FB.apiKey}`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password,returnSecureToken:true})
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || 'Giriş alınmadı');
  return data;
}
async function ammoRefreshAuth(a,apiKey){
  if(!a?.refreshToken) return a;
  if(a.expiresAt && Date.now() < Number(a.expiresAt) - 120000) return a;
  try{
    const r=await fetch(`https://securetoken.googleapis.com/v1/token?key=${apiKey}`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',refresh_token:a.refreshToken})});
    const d=await r.json();
    if(r.ok){ a={...a,idToken:d.id_token,refreshToken:d.refresh_token||a.refreshToken,uid:d.user_id||a.uid,expiresAt:Date.now()+Number(d.expires_in||3600)*1000}; await chrome.storage.local.set({suiteAuth:a}); }
  }catch(e){}
  return a;
}
async function validateAuth(auth) {
  if (!auth?.idToken || !auth?.uid) return false;
  auth = await ammoRefreshAuth(auth, FB.apiKey);
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${FB.apiKey}`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({idToken:auth.idToken})
  });
  const data = await response.json();
  const user = data?.users?.[0];
  return Boolean(response.ok && user && user.localId === auth.uid && !user.disabled);
}

/* === V29: CİHAZA BAĞLI GİRİŞ (TaxPro modeli) ===
   Hər hesab ilk girdiyi kompüterə bağlanır. Başqa kompüterdə həmin hesabla giriş olmur,
   admin "Cihazlar" panelindən cihazı sıfırlayana qədər. Adminlər bağlanmır.
   update-config.json → "deviceLock": false etsəniz bu yoxlama söndürülür. */
let AMMO_CFG=null;
async function ammoCfg(){ if(AMMO_CFG) return AMMO_CFG; try{ AMMO_CFG=await (await fetch(chrome.runtime.getURL('update-config.json'),{cache:'no-store'})).json(); }catch(e){ AMMO_CFG={}; } return AMMO_CFG; }
async function ammoDeviceId(){
  let {ammoDeviceId:id}=await chrome.storage.local.get('ammoDeviceId');
  if(!id){ id=(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random().toString(16).slice(2)); await chrome.storage.local.set({ammoDeviceId:id}); }
  return id;
}
function ammoDeviceLabel(){ const ua=navigator.userAgent; const os=/Windows NT 10/.test(ua)?'Windows 10/11':/Windows/.test(ua)?'Windows':/Mac OS X/.test(ua)?'macOS':/Linux/.test(ua)?'Linux':'Naməlum'; const br=(ua.match(/(Edg|Chrome)\/(\d+)/)||[]); return `${os} · ${br[1]==='Edg'?'Edge':'Chrome'} ${br[2]||''}`.trim(); }
async function deviceGate(auth){
  const cfg=await ammoCfg();
  if(cfg.deviceLock===false || !auth?.uid) return {ok:true};
  const admin=ADMIN_EMAILS.includes((auth.email||'').toLowerCase());
  const myId=await ammoDeviceId();
  const url=`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/devices/${encodeURIComponent(auth.uid)}`;
  const H={Authorization:`Bearer ${auth.idToken}`,'Content-Type':'application/json'};
  try{
    const r=await fetch(url,{headers:H});
    let bound='';
    if(r.ok){ const d=await r.json(); bound=d.fields?.deviceId?.stringValue||''; }
    else if(r.status!==404){ console.warn('AMMO deviceGate: HTTP',r.status,'(Firestore rules yenilənməyib?)'); return {ok:true,warn:true}; }
    if(bound && bound!==myId && !admin) return {ok:false,message:'Bu hesab başqa kompüterə bağlıdır. Admin cihazı sıfırlamalıdır.'};
    const fields={email:{stringValue:(auth.email||'').toLowerCase()},appVersion:{stringValue:chrome.runtime.getManifest().version},lastSeenAt:{timestampValue:new Date().toISOString()},deviceLabel:{stringValue:ammoDeviceLabel()}};
    if(!bound){ fields.deviceId={stringValue:myId}; fields.boundAt={timestampValue:new Date().toISOString()}; }
    const mask=Object.keys(fields).map(k=>'updateMask.fieldPaths='+k).join('&');
    const w=await fetch(`${url}?${mask}`,{method:'PATCH',headers:H,body:JSON.stringify({fields})});
    if(!w.ok && !bound && !admin){ // eyni anda başqa kompüter bağlanıbsa
      const again=await fetch(url,{headers:H}); if(again.ok){ const d=await again.json(); const b2=d.fields?.deviceId?.stringValue||''; if(b2 && b2!==myId) return {ok:false,message:'Bu hesab başqa kompüterə bağlıdır. Admin cihazı sıfırlamalıdır.'}; }
    }
    return {ok:true};
  }catch(e){ return {ok:true,offline:true}; } // internet yoxdursa — əvvəlki giriş qüvvədədir
}
function isAdmin(){ return ADMIN_EMAILS.includes((currentAuth?.email||'').toLowerCase()); }
function value(v){
  if (v === undefined || v === null) return null;
  if (typeof v === 'string') return {stringValue:v};
  if (typeof v === 'boolean') return {booleanValue:v};
  if (typeof v === 'number') return {integerValue:String(Math.trunc(v))};
  if (Array.isArray(v)) return {arrayValue:{values:v.map(value)}};
  return {stringValue:String(v)};
}
function fromField(f){
  if (!f) return null;
  if ('stringValue' in f) return f.stringValue;
  if ('booleanValue' in f) return f.booleanValue;
  if ('integerValue' in f) return Number(f.integerValue);
  if ('doubleValue' in f) return Number(f.doubleValue);
  if ('arrayValue' in f) return (f.arrayValue.values||[]).map(fromField);
  return null;
}
async function fsList(){
  const r=await fetch(`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/suiteModules?pageSize=200`, {headers:{Authorization:`Bearer ${currentAuth.idToken}`}});
  if(!r.ok) throw new Error('Modullar oxunmadı');
  const d=await r.json();
  return (d.documents||[]).map(doc=>{
    const f=doc.fields||{}; const id=doc.name.split('/').pop();
    return {id, title:fromField(f.title)||id, icon:fromField(f.icon)||'◻', url:fromField(f.url)||'', order:fromField(f.order)||100, version:fromField(f.version)||'1.0.0', enabled:fromField(f.enabled)!==false, openMode:fromField(f.openMode)||'iframe', allowedEmails:fromField(f.allowedEmails)||[], builtin:fromField(f.builtin)===true};
  });
}
async function fsSet(mod){
  const fields={}; Object.entries(mod).forEach(([k,v])=>{ if(k!=='id' && v!==undefined) fields[k]=value(v); });
  const r=await fetch(`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/suiteModules/${encodeURIComponent(mod.id)}`, {method:'PATCH',headers:{Authorization:`Bearer ${currentAuth.idToken}`,'Content-Type':'application/json'},body:JSON.stringify({fields})});
  if(!r.ok) throw new Error((await r.json()).error?.message||'Yadda saxlanmadı');
}
async function fsDelete(id){
  const r=await fetch(`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/suiteModules/${encodeURIComponent(id)}`, {method:'DELETE',headers:{Authorization:`Bearer ${currentAuth.idToken}`}});
  if(!r.ok) throw new Error('Silinmədi');
}
async function seedDefaults(){
  const remote=await fsList();
  if(remote.length) return remote;
  if(!isAdmin()) return [];
  for(const mod of Object.values(DEFAULT_MODULES)) await fsSet(mod);
  return Object.values(DEFAULT_MODULES);
}
function canSee(mod){
  const list=Array.isArray(mod.allowedEmails)?mod.allowedEmails:[];
  return !list.length || list.map(x=>String(x).toLowerCase()).includes((currentAuth?.email||'').toLowerCase()) || isAdmin();
}
function renderNav(){
  const nav=$('#moduleNav'); nav.innerHTML='';
  const all=Object.values(modules).filter(m=>m.enabled!==false && canSee(m));
  let list=all.filter(m=>!isHidden(m.id)).sort((a,b)=>orderOf(a)-orderOf(b));
  if(!list.length) list=all.sort((a,b)=>orderOf(a)-orderOf(b)); // heç olmasa bir panel qalsın
  list.forEach(mod=>{
    const b=document.createElement('button'); b.dataset.module=mod.id; b.textContent=`${mod.icon||'◻'} ${mod.title}`; b.classList.toggle('active',mod.id===currentModule); b.addEventListener('click',()=>openModule(mod.id)); nav.appendChild(b);
  });
  if(!modules[currentModule] || !canSee(modules[currentModule]) || modules[currentModule].enabled===false || !list.some(m=>m.id===currentModule)){ currentModule=list[0]?.id||'gomruk'; }
}
function markActive(key){
  document.querySelectorAll('#moduleNav button').forEach(b=>b.classList.toggle('active',b.dataset.module===key));
  $('#moduleTitle').textContent=modules[key]?.title||'AMMO SUITE';
}
function openModule(key){
  const mod=modules[key]; if(!mod || !canSee(mod) || mod.enabled===false) return;
  currentModule=key; markActive(key);
  if(!suiteUnlocked){ $('#frame').src='about:blank'; $('#frame').classList.remove('visible'); $('#moduleLogin').classList.remove('hidden'); return; }
  $('#moduleLogin').classList.add('hidden');
  if(mod.openMode==='tab'){ chrome.tabs.create({url:mod.url}); return; }
  $('#frame').src=mod.url; $('#frame').classList.add('visible');
}
async function refreshModules(showStatus=false){
  if(registryBusy) return; registryBusy=true;
  try{
    if(currentAuth) currentAuth=await ammoRefreshAuth(currentAuth, FB.apiKey);
    const remote=await seedDefaults();
    const next={...DEFAULT_MODULES}; remote.forEach(m=>next[m.id]={...(next[m.id]||{}),...m});
    const signature=JSON.stringify(Object.values(next).map(m=>[m.id,m.title,m.icon,m.url,m.order,m.version,m.enabled,m.openMode,m.allowedEmails]));
    if(signature!==lastModuleSignature){
      const previous=modules; modules=next; renderNav();
      const active=modules[currentModule], old=previous[currentModule];
      if(suiteUnlocked && active && old && (active.url!==old.url || active.version!==old.version)){
        const tag=(document.activeElement?.tagName||'').toLowerCase();
        const editing=['input','textarea','select'].includes(tag);
        if(!editing) openModule(currentModule); else $('#syncStatus').textContent='☁ Yeni modul versiyası hazırdır';
      }
      lastModuleSignature=signature;
      if(!$('#adminOverlay').classList.contains('hidden')) renderAdminList();
    }
    if(showStatus) $('#syncStatus').textContent='☁ Yeniləndi';
    if(!$('#frame').classList.contains('visible') && suiteUnlocked) openModule(currentModule);
  }catch(e){ $('#syncStatus').textContent='⚠ Firebase bağlantısı'; }
  finally{registryBusy=false;}
}
async function unlockSuite(){
  if(authenticating) return; const email=$('#email').value.trim(), password=$('#password').value;
  if(!email||!password){ $('#loginMsg').textContent='Email və şifrəni yazın.'; return; }
  authenticating=true; $('#loginBtn').disabled=true; $('#loginMsg').textContent='Yoxlanılır...';
  try{
    const auth=await login(email,password); const candidate={idToken:auth.idToken,refreshToken:auth.refreshToken,uid:auth.localId,email:auth.email||email,loginAt:Date.now(),expiresAt:Date.now()+Number(auth.expiresIn||3600)*1000};
    const gate=await deviceGate(candidate); if(!gate.ok){ const err=new Error(gate.message); err.deviceLocked=true; throw err; }
    currentAuth=candidate;
    await chrome.storage.local.set({suiteAuth:currentAuth,ammoLastEmail:currentAuth.email}); suiteUnlocked=true; $('#password').value=''; $('#loginMsg').textContent='';
    $('#adminBtn').classList.toggle('hidden',!isAdmin());$('#panelsBtn').classList.remove('hidden'); await refreshModules(); openModule(currentModule); startPolling();
  }catch(e){ $('#loginMsg').textContent=e.deviceLocked?('🔒 '+e.message):'Giriş alınmadı. Email və ya şifrə yanlışdır.'; }
  finally{ authenticating=false; $('#loginBtn').disabled=false; }
}
async function lockSuite(){
  suiteUnlocked=false; currentAuth=null; clearInterval(pollTimer); await chrome.storage.local.remove('suiteAuth');
  $('#frame').src='about:blank'; $('#frame').classList.remove('visible'); $('#moduleLogin').classList.remove('hidden'); $('#adminBtn').classList.add('hidden'); $('#panelsBtn').classList.add('hidden'); $('#panelsOverlay').classList.add('hidden'); $('#password').value=''; $('#loginMsg').textContent='';
}
function startPolling(){ clearInterval(pollTimer); pollTimer=setInterval(()=>refreshModules(false),5000); }
function renderAdminList(){
  const root=$('#moduleList'); root.innerHTML='';
  Object.values(modules).sort((a,b)=>(a.order||100)-(b.order||100)).forEach(m=>{
    const row=document.createElement('div'); row.className='module-row';
    const e=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));row.innerHTML=`<div><b>${e(m.icon||'◻')} ${e(m.title)}</b><small>${e(m.id)} · v${e(m.version||'1.0.0')} · ${e(m.url||'URL yoxdur')} · ${m.enabled===false?'deaktiv':'aktiv'}</small></div><div><button data-edit="${e(m.id)}">Düzəlt</button><button data-toggle="${e(m.id)}">${m.enabled===false?'Aktiv et':'Söndür'}</button>${m.builtin?'':'<button class="danger" data-del="'+m.id+'">Sil</button>'}</div>`;
    root.appendChild(row);
  });
  root.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>fillForm(modules[b.dataset.edit]));
  root.querySelectorAll('[data-toggle]').forEach(b=>b.onclick=async()=>{const m={...modules[b.dataset.toggle],enabled:modules[b.dataset.toggle].enabled===false}; await fsSet(m); await refreshModules();});
  root.querySelectorAll('[data-del]').forEach(b=>b.onclick=async()=>{if(confirm('Bu modulu silmək istəyirsiniz?')){await fsDelete(b.dataset.del);await refreshModules();}});
}
function fillForm(m={}){
  $('#modId').value=m.id||''; $('#modId').disabled=Boolean(m.id); $('#modTitle').value=m.title||''; $('#modIcon').value=m.icon||''; $('#modUrl').value=m.url||''; $('#modOrder').value=m.order||100; $('#modVersion').value=m.version||'1.0.0'; $('#modOpenMode').value=m.openMode||'iframe'; $('#modEnabled').checked=m.enabled!==false; $('#modAllowed').value=(m.allowedEmails||[]).join(', ');
}
$('#loginBtn').addEventListener('click',unlockSuite); $('#password').addEventListener('keydown',e=>{if(e.key==='Enter')unlockSuite();}); $('#email').addEventListener('keydown',e=>{if(e.key==='Enter')$('#password').focus();});
$('#reload').addEventListener('click',()=>{if(suiteUnlocked&&$('#frame').src!=='about:blank')$('#frame').contentWindow.location.reload();}); $('#lock').addEventListener('click',lockSuite);
$('#adminBtn').addEventListener('click',()=>{$('#adminOverlay').classList.remove('hidden');fillForm();renderAdminList();}); $('#adminClose').addEventListener('click',()=>$('#adminOverlay').classList.add('hidden'));
$('#modSave').addEventListener('click',async()=>{
  const id=$('#modId').value.trim().replace(/[^a-zA-Z0-9_-]/g,''); const title=$('#modTitle').value.trim(), url=$('#modUrl').value.trim();
  if(!id||!title||!url){$('#adminMsg').textContent='Kod, ad və URL mütləqdir.';return;}
  const mod={id,title,icon:$('#modIcon').value.trim()||'◻',url,order:Number($('#modOrder').value)||100,version:$('#modVersion').value.trim()||'1.0.0',openMode:$('#modOpenMode').value,enabled:$('#modEnabled').checked,allowedEmails:$('#modAllowed').value.split(',').map(x=>x.trim().toLowerCase()).filter(Boolean),builtin:Boolean(modules[id]?.builtin)};
  try{await fsSet(mod);$('#adminMsg').textContent='Yadda saxlanıldı. Bütün kompüterlərdə görünəcək.';fillForm();await refreshModules();}catch(e){$('#adminMsg').textContent=e.message;}
});
(async()=>{
  await loadPanelPrefs();
  const {ammoLastEmail,suiteAuth}=await chrome.storage.local.get(['ammoLastEmail','suiteAuth']); if(ammoLastEmail)$('#email').value=ammoLastEmail;
  suiteUnlocked=await validateAuth(suiteAuth).catch(()=>false); if(!suiteUnlocked){await chrome.storage.local.remove('suiteAuth');renderNav();openModule(isHidden(requested)?currentModule:requested);return;}
  currentAuth=(await chrome.storage.local.get('suiteAuth')).suiteAuth||suiteAuth;
  const gate=await deviceGate(currentAuth);
  if(!gate.ok){ currentAuth=null; suiteUnlocked=false; await chrome.storage.local.remove('suiteAuth'); renderNav(); openModule(isHidden(requested)?currentModule:requested); $('#loginMsg').textContent='🔒 '+gate.message; return; }
  $('#adminBtn').classList.toggle('hidden',!isAdmin());$('#panelsBtn').classList.remove('hidden'); await refreshModules(); openModule(isHidden(requested)?currentModule:requested); startPolling();
})();

// AMMO vahid vizual tema: bütün daxili modullarda logo palitrası
const AMMO_THEME_CSS = `:root{--ammo-navy:#09204e;--ammo-blue:#0b6be8;--accent:#0b6be8!important;--primary:#0b6be8!important;--nav:#09204e!important} body{accent-color:#0b6be8} button.primary,.primary,[class*="primary"]{border-color:#0b6be8} a{color:#0b6be8} ::selection{background:#cfe2ff}`;
function applyAmmoTheme(){try{const d=$('#frame').contentDocument;if(!d)return;let st=d.getElementById('ammo-unified-theme');if(!st){st=d.createElement('style');st.id='ammo-unified-theme';st.textContent=AMMO_THEME_CSS;d.head.appendChild(st);} }catch(e){}}
$('#frame').addEventListener('load',()=>{applyAmmoTheme();setTimeout(applyAmmoTheme,250);});


/* === V28: Panelləri idarə et (aç / bağla / sırala) === */
function panelEsc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function panelList(){return Object.values(modules).filter(m=>m.enabled!==false && canSee(m)).sort((a,b)=>orderOf(a)-orderOf(b));}
function renderPanelsList(){
  const list=panelList(), root=$('#panelsList');
  const visible=list.filter(m=>!isHidden(m.id)).length;
  $('#panelsCount').textContent=`${visible} / ${list.length} panel açıqdır`;
  root.innerHTML=list.map((m,i)=>{const on=!isHidden(m.id);return `<div class="panel-row ${on?'':'off'}">
    <div class="panel-move"><button data-up="${panelEsc(m.id)}" ${i===0?'disabled':''} title="Yuxarı">▲</button><button data-down="${panelEsc(m.id)}" ${i===list.length-1?'disabled':''} title="Aşağı">▼</button></div>
    <div class="panel-name"><span class="panel-icon">${panelEsc(m.icon||'◻')}</span><div><b>${panelEsc(m.title)}</b><small>${on?'Menyuda görünür':'Bağlıdır — menyuda görünmür'}</small></div></div>
    <button class="panel-open" data-go="${panelEsc(m.id)}" ${on?'':'disabled'}>Aç</button>
    <label class="switch" title="${on?'Bağla':'Aç'}"><input type="checkbox" data-toggle-panel="${panelEsc(m.id)}" ${on?'checked':''}><span></span></label>
  </div>`;}).join('');
  root.querySelectorAll('[data-toggle-panel]').forEach(x=>x.onchange=async()=>{
    const id=x.dataset.togglePanel;
    if(!x.checked){ if(list.filter(m=>!isHidden(m.id)).length<=1){x.checked=true;return;} panelPrefs.hidden=[...new Set([...panelPrefs.hidden,id])]; }
    else panelPrefs.hidden=panelPrefs.hidden.filter(h=>h!==id);
    await savePanelPrefs(); applyPanelPrefs();
  });
  const move=async(id,dir)=>{const arr=panelList();const i=arr.findIndex(m=>m.id===id),j=i+dir;if(i<0||j<0||j>=arr.length)return;[arr[i],arr[j]]=[arr[j],arr[i]];arr.forEach((m,k)=>panelPrefs.order[m.id]=(k+1)*10);await savePanelPrefs();applyPanelPrefs();};
  root.querySelectorAll('[data-up]').forEach(b=>b.onclick=()=>move(b.dataset.up,-1));
  root.querySelectorAll('[data-down]').forEach(b=>b.onclick=()=>move(b.dataset.down,1));
  root.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{$('#panelsOverlay').classList.add('hidden');openModule(b.dataset.go);});
}
function applyPanelPrefs(){
  const before=currentModule; renderNav(); markActive(currentModule);
  if(currentModule!==before && suiteUnlocked) openModule(currentModule);
  if(!$('#panelsOverlay').classList.contains('hidden')) renderPanelsList();
}
$('#panelsBtn').addEventListener('click',()=>{$('#panelsAdmin').classList.toggle('hidden',!isAdmin());renderPanelsList();$('#panelsOverlay').classList.remove('hidden');});
$('#panelsClose').addEventListener('click',()=>$('#panelsOverlay').classList.add('hidden'));
$('#panelsOverlay').addEventListener('click',e=>{if(e.target.id==='panelsOverlay')$('#panelsOverlay').classList.add('hidden');});
$('#adminOverlay').addEventListener('click',e=>{if(e.target.id==='adminOverlay')$('#adminOverlay').classList.add('hidden');});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('#panelsOverlay').classList.add('hidden');$('#adminOverlay').classList.add('hidden');}});
$('#panelsShowAll').addEventListener('click',async()=>{panelPrefs.hidden=[];await savePanelPrefs();applyPanelPrefs();});
$('#panelsReset').addEventListener('click',async()=>{panelPrefs.order={};await savePanelPrefs();applyPanelPrefs();});
$('#panelsAdmin').addEventListener('click',()=>{$('#panelsOverlay').classList.add('hidden');$('#adminOverlay').classList.remove('hidden');fillForm();renderAdminList();});
