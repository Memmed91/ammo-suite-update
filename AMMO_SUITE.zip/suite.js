const FB = { apiKey: 'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg', projectId: 'konsalting-79c40' };
const ADMIN_EMAILS = ['memmed@ammo.az'];
// Cihaz bağlamasından azad hesablar (sahib/admin) — istənilən kompüterdən girə bilər
const DEVICE_LOCK_EXEMPT = ['memmed@ammo.az', 'memmed.allahverdiyev@yahoo.com'];
const $ = (s) => document.querySelector(s);

const DEFAULT_MODULES = {
  taskpanel: { id:'taskpanel', title:'TaskPanel', icon:'✅', url:'modules/taskpanel/index.html', order:20, enabled:true, openMode:'iframe', builtin:true },
  emekhaqqi: { id:'emekhaqqi', title:'Əməkhaqqı', icon:'💼', url:'modules/emekhaqqi/app.html', order:30, enabled:true, openMode:'iframe', builtin:true },
  kurs: { id:'kurs', title:'Kurs İdarəetmə', icon:'🎓', url:'modules/kurs/app.html', order:33, enabled:true, openMode:'iframe', builtin:true },
  sexsiHesab: { id:'sexsiHesab', title:'Şəxsi hesab → Borc', icon:'🧮', url:'modules/sexsi-hesab/app.html', order:35, enabled:true, openMode:'iframe', builtin:true },
  surucu: { id:'surucu', title:'Sürücü gəliri', icon:'🚚', url:'modules/surucu-gelir/app.html', order:40, enabled:true, openMode:'iframe', builtin:true },
  beyannameUcotu: { id:'beyannameUcotu', title:'Vergi məktubları', icon:'📬', url:'modules/beyanname-ucotu/popup.html', order:50, enabled:true, openMode:'iframe', builtin:true },
  beyannameNezaret: { id:'beyannameNezaret', title:'Bəyannamə nəzarət', icon:'📊', url:'modules/beyanname-nezaret/app.html', order:60, enabled:true, openMode:'iframe', builtin:true },
  menfeet: { id:'menfeet', title:'Mənfəət', icon:'💰', url:'modules/menfeet-html-full/popup.html', order:70, enabled:true, openMode:'iframe', builtin:true },
  links: { id:'links', title:'Linklər', icon:'🔗', url:'modules/links/links.html', order:80, enabled:true, openMode:'iframe', builtin:true },
  hesabatVaxti: { id:'hesabatVaxti', title:'Hesabat Vaxtı', icon:'⏰', url:'modules/hesabat-vaxti/index.html', order:90, enabled:true, openMode:'iframe', builtin:true },
  borcXatirlatici: { id:'borcXatirlatici', title:'Borc Xatırladıcı', icon:'💳', url:'modules/borc-xatirlatici/dashboard.html', order:100, enabled:true, openMode:'iframe', builtin:true },
  malHereketi: { id:'malHereketi', title:'Mal Hərəkəti PRO', icon:'📦', url:'modules/mal-hereketi-pro/app.html', order:110, enabled:true, openMode:'iframe', builtin:true }
};
// V30.2: ləğv edilmiş panellər — Firestore reyestrində qalsa belə menyuda göstərilmir (admin girişində reyestrdən silinir)
// V31: Gömrük nəzarət paneli də ləğv edildi
const REMOVED_MODULES = new Set(['senedHazirla','edvAnaliz','gomruk']);
const REMOVED_URL_RX = /modules\/(sened-hazirla|edv-analiz|gomruk|menfeet-visual|menfeet)\//;
const isRemovedModule = (m) => !m || REMOVED_MODULES.has(m.id) || REMOVED_URL_RX.test(String(m.url||''));

let modules = {...DEFAULT_MODULES};
let requested = new URLSearchParams(location.search).get('module') || 'taskpanel';
let currentModule = requested;
let authenticating = false;
let suiteUnlocked = false;
let currentAuth = null;
let pollTimer = null;
let moduleVersions = {};
let lastModuleSignature = '';
let registryBusy = false;
// V28: istifadəçinin öz panel seçimi (bu kompüterdə) — gizli panellər və sıra
let panelPrefs = { hidden: [], order: {} };
async function loadPanelPrefs(){ try{ const {suitePanelPrefs}=await chrome.storage.local.get('suitePanelPrefs'); if(suitePanelPrefs) panelPrefs={hidden:Array.isArray(suitePanelPrefs.hidden)?suitePanelPrefs.hidden:[],order:suitePanelPrefs.order||{}}; }catch(e){} }
async function savePanelPrefs(){ try{ await chrome.storage.local.set({suitePanelPrefs:panelPrefs}); }catch(e){} }
// V30.2: panelləri yalnız admin idarə edir və seçim Firebase-də saxlanılır — bütün kompüterlərdə eyni
const isHidden = (id) => false;
const orderOf = (m) => (Number(m.order) || 100);

async function login(email, password) {
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${FB.apiKey}`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password,returnSecureToken:true})
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || 'Giriş alınmadı');
  return data;
}
async function ammoRefreshAuth(a,apiKey){
  if(!a?.refreshToken) return a;
  if(a.expiresAt && Date.now() < Number(a.expiresAt) - 120000) return a;
  try{
    const r=await fetch(`https://securetoken.googleapis.com/v1/token?key=${apiKey}`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',refresh_token:a.refreshToken})});
    const d=await r.json();
    if(r.ok){ a={...a,idToken:d.id_token,refreshToken:d.refresh_token||a.refreshToken,uid:d.user_id||a.uid,expiresAt:Date.now()+Number(d.expires_in||3600)*1000}; await chrome.storage.local.set({suiteAuth:a}); }
  }catch(e){}
  return a;
}
async function validateAuth(auth) {
  if (!auth?.idToken || !auth?.uid) return false;
  auth = await ammoRefreshAuth(auth, FB.apiKey);
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${FB.apiKey}`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({idToken:auth.idToken})
  });
  const data = await response.json();
  const user = data?.users?.[0];
  return Boolean(response.ok && user && user.localId === auth.uid && !user.disabled);
}

/* === V29: CİHAZA BAĞLI GİRİŞ (TaxPro modeli) ===
   Hər hesab ilk girdiyi kompüterə bağlanır. Başqa kompüterdə həmin hesabla giriş olmur,
   admin "Cihazlar" panelindən cihazı sıfırlayana qədər. Adminlər bağlanmır.
   update-config.json → "deviceLock": false etsəniz bu yoxlama söndürülür. */
let AMMO_CFG=null;
async function ammoCfg(){ if(AMMO_CFG) return AMMO_CFG; try{ AMMO_CFG=await (await fetch(chrome.runtime.getURL('update-config.json'),{cache:'no-store'})).json(); }catch(e){ AMMO_CFG={}; } return AMMO_CFG; }
async function ammoDeviceId(){
  let {ammoDeviceId:id}=await chrome.storage.local.get('ammoDeviceId');
  if(!id){ id=(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random().toString(16).slice(2)); await chrome.storage.local.set({ammoDeviceId:id}); }
  return id;
}
function ammoDeviceLabel(){ const ua=navigator.userAgent; const os=/Windows NT 10/.test(ua)?'Windows 10/11':/Windows/.test(ua)?'Windows':/Mac OS X/.test(ua)?'macOS':/Linux/.test(ua)?'Linux':'Naməlum'; const br=(ua.match(/(Edg|Chrome)\/(\d+)/)||[]); return `${os} · ${br[1]==='Edg'?'Edge':'Chrome'} ${br[2]||''}`.trim(); }
async function deviceGate(auth){
  const cfg=await ammoCfg();
  if(cfg.deviceLock===false || !auth?.uid) return {ok:true};
  const em=(auth.email||'').toLowerCase();
  const admin=ADMIN_EMAILS.includes(em) || DEVICE_LOCK_EXEMPT.includes(em);
  const myId=await ammoDeviceId();
  const url=`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/devices/${encodeURIComponent(auth.uid)}`;
  const H={Authorization:`Bearer ${auth.idToken}`,'Content-Type':'application/json'};
  try{
    const r=await fetch(url,{headers:H});
    let bound='';
    if(r.ok){ const d=await r.json(); bound=d.fields?.deviceId?.stringValue||''; }
    else if(r.status!==404){ console.warn('AMMO deviceGate: HTTP',r.status,'(Firestore rules yenilənməyib?)'); return {ok:true,warn:true}; }
    if(bound && bound!==myId && !admin) return {ok:false,message:'Bu hesab başqa kompüterə bağlıdır. Admin cihazı sıfırlamalıdır.'};
    const fields={email:{stringValue:(auth.email||'').toLowerCase()},appVersion:{stringValue:chrome.runtime.getManifest().version},lastSeenAt:{timestampValue:new Date().toISOString()},deviceLabel:{stringValue:ammoDeviceLabel()}};
    if(!bound){ fields.deviceId={stringValue:myId}; fields.boundAt={timestampValue:new Date().toISOString()}; }
    const mask=Object.keys(fields).map(k=>'updateMask.fieldPaths='+k).join('&');
    const w=await fetch(`${url}?${mask}`,{method:'PATCH',headers:H,body:JSON.stringify({fields})});
    if(!w.ok && !bound && !admin){ // eyni anda başqa kompüter bağlanıbsa
      const again=await fetch(url,{headers:H}); if(again.ok){ const d=await again.json(); const b2=d.fields?.deviceId?.stringValue||''; if(b2 && b2!==myId) return {ok:false,message:'Bu hesab başqa kompüterə bağlıdır. Admin cihazı sıfırlamalıdır.'}; }
    }
    return {ok:true};
  }catch(e){ return {ok:true,offline:true}; } // internet yoxdursa — əvvəlki giriş qüvvədədir
}
function isAdmin(){ return ADMIN_EMAILS.includes((currentAuth?.email||'').toLowerCase()); }
function value(v){
  if (v === undefined || v === null) return null;
  if (typeof v === 'string') return {stringValue:v};
  if (typeof v === 'boolean') return {booleanValue:v};
  if (typeof v === 'number') return {integerValue:String(Math.trunc(v))};
  if (Array.isArray(v)) return {arrayValue:{values:v.map(value)}};
  return {stringValue:String(v)};
}
function fromField(f){
  if (!f) return null;
  if ('stringValue' in f) return f.stringValue;
  if ('booleanValue' in f) return f.booleanValue;
  if ('integerValue' in f) return Number(f.integerValue);
  if ('doubleValue' in f) return Number(f.doubleValue);
  if ('arrayValue' in f) return (f.arrayValue.values||[]).map(fromField);
  return null;
}
async function fsList(){
  const r=await fetch(`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/suiteModules?pageSize=200`, {headers:{Authorization:`Bearer ${currentAuth.idToken}`}});
  if(!r.ok) throw new Error('Modullar oxunmadı');
  const d=await r.json();
  return (d.documents||[]).map(doc=>{
    const f=doc.fields||{}; const id=doc.name.split('/').pop();
    return {id, title:fromField(f.title)||id, icon:fromField(f.icon)||'◻', url:fromField(f.url)||'', order:fromField(f.order)||100, version:fromField(f.version)||'1.0.0', enabled:fromField(f.enabled)!==false, openMode:fromField(f.openMode)||'iframe', allowedEmails:fromField(f.allowedEmails)||[], builtin:fromField(f.builtin)===true};
  });
}
async function fsSet(mod){
  const fields={}; Object.entries(mod).forEach(([k,v])=>{ if(k!=='id' && v!==undefined) fields[k]=value(v); });
  const r=await fetch(`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/suiteModules/${encodeURIComponent(mod.id)}`, {method:'PATCH',headers:{Authorization:`Bearer ${currentAuth.idToken}`,'Content-Type':'application/json'},body:JSON.stringify({fields})});
  if(!r.ok) throw new Error((await r.json()).error?.message||'Yadda saxlanmadı');
}
async function fsDelete(id){
  const r=await fetch(`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/suiteModules/${encodeURIComponent(id)}`, {method:'DELETE',headers:{Authorization:`Bearer ${currentAuth.idToken}`}});
  if(!r.ok) throw new Error('Silinmədi');
}
let removedCleaned=false;
async function seedDefaults(){
  let remote=await fsList();
  if(isAdmin() && !removedCleaned){ removedCleaned=true; for(const m of remote.filter(isRemovedModule)){ try{ await fsDelete(m.id); }catch(e){} } }
  remote=remote.filter(m=>!isRemovedModule(m));
  if(remote.length) return remote;
  if(!isAdmin()) return [];
  for(const mod of Object.values(DEFAULT_MODULES)) await fsSet(mod);
  return Object.values(DEFAULT_MODULES);
}
function canSee(mod){
  const list=Array.isArray(mod.allowedEmails)?mod.allowedEmails:[];
  return !list.length || list.map(x=>String(x).toLowerCase()).includes((currentAuth?.email||'').toLowerCase()) || isAdmin();
}
/* V31: yeni naviqasiya — bölmələr qruplara ayrılıb, vahid xətti ikonlar */
const NAV_GROUPS = [
  { name:'Vergi', ids:['beyannameNezaret','beyannameUcotu','hesabatVaxti','sexsiHesab','menfeet'] },
  { name:'Maliyyə və kadr', ids:['emekhaqqi','surucu','borcXatirlatici','malHereketi'] },
  { name:'Komanda', ids:['taskpanel','kurs','links'] }
];
const ICONS = {
  beyannameNezaret:'<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="m9 13 2 2 4-4"/>',
  beyannameUcotu:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  hesabatVaxti:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/><path d="M12 14v2.5l1.5 1"/>',
  sexsiHesab:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h2M12 11h2M16 11h0M8 15h2M12 15h2M8 18h2M12 18h4"/>',
  menfeet:'<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
  emekhaqqi:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18"/>',
  surucu:'<path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
  borcXatirlatici:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/>',
  malHereketi:'<path d="m21 8-9-5-9 5 9 5 9-5Z"/><path d="M3 8v8l9 5 9-5V8M12 13v8"/>',
  taskpanel:'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m8 12 3 3 5-6"/>',
  kurs:'<path d="m2 9 10-5 10 5-10 5L2 9Z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5M22 9v5"/>',
  links:'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>'
};
const groupOf = (id) => (NAV_GROUPS.find(g=>g.ids.includes(id))||{name:'Digər'}).name;
const navEsc = (v) => String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function iconHtml(mod){ return ICONS[mod.id] ? `<svg viewBox="0 0 24 24">${ICONS[mod.id]}</svg>` : `<span class="emo">${navEsc(mod.icon||'◻')}</span>`; }
function renderNav(){
  const nav=$('#moduleNav'); nav.innerHTML='';
  // V31.1: admin bağlı panelləri də görür (işarəli); işçilər görmür
  const all=Object.values(modules).filter(m=>(m.enabled!==false || isAdmin()) && canSee(m) && !isRemovedModule(m));
  let list=all.filter(m=>!isHidden(m.id)).sort((a,b)=>orderOf(a)-orderOf(b));
  if(!list.length) list=all.sort((a,b)=>orderOf(a)-orderOf(b));
  const groups=[...NAV_GROUPS.map(g=>g.name),'Digər'];
  groups.forEach(gName=>{
    const items=list.filter(m=>groupOf(m.id)===gName); if(!items.length) return;
    const g=document.createElement('div'); g.className='nav-group';
    g.innerHTML=`<div class="nav-label">${navEsc(gName)}</div>`;
    items.forEach(mod=>{
      const b=document.createElement('button'); b.className='nav-item'; b.dataset.module=mod.id; b.title=mod.title;
      const off=mod.enabled===false, few=Array.isArray(mod.allowedEmails)&&mod.allowedEmails.length;
      b.classList.toggle('off',off);
      b.innerHTML=`${iconHtml(mod)}<span class="t">${navEsc(mod.title)}</span>${off?'<span class="nav-tag" title="İşçilərdə görünmür — yalnız siz görürsünüz">gizli</span>':(few&&isAdmin()?`<span class="nav-tag" title="Yalnız seçilmiş işçilər görür">${mod.allowedEmails.length}</span>`:'')}`;
      b.classList.toggle('active',mod.id===currentModule); b.addEventListener('click',()=>openModule(mod.id)); g.appendChild(b);
    });
    nav.appendChild(g);
  });
  if(!modules[currentModule] || !canSee(modules[currentModule]) || (modules[currentModule].enabled===false && !isAdmin()) || !list.some(m=>m.id===currentModule)){ currentModule=list[0]?.id||'taskpanel'; }
}
function markActive(key){
  document.querySelectorAll('#moduleNav .nav-item').forEach(b=>b.classList.toggle('active',b.dataset.module===key));
  $('#moduleTitle').textContent=modules[key]?.title||'AMMO SUITE';
  $('#moduleGroup').textContent=modules[key]?groupOf(key):'';
  document.title=(modules[key]?.title?modules[key].title+' · ':'')+'AMMO SUITE';
}
function setUserBox(){
  const em=currentAuth?.email||''; $('#userEmail').textContent=em||'—';
  const nm=em.split('@')[0].replace(/[._-]+/g,' ').trim(); const ini=nm.split(' ').filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase()||'A';
  $('#userAvatar').textContent=ini;
  document.querySelectorAll('.admin-only').forEach(x=>x.classList.toggle('hidden',!isAdmin()));
}
function openModule(key){
  const mod=modules[key]; if(!mod || !canSee(mod) || (mod.enabled===false && !isAdmin())) return;
  currentModule=key; markActive(key);
  document.body.classList.toggle('locked',!suiteUnlocked); document.body.classList.remove('booting');
  if(!suiteUnlocked){ $('#frame').src='about:blank'; $('#frame').classList.remove('visible'); $('#moduleLogin').classList.remove('hidden'); setTimeout(()=>$('#email').value?$('#password').focus():$('#email').focus(),50); return; }
  $('#moduleLogin').classList.add('hidden'); setUserBox();
  if(mod.openMode==='tab'){ chrome.tabs.create({url:mod.url}); return; }
  $('#frame').src=mod.url; $('#frame').classList.add('visible');
}
async function refreshModules(showStatus=false){
  if(registryBusy) return; registryBusy=true;
  try{
    if(currentAuth) currentAuth=await ammoRefreshAuth(currentAuth, FB.apiKey);
    const remote=await seedDefaults();
    const next={...DEFAULT_MODULES}; remote.forEach(m=>next[m.id]={...(next[m.id]||{}),...m});
    const signature=JSON.stringify(Object.values(next).map(m=>[m.id,m.title,m.icon,m.url,m.order,m.version,m.enabled,m.openMode,m.allowedEmails]));
    if(signature!==lastModuleSignature){
      const previous=modules, before=currentModule; modules=next; renderNav();
      if(suiteUnlocked && currentModule!==before){ markActive(currentModule); openModule(currentModule); } // admin paneli bağlayıb
      const active=modules[currentModule], old=previous[currentModule];
      if(suiteUnlocked && active && old && (active.url!==old.url || active.version!==old.version)){
        const tag=(document.activeElement?.tagName||'').toLowerCase();
        const editing=['input','textarea','select'].includes(tag);
        if(!editing) openModule(currentModule); else $('#syncStatus').textContent='☁ Yeni modul versiyası hazırdır';
      }
      lastModuleSignature=signature;
      if(!$('#adminOverlay').classList.contains('hidden')) renderAdminList();
    }
    if(showStatus) $('#syncStatus').textContent='☁ Yeniləndi';
    if(!$('#frame').classList.contains('visible') && suiteUnlocked) openModule(currentModule);
  }catch(e){ $('#syncStatus').textContent='⚠ Firebase bağlantısı'; }
  finally{registryBusy=false;}
}
async function unlockSuite(){
  if(authenticating) return; const email=$('#email').value.trim(), password=$('#password').value;
  if(!email||!password){ $('#loginMsg').textContent='Email və şifrəni yazın.'; return; }
  authenticating=true; $('#loginBtn').disabled=true; $('#loginMsg').textContent='Yoxlanılır...';
  try{
    const auth=await login(email,password); const candidate={idToken:auth.idToken,refreshToken:auth.refreshToken,uid:auth.localId,email:auth.email||email,loginAt:Date.now(),expiresAt:Date.now()+Number(auth.expiresIn||3600)*1000};
    const gate=await deviceGate(candidate); if(!gate.ok){ const err=new Error(gate.message); err.deviceLocked=true; throw err; }
    currentAuth=candidate;
    await chrome.storage.local.set({suiteAuth:currentAuth,ammoLastEmail:currentAuth.email}); suiteUnlocked=true; $('#password').value=''; $('#loginMsg').textContent='';
    $('#adminBtn').classList.toggle('hidden',!isAdmin());$('#panelsBtn').classList.toggle('hidden',!isAdmin()); await refreshModules(); openModule(currentModule); startPolling();
  }catch(e){ $('#loginMsg').textContent=e.deviceLocked?('🔒 '+e.message):'Giriş alınmadı. Email və ya şifrə yanlışdır.'; }
  finally{ authenticating=false; $('#loginBtn').disabled=false; }
}
async function lockSuite(){
  suiteUnlocked=false; currentAuth=null; document.body.classList.add('locked'); $('#userMenu').classList.add('hidden'); clearInterval(pollTimer); await chrome.storage.local.remove('suiteAuth');
  $('#frame').src='about:blank'; $('#frame').classList.remove('visible'); $('#moduleLogin').classList.remove('hidden'); $('#adminBtn').classList.add('hidden'); $('#panelsBtn').classList.add('hidden'); $('#panelsOverlay').classList.add('hidden'); $('#password').value=''; $('#loginMsg').textContent='';
}
function startPolling(){ clearInterval(pollTimer); pollTimer=setInterval(()=>refreshModules(false),5000); }
function renderAdminList(){
  const root=$('#moduleList'); root.innerHTML='';
  Object.values(modules).sort((a,b)=>(a.order||100)-(b.order||100)).forEach(m=>{
    const row=document.createElement('div'); row.className='module-row';
    const e=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));row.innerHTML=`<div><b>${e(m.icon||'◻')} ${e(m.title)}</b><small>${e(m.id)} · v${e(m.version||'1.0.0')} · ${e(m.url||'URL yoxdur')} · ${m.enabled===false?'deaktiv':'aktiv'}</small></div><div><button data-edit="${e(m.id)}">Düzəlt</button><button data-toggle="${e(m.id)}">${m.enabled===false?'Aktiv et':'Söndür'}</button>${m.builtin?'':'<button class="danger" data-del="'+m.id+'">Sil</button>'}</div>`;
    root.appendChild(row);
  });
  root.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>fillForm(modules[b.dataset.edit]));
  root.querySelectorAll('[data-toggle]').forEach(b=>b.onclick=async()=>{const m={...modules[b.dataset.toggle],enabled:modules[b.dataset.toggle].enabled===false}; await fsSet(m); await refreshModules();});
  root.querySelectorAll('[data-del]').forEach(b=>b.onclick=async()=>{if(confirm('Bu modulu silmək istəyirsiniz?')){await fsDelete(b.dataset.del);await refreshModules();}});
}
function fillForm(m={}){
  $('#modId').value=m.id||''; $('#modId').disabled=Boolean(m.id); $('#modTitle').value=m.title||''; $('#modIcon').value=m.icon||''; $('#modUrl').value=m.url||''; $('#modOrder').value=m.order||100; $('#modVersion').value=m.version||'1.0.0'; $('#modOpenMode').value=m.openMode||'iframe'; $('#modEnabled').checked=m.enabled!==false; $('#modAllowed').value=(m.allowedEmails||[]).join(', ');
}
$('#loginBtn').addEventListener('click',unlockSuite); $('#password').addEventListener('keydown',e=>{if(e.key==='Enter')unlockSuite();}); $('#email').addEventListener('keydown',e=>{if(e.key==='Enter')$('#password').focus();});
$('#reload').addEventListener('click',()=>{if(suiteUnlocked&&$('#frame').src!=='about:blank')$('#frame').contentWindow.location.reload();}); $('#lock').addEventListener('click',lockSuite);
$('#adminBtn').addEventListener('click',()=>{if(!isAdmin())return;$('#adminOverlay').classList.remove('hidden');fillForm();renderAdminList();}); $('#adminClose').addEventListener('click',()=>$('#adminOverlay').classList.add('hidden'));
$('#modSave').addEventListener('click',async()=>{
  const id=$('#modId').value.trim().replace(/[^a-zA-Z0-9_-]/g,''); const title=$('#modTitle').value.trim(), url=$('#modUrl').value.trim();
  if(!id||!title||!url){$('#adminMsg').textContent='Kod, ad və URL mütləqdir.';return;}
  const mod={id,title,icon:$('#modIcon').value.trim()||'◻',url,order:Number($('#modOrder').value)||100,version:$('#modVersion').value.trim()||'1.0.0',openMode:$('#modOpenMode').value,enabled:$('#modEnabled').checked,allowedEmails:$('#modAllowed').value.split(',').map(x=>x.trim().toLowerCase()).filter(Boolean),builtin:Boolean(modules[id]?.builtin)};
  try{await fsSet(mod);$('#adminMsg').textContent='Yadda saxlanıldı. Bütün kompüterlərdə görünəcək.';fillForm();await refreshModules();}catch(e){$('#adminMsg').textContent=e.message;}
});
(async()=>{
  await loadPanelPrefs();
  const {ammoLastEmail,suiteAuth}=await chrome.storage.local.get(['ammoLastEmail','suiteAuth']); if(ammoLastEmail)$('#email').value=ammoLastEmail;
  suiteUnlocked=await validateAuth(suiteAuth).catch(()=>false); if(!suiteUnlocked){await chrome.storage.local.remove('suiteAuth');renderNav();openModule(isHidden(requested)?currentModule:requested);return;}
  currentAuth=(await chrome.storage.local.get('suiteAuth')).suiteAuth||suiteAuth;
  const gate=await deviceGate(currentAuth);
  if(!gate.ok){ currentAuth=null; suiteUnlocked=false; await chrome.storage.local.remove('suiteAuth'); renderNav(); openModule(isHidden(requested)?currentModule:requested); $('#loginMsg').textContent='🔒 '+gate.message; return; }
  $('#adminBtn').classList.toggle('hidden',!isAdmin());$('#panelsBtn').classList.toggle('hidden',!isAdmin()); await refreshModules(); openModule(isHidden(requested)?currentModule:requested); startPolling();
})();

/* V31: panellərin vahid görünüşü modulların öz HTML-ində theme/ammo-ui.css ilə yüklənir. */

/* İstifadəçi menyusu */
(()=>{const btn=$('#userBtn'),menu=$('#userMenu');
  const close=()=>{menu.classList.add('hidden');btn.setAttribute('aria-expanded','false');};
  btn.addEventListener('click',e=>{e.stopPropagation();const open=menu.classList.contains('hidden');menu.classList.toggle('hidden',!open);btn.setAttribute('aria-expanded',String(open));});
  document.addEventListener('click',e=>{if(!menu.contains(e.target))close();});
  menu.addEventListener('click',e=>{const t=e.target.closest('.menu-item');if(t&&t.id!=='checkUpdateBtn')close();});
  $('#frame').addEventListener('load',()=>{try{$('#frame').contentDocument.addEventListener('click',close);}catch(e){}});
})();

/* === V30.2: Panelləri idarə et — YALNIZ ADMIN, BÜTÜN KOMPÜTERLƏR ÜÇÜN ===
   Admin paneli bağlayanda / açanda / sırasını dəyişəndə Firebase-dəki modul reyestri (suiteModules)
   yenilənir. İşçilərin AMMO SUITE-i reyestri 5 saniyədən bir oxuyur — dəyişiklik özləri üçün də dərhal tətbiq olunur.
   "👥" ilə panel yalnız seçilmiş işçilərə göstərilə bilər. */
function panelEsc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function panelList(){return Object.values(modules).filter(m=>!isRemovedModule(m)).sort((a,b)=>orderOf(a)-orderOf(b));}
let panelsBusy=false;
async function panelSave(mods,msg){
  if(panelsBusy) return; panelsBusy=true; $('#panelsCount').textContent='Serverə yazılır...';
  try{ for(const m of mods) await fsSet(m); lastModuleSignature=''; await refreshModules(); toastSuite(msg||'Yadda saxlanıldı — bütün kompüterlərdə tətbiq olunur'); }
  catch(e){ toastSuite('⚠ Yazılmadı: '+e.message); }
  finally{ panelsBusy=false; renderPanelsList(); }
}
function toastSuite(t){let x=document.getElementById('suiteToast');if(!x){x=document.createElement('div');x.id='suiteToast';document.body.appendChild(x);}x.textContent=t;x.classList.add('show');clearTimeout(x._t);x._t=setTimeout(()=>x.classList.remove('show'),2600);}
function whoText(m){const l=Array.isArray(m.allowedEmails)?m.allowedEmails:[];return l.length?`${l.length} işçi`:'Hamı';}
function renderPanelsList(){
  const list=panelList(), root=$('#panelsList');
  const on=list.filter(m=>m.enabled!==false).length;
  $('#panelsCount').textContent=`${on} / ${list.length} panel açıqdır · dəyişiklik bütün işçilərdə 5 saniyəyə tətbiq olunur`;
  root.innerHTML=list.map((m,i)=>{const en=m.enabled!==false;return `<div class="panel-row ${en?'':'off'}">
    <div class="panel-move"><button data-up="${panelEsc(m.id)}" ${i===0?'disabled':''} title="Yuxarı">▲</button><button data-down="${panelEsc(m.id)}" ${i===list.length-1?'disabled':''} title="Aşağı">▼</button></div>
    <div class="panel-name"><span class="panel-icon">${iconHtml(m)}</span><div><b>${panelEsc(m.title)}</b><small>${en?'Açıqdır — işçilərdə görünür':'Bağlıdır — işçilərdə görünmür, yalnız siz görürsünüz'}</small></div></div>
    <button class="panel-who" data-who="${panelEsc(m.id)}" title="Kimlər görsün">👥 ${panelEsc(whoText(m))}</button>
    <button class="panel-open" data-go="${panelEsc(m.id)}">Aç</button>
    <label class="switch" title="${en?'Hamı üçün bağla':'Hamı üçün aç'}"><input type="checkbox" data-toggle-panel="${panelEsc(m.id)}" ${en?'checked':''}><span></span></label>
  </div>`;}).join('');
  root.querySelectorAll('[data-toggle-panel]').forEach(x=>x.onchange=()=>{
    const m=modules[x.dataset.togglePanel];
    if(!x.checked && panelList().filter(p=>p.enabled!==false).length<=1){x.checked=true;return;}
    panelSave([{...m,enabled:x.checked}], `${m.title}: ${x.checked?'açıldı':'bağlandı'} — bütün işçilərdə`);
  });
  const move=(id,dir)=>{const arr=panelList();const i=arr.findIndex(m=>m.id===id),j=i+dir;if(i<0||j<0||j>=arr.length)return;[arr[i],arr[j]]=[arr[j],arr[i]];
    const changed=arr.map((m,k)=>({...m,order:(k+1)*10})).filter(m=>m.order!==modules[m.id].order); panelSave(changed,'Sıra yadda saxlanıldı');};
  root.querySelectorAll('[data-up]').forEach(b=>b.onclick=()=>move(b.dataset.up,-1));
  root.querySelectorAll('[data-down]').forEach(b=>b.onclick=()=>move(b.dataset.down,1));
  root.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{$('#panelsOverlay').classList.add('hidden');openModule(b.dataset.go);});
  root.querySelectorAll('[data-who]').forEach(b=>b.onclick=()=>openWho(modules[b.dataset.who]));
}
async function knownUsers(){
  const out=new Set();
  try{ let token=''; do{ const r=await fetch(`https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents/devices?pageSize=300${token?'&pageToken='+encodeURIComponent(token):''}`,{headers:{Authorization:`Bearer ${currentAuth.idToken}`}}); if(!r.ok) break; const d=await r.json(); (d.documents||[]).forEach(x=>{const e=x.fields?.email?.stringValue; if(e) out.add(e.toLowerCase());}); token=d.nextPageToken||''; }while(token); }catch(e){}
  Object.values(modules).forEach(m=>(m.allowedEmails||[]).forEach(e=>out.add(String(e).toLowerCase())));
  ADMIN_EMAILS.forEach(e=>out.delete(e));
  return [...out].sort();
}
async function openWho(m){
  const ov=document.createElement('div'); ov.className='admin-overlay'; ov.innerHTML=`<div class="admin-panel who-panel"><div class="admin-head"><div><h2>${panelEsc(m.icon)} ${panelEsc(m.title)} — kimlər görsün?</h2><p>Heç kim seçilməsə panel bütün işçilərdə görünür. Admin hər paneli həmişə görür.</p></div><button data-x>✕</button></div><div class="who-body">Yüklənir...</div><div class="who-foot"><input placeholder="Yeni e-poçt əlavə et" class="who-new"><button data-all>Hamı görsün</button><button class="primary-btn" data-save>Yadda saxla</button></div></div>`;
  document.body.appendChild(ov);
  const close=()=>ov.remove(); ov.querySelector('[data-x]').onclick=close; ov.onclick=e=>{if(e.target===ov)close();};
  const sel=new Set((m.allowedEmails||[]).map(e=>String(e).toLowerCase()));
  const users=await knownUsers();
  const draw=()=>{ ov.querySelector('.who-body').innerHTML=users.length?users.map(u=>`<label class="who-row"><input type="checkbox" value="${panelEsc(u)}" ${sel.has(u)?'checked':''}> ${panelEsc(u)}</label>`).join(''):'<p>Hələ işçi qeydə alınmayıb — aşağıdan e-poçt yazın.</p>'; ov.querySelectorAll('.who-row input').forEach(c=>c.onchange=()=>{c.checked?sel.add(c.value):sel.delete(c.value);}); };
  draw();
  ov.querySelector('.who-new').onkeydown=e=>{if(e.key==='Enter'){const v=e.target.value.trim().toLowerCase(); if(/@/.test(v)){ if(!users.includes(v)) users.push(v); sel.add(v); e.target.value=''; draw(); }}};
  ov.querySelector('[data-all]').onclick=()=>{close(); panelSave([{...m,allowedEmails:[]}],`${m.title}: hamı görür`);};
  ov.querySelector('[data-save]').onclick=()=>{const v=ov.querySelector('.who-new').value.trim().toLowerCase(); if(/@/.test(v)) sel.add(v); close(); panelSave([{...m,allowedEmails:[...sel]}],`${m.title}: ${sel.size?sel.size+' işçi görür':'hamı görür'}`);};
}
$('#panelsBtn').addEventListener('click',()=>{if(!isAdmin())return;renderPanelsList();$('#panelsOverlay').classList.remove('hidden');});
$('#panelsClose').addEventListener('click',()=>$('#panelsOverlay').classList.add('hidden'));
$('#panelsOverlay').addEventListener('click',e=>{if(e.target.id==='panelsOverlay')$('#panelsOverlay').classList.add('hidden');});
$('#adminOverlay').addEventListener('click',e=>{if(e.target.id==='adminOverlay')$('#adminOverlay').classList.add('hidden');});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('#panelsOverlay').classList.add('hidden');$('#adminOverlay').classList.add('hidden');}});
$('#panelsShowAll').addEventListener('click',()=>panelSave(panelList().filter(m=>m.enabled===false).map(m=>({...m,enabled:true})),'Bütün panellər hamı üçün açıldı'));
$('#panelsReset').addEventListener('click',()=>panelSave(panelList().map(m=>({...m,order:DEFAULT_MODULES[m.id]?.order??m.order})).filter(m=>m.order!==modules[m.id].order),'Sıra standarta qaytarıldı'));
$('#panelsAdmin').addEventListener('click',()=>{$('#panelsOverlay').classList.add('hidden');$('#adminOverlay').classList.remove('hidden');fillForm();renderAdminList();});
// Köhnə (V28) hər kompüterin öz gizli panel seçimi artıq istifadə olunmur
chrome.storage.local.remove('suitePanelPrefs').catch(()=>{});
