AMMO SUITE V25.3 — STATUS RƏNGLƏRİ

Bəyannamə Nəzarət statusları:
- TƏSDİQLƏNDİ: yaşıl
- UYĞUNSUZLUQ YOXLAMASINDA: qırmızı
- KAMERAL: sarı fon, qırmızı yazı, yanıb-sönür
- KAMERAL TƏSDİQLƏNDİ: yaşıl, yanıb-sönür
- ANOLOJİ: bənövşəyi
- ANOLOJİ TƏSDİQLƏNDİ: yaşıl, yanıb-sönür
- TƏQDİM OLUNAN: tünd göy

Açılan seçim siyahısında bütün statuslar qara rəngdə görünür. Rənglər yalnız cədvəldə status göstəriləndə tətbiq olunur.
