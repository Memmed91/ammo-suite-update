AMMO SUITE V14 Cloud Sync
- V13 məlumatlarının avtomatik miqrasiyası
- Açar-səviyyəli Firestore sinxronizasiya
- İki istifadəçi üçün daha təhlükəsiz merge
- Tokenin avtomatik yenilənməsi
- Ekran refresh olmadan səssiz məlumat qəbulu
- Mərkəzi modul siyahısı, URL və versiya idarəsi
