(() => {
  const API_KEY = 'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg';
  document.documentElement.style.visibility = 'hidden';

  async function deny() {
    try { await chrome.storage.local.remove('suiteAuth'); } catch (_) {}
    const target = chrome.runtime.getURL('suite.html');
    // V28: SUITE içində ikinci SUITE açılmasın — əsas pəncərəni yönləndir
    try { if (window.top !== window) { window.top.location.replace(target); return; } } catch (_) {}
    if (location.href !== target) location.replace(target);
  }

  function allow(suiteAuth) {
    window.AMMO_SUITE_AUTH = suiteAuth;
    document.documentElement.style.visibility = '';
    window.dispatchEvent(new CustomEvent('ammo-suite-auth-ready', { detail: suiteAuth }));
  }

  async function ammoRefreshAuth(a,apiKey){
    if(!a?.refreshToken) return a;
    if(a.expiresAt && Date.now() < Number(a.expiresAt) - 120000) return a;
    try{
      const r=await fetch(`https://securetoken.googleapis.com/v1/token?key=${apiKey}`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',refresh_token:a.refreshToken})});
      const d=await r.json();
      if(r.ok){ a={...a,idToken:d.id_token,refreshToken:d.refresh_token||a.refreshToken,uid:d.user_id||a.uid,expiresAt:Date.now()+Number(d.expires_in||3600)*1000}; await chrome.storage.local.set({suiteAuth:a}); }
    }catch(e){}
    return a;
  }
  
  async function validate() {
    try {
      let { suiteAuth } = await chrome.storage.local.get('suiteAuth');
      suiteAuth = await ammoRefreshAuth(suiteAuth, API_KEY);
      if (!suiteAuth?.idToken || !suiteAuth?.uid) return deny();
      const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken: suiteAuth.idToken })
      });
      const data = await response.json().catch(() => ({}));
      const user = data?.users?.[0];
      if (response.status >= 500) return allow(suiteAuth); // server müvəqqəti xətası — çıxarma
      if (!response.ok || !user || user.localId !== suiteAuth.uid || user.disabled) return deny();
      allow(suiteAuth);
    } catch (_) {
      // V28: internet yoxdursa istifadəçini sistemdən çıxarma — giriş artıq edilib
      const { suiteAuth } = await chrome.storage.local.get('suiteAuth').catch(() => ({}));
      if (suiteAuth?.idToken && suiteAuth?.uid) allow(suiteAuth); else deny();
    }
  }
  validate();
})();
