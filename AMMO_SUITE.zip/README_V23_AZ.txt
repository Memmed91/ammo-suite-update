AMMO SUITE V23

Düzəlişlər:
- Tapşırıq bazaya yazılan kimi təxminən 1 saniyə ərzində yaşıl "Tapşırıq göndərildi" bildirişi göstərilir.
- PDF, Excel, Word, JPG/PNG və digər fayllar arxa planda yüklənir.
- Şəkil data: ünvanı ilə yox, Blob URL ilə açılır.
- Həm göndərən, həm alan tərəfdə hər fayl üçün "Bax" və "Yüklə" düymələri var.

MÜTLƏQ:
Firebase Console > Firestore Database > Rules bölməsində
modules/taskpanel/firestore.rules faylının məzmununu yerləşdirib Publish basın.
Əks halda digər kompüter taskFileChunks kolleksiyasını oxuya bilməz.
