/* AMMO SUITE V30.2 — e-taxes kabinetində (new.e-taxes.gov.az) işləyir, MAIN world.
   Kabinet səhifəsinin öz API sorğularını PASSİV izləyir və AMMO üçün iki şeyi yadda saxlayır:
     1) Məktublar/bildirişlər siyahısını qaytaran API ünvanı (ammo_etax_letter_eps)
     2) Açıq kabinetin şirkəti — VÖEN və ad (ammo_etax_taxpayer)
   Heç bir sorğu göndərmir, heç nəyi dəyişmir; yalnız səhifənin aldığı cavablara baxır. */
(() => {
  'use strict';
  if (window.__ammoEtaxCapture) return; window.__ammoEtaxCapture = true;
  const LETTER_RX = /(letter|mektub|m%C9%99ktub|message|notif|bildiri|inbox|mailbox|correspond|xeberdar|warning|appeal|muraciet)/i;
  const SKIP_RX = /(\.js|\.css|\.png|\.svg|\/i18n|translation|dictionary|\/count\b|unread-?count)/i;
  const PROFILE_RX = /(profile|taxpayer|account|cabinet|user|\/me\b|session|whoami)/i;
  const TIN_RX = /^\d{10}$/;

  function save(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* yer yoxdur */ } }
  function load(key, def) { try { return JSON.parse(localStorage.getItem(key) || 'null') ?? def; } catch (e) { return def; } }

  function biggestArray(o, depth = 0) {
    let best = null;
    if (!o || depth > 4) return null;
    if (Array.isArray(o)) { if (o.length && typeof o[0] === 'object' && o[0]) best = o; o.slice(0, 3).forEach((x) => { const b = biggestArray(x, depth + 1); if (b && (!best || b.length > best.length)) best = b; }); return best; }
    if (typeof o === 'object') for (const v of Object.values(o)) { const b = biggestArray(v, depth + 1); if (b && (!best || b.length > best.length)) best = b; }
    return best;
  }
  function findTaxpayer(o, depth = 0, out = { voen: '', name: '', score: 0 }) {
    if (!o || typeof o !== 'object' || depth > 4) return out;
    let localTin = '', localName = '';
    for (const [k, v] of Object.entries(o)) {
      if ((typeof v === 'string' || typeof v === 'number') && /(^|_)(tin|voen)$|taxpayerTin|orgTin|companyTin|legalTin/i.test(k) && TIN_RX.test(String(v))) localTin = String(v);
      if (typeof v === 'string' && /^(name|fullName|taxpayerName|orgName|organizationName|companyName|legalName|title)$/i.test(k) && v.trim().length > 2) localName = v.trim();
    }
    if (localTin) { const sc = (localName ? 2 : 1); if (sc > out.score) { out.voen = localTin; out.name = localName; out.score = sc; } }
    for (const v of Object.values(o)) if (v && typeof v === 'object') findTaxpayer(v, depth + 1, out);
    return out;
  }

  function onJson(url, method, body, json) {
    try {
      const u = new URL(url, location.href);
      if (!/\/api\//.test(u.pathname) || SKIP_RX.test(u.pathname)) return;
      if (LETTER_RX.test(u.pathname + u.search)) {
        const arr = biggestArray(json);
        if (arr && arr.length >= 0) {
          const list = load('ammo_etax_letter_eps', []).filter((x) => x.path !== u.pathname || x.method !== method);
          list.unshift({ url: u.href, path: u.pathname, method, body: body && typeof body === 'string' && body.length < 4000 ? body : '', at: Date.now(), count: arr.length });
          save('ammo_etax_letter_eps', list.slice(0, 6));
        }
      }
      if (PROFILE_RX.test(u.pathname)) {
        const tp = findTaxpayer(json);
        if (tp.voen) save('ammo_etax_taxpayer', { voen: tp.voen, name: tp.name, at: Date.now(), from: u.pathname });
      }
    } catch (e) { /* səssiz */ }
  }

  const ofetch = window.fetch;
  window.fetch = async function (input, init) {
    const res = await ofetch.apply(this, arguments);
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      const method = ((init && init.method) || (input && input.method) || 'GET').toUpperCase();
      const ct = res.headers.get('content-type') || '';
      if (/json/i.test(ct) && /\/api\//.test(url)) res.clone().json().then((j) => onJson(url, method, init && init.body, j)).catch(() => {});
    } catch (e) { /* səssiz */ }
    return res;
  };
  const oopen = XMLHttpRequest.prototype.open, osend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__ammo = { m: String(m || 'GET').toUpperCase(), u: String(u || '') }; return oopen.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      const meta = this.__ammo;
      if (meta && /\/api\//.test(meta.u)) this.addEventListener('load', () => {
        try {
          if (!/json/i.test(this.getResponseHeader('content-type') || '')) return;
          const j = this.responseType === 'json' ? this.response : JSON.parse(this.responseText);
          onJson(meta.u, meta.m, body, j);
        } catch (e) { /* səssiz */ }
      });
    } catch (e) { /* səssiz */ }
    return osend.apply(this, arguments);
  };
})();
