/* AMMO SUITE V31 — vahid Firebase (konsalting-79c40) girişi və GOMRUK-NEZARET-dən köçürmə.
   Bəyannamə nəzarət və Vergi məktubları artıq AMMO SUITE-in öz layihəsindədir (Konsalting).
   Giriş AMMO SUITE-in tokeni ilə olur — ayrıca parol və ya anonim sessiya yoxdur.

   Köçürmə: panel açılanda köhnə layihədəki (gomruk-nezaret) qeydlər Konsalting-ə köçürülür.
   - Konsalting-də olmayan qeyd əlavə olunur.
   - Hər iki yerdə varsa, köhnə layihədəki daha yenidirsə (updatedAt) yenilənir — keçid dövründə köhnə
     versiyada işləyən kompüterlərin yazdıqları da itmir.
   - Konsalting-də silinmiş (deleted: true) qeyd geri qaytarılmır.
   - Köhnə layihə bağlanandan (və ya 2027-01-01-dən) sonra köçürmə özü dayanır. */
(() => {
  'use strict';
  const PROJECT = 'konsalting-79c40', API_KEY = 'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg';
  const ROOT = `https://firestore.googleapis.com/v1/projects/${PROJECT}/databases/(default)/documents`;
  const OLD = { project: 'gomruk-nezaret', key: 'AIzaSyCwcYEbn6WAIhgYgYwCPsEde1uPjPL7n_8' };
  const OLD_ROOT = `https://firestore.googleapis.com/v1/projects/${OLD.project}/databases/(default)/documents`;
  const MIGRATION_END = Date.parse('2027-01-01T00:00:00+04:00');

  async function refresh(a, force) {
    if (!a?.refreshToken) return a;
    if (!force && a.expiresAt && Date.now() < Number(a.expiresAt) - 120000) return a;
    try {
      const r = await fetch(`https://securetoken.googleapis.com/v1/token?key=${API_KEY}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: a.refreshToken }) });
      const d = await r.json();
      if (r.ok) { a = { ...a, idToken: d.id_token, refreshToken: d.refresh_token || a.refreshToken, uid: d.user_id || a.uid, expiresAt: Date.now() + Number(d.expires_in || 3600) * 1000 }; await chrome.storage.local.set({ suiteAuth: a }); }
    } catch (e) { /* oflayn — köhnə tokenlə davam */ }
    return a;
  }
  async function auth(force) {
    const { suiteAuth } = await chrome.storage.local.get('suiteAuth');
    if (!suiteAuth?.idToken) throw new Error('AMMO SUITE girişi yoxdur');
    return refresh(suiteAuth, force);
  }
  async function request(url, opt = {}, retried) {
    const a = await auth(retried);
    const res = await fetch(url, { ...opt, cache: 'no-store', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + a.idToken, ...(opt.headers || {}) } });
    if (res.status === 401 && !retried) return request(url, opt, true);
    const text = await res.text(); let json = {};
    try { json = text ? JSON.parse(text) : {}; } catch (e) { /* boş */ }
    if (!res.ok) { const err = new Error(json?.error?.message || ('Firebase xəta: ' + res.status)); err.status = res.status; throw err; }
    return json;
  }
  async function listAll(base, fetcher) {
    const out = []; let token = '';
    do {
      const j = await fetcher(`${base}?pageSize=300${token ? '&pageToken=' + encodeURIComponent(token) : ''}`);
      (j.documents || []).forEach((d) => out.push(d)); token = j.nextPageToken || '';
    } while (token);
    return out;
  }
  const idOf = (name) => String(name || '').split('/').pop();
  const num = (f) => (!f ? 0 : Number(f.integerValue ?? f.doubleValue ?? f.stringValue ?? 0) || 0);

  /* ---------- köhnə layihəyə yalnız oxumaq üçün giriş ---------- */
  async function oldToken() {
    const keys = ['beyannameFirebaseAuth', 'ammo_beyanname_nezaret_fixed_auth', 'ammoOldGomrukAuth'];
    const st = await chrome.storage.local.get(keys);
    for (const k of keys) {
      const a = st[k]; if (!a?.refreshToken) continue;
      if (a.idToken && Date.now() < Number(a.expiresAt || 0) - 120000) return a.idToken;
      try {
        const r = await fetch(`https://securetoken.googleapis.com/v1/token?key=${OLD.key}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: a.refreshToken }) });
        const d = await r.json(); if (r.ok) { await chrome.storage.local.set({ [k]: { ...a, idToken: d.id_token, refreshToken: d.refresh_token || a.refreshToken, expiresAt: Date.now() + Number(d.expires_in || 3600) * 1000 } }); return d.id_token; }
      } catch (e) { /* növbəti */ }
    }
    const r = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${OLD.key}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ returnSecureToken: true }) });
    const d = await r.json(); if (!r.ok) { const e = new Error(d?.error?.message || 'old_auth'); e.status = r.status; throw e; }
    await chrome.storage.local.set({ ammoOldGomrukAuth: { idToken: d.idToken, refreshToken: d.refreshToken, expiresAt: Date.now() + Number(d.expiresIn || 3600) * 1000 } });
    return d.idToken;
  }

  const running = {};
  async function migrate(collection) {
    if (running[collection]) return running[collection];
    return (running[collection] = (async () => {
      const flagKey = 'ammoMigV31_' + collection;
      const { [flagKey]: flag } = await chrome.storage.local.get(flagKey);
      if (flag?.closed || Date.now() > MIGRATION_END) return { skipped: true };
      if (flag?.at && Date.now() - flag.at < 6 * 60 * 60 * 1000) return { skipped: true, recent: true }; // V31.0.2: 6 saatda bir (oxuma limitinə qənaət)
      let oldDocs;
      try {
        const tok = await oldToken();
        oldDocs = await listAll(`${OLD_ROOT}/${collection}`, async (u) => {
          const r = await fetch(u, { headers: { Authorization: 'Bearer ' + tok }, cache: 'no-store' });
          const j = await r.json().catch(() => ({}));
          if (!r.ok) { const e = new Error(j?.error?.message || ('HTTP ' + r.status)); e.status = r.status; throw e; }
          return j;
        });
      } catch (e) {
        // Köhnə layihə silinib / bağlanıb → köçürmə bir daha işləməsin
        if ([400, 403, 404].includes(e.status) && /NOT_FOUND|deleted|disabled|CONFIGURATION_NOT_FOUND|PROJECT|API key|has not been used/i.test(String(e.message))) await chrome.storage.local.set({ [flagKey]: { closed: true, at: Date.now() } });
        return { error: String(e.message || e) };
      }
      const cur = await listAll(`${ROOT}/${collection}`, (u) => request(u));
      const have = new Map(cur.map((d) => [idOf(d.name), d.fields || {}]));
      let added = 0, updated = 0, failed = 0;
      for (const d of oldDocs) {
        const id = idOf(d.name), f = d.fields || {}, mine = have.get(id);
        let precond = '';
        if (!mine) precond = '?currentDocument.exists=false';
        else if (mine.deleted?.booleanValue === true) continue;
        else if (!(num(f.updatedAt) > num(mine.updatedAt))) continue;
        try {
          await request(`${ROOT}/${collection}/${encodeURIComponent(id)}${precond}`, { method: 'PATCH', body: JSON.stringify({ fields: f }) });
          mine ? updated++ : added++;
        } catch (e) { if (e.status !== 400 && e.status !== 409) failed++; }
      }
      if (added || updated) window.AMMO_REV?.bump(collection);
      if (!failed) await chrome.storage.local.set({ [flagKey]: { at: Date.now(), old: oldDocs.length, added, updated } });
      return { added, updated, failed, old: oldDocs.length };
    })().finally(() => { delete running[collection]; }));
  }

  window.AMMO_FS = { PROJECT, ROOT, base: (c) => `${ROOT}/${c}`, request, auth, migrate };
})();
