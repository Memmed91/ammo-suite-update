/* Qəbul ekranı: müəllimlərin boş saatları (proqram açılan kimi), boş vaxt axtarışı, bu günün dərsləri. */
(function () {
  'use strict';
  const { D, L, $, $$, esc, money, today } = K;
  const st = { course: '', plan: '2x', days: [], time: '', teacher: '' };

  function todayLessons() {
    const t = today(), out = [];
    for (const s of D.students) {
      if (s.status === 'left' || s.status === 'finished') continue;
      const l = L.lessons(s, D, t).find((x) => x.date === t);
      if (l) out.push({ s, l });
    }
    return out.sort((a, b) => a.l.from.localeCompare(b.l.from));
  }

  function kpis() {
    const t = today(), ym = t.slice(0, 7);
    const active = D.students.filter((s) => s.status !== 'left' && s.status !== 'finished');
    let ending = 0, endingShare = 0, debt = 0, soon = 0;
    for (const s of active) for (const m of L.months(s, D, t)) {
      if (m.end && m.end.slice(0, 7) === ym) { ending++; const tc = K.teacher(m.teacherId); endingShare += Math.min(m.paid, m.due) * (Number(tc && tc.percent) || 0) / 100; }
      if (m.started) debt += m.debt;
      if (m.end && !m.completed && m.daysLeft != null && m.daysLeft <= 3) soon++;
    }
    return `<div class="kpis">
      <div class="kpi acc"><span>Aktiv tələbə</span><b>${active.length}</b><small>${D.teachers.length} müəllim · ${D.courses.length} kurs</small></div>
      <div class="kpi"><span>Bu gün dərs</span><b>${todayLessons().length}</b><small>${L.DAY_FULL[new Date().getDay()]}</small></div>
      <div class="kpi ok"><span>Bu ay bitən aylar</span><b>${ending}</b><small>müəllim payı ≈ ${money(endingShare)}</small></div>
      <div class="kpi warn"><span>3 gündə bitəcək</span><b>${soon}</b><small>ödəniş vaxtı yaxınlaşır</small></div>
      <div class="kpi bad"><span>Ödənilməmiş borc</span><b>${money(debt)}</b><small>başlamış aylar üzrə</small></div>
    </div>`;
  }

  function slotTxt(x) { return `${L.toTime(x.from)}–${L.toTime(x.to)}`; }

  function board() {
    const ts = D.teachers.filter((t) => t.active !== false && (!st.course || (t.courseIds || []).includes(st.course)));
    if (!ts.length) return `<div class="card"><div class="empty">${D.teachers.length ? 'Bu kurs üzrə müəllim yoxdur.' : 'Hələ müəllim əlavə edilməyib. Yuxarıdan “＋ Müəllim” basın.'}</div></div>`;
    const wdToday = new Date().getDay();
    return `<div class="board"><table><thead><tr><th>Müəllim</th>${L.DAY_ORDER.map((d) => `<th class="${d === wdToday ? 'today-col' : ''}">${L.DAY_FULL[d]}${d === wdToday ? ' · bu gün' : ''}</th>`).join('')}</tr></thead><tbody>
      ${ts.map((t) => {
        const { free, busy } = L.freeOf(t, D, today());
        const work = new Set((t.workDays || [1, 2, 3, 4, 5, 6]).map(Number));
        return `<tr><td class="tc"><div class="who">${K.avatar(t, t.photoKey)}<div><b><button class="link" data-week="${t.id}">${esc(L.fullName(t))}</button></b><small>${esc((t.courseIds || []).map(K.cName).join(', ') || '—')}</small><br><small>${esc(t.workFrom || '09:00')}–${esc(t.workTo || '20:00')}</small></div></div></td>
        ${L.DAY_ORDER.map((d) => !work.has(d) ? '<td class="off">iş günü deyil</td>' : `<td class="${d === wdToday ? 'today-col' : ''}">${free[d].map((x) => `<span class="slot free">✓ ${slotTxt(x)}</span>`).join('') || '<span class="pill bad">Boş vaxt yoxdur</span>'}${busy[d].length ? `<span class="small muted">${busy[d].length} dərs</span>` : ''}</td>`).join('')}</tr>`;
      }).join('')}
    </tbody></table></div>`;
  }

  function finder() {
    return `<div class="card"><div class="card-h"><div><h3>Boş vaxt axtar</h3><p class="sub">Tələbə “hansı günlər, hansı saat boşdur?” soruşanda: kursu, planı və günləri seçin.</p></div></div>
      <div class="toolbar">
        <select id="fCourse"><option value="">Bütün kurslar</option>${K.opt(D.courses, st.course)}</select>
        <select id="fPlan">${Object.entries(L.PLANS).map(([k, p]) => `<option value="${k}" ${k === st.plan ? 'selected' : ''}>${p.label} · ${(D.settings.plans || {})[k] || p.hours} saat</option>`).join('')}</select>
        <div class="chips" id="fDays">${L.DAY_ORDER.map((d) => `<span class="chip ${st.days.includes(d) ? 'on' : ''}" data-d="${d}">${L.DAY_SHORT[d]}</span>`).join('')}</div>
        <span class="chip" data-pre="odd">Tək günlər</span><span class="chip" data-pre="even">Cüt günlər</span>
        <input type="time" id="fTime" value="${st.time}" title="İstəyə bağlı: konkret saat">
        <button class="btn primary" id="fGo">Axtar</button>
      </div>
      <div id="fRes"></div></div>`;
  }

  function search(root) {
    const hours = Number((D.settings.plans || {})[st.plan] || L.PLANS[st.plan].hours);
    const need = hours * 60;
    const days = st.days.length ? st.days : (st.plan === 'intensive' ? L.PRESETS.all : []);
    const res = $('#fRes', root);
    if (!days.length) { res.innerHTML = '<div class="alert info">Günləri seçin (və ya “Tək günlər / Cüt günlər”).</div>'; return; }
    const ts = D.teachers.filter((t) => t.active !== false && (!st.course || (t.courseIds || []).includes(st.course)));
    const rows = [];
    for (const t of ts) {
      const { free } = L.freeOf(t, D, today(), 1);
      // bütün seçilmiş günlərdə ortaq boş pəncərələr
      let common = null;
      for (const d of days) {
        const f = (free[d] || []).map((x) => [x.from, x.to]);
        common = common == null ? f : intersect(common, f);
      }
      common = (common || []).filter(([a, b]) => b - a >= need);
      if (st.time) {
        const a = L.toMin(st.time), b = a + need;
        const ok = common.some(([x, y]) => a >= x && b <= y);
        rows.push({ t, common, ok, exact: true });
      } else rows.push({ t, common, ok: common.length > 0 });
    }
    rows.sort((a, b) => Number(b.ok) - Number(a.ok));
    res.innerHTML = rows.length ? `<div class="tbl-wrap"><table class="t"><thead><tr><th>Müəllim</th><th>${days.map((d) => L.DAY_SHORT[d]).join(', ')} günləri ortaq boş vaxt (${hours} saatlıq dərs üçün)</th><th>Nəticə</th><th></th></tr></thead><tbody>
      ${rows.map((r) => `<tr><td><div class="who">${K.avatar(r.t, r.t.photoKey)}<div><b>${esc(L.fullName(r.t))}</b><small>${esc((r.t.courseIds || []).map(K.cName).join(', '))}</small></div></div></td>
      <td>${r.common.length ? r.common.map(([a, b]) => `<span class="slot free" style="display:inline-block">${L.toTime(a)}–${L.toTime(b)}</span>`).join(' ') : '<span class="muted">ortaq boş vaxt yoxdur</span>'}</td>
      <td>${r.ok ? `<span class="pill ok">${r.exact ? st.time + ' uyğundur' : 'Uyğundur'}</span>` : `<span class="pill bad">${r.exact ? st.time + ' məşğuldur' : 'Uyğun deyil'}</span>`}</td>
      <td>${r.ok ? `<button class="btn sm soft" data-enroll="${r.t.id}">Tələbə yaz</button>` : ''} <button class="btn sm ghost" data-week="${r.t.id}">Həftə</button></td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty">Bu kurs üzrə müəllim yoxdur.</div>';
    $$('[data-enroll]', res).forEach((b) => b.onclick = () => K.editStudent(null, { teacherId: b.dataset.enroll, courseId: st.course, plan: st.plan, days, startTime: st.time || (rows.find((r) => r.t.id === b.dataset.enroll).common[0] ? L.toTime(rows.find((r) => r.t.id === b.dataset.enroll).common[0][0]) : '') }));
    $$('[data-week]', res).forEach((b) => b.onclick = () => K.teacherWeek(K.teacher(b.dataset.week)));
  }
  function intersect(A, B) { const out = []; for (const [a1, a2] of A) for (const [b1, b2] of B) { const s = Math.max(a1, b1), e = Math.min(a2, b2); if (e > s) out.push([s, e]); } return out; }

  /** Müəllimin həftəlik vizual cədvəli */
  K.teacherWeek = function (t) {
    if (!t) return;
    const { free, busy } = L.freeOf(t, D, today());
    const work = new Set((t.workDays || [1, 2, 3, 4, 5, 6]).map(Number));
    const s0 = Math.floor(Math.min(L.toMin(t.workFrom || '09:00'), ...Object.values(busy).flat().map((b) => b.from)) / 60) * 60;
    const e0 = Math.ceil(Math.max(L.toMin(t.workTo || '20:00'), ...Object.values(busy).flat().map((b) => b.to)) / 60) * 60;
    const PX = 44 / 60, H = (e0 - s0) * PX;
    const hours = []; for (let m = s0; m < e0; m += 60) hours.push(m);
    const col = (d) => `<div class="col ${work.has(d) ? '' : 'off'}" style="height:${H}px">${hours.map(() => '<div class="hr"></div>').join('')}
      ${(free[d] || []).map((x) => `<div class="blk free" style="top:${(x.from - s0) * PX}px;height:${(x.to - x.from) * PX - 2}px">Boş<br>${L.toTime(x.from)}–${L.toTime(x.to)}</div>`).join('')}
      ${(busy[d] || []).map((b) => `<div class="blk busy" style="top:${(b.from - s0) * PX}px;height:${(b.to - b.from) * PX - 2}px" title="${esc(L.fullName(b.student))}"><b>${L.toTime(b.from)}–${L.toTime(b.to)}</b><br>${esc(L.fullName(b.student))}<br><span style="opacity:.7">${esc(K.cName(b.student.courseId))}</span></div>`).join('')}</div>`;
    K.modal({
      title: `${L.fullName(t)} — həftəlik cədvəl`, full: true,
      body: `<div class="toolbar"><span class="pill acc">İş saatı ${esc(t.workFrom || '09:00')}–${esc(t.workTo || '20:00')}</span><span class="slot busy" style="display:inline-block">Dərs</span><span class="slot free" style="display:inline-block">Boş</span></div>
      <div class="timeline"><div class="hd"></div>${L.DAY_ORDER.map((d) => `<div class="hd">${L.DAY_FULL[d]}</div>`).join('')}
      <div style="height:${H}px">${hours.map((m) => `<div class="hr">${L.toTime(m)}</div>`).join('')}</div>${L.DAY_ORDER.map(col).join('')}</div>`,
      actions: [{ label: 'Bu müəllimə tələbə yaz', cls: 'primary', onClick: () => K.editStudent(null, { teacherId: t.id, courseId: (t.courseIds || [])[0] || '' }) }, { label: 'Bağla' }]
    });
  };

  K.register('home', {
    render(view) {
      K.sub(`${L.DAY_FULL[new Date().getDay()]}, ${L.fmtDate(today())} — müəllimlərin boş saatları`);
      const tl = todayLessons();
      view.innerHTML = `${kpis()}
      <div class="stack">
        ${finder()}
        <div class="card"><div class="card-h"><div><h3>Müəllimlərin həftəlik boş saatları</h3><p class="sub">Yaşıl — boş vaxt. Müəllimin adına klikləyin — həftəlik vizual cədvəl açılır.</p></div>
          <select id="bCourse"><option value="">Bütün kurslar</option>${K.opt(D.courses, st.course)}</select></div>
          ${board()}</div>
        <div class="card"><div class="card-h"><div><h3>Bu günün dərsləri</h3><p class="sub">${tl.length} dərs</p></div><button class="btn sm soft" id="toAtt">Davamiyyəti qeyd et →</button></div>
          ${tl.length ? `<div class="tbl-wrap"><table class="t"><thead><tr><th>Saat</th><th>Tələbə</th><th>Kurs</th><th>Müəllim</th><th>Vəziyyət</th></tr></thead><tbody>${tl.map(({ s, l }) => `<tr class="click" data-st="${s.id}"><td><b>${l.from}–${l.to}</b></td><td>${esc(L.fullName(s))}</td><td>${esc(K.cName(s.courseId))}</td><td>${esc(K.tName(s.teacherId))}</td><td>${K.statusPill(l.status)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Bu gün dərs yoxdur.</div>'}
        </div>
      </div>`;
      const root = view;
      $('#bCourse', root).onchange = (e) => { st.course = e.target.value; K.refresh(); };
      $('#fCourse', root).onchange = (e) => { st.course = e.target.value; };
      $('#fPlan', root).onchange = (e) => { st.plan = e.target.value; if (st.plan === 'intensive' && !st.days.length) st.days = L.PRESETS.all.slice(); $$('#fDays .chip', root).forEach((c) => c.classList.toggle('on', st.days.includes(Number(c.dataset.d)))); };
      $$('#fDays .chip', root).forEach((c) => c.onclick = () => { const d = Number(c.dataset.d); st.days = st.days.includes(d) ? st.days.filter((x) => x !== d) : [...st.days, d]; c.classList.toggle('on'); });
      $$('[data-pre]', root).forEach((c) => c.onclick = () => { st.days = L.PRESETS[c.dataset.pre].slice(); $$('#fDays .chip', root).forEach((x) => x.classList.toggle('on', st.days.includes(Number(x.dataset.d)))); });
      $('#fTime', root).onchange = (e) => { st.time = e.target.value; };
      $('#fGo', root).onclick = () => search(root);
      $$('[data-week]', root).forEach((b) => b.onclick = () => K.teacherWeek(K.teacher(b.dataset.week)));
      $$('[data-st]', root).forEach((r) => r.onclick = () => K.openStudent(r.dataset.st));
      $('#toAtt', root).onclick = () => K.go('attendance');
      K.hydrateAvatars(root);
    }
  });

  K.statusPill = function (s) {
    return ({ present: '<span class="pill ok">Gəldi</span>', assumed: '<span class="pill ok">Keçirilib</span>', unexcused: '<span class="pill bad">Üzrsüz — sayılır</span>', excused: '<span class="pill warn">Üzrlü — əvəz olunur</span>', planned: '<span class="pill acc">Planlı</span>', holiday: '<span class="pill mute">Bayram</span>', teacherAbsent: '<span class="pill warn">Müəllim gəlmədi</span>', extra: '<span class="pill ok">Əvəz dərsi</span>' })[s] || s;
  };
})();
