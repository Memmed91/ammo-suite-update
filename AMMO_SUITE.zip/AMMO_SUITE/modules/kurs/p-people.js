/* Tələbələr, müəllimlər, kurslar */
(function () {
  'use strict';
  const { D, L, $, $$, esc, money, today, uid } = K;
  const f = (name, label, val = '', type = 'text', extra = '') => `<label class="f"><span>${label}</span><input name="${name}" type="${type}" value="${esc(val ?? '')}" ${extra}></label>`;
  const sel = (name, label, options, extra = '') => `<label class="f"><span>${label}</span><select name="${name}" ${extra}>${options}</select></label>`;
  const statusTxt = { active: '<span class="pill ok">Aktiv</span>', finished: '<span class="pill acc">Bitirib</span>', left: '<span class="pill mute">Ayrılıb</span>', paused: '<span class="pill warn">Dayandırılıb</span>' };

  // ================================================================= TƏLƏBƏLƏR
  const sf = { q: '', course: '', teacher: '', status: 'active' };
  function curMonth(s) { const ms = L.months(s, D, today()); return { ms, cur: ms.find((m) => !m.completed) || null, done: ms.filter((m) => m.completed).length, debt: ms.filter((m) => m.started).reduce((a, m) => a + m.debt, 0) }; }

  K.register('students', {
    render(view) {
      const list = D.students.filter((s) => (!sf.course || s.courseId === sf.course) && (!sf.teacher || s.teacherId === sf.teacher) && (sf.status === 'all' || (s.status || 'active') === sf.status)
        && (!sf.q || `${L.fullName(s)} ${s.fatherName || ''} ${s.phone || ''} ${s.parentPhone || ''} ${s.fin || ''}`.toLowerCase().includes(sf.q.toLowerCase())))
        .sort((a, b) => L.fullName(a).localeCompare(L.fullName(b), 'az'));
      K.sub(`${list.length} tələbə`);
      view.innerHTML = `<div class="toolbar">
        <input class="grow" id="sq" placeholder="Ad, telefon, FİN üzrə axtar…" value="${esc(sf.q)}">
        <select id="sc"><option value="">Bütün kurslar</option>${K.opt(D.courses, sf.course)}</select>
        <select id="stc"><option value="">Bütün müəllimlər</option>${K.opt(D.teachers, sf.teacher, L.fullName)}</select>
        <select id="sst">${[['active', 'Aktiv'], ['finished', 'Bitirənlər'], ['left', 'Ayrılanlar'], ['paused', 'Dayandırılan'], ['all', 'Hamısı']].map(([v, l]) => `<option value="${v}" ${sf.status === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <button class="btn primary" id="sAdd">＋ Yeni tələbə</button></div>
        <div class="tbl-wrap"><table class="t"><thead><tr><th>Tələbə</th><th>Kurs / müəllim</th><th>Cədvəl</th><th>Cari ay</th><th>Ayın sonu</th><th class="n">Aylıq</th><th class="n">Borc</th><th>Status</th></tr></thead><tbody>
        ${list.map((s) => { const c = curMonth(s); const m = c.cur; const pct = m ? Math.min(100, Math.round(m.hoursDone / m.hoursTotal * 100)) : 100;
          return `<tr class="click" data-open="${s.id}"><td><div class="who">${K.avatar(s, s.photoKey)}<div><b>${esc(L.fullName(s))}</b><small>${esc(s.phone || s.parentPhone || '')}</small></div></div></td>
          <td>${esc(K.cName(s.courseId))}<br><small class="muted">${esc(K.tName(s.teacherId))}</small></td>
          <td>${esc(K.planText(s))} · ${esc(K.daysText(s.days))}<br><small class="muted">${esc(s.startTime || '')} · ${L.lessonHours(s, D.settings)} saat</small></td>
          <td>${m ? `${m.k}/${c.ms.length}-ci ay <div class="bar" style="margin-top:4px"><i style="width:${pct}%"></i></div><small class="muted">${m.hoursDone}/${m.hoursTotal} saat</small>` : '<span class="pill acc">Kurs bitib</span>'}</td>
          <td>${m && m.end ? `${L.fmtDate(m.end)}<br>${m.daysLeft <= 3 ? `<span class="pill warn">${m.daysLeft} gün qalıb</span>` : `<small class="muted">${m.daysLeft} gün qalıb</small>`}` : '—'}</td>
          <td class="n">${money(L.feeOf(s, D))}${(s.discount && Number(s.discount.percent)) ? `<br><span class="pill acc">−${s.discount.percent}% ${esc(s.discount.reason || '')}</span>` : ''}</td>
          <td class="n">${c.debt > 0 ? `<span class="pill bad">${money(c.debt)}</span>` : '<span class="pill ok">0</span>'}</td>
          <td>${statusTxt[s.status || 'active']}</td></tr>`; }).join('') || `<tr><td colspan="8" class="empty">Tələbə yoxdur. “＋ Yeni tələbə” ilə əlavə edin.</td></tr>`}
        </tbody></table></div>`;
      $('#sq', view).oninput = (e) => { sf.q = e.target.value; clearTimeout(sf.t); sf.t = setTimeout(() => { K.refresh(); const i = $('#sq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }, 250); };
      $('#sc', view).onchange = (e) => { sf.course = e.target.value; K.refresh(); };
      $('#stc', view).onchange = (e) => { sf.teacher = e.target.value; K.refresh(); };
      $('#sst', view).onchange = (e) => { sf.status = e.target.value; K.refresh(); };
      $('#sAdd', view).onclick = () => K.editStudent(null);
      $$('[data-open]', view).forEach((r) => r.onclick = () => K.openStudent(r.dataset.open));
      K.hydrateAvatars(view);
    }
  });

  K.editStudent = function (id, pre = {}) {
    const s0 = id ? K.student(id) : null;
    const s = s0 ? JSON.parse(JSON.stringify(s0)) : { id: uid(), status: 'active', plan: '2x', days: [], startTime: '', startDate: today(), discount: { percent: 0, reason: '', months: 'all' }, ...pre };
    s.discount = s.discount || { percent: 0, reason: '', months: 'all' };
    const pending = {};
    const body = `<form class="form" id="sf" autocomplete="off">
      <fieldset class="fs"><legend>Şəxsi məlumat</legend><div class="row">
        ${f('lastName', 'Soyad *', s.lastName)}${f('firstName', 'Ad *', s.firstName)}${f('fatherName', 'Ata adı', s.fatherName)}${f('birthDate', 'Doğum tarixi', s.birthDate, 'date')}
        ${f('phone', 'Telefon', s.phone, 'tel', 'placeholder="+994 50 000 00 00"')}${f('email', 'E-poçt', s.email, 'email')}${f('parentName', 'Valideyn (ad, soyad)', s.parentName)}${f('parentPhone', 'Valideyn telefonu', s.parentPhone, 'tel')}
        <label class="f wide"><span>Ünvan</span><input name="address" value="${esc(s.address || '')}"></label></div></fieldset>
      <fieldset class="fs"><legend>Şəxsiyyət vəsiqəsi</legend><div class="row">
        ${sel('idSeries', 'Seriya', ['AZE', 'AA', 'MYI', 'DYI', 'Digər'].map((x) => `<option ${s.idSeries === x ? 'selected' : ''}>${x}</option>`).join(''))}${f('idNumber', 'Nömrə', s.idNumber)}${f('fin', 'FİN kod', s.fin, 'text', 'maxlength="7" style="text-transform:uppercase"')}${f('idIssueDate', 'Verilmə tarixi', s.idIssueDate, 'date')}${f('idIssuer', 'Verən orqan', s.idIssuer)}${f('idExpiry', 'Etibarlıdır (tarixədək)', s.idExpiry, 'date')}</div>
        <div style="margin-top:10px">${K.photoBox([[`st_${s.id}_front`, 'Vəsiqənin ön üzü'], [`st_${s.id}_back`, 'Vəsiqənin arxa üzü'], [`st_${s.id}_photo`, 'Profil şəkli']])}</div></fieldset>
      <fieldset class="fs"><legend>Kurs və cədvəl</legend><div class="row">
        ${sel('courseId', 'Kurs *', K.opt(D.courses, s.courseId, (c) => `${c.name} · ${c.months} ay`, 'Seçin…'))}
        ${sel('teacherId', 'Müəllim *', '', '')}
        ${f('startDate', 'Başlama tarixi *', s.startDate, 'date')}${f('startTime', 'Dərs saatı *', s.startTime, 'time')}</div>
        <div style="margin:12px 0 6px" class="f"><span>Həftədə neçə dəfə</span><div class="chips" id="planChips">${Object.entries(L.PLANS).map(([k, p]) => `<span class="chip ${s.plan === k ? 'on' : ''}" data-plan="${k}">${p.label} · ${(D.settings.plans || {})[k] || p.hours} saat</span>`).join('')}</div></div>
        <div class="f"><span>Dərs günləri <span class="hint" id="dayHint"></span></span><div class="chips" id="dayChips">${L.DAY_ORDER.map((d) => `<span class="chip ${(s.days || []).map(Number).includes(d) ? 'on' : ''}" data-d="${d}">${L.DAY_FULL[d]}</span>`).join('')}<span class="chip" data-pre="odd">Tək</span><span class="chip" data-pre="even">Cüt</span><span class="chip" data-pre="all">B.e–Şənbə</span></div></div>
        <div class="row" style="margin-top:10px">${f('duration', 'Bir dərsin müddəti (saat)', s.duration || '', 'number', 'step="0.25" min="0.5" placeholder="avtomatik"')}${f('months', 'Kursun müddəti (ay)', s.months || '', 'number', 'min="1" placeholder="kursdan"')}${f('monthlyFee', 'Kursa yazıldığı məbləğ (aylıq, ₼) *', s.monthlyFee || '', 'number', 'step="0.01" min="0"')}${f('regFee', 'Qeydiyyat haqqı (₼)', s.regFee || '', 'number', 'step="0.01" min="0"')}</div>
        <div id="schedInfo" style="margin-top:10px"></div></fieldset>
      <fieldset class="fs"><legend>Güzəşt</legend><div class="row">
        ${f('dPercent', 'Güzəşt faizi (%)', s.discount.percent || '', 'number', 'min="0" max="100" step="0.5" placeholder="0"')}
        ${sel('dReason', 'Səbəb', ['', ...(D.settings.discountReasons || [])].map((r) => `<option value="${esc(r)}" ${s.discount.reason === r ? 'selected' : ''}>${r ? esc(r) : '—'}</option>`).join(''))}
        ${f('dNote', 'Qeyd (məs. kampaniyanın adı)', s.discount.note)}</div>
        <div class="f" style="margin-top:10px"><span>Hansı aylara tətbiq olunsun</span><div class="chips" id="dMonths"></div></div>
        <div id="discInfo" style="margin-top:8px"></div></fieldset>
      <fieldset class="fs"><legend>Status</legend><div class="row">
        ${sel('status', 'Status', [['active', 'Aktiv'], ['paused', 'Dayandırılıb'], ['finished', 'Bitirib'], ['left', 'Ayrılıb']].map(([v, l]) => `<option value="${v}" ${(s.status || 'active') === v ? 'selected' : ''}>${l}</option>`).join(''))}
        ${f('leftDate', 'Ayrılma tarixi', s.leftDate, 'date')}<label class="f wide"><span>Qeyd</span><textarea name="note" rows="2">${esc(s.note || '')}</textarea></label></div></fieldset>
    </form>`;
    K.modal({
      title: s0 ? `Tələbə: ${L.fullName(s0)}` : 'Yeni tələbə', wide: true, body,
      actions: [...(s0 ? [{ label: 'Sil', cls: 'danger', left: true, onClick: async () => { if (!confirm(`${L.fullName(s0)} silinsin? Ödəniş, davamiyyət və imtahan nəticələri də silinəcək.`)) return false; D.students = D.students.filter((x) => x.id !== s0.id); D.payments = D.payments.filter((p) => p.studentId !== s0.id); delete D.att[s0.id]; D.results = D.results.filter((r) => r.studentId !== s0.id); await K.save('students', 'payments', 'att', 'results'); K.log(`Tələbə silindi: ${L.fullName(s0)}`); K.toast('Silindi'); K.refresh(); } }] : []),
        { label: 'Ləğv et' }, { label: s0 ? 'Yadda saxla' : 'Tələbəni yaz', cls: 'primary', onClick: (api) => saveStudent(api, s, s0, pending) }],
      onMount(api) {
        const root = api.body;
        K.bindPhotos(root, pending);
        const fm = $('#sf', root);
        const fillTeachers = () => { const cid = fm.courseId.value; const ts = D.teachers.filter((t) => t.active !== false && (!cid || (t.courseIds || []).includes(cid))); fm.teacherId.innerHTML = K.opt(ts.length ? ts : D.teachers, s.teacherId, L.fullName, 'Seçin…'); };
        fillTeachers();
        fm.courseId.onchange = () => { const c = K.course(fm.courseId.value); if (c && !fm.monthlyFee.value) fm.monthlyFee.value = c.monthlyFee || ''; fillTeachers(); upd(); };
        if (!s0 && s.courseId && !s.monthlyFee) { const c = K.course(s.courseId); if (c) fm.monthlyFee.value = c.monthlyFee || ''; }
        $$('#planChips .chip', root).forEach((c) => c.onclick = () => { s.plan = c.dataset.plan; $$('#planChips .chip', root).forEach((x) => x.classList.toggle('on', x === c)); if (s.plan === 'intensive' && (s.days || []).length < 4) s.days = L.PRESETS.all.slice(); syncDays(); upd(); });
        const syncDays = () => $$('#dayChips [data-d]', root).forEach((x) => x.classList.toggle('on', s.days.map(Number).includes(Number(x.dataset.d))));
        $$('#dayChips [data-d]', root).forEach((c) => c.onclick = () => { const d = Number(c.dataset.d); s.days = s.days.map(Number).includes(d) ? s.days.filter((x) => Number(x) !== d) : [...s.days, d]; syncDays(); upd(); });
        $$('#dayChips [data-pre]', root).forEach((c) => c.onclick = () => { s.days = L.PRESETS[c.dataset.pre].slice(); syncDays(); upd(); });
        const dm = () => {
          const n = Number(fm.months.value) || (K.course(fm.courseId.value) || {}).months || 1;
          const sel = s.discount.months === 'all' ? 'all' : (s.discount.months || []).map(Number);
          $('#dMonths', root).innerHTML = `<span class="chip ${sel === 'all' ? 'on' : ''}" data-dm="all">Bütün aylar</span>` + Array.from({ length: n }, (_, i) => `<span class="chip ${sel !== 'all' && sel.includes(i + 1) ? 'on' : ''}" data-dm="${i + 1}">${i + 1}-ci ay</span>`).join('');
          $$('#dMonths .chip', root).forEach((c) => c.onclick = () => { if (c.dataset.dm === 'all') s.discount.months = 'all'; else { let a = s.discount.months === 'all' ? [] : (s.discount.months || []).map(Number); const k = Number(c.dataset.dm); a = a.includes(k) ? a.filter((x) => x !== k) : [...a, k].sort((x, y) => x - y); s.discount.months = a.length ? a : 'all'; } dm(); upd(); });
        };
        dm();
        ['teacherId', 'startTime', 'duration', 'months', 'monthlyFee', 'dPercent', 'startDate'].forEach((n) => fm[n].addEventListener('input', () => { if (n === 'months') dm(); upd(); }));
        function upd() {
          const plan = L.PLANS[s.plan], need = plan.days;
          const hrs = Number(fm.duration.value) || (D.settings.plans || {})[s.plan] || plan.hours;
          const n = s.days.length;
          $('#dayHint', root).textContent = need ? `— ${need} gün seçin (${n} seçilib)` : `— ən azı 4 gün (${n} seçilib)`;
          const MH = Number(D.settings.monthHours) || 12;
          const months = Number(fm.months.value) || (K.course(fm.courseId.value) || {}).months || 1;
          const per = Math.round(MH / hrs * 10) / 10;
          let html = `<div class="alert info">Ayda <b>${MH} saat</b> = <b>${per} dərs</b> × ${hrs} saat. Kurs: <b>${months} ay</b> = ${months * MH} saat.`;
          // proqnoz: ilk ayın bitmə tarixi
          const t = { ...s, ...K.formData(fm), plan: s.plan, days: s.days, duration: Number(fm.duration.value) || 0, months: Number(fm.months.value) || 0 };
          if (t.startDate && n) { const ms = L.months(t, D, today()); if (ms[0] && ms[0].end) html += ` 1-ci ay ≈ <b>${L.fmtDate(ms[0].end)}</b>-də bitir, kurs ≈ <b>${L.fmtDate(ms[ms.length - 1].end)}</b>.`; }
          html += '</div>';
          const tc = K.teacher(fm.teacherId.value);
          if (tc && fm.startTime.value && n) {
            const c = L.conflicts(tc, D, s.days.map(Number), fm.startTime.value, hrs, s.id, today());
            if (c.overlaps.length) html += `<div class="alert warn" style="margin-top:6px">⚠ Müəllim bu vaxt məşğuldur: ${c.overlaps.map((o) => `${L.DAY_SHORT[o.wd]} ${L.toTime(o.from)}–${L.toTime(o.to)} (${esc(L.fullName(o.student))})`).join('; ')}. Qrup dərsidirsə davam edə bilərsiniz.</div>`;
            if (c.offDays.length) html += `<div class="alert warn" style="margin-top:6px">⚠ ${c.offDays.map((d) => L.DAY_FULL[d]).join(', ')} müəllimin iş günü deyil.</div>`;
            if (c.outside) html += `<div class="alert warn" style="margin-top:6px">⚠ Saat müəllimin iş saatından (${esc(tc.workFrom || '09:00')}–${esc(tc.workTo || '20:00')}) kənardadır.</div>`;
            if (!c.overlaps.length && !c.offDays.length && !c.outside) html += '<div class="alert ok" style="margin-top:6px">✓ Müəllim bu günlərdə və saatda boşdur.</div>';
          }
          $('#schedInfo', root).innerHTML = html;
          const p = Number(fm.dPercent.value) || 0, fee = Number(fm.monthlyFee.value) || 0;
          $('#discInfo', root).innerHTML = p ? `<div class="alert ok">Güzəştli aylıq məbləğ: <b>${money(fee * (1 - p / 100))}</b> (${money(fee * p / 100)} endirim) — ${s.discount.months === 'all' ? 'bütün aylara' : (s.discount.months || []).map((k) => k + '-ci').join(', ') + ' aya'} tətbiq olunur.</div>` : '';
        }
        upd();
      }
    });
  };
  async function saveStudent(api, s, s0, pending) {
    const fm = $('#sf', api.body); const v = K.formData(fm);
    const err = (t) => { K.toast(t); return false; };
    if (!v.lastName || !v.firstName) return err('Ad və soyadı yazın');
    if (!v.courseId) return err('Kursu seçin'); if (!v.teacherId) return err('Müəllimi seçin');
    if (!v.startDate || !v.startTime) return err('Başlama tarixini və dərs saatını yazın');
    const need = L.PLANS[s.plan].days;
    if (need && s.days.length !== need) return err(`${L.PLANS[s.plan].label}: ${need} gün seçilməlidir`);
    if (!need && s.days.length < 4) return err('İntensiv üçün ən azı 4 gün seçin');
    if (!(Number(v.monthlyFee) >= 0) || v.monthlyFee === '') return err('Kursa yazıldığı (aylıq) məbləği yazın');
    const st = { ...s, ...v, fin: (v.fin || '').toUpperCase(), days: s.days.map(Number), plan: s.plan, duration: Number(v.duration) || 0, months: Number(v.months) || 0, monthlyFee: Number(v.monthlyFee) || 0, regFee: Number(v.regFee) || 0,
      discount: { percent: Number(v.dPercent) || 0, reason: v.dReason, note: v.dNote, months: s.discount.months || 'all' } };
    delete st.dPercent; delete st.dReason; delete st.dNote;
    await K.commitPhotos(pending);
    st.photoKey = (pending[`st_${s.id}_photo`] || (pending[`st_${s.id}_photo`] !== null && await K.getImg(`st_${s.id}_photo`))) ? `st_${s.id}_photo` : '';
    st.idFrontKey = `st_${s.id}_front`; st.idBackKey = `st_${s.id}_back`;
    if (!s0) st.createdAt = new Date().toISOString();
    const i = D.students.findIndex((x) => x.id === st.id);
    if (i >= 0) D.students[i] = st; else D.students.push(st);
    await K.save('students');
    K.log(`${s0 ? 'Tələbə yeniləndi' : 'Yeni tələbə'}: ${L.fullName(st)} — ${K.cName(st.courseId)}, ${K.tName(st.teacherId)}`);
    K.toast(s0 ? 'Yadda saxlanıldı' : 'Tələbə qeydiyyata alındı');
    K.refresh();
    if (!s0) setTimeout(() => K.openStudent(st.id), 50);
  }

  K.openStudent = async function (id) {
    const s = K.student(id); if (!s) return;
    const t = today(); const ms = L.months(s, D, t); const att = L.attendanceSummary(s, D, null, null, t);
    const avg = L.examAvg(s.id, D);
    const res = D.results.filter((r) => r.studentId === s.id).sort((a, b) => b.date.localeCompare(a.date));
    const pays = D.payments.filter((p) => p.studentId === s.id).sort((a, b) => b.date.localeCompare(a.date));
    const lessons = L.lessons(s, D, t);
    const kv = (items) => `<div class="kvg">${items.map(([k, v]) => `<div><span>${esc(k)}</span><b>${v == null || v === '' ? '—' : esc(v)}</b></div>`).join('')}</div>`;
    const tabs = {
      info: `<div class="grid g2"><div>${kv([['Ata adı', s.fatherName], ['Doğum tarixi', L.fmtDate(s.birthDate)], ['Telefon', s.phone], ['Valideyn', s.parentName], ['Valideyn tel.', s.parentPhone], ['Ünvan', s.address], ['Vəsiqə', [s.idSeries, s.idNumber].filter(Boolean).join(' ')], ['FİN', s.fin]])}</div>
        <div>${kv([['Kurs', K.cName(s.courseId)], ['Müəllim', K.tName(s.teacherId)], ['Plan', L.PLANS[s.plan] && L.PLANS[s.plan].label], ['Günlər', K.daysText(s.days)], ['Saat', `${s.startTime} · ${L.lessonHours(s, D.settings)} saat`], ['Başlama', L.fmtDate(s.startDate)], ['Aylıq məbləğ', money(L.feeOf(s, D))], ['Güzəşt', s.discount && Number(s.discount.percent) ? `${s.discount.percent}% · ${s.discount.reason || ''} · ${s.discount.months === 'all' ? 'bütün aylar' : (s.discount.months || []).join(', ') + '-ci aylar'}` : 'yoxdur']])}</div></div>
        <div style="margin-top:12px" class="photo-box" id="idPhotos"></div>
        <h4 style="margin:16px 0 8px">Aylar üzrə irəliləyiş</h4>${monthsTable(s, ms)}`,
      pay: `<div class="toolbar"><button class="btn primary" id="payAdd">＋ Ödəniş qəbul et</button><span class="grow"></span><span class="muted">Ümumi borc: <b>${money(ms.filter((m) => m.started).reduce((a, m) => a + m.debt, 0))}</b></span></div>${monthsTable(s, ms, true)}
        <h4 style="margin:16px 0 8px">Ödənişlər</h4><div class="tbl-wrap"><table class="t"><thead><tr><th>Tarix</th><th>Ay</th><th class="n">Məbləğ</th><th>Üsul</th><th>Qeyd</th><th></th></tr></thead><tbody>${pays.map((p) => `<tr><td>${L.fmtDate(p.date)}</td><td>${p.monthNo}-ci ay</td><td class="n">${money(p.amount)}</td><td>${esc(p.method || '')}</td><td>${esc(p.note || '')}</td><td><button class="link" data-delpay="${p.id}">sil</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">Ödəniş yoxdur</td></tr>'}</tbody></table></div>`,
      att: `<div class="kpis"><div class="kpi ok"><span>Davamiyyət</span><b>${att.percent == null ? '—' : att.percent + '%'}</b></div><div class="kpi"><span>İştirak</span><b>${att.attended}</b></div><div class="kpi warn"><span>Üzrlü</span><b>${att.excused}</b></div><div class="kpi bad"><span>Üzrsüz</span><b>${att.unexcused}</b></div><div class="kpi"><span>Müəllim gəlmədi</span><b>${att.teacherAbsent}</b></div></div>
        <div class="tbl-wrap" style="max-height:380px"><table class="t"><thead><tr><th>Tarix</th><th>Gün</th><th>Saat</th><th>Vəziyyət</th><th>Dəyiş</th></tr></thead><tbody>${lessons.filter((l) => l.date <= L.addDays(t, 14)).reverse().map((l) => `<tr><td>${L.fmtDate(l.date)}</td><td>${L.DAY_SHORT[L.parse(l.date).getDay()]}</td><td>${l.from}–${l.to}</td><td>${K.statusPill(l.status)}</td><td>${['holiday', 'teacherAbsent'].includes(l.status) ? '' : K.attSeg(s.id, l.date, l.status)}</td></tr>`).join('')}</tbody></table></div>`,
      exam: `<div class="toolbar"><button class="btn primary" id="exStart">📝 İmtahan keçir</button><span class="grow"></span><span class="muted">Orta bal: <b>${avg == null ? '—' : avg + '%'}</b> · ${L.level(avg)}</span></div>
        <div class="tbl-wrap"><table class="t"><thead><tr><th>Tarix</th><th>İmtahan</th><th class="n">Bal</th><th class="n">Faiz</th><th>Səviyyə</th></tr></thead><tbody>${res.map((r) => `<tr><td>${L.fmtDate(r.date)}</td><td>${esc((D.exams.find((e) => e.id === r.examId) || {}).title || '—')}</td><td class="n">${r.score}/${r.max}</td><td class="n">${r.percent}%</td><td>${L.level(r.percent)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">İmtahan nəticəsi yoxdur</td></tr>'}</tbody></table></div>`
    };
    let tab = 'info';
    K.modal({
      title: L.fullName(s), full: true,
      body: `<div class="card-h"><div class="who">${K.avatar(s, s.photoKey)}<div><b style="font-size:16px">${esc(L.fullName(s))}</b><small>${esc(K.cName(s.courseId))} · ${esc(K.tName(s.teacherId))}</small></div></div><div>${statusTxt[s.status || 'active']}</div></div>
        <div class="tabs">${[['info', 'Ümumi'], ['pay', 'Ödənişlər'], ['att', 'Davamiyyət'], ['exam', 'İmtahanlar']].map(([k, l]) => `<button class="tab ${k === tab ? 'on' : ''}" data-tab="${k}">${l}</button>`).join('')}</div><div id="tabBody"></div>`,
      actions: [{ label: '⬇ Excel', cls: 'ghost', left: true, close: false, onClick: () => K.studentReport(s.id, 'xlsx') }, { label: '⬇ PDF', cls: 'ghost', close: false, onClick: () => K.studentReport(s.id, 'pdf') }, { label: 'Redaktə et', cls: 'soft', onClick: () => K.editStudent(s.id) }, { label: 'Bağla' }],
      async onMount(api) {
        const show = async () => {
          $('#tabBody', api.body).innerHTML = tabs[tab];
          $$('.tab', api.body).forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
          if (tab === 'info') { const box = $('#idPhotos', api.body); for (const [k, l] of [[s.idFrontKey, 'Vəsiqə ön'], [s.idBackKey, 'Vəsiqə arxa']]) { const d = await K.getImg(k); if (d) { const el = document.createElement('div'); el.className = 'photo'; el.title = l; el.innerHTML = `<img src="${d}">`; el.onclick = () => K.viewImage(d); box.appendChild(el); } } }
          const pa = $('#payAdd', api.body); if (pa) pa.onclick = () => { api.close(); K.addPayment(s.id); };
          $$('[data-paymonth]', api.body).forEach((b) => b.onclick = () => { api.close(); K.addPayment(s.id, Number(b.dataset.paymonth)); });
          $$('[data-delpay]', api.body).forEach((b) => b.onclick = async () => { if (!confirm('Ödəniş silinsin?')) return; const p = D.payments.find((x) => x.id === b.dataset.delpay); D.payments = D.payments.filter((x) => x.id !== b.dataset.delpay); await K.save('payments'); K.log(`Ödəniş silindi: ${L.fullName(s)} ${p ? money(p.amount) : ''}`); api.close(); K.openStudent(s.id); K.refresh(); });
          const ex = $('#exStart', api.body); if (ex) ex.onclick = () => { api.close(); K.takeExam(null, s.id); };
          K.bindAttSeg(api.body, () => { api.close(); K.openStudent(s.id); });
          K.hydrateAvatars(api.body);
        };
        $$('.tab', api.body).forEach((b) => b.onclick = () => { tab = b.dataset.tab; show(); });
        show();
      }
    });
  };
  function monthsTable(s, ms, payBtns) {
    return `<div class="tbl-wrap"><table class="t"><thead><tr><th>Ay</th><th>Başlayır</th><th>Bitir</th><th>İrəliləyiş</th><th class="n">Məbləğ</th><th class="n">Güzəşt</th><th class="n">Ödənilib</th><th class="n">Borc</th><th>Vəziyyət</th>${payBtns ? '<th></th>' : ''}</tr></thead><tbody>
      ${ms.map((m) => `<tr><td><b>${m.k}-ci ay</b></td><td>${L.fmtDate(m.start)}</td><td>${L.fmtDate(m.end)}${m.end && !m.completed ? `<br><small class="muted">${m.daysLeft} gün qalıb</small>` : ''}</td>
        <td><div class="bar"><i style="width:${Math.min(100, m.hoursDone / m.hoursTotal * 100)}%"></i></div><small class="muted">${m.hoursDone}/${m.hoursTotal} saat</small></td>
        <td class="n">${money(m.base)}</td><td class="n">${m.percent ? `−${m.percent}%` : '—'}</td><td class="n">${money(m.paid)}</td><td class="n">${m.debt > 0 ? `<b style="color:var(--bad)">${money(m.debt)}</b>` : '0.00 ₼'}</td>
        <td>${m.completed ? '<span class="pill ok">Tamamlanıb</span>' : m.started ? '<span class="pill acc">Davam edir</span>' : '<span class="pill mute">Başlamayıb</span>'}</td>${payBtns ? `<td>${m.debt > 0 ? `<button class="btn sm soft" data-paymonth="${m.k}">Ödə</button>` : ''}</td>` : ''}</tr>`).join('')}</tbody></table></div>`;
  }

  // ================================================================= MÜƏLLİMLƏR
  K.register('teachers', {
    render(view) {
      K.sub(`${D.teachers.length} müəllim`);
      const t = today();
      view.innerHTML = `<div class="toolbar"><span class="grow"></span><button class="btn primary" id="tAdd">＋ Yeni müəllim</button></div>
        <div class="grid g3">${D.teachers.map((tc) => {
          const stds = D.students.filter((s) => s.teacherId === tc.id && s.status !== 'left' && s.status !== 'finished');
          const ta = L.teacherAttendance(tc, D, t.slice(0, 7) + '-01', t, t);
          const avgs = stds.map((s) => L.examAvg(s.id, D)).filter((x) => x != null); const lvl = avgs.length ? Math.round(avgs.reduce((a, b) => a + b, 0) / avgs.length * 10) / 10 : null;
          const { free } = L.freeOf(tc, D, t); const wd = new Date().getDay();
          return `<div class="card" style="cursor:pointer" data-topen="${tc.id}"><div class="who" style="margin-bottom:10px">${K.avatar(tc, tc.photoKey)}<div><b>${esc(L.fullName(tc))}</b><small>${esc((tc.courseIds || []).map(K.cName).join(', ') || '—')}</small></div></div>
            <div class="chips" style="margin-bottom:8px"><span class="pill acc">${Number(tc.percent) || 0}% pay</span><span class="pill mute">${stds.length} tələbə</span>${ta.percent != null ? `<span class="pill ${ta.percent >= 90 ? 'ok' : 'warn'}">davamiyyət ${ta.percent}%</span>` : ''}${lvl != null ? `<span class="pill ok">səviyyə ${lvl}%</span>` : ''}${tc.active === false ? '<span class="pill mute">Deaktiv</span>' : ''}</div>
            <div class="small muted">Bu gün boş: ${(free[wd] || []).map((x) => `<span class="slot free" style="display:inline-block">${L.toTime(x.from)}–${L.toTime(x.to)}</span>`).join(' ') || '—'}</div></div>`;
        }).join('') || '<div class="card"><div class="empty">Müəllim yoxdur. “＋ Yeni müəllim” ilə əlavə edin.</div></div>'}</div>`;
      $('#tAdd', view).onclick = () => K.editTeacher(null);
      $$('[data-topen]', view).forEach((c) => c.onclick = () => K.openTeacher(c.dataset.topen));
      K.hydrateAvatars(view);
    }
  });

  K.editTeacher = function (id) {
    const t0 = id ? K.teacher(id) : null;
    const t = t0 ? JSON.parse(JSON.stringify(t0)) : { id: uid(), courseIds: [], workDays: [1, 2, 3, 4, 5, 6], workFrom: '09:00', workTo: '20:00', percent: 40, active: true, hireDate: today() };
    const pending = {};
    const body = `<form class="form" id="tf" autocomplete="off">
      <fieldset class="fs"><legend>Şəxsi məlumat</legend><div class="row">${f('lastName', 'Soyad *', t.lastName)}${f('firstName', 'Ad *', t.firstName)}${f('fatherName', 'Ata adı', t.fatherName)}${f('birthDate', 'Doğum tarixi', t.birthDate, 'date')}${f('phone', 'Telefon', t.phone, 'tel')}${f('email', 'E-poçt', t.email, 'email')}<label class="f wide"><span>Ünvan</span><input name="address" value="${esc(t.address || '')}"></label></div></fieldset>
      <fieldset class="fs"><legend>Şəxsiyyət vəsiqəsi</legend><div class="row">${sel('idSeries', 'Seriya', ['AZE', 'AA', 'MYI', 'DYI', 'Digər'].map((x) => `<option ${t.idSeries === x ? 'selected' : ''}>${x}</option>`).join(''))}${f('idNumber', 'Nömrə', t.idNumber)}${f('fin', 'FİN kod', t.fin, 'text', 'maxlength="7" style="text-transform:uppercase"')}${f('idIssueDate', 'Verilmə tarixi', t.idIssueDate, 'date')}${f('idIssuer', 'Verən orqan', t.idIssuer)}</div>
        <div style="margin-top:10px">${K.photoBox([[`tc_${t.id}_front`, 'Vəsiqənin ön üzü'], [`tc_${t.id}_back`, 'Vəsiqənin arxa üzü'], [`tc_${t.id}_photo`, 'Profil şəkli']])}</div></fieldset>
      <fieldset class="fs"><legend>Diplom</legend><div class="row">${f('uni', 'Ali təhsil müəssisəsi', t.uni)}${f('specialty', 'İxtisas', t.specialty)}${sel('degree', 'Dərəcə', ['', 'Bakalavr', 'Magistr', 'Doktorantura', 'Orta ixtisas', 'Sertifikat'].map((x) => `<option ${t.degree === x ? 'selected' : ''}>${x}</option>`).join(''))}${f('diplomaNo', 'Diplom nömrəsi', t.diplomaNo)}${f('diplomaDate', 'Verilmə tarixi', t.diplomaDate, 'date')}${f('certs', 'Sertifikatlar (IELTS, CELTA…)', t.certs)}</div>
        <div style="margin-top:10px">${K.photoBox([[`tc_${t.id}_diploma`, 'Diplomun şəkli']])}</div></fieldset>
      <fieldset class="fs"><legend>İş şərtləri</legend><div class="row">${f('percent', 'Müəllimin payı (%) *', t.percent, 'number', 'min="0" max="100" step="0.5"')}${f('hireDate', 'İşə başlama', t.hireDate, 'date')}${f('workFrom', 'İş saatı (başlayır)', t.workFrom, 'time')}${f('workTo', 'İş saatı (bitir)', t.workTo, 'time')}</div>
        <div class="f" style="margin-top:10px"><span>Tədris etdiyi kurslar</span><div class="chips" id="tCourses">${D.courses.map((c) => `<span class="chip ${(t.courseIds || []).includes(c.id) ? 'on' : ''}" data-c="${c.id}">${esc(c.name)}</span>`).join('') || '<span class="hint">Əvvəlcə “Kurslar” bölməsində kurs əlavə edin</span>'}</div></div>
        <div class="f" style="margin-top:10px"><span>İş günləri</span><div class="chips" id="tDays">${L.DAY_ORDER.map((d) => `<span class="chip ${(t.workDays || []).map(Number).includes(d) ? 'on' : ''}" data-d="${d}">${L.DAY_FULL[d]}</span>`).join('')}</div></div>
        <label class="f" style="margin-top:10px;display:flex;gap:8px;align-items:center"><input type="checkbox" name="active" ${t.active !== false ? 'checked' : ''}> Aktiv (qəbul ekranında görünür)</label></fieldset>
    </form>`;
    K.modal({
      title: t0 ? `Müəllim: ${L.fullName(t0)}` : 'Yeni müəllim', wide: true, body,
      actions: [...(t0 ? [{ label: 'Sil', cls: 'danger', left: true, onClick: async () => { const n = D.students.filter((s) => s.teacherId === t0.id).length; if (n) { K.toast(`Bu müəllimin ${n} tələbəsi var — əvvəlcə tələbələri başqa müəllimə keçirin və ya deaktiv edin`); return false; } if (!confirm('Müəllim silinsin?')) return false; D.teachers = D.teachers.filter((x) => x.id !== t0.id); await K.save('teachers'); K.log(`Müəllim silindi: ${L.fullName(t0)}`); K.refresh(); } }] : []),
        { label: 'Ləğv et' }, {
          label: 'Yadda saxla', cls: 'primary', async onClick(api) {
            const v = K.formData($('#tf', api.body));
            if (!v.lastName || !v.firstName) { K.toast('Ad və soyadı yazın'); return false; }
            const nt = { ...t, ...v, fin: (v.fin || '').toUpperCase(), percent: Number(v.percent) || 0, courseIds: t.courseIds, workDays: t.workDays.map(Number) };
            await K.commitPhotos(pending);
            nt.photoKey = (pending[`tc_${t.id}_photo`] || (pending[`tc_${t.id}_photo`] !== null && await K.getImg(`tc_${t.id}_photo`))) ? `tc_${t.id}_photo` : '';
            const i = D.teachers.findIndex((x) => x.id === nt.id); if (i >= 0) D.teachers[i] = nt; else D.teachers.push(nt);
            await K.save('teachers'); K.log(`${t0 ? 'Müəllim yeniləndi' : 'Yeni müəllim'}: ${L.fullName(nt)} (${nt.percent}%)`); K.toast('Yadda saxlanıldı'); K.refresh();
          }
        }],
      onMount(api) {
        K.bindPhotos(api.body, pending);
        $$('#tCourses .chip', api.body).forEach((c) => c.onclick = () => { const id = c.dataset.c; t.courseIds = t.courseIds.includes(id) ? t.courseIds.filter((x) => x !== id) : [...t.courseIds, id]; c.classList.toggle('on'); });
        $$('#tDays .chip', api.body).forEach((c) => c.onclick = () => { const d = Number(c.dataset.d); t.workDays = t.workDays.map(Number).includes(d) ? t.workDays.filter((x) => Number(x) !== d) : [...t.workDays, d]; c.classList.toggle('on'); });
      }
    });
  };

  K.openTeacher = function (id) {
    const tc = K.teacher(id); if (!tc) return;
    const t = today(); const from = t.slice(0, 7) + '-01';
    const prog = L.teacherProgress(tc, D, t);
    const ta = L.teacherAttendance(tc, D, from, t, t);
    const abs = Object.entries(D.tabs[tc.id] || {}).sort((a, b) => b[0].localeCompare(a[0]));
    const kv = (items) => `<div class="kvg">${items.map(([k, v]) => `<div><span>${esc(k)}</span><b>${v == null || v === '' ? '—' : esc(v)}</b></div>`).join('')}</div>`;
    K.modal({
      title: L.fullName(tc), full: true,
      body: `<div class="grid g2"><div>${kv([['Telefon', tc.phone], ['E-poçt', tc.email], ['Doğum tarixi', L.fmtDate(tc.birthDate)], ['Vəsiqə', [tc.idSeries, tc.idNumber].filter(Boolean).join(' ')], ['FİN', tc.fin], ['İşə başlama', L.fmtDate(tc.hireDate)], ['İş saatı', `${tc.workFrom}–${tc.workTo}, ${K.daysText(tc.workDays)}`], ['Pay', (Number(tc.percent) || 0) + '%']])}</div>
        <div>${kv([['Universitet', tc.uni], ['İxtisas', tc.specialty], ['Dərəcə', tc.degree], ['Diplom №', tc.diplomaNo], ['Diplom tarixi', L.fmtDate(tc.diplomaDate)], ['Sertifikatlar', tc.certs], ['Kurslar', (tc.courseIds || []).map(K.cName).join(', ')]])}<div class="photo-box" id="tPhotos" style="margin-top:10px"></div></div></div>
        <h4 style="margin:18px 0 8px">Tələbələr və cari aylar</h4>
        <div class="tbl-wrap"><table class="t"><thead><tr><th>Tələbə</th><th>Kurs</th><th>Cari ay</th><th>Ay bitir</th><th>Qalan gün</th><th class="n">Ödənilib</th><th class="n">Gözlənilən pay</th></tr></thead><tbody>
        ${prog.map((p) => `<tr><td>${esc(L.fullName(p.student))}</td><td>${esc(K.cName(p.student.courseId))}</td><td>${p.current ? `${p.current.k}/${p.totalMonths}` : 'bitib'}</td><td>${p.current ? L.fmtDate(p.current.end) : '—'}</td><td>${p.current && p.current.daysLeft != null ? p.current.daysLeft + ' gün' : '—'}</td><td class="n">${p.current ? (p.current.paid >= p.current.due - 0.009 ? `<span class="pill ok">${money(p.current.paid)}</span>` : `<span class="pill bad">${money(p.current.paid)} / ${money(p.current.due)}</span>`) : '—'}</td><td class="n"><b>${money(p.expected)}</b></td></tr>`).join('') || '<tr><td colspan="7" class="empty">Tələbə yoxdur</td></tr>'}</tbody></table></div>
        <div class="grid g2" style="margin-top:16px"><div class="card"><h3>Müəllimin davamiyyəti (bu ay)</h3><p class="sub">${ta.total} dərs günü · ${ta.absent} gün gəlməyib · ${ta.percent == null ? '—' : ta.percent + '%'}</p>
          <div class="toolbar"><input type="date" id="absDate" value="${t}"><input id="absReason" placeholder="Səbəb (xəstəlik, məzuniyyət…)" class="grow"><button class="btn sm danger" id="absAdd">Gəlmədi qeyd et</button></div>
          <div class="small">${abs.map(([d, v]) => `<div class="att-row"><span>${L.fmtDate(d)} — ${esc((v && v.reason) || '')}</span><button class="link" data-absdel="${d}">sil</button></div>`).join('') || '<span class="muted">Qeyd yoxdur</span>'}</div>
          <p class="hint" style="margin-top:8px">Müəllim gəlmədiyi gün tələbələrin dərsi sayılmır — ay avtomatik uzanır (dərs əvəz olunur).</p></div>
          <div class="card"><h3>Hesabat</h3><p class="sub">Tələbələr, orta səviyyə, davamiyyət, maaş</p><div class="toolbar"><button class="btn soft" id="tWeek">🗓 Həftəlik cədvəl</button><button class="btn ghost" id="tX">⬇ Excel</button><button class="btn ghost" id="tP">⬇ PDF</button></div></div></div>`,
      actions: [{ label: 'Redaktə et', cls: 'soft', onClick: () => K.editTeacher(tc.id) }, { label: 'Bağla' }],
      async onMount(api) {
        const box = $('#tPhotos', api.body);
        for (const k of [`tc_${tc.id}_diploma`, `tc_${tc.id}_front`, `tc_${tc.id}_back`]) { const d = await K.getImg(k); if (d) { const el = document.createElement('div'); el.className = 'photo'; el.innerHTML = `<img src="${d}">`; el.onclick = () => K.viewImage(d); box.appendChild(el); } }
        $('#tWeek', api.body).onclick = () => K.teacherWeek(tc);
        $('#tX', api.body).onclick = () => K.teacherReport(tc.id, 'xlsx');
        $('#tP', api.body).onclick = () => K.teacherReport(tc.id, 'pdf');
        $('#absAdd', api.body).onclick = async () => { const d = $('#absDate', api.body).value; if (!d) return; D.tabs[tc.id] = D.tabs[tc.id] || {}; D.tabs[tc.id][d] = { reason: $('#absReason', api.body).value.trim() }; await K.save('tabs'); K.log(`Müəllim gəlmədi: ${L.fullName(tc)} — ${L.fmtDate(d)}`); api.close(); K.openTeacher(tc.id); K.refresh(); };
        $$('[data-absdel]', api.body).forEach((b) => b.onclick = async () => { delete D.tabs[tc.id][b.dataset.absdel]; await K.save('tabs'); api.close(); K.openTeacher(tc.id); K.refresh(); });
      }
    });
  };

  // ================================================================= KURSLAR
  K.register('courses', {
    render(view) {
      K.sub(`${D.courses.length} kurs`);
      const MH = Number(D.settings.monthHours) || 12;
      view.innerHTML = `<div class="toolbar"><span class="grow muted">Hər ay = ${MH} saat. 2×/həftə → ${D.settings.plans['2x']} saat, 3×/həftə → ${D.settings.plans['3x']} saat, intensiv → ${D.settings.plans.intensive} saat.</span><button class="btn primary" id="cAdd">＋ Yeni kurs</button></div>
        <div class="tbl-wrap"><table class="t"><thead><tr><th>Kurs</th><th>Müddət</th><th>Ümumi saat</th><th class="n">Aylıq qiymət</th><th class="n">Tam kurs</th><th>Müəllimlər</th><th>Aktiv tələbə</th></tr></thead><tbody>
        ${D.courses.map((c) => `<tr class="click" data-c="${c.id}"><td><span class="pill" style="background:${esc(c.color || '#eef0ff')}22;color:${esc(c.color || '#4f46e5')}">●</span> <b>${esc(c.name)}</b><br><small class="muted">${esc(c.description || '')}</small></td><td>${c.months} ay</td><td>${c.months * MH} saat</td><td class="n">${money(c.monthlyFee)}</td><td class="n">${money(c.monthlyFee * c.months)}</td><td>${esc(D.teachers.filter((t) => (t.courseIds || []).includes(c.id)).map(L.fullName).join(', ') || '—')}</td><td>${D.students.filter((s) => s.courseId === c.id && (s.status || 'active') === 'active').length}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">Kurs yoxdur — “＋ Yeni kurs” ilə əlavə edin (məs. İngilis dili, 4 ay, 150 ₼)</td></tr>'}</tbody></table></div>`;
      $('#cAdd', view).onclick = () => editCourse(null);
      $$('[data-c]', view).forEach((r) => r.onclick = () => editCourse(r.dataset.c));
    }
  });
  function editCourse(id) {
    const c0 = id ? K.course(id) : null; const c = c0 ? { ...c0 } : { id: uid(), months: 4, monthlyFee: 150, color: K.colorFor(Date.now()) };
    K.modal({
      title: c0 ? 'Kurs: ' + c0.name : 'Yeni kurs',
      body: `<form class="form" id="cf"><div class="row">${f('name', 'Kursun adı *', c.name)}${f('months', 'Müddət (ay) *', c.months, 'number', 'min="1" max="48"')}${f('monthlyFee', 'Aylıq qiymət (₼) *', c.monthlyFee, 'number', 'min="0" step="0.01"')}${f('color', 'Rəng', c.color, 'color')}<label class="f wide"><span>Təsvir</span><input name="description" value="${esc(c.description || '')}"></label></div></form>`,
      actions: [...(c0 ? [{ label: 'Sil', cls: 'danger', left: true, onClick: async () => { if (D.students.some((s) => s.courseId === c0.id)) { K.toast('Bu kursda tələbə var — silmək olmaz'); return false; } if (!confirm('Kurs silinsin?')) return false; D.courses = D.courses.filter((x) => x.id !== c0.id); await K.save('courses'); K.refresh(); } }] : []), { label: 'Ləğv et' },
        { label: 'Yadda saxla', cls: 'primary', async onClick(api) { const v = K.formData($('#cf', api.body)); if (!v.name || !(Number(v.months) > 0)) { K.toast('Adı və müddəti yazın'); return false; } const nc = { ...c, ...v, months: Number(v.months), monthlyFee: Number(v.monthlyFee) || 0 }; const i = D.courses.findIndex((x) => x.id === nc.id); if (i >= 0) D.courses[i] = nc; else D.courses.push(nc); await K.save('courses'); K.log(`Kurs: ${nc.name} (${nc.months} ay, ${money(nc.monthlyFee)})`); K.toast('Yadda saxlanıldı'); K.refresh(); } }]
    });
  }
})();
