/* AMMO — Kurs İdarəetmə: nüvə (yaddaş, naviqasiya, pəncərələr, köməkçilər). Panellər p-*.js fayllarındadır. */
window.K = (function () {
  'use strict';
  const L = window.KursLogic;
  const KEYS = ['courses', 'teachers', 'students', 'payments', 'att', 'tabs', 'exams', 'results', 'settings', 'custom', 'log'];
  const D = { courses: [], teachers: [], students: [], payments: [], att: {}, tabs: {}, exams: [], results: [], settings: {}, custom: {}, log: [] };

  const DEFAULT_PANELS = [
    { id: 'home', title: 'Qəbul · Boş saatlar', icon: '🏠' },
    { id: 'students', title: 'Tələbələr', icon: '🎓' },
    { id: 'teachers', title: 'Müəllimlər', icon: '👩‍🏫' },
    { id: 'courses', title: 'Kurslar', icon: '📚' },
    { id: 'attendance', title: 'Davamiyyət', icon: '🗓' },
    { id: 'payments', title: 'Ödənişlər', icon: '💳' },
    { id: 'salary', title: 'Əmək haqqı', icon: '💼' },
    { id: 'exams', title: 'İmtahanlar', icon: '📝' },
    { id: 'reports', title: 'Hesabatlar', icon: '📄' },
    { id: 'director', title: 'Direktor', icon: '📊' },
    { id: 'modules', title: 'Modullar və ayarlar', icon: '⚙', locked: true }
  ];

  // ---------------------------------------------------------------- köməkçilər
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2)).replace(/-/g, '').slice(0, 14);
  const money = (n) => `${(Number(n) || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} ₼`;
  const today = () => L.ymd();
  function toast(t) { const x = $('#toast'); x.textContent = t; x.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => x.classList.remove('show'), 2800); }
  const COLORS = ['#6366f1', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#14b8a6', '#ec4899', '#64748b', '#84cc16'];
  const colorFor = (id) => { let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; };
  const initials = (p) => ((p.firstName || '')[0] || '') + ((p.lastName || '')[0] || '') || '?';

  // ---------------------------------------------------------------- yaddaş
  async function load() {
    const r = await chrome.storage.local.get(KEYS.map((k) => 'kurs_' + k));
    for (const k of KEYS) if (r['kurs_' + k] != null) D[k] = r['kurs_' + k];
    D.settings = { ...L.DEFAULT_SETTINGS, ...(D.settings || {}), plans: { ...L.DEFAULT_SETTINGS.plans, ...((D.settings || {}).plans || {}) } };
    D.settings.panels = mergePanels(D.settings.panels);
  }
  function mergePanels(saved) {
    const list = Array.isArray(saved) ? saved.slice() : [];
    for (const p of DEFAULT_PANELS) if (!list.some((x) => x.id === p.id)) list.push({ ...p, enabled: true });
    return list.map((p) => { const def = DEFAULT_PANELS.find((x) => x.id === p.id); return def ? { ...p, title: p.title || def.title, icon: p.icon || def.icon, locked: def.locked } : p; });
  }
  async function save(...keys) {
    const o = {}; for (const k of keys) o['kurs_' + k] = D[k];
    await chrome.storage.local.set(o);
    const s = $('#syncTxt'); if (s) { s.textContent = 'Yadda saxlanıldı ' + new Date().toTimeString().slice(0, 5); }
  }
  function log(text) { D.log.unshift({ at: new Date().toISOString(), text }); if (D.log.length > 800) D.log.length = 800; save('log'); }

  // şəkillər ayrıca açarlarda (sıxılmış JPEG)
  const imgCache = {};
  async function getImg(key) { if (!key) return ''; if (key in imgCache) return imgCache[key]; const r = await chrome.storage.local.get('kurs_img_' + key); return (imgCache[key] = r['kurs_img_' + key] || ''); }
  async function setImg(key, data) { imgCache[key] = data; await chrome.storage.local.set({ ['kurs_img_' + key]: data }); }
  async function delImg(key) { delete imgCache[key]; await chrome.storage.local.remove('kurs_img_' + key); }
  async function fileToJpeg(file, max = 1280, q = 0.78) {
    const url = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Şəkil oxunmadı')); i.src = url; });
    const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
    const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', q);
  }
  /** Şəkil seçmə qutusu: html + bağlama */
  function photoBox(slots) { return `<div class="photo-box">${slots.map(([key, label]) => `<label class="photo" data-photo="${key}"><span>${esc(label)}<br><small>klikləyin və ya sürükləyin</small></span><input type="file" accept="image/*" hidden></label>`).join('')}</div>`; }
  async function bindPhotos(root, pending) {
    for (const box of $$('[data-photo]', root)) {
      const key = box.dataset.photo;
      const show = (data) => { box.querySelectorAll('img,.x').forEach((x) => x.remove()); if (data) { const i = new Image(); i.src = data; box.prepend(i); const x = document.createElement('button'); x.className = 'x'; x.type = 'button'; x.textContent = 'sil'; x.onclick = (e) => { e.preventDefault(); pending[key] = null; show(''); }; box.append(x); box.querySelector('span').classList.add('hidden'); } else box.querySelector('span').classList.remove('hidden'); };
      show(pending[key] !== undefined ? pending[key] : await getImg(key));
      const inp = box.querySelector('input');
      const take = async (f) => { if (!f) return; try { pending[key] = await fileToJpeg(f); show(pending[key]); } catch (e) { toast(e.message); } };
      inp.onchange = () => take(inp.files[0]);
      box.ondragover = (e) => e.preventDefault(); box.ondrop = (e) => { e.preventDefault(); take(e.dataTransfer.files[0]); };
      box.addEventListener('dblclick', async (e) => { const d = pending[key] !== undefined ? pending[key] : await getImg(key); if (d) { e.preventDefault(); viewImage(d); } });
    }
  }
  async function commitPhotos(pending) { for (const [k, v] of Object.entries(pending)) { if (v === null) await delImg(k); else if (v) await setImg(k, v); } }
  function viewImage(src) { modal({ title: 'Şəkil', body: `<img src="${src}" style="max-width:100%;border-radius:10px">`, wide: true }); }

  // ---------------------------------------------------------------- pəncərə
  function modal({ title, body, wide, full, actions = [], onMount, onClose }) {
    const bg = document.createElement('div'); bg.className = 'modal-bg';
    bg.innerHTML = `<div class="modal ${full ? 'full' : wide ? 'wide' : ''}"><div class="modal-h"><h2>${esc(title)}</h2><button class="x" type="button">✕</button></div><div class="modal-b">${body}</div>${actions.length ? `<div class="modal-f">${actions.map((a, i) => `<button class="btn ${a.cls || 'ghost'} ${a.left ? 'left' : ''}" data-ai="${i}">${esc(a.label)}</button>`).join('')}</div>` : ''}</div>`;
    $('#modalRoot').appendChild(bg);
    const close = () => { bg.remove(); onClose && onClose(); };
    bg.querySelector('.x').onclick = close;
    bg.addEventListener('mousedown', (e) => { if (e.target === bg) bg.dataset.down = '1'; });
    bg.addEventListener('mouseup', (e) => { if (e.target === bg && bg.dataset.down) close(); delete bg.dataset.down; });
    const api = { el: bg, body: bg.querySelector('.modal-b'), close };
    actions.forEach((a, i) => { bg.querySelector(`[data-ai="${i}"]`).onclick = async () => { if (a.onClick) { const r = await a.onClick(api); if (r === false) return; } if (a.close !== false) close(); }; });
    onMount && onMount(api);
    return api;
  }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { const m = $$('.modal-bg').pop(); if (m) m.querySelector('.x').click(); } });

  /** Formadan dəyərlər: name atributlu elementlər */
  function formData(root) {
    const o = {};
    for (const el of $$('[name]', root)) {
      if (el.type === 'checkbox') o[el.name] = el.checked;
      else if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; }
      else o[el.name] = el.value.trim();
    }
    return o;
  }

  // ---------------------------------------------------------------- panellər
  const panels = {};
  let current = 'home', params = {};
  function register(id, def) { panels[id] = def; }
  function nav() {
    const list = D.settings.panels.filter((p) => p.enabled !== false && (panels[p.id] || p.custom));
    $('#nav').innerHTML = list.map((p, i) => `${p.id === 'modules' ? '<div class="nav-sep"></div>' : ''}<button class="nav ${p.id === current ? 'on' : ''}" data-go="${esc(p.id)}"><i>${esc(p.icon || '◻')}</i><span>${esc(p.title)}</span>${badge(p.id)}</button>`).join('');
    $$('#nav [data-go]').forEach((b) => b.onclick = () => go(b.dataset.go));
    $('#centerName').textContent = D.settings.centerName || 'Tədris Mərkəzi';
  }
  function badge(id) {
    if (id === 'students') { const n = D.students.filter((s) => s.status !== 'left' && s.status !== 'finished').length; return n ? `<em>${n}</em>` : ''; }
    if (id === 'teachers') return D.teachers.length ? `<em>${D.teachers.length}</em>` : '';
    return '';
  }
  function go(id, p = {}) {
    const def = D.settings.panels.find((x) => x.id === id);
    if (!def || def.enabled === false) id = (D.settings.panels.find((x) => x.enabled !== false) || { id: 'modules' }).id;
    current = id; params = p; render();
    window.scrollTo(0, 0);
    try { localStorage.setItem('kurs_last_panel', id); } catch (e) { /* */ }
  }
  function render() {
    nav();
    const def = D.settings.panels.find((x) => x.id === current) || {};
    const P = panels[current] || (def.custom ? panels.__custom : null);
    $('#pageTitle').textContent = def.title || '';
    $('#pageSub').textContent = '';
    const view = $('#view');
    if (!P) { view.innerHTML = '<div class="empty">Panel tapılmadı</div>'; return; }
    try { P.render(view, params, def); } catch (e) { console.error(e); view.innerHTML = `<div class="alert bad">Xəta: ${esc(e.message)}</div>`; }
  }
  const refresh = () => render();
  const sub = (t) => { $('#pageSub').textContent = t; };

  // ---------------------------------------------------------------- ümumi seçicilər
  const S = () => D.settings;
  const teacher = (id) => D.teachers.find((t) => t.id === id);
  const student = (id) => D.students.find((s) => s.id === id);
  const course = (id) => D.courses.find((c) => c.id === id);
  const opt = (arr, sel, lab = (x) => x.name, empty) => (empty != null ? `<option value="">${esc(empty)}</option>` : '') + arr.map((x) => `<option value="${esc(x.id)}" ${x.id === sel ? 'selected' : ''}>${esc(lab(x))}</option>`).join('');
  const tName = (id) => { const t = teacher(id); return t ? L.fullName(t) : '—'; };
  const cName = (id) => { const c = course(id); return c ? c.name : '—'; };
  function avatar(p, imgKey) { return `<span class="av" style="background:${colorFor(p.id)}" ${imgKey ? `data-av="${esc(imgKey)}"` : ''}>${esc(initials(p).toUpperCase())}</span>`; }
  async function hydrateAvatars(root) { for (const a of $$('[data-av]', root)) { const d = await getImg(a.dataset.av); if (d) a.innerHTML = `<img src="${d}" alt="">`; } }
  function daysText(days) { return L.DAY_ORDER.filter((d) => (days || []).map(Number).includes(d)).map((d) => L.DAY_SHORT[d]).join(', '); }
  function planText(st) { const p = L.PLANS[st.plan]; return p ? p.short : '—'; }

  /** Tarix aralığı seçicisi (Bu ay / Keçən ay / Bu il / Gün / Aralıq) */
  function rangeControl(id, init = {}) {
    const t = today(); const ym = t.slice(0, 7);
    return `<div class="toolbar" id="${id}">
      <select data-r="mode"><option value="month">Ay üzrə</option><option value="day">Gün üzrə</option><option value="range">İki tarix arası</option><option value="year">İl üzrə</option></select>
      <input type="month" data-r="month" value="${init.month || ym}">
      <input type="date" data-r="day" value="${init.day || t}" class="hidden">
      <input type="date" data-r="from" value="${init.from || ym + '-01'}" class="hidden"><input type="date" data-r="to" value="${init.to || t}" class="hidden">
      <input type="number" data-r="year" value="${init.year || t.slice(0, 4)}" class="hidden" style="width:90px">
    </div>`;
  }
  function bindRange(root, id, onChange) {
    const box = $('#' + id, root);
    const sync = () => { const m = $('[data-r=mode]', box).value; $('[data-r=month]', box).classList.toggle('hidden', m !== 'month'); $('[data-r=day]', box).classList.toggle('hidden', m !== 'day'); $('[data-r=from]', box).classList.toggle('hidden', m !== 'range'); $('[data-r=to]', box).classList.toggle('hidden', m !== 'range'); $('[data-r=year]', box).classList.toggle('hidden', m !== 'year'); };
    $$('[data-r]', box).forEach((el) => el.onchange = () => { sync(); onChange && onChange(readRange(box)); });
    sync();
    return () => readRange(box);
  }
  function readRange(box) {
    const m = $('[data-r=mode]', box).value;
    if (m === 'day') { const d = $('[data-r=day]', box).value; return { from: d, to: d, label: L.fmtDate(d) }; }
    if (m === 'range') { const f = $('[data-r=from]', box).value, t = $('[data-r=to]', box).value; return { from: f, to: t, label: `${L.fmtDate(f)} – ${L.fmtDate(t)}` }; }
    if (m === 'year') { const y = $('[data-r=year]', box).value; return { from: y + '-01-01', to: y + '-12-31', label: y + '-ci il' }; }
    const v = $('[data-r=month]', box).value || today().slice(0, 7); const [y, mo] = v.split('-').map(Number);
    const last = new Date(y, mo, 0).getDate();
    return { from: `${v}-01`, to: `${v}-${String(last).padStart(2, '0')}`, label: `${L.AZM[mo - 1]} ${y}` };
  }

  return { D, L, KEYS, DEFAULT_PANELS, $, $$, esc, uid, money, today, toast, colorFor, initials, load, save, log, getImg, setImg, delImg, photoBox, bindPhotos, commitPhotos, viewImage, modal, formData, register, go, render, refresh, sub, S, teacher, student, course, opt, tName, cName, avatar, hydrateAvatars, daysText, planText, rangeControl, bindRange, mergePanels, get current() { return current; } };
})();
