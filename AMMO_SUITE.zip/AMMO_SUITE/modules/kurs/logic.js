/* AMMO — Kurs İdarəetmə: hesablama məntiqi (DOM yoxdur).
 *
 * Əsas qaydalar:
 *  - Hər "ay" = 12 akademik saat (ayarlarda dəyişir). 2x/həftə → 1.5 saat, 3x/həftə → 1 saat, intensiv → 1 saat.
 *    Deməli 2x: 8 dərs, 3x: 12 dərs, intensiv: 12 dərs = 1 ay. Kurs müddəti N ay → N × 12 saat.
 *  - Keçmiş planlı dərs işarələnməyibsə — keçirilmiş sayılır.
 *  - Üzrlü buraxılış, bayram və müəllimin gəlmədiyi gün SAYILMIR → ay həmin qədər uzanır (dərs əvəz olunur).
 *  - Üzrsüz buraxılış SAYILIR (dərs yanmış olur).
 *  - Tələbənin ayı bitdiyi gün (12-ci saat) müəllimin payı hesablanır: həmin ay üçün ödənilən məbləğ × müəllimin faizi.
 */
(function (root) {
  'use strict';

  const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0];
  const DAY_SHORT = { 1: 'B.e', 2: 'Ç.a', 3: 'Ç', 4: 'C.a', 5: 'C', 6: 'Ş', 0: 'B' };
  const DAY_FULL = { 1: 'Bazar ertəsi', 2: 'Çərşənbə axşamı', 3: 'Çərşənbə', 4: 'Cümə axşamı', 5: 'Cümə', 6: 'Şənbə', 0: 'Bazar' };
  const AZM = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];

  const PLANS = {
    '2x': { label: 'Həftədə 2 dəfə', short: '2×', days: 2, hours: 1.5 },
    '3x': { label: 'Həftədə 3 dəfə', short: '3×', days: 3, hours: 1 },
    intensive: { label: 'İntensiv (hər gün)', short: 'İntensiv', days: 0, hours: 1 }
  };
  const PRESETS = { odd: [1, 3, 5], even: [2, 4, 6], all: [1, 2, 3, 4, 5, 6] };

  const DEFAULT_SETTINGS = {
    centerName: 'Tədris Mərkəzi',
    monthHours: 12,
    plans: { '2x': 1.5, '3x': 1, intensive: 1 },
    holidays: [],
    discountReasons: ['Kampaniya', 'Şəhid ailəsi', 'Qazi ailəsi', 'Qardaş/bacı', 'Digər'],
    panels: null // app.js doldurur
  };

  // ---------------------------------------------------------------- tarix
  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = (s) => new Date(String(s).slice(0, 10) + 'T00:00:00');
  const addDays = (s, k) => { const d = parse(s); d.setDate(d.getDate() + k); return ymd(d); };
  const diffDays = (a, b) => Math.round((parse(b) - parse(a)) / 86400000);
  const fmtDate = (s) => { if (!s) return '—'; const [y, m, d] = String(s).slice(0, 10).split('-'); return `${d}.${m}.${y}`; };
  const toMin = (t) => { const [h, m] = String(t || '0:0').split(':').map(Number); return (h || 0) * 60 + (m || 0); };
  const toTime = (m) => `${pad(Math.floor(m / 60))}:${pad(Math.round(m % 60))}`;
  const money = (n) => `${(Math.round((Number(n) || 0) * 100) / 100).toFixed(2)} ₼`;
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

  // ---------------------------------------------------------------- tələbə köməkçiləri
  const fullName = (p) => [p && p.lastName, p && p.firstName].filter(Boolean).join(' ') || (p && p.name) || '—';
  function lessonHours(st, S) { const h = Number(st.duration); if (h > 0) return h; return (S.plans || DEFAULT_SETTINGS.plans)[st.plan] || 1; }
  function courseOf(st, D) { return (D.courses || []).find((c) => c.id === st.courseId) || null; }
  function monthsOf(st, D) { const c = courseOf(st, D); return Number(st.months || (c && c.months) || 1); }
  function feeOf(st, D) { const c = courseOf(st, D); const f = Number(st.monthlyFee); return f > 0 ? f : Number((c && c.monthlyFee) || 0); }

  /** k-cı ay üçün güzəşt faizi (0..100). */
  function discountFor(st, k) {
    const d = st.discount || {};
    const p = Number(d.percent) || 0;
    if (!p) return 0;
    if (!d.months || d.months === 'all') return p;
    return Array.isArray(d.months) && d.months.map(Number).includes(k) ? p : 0;
  }
  function dueFor(st, k, D) { const base = feeOf(st, D); const p = discountFor(st, k); return { base, percent: p, discount: r2(base * p / 100), due: r2(base * (1 - p / 100)) }; }

  // ---------------------------------------------------------------- dərslər
  /**
   * Tələbənin bütün dərsləri (keçmiş + proqnoz), kursun sonuna qədər.
   * Hər dərs: {date, from, to, hours, status, counted}
   *  status: present | unexcused | excused | assumed | planned | holiday | teacherAbsent | extra
   */
  function lessons(st, D, today = ymd()) {
    const S = { ...DEFAULT_SETTINGS, ...(D.settings || {}) };
    const out = [];
    if (!st.startDate || !Array.isArray(st.days) || !st.days.length) return out;
    const marks = (D.att && D.att[st.id]) || {};
    const tAbs = (D.tabs && D.tabs[st.teacherId]) || {};
    const hol = new Set(S.holidays || []);
    const h = lessonHours(st, S);
    const total = monthsOf(st, D) * (Number(S.monthHours) || 12);
    const from = toMin(st.startTime || '10:00');
    const days = new Set(st.days.map(Number));
    const stop = st.status === 'left' && st.leftDate ? st.leftDate : null;
    // tarixə görə əlavə (əvəz) dərsləri
    const extras = Object.entries(marks).filter(([, v]) => v === 'extra' || (v && v.status === 'extra')).map(([d]) => d);
    let counted = 0, d = st.startDate, guard = 0;
    while (counted < total - 1e-9 && guard++ < 1500) {
      if (stop && d > stop) break;
      const wd = parse(d).getDay();
      const isExtra = extras.includes(d);
      if (days.has(wd) || isExtra) {
        const m = marks[d] && (marks[d].status || marks[d]);
        let status;
        if (isExtra && !days.has(wd)) status = 'extra';
        else if (hol.has(d)) status = 'holiday';
        else if (tAbs[d]) status = 'teacherAbsent';
        else if (m === 'present' || m === 'unexcused' || m === 'excused') status = m;
        else status = d < today ? 'assumed' : 'planned';
        const isCounted = status === 'present' || status === 'unexcused' || status === 'assumed' || status === 'planned' || status === 'extra';
        out.push({ date: d, from: toTime(from), to: toTime(from + h * 60), hours: h, status, counted: isCounted, note: (marks[d] && marks[d].note) || '' });
        if (isCounted) counted += h;
      }
      d = addDays(d, 1);
    }
    return out;
  }

  /** Aylar (12 saatlıq bloklar): başlama, bitmə (proqnoz), irəliləyiş, ödəniş. */
  function months(st, D, today = ymd()) {
    const S = { ...DEFAULT_SETTINGS, ...(D.settings || {}) };
    const MH = Number(S.monthHours) || 12;
    const L = lessons(st, D, today);
    const n = monthsOf(st, D);
    const pays = (D.payments || []).filter((p) => p.studentId === st.id);
    const res = [];
    let cum = 0, k = 1, start = null, done = 0, plannedLeft = 0, lessonsIn = 0;
    for (const l of L) {
      if (!l.counted) continue;
      if (start == null) start = l.date;
      cum += l.hours; lessonsIn++;
      if (l.date <= today && l.status !== 'planned') done += l.hours; else plannedLeft += l.hours;
      if (cum >= k * MH - 1e-9) {
        res.push(mk(k, start, l.date, lessonsIn, done, plannedLeft));
        k++; start = null; done = 0; plannedLeft = 0; lessonsIn = 0;
        if (k > n) break;
      }
    }
    while (k <= n) { res.push(mk(k, start, null, lessonsIn, done, plannedLeft)); k++; start = null; done = 0; plannedLeft = 0; lessonsIn = 0; }
    function mk(k, s, e, cnt, done, left) {
      const due = dueFor(st, k, D);
      const pl = pays.filter((p) => Number(p.monthNo) === k);
      const paid = r2(pl.reduce((a, p) => a + Number(p.amount || 0), 0));
      const completed = !!e && e <= today && (st.status !== 'left' || e <= (st.leftDate || e));
      const started = !!s && s <= today;
      return {
        k, start: s, end: e, lessons: cnt, hoursDone: done, hoursTotal: MH,
        completed, started, daysLeft: e ? diffDays(today, e) : null,
        ...due, paid, debt: r2(Math.max(0, due.due - paid)), payDates: pl.map((p) => p.date).sort(),
        teacherId: (pl.find((p) => p.teacherId) || {}).teacherId || st.teacherId
      };
    }
    return res;
  }

  /** Davamiyyət xülasəsi (yalnız keçmiş günlər). */
  function attendanceSummary(st, D, from, to, today = ymd()) {
    const L = lessons(st, D, today).filter((l) => l.date <= today && (!from || l.date >= from) && (!to || l.date <= to));
    const c = { total: 0, present: 0, unexcused: 0, excused: 0, teacherAbsent: 0, holiday: 0, extra: 0 };
    for (const l of L) {
      if (l.status === 'planned') continue;
      if (l.status === 'present' || l.status === 'assumed') c.present++;
      else if (c[l.status] != null) c[l.status]++;
      if (['present', 'assumed', 'unexcused', 'excused', 'extra'].includes(l.status)) c.total++;
    }
    c.attended = c.present + c.extra;
    c.percent = c.total ? Math.round((c.attended / c.total) * 1000) / 10 : null;
    return c;
  }

  // ---------------------------------------------------------------- imtahan
  function grade(exam, answers) {
    let score = 0, max = 0, right = 0;
    (exam.questions || []).forEach((q, i) => { const p = Number(q.points) || 1; max += p; if (answers && answers[i] && answers[i] === q.correct) { score += p; right++; } });
    return { score, max, right, count: (exam.questions || []).length, percent: max ? Math.round((score / max) * 1000) / 10 : 0 };
  }
  function examAvg(stId, D) { const r = (D.results || []).filter((x) => x.studentId === stId); return r.length ? Math.round(r.reduce((a, x) => a + Number(x.percent || 0), 0) / r.length * 10) / 10 : null; }
  const level = (p) => p == null ? '—' : p >= 90 ? 'Əla' : p >= 75 ? 'Yaxşı' : p >= 60 ? 'Kafi' : 'Zəif';

  // ---------------------------------------------------------------- əmək haqqı
  /** [from,to] aralığında bitən aylar üzrə müəllimin payı. */
  function salary(teacher, D, from, to, today = ymd()) {
    const pct = Number(teacher.percent) || 0;
    const rows = [];
    for (const st of D.students || []) {
      for (const m of months(st, D, today)) {
        if ((m.teacherId || st.teacherId) !== teacher.id) continue;
        if (!m.end || m.end < from || m.end > to) continue;
        const base = Math.min(m.paid, m.due);
        rows.push({ student: st, month: m, base, percent: pct, amount: r2(base * pct / 100), pending: m.paid < m.due - 0.009, projected: !m.completed });
      }
    }
    rows.sort((a, b) => a.month.end.localeCompare(b.month.end));
    const done = rows.filter((r) => !r.projected), fut = rows.filter((r) => r.projected);
    return { rows, total: r2(done.reduce((a, r) => a + r.amount, 0)), base: r2(done.reduce((a, r) => a + r.base, 0)), projected: r2(fut.reduce((a, r) => a + r.amount, 0)), projectedCount: fut.length };
  }
  /** Müəllimin hazırda davam edən tələbə ayları (neçə gün qalıb). */
  function teacherProgress(teacher, D, today = ymd()) {
    const out = [];
    for (const st of D.students || []) {
      if (st.teacherId !== teacher.id || st.status === 'left') continue;
      const ms = months(st, D, today);
      const cur = ms.find((m) => !m.completed);
      const doneN = ms.filter((m) => m.completed).length;
      out.push({ student: st, current: cur || null, completedMonths: doneN, totalMonths: ms.length, expected: cur ? r2(Math.min(cur.paid, cur.due) * (Number(teacher.percent) || 0) / 100) : 0 });
    }
    return out.sort((a, b) => String(a.current && a.current.end || '9999').localeCompare(String(b.current && b.current.end || '9999')));
  }
  /** Müəllimin davamiyyəti: dərs günləri və gəlmədiyi günlər. */
  function teacherAttendance(teacher, D, from, to, today = ymd()) {
    const daysSet = new Set();
    for (const st of D.students || []) {
      if (st.teacherId !== teacher.id) continue;
      for (const l of lessons(st, D, today)) if (l.date <= today && l.date >= from && l.date <= to && l.status !== 'holiday') daysSet.add(l.date);
    }
    const abs = Object.keys((D.tabs && D.tabs[teacher.id]) || {}).filter((d) => d >= from && d <= to && d <= today);
    abs.forEach((d) => daysSet.add(d));
    const total = daysSet.size, absent = abs.length;
    return { total, absent, present: total - absent, percent: total ? Math.round(((total - absent) / total) * 1000) / 10 : null, absDates: abs.sort() };
  }

  // ---------------------------------------------------------------- boş saatlar
  /** Müəllimin həftəlik məşğulluğu: {weekday: [{from,to,student}]} */
  function busyOf(teacher, D, today = ymd()) {
    const S = { ...DEFAULT_SETTINGS, ...(D.settings || {}) };
    const map = {}; DAY_ORDER.forEach((d) => { map[d] = []; });
    for (const st of D.students || []) {
      if (st.teacherId !== teacher.id || st.status === 'left' || !st.days) continue;
      const L = lessons(st, D, today); const last = L.filter((l) => l.counted).pop();
      if (last && last.date < today) continue; // kurs bitib
      const f = toMin(st.startTime || '10:00'), t = f + lessonHours(st, S) * 60;
      for (const wd of st.days) map[wd].push({ from: f, to: t, student: st });
    }
    for (const k in map) map[k].sort((a, b) => a.from - b.from);
    return map;
  }
  function freeOf(teacher, D, today = ymd(), minMinutes = 30) {
    const busy = busyOf(teacher, D, today);
    const work = new Set((teacher.workDays || [1, 2, 3, 4, 5, 6]).map(Number));
    const wf = toMin(teacher.workFrom || '09:00'), wt = toMin(teacher.workTo || '20:00');
    const out = {};
    for (const d of DAY_ORDER) {
      out[d] = [];
      if (!work.has(d)) continue;
      let cur = wf;
      const blocks = busy[d].map((b) => [Math.max(wf, b.from), Math.min(wt, b.to)]).filter(([a, b]) => b > a).sort((a, b) => a[0] - b[0]);
      for (const [a, b] of blocks) { if (a - cur >= minMinutes) out[d].push({ from: cur, to: a }); cur = Math.max(cur, b); }
      if (wt - cur >= minMinutes) out[d].push({ from: cur, to: wt });
    }
    return { free: out, busy };
  }
  /** Yeni tələbə üçün: bu günlərdə bu saatda müəllim boşdurmu? */
  function conflicts(teacher, D, days, startTime, hours, exceptStudentId, today = ymd()) {
    const busy = busyOf(teacher, D, today);
    const f = toMin(startTime), t = f + hours * 60, out = [];
    for (const wd of days) for (const b of busy[wd] || []) if (b.student.id !== exceptStudentId && b.from < t && f < b.to) out.push({ wd, ...b });
    const work = new Set((teacher.workDays || [1, 2, 3, 4, 5, 6]).map(Number));
    const offDays = days.filter((d) => !work.has(Number(d)));
    const outside = f < toMin(teacher.workFrom || '09:00') || t > toMin(teacher.workTo || '20:00');
    return { overlaps: out, offDays, outside };
  }

  // ---------------------------------------------------------------- direktor / maliyyə
  function finance(D, from, to, today = ymd()) {
    const income = r2((D.payments || []).filter((p) => p.date >= from && p.date <= to).reduce((a, p) => a + Number(p.amount || 0), 0));
    let expected = 0, discounts = 0, debt = 0;
    for (const st of D.students || []) for (const m of months(st, D, today)) {
      if (m.start && m.start >= from && m.start <= to) { expected += m.due; discounts += m.discount; }
      if (m.started) debt += m.debt;
    }
    const payouts = r2((D.teachers || []).reduce((a, t) => a + salary(t, D, from, to, today).total, 0));
    return { income, expected: r2(expected), discounts: r2(discounts), payouts, net: r2(income - payouts), debt: r2(debt) };
  }

  const api = { DAY_ORDER, DAY_SHORT, DAY_FULL, AZM, PLANS, PRESETS, DEFAULT_SETTINGS, ymd, parse, addDays, diffDays, fmtDate, toMin, toTime, money, r2, fullName, lessonHours, courseOf, monthsOf, feeOf, discountFor, dueFor, lessons, months, attendanceSummary, grade, examAvg, level, salary, teacherProgress, teacherAttendance, busyOf, freeOf, conflicts, finance };
  root.KursLogic = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
