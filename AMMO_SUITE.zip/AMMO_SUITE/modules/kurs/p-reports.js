/* Hesabatlar: tələbə (valideyn üçün), müəllim, direktor, əmək haqqı — ekranda önizləmə + Excel + PDF */
(function () {
  'use strict';
  const { D, L, $, $$, esc, money, today } = K;
  const ST = { present: 'Gəldi', assumed: 'Keçirilib', unexcused: 'Üzrsüz (sayılır)', excused: 'Üzrlü (əvəz olunur)', holiday: 'Bayram', teacherAbsent: 'Müəllim gəlmədi', extra: 'Əvəz dərsi', planned: 'Planlı' };
  const pct = (v) => (v == null ? '—' : v + '%');
  const base = (title, sub, r) => ({ title, subtitle: sub, center: D.settings.centerName, date: `Tarix: ${L.fmtDate(today())}${r ? ' · Dövr: ' + r.label : ''}`, blocks: [] });

  // ---------------------------------------------------------------- tələbə
  function studentDoc(s, r) {
    const t = today(); const ms = L.months(s, D, t); const att = L.attendanceSummary(s, D, r.from, r.to, t); const attAll = L.attendanceSummary(s, D, null, null, t);
    const avg = L.examAvg(s.id, D); const res = D.results.filter((x) => x.studentId === s.id && x.date >= r.from && x.date <= r.to).sort((a, b) => a.date.localeCompare(b.date));
    const fee = L.feeOf(s, D); const n = ms.length;
    const doc = base('Tələbə hesabatı', L.fullName(s), r); doc.sheet = 'Tələbə';
    doc.blocks.push({ t: 'kv', items: [['Tələbə', L.fullName(s)], ['Ata adı', s.fatherName], ['Doğum tarixi', L.fmtDate(s.birthDate)], ['Telefon', s.phone], ['Valideyn', s.parentName], ['Valideyn telefonu', s.parentPhone], ['Kurs', K.cName(s.courseId)], ['Müəllim', K.tName(s.teacherId)], ['Dərs qrafiki', `${K.planText(s)} · ${K.daysText(s.days)} · ${s.startTime}, ${L.lessonHours(s, D.settings)} saat`], ['Başlama tarixi', L.fmtDate(s.startDate)], ['Kursa yazıldığı məbləğ', `${money(fee)} / ay · ${n} ay = ${money(fee * n)}`], ['Güzəşt', s.discount && Number(s.discount.percent) ? `${s.discount.percent}% — ${s.discount.reason || ''} (${s.discount.months === 'all' ? 'bütün aylar' : (s.discount.months || []).join(', ') + '-ci aylar'})` : 'yoxdur']] });
    doc.blocks.push({ t: 'kpis', items: [['Davamiyyət (dövr)', pct(att.percent)], ['İştirak etdiyi dərs', String(att.attended)], ['Üzrlü / üzrsüz', `${att.excused} / ${att.unexcused}`], ['Orta imtahan balı', pct(avg)], ['Səviyyə', L.level(avg)]] });
    doc.blocks.push({ t: 'table', title: 'Ödənişlər və aylar', cols: [{ h: 'Ay', w: 0.7 }, { h: 'Dövr', w: 2 }, { h: 'Məbləğ', w: 1, money: 1 }, { h: 'Güzəşt', w: 0.8 }, { h: 'Ödənilib', w: 1, money: 1 }, { h: 'Borc', w: 1, money: 1 }, { h: 'Vəziyyət', w: 1.2 }],
      rows: ms.map((m) => [m.k + '-ci ay', `${L.fmtDate(m.start)} – ${L.fmtDate(m.end)}`, m.due, m.percent ? m.percent + '%' : '—', m.paid, m.debt, m.completed ? 'Tamamlanıb' : m.started ? `Davam edir (${m.daysLeft} gün)` : 'Başlamayıb']),
      total: ['Cəmi', '', ms.reduce((a, m) => a + m.due, 0), '', ms.reduce((a, m) => a + m.paid, 0), ms.filter((m) => m.started).reduce((a, m) => a + m.debt, 0), ''] });
    doc.blocks.push({ t: 'table', title: 'İmtahan nəticələri', cols: [{ h: 'Tarix', w: 1 }, { h: 'İmtahan', w: 3 }, { h: 'Bal', w: 1 }, { h: 'Faiz', w: 0.8, pct: 1 }, { h: 'Səviyyə', w: 1 }], rows: res.map((x) => [L.fmtDate(x.date), (D.exams.find((e) => e.id === x.examId) || {}).title || '—', `${x.score}/${x.max}`, x.percent, L.level(x.percent)]), empty: 'Bu dövrdə imtahan olmayıb' });
    const lessons = L.lessons(s, D, t).filter((l) => l.date >= r.from && l.date <= r.to && l.date <= t);
    doc.blocks.push({ t: 'table', title: `Dərs davamiyyəti (${att.total} dərs, ümumi kurs üzrə ${pct(attAll.percent)})`, cols: [{ h: 'Tarix', w: 1 }, { h: 'Gün', w: 1.3 }, { h: 'Saat', w: 1 }, { h: 'Vəziyyət', w: 2 }], rows: lessons.map((l) => [L.fmtDate(l.date), L.DAY_FULL[L.parse(l.date).getDay()], `${l.from}–${l.to}`, ST[l.status] || l.status]), empty: 'Bu dövrdə dərs yoxdur' });
    doc.blocks.push({ t: 'note', text: 'Qeyd: “Üzrlü” buraxılmış dərslər və müəllimin gəlmədiyi günlər sayılmır — həmin dərslər əvəz olunur. “Üzrsüz” buraxılmış dərs keçirilmiş sayılır.' });
    doc.blocks.push({ t: 'sign', items: ['Direktor', 'Valideyn'] });
    return doc;
  }
  // ---------------------------------------------------------------- müəllim
  function teacherDoc(tc, r) {
    const t = today(); const stds = D.students.filter((s) => s.teacherId === tc.id);
    const ta = L.teacherAttendance(tc, D, r.from, r.to, t); const sal = L.salary(tc, D, r.from, r.to, t);
    const rows = stds.map((s) => { const ms = L.months(s, D, t); const cur = ms.find((m) => !m.completed); const a = L.attendanceSummary(s, D, r.from, r.to, t); const av = L.examAvg(s.id, D); return { s, cur, done: ms.filter((m) => m.completed).length, n: ms.length, a, av }; });
    const avs = rows.map((x) => x.av).filter((x) => x != null); const lvl = avs.length ? Math.round(avs.reduce((a, b) => a + b, 0) / avs.length * 10) / 10 : null;
    const doc = base('Müəllim hesabatı', L.fullName(tc), r); doc.sheet = 'Müəllim';
    doc.blocks.push({ t: 'kv', items: [['Müəllim', L.fullName(tc)], ['Telefon', tc.phone], ['Kurslar', (tc.courseIds || []).map(K.cName).join(', ')], ['Pay', (Number(tc.percent) || 0) + '%'], ['Diplom', [tc.uni, tc.specialty, tc.degree].filter(Boolean).join(', ')], ['Diplom №', [tc.diplomaNo, L.fmtDate(tc.diplomaDate)].filter((x) => x && x !== '—').join(' · ')], ['İş qrafiki', `${K.daysText(tc.workDays)} · ${tc.workFrom}–${tc.workTo}`], ['İşə başlama', L.fmtDate(tc.hireDate)]] });
    doc.blocks.push({ t: 'kpis', items: [['Tələbə sayı', String(stds.filter((s) => s.status !== 'left').length)], ['Orta səviyyə balı', pct(lvl)], ['Müəllimin davamiyyəti', pct(ta.percent)], ['Gəlmədiyi gün', String(ta.absent)], ['Əmək haqqı (dövr)', money(sal.total)]] });
    doc.blocks.push({ t: 'table', title: 'Öyrətdiyi tələbələr', cols: [{ h: 'Tələbə', w: 2 }, { h: 'Kurs', w: 1.4 }, { h: 'Bitən ay', w: 0.8 }, { h: 'Cari ay bitir', w: 1.1 }, { h: 'Davamiyyət', w: 0.9, pct: 1 }, { h: 'Orta bal', w: 0.8, pct: 1 }, { h: 'Səviyyə', w: 0.8 }, { h: 'Status', w: 0.8 }],
      rows: rows.map((x) => [L.fullName(x.s), K.cName(x.s.courseId), `${x.done}/${x.n}`, x.cur && x.cur.end ? `${L.fmtDate(x.cur.end)} (${x.cur.daysLeft} gün)` : 'bitib', x.a.percent == null ? '' : x.a.percent, x.av == null ? '' : x.av, L.level(x.av), { active: 'Aktiv', left: 'Ayrılıb', finished: 'Bitirib', paused: 'Dayandırılıb' }[x.s.status || 'active']]) });
    doc.blocks.push(salTable(sal, 'Əmək haqqı — dövrdə bitən tələbə ayları'));
    doc.blocks.push({ t: 'table', title: 'Müəllimin gəlmədiyi günlər', cols: [{ h: 'Tarix', w: 1 }, { h: 'Səbəb', w: 4 }], rows: ta.absDates.map((d) => [L.fmtDate(d), ((D.tabs[tc.id] || {})[d] || {}).reason || '']), empty: 'Bu dövrdə buraxılış yoxdur' });
    doc.blocks.push({ t: 'sign', items: ['Direktor', 'Müəllim'] });
    return doc;
  }
  function salTable(sal, title) {
    return { t: 'table', title, cols: [{ h: 'Tələbə', w: 2 }, { h: 'Ay', w: 0.6 }, { h: 'Ayın dövrü', w: 1.9 }, { h: 'Ödənilib', w: 1, money: 1 }, { h: 'Faiz', w: 0.6, pct: 1 }, { h: 'Müəllimin payı', w: 1.1, money: 1 }, { h: 'Qeyd', w: 1.2 }],
      rows: sal.rows.map((x) => [L.fullName(x.student), x.month.k + '-ci', `${L.fmtDate(x.month.start)} – ${L.fmtDate(x.month.end)}`, x.base, x.percent, x.projected ? '' : x.amount, [x.projected ? `proqnoz ${x.amount.toFixed(2)}` : 'hesablandı', x.pending ? `ödənilməyib ${x.month.debt.toFixed(2)}` : '', x.month.percent ? `güzəşt ${x.month.percent}%` : ''].filter(Boolean).join(', ')]),
      total: ['Hesablanan', '', '', sal.base, '', sal.total, sal.projected ? `proqnoz +${sal.projected.toFixed(2)}` : ''], empty: 'Bu dövrdə bitən tələbə ayı yoxdur' };
  }
  // ---------------------------------------------------------------- direktor
  function directorDocs(r) {
    const t = today(); const fin = L.finance(D, r.from, r.to, t);
    const act = D.students.filter((s) => s.status !== 'left');
    let A = { total: 0, attended: 0, excused: 0, unexcused: 0, teacherAbsent: 0 };
    const stRows = act.map((s) => { const a = L.attendanceSummary(s, D, r.from, r.to, t); A.total += a.total; A.attended += a.attended; A.excused += a.excused; A.unexcused += a.unexcused; A.teacherAbsent += a.teacherAbsent; const ms = L.months(s, D, t); return [L.fullName(s), K.cName(s.courseId), K.tName(s.teacherId), a.percent == null ? '' : a.percent, L.examAvg(s.id, D) ?? '', ms.filter((m) => m.started).reduce((x, m) => x + m.debt, 0)]; });
    const attP = A.total ? Math.round(A.attended / A.total * 1000) / 10 : null;
    const sum = base('Direktor hesabatı', 'Ümumi vəziyyət', r); sum.sheet = 'Xülasə'; sum.orientation = 'landscape';
    sum.blocks.push({ t: 'kpis', items: [['Daxil olan ödəniş', money(fin.income)], ['Müəllimlərə əmək haqqı', money(fin.payouts)], ['Xalis gəlir', money(fin.net)], ['Güzəştlər', money(fin.discounts)], ['Ümumi borc', money(fin.debt)]] });
    sum.blocks.push({ t: 'kpis', items: [['Aktiv tələbə', String(act.filter((s) => (s.status || 'active') === 'active').length)], ['Yeni qeydiyyat', String(D.students.filter((s) => s.startDate >= r.from && s.startDate <= r.to).length)], ['Müəllim', String(D.teachers.length)], ['Kurs', String(D.courses.length)], ['Ümumi davamiyyət', pct(attP)]] });
    sum.blocks.push({ t: 'table', title: 'Kurslar üzrə', cols: [{ h: 'Kurs', w: 2 }, { h: 'Müddət', w: 0.8 }, { h: 'Aktiv tələbə', w: 1, num: 1 }, { h: 'Yeni qeydiyyat', w: 1, num: 1 }, { h: 'Daxil olan', w: 1.2, money: 1 }, { h: 'Güzəşt', w: 1, money: 1 }, { h: 'Borc', w: 1, money: 1 }],
      rows: D.courses.map((c) => { const ss = D.students.filter((s) => s.courseId === c.id); const ids = new Set(ss.map((s) => s.id)); let disc = 0, debt = 0; for (const s of ss) for (const m of L.months(s, D, t)) { if (m.start && m.start >= r.from && m.start <= r.to) disc += m.discount; if (m.started) debt += m.debt; } return [c.name, c.months + ' ay', ss.filter((s) => (s.status || 'active') === 'active').length, ss.filter((s) => s.startDate >= r.from && s.startDate <= r.to).length, D.payments.filter((p) => ids.has(p.studentId) && p.date >= r.from && p.date <= r.to).reduce((a, p) => a + Number(p.amount), 0), disc, debt]; }), total: ['Cəmi', '', '', '', fin.income, fin.discounts, fin.debt] });
    sum.blocks.push({ t: 'table', title: 'Müəllimlər üzrə', cols: [{ h: 'Müəllim', w: 2 }, { h: 'Pay', w: 0.6, pct: 1 }, { h: 'Tələbə', w: 0.7, num: 1 }, { h: 'Davamiyyət', w: 1, pct: 1 }, { h: 'Gəlmədiyi gün', w: 1, num: 1 }, { h: 'Orta səviyyə', w: 1, pct: 1 }, { h: 'Əmək haqqı', w: 1.2, money: 1 }],
      rows: D.teachers.map((tc) => { const ta = L.teacherAttendance(tc, D, r.from, r.to, t); const ss = D.students.filter((s) => s.teacherId === tc.id && s.status !== 'left'); const av = ss.map((s) => L.examAvg(s.id, D)).filter((x) => x != null); return [L.fullName(tc), Number(tc.percent) || 0, ss.length, ta.percent == null ? '' : ta.percent, ta.absent, av.length ? Math.round(av.reduce((a, b) => a + b, 0) / av.length * 10) / 10 : '', L.salary(tc, D, r.from, r.to, t).total]; }), total: ['Cəmi', '', '', '', '', '', fin.payouts] });
    sum.blocks.push({ t: 'kv', items: [['Keçirilən dərs (tələbə-dərs)', String(A.total)], ['İştirak', String(A.attended)], ['Üzrlü buraxılış', String(A.excused)], ['Üzrsüz buraxılış', String(A.unexcused)], ['Müəllim gəlmədiyi üçün', String(A.teacherAbsent)], ['Davamiyyət', pct(attP)]] });
    sum.blocks.push({ t: 'sign', items: ['Direktor', 'Mühasib'] });
    const st = base('Tələbələr', 'Davamiyyət, bal, borc', r); st.sheet = 'Tələbələr'; st.orientation = 'landscape';
    st.blocks.push({ t: 'table', cols: [{ h: 'Tələbə', w: 2 }, { h: 'Kurs', w: 1.5 }, { h: 'Müəllim', w: 1.7 }, { h: 'Davamiyyət', w: 1, pct: 1 }, { h: 'Orta bal', w: 0.9, pct: 1 }, { h: 'Borc', w: 1, money: 1 }], rows: stRows, total: ['Cəmi', '', '', '', '', stRows.reduce((a, x) => a + x[5], 0)] });
    const pay = base('Ödənişlər', '', r); pay.sheet = 'Ödənişlər';
    const pl = D.payments.filter((p) => p.date >= r.from && p.date <= r.to).sort((a, b) => a.date.localeCompare(b.date));
    pay.blocks.push({ t: 'table', cols: [{ h: 'Tarix', w: 1 }, { h: 'Tələbə', w: 2 }, { h: 'Kurs', w: 1.5 }, { h: 'Ay', w: 0.6 }, { h: 'Üsul', w: 0.8 }, { h: 'Məbləğ', w: 1, money: 1 }], rows: pl.map((p) => { const s = K.student(p.studentId); return [L.fmtDate(p.date), s ? L.fullName(s) : '—', s ? K.cName(s.courseId) : '', p.monthNo + '-ci', p.method || '', Number(p.amount)]; }), total: ['Cəmi', '', '', '', '', fin.income] });
    const sal = base('Əmək haqqı', '', r); sal.sheet = 'Əmək haqqı'; sal.orientation = 'landscape';
    for (const tc of D.teachers) { const s = L.salary(tc, D, r.from, r.to, t); sal.blocks.push(salTable(s, `${L.fullName(tc)} — ${Number(tc.percent) || 0}% · cəmi ${money(s.total)}`)); }
    const lg = base('Əməliyyatlar jurnalı', '', r); lg.sheet = 'Jurnal';
    lg.blocks.push({ t: 'table', cols: [{ h: 'Vaxt', w: 1.2 }, { h: 'Əməliyyat', w: 5 }], rows: D.log.filter((x) => x.at.slice(0, 10) >= r.from && x.at.slice(0, 10) <= r.to).map((x) => [`${L.fmtDate(x.at.slice(0, 10))} ${new Date(x.at).toTimeString().slice(0, 5)}`, x.text]) });
    return [sum, st, pay, sal, lg];
  }

  // ---------------------------------------------------------------- ixrac
  const fname = (s) => s.replace(/[^\wəöüğıçşƏÖÜĞIÇŞİ\- ]+/gi, '').trim().replace(/\s+/g, '_');
  async function out(docs, fmt, name) {
    docs = Array.isArray(docs) ? docs : [docs];
    try {
      if (fmt === 'xlsx') await KursExport.xlsx(docs, name + '.xlsx');
      else { const merged = { ...docs[0], blocks: docs.flatMap((d, i) => (i ? [{ t: 'section', text: d.title }] : []).concat(d.blocks)) }; await KursExport.pdf(merged, name + '.pdf'); }
      K.toast(fmt === 'xlsx' ? 'Excel yükləndi' : 'PDF yükləndi');
    } catch (e) { console.error(e); K.toast('Xəta: ' + e.message); }
  }
  const allRange = (from) => ({ from: from || '2000-01-01', to: today(), label: `${L.fmtDate(from)} – ${L.fmtDate(today())}` });
  K.studentReport = (id, fmt, r) => { const s = K.student(id); if (!s) return; out(studentDoc(s, r || allRange(s.startDate)), fmt, fname(`Telebe_${L.fullName(s)}_${today()}`)); };
  K.teacherReport = (id, fmt, r) => { const tc = K.teacher(id); if (!tc) return; const m = today().slice(0, 7); out(teacherDoc(tc, r || { from: m + '-01', to: today(), label: L.AZM[Number(m.slice(5)) - 1] + ' ' + m.slice(0, 4) }), fmt, fname(`Muellim_${L.fullName(tc)}_${today()}`)); };
  K.salaryReport = (R, fmt) => {
    if (!R) return;
    const doc = base('Əmək haqqı hesablaması', R.range.label, R.range); doc.sheet = 'Əmək haqqı'; doc.orientation = 'landscape';
    doc.blocks.push({ t: 'table', title: 'Xülasə', cols: [{ h: 'Müəllim', w: 2 }, { h: 'Pay', w: 0.7, pct: 1 }, { h: 'Bitən ay sayı', w: 1, num: 1 }, { h: 'Ödənilən məbləğ', w: 1.2, money: 1 }, { h: 'Əmək haqqı', w: 1.2, money: 1 }, { h: 'Proqnoz', w: 1.1, money: 1 }], rows: R.list.map(({ t, s }) => [L.fullName(t), Number(t.percent) || 0, s.rows.filter((r) => !r.projected).length, s.base, s.total, s.projected]), total: ['Cəmi', '', R.list.reduce((a, x) => a + x.s.rows.filter((r) => !r.projected).length, 0), R.list.reduce((a, x) => a + x.s.base, 0), R.list.reduce((a, x) => a + x.s.total, 0), R.list.reduce((a, x) => a + x.s.projected, 0)] });
    for (const { t, s, prog } of R.list) {
      doc.blocks.push({ t: 'section', text: `${L.fullName(t)} — ${money(s.total)}` });
      doc.blocks.push(salTable(s, 'Dövrdə bitən aylar'));
      doc.blocks.push({ t: 'table', title: 'Davam edən aylar (neçə gün qalıb)', cols: [{ h: 'Tələbə', w: 2 }, { h: 'Cari ay', w: 0.8 }, { h: 'Saat', w: 0.8 }, { h: 'Bitir', w: 1 }, { h: 'Qalan gün', w: 0.8, num: 1 }, { h: 'Gözlənilən pay', w: 1.1, money: 1 }], rows: prog.filter((p) => p.current).map((p) => [L.fullName(p.student), `${p.current.k}/${p.totalMonths}`, `${p.current.hoursDone}/${p.current.hoursTotal}`, L.fmtDate(p.current.end), p.current.daysLeft ?? '', p.expected]) });
    }
    doc.blocks.push({ t: 'sign', items: ['Direktor', 'Mühasib'] });
    out(doc, fmt, fname(`Emek_haqqi_${R.range.from}_${R.range.to}`));
  };

  // ---------------------------------------------------------------- HTML önizləmə
  function preview(doc) {
    const cell = (v, c) => { if (v === '' || v == null) return ''; if (c.money) return money(v); if (c.pct) return v + '%'; return esc(v); };
    return `<div class="rep"><div class="rep-h"><div><small>${esc(doc.center || '')}</small><b>${esc(doc.title)}</b></div><div style="text-align:right"><small>${esc(doc.date)}</small><b style="font-size:14px">${esc(doc.subtitle || '')}</b></div></div><div class="rep-b">${doc.blocks.map((b) => {
      if (b.t === 'kv') return `<div class="kvg">${b.items.map(([k, v]) => `<div><span>${esc(k)}</span><b>${esc(v == null || v === '' ? '—' : v)}</b></div>`).join('')}</div>`;
      if (b.t === 'kpis') return `<div class="kpis" style="margin-top:12px">${b.items.map(([k, v]) => `<div class="kpi"><span>${esc(k)}</span><b style="font-size:18px">${esc(v)}</b></div>`).join('')}</div>`;
      if (b.t === 'section') return `<h4>${esc(b.text)}</h4>`;
      if (b.t === 'note') return `<p class="hint">${esc(b.text)}</p>`;
      if (b.t === 'sign') return '';
      if (b.t === 'table') return `${b.title ? `<h4>${esc(b.title)}</h4>` : ''}<div class="tbl-wrap" style="max-height:340px"><table class="t"><thead><tr>${b.cols.map((c) => `<th class="${c.money || c.num || c.pct ? 'n' : ''}">${esc(c.h)}</th>`).join('')}</tr></thead><tbody>${b.rows.map((r) => `<tr>${r.map((v, i) => `<td class="${b.cols[i] && (b.cols[i].money || b.cols[i].num || b.cols[i].pct) ? 'n' : ''}">${cell(v, b.cols[i] || {})}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${b.cols.length}" class="empty">${esc(b.empty || 'Məlumat yoxdur')}</td></tr>`}</tbody>${b.total && b.rows.length ? `<tfoot><tr>${b.total.map((v, i) => `<td class="${b.cols[i] && (b.cols[i].money || b.cols[i].num) ? 'n' : ''}">${cell(v, b.cols[i] || {})}</td>`).join('')}</tr></tfoot>` : ''}</table></div>`;
      return '';
    }).join('')}</div></div>`;
  }

  // ---------------------------------------------------------------- panellər
  const rs = { tab: 'student', student: '', teacher: '' };
  K.register('reports', {
    render(view) {
      K.sub('Valideyn üçün tələbə hesabatı və müəllim hesabatı — Excel və PDF');
      view.innerHTML = `<div class="tabs">${[['student', '🎓 Tələbə hesabatı'], ['teacher', '👩‍🏫 Müəllim hesabatı']].map(([k, l]) => `<button class="tab ${rs.tab === k ? 'on' : ''}" data-t="${k}">${l}</button>`).join('')}</div>
        <div class="toolbar">${rs.tab === 'student' ? `<select id="rS">${K.opt(D.students.slice().sort((a, b) => L.fullName(a).localeCompare(L.fullName(b), 'az')), rs.student, (s) => `${L.fullName(s)} — ${K.cName(s.courseId)}`, 'Tələbəni seçin…')}</select>` : `<select id="rT">${K.opt(D.teachers, rs.teacher, L.fullName, 'Müəllimi seçin…')}</select>`}</div>
        ${K.rangeControl('repR', rs.tab === 'student' ? { } : {})}
        <div class="toolbar"><button class="btn ghost" id="rX">⬇ Excel</button><button class="btn primary" id="rP">⬇ PDF</button></div><div id="repPrev"></div>`;
      $$('[data-t]', view).forEach((b) => b.onclick = () => { rs.tab = b.dataset.t; K.refresh(); });
      const box = $('#repR', view);
      if (rs.tab === 'student') { $('[data-r=mode]', box).value = 'range'; const s = K.student(rs.student); if (s) $('[data-r=from]', box).value = s.startDate; }
      const read = K.bindRange(view, 'repR', draw);
      const sS = $('#rS', view), sT = $('#rT', view);
      if (sS) sS.onchange = () => { rs.student = sS.value; const s = K.student(rs.student); if (s) $('[data-r=from]', box).value = s.startDate; draw(); };
      if (sT) sT.onchange = () => { rs.teacher = sT.value; draw(); };
      function doc() { const r = read(); if (rs.tab === 'student') { const s = K.student(rs.student); return s ? studentDoc(s, r) : null; } const tc = K.teacher(rs.teacher); return tc ? teacherDoc(tc, r) : null; }
      function draw() { const d = doc(); $('#repPrev', view).innerHTML = d ? preview(d) : '<div class="card"><div class="empty">Seçim edin — hesabat burada görünəcək.</div></div>'; }
      $('#rX', view).onclick = () => { const d = doc(); if (!d) return K.toast('Əvvəlcə seçim edin'); out(d, 'xlsx', fname(`${d.title}_${d.subtitle}_${today()}`)); };
      $('#rP', view).onclick = () => { const d = doc(); if (!d) return K.toast('Əvvəlcə seçim edin'); out(d, 'pdf', fname(`${d.title}_${d.subtitle}_${today()}`)); };
      draw();
    }
  });
  K.register('director', {
    render(view) {
      K.sub('Davamiyyət, kurslar, maliyyə, müəllimlər — hamısı bir yerdə');
      view.innerHTML = `${K.rangeControl('dirR')}<div class="toolbar"><button class="btn ghost" id="dX">⬇ Excel (5 vərəq)</button><button class="btn primary" id="dP">⬇ PDF</button></div><div id="dirBody"></div>`;
      const read = K.bindRange(view, 'dirR', draw);
      function draw() {
        const r = read(); const docs = directorDocs(r);
        const recent = D.log.slice(0, 30);
        $('#dirBody', view).innerHTML = preview(docs[0]) + `<div class="card" style="margin-top:14px"><h3>Son əməliyyatlar</h3><p class="sub">Sistemdə edilən bütün hərəkətlər (tam siyahı Excel-də “Jurnal” vərəqindədir)</p>${recent.map((x) => `<div class="att-row"><span>${esc(x.text)}</span><small class="muted">${L.fmtDate(x.at.slice(0, 10))} ${new Date(x.at).toTimeString().slice(0, 5)}</small></div>`).join('') || '<div class="empty">Hələ əməliyyat yoxdur</div>'}</div>`;
        $('#dX', view).onclick = () => out(docs, 'xlsx', fname(`Direktor_hesabati_${r.from}_${r.to}`));
        $('#dP', view).onclick = () => out(docs.slice(0, 4), 'pdf', fname(`Direktor_hesabati_${r.from}_${r.to}`));
      }
      draw();
    }
  });
})();
