/* AMMO — Kurs: universal hesabat ixracı. Eyni "blok" modelindən həm Excel (.xlsx), həm PDF yaradılır.
 * Bloklar:
 *  {t:'kv', items:[[label, value], ...]}
 *  {t:'kpis', items:[[label, value], ...]}
 *  {t:'table', title, cols:[{h, w, num, money, pct}], rows:[[...]], total:[...]}
 *  {t:'note', text}
 *  {t:'section', text}
 */
(function () {
  'use strict';
  const NAVY = [30, 41, 82], ACC = [79, 70, 229], GRID = [205, 210, 225];
  const clean = (v) => String(v ?? '').replace(/₼/g, 'AZN').replace(/✓/g, '+').replace(/✗/g, 'x');
  const num = (v) => (typeof v === 'number' ? v : Number(String(v).replace(/[^\d.\-]/g, '')));
  const fmtNum = (v, c) => { if (v === '' || v == null) return ''; const n = num(v); if (!Number.isFinite(n)) return clean(v); if (c.pct) return n.toFixed(1) + '%'; if (c.money) return n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' AZN'; return Number.isInteger(n) ? String(n) : n.toFixed(2); };
  function download(blob, name) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }

  // ================================================================ PDF
  async function pdf(doc, filename) {
    const { jsPDF } = window.jspdf;
    const landscape = doc.orientation === 'landscape';
    const P = new jsPDF({ orientation: landscape ? 'landscape' : 'portrait', unit: 'mm', format: 'a4', compress: true });
    P.addFileToVFS('LS-Regular.ttf', window.SH_FONTS.Regular); P.addFont('LS-Regular.ttf', 'LS', 'normal');
    P.addFileToVFS('LS-Bold.ttf', window.SH_FONTS.Bold); P.addFont('LS-Bold.ttf', 'LS', 'bold');
    P.setProperties({ title: clean(doc.title), creator: 'AMMO SUITE — Kurs' });
    const PW = landscape ? 297 : 210, PH = landscape ? 210 : 297, L = 12, R = PW - 12, W = R - L, BOTTOM = PH - 14;
    const font = (st, sz, col) => { P.setFont('LS', st); P.setFontSize(sz); P.setTextColor(...(col || [20, 24, 40])); };
    const fit = (t, w) => { t = clean(t); if (P.getTextWidth(t) <= w) return t; while (t.length > 1 && P.getTextWidth(t + '…') > w) t = t.slice(0, -1); return t + '…'; };
    let y = 0, page = 1;

    function header() {
      P.setFillColor(...NAVY); P.rect(0, 0, PW, 22, 'F');
      P.setFillColor(...ACC); P.rect(0, 22, PW, 1.2, 'F');
      font('bold', 8, [190, 198, 230]); P.text(clean(doc.center || '').toLocaleUpperCase('az'), L, 8.5);
      font('bold', 15, [255, 255, 255]); P.text(fit(doc.title, W - 50), L, 16.5);
      font('normal', 8.5, [190, 198, 230]); P.text(clean(doc.date || ''), R, 8.5, { align: 'right' });
      if (doc.subtitle) { font('normal', 9, [220, 225, 245]); P.text(fit(doc.subtitle, 80), R, 16.5, { align: 'right' }); }
      y = 30;
    }
    function footer() { font('normal', 7.5, [140, 146, 165]); P.text(`Səhifə ${page}`, R, PH - 7, { align: 'right' }); P.text('AMMO SUITE · Kurs idarəetmə', L, PH - 7); }
    function need(h) { if (y + h > BOTTOM) { footer(); P.addPage(); page++; header(); return true; } return false; }
    header();

    for (const b of doc.blocks) {
      if (b.t === 'section') { need(12); y += 2; font('bold', 11.5, NAVY); P.text(clean(b.text), L, y + 4); P.setDrawColor(...ACC); P.setLineWidth(0.5); P.line(L, y + 6, L + 18, y + 6); y += 10; }
      else if (b.t === 'note') { font('normal', 8.5, [90, 96, 115]); const lines = P.splitTextToSize(clean(b.text), W); need(lines.length * 4 + 3); P.text(lines, L, y + 3); y += lines.length * 4 + 3; }
      else if (b.t === 'kv') {
        const cols = b.cols || 2, cw = W / cols, rh = 6.4;
        const rows = Math.ceil(b.items.length / cols);
        need(rows * rh + 3);
        b.items.forEach(([k, v], i) => {
          const cx = L + (i % cols) * cw, cy = y + Math.floor(i / cols) * rh;
          P.setDrawColor(...GRID); P.setLineWidth(0.2); P.setFillColor(246, 247, 252); P.rect(cx, cy, cw * 0.38, rh, 'FD'); P.rect(cx + cw * 0.38, cy, cw * 0.62, rh, 'S');
          font('bold', 8, [70, 78, 110]); P.text(fit(k, cw * 0.38 - 3), cx + 1.6, cy + 4.3);
          font('normal', 8.6); P.text(fit(v == null || v === '' ? '—' : v, cw * 0.62 - 3), cx + cw * 0.38 + 1.6, cy + 4.3);
        });
        y += rows * rh + 4;
      } else if (b.t === 'kpis') {
        const n = b.items.length, gap = 3, kw = (W - gap * (n - 1)) / n, kh = 15;
        need(kh + 4);
        b.items.forEach(([k, v], i) => {
          const x = L + i * (kw + gap);
          P.setFillColor(243, 244, 255); P.setDrawColor(222, 225, 250); P.roundedRect(x, y, kw, kh, 2, 2, 'FD');
          font('normal', 7.5, [90, 96, 130]); P.text(fit(k, kw - 4), x + 2.5, y + 5);
          font('bold', 11.5, NAVY); P.text(fit(v, kw - 4), x + 2.5, y + 11.5);
        });
        y += kh + 5;
      } else if (b.t === 'table') {
        const cols = b.cols; const tw = cols.reduce((a, c) => a + (c.w || 1), 0);
        const ws = cols.map((c) => (c.w || 1) / tw * W);
        const rh = 6.2;
        const head = () => { let x = L; P.setFillColor(...NAVY); P.rect(L, y, W, rh + 0.6, 'F'); cols.forEach((c, i) => { font('bold', 7.6, [255, 255, 255]); const t = fit(c.h, ws[i] - 2.4); if (c.num || c.money || c.pct) P.text(t, x + ws[i] - 1.4, y + 4.4, { align: 'right' }); else P.text(t, x + 1.4, y + 4.4); x += ws[i]; }); y += rh + 0.6; };
        if (b.title) { need(rh * 3 + 7); font('bold', 9.5, NAVY); P.text(clean(b.title), L, y + 3.5); y += 5.5; }
        else need(rh * 3);
        head();
        const rowsAll = b.rows.length ? b.rows : [[b.empty || 'Məlumat yoxdur']];
        rowsAll.forEach((row, ri) => {
          if (need(rh)) head();
          if (ri % 2) { P.setFillColor(248, 249, 253); P.rect(L, y, W, rh, 'F'); }
          let x = L;
          if (!b.rows.length) { font('normal', 8, [130, 136, 155]); P.text(clean(row[0]), L + 1.4, y + 4.2); }
          else row.forEach((v, i) => {
            const c = cols[i] || {}; font(c.bold ? 'bold' : 'normal', 8, c.color ? c.color(v) : undefined);
            const t = c.num || c.money || c.pct ? fmtNum(v, c) : clean(v);
            if (c.num || c.money || c.pct) P.text(fit(t, ws[i] - 2.4), x + ws[i] - 1.4, y + 4.2, { align: 'right' }); else P.text(fit(t, ws[i] - 2.4), x + 1.4, y + 4.2);
            x += ws[i];
          });
          P.setDrawColor(...GRID); P.setLineWidth(0.15); P.line(L, y + rh, R, y + rh);
          y += rh;
        });
        if (b.total) {
          need(rh + 1); P.setFillColor(232, 234, 250); P.rect(L, y, W, rh + 0.4, 'F'); let x = L;
          b.total.forEach((v, i) => { const c = cols[i] || {}; font('bold', 8.2, NAVY); const t = (c.num || c.money || c.pct) && v !== '' ? fmtNum(v, c) : clean(v); if (c.num || c.money || c.pct) P.text(fit(t, ws[i] - 2.4), x + ws[i] - 1.4, y + 4.4, { align: 'right' }); else P.text(fit(t, ws[i] - 2.4), x + 1.4, y + 4.4); x += ws[i]; });
          y += rh + 0.4;
        }
        y += 5;
      } else if (b.t === 'sign') {
        need(24); y += 10; font('normal', 8.5);
        const cw = W / 2;
        (b.items || ['Direktor', 'Hazırladı']).forEach((lab, i) => { const x = L + i * cw; P.setDrawColor(40, 40, 40); P.line(x, y + 8, x + cw - 20, y + 8); font('bold', 8.5); P.text(clean(lab) + ':', x, y + 3); font('normal', 7.5, [120, 126, 145]); P.text('Ad, soyad / imza', x, y + 12); });
        y += 16;
      }
    }
    footer();
    download(P.output('blob'), filename);
  }

  // ================================================================ XLSX
  const xesc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');
  const colName = (i) => { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  const ST = { def: 0, title: 1, sub: 2, sec: 3, kvL: 4, kvV: 5, th: 6, td: 7, num: 8, money: 9, pct: 10, totL: 11, totN: 12, totM: 13, note: 14, kpiL: 15, kpiV: 16, thR: 17 };
  const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="3"><numFmt numFmtId="164" formatCode="#,##0.00"/><numFmt numFmtId="165" formatCode="#,##0.00\\ &quot;AZN&quot;"/><numFmt numFmtId="166" formatCode="0.0&quot;%&quot;"/></numFmts>
<fonts count="8"><font><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="16"/><color rgb="FF1E2952"/><name val="Calibri"/></font><font><sz val="10"/><color rgb="FF6B7280"/><name val="Calibri"/></font><font><b/><sz val="12"/><color rgb="FF4F46E5"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FF46506E"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FF1E2952"/><name val="Calibri"/></font><font><b/><sz val="13"/><color rgb="FF1E2952"/><name val="Calibri"/></font></fonts>
<fills count="6"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1E2952"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF6F7FC"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE8EAFA"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF3F4FF"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFCDD2E1"/></left><right style="thin"><color rgb="FFCDD2E1"/></right><top style="thin"><color rgb="FFCDD2E1"/></top><bottom style="thin"><color rgb="FFCDD2E1"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="18">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="4" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left"/></xf>
<xf numFmtId="0" fontId="5" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
<xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
<xf numFmtId="166" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
<xf numFmtId="0" fontId="6" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="164" fontId="6" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="165" fontId="6" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="7" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left"/></xf>
<xf numFmtId="0" fontId="5" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>
</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;

  function sheetXml(doc) {
    const rows = {}; const merges = []; let r = 1; let maxCols = 2;
    const set = (row, c, v, s) => { (rows[row] = rows[row] || {})[c] = { v, s }; };
    const widths = [];
    const want = (c, w) => { widths[c] = Math.max(widths[c] || 10, Math.min(60, w)); };
    set(r, 0, doc.title, ST.title); r++;
    set(r, 0, [doc.center, doc.subtitle, doc.date].filter(Boolean).join(' · '), ST.sub); r += 2;
    for (const b of doc.blocks) {
      if (b.t === 'section') { set(r, 0, b.text, ST.sec); r++; }
      else if (b.t === 'note') { set(r, 0, b.text, ST.note); merges.push(`A${r}:F${r}`); r++; }
      else if (b.t === 'kv' || b.t === 'kpis') {
        const cols = b.t === 'kpis' ? 2 : (b.cols || 2);
        b.items.forEach(([k, v], i) => {
          const rr = r + Math.floor(i / cols), cc = (i % cols) * 2;
          set(rr, cc, k, b.t === 'kpis' ? ST.kpiL : ST.kvL); set(rr, cc + 1, v == null || v === '' ? '—' : v, b.t === 'kpis' ? ST.kpiV : ST.kvV);
          want(cc, String(k).length + 2); want(cc + 1, String(v).length + 2); maxCols = Math.max(maxCols, cc + 2);
        });
        r += Math.ceil(b.items.length / cols) + 1;
      } else if (b.t === 'table') {
        if (b.title) { set(r, 0, b.title, ST.sec); r++; }
        b.cols.forEach((c, i) => { set(r, i, c.h, c.num || c.money || c.pct ? ST.thR : ST.th); want(i, c.h.length + 2); });
        maxCols = Math.max(maxCols, b.cols.length);
        r++; const first = r;
        for (const row of b.rows) {
          row.forEach((v, i) => {
            const c = b.cols[i] || {};
            if ((c.num || c.money || c.pct) && v !== '' && v != null && Number.isFinite(num(v))) set(r, i, num(v), c.money ? ST.money : c.pct ? ST.pct : ST.num);
            else set(r, i, clean(v), ST.td);
            want(i, String(v ?? '').length + 2);
          });
          r++;
        }
        if (!b.rows.length) { set(r, 0, b.empty || 'Məlumat yoxdur', ST.note); r++; }
        if (b.total) {
          b.total.forEach((v, i) => {
            const c = b.cols[i] || {};
            if ((c.num || c.money) && v !== '' && v != null && b.rows.length) set(r, i, { f: `SUM(${colName(i)}${first}:${colName(i)}${r - 1})`, v: num(v) }, c.money ? ST.totM : ST.totN);
            else set(r, i, clean(v), ST.totL);
          });
          r++;
        }
        r++;
      } else if (b.t === 'sign') {
        r++; (b.items || ['Direktor', 'Hazırladı']).forEach((lab, i) => set(r, i * 2, lab + ': ____________________', ST.kvL)); r += 2;
      }
    }
    const rowsXml = Object.keys(rows).map(Number).sort((a, b) => a - b).map((rr) => {
      const cs = Object.keys(rows[rr]).map(Number).sort((a, b) => a - b).map((c) => {
        const { v, s } = rows[rr][c]; const ref = colName(c) + rr; const st = s ? ` s="${s}"` : '';
        if (v && typeof v === 'object' && v.f) return `<c r="${ref}"${st}><f>${xesc(v.f)}</f><v>${v.v}</v></c>`;
        if (typeof v === 'number') return `<c r="${ref}"${st}><v>${v}</v></c>`;
        if (v == null || v === '') return `<c r="${ref}"${st}/>`;
        return `<c r="${ref}"${st} t="inlineStr"><is><t xml:space="preserve">${xesc(clean(v))}</t></is></c>`;
      }).join('');
      return `<row r="${rr}">${cs}</row>`;
    }).join('');
    const cols = `<cols>${Array.from({ length: Math.max(maxCols, widths.length) }, (_, i) => `<col min="${i + 1}" max="${i + 1}" width="${widths[i] || 14}" customWidth="1"/>`).join('')}</cols>`;
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews><sheetFormatPr defaultRowHeight="16"/>${cols}<sheetData>${rowsXml}</sheetData>${merges.length ? `<mergeCells count="${merges.length}">${merges.map((m) => `<mergeCell ref="${m}"/>`).join('')}</mergeCells>` : ''}<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="${doc.orientation === 'landscape' ? 'landscape' : 'portrait'}" fitToWidth="1" fitToHeight="0"/></worksheet>`;
  }

  /** docs: bir və ya bir neçə hesabat → hər biri ayrı vərəq */
  async function xlsx(docs, filename) {
    docs = Array.isArray(docs) ? docs : [docs];
    const z = new JSZip();
    const names = docs.map((d, i) => (clean(d.sheet || d.title).replace(/[\\/?*[\]:]/g, ' ').slice(0, 31) || 'Vərəq ' + (i + 1)));
    z.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${docs.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`);
    z.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
    z.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${xesc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
    z.file('xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${docs.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${docs.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
    z.file('xl/styles.xml', STYLES);
    docs.forEach((d, i) => z.file(`xl/worksheets/sheet${i + 1}.xml`, sheetXml(d)));
    download(await z.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', compression: 'DEFLATE' }), filename);
  }

  window.KursExport = { pdf, xlsx };
})();
