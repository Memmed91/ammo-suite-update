/* Başlanğıc: məlumatı yüklə, ilk ekran — Qəbul (boş saatlar), qlobal axtarış, nümunə məlumat */
(function () {
  'use strict';
  const { D, L, $, $$, esc, uid, today } = K;

  function bindSearch() {
    const inp = $('#globalSearch'), drop = $('#searchDrop');
    inp.oninput = () => {
      const q = inp.value.trim().toLowerCase(); if (q.length < 2) { drop.classList.add('hidden'); return; }
      const st = D.students.filter((s) => `${L.fullName(s)} ${s.phone || ''} ${s.parentPhone || ''} ${s.fin || ''}`.toLowerCase().includes(q)).slice(0, 8);
      const tc = D.teachers.filter((t) => `${L.fullName(t)} ${t.phone || ''}`.toLowerCase().includes(q)).slice(0, 5);
      drop.innerHTML = [...st.map((s) => `<button data-s="${s.id}">🎓 ${esc(L.fullName(s))} <small>${esc(K.cName(s.courseId))}</small></button>`), ...tc.map((t) => `<button data-t="${t.id}">👩‍🏫 ${esc(L.fullName(t))} <small>müəllim</small></button>`)].join('') || '<div class="empty">Tapılmadı</div>';
      drop.classList.remove('hidden');
      $$('[data-s]', drop).forEach((b) => b.onclick = () => { drop.classList.add('hidden'); inp.value = ''; K.openStudent(b.dataset.s); });
      $$('[data-t]', drop).forEach((b) => b.onclick = () => { drop.classList.add('hidden'); inp.value = ''; K.openTeacher(b.dataset.t); });
    };
    document.addEventListener('click', (e) => { if (!e.target.closest('.search')) drop.classList.add('hidden'); });
  }

  /** Nümunə məlumat: sınamaq üçün (istifadəçinin öz nümunəsi — Aytən müəllimə və 5 tələbə). */
  K.loadDemo = async function () {
    if ((D.students.length || D.teachers.length) && !confirm('Nümunə məlumat MÖVCUD məlumatların ÜSTÜNƏ əlavə edilsin?')) return;
    const c1 = { id: uid(), name: 'İngilis dili', months: 4, monthlyFee: 150, color: '#6366f1', description: 'General English A1–B1' };
    const c2 = { id: uid(), name: 'Rus dili', months: 1, monthlyFee: 120, color: '#0ea5e9' };
    const c3 = { id: uid(), name: 'Proqramlaşdırma', months: 8, monthlyFee: 200, color: '#10b981' };
    const t1 = { id: uid(), lastName: 'Həsənova', firstName: 'Aytən', phone: '+994 50 111 22 33', percent: 40, courseIds: [c1.id, c2.id], workDays: [1, 2, 3, 4, 5, 6], workFrom: '09:00', workTo: '19:00', uni: 'ADU', specialty: 'İngilis dili müəllimliyi', degree: 'Magistr', diplomaNo: 'MD 012345', active: true, hireDate: '2025-09-01' };
    const t2 = { id: uid(), lastName: 'Quliyev', firstName: 'Kamran', phone: '+994 55 444 55 66', percent: 50, courseIds: [c3.id], workDays: [1, 3, 5, 6], workFrom: '12:00', workTo: '20:00', uni: 'BDU', specialty: 'Kompüter elmləri', degree: 'Bakalavr', active: true, hireDate: '2026-01-10' };
    const mk = (fn, ln, start, plan, days, time, tid, cid, extra = {}) => ({ id: uid(), firstName: fn, lastName: ln, phone: '+994 70 000 00 0' + Math.floor(Math.random() * 10), parentName: 'Valideyn ' + ln, parentPhone: '+994 51 222 33 44', courseId: cid, teacherId: tid, plan, days, startTime: time, startDate: start, status: 'active', monthlyFee: 150, discount: { percent: 0, reason: '', months: 'all' }, ...extra });
    const S = [
      mk('Əli', 'Məmmədov', '2026-10-01', '2x', [4, 6], '10:00', t1.id, c1.id, { discount: { percent: 20, reason: 'Şəhid ailəsi', months: 'all' } }),
      mk('Tural', 'Əliyev', '2026-10-08', '3x', [1, 3, 5], '12:00', t1.id, c1.id),
      mk('Aygün', 'Kərimova', '2026-10-18', 'intensive', [1, 2, 3, 4, 5, 6], '15:00', t1.id, c1.id, { discount: { percent: 10, reason: 'Kampaniya', months: [1] } }),
      mk('Vəli', 'Rəhimov', '2026-11-02', '2x', [1, 4], '17:00', t1.id, c1.id),
      mk('Nadir', 'Səfərov', '2026-11-08', '3x', [2, 4, 6], '09:00', t1.id, c1.id),
      mk('Leyla', 'Nəsibova', '2026-09-05', '2x', [3, 6], '14:00', t2.id, c3.id, { monthlyFee: 200 })
    ];
    const P = S.filter((s) => s.startDate <= today()).map((s) => { const m = L.months(s, { ...D, courses: [c1, c2, c3], students: S, payments: [] }, today())[0]; return { id: uid(), studentId: s.id, monthNo: 1, amount: m.due, date: s.startDate, method: 'Nağd', teacherId: s.teacherId }; });
    const ex = { id: uid(), title: 'A1 — 1-ci ay yekun testi', courseId: c1.id, passPercent: 60, questions: [
      { q: 'I ___ a student.', a: 'am', b: 'is', c: 'are', d: 'be', correct: 'a', points: 1 },
      { q: 'She ___ to school every day.', a: 'go', b: 'goes', c: 'going', d: 'gone', correct: 'b', points: 1 },
      { q: '“Kitab” ingiliscə necədir?', a: 'Pen', b: 'Table', c: 'Book', d: 'Door', correct: 'c', points: 1 },
      { q: 'They ___ football yesterday.', a: 'play', b: 'plays', c: 'playing', d: 'played', correct: 'd', points: 1 }] };
    D.courses.push(c1, c2, c3); D.teachers.push(t1, t2); D.students.push(...S); D.payments.push(...P); D.exams.push(ex);
    D.results.push({ id: uid(), examId: ex.id, studentId: S[0].id, date: today(), at: new Date().toISOString(), answers: { 0: 'a', 1: 'b', 2: 'c', 3: 'a' }, ...L.grade(ex, { 0: 'a', 1: 'b', 2: 'c', 3: 'a' }) });
    D.att[S[0].id] = { '2026-10-08': 'excused' };
    D.tabs[t1.id] = { '2026-10-03': { reason: 'Xəstəlik' } };
    await K.save('courses', 'teachers', 'students', 'payments', 'exams', 'results', 'att', 'tabs');
    K.log('Nümunə məlumat yükləndi'); K.toast('Nümunə məlumat yükləndi'); K.go('home');
  };

  (async function boot() {
    await K.load();
    bindSearch();
    $('#qaStudent').onclick = () => K.editStudent(null);
    $('#qaTeacher').onclick = () => K.editTeacher(null);
    window.addEventListener('ammo-cloud-updated', async () => { await K.load(); K.refresh(); });
    // Proqram açılan kimi — Qəbul (müəllimlərin boş saatları)
    K.go('home');
    if (!D.teachers.length && !D.students.length) setTimeout(() => {
      K.modal({ title: 'Xoş gəlmisiniz! 👋', body: `<p>Kurs idarəetmə proqramı hazırdır. Başlamaq üçün:</p><ol><li><b>Kurslar</b> — kursları əlavə edin (ad, neçə ay, aylıq qiymət)</li><li><b>Müəllimlər</b> — müəllimi, diplomunu, iş saatlarını və faizini yazın</li><li><b>＋ Tələbə</b> — tələbəni, vəsiqəsini, kursu və dərs günlərini yazın</li></ol><p class="muted">Sınamaq üçün nümunə məlumat (Aytən müəllimə və 5 tələbə) yükləyə bilərsiniz — sonra “Modullar və ayarlar”dan silmək olar.</p>`,
        actions: [{ label: 'Boş başla' }, { label: 'Nümunə məlumat yüklə', cls: 'primary', onClick: () => K.loadDemo() }] });
    }, 300);
  })();
})();
