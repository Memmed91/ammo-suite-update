/* Davamiyyət, ödənişlər, əmək haqqı */
(function () {
  'use strict';
  const { D, L, $, $$, esc, money, today, uid } = K;

  // ================================================================= DAVAMİYYƏT
  K.attSeg = function (stId, date, status) {
    const cur = status === 'assumed' || status === 'planned' ? '' : status;
    return `<span class="seg">${[['present', 'Gəldi'], ['excused', 'Üzrlü'], ['unexcused', 'Üzrsüz']].map(([v, l]) => `<button type="button" class="${v} ${cur === v ? 'on' : ''}" data-att-st="${stId}" data-att-d="${date}" data-att-v="${v}" title="${v === 'excused' ? 'Sayılmır — dərs əvəz olunur' : v === 'unexcused' ? 'Sayılır — dərs yanır' : 'Dərsdə iştirak edib'}">${l}</button>`).join('')}</span>`;
  };
  K.bindAttSeg = function (root, after) {
    $$('[data-att-st]', root).forEach((b) => b.onclick = async () => {
      const s = b.dataset.attSt, d = b.dataset.attD, v = b.dataset.attV;
      D.att[s] = D.att[s] || {};
      const cur = D.att[s][d] && (D.att[s][d].status || D.att[s][d]);
      if (cur === v) delete D.att[s][d]; else D.att[s][d] = v;
      await K.save('att');
      const st = K.student(s);
      K.log(`Davamiyyət: ${st ? L.fullName(st) : ''} ${L.fmtDate(d)} — ${{ present: 'gəldi', excused: 'üzrlü', unexcused: 'üzrsüz' }[v]}${cur === v ? ' (ləğv)' : ''}`);
      after ? after() : K.refresh();
    });
  };
  let attDate = null;
  K.register('attendance', {
    render(view) {
      const d = attDate || today();
      const wd = L.parse(d).getDay();
      const hol = (D.settings.holidays || []).includes(d);
      const rows = [];
      for (const s of D.students) {
        if (s.status === 'finished') continue;
        const l = L.lessons(s, D, today()).find((x) => x.date === d);
        if (l) rows.push({ s, l });
      }
      const byT = {};
      for (const r of rows) (byT[r.s.teacherId] = byT[r.s.teacherId] || []).push(r);
      K.sub(`${L.DAY_FULL[wd]}, ${L.fmtDate(d)} · ${rows.length} dərs`);
      view.innerHTML = `<div class="toolbar"><button class="btn ghost" id="aPrev">‹</button><input type="date" id="aDate" value="${d}"><button class="btn ghost" id="aNext">›</button><button class="btn ghost" id="aToday">Bu gün</button>
        <label class="chip ${hol ? 'on' : ''}" id="aHol">${hol ? '✓ ' : ''}Bayram / qeyri-iş günü</label><span class="grow"></span><button class="btn soft" id="aExtra">＋ Əvəz dərsi</button></div>
        <div class="alert info" style="margin-bottom:12px">Keçmiş dərs işarələnməyibsə “keçirilib” sayılır. <b>Üzrlü</b> — dərs sayılmır, ay uzanır (əvəz olunur). <b>Üzrsüz</b> — dərs sayılır. <b>Müəllim gəlmədi</b> — həmin gün müəllimin bütün tələbələrinə sayılmır.</div>
        ${hol ? '<div class="alert warn">Bu gün bayram/qeyri-iş günü kimi qeyd olunub — heç bir dərs sayılmır.</div>' : ''}
        <div class="grid g2">${Object.entries(byT).map(([tid, list]) => {
          const tc = K.teacher(tid); const absent = !!(D.tabs[tid] && D.tabs[tid][d]);
          return `<div class="card"><div class="card-h"><div class="who">${tc ? K.avatar(tc, tc.photoKey) : ''}<div><b>${esc(K.tName(tid))}</b><small>${list.length} dərs</small></div></div>
            <div style="display:flex;gap:6px"><button class="btn sm ${absent ? 'danger' : 'ghost'}" data-tabs="${tid}">${absent ? '✗ Müəllim gəlmədi' : 'Müəllim gəlmədi?'}</button>${absent ? '' : `<button class="btn sm ok" data-allp="${tid}">Hamısı gəldi</button>`}</div></div>
            ${list.sort((a, b) => a.l.from.localeCompare(b.l.from)).map(({ s, l }) => `<div class="att-row"><div><b>${l.from}–${l.to}</b> · <button class="link" data-open="${s.id}">${esc(L.fullName(s))}</button><br><small class="muted">${esc(K.cName(s.courseId))} · ${K.statusPill(l.status)}</small></div><div>${['holiday', 'teacherAbsent'].includes(l.status) ? '' : K.attSeg(s.id, d, l.status)}</div></div>`).join('')}</div>`;
        }).join('') || '<div class="card"><div class="empty">Bu tarixdə dərs yoxdur.</div></div>'}</div>`;
      const setD = (x) => { attDate = x; K.refresh(); };
      $('#aDate', view).onchange = (e) => setD(e.target.value);
      $('#aPrev', view).onclick = () => setD(L.addDays(d, -1));
      $('#aNext', view).onclick = () => setD(L.addDays(d, 1));
      $('#aToday', view).onclick = () => setD(today());
      $('#aHol', view).onclick = async () => { const h = new Set(D.settings.holidays || []); h.has(d) ? h.delete(d) : h.add(d); D.settings.holidays = [...h].sort(); await K.save('settings'); K.log(`Bayram günü ${h.has(d) ? 'əlavə' : 'ləğv'}: ${L.fmtDate(d)}`); K.refresh(); };
      $$('[data-tabs]', view).forEach((b) => b.onclick = async () => {
        const tid = b.dataset.tabs; D.tabs[tid] = D.tabs[tid] || {};
        if (D.tabs[tid][d]) delete D.tabs[tid][d]; else { const r = prompt('Səbəb (istəyə bağlı):', ''); if (r === null) return; D.tabs[tid][d] = { reason: r }; }
        await K.save('tabs'); K.log(`Müəllim davamiyyəti: ${K.tName(tid)} ${L.fmtDate(d)} — ${D.tabs[tid][d] ? 'gəlmədi' : 'ləğv'}`); K.refresh();
      });
      $$('[data-allp]', view).forEach((b) => b.onclick = async () => { for (const { s } of byT[b.dataset.allp]) { D.att[s.id] = D.att[s.id] || {}; if (!D.att[s.id][d]) D.att[s.id][d] = 'present'; } await K.save('att'); K.toast('Hamısı “gəldi” qeyd olundu'); K.refresh(); });
      $$('[data-open]', view).forEach((b) => b.onclick = () => K.openStudent(b.dataset.open));
      $('#aExtra', view).onclick = () => extraLesson(d);
      K.bindAttSeg(view);
      K.hydrateAvatars(view);
    }
  });
  function extraLesson(d) {
    const act = D.students.filter((s) => s.status !== 'left' && s.status !== 'finished').sort((a, b) => L.fullName(a).localeCompare(L.fullName(b), 'az'));
    K.modal({
      title: 'Əvəz dərsi əlavə et',
      body: `<div class="form"><div class="alert info">Üzrlü buraxılmış və ya müəllimin gəlmədiyi dərsin əvəzinə cədvəldən kənar gündə keçirilən dərs. Bu dərs sayılır.</div><div class="row"><label class="f"><span>Tələbə</span><select id="exS">${K.opt(act, '', L.fullName, 'Seçin…')}</select></label><label class="f"><span>Tarix</span><input type="date" id="exD" value="${d}"></label></div></div>`,
      actions: [{ label: 'Ləğv et' }, { label: 'Əlavə et', cls: 'primary', async onClick(api) { const s = $('#exS', api.body).value, dt = $('#exD', api.body).value; if (!s || !dt) { K.toast('Tələbəni və tarixi seçin'); return false; } D.att[s] = D.att[s] || {}; D.att[s][dt] = { status: 'extra' }; await K.save('att'); K.log(`Əvəz dərsi: ${L.fullName(K.student(s))} — ${L.fmtDate(dt)}`); K.toast('Əvəz dərsi əlavə olundu'); K.refresh(); } }]
    });
  }

  // ================================================================= ÖDƏNİŞLƏR
  K.addPayment = function (stId, monthNo) {
    const act = D.students.filter((s) => s.status !== 'left').sort((a, b) => L.fullName(a).localeCompare(L.fullName(b), 'az'));
    K.modal({
      title: 'Ödəniş qəbul et',
      body: `<form class="form" id="pf"><div class="row"><label class="f"><span>Tələbə *</span><select name="studentId">${K.opt(act, stId, (s) => `${L.fullName(s)} — ${K.cName(s.courseId)}`, 'Seçin…')}</select></label>
        <label class="f"><span>Hansı ay üçün *</span><select name="monthNo"></select></label></div>
        <div id="pInfo"></div>
        <div class="row"><label class="f"><span>Məbləğ (₼) *</span><input name="amount" type="number" step="0.01" min="0"></label><label class="f"><span>Tarix *</span><input name="date" type="date" value="${today()}"></label>
        <label class="f"><span>Üsul</span><select name="method"><option>Nağd</option><option>Kart</option><option>Köçürmə</option></select></label><label class="f"><span>Qeyd</span><input name="note"></label></div></form>`,
      actions: [{ label: 'Ləğv et' }, {
        label: 'Ödənişi qəbul et', cls: 'primary', async onClick(api) {
          const v = K.formData($('#pf', api.body)); const s = K.student(v.studentId);
          if (!s || !v.monthNo || !(Number(v.amount) > 0) || !v.date) { K.toast('Tələbəni, ayı, məbləği və tarixi yazın'); return false; }
          const p = { id: uid(), studentId: s.id, monthNo: Number(v.monthNo), amount: Number(v.amount), date: v.date, method: v.method, note: v.note, teacherId: s.teacherId, createdAt: new Date().toISOString() };
          D.payments.push(p); await K.save('payments');
          K.log(`Ödəniş: ${L.fullName(s)} — ${p.monthNo}-ci ay, ${money(p.amount)}`); K.toast('Ödəniş qəbul olundu'); K.refresh();
        }
      }],
      onMount(api) {
        const fm = $('#pf', api.body);
        const fill = () => {
          const s = K.student(fm.studentId.value); if (!s) { fm.monthNo.innerHTML = ''; $('#pInfo', api.body).innerHTML = ''; return; }
          const ms = L.months(s, D, today());
          const firstDebt = (ms.find((m) => m.debt > 0) || ms[ms.length - 1]).k;
          const pick = monthNo || firstDebt;
          fm.monthNo.innerHTML = ms.map((m) => `<option value="${m.k}" ${m.k === pick ? 'selected' : ''}>${m.k}-ci ay · ${m.start ? L.fmtDate(m.start) : '—'} · borc ${money(m.debt)}</option>`).join('');
          const upd = () => { const m = ms.find((x) => x.k === Number(fm.monthNo.value)); if (!m) return; fm.amount.value = m.debt > 0 ? m.debt : m.due; $('#pInfo', api.body).innerHTML = `<div class="alert ${m.debt > 0 ? 'warn' : 'ok'}">${m.k}-ci ay: məbləğ ${money(m.base)}${m.percent ? `, güzəşt ${m.percent}% (${esc(s.discount.reason || '')}) → <b>${money(m.due)}</b>` : ''} · ödənilib ${money(m.paid)} · <b>borc ${money(m.debt)}</b>${m.end ? ` · ay ${L.fmtDate(m.end)}-də bitir` : ''}</div>`; };
          fm.monthNo.onchange = upd; upd();
        };
        fm.studentId.onchange = () => { monthNo = null; fill(); };
        fill();
      }
    });
  };
  let payRange = null;
  K.register('payments', {
    render(view) {
      view.innerHTML = `${K.rangeControl('payR', payRange || {})}<div id="payBody"></div>`;
      const read = K.bindRange(view, 'payR', () => { const b = $('#payR', view); payRange = { month: $('[data-r=month]', b).value }; draw(); });
      const t = today();
      function draw() {
        const r = read();
        const list = D.payments.filter((p) => p.date >= r.from && p.date <= r.to).sort((a, b) => b.date.localeCompare(a.date));
        const total = list.reduce((a, p) => a + Number(p.amount || 0), 0);
        const debtors = [];
        for (const s of D.students) { if (s.status === 'left') continue; const ms = L.months(s, D, t).filter((m) => m.started && m.debt > 0); if (ms.length) debtors.push({ s, ms, debt: ms.reduce((a, m) => a + m.debt, 0) }); }
        debtors.sort((a, b) => b.debt - a.debt);
        K.sub(`${r.label} · ${list.length} ödəniş · ${money(total)}`);
        $('#payBody', view).innerHTML = `<div class="kpis"><div class="kpi ok"><span>Daxil olan</span><b>${money(total)}</b><small>${r.label}</small></div><div class="kpi"><span>Ödəniş sayı</span><b>${list.length}</b></div><div class="kpi bad"><span>Ümumi borc</span><b>${money(debtors.reduce((a, d) => a + d.debt, 0))}</b><small>${debtors.length} tələbə</small></div></div>
          <div class="grid g2"><div class="card"><div class="card-h"><div><h3>Ödənişlər</h3><p class="sub">${r.label}</p></div><button class="btn primary sm" id="pAdd">＋ Ödəniş qəbul et</button></div>
            <div class="tbl-wrap"><table class="t"><thead><tr><th>Tarix</th><th>Tələbə</th><th>Ay</th><th>Üsul</th><th class="n">Məbləğ</th></tr></thead><tbody>${list.map((p) => { const s = K.student(p.studentId); return `<tr class="click" data-open="${p.studentId}"><td>${L.fmtDate(p.date)}</td><td>${esc(s ? L.fullName(s) : '—')}<br><small class="muted">${esc(s ? K.cName(s.courseId) : '')}</small></td><td>${p.monthNo}-ci</td><td>${esc(p.method || '')}</td><td class="n">${money(p.amount)}</td></tr>`; }).join('') || '<tr><td colspan="5" class="empty">Ödəniş yoxdur</td></tr>'}</tbody>${list.length ? `<tfoot><tr><td colspan="4">Cəmi</td><td class="n">${money(total)}</td></tr></tfoot>` : ''}</table></div></div>
          <div class="card"><h3>Borclular</h3><p class="sub">Başlamış, lakin tam ödənilməmiş aylar</p>
            <div class="tbl-wrap"><table class="t"><thead><tr><th>Tələbə</th><th>Aylar</th><th class="n">Borc</th><th></th></tr></thead><tbody>${debtors.map((d) => `<tr><td><button class="link" data-open="${d.s.id}">${esc(L.fullName(d.s))}</button><br><small class="muted">${esc(d.s.phone || d.s.parentPhone || '')}</small></td><td>${d.ms.map((m) => m.k + '-ci').join(', ')}</td><td class="n"><b style="color:var(--bad)">${money(d.debt)}</b></td><td><button class="btn sm soft" data-pay="${d.s.id}">Ödə</button></td></tr>`).join('') || '<tr><td colspan="4" class="empty">Borc yoxdur 🎉</td></tr>'}</tbody></table></div></div></div>`;
        $('#pAdd', view).onclick = () => K.addPayment();
        $$('[data-open]', view).forEach((x) => x.onclick = () => K.openStudent(x.dataset.open));
        $$('[data-pay]', view).forEach((x) => x.onclick = (e) => { e.stopPropagation(); K.addPayment(x.dataset.pay); });
      }
      draw();
    }
  });

  // ================================================================= ƏMƏK HAQQI
  const sal = { teacher: '', result: null };
  K.register('salary', {
    render(view) {
      K.sub('Müəllimin payı tələbənin ödənişli ayı bitdiyi gün hesablanır');
      view.innerHTML = `<div class="card" style="margin-bottom:14px"><div class="card-h"><div><h3>Əmək haqqı hesabla</h3><p class="sub">Müəllimi (və ya hamısını) və dövrü seçin, “Hesabla” basın. Həmin dövrdə <b>bitən</b> tələbə ayları hesablanır; hələ bitməyənlər “proqnoz” kimi ayrıca göstərilir.</p></div></div>
        <div class="toolbar"><select id="salT"><option value="">Bütün müəllimlər</option>${K.opt(D.teachers, sal.teacher, L.fullName)}</select></div>
        ${K.rangeControl('salR')}<div class="toolbar"><button class="btn primary" id="salGo">Hesabla</button><span class="grow"></span><button class="btn ghost" id="salX" disabled>⬇ Excel</button><button class="btn ghost" id="salP" disabled>⬇ PDF</button></div></div>
        <div id="salBody"><div class="empty">Dövrü seçib “Hesabla” düyməsini basın.</div></div>`;
      const read = K.bindRange(view, 'salR');
      $('#salT', view).onchange = (e) => { sal.teacher = e.target.value; };
      const go = () => {
        const r = read(); const ts = sal.teacher ? [K.teacher(sal.teacher)] : D.teachers.slice();
        sal.result = { range: r, list: ts.filter(Boolean).map((t) => ({ t, s: L.salary(t, D, r.from, r.to, today()), prog: L.teacherProgress(t, D, today()) })) };
        draw();
      };
      $('#salGo', view).onclick = go;
      $('#salX', view).onclick = () => K.salaryReport(sal.result, 'xlsx');
      $('#salP', view).onclick = () => K.salaryReport(sal.result, 'pdf');
      function draw() {
        const R = sal.result; if (!R) return;
        $('#salX', view).disabled = $('#salP', view).disabled = false;
        const grand = R.list.reduce((a, x) => a + x.s.total, 0);
        $('#salBody', view).innerHTML = `<div class="kpis"><div class="kpi acc"><span>Cəmi əmək haqqı</span><b>${money(grand)}</b><small>${esc(R.range.label)}</small></div><div class="kpi"><span>Bitən tələbə ayı</span><b>${R.list.reduce((a, x) => a + x.s.rows.filter((r) => !r.projected).length, 0)}</b></div><div class="kpi ok"><span>Proqnoz (hələ bitməyən aylar)</span><b>${money(R.list.reduce((a, x) => a + x.s.projected, 0))}</b><small>${R.list.reduce((a, x) => a + x.s.projectedCount, 0)} ay — bitdiyi gün hesablanacaq</small></div><div class="kpi warn"><span>Ödənişi gözlənilən</span><b>${R.list.reduce((a, x) => a + x.s.rows.filter((r) => r.pending && !r.projected).length, 0)}</b><small>tələbə ödəməyib — pay hesablanmadı</small></div></div>
          ${R.list.map(({ t, s, prog }) => `<div class="card" style="margin-bottom:14px"><div class="card-h"><div class="who">${K.avatar(t, t.photoKey)}<div><b>${esc(L.fullName(t))}</b><small>${Number(t.percent) || 0}% · ${esc(R.range.label)}</small></div></div><div style="text-align:right"><span class="muted small">Əmək haqqı</span><br><b style="font-size:20px;color:var(--acc)">${money(s.total)}</b>${s.projected ? `<br><small class="muted">+ proqnoz ${money(s.projected)}</small>` : ''}</div></div>
            <div class="tbl-wrap"><table class="t"><thead><tr><th>Tələbə</th><th>Ay</th><th>Ayın dövrü</th><th>Bitdi</th><th class="n">Ödənilib</th><th class="n">Faiz</th><th class="n">Müəllimin payı</th><th>Qeyd</th></tr></thead><tbody>
            ${s.rows.map((r) => `<tr><td>${esc(L.fullName(r.student))}<br><small class="muted">${esc(K.cName(r.student.courseId))}</small></td><td>${r.month.k}-ci ay</td><td>${L.fmtDate(r.month.start)} – ${L.fmtDate(r.month.end)}</td><td>${L.fmtDate(r.month.end)}</td><td class="n">${money(r.base)}</td><td class="n">${r.percent}%</td><td class="n"><b>${money(r.amount)}</b></td><td>${r.projected ? `<span class="pill mute">Proqnoz — ${r.month.daysLeft} gün qalıb</span> ` : ''}${r.pending ? `<span class="pill bad">Ödənilməyib: ${money(r.month.debt)}</span>` : (r.month.percent ? `<span class="pill acc">güzəşt ${r.month.percent}%</span>` : (r.projected ? '' : '<span class="pill ok">Hesablandı</span>'))}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">Bu dövrdə bitən tələbə ayı yoxdur</td></tr>'}</tbody>${s.rows.length ? `<tfoot><tr><td colspan="4">Hesablanan (bitmiş aylar)</td><td class="n">${money(s.base)}</td><td></td><td class="n">${money(s.total)}</td><td>${s.projected ? `proqnoz +${money(s.projected)}` : ''}</td></tr></tfoot>` : ''}</table></div>
            <details style="margin-top:10px"><summary class="link">Davam edən aylar — hansı tələbənin neçə günü qalıb (${prog.filter((p) => p.current).length})</summary>
            <div class="tbl-wrap" style="margin-top:8px"><table class="t"><thead><tr><th>Tələbə</th><th>Cari ay</th><th>İrəliləyiş</th><th>Bitir</th><th>Qalan</th><th class="n">Gözlənilən pay</th></tr></thead><tbody>${prog.filter((p) => p.current).map((p) => `<tr><td>${esc(L.fullName(p.student))}</td><td>${p.current.k}/${p.totalMonths}</td><td><div class="bar"><i style="width:${Math.min(100, p.current.hoursDone / p.current.hoursTotal * 100)}%"></i></div><small class="muted">${p.current.hoursDone}/${p.current.hoursTotal} saat</small></td><td>${L.fmtDate(p.current.end)}</td><td>${p.current.daysLeft != null ? p.current.daysLeft + ' gün' : '—'}</td><td class="n">${money(p.expected)}${p.current.debt > 0 ? '<br><span class="pill bad">ödənilməyib</span>' : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">—</td></tr>'}</tbody></table></div></details></div>`).join('')}`;
        K.hydrateAvatars(view);
      }
      if (sal.result) draw();
    }
  });
})();
