/* İmtahanlar: a, b, c, d variantlı testlər, imtahanın keçirilməsi, nəticələr */
(function () {
  'use strict';
  const { D, L, $, $$, esc, today, uid } = K;
  const LET = ['a', 'b', 'c', 'd'];
  const ef = { exam: '', course: '' };

  K.register('exams', {
    render(view) {
      const res = D.results.filter((r) => (!ef.exam || r.examId === ef.exam) && (!ef.course || (D.exams.find((e) => e.id === r.examId) || {}).courseId === ef.course)).sort((a, b) => b.date.localeCompare(a.date) || String(b.at).localeCompare(String(a.at)));
      K.sub(`${D.exams.length} imtahan · ${D.results.length} nəticə`);
      view.innerHTML = `<div class="grid g2">
        <div class="card"><div class="card-h"><div><h3>İmtahanlar</h3><p class="sub">a, b, c, d variantlı testlər</p></div><button class="btn primary sm" id="exAdd">＋ Yeni imtahan</button></div>
          <div class="tbl-wrap"><table class="t"><thead><tr><th>İmtahan</th><th>Kurs</th><th>Sual</th><th>Nəticə</th><th></th></tr></thead><tbody>
          ${D.exams.map((e) => `<tr><td><b>${esc(e.title)}</b><br><small class="muted">keçid balı ${e.passPercent || 60}%</small></td><td>${esc(K.cName(e.courseId))}</td><td>${(e.questions || []).length}</td><td>${D.results.filter((r) => r.examId === e.id).length}</td><td style="white-space:nowrap"><button class="btn sm primary" data-take="${e.id}">Keçir</button> <button class="btn sm ghost" data-edit="${e.id}">✎</button></td></tr>`).join('') || '<tr><td colspan="5" class="empty">İmtahan yoxdur</td></tr>'}</tbody></table></div></div>
        <div class="card"><div class="card-h"><div><h3>Nəticələr</h3><p class="sub">${res.length} nəticə</p></div>
          <div style="display:flex;gap:6px"><select id="rfE"><option value="">Bütün imtahanlar</option>${K.opt(D.exams, ef.exam, (e) => e.title)}</select><select id="rfC"><option value="">Bütün kurslar</option>${K.opt(D.courses, ef.course)}</select></div></div>
          <div class="tbl-wrap"><table class="t"><thead><tr><th>Tarix</th><th>Tələbə</th><th>İmtahan</th><th class="n">Bal</th><th>Səviyyə</th><th></th></tr></thead><tbody>
          ${res.map((r) => { const s = K.student(r.studentId); const e = D.exams.find((x) => x.id === r.examId) || {}; const pass = r.percent >= (e.passPercent || 60);
            return `<tr><td>${L.fmtDate(r.date)}</td><td><button class="link" data-open="${r.studentId}">${esc(s ? L.fullName(s) : '—')}</button></td><td>${esc(e.title || '—')}</td><td class="n"><b>${r.percent}%</b><br><small class="muted">${r.score}/${r.max}</small></td><td><span class="pill ${pass ? 'ok' : 'bad'}">${L.level(r.percent)}</span></td><td><button class="link" data-view="${r.id}">bax</button> · <button class="link" data-del="${r.id}" style="color:var(--bad)">sil</button></td></tr>`; }).join('') || '<tr><td colspan="6" class="empty">Nəticə yoxdur</td></tr>'}</tbody></table></div></div></div>`;
      $('#exAdd', view).onclick = () => editExam(null);
      $$('[data-edit]', view).forEach((b) => b.onclick = () => editExam(b.dataset.edit));
      $$('[data-take]', view).forEach((b) => b.onclick = () => K.takeExam(b.dataset.take));
      $('#rfE', view).onchange = (e) => { ef.exam = e.target.value; K.refresh(); };
      $('#rfC', view).onchange = (e) => { ef.course = e.target.value; K.refresh(); };
      $$('[data-open]', view).forEach((b) => b.onclick = () => K.openStudent(b.dataset.open));
      $$('[data-view]', view).forEach((b) => b.onclick = () => showResult(D.results.find((r) => r.id === b.dataset.view)));
      $$('[data-del]', view).forEach((b) => b.onclick = async () => { if (!confirm('Nəticə silinsin?')) return; D.results = D.results.filter((r) => r.id !== b.dataset.del); await K.save('results'); K.refresh(); });
    }
  });

  function editExam(id) {
    const e0 = id ? D.exams.find((x) => x.id === id) : null;
    const e = e0 ? JSON.parse(JSON.stringify(e0)) : { id: uid(), title: '', courseId: '', passPercent: 60, questions: [{ q: '', a: '', b: '', c: '', d: '', correct: 'a', points: 1 }] };
    const qHtml = (q, i) => `<div class="q-ed" data-qi="${i}"><div style="display:flex;gap:8px;align-items:center"><b>${i + 1}.</b><input class="grow" style="flex:1" data-k="q" value="${esc(q.q)}" placeholder="Sualın mətni"><input type="number" data-k="points" value="${q.points || 1}" min="0" step="0.5" style="width:70px" title="Bal"><button type="button" class="btn sm danger" data-qdel="${i}">✕</button></div>
      <div class="opts">${LET.map((l) => `<label class="opt"><input type="radio" name="c${i}" value="${l}" ${q.correct === l ? 'checked' : ''} title="Düzgün cavab"><b>${l}</b><input type="text" data-k="${l}" value="${esc(q[l] || '')}" placeholder="Variant ${l.toUpperCase()}"></label>`).join('')}</div></div>`;
    K.modal({
      title: e0 ? 'İmtahan: ' + e0.title : 'Yeni imtahan', wide: true,
      body: `<div class="form"><div class="row"><label class="f"><span>Adı *</span><input id="eT" value="${esc(e.title)}" placeholder="məs. A2 səviyyə — 1-ci ay yekun"></label><label class="f"><span>Kurs</span><select id="eC">${K.opt(D.courses, e.courseId, (c) => c.name, '—')}</select></label><label class="f"><span>Keçid balı (%)</span><input id="eP" type="number" min="0" max="100" value="${e.passPercent || 60}"></label></div>
        <div class="alert info">Düzgün cavabı variantın yanındakı dairə ilə seçin. Çoxlu sualı tez əlavə etmək üçün “Mətndən əlavə et”.</div>
        <div id="qList" class="stack"></div>
        <div class="toolbar"><button type="button" class="btn soft" id="qAdd">＋ Sual</button><button type="button" class="btn ghost" id="qBulk">Mətndən əlavə et</button><span class="grow"></span><span class="muted" id="qCnt"></span></div></div>`,
      actions: [...(e0 ? [{ label: 'Sil', cls: 'danger', left: true, onClick: async () => { if (!confirm('İmtahan və onun nəticələri silinsin?')) return false; D.exams = D.exams.filter((x) => x.id !== e0.id); D.results = D.results.filter((r) => r.examId !== e0.id); await K.save('exams', 'results'); K.refresh(); } }] : []), { label: 'Ləğv et' },
        { label: 'Yadda saxla', cls: 'primary', async onClick(api) { collect(api.body); e.title = $('#eT', api.body).value.trim(); e.courseId = $('#eC', api.body).value; e.passPercent = Number($('#eP', api.body).value) || 60; e.questions = e.questions.filter((q) => q.q.trim()); if (!e.title) { K.toast('İmtahanın adını yazın'); return false; } if (!e.questions.length) { K.toast('Ən azı bir sual yazın'); return false; } const bad = e.questions.findIndex((q) => !q[q.correct]); if (bad >= 0) { K.toast(`${bad + 1}-ci sualın düzgün variantı boşdur`); return false; } const i = D.exams.findIndex((x) => x.id === e.id); if (i >= 0) D.exams[i] = e; else D.exams.push(e); await K.save('exams'); K.log(`İmtahan: ${e.title} (${e.questions.length} sual)`); K.toast('Yadda saxlanıldı'); K.refresh(); } }],
      onMount(api) {
        const draw = () => { $('#qList', api.body).innerHTML = e.questions.map(qHtml).join(''); $('#qCnt', api.body).textContent = `${e.questions.length} sual · ${e.questions.reduce((a, q) => a + (Number(q.points) || 1), 0)} bal`; $$('[data-qdel]', api.body).forEach((b) => b.onclick = () => { collect(api.body); e.questions.splice(Number(b.dataset.qdel), 1); draw(); }); };
        $('#qAdd', api.body).onclick = () => { collect(api.body); e.questions.push({ q: '', a: '', b: '', c: '', d: '', correct: 'a', points: 1 }); draw(); const l = $$('.q-ed', api.body).pop(); l && l.scrollIntoView({ block: 'center' }); };
        $('#qBulk', api.body).onclick = () => bulk((qs) => { collect(api.body); e.questions = e.questions.filter((q) => q.q.trim()).concat(qs); draw(); });
        draw();
      }
    });
    function collect(root) {
      $$('.q-ed', root).forEach((box) => { const i = Number(box.dataset.qi); const q = e.questions[i]; if (!q) return; $$('[data-k]', box).forEach((inp) => { q[inp.dataset.k] = inp.dataset.k === 'points' ? Number(inp.value) || 1 : inp.value; }); const c = $(`input[name="c${i}"]:checked`, box); q.correct = c ? c.value : 'a'; });
    }
  }
  function bulk(done) {
    K.modal({
      title: 'Mətndən sual əlavə et', wide: true,
      body: `<div class="alert info">Format (hər sual boş sətirlə ayrılır):<br><code>1. London hansı ölkənin paytaxtıdır?<br>a) Fransa<br>b) Böyük Britaniya<br>c) İtaliya<br>d) İspaniya<br>Cavab: b</code></div><textarea id="bt" rows="16" style="width:100%;margin-top:10px;font-family:ui-monospace,Consolas,monospace"></textarea><div id="bInfo" class="hint"></div>`,
      actions: [{ label: 'Ləğv et' }, { label: 'Əlavə et', cls: 'primary', onClick(api) { const qs = parse($('#bt', api.body).value); if (!qs.length) { K.toast('Sual tanınmadı — formatı yoxlayın'); return false; } done(qs); K.toast(`${qs.length} sual əlavə olundu`); } }],
      onMount(api) { $('#bt', api.body).oninput = (ev) => { $('#bInfo', api.body).textContent = `Tanınan sual: ${parse(ev.target.value).length}`; }; }
    });
    function parse(txt) {
      const out = []; let cur = null;
      for (let line of txt.replace(/\r/g, '').split('\n')) {
        line = line.trim(); if (!line) continue;
        const o = line.match(/^([abcdABCD])[).:\-]\s*(.+)$/);
        const ans = line.match(/^(cavab|düzgün|answer|ответ)\s*[:\-]?\s*([abcdABCD])\b/i);
        if (ans && cur) { cur.correct = ans[2].toLowerCase(); continue; }
        if (o && cur) { let t = o[2]; let star = false; if (/\*\s*$/.test(t)) { star = true; t = t.replace(/\*\s*$/, '').trim(); } cur[o[1].toLowerCase()] = t; if (star) cur.correct = o[1].toLowerCase(); continue; }
        cur = { q: line.replace(/^\d+\s*[).:\-]\s*/, ''), a: '', b: '', c: '', d: '', correct: 'a', points: 1 }; out.push(cur);
      }
      return out.filter((q) => q.q && q.a && q.b);
    }
  }

  K.takeExam = function (examId, studentId) {
    const act = D.students.filter((s) => s.status !== 'left').sort((a, b) => L.fullName(a).localeCompare(L.fullName(b), 'az'));
    if (!D.exams.length) { K.toast('Əvvəlcə “İmtahanlar” bölməsində imtahan yaradın'); return; }
    K.modal({
      title: 'İmtahan keçir',
      body: `<div class="form"><div class="row"><label class="f"><span>İmtahan</span><select id="tkE">${K.opt(D.exams, examId, (e) => `${e.title} (${(e.questions || []).length} sual)`, 'Seçin…')}</select></label><label class="f"><span>Tələbə</span><select id="tkS">${K.opt(act, studentId, (s) => `${L.fullName(s)} — ${K.cName(s.courseId)}`, 'Seçin…')}</select></label><label class="f"><span>Tarix</span><input type="date" id="tkD" value="${today()}"></label></div>
        <div class="alert info">İmtahan ekranı açılır — tələbə cavabları özü seçə bilər, və ya kağız üzərində yazılmış cavabları siz daxil edə bilərsiniz.</div></div>`,
      actions: [{ label: 'Ləğv et' }, { label: 'Başla →', cls: 'primary', onClick(api) { const e = D.exams.find((x) => x.id === $('#tkE', api.body).value); const s = K.student($('#tkS', api.body).value); if (!e || !s) { K.toast('İmtahanı və tələbəni seçin'); return false; } paper(e, s, $('#tkD', api.body).value || today()); } }]
    });
  };
  function paper(e, s, date) {
    const answers = {};
    K.modal({
      title: `${e.title} — ${L.fullName(s)}`, full: true,
      body: `<div class="exam-paper"><div class="alert info" style="margin-bottom:12px">${(e.questions || []).length} sual · keçid balı ${e.passPercent || 60}% · <span id="ans">0 cavab</span></div>
        ${e.questions.map((q, i) => `<div class="exam-q"><h4>${i + 1}. ${esc(q.q)} <small class="muted">(${q.points || 1} bal)</small></h4>${LET.filter((l) => q[l]).map((l) => `<label><input type="radio" name="q${i}" value="${l}"><b>${l})</b> ${esc(q[l])}</label>`).join('')}</div>`).join('')}</div>`,
      actions: [{ label: 'Ləğv et' }, {
        label: 'İmtahanı bitir', cls: 'primary', async onClick(api) {
          const miss = e.questions.length - Object.keys(answers).length;
          if (miss && !confirm(`${miss} suala cavab verilməyib. Bitirilsin?`)) return false;
          const g = L.grade(e, answers);
          const r = { id: uid(), examId: e.id, studentId: s.id, date, at: new Date().toISOString(), answers, ...g };
          D.results.push(r); await K.save('results');
          K.log(`İmtahan nəticəsi: ${L.fullName(s)} — ${e.title}: ${g.percent}%`);
          K.refresh(); setTimeout(() => showResult(r), 50);
        }
      }],
      onMount(api) { $$('input[type=radio]', api.body).forEach((x) => x.onchange = () => { answers[Number(x.name.slice(1))] = x.value; $('#ans', api.body).textContent = `${Object.keys(answers).length}/${e.questions.length} cavab`; }); }
    });
  }
  function showResult(r) {
    if (!r) return;
    const e = D.exams.find((x) => x.id === r.examId) || { questions: [] }; const s = K.student(r.studentId);
    const pass = r.percent >= (e.passPercent || 60); const col = pass ? 'var(--ok)' : 'var(--bad)';
    K.modal({
      title: `Nəticə — ${s ? L.fullName(s) : ''}`, wide: true,
      body: `<div style="text-align:center;margin-bottom:16px"><div class="score-ring" style="border:8px solid ${col};color:${col}">${r.percent}%</div><p><b>${r.score}/${r.max} bal</b> · ${r.right}/${r.count} düzgün · <span class="pill ${pass ? 'ok' : 'bad'}">${L.level(r.percent)} — ${pass ? 'keçdi' : 'keçmədi'}</span></p><p class="muted">${esc(e.title || '')} · ${L.fmtDate(r.date)}</p></div>
        <div class="exam-paper">${e.questions.map((q, i) => { const a = r.answers[i]; return `<div class="exam-q"><h4>${i + 1}. ${esc(q.q)}</h4>${LET.filter((l) => q[l]).map((l) => `<label class="${l === q.correct ? 'right' : l === a ? 'wrong' : ''}"><b>${l})</b> ${esc(q[l])} ${l === q.correct ? '✓' : l === a ? '✗ (tələbənin cavabı)' : ''}</label>`).join('')}${a ? '' : '<small class="muted">cavab verilməyib</small>'}</div>`; }).join('')}</div>`,
      actions: [{ label: 'Bağla', cls: 'primary' }]
    });
  }
})();
