/* Modullar (panelləri aç/bağla, sırala, yeni panel əlavə et) və ayarlar */
(function () {
  'use strict';
  const { D, L, $, $$, esc, today, uid } = K;

  K.register('modules', {
    render(view) {
      K.sub('Panelləri idarə edin və mərkəzin ayarlarını dəyişin');
      const P = D.settings.panels; const S = D.settings;
      view.innerHTML = `<div class="grid g2">
        <div class="card"><div class="card-h"><div><h3>Panellər</h3><p class="sub">Açarla bağlayın/açın, oxlarla sıralayın. Öz panelinizi də əlavə edə bilərsiniz.</p></div><button class="btn primary sm" id="mAdd">＋ Yeni panel</button></div>
          ${P.map((p, i) => `<div class="att-row"><div><span style="font-size:16px;margin-right:6px">${esc(p.icon || '◻')}</span><b>${esc(p.title)}</b> ${p.custom ? `<span class="pill acc">${{ table: 'cədvəl', note: 'qeyd', link: 'link' }[p.type] || 'xüsusi'}</span>` : ''}</div>
            <div style="display:flex;gap:6px;align-items:center"><button class="btn sm ghost" data-up="${i}" ${i ? '' : 'disabled'}>↑</button><button class="btn sm ghost" data-down="${i}" ${i < P.length - 1 ? '' : 'disabled'}>↓</button>
            ${p.locked ? '<span class="pill mute">həmişə açıq</span>' : `<button class="btn sm ${p.enabled !== false ? 'ok' : 'ghost'}" data-tog="${i}">${p.enabled !== false ? 'Açıq' : 'Bağlı'}</button>`}
            ${p.custom ? `<button class="btn sm ghost" data-ren="${i}">✎</button><button class="btn sm danger" data-del="${i}">Sil</button>` : `<button class="btn sm ghost" data-ren="${i}">✎</button>`}</div></div>`).join('')}</div>
        <div class="stack">
          <div class="card"><h3>Mərkəz və dərs ayarları</h3><p class="sub">Hesablamalar bu ayarlara əsaslanır</p><form class="form" id="setF"><div class="row">
            <label class="f"><span>Mərkəzin adı (hesabatlarda)</span><input name="centerName" value="${esc(S.centerName)}"></label>
            <label class="f"><span>1 ay = neçə saat</span><input name="monthHours" type="number" min="1" step="0.5" value="${S.monthHours}"></label>
            <label class="f"><span>Həftədə 2 dəfə — dərs (saat)</span><input name="p2" type="number" step="0.25" value="${S.plans['2x']}"></label>
            <label class="f"><span>Həftədə 3 dəfə — dərs (saat)</span><input name="p3" type="number" step="0.25" value="${S.plans['3x']}"></label>
            <label class="f"><span>İntensiv — dərs (saat)</span><input name="pi" type="number" step="0.25" value="${S.plans.intensive}"></label>
            <label class="f wide"><span>Güzəşt səbəbləri (vergüllə)</span><input name="reasons" value="${esc((S.discountReasons || []).join(', '))}"></label></div>
            <div class="toolbar"><button class="btn primary" type="button" id="setSave">Yadda saxla</button></div></form></div>
          <div class="card"><h3>Bayram və qeyri-iş günləri</h3><p class="sub">Bu günlərdə dərs sayılmır, aylar uzanır</p>
            <div class="toolbar"><input type="date" id="hD"><button class="btn sm soft" id="hAdd">Əlavə et</button></div>
            <div class="chips">${(S.holidays || []).map((d) => `<span class="chip" data-hdel="${d}" title="silmək üçün klikləyin">${L.fmtDate(d)} ✕</span>`).join('') || '<span class="muted">yoxdur</span>'}</div></div>
          <div class="card"><h3>Ehtiyat nüsxə</h3><p class="sub">Bütün kurs məlumatlarını fayla yazın və ya fayldan bərpa edin</p>
            <div class="toolbar"><button class="btn ghost" id="bExp">⬇ JSON ixrac</button><label class="btn ghost">⬆ JSON idxal<input type="file" id="bImp" accept="application/json" hidden></label><button class="btn ghost" id="bDemo">Nümunə məlumat yüklə</button><button class="btn danger" id="bClear">Hamısını sil</button></div></div>
        </div></div>`;
      const sv = async () => { await K.save('settings'); K.refresh(); };
      $$('[data-up]', view).forEach((b) => b.onclick = () => { const i = Number(b.dataset.up); [P[i - 1], P[i]] = [P[i], P[i - 1]]; sv(); });
      $$('[data-down]', view).forEach((b) => b.onclick = () => { const i = Number(b.dataset.down); [P[i + 1], P[i]] = [P[i], P[i + 1]]; sv(); });
      $$('[data-tog]', view).forEach((b) => b.onclick = () => { const p = P[Number(b.dataset.tog)]; p.enabled = p.enabled === false; K.log(`Panel ${p.enabled ? 'açıldı' : 'bağlandı'}: ${p.title}`); sv(); });
      $$('[data-ren]', view).forEach((b) => b.onclick = () => { const p = P[Number(b.dataset.ren)]; const t = prompt('Panelin adı:', p.title); if (t === null) return; const ic = prompt('İkon (emoji):', p.icon || '◻'); p.title = t.trim() || p.title; if (ic) p.icon = ic.trim(); sv(); });
      $$('[data-del]', view).forEach((b) => b.onclick = async () => { const i = Number(b.dataset.del); const p = P[i]; if (!confirm(`“${p.title}” paneli və içindəki məlumatlar silinsin?`)) return; P.splice(i, 1); delete D.custom[p.id]; await K.save('custom'); K.log(`Panel silindi: ${p.title}`); sv(); });
      $('#mAdd', view).onclick = addPanel;
      $('#setSave', view).onclick = async () => { const v = K.formData($('#setF', view)); S.centerName = v.centerName || 'Tədris Mərkəzi'; S.monthHours = Number(v.monthHours) || 12; S.plans = { '2x': Number(v.p2) || 1.5, '3x': Number(v.p3) || 1, intensive: Number(v.pi) || 1 }; S.discountReasons = v.reasons.split(',').map((x) => x.trim()).filter(Boolean); await K.save('settings'); K.log('Ayarlar dəyişdi'); K.toast('Ayarlar yadda saxlanıldı'); K.refresh(); };
      $('#hAdd', view).onclick = async () => { const d = $('#hD', view).value; if (!d) return; S.holidays = [...new Set([...(S.holidays || []), d])].sort(); await sv(); };
      $$('[data-hdel]', view).forEach((c) => c.onclick = async () => { S.holidays = S.holidays.filter((x) => x !== c.dataset.hdel); await sv(); });
      $('#bExp', view).onclick = async () => { const data = {}; for (const k of K.KEYS) data[k] = D[k]; const all = await chrome.storage.local.get(null); data.images = Object.fromEntries(Object.entries(all).filter(([k]) => k.startsWith('kurs_img_'))); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' })); a.download = `kurs-ehtiyat-${today()}.json`; a.click(); };
      $('#bImp', view).onchange = async (e) => { const f = e.target.files[0]; if (!f) return; try { const data = JSON.parse(await f.text()); if (!confirm('Mövcud kurs məlumatları fayldakı ilə ƏVƏZ edilsin?')) return; for (const k of K.KEYS) if (data[k] != null) D[k] = data[k]; D.settings.panels = K.mergePanels(D.settings.panels); await K.save(...K.KEYS); if (data.images) await chrome.storage.local.set(data.images); K.toast('Bərpa olundu'); K.go('home'); } catch (err) { K.toast('Fayl oxunmadı: ' + err.message); } };
      $('#bDemo', view).onclick = () => K.loadDemo();
      $('#bClear', view).onclick = async () => { if (!confirm('BÜTÜN kurs məlumatları (tələbələr, müəllimlər, ödənişlər, imtahanlar) silinsin? Bu geri qaytarılmır.')) return; if (prompt('Təsdiq üçün SİL yazın') !== 'SİL') return; for (const k of ['courses', 'teachers', 'students', 'payments', 'exams', 'results', 'log']) D[k] = []; D.att = {}; D.tabs = {}; D.custom = {}; await K.save('courses', 'teachers', 'students', 'payments', 'exams', 'results', 'log', 'att', 'tabs', 'custom'); const all = await chrome.storage.local.get(null); await chrome.storage.local.remove(Object.keys(all).filter((k) => k.startsWith('kurs_img_'))); K.toast('Bütün məlumatlar silindi'); K.go('home'); };
    }
  });

  function addPanel() {
    K.modal({
      title: 'Yeni panel',
      body: `<form class="form" id="npf"><div class="row"><label class="f"><span>Adı *</span><input name="title" placeholder="məs. Kitab satışı"></label><label class="f"><span>İkon</span><input name="icon" value="📁"></label>
        <label class="f"><span>Növ</span><select name="type"><option value="table">Cədvəl (öz sütunlarınız)</option><option value="note">Qeydlər</option><option value="link">Veb səhifə (link)</option></select></label></div>
        <label class="f"><span>Sütunlar (cədvəl üçün, vergüllə)</span><input name="columns" placeholder="Tarix, Ad, Məbləğ, Qeyd"></label>
        <label class="f"><span>Link (veb səhifə üçün)</span><input name="url" placeholder="https://…"></label></form>`,
      actions: [{ label: 'Ləğv et' }, { label: 'Əlavə et', cls: 'primary', async onClick(api) { const v = K.formData($('#npf', api.body)); if (!v.title) { K.toast('Adı yazın'); return false; } const id = 'c_' + uid(); D.settings.panels.splice(D.settings.panels.length - 1, 0, { id, title: v.title, icon: v.icon || '📁', enabled: true, custom: true, type: v.type, columns: v.columns.split(',').map((x) => x.trim()).filter(Boolean), url: v.url }); if (v.type === 'table' && !D.settings.panels.find((p) => p.id === id).columns.length) D.settings.panels.find((p) => p.id === id).columns = ['Tarix', 'Ad', 'Qeyd']; await K.save('settings'); K.log(`Yeni panel: ${v.title}`); K.go(id); } }]
    });
  }

  // xüsusi panellər
  K.register('__custom', {
    render(view, params, def) {
      const data = D.custom[def.id] = D.custom[def.id] || (def.type === 'note' ? { text: '' } : { rows: [] });
      if (def.type === 'link') { view.innerHTML = def.url ? `<div class="toolbar"><a class="btn ghost" href="${esc(def.url)}" target="_blank" rel="noopener">Yeni pəncərədə aç ↗</a></div><iframe src="${esc(def.url)}" style="width:100%;height:calc(100vh - 160px);border:1px solid var(--line);border-radius:12px;background:#fff"></iframe>` : '<div class="empty">Link yoxdur — “Modullar” bölməsində redaktə edin.</div>'; return; }
      if (def.type === 'note') { view.innerHTML = `<div class="card"><textarea id="cn" rows="22" style="width:100%">${esc(data.text || '')}</textarea><p class="hint">Avtomatik yadda saxlanılır</p></div>`; let t; $('#cn', view).oninput = (e) => { data.text = e.target.value; clearTimeout(t); t = setTimeout(() => K.save('custom'), 500); }; return; }
      const cols = def.columns || [];
      K.sub(`${data.rows.length} sətir`);
      view.innerHTML = `<div class="toolbar"><input class="grow" id="cq" placeholder="Axtar…"><button class="btn ghost" id="cX">⬇ Excel</button><button class="btn primary" id="cAdd">＋ Sətir</button></div><div class="tbl-wrap"><table class="t"><thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join('')}<th></th></tr></thead><tbody id="cb"></tbody></table></div>`;
      const draw = (q = '') => { $('#cb', view).innerHTML = data.rows.filter((r) => !q || cols.some((c) => String(r[c] || '').toLowerCase().includes(q.toLowerCase()))).map((r) => `<tr>${cols.map((c) => `<td>${esc(r[c] || '')}</td>`).join('')}<td style="white-space:nowrap"><button class="link" data-e="${r.id}">✎</button> <button class="link" data-d="${r.id}" style="color:var(--bad)">sil</button></td></tr>`).join('') || `<tr><td colspan="${cols.length + 1}" class="empty">Boşdur</td></tr>`;
        $$('[data-e]', view).forEach((b) => b.onclick = () => edit(data.rows.find((r) => r.id === b.dataset.e)));
        $$('[data-d]', view).forEach((b) => b.onclick = async () => { if (!confirm('Silinsin?')) return; data.rows = data.rows.filter((r) => r.id !== b.dataset.d); await K.save('custom'); K.refresh(); }); };
      const edit = (row) => { const r = row ? { ...row } : { id: uid() }; K.modal({ title: def.title, body: `<form class="form" id="crf"><div class="row">${cols.map((c, i) => `<label class="f"><span>${esc(c)}</span><input name="c${i}" value="${esc(r[c] || '')}"></label>`).join('')}</div></form>`, actions: [{ label: 'Ləğv et' }, { label: 'Yadda saxla', cls: 'primary', async onClick(api) { const v = K.formData($('#crf', api.body)); cols.forEach((c, i) => { r[c] = v['c' + i]; }); const i = data.rows.findIndex((x) => x.id === r.id); if (i >= 0) data.rows[i] = r; else data.rows.push(r); await K.save('custom'); K.refresh(); } }] }); };
      $('#cAdd', view).onclick = () => edit(null);
      $('#cq', view).oninput = (e) => draw(e.target.value);
      $('#cX', view).onclick = () => KursExport.xlsx({ title: def.title, center: D.settings.centerName, date: L.fmtDate(today()), blocks: [{ t: 'table', cols: cols.map((c) => ({ h: c })), rows: data.rows.map((r) => cols.map((c) => r[c] || '')) }] }, `${def.title}.xlsx`);
      draw();
    }
  });
})();
