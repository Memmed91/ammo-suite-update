/* Vergi məktubları — V30.2: açıq e-taxes kabinetindən yenilənmə.
   "↻ Yenilə" → hansı şirkətin kabineti açıqdırsa onun məktubları oxunur → yeni olanlar varsa
   yuxarıda "🔔 Yenilənmə" çıxır → üzərinə basanda cədvələ düşür və Firebase-ə yazılır.
   popup.js-dən sonra yüklənir (records, saveLocal, render, pushFirebase, fetchFirebaseRecords qlobaldır). */
(() => {
  'use strict';
  const E = window.AmmoEtax; if (!E) return;
  const main = document.getElementById('mainPanel'); if (!main) return;
  const bar = E.bar(main, main.firstElementChild);
  const tools = document.querySelector('header.top .right-tools');
  const chip = tools ? E.topChip(tools, tools.firstChild) : null;
  let pending = [], who = null, busy = false;

  const norm = (s) => String(s || '').toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();
  function companyName(tp) {
    const fromRecords = records.find((r) => r.voen === tp.voen && r.teskilat)?.teskilat;
    if (fromRecords) return fromRecords;
    const opt = [...document.querySelectorAll('#ammoCompaniesList option')].find((o) => o.textContent.trim() === tp.voen);
    return opt?.value || tp.name || ('VÖEN ' + tp.voen);
  }
  const recNo = (r) => r.nomre || E.regNo(r.qeyd);
  function findRec(x, voen) {
    return records.find((r) => !r.deleted && (r.voen || '') === voen && (
      (r.etaxId && r.etaxId === x.etaxId) ||
      (x.nomre && norm(recNo(r)) === norm(x.nomre)) ||
      (x.regNo2 && norm(recNo(r)) === norm(x.regNo2))
    ));
  }
  function exists(x, voen) { return !!findRec(x, voen); }

  /* V31.0.3: .adoc faylları — açıq kabinetin şirkəti üzrə faylı olmayan məktublar üçün avtomatik yüklənir */
  const failed = new Set(); let filesBusy = false;
  async function autoFiles(all, voen, limit = 20) {
    if (filesBusy || !all?.length || !authState?.idToken) return 0;
    filesBusy = true; let done = 0;
    try {
      for (const x of all) {
        if (done >= limit) break;
        const rec = findRec(x, voen);
        if (!rec || rec.adocName || failed.has(x.etaxId)) continue;
        const f = await E.letterFile({ id: x.etaxId, voen });
        if (!f.ok) { failed.add(x.etaxId); if (f.error === 'expired' || f.error === 'no_tab' || f.error === 'wrong_company') break; continue; }
        rec.etaxId = x.etaxId;
        if (!String(rec.nomre || '').trim()) rec.nomre = x.nomre;
        try { await saveLetterFile(rec, f); done++; } catch (e) { failed.add(x.etaxId); console.warn('AMMO adoc', e); }
      }
    } finally { filesBusy = false; }
    if (done) { await saveLocal(); render(); }
    return done;
  }
  let lastAll = [];
  async function fetchOne(recId) {
    const rec = records.find((r) => r.id === recId); if (!rec) return;
    await check(true);
    if (!who || who.voen !== rec.voen) {
      alert(`Bu məktub ${rec.teskilat || rec.voen} şirkətinindir.\n\nHəmin şirkətin e-taxes kabinetini (new.e-taxes.gov.az) açın və yenidən “⤓ Al” basın — sənəd avtomatik yüklənəcək.`);
      return;
    }
    const x = lastAll.find((l) => (rec.etaxId && l.etaxId === rec.etaxId) || (l.nomre && norm(l.nomre) === norm(recNo(rec))));
    if (!x) { alert('Bu məktub açıq kabinetin “Daxil olanlar” siyahısında tapılmadı (son 2 il).'); return; }
    failed.delete(x.etaxId);
    bar.show('info', `${who.name}: sənəd yüklənir...`);
    const n = await autoFiles([x], who.voen, 1);
    if (n) bar.show('ok', `${who.name}: .adoc sənədi yükləndi`, 'Cədvəldə “⬇ ADOC” düyməsi ilə istədiyiniz vaxt yükləyə bilərsiniz.');
    else bar.show('warn', 'Sənəd e-taxes-dən alınmadı', 'Kabinetin sessiyası bitmiş ola bilər — yenidən daxil olub təkrar edin.');
  }
  window.AMMO_LETTER_FILES = { fetchOne };
  function setChip(n) { if (!chip) return; chip.textContent = `🔔 Yenilənmə (${n})`; chip.classList.toggle('hidden', !n); }

  async function check(manual) {
    if (busy) return; busy = true;
    try {
      const r = await E.snapshot({ letters: true });
      if (!r.ok) { pending = []; setChip(0); if (manual) bar.show('warn', E.errorText(r)); else bar.hide(); return; }
      const tp = r.taxpayer || {};
      if (!tp.voen) { if (manual) bar.show('warn', 'e-taxes kabineti açıqdır, amma şirkətin VÖEN-i müəyyən edilmədi.', 'Kabinetin ana səhifəsini bir dəfə açıb yenidən “Yenilə” basın.'); return; }
      who = { voen: tp.voen, name: companyName(tp) };
      if (r.lettersInfo === 'expired') { bar.show('warn', `${who.name}: e-taxes sessiyasının vaxtı bitib.`, 'Kabinetə yenidən daxil olun.'); return; }
      const all = E.normalizeLetters(r.letters || []);
      lastAll = all;
      // Yeni kimi yalnız bu ilin məktubları təklif olunur (köhnə illərin məktubları cədvələ yığılmasın)
      const yearStart = new Date().getFullYear() + '-01-01';
      pending = all.filter((x) => (!x.tarixGelen || x.tarixGelen >= yearStart) && !exists(x, who.voen));
      if (r.lettersInfo === 'api') autoFiles(all, who.voen).then((n) => { if (n && !pending.length) bar.show('ok', `${who.name}: ${n} məktubun .adoc sənədi yükləndi`, 'Cədvəldə “⬇ ADOC” ilə istədiyiniz vaxt açın.'); });
      setChip(pending.length);
      if (pending.length) {
        bar.show('new', `Yenilənmə — ${who.name} (${who.voen}): ${pending.length} yeni məktub`, pending.slice(0, 3).map((x) => [x.nomre, x.subject].filter(Boolean).join(' · ')).join('  |  ') + (pending.length > 3 ? '  …' : ''), apply, 'Yenilənmə ⤵');
      } else if (!all.length && r.lettersInfo === 'no_endpoint') {
        bar.show('info', `Açıq kabinet: ${who.name} (${who.voen})`, 'Məktubları oxumaq üçün kabinetdə bir dəfə “Məktublar / Bildirişlər” bölməsini açın — AMMO ünvanı öyrənəcək. Sonra “Yenilə” basın.');
      } else if (manual) {
        bar.show('ok', `${who.name} (${who.voen}): yeni məktub yoxdur`, `Kabinetdə ${all.length} məktub yoxlanıldı · ${new Date().toLocaleTimeString('az-AZ')}`);
      }
    } finally { busy = false; }
  }

  async function apply() {
    if (!pending.length || !who) return;
    const list = pending.slice(); pending = []; setChip(0);
    bar.show('info', `${list.length} məktub cədvələ yazılır...`);
    const rows = list.map((x) => ({
      id: 'id_' + Date.now() + '_' + Math.random().toString(16).slice(2),
      teskilat: who.name, voen: who.voen, nomre: x.nomre, nov: x.nov,
      tarixGelen: x.tarixGelen, tarixCavab: '', teyinat: 'CAVABLANDIRILMADI',
      qeyd: [x.subject, E.stripRegNo(x.sender)].filter(Boolean).join(' — ').slice(0, 300),
      etaxId: x.etaxId, source: 'e-taxes', updatedAt: Date.now(), updatedBy: (authState && authState.email) || '', deleted: false
    }));
    rows.forEach((r) => records.unshift(r));
    await saveLocal(); render();
    let ok = 0;
    for (const r of rows) { try { await pushFirebase(r); ok++; } catch (e) { console.warn('AMMO məktub Firebase', e); } }
    try { await fetchFirebaseRecords(); } catch (e) { /* lokal qalır */ }
    try { await autoFiles(list, who.voen, list.length); } catch (e) { console.warn('AMMO adoc', e); }
    bar.show(ok === rows.length ? 'ok' : 'warn', `${who.name}: ${rows.length} yeni məktub cədvələ əlavə olundu`, ok === rows.length ? 'Firebase serverə yazıldı — bütün kompüterlərdə görünəcək.' : `${rows.length - ok} məktub hələ Firebase-ə yazılmadı (internet?).`);
  }

  if (chip) chip.onclick = apply;
  document.getElementById('refreshBtn')?.addEventListener('click', () => check(true));
  // Panel açıq olduqca hər dəqiqə səssiz yoxla — yeni məktub varsa zolaq özü çıxır
  setTimeout(() => check(false), 2500);
  setInterval(() => { if (document.visibilityState === 'visible') check(false); }, 60000);
})();
