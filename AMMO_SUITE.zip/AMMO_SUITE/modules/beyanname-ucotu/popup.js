/* V31: Vergi məktubları AMMO SUITE-in öz Firebase layihəsindədir (konsalting-79c40).
   Giriş AMMO SUITE hesabı ilə olur (ammo-fs.js) — ayrıca parol yoxdur. Köhnə gomruk-nezaret məlumatı avtomatik köçürülür. */
const COLLECTION = "beyannameUcotu";
const LOCAL_KEY = "beyannameUcotuLocalCache";
const BASE = AMMO_FS.base(COLLECTION);

let records = [];
let editId = null;
let authState = null;
let pollTimer = null;
let syncBusy = false;

const $ = id => document.getElementById(id);
const fields = ["teskilat","voen","nomre","nov","tarixGelen","tarixCavab","teyinat","qeyd"];

function setBadge(on, text){
  const b = $("serverBadge");
  if(!b) return;
  b.className = "server-badge " + (on ? "on" : "off");
  b.textContent = text;
}

function setSyncInfo(text){
  const el = $("syncInfo");
  if(el) el.textContent = text;
}

function nowText(){
  return new Date().toLocaleString("az-AZ");
}

function normalizeText(v){
  return String(v || "").toLowerCase().trim();
}

function escapeHtml(v){
  return String(v ?? "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#039;");
}

function formatDate(v){
  if(!v) return "";
  if(v === "yoxdur") return "yoxdur";
  const d = new Date(v);
  if(isNaN(d)) return v;
  return String(d.getDate()).padStart(2,"0") + "." +
         String(d.getMonth()+1).padStart(2,"0") + "." +
         d.getFullYear();
}

function daysBetween(a,b){
  if(!a || !b || a === "yoxdur" || b === "yoxdur") return "";
  const d1 = new Date(a);
  const d2 = new Date(b);
  if(isNaN(d1) || isNaN(d2)) return "";
  return Math.max(0, Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24)));
}

/* V31.0.3: gecikmə — cavab verilənə qədər hər gün artır */
function todayIso(){ const d=new Date(); return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0"); }
function delayInfo(r){
  if(r.tarixCavab && r.tarixCavab !== "yoxdur") return { n: daysBetween(r.tarixGelen, r.tarixCavab), open:false };
  if(r.teyinat === "CAVABLANDIRILIB" || !r.tarixGelen || r.tarixGelen === "yoxdur") return { n:"", open:false };
  return { n: daysBetween(r.tarixGelen, todayIso()), open:true };
}
function delayHtml(r){
  const d = delayInfo(r);
  if(d.n === "") return "";
  if(!d.open) return escapeHtml(d.n);
  return `<span class="delay-open" title="Hələ cavablandırılmayıb — bu gün də sayılır">${escapeHtml(d.n)} gün</span>`;
}

/* V31.0.3: qeydiyyat nömrəsi ("Qeydiyyat nömrəsi: 3-21-2-4/2-341082/2026") */
const REG_RX = /Qeydiyyat\s+n[öo]mr[əe]si\s*[:№]?\s*([^\s,;]+)/i;
const regFrom = t => (String(t||"").match(REG_RX) || [])[1] || "";
const stripReg = t => String(t||"").replace(REG_RX, "").replace(/\s+—\s*$/, "").replace(/\s{2,}/g, " ").trim();
let regBackfillDone = false;
async function backfillNumbers(){
  if(regBackfillDone || !authState?.idToken) return;
  regBackfillDone = true;
  const fix = records.filter(r => !r.deleted && !String(r.nomre||"").trim() && regFrom(r.qeyd));
  for(const r of fix){
    r.nomre = regFrom(r.qeyd); r.qeyd = stripReg(r.qeyd); r.updatedAt = Date.now();
    try{ await pushFirebase(r); }catch(e){ console.warn("AMMO nömrə", e); }
  }
  if(fix.length){ await saveLocal(); render(); setSyncInfo(`${fix.length} məktubun qeydiyyat nömrəsi “Nömrə” sütununa yazıldı`); }
}

/* V31.0.3: məktubun .adoc faylı — Firebase-də hissələrlə saxlanılır (taskFileChunks), yalnız “Yüklə” basanda oxunur */
const FILE_BASE = AMMO_FS.base("taskFileChunks");
const CHUNK = 700000;
const fileDocId = (id, i) => `letter_${id}_${String(i).padStart(4,"0")}`;
async function saveLetterFile(rec, f){
  const parts = Math.max(1, Math.ceil(f.b64.length / CHUNK));
  for(let i=0;i<parts;i++){
    await apiFetch(`${FILE_BASE}/${encodeURIComponent(fileDocId(rec.id,i))}`, { method:"PATCH", body: JSON.stringify({ fields: toFsFields({
      taskId: "letter:" + rec.id, kind: "letterAdoc", name: f.name, part: i, parts, size: f.size, data: f.b64.slice(i*CHUNK, (i+1)*CHUNK), updatedAt: Date.now() }) }) });
  }
  Object.assign(rec, { adocName: f.name, adocSize: f.size, adocParts: parts, adocAt: Date.now(), updatedAt: Date.now() });
  if(!String(rec.nomre||"").trim() && f.regNo) rec.nomre = f.regNo;
  await pushFirebase(rec);
}
async function downloadLetterFile(id){
  const rec = records.find(x => x.id === id); if(!rec?.adocName) return;
  const btn = document.querySelector(`[data-file="${CSS.escape(id)}"]`); if(btn){ btn.disabled = true; btn.textContent = "Yüklənir..."; }
  try{
    let b64 = "";
    for(let i=0;i<(rec.adocParts||1);i++){
      const d = await apiFetch(`${FILE_BASE}/${encodeURIComponent(fileDocId(id,i))}`);
      b64 += d.fields?.data?.stringValue || "";
    }
    const bin = atob(b64), u8 = new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++) u8[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([u8], { type:"application/octet-stream" }));
    const a = document.createElement("a"); a.href = url; a.download = rec.adocName; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }catch(e){ alert("Sənəd yüklənmədi: " + e.message); }
  finally{ if(btn){ btn.disabled = false; btn.textContent = "⬇ ADOC"; } }
}
function fileHtml(r){
  if(r.adocName) return `<button class="action file" data-file="${escapeHtml(r.id)}" title="${escapeHtml(r.adocName)} · ${Math.round((r.adocSize||0)/1024)} KB">⬇ ADOC</button>`;
  if(r.source === "e-taxes" || r.etaxId) return `<button class="action fetch" data-fetch="${escapeHtml(r.id)}" title="Bu şirkətin e-taxes kabineti açıq olanda sənəd avtomatik yüklənir">⤓ Al</button>`;
  return `<span class="muted-dash">—</span>`;
}

function newId(){
  return "id_" + Date.now() + "_" + Math.random().toString(16).slice(2);
}

function getForm(){
  return {
    id: editId || newId(),
    teskilat: $("teskilat").value.trim(),
    voen: $("voen").value.trim(),
    nomre: $("nomre").value.trim(),
    nov: $("nov").value.trim(),
    tarixGelen: $("tarixGelen").value,
    tarixCavab: $("tarixCavab").value,
    teyinat: $("teyinat").value || "CAVABLANDIRILMADI",
    qeyd: $("qeyd").value.trim(),
    updatedAt: Date.now(),
    updatedBy: authState?.email || "",
    deleted: false
  };
}

function clearForm(){
  fields.forEach(f => { if($(f)) $(f).value = ""; });
  if($("gecikme")) $("gecikme").value = "";
  editId = null;
  $("addBtn")?.classList.remove("hidden");
  $("saveEditBtn")?.classList.add("hidden");
}

async function saveLocal(){
  await chrome.storage.local.set({ [LOCAL_KEY]: records });
}

async function loadLocal(){
  const res = await chrome.storage.local.get([LOCAL_KEY]);
  records = Array.isArray(res[LOCAL_KEY]) ? res[LOCAL_KEY] : [];
  render();
}

function toFsValue(v){
  if(typeof v === "number") return { doubleValue: v };
  if(typeof v === "boolean") return { booleanValue: v };
  return { stringValue: String(v ?? "") };
}

function toFsFields(obj){
  const out = {};
  Object.keys(obj).forEach(k => out[k] = toFsValue(obj[k]));
  return out;
}

function fromFsFields(fields){
  const obj = {};
  Object.keys(fields || {}).forEach(k => {
    const v = fields[k];
    if("stringValue" in v) obj[k] = v.stringValue;
    else if("integerValue" in v) obj[k] = Number(v.integerValue);
    else if("doubleValue" in v) obj[k] = Number(v.doubleValue);
    else if("booleanValue" in v) obj[k] = Boolean(v.booleanValue);
    else obj[k] = "";
  });
  return obj;
}

function docIdFromName(name){
  return String(name || "").split("/").pop();
}

async function loadAuth(){
  const { suiteAuth } = await chrome.storage.local.get("suiteAuth");
  authState = suiteAuth ? { email: suiteAuth.email || "", idToken: suiteAuth.idToken, refreshToken: suiteAuth.refreshToken, suite: true } : null;
}
async function refreshToken(){ await AMMO_FS.auth(true); await loadAuth(); }
async function apiFetch(url, options = {}){ return AMMO_FS.request(url, options); }

async function fetchFirebaseRecords(){
  const data = await apiFetch(`${BASE}?pageSize=1000&orderBy=updatedAt desc`);
  const arr = (data.documents || [])
    .map(doc => ({ id: docIdFromName(doc.name), ...fromFsFields(doc.fields) }))
    .filter(r => !r.deleted);
  records = arr;
  await saveLocal();
  render();
  setSyncInfo("Son yenilənmə: " + nowText());
  setBadge(true, "Firebase: aktiv");
  backfillNumbers().catch(console.warn);
}

async function pushFirebase(row){
  if(!authState?.idToken) return;
  await apiFetch(`${BASE}/${encodeURIComponent(row.id)}`, {
    method:"PATCH",
    body: JSON.stringify({ fields: toFsFields(row) })
  });
  AMMO_REV.bump("beyannameUcotu");
}

async function deleteFirebase(id){
  if(!authState?.idToken) return;
  // V31: yumşaq silmə — köçürmə qeydi geri qaytarmasın
  await apiFetch(`${BASE}/${encodeURIComponent(id)}?updateMask.fieldPaths=deleted&updateMask.fieldPaths=updatedAt`, { method:"PATCH", body: JSON.stringify({ fields: { deleted:{booleanValue:true}, updatedAt:{doubleValue:Date.now()} } }) });
  AMMO_REV.bump("beyannameUcotu");
}

function filters(){
  const f = {};
  document.querySelectorAll("[data-filter]").forEach(i => f[i.dataset.filter] = normalizeText(i.value));
  return f;
}

function match(r,f){
  return Object.keys(f).every(k => {
    if(!f[k]) return true;
    let v = "";
    if(k === "tarixGelen" || k === "tarixCavab") v = formatDate(r[k]);
    else if(k === "gecikme") v = delayInfo(r).n;
    else v = r[k];
    return normalizeText(v).includes(f[k]);
  });
}

function statusHtml(v){
  if(v === "CAVABLANDIRILIB") return `<span class="status green">CAVABLANDIRILIB</span>`;
  if(v === "BAXIŞ") return `<span class="status blue">BAXIŞ</span>`;
  return `<span class="status red">CAVABLANDIRILMADI</span>`;
}

function render(){
  const f = filters();
  const arr = records.filter(r => !r.deleted && match(r,f));
  if($("count")) $("count").textContent = "Cəmi " + arr.length + " qeyd";
  if(!$("tbody")) return;
  $("tbody").innerHTML = arr.map(r => `
    <tr>
      <td>${escapeHtml(r.teskilat)}</td>
      <td>${escapeHtml(r.voen)}</td>
      <td>${escapeHtml(r.nomre)}</td>
      <td>${escapeHtml(r.nov)}</td>
      <td>${escapeHtml(formatDate(r.tarixGelen))}</td>
      <td>${escapeHtml(formatDate(r.tarixCavab))}</td>
      <td>${statusHtml(r.teyinat)}</td>
      <td>${escapeHtml(r.qeyd)}</td>
      <td>${delayHtml(r)}</td>
      <td>${fileHtml(r)}</td>
      <td>
        <button class="action edit" data-edit="${escapeHtml(r.id)}">✎</button>
        <button class="action del" data-del="${escapeHtml(r.id)}">🗑</button>
      </td>
    </tr>
  `).join("");
  document.querySelectorAll("[data-edit]").forEach(b => b.onclick = () => editRecord(b.dataset.edit));
  document.querySelectorAll("[data-del]").forEach(b => b.onclick = () => deleteRecord(b.dataset.del));
  document.querySelectorAll("[data-file]").forEach(b => b.onclick = () => downloadLetterFile(b.dataset.file));
  document.querySelectorAll("[data-fetch]").forEach(b => b.onclick = () => window.AMMO_LETTER_FILES?.fetchOne(b.dataset.fetch));
}

function editRecord(id){
  const r = records.find(x => x.id === id);
  if(!r) return;
  editId = id;
  fields.forEach(f => { if($(f)) $(f).value = r[f] || ""; });
  if($("gecikme")) $("gecikme").value = daysBetween(r.tarixGelen, r.tarixCavab);
  $("addBtn")?.classList.add("hidden");
  $("saveEditBtn")?.classList.remove("hidden");
}

async function deleteRecord(id){
  if(!confirm("Bu məlumat silinsin?")) return;
  const idx = records.findIndex(x => x.id === id);
  if(idx >= 0) records.splice(idx, 1);
  await saveLocal();
  render();
  try{
    await deleteFirebase(id);
    await fetchFirebaseRecords();
  }catch(e){
    console.error(e);
    setSyncInfo("Firebase silmə xətası: " + e.message);
  }
}

async function addOrUpdate(){
  const prevRec = editId ? records.find(x => x.id === editId) : null;
  const row = { ...(prevRec || {}), ...getForm() }; // V31.0.3: etaxId, ADOC və s. düzəlişdə itməsin
  if(!row.teskilat && !row.voen && !row.nomre){
    alert("Ən azı bir əsas məlumat yaz.");
    return;
  }
  const idx = records.findIndex(x => x.id === row.id);
  if(idx >= 0) records[idx] = row;
  else records.unshift(row);

  await saveLocal();
  render();
  clearForm();
  setSyncInfo("Məlumat əlavə edildi. Firebase-ə yazılır...");

  try{
    await pushFirebase(row);
    await fetchFirebaseRecords();
  }catch(e){
    console.error(e);
    setBadge(false, "Firebase: xəta");
    setSyncInfo("Məlumat lokal əlavə edildi, Firebase xətası: " + e.message);
    alert("Məlumat cədvələ əlavə edildi, amma Firebase-ə yazılmadı:\n" + e.message);
  }
}

async function startApp(){
  $("loginPanel")?.classList.add("hidden");
  $("mainPanel")?.classList.remove("hidden");
  $("logoutBtn")?.classList.remove("hidden");
  setBadge(true, "Firebase: aktiv");
  await loadLocal();
  try{
    const mig = await AMMO_FS.migrate(COLLECTION).catch(e => ({error:e.message}));
    if(mig && (mig.added || mig.updated)) setSyncInfo(`Köhnə serverdən köçürüldü: ${mig.added||0} yeni, ${mig.updated||0} yenilənmiş`);
    await fetchFirebaseRecords();
  }catch(e){
    console.error(e);
    setBadge(false, "Firebase: xəta");
    setSyncInfo("Lokal məlumat göstərilir. Firebase oxuma xətası: " + e.message);
  }
  // V31.0.2: hər 4 saniyədə tam oxuma əvəzinə dəyişiklik nişanı (Firebase limitinə qənaət)
  if(!pollTimer) pollTimer = AMMO_REV.watch("beyannameUcotu", {every:30000}, () => { if(syncBusy) return; syncBusy = true; return fetchFirebaseRecords().catch(console.error).finally(()=>syncBusy=false); });
}

function showLogin(){
  $("loginPanel")?.classList.remove("hidden");
  $("mainPanel")?.classList.add("hidden");
  $("logoutBtn")?.classList.add("hidden");
  setBadge(false, "Firebase: qoşulmayıb");
}

function exportCsv(){
  const header = ["Təşkilat","VÖEN","Nömrə","Məktubun növü","Tarix gələn","Tarix cavablandırılan","Təyinat","Qeyd","Gecikmə günü","Sənəd"];
  const rows = records.filter(r=>!r.deleted).map(r => [
    r.teskilat||"", r.voen||"", r.nomre||"", r.nov||"", formatDate(r.tarixGelen),
    formatDate(r.tarixCavab), r.teyinat||"", r.qeyd||"", delayInfo(r).n, r.adocName||""
  ]);
  const csv = [header, ...rows].map(row => row.map(v => `"${String(v).replace(/"/g,'""')}"`).join(";")).join("\n");
  const blob = new Blob(["\ufeff" + csv], {type:"text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "beyanname-ucotu.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function bindEvents(){
  $("addBtn")?.addEventListener("click", addOrUpdate);
  $("saveEditBtn")?.addEventListener("click", addOrUpdate);
  $("refreshBtn")?.addEventListener("click", () => fetchFirebaseRecords().catch(e => alert(e.message)));
  $("printPdf")?.addEventListener("click", () => window.print());
  $("exportExcel")?.addEventListener("click", exportCsv);

  ["tarixGelen","tarixCavab"].forEach(id => {
    $(id)?.addEventListener("input", () => {
      if($("gecikme")) $("gecikme").value = daysBetween($("tarixGelen").value, $("tarixCavab").value);
    });
  });

  document.querySelectorAll("[data-filter]").forEach(i => i.addEventListener("input", render));
}

(async function init(){
  bindEvents();
  $("logoutBtn")?.remove(); // çıxış yalnız AMMO SUITE-dən
  $("loginPanel")?.remove(); // V31: ayrıca server girişi yoxdur — AMMO SUITE hesabı istifadə olunur
  await loadAuth();
  await startApp();
})();
