/* Borc Xatırladıcı — "📲 WhatsApp" paneli: ayarlar, şablon, bu günün siyahısı, jurnal, əl ilə göndərmə.
 * dashboard.js-in qlobal dəyişənlərindən istifadə edir: records, settings, persist, renderAll, toast, esc, $ */
(function () {
  'use strict';
  const W = window.BorcWA;
  let waLog = {}, waState = {}, myDevice = '', busy = false, inited = false;

  const wa = () => (settings.wa = { ...W.DEFAULTS, ...(settings.wa || {}) });
  async function saveWa(msg) {
    await chrome.storage.local.set({ borcSettings: settings });
    try { await chrome.runtime.sendMessage({ type: 'BORC_WA_RESCHEDULE' }); } catch (e) { /* */ }
    if (msg) toast(msg);
  }
  const fmtAt = (iso) => { if (!iso) return ''; const d = new Date(iso); return `${W.fmtDate(W.ymd(d))} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const isToday = (iso) => iso && W.ymd(new Date(iso)) === W.ymd();

  async function loadAux() {
    const d = await chrome.storage.local.get(['borcWaLog', 'borcWaState', 'ammoDeviceId']);
    waLog = d.borcWaLog || {}; waState = d.borcWaState || {};
    myDevice = d.ammoDeviceId || '';
    if (!myDevice) { myDevice = crypto.randomUUID(); await chrome.storage.local.set({ ammoDeviceId: myDevice }); }
  }

  // ---------------------------------------------------------------- cədvəl sətrində nişan
  window.waRowBadge = function (r) {
    if (r.type !== 'receivable') return '';
    const entries = Object.values(waLog).filter((x) => x.recordId === r.id).sort((a, b) => String(b.at).localeCompare(String(a.at)));
    const last = entries[0];
    const ev = W.dueEvents([r], wa(), W.ymd()).find(Boolean);
    if (ev && !(waLog[ev.key] && waLog[ev.key].status === 'sent')) {
      if (r.waAuto === false) return '';
      if (!ev.phone) return '<br><span class="wa-badge bad">📲 Bu gün göndərilməli idi — WhatsApp nömrəsi yoxdur</span>';
      if (waLog[ev.key] && waLog[ev.key].status === 'failed') return `<br><span class="wa-badge bad">📲 Göndərilmədi: ${esc(waLog[ev.key].error)}</span>`;
      return wa().enabled ? `<br><span class="wa-badge wait">📲 Bu gün ${esc(wa().time)}-da WhatsApp-a göndəriləcək</span>` : '';
    }
    if (last && last.status === 'sent') return `<br><span class="wa-badge ok">📲 WhatsApp göndərildi: ${fmtAt(last.at)}</span>`;
    if (r.waAuto === false) return '<br><span class="wa-badge off">📲 Avtomatik mesaj söndürülüb</span>';
    return '';
  };

  // ---------------------------------------------------------------- əl ilə göndərmə
  async function sendItems(items, opts = {}) {
    if (busy) { toast('Göndəriş artıq gedir — bir az gözləyin'); return null; }
    busy = true; setBusyUI(true);
    toast(opts.test ? 'Test mesajı göndərilir… WhatsApp Web açılır' : `Göndərilir… (${items.length} mesaj) — WhatsApp Web açılır`);
    try {
      const res = await chrome.runtime.sendMessage({ type: 'BORC_WA_SEND', items, test: !!opts.test });
      if (!res) toast('Arxa fon xidməti cavab vermədi — AMMO-nu yeniləyin (chrome://extensions → ↻)');
      else if (res.busy) toast('Hazırda başqa göndəriş gedir — bir neçə dəqiqə sonra yenidən cəhd edin');
      else if (res.error) toast('Göndərilmədi: ' + res.error);
      else if (res.sent && !res.failed) toast(`✓ ${res.sent} mesaj WhatsApp-a göndərildi`);
      else toast(`Göndərilmədi: ${((res.results || []).find((x) => x.status !== 'sent') || {}).error || 'naməlum xəta'}`);
      return res;
    } catch (e) { toast('Xəta: ' + e.message); return null; }
    finally { busy = false; setBusyUI(false); await loadAux(); render(); if (typeof renderTables === 'function') renderTables(); }
  }
  window.waSendRecord = async function (id) {
    const r = records.find((x) => x.id === id); if (!r) return;
    const ev = W.manualEvent(r, wa());
    if (!ev) { toast('Bu qeyd üzrə ödənilməmiş borc yoxdur'); return; }
    if (!ev.phone) { toast('Qeyddə WhatsApp nömrəsi yoxdur və ya səhvdir — redaktə edib nömrə yazın'); editRecord(id); return; }
    if (!confirm(`${r.ownerName || r.person} (${W.prettyPhone(ev.phone)}) nömrəsinə bu mesaj İNDİ göndərilsin?\n\n${ev.text}`)) return;
    await sendItems([ev]);
  };

  // ---------------------------------------------------------------- panel
  function setBusyUI(on) { ['waRunNow', 'waTestSend'].forEach((id) => { const b = $(id); if (b) { b.disabled = on; } }); const b = $('waRunNow'); if (b) b.textContent = on ? 'Göndərilir…' : 'İndi yoxla və göndər'; }

  function todayItems() {
    return W.dueEvents(records, wa(), W.ymd()).map((e) => ({ e, L: waLog[e.key] }));
  }

  function render() {
    if (!$('whatsapp')) return;
    const s = wa();
    const items = todayItems();
    const pending = items.filter((x) => !(x.L && x.L.status === 'sent'));
    const nav = $('waNavCount'); if (nav) { nav.textContent = pending.length; nav.classList.toggle('hot', pending.length > 0); }
    document.querySelectorAll('.wa-time-txt').forEach((x) => { x.textContent = s.time; });
    if (!inited) return;

    // hero
    const isSender = s.deviceId && s.deviceId === myDevice;
    const now = new Date(), at = W.sendTimeToday(s.time, now);
    const nextTxt = now < at ? `bu gün ${s.time}` : `sabah ${s.time}`;
    $('waEnabled').checked = !!s.enabled; $('waEnabledTxt').textContent = s.enabled ? 'Aktiv' : 'Söndürülüb';
    $('waHero').classList.toggle('off', !s.enabled);
    const last = waState.lastRun ? ` Son göndəriş: ${fmtAt(waState.lastRun)}${waState.lastResult ? ` (${waState.lastResult.sent} göndərildi${waState.lastResult.failed ? `, ${waState.lastResult.failed} alınmadı` : ''})` : ''}.` : '';
    $('waHeroText').innerHTML = !s.enabled ? 'Avtomatik göndəriş söndürülüb. Yandırmaq üçün sağdakı açarı basın.'
      : `Hər gün <b>${esc(s.time)}</b>-da ödəniş vaxtı çatan alacaqlara mesaj gedir. Növbəti yoxlama: <b>${nextTxt}</b>. Bu gün: <b>${items.length}</b> mesaj${pending.length ? `, <b>${pending.length}</b> gözləyir` : ''}.${last}`;
    $('waDevice').innerHTML = isSender
      ? '<span class="wa-dev ok">✓ Mesajları <b>bu kompüter</b> göndərir. Chrome bu kompüterdə açıq olmalı və WhatsApp Web-ə daxil olunmalıdır.</span>'
      : `<span class="wa-dev warn">⚠ ${s.deviceId ? 'Mesajları <b>başqa kompüter</b> göndərir.' : 'Göndərən kompüter seçilməyib.'} Eyni mesajın iki dəfə getməməsi üçün yalnız bir kompüter göndərir.</span><button class="secondary" id="waMakeSender">Bu kompüterdən göndər</button>`;
    const mk = $('waMakeSender'); if (mk) mk.onclick = async () => { s.deviceId = myDevice; await saveWa('Bu kompüter göndərici təyin edildi'); render(); };

    // bu gün
    $('waTodaySub').textContent = s.catchupDays > 0 ? `Ödəniş vaxtı bu gün (və ya buraxılmış son ${s.catchupDays} gündə) çatan alacaqlar` : 'Ödəniş vaxtı bu gün çatan alacaqlar';
    $('waTodayList').innerHTML = items.length ? items.map(({ e, L }) => {
      const st = !e.phone ? '<span class="wa-st bad">Nömrə yoxdur</span>'
        : L && L.status === 'sent' ? `<span class="wa-st ok">✓ Göndərildi ${fmtAt(L.at).slice(-5)}</span>`
          : L && L.status === 'failed' ? `<span class="wa-st bad" title="${esc(L.error)}">✗ ${esc(L.error)}</span>`
            : `<span class="wa-st wait">⏰ ${esc(s.time)}-da</span>`;
      const btn = !e.phone ? `<button class="secondary sm" data-wa-edit="${e.recordId}">Nömrə yaz</button>`
        : L && L.status === 'sent' ? `<button class="text-btn sm" data-wa-send="${e.key}">Yenidən göndər</button>`
          : `<button class="secondary sm" data-wa-send="${e.key}">İndi göndər</button>`;
      return `<div class="wa-item"><div><b>${esc(e.ownerName || e.person)}</b><small>${esc(e.person)} · ${esc(e.period)} · ${e.phone ? esc(W.prettyPhone(e.phone)) : '—'}</small></div><strong>${esc(W.fmtMoney(e.total, e.currency))}</strong>${st}${btn}</div>`;
    }).join('') : '<div class="empty">Bu gün ödəniş vaxtı çatan alacaq yoxdur.</div>';
    $('waTodayList').querySelectorAll('[data-wa-send]').forEach((b) => b.onclick = () => {
      const it = items.find((x) => x.e.key === b.dataset.waSend); if (!it) return;
      if (!confirm(`${it.e.ownerName || it.e.person} nömrəsinə mesaj indi göndərilsin?\n\n${it.e.text}`)) return;
      sendItems([it.e]);
    });
    $('waTodayList').querySelectorAll('[data-wa-edit]').forEach((b) => b.onclick = () => editRecord(b.dataset.waEdit));

    // jurnal
    const logs = Object.values(waLog).sort((a, b) => String(b.at).localeCompare(String(a.at))).slice(0, 40);
    $('waLogBody').innerHTML = logs.length ? logs.map((x) => `<tr><td>${fmtAt(x.at)}</td><td><b>${esc(x.ownerName || x.person)}</b><br><small>${esc(x.person)}</small></td><td>${esc(W.prettyPhone(x.phone) || x.phone || '—')}</td><td>${esc(x.period || '')}</td><td>${esc(W.fmtMoney(x.total, x.currency))}</td><td>${x.status === 'sent' ? '<span class="wa-st ok">✓ Göndərildi</span>' : `<span class="wa-st bad">✗ ${esc(x.error || 'xəta')}</span>`}${x.manual ? ' <small class="muted">(əl ilə)</small>' : ''}</td><td>${x.text ? `<button class="text-btn sm" data-wa-show="${esc(x.key)}">Mətn</button>` : ''}</td></tr>`).join('')
      : '<tr><td colspan="7" class="empty">Hələ mesaj göndərilməyib.</td></tr>';
    $('waLogBody').querySelectorAll('[data-wa-show]').forEach((b) => b.onclick = () => { const x = waLog[b.dataset.waShow]; if (x) alert(x.text); });

    renderPreview();
  }

  function previewRecords() { return records.filter((r) => r.type === 'receivable'); }
  function renderPreview() {
    const sel = $('waPreviewRecord'); const list = previewRecords();
    const cur = sel.value;
    sel.innerHTML = list.length ? list.map((r) => `<option value="${r.id}">${esc(r.person)}</option>`).join('') : '<option value="">Nümunə</option>';
    if (cur && list.some((r) => r.id === cur)) sel.value = cur;
    const r = list.find((x) => x.id === sel.value);
    const s = wa();
    let ev = r && W.manualEvent(r, s);
    if (!ev) {
      const demo = { id: 'demo', type: 'receivable', person: r ? r.person : 'Nümunə MMC', ownerName: r ? r.ownerName : 'Elvin Məmmədov', phone: r ? r.phone : '+994501234567', cardNumber: r ? r.cardNumber : '', paymentMode: 'one_time', currency: 'AZN', installments: [{ id: 'x', dueDate: W.ymd(), amount: r ? (r.monthlyAmount || r.baseAmount || 100) : 250, status: 'open' }] };
      ev = W.manualEvent(demo, s);
    }
    $('waPrevName').textContent = ev.ownerName || ev.person;
    $('waPrevNum').textContent = ev.phone ? W.prettyPhone(ev.phone) : 'nömrə yoxdur';
    $('waPreview').innerHTML = waFormat(ev.text) + `<span class="wa-time">${s.time} ✓✓</span>`;
    const warn = !((r && r.cardNumber) || s.card);
    $('waCard').classList.toggle('need', warn);
  }
  // WhatsApp formatı: *qalın* _italik_
  function waFormat(t) { return esc(t).replace(/\*([^*\n]+)\*/g, '<b>$1</b>').replace(/_([^_\n]+)_/g, '<i>$1</i>').replace(/\n/g, '<br>'); }

  function initPanel() {
    $('waCard').value = W.prettyCard(wa().card); $('waCardHolder').value = wa().cardHolder; $('waTime').value = wa().time;
    $('waCatchup').value = String(wa().catchupDays); $('waTemplate').value = wa().template;
    $('waChips').innerHTML = W.PLACEHOLDERS.map(([k, d]) => `<button type="button" class="wa-chip" data-ph="${k}" title="${esc(d)}">${k}</button>`).join('');
    $('waChips').querySelectorAll('[data-ph]').forEach((b) => b.onclick = () => {
      const ta = $('waTemplate'), a = ta.selectionStart, z = ta.selectionEnd;
      ta.value = ta.value.slice(0, a) + b.dataset.ph + ta.value.slice(z); ta.focus(); ta.selectionStart = ta.selectionEnd = a + b.dataset.ph.length;
      ta.dispatchEvent(new Event('input'));
    });
    let tplT = null;
    $('waTemplate').oninput = () => { wa().template = $('waTemplate').value; renderPreview(); clearTimeout(tplT); tplT = setTimeout(() => saveWa(), 600); };
    $('waTplReset').onclick = async () => { if (!confirm('Şablon standart mətnə qaytarılsın?')) return; wa().template = W.DEFAULT_TEMPLATE; $('waTemplate').value = wa().template; await saveWa('Standart şablon bərpa olundu'); renderPreview(); };
    $('waPreviewRecord').onchange = renderPreview;
    $('waCard').onchange = async () => { wa().card = W.prettyCard($('waCard').value); $('waCard').value = wa().card; await saveWa('Kart nömrəsi yadda saxlanıldı'); render(); renderTables(); };
    $('waCardHolder').onchange = async () => { wa().cardHolder = $('waCardHolder').value.trim(); await saveWa('Kart sahibi yadda saxlanıldı'); renderPreview(); };
    $('waTime').onchange = async () => { if (!/^\d{2}:\d{2}$/.test($('waTime').value)) return; wa().time = $('waTime').value; await saveWa(`Göndərmə saatı: hər gün ${wa().time}`); render(); renderTables(); };
    $('waCatchup').onchange = async () => { wa().catchupDays = Number($('waCatchup').value); await saveWa('Yadda saxlanıldı'); render(); };
    $('waEnabled').onchange = async () => {
      wa().enabled = $('waEnabled').checked;
      if (wa().enabled && !wa().deviceId) wa().deviceId = myDevice;
      await saveWa(wa().enabled ? 'Avtomatik WhatsApp mesajları aktivdir' : 'Avtomatik mesajlar söndürüldü'); render(); renderTables();
    };
    $('waApplyCardAll').onclick = async () => {
      const card = W.prettyCard($('waCard').value);
      if (!W.cardDigits(card)) { toast('Əvvəlcə kart nömrəsini yazın'); $('waCard').focus(); return; }
      const rec = records.filter((r) => r.type === 'receivable');
      if (!confirm(`${rec.length} alacaq qeydinin hamısında kart nömrəsi "${card}" ilə əvəz edilsin?`)) return;
      wa().card = card; rec.forEach((r) => { r.cardNumber = card; });
      await persist(); await saveWa(`Kart ${rec.length} qeyddə yeniləndi`); renderAll();
    };
    $('waOpenWeb').onclick = () => window.open('https://web.whatsapp.com/', '_blank');
    $('waRunNow').onclick = async () => {
      const items = todayItems().filter((x) => x.e.phone && !(x.L && x.L.status === 'sent')).map((x) => x.e);
      if (!items.length) { toast('Göndəriləsi mesaj yoxdur — bu günün bütün mesajları artıq göndərilib'); return; }
      if (!confirm(`${items.length} mesaj indi göndərilsin?\n\n${items.map((e) => `• ${e.ownerName || e.person} — ${W.fmtMoney(e.total, e.currency)}`).join('\n')}`)) return;
      await sendItems(items);
    };
    $('waTestSend').onclick = async () => {
      const ph = W.normalizePhone($('waTestPhone').value);
      if (!ph) { toast('Test üçün düzgün nömrə yazın: +994 50 123 45 67'); return; }
      const text = 'AMMO — test mesajı ✅\n\nBelə görünəcək:\n\n' + $('waPreview').innerText.replace(/\s*\d{1,2}:\d{2} ✓✓$/, '');
      await sendItems([{ key: 'test:' + Date.now(), phone: ph, text, person: 'Test', period: 'test', total: 0 }], { test: true });
    };
    inited = true;
  }

  window.renderWaPanel = render;
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.borcWaLog || ch.borcWaState) { loadAux().then(() => { render(); if (typeof renderTables === 'function') renderTables(); }); }
  });

  (async () => {
    await loadAux();
    // dashboard init() settings-i oxuyana qədər gözlə
    for (let i = 0; i < 50 && !document.querySelector('#todayText')?.textContent; i++) await new Promise((r) => setTimeout(r, 100));
    wa();
    initPanel(); render();
    if (typeof renderTables === 'function') renderTables();
  })();
})();
