/* Borc Xatırladıcı — WhatsApp avtomatik göndərmə (arxa fon, AMMO SUITE service worker daxilində).
 *
 * Necə işləyir:
 *  - Hər gün təyin olunmuş saatda (default 10:10) alacaqlar yoxlanılır.
 *  - Ödəniş vaxtı bu gün çatan (və ya kompüter sönülü olduğu üçün son N gündə buraxılmış) hər alacaq üçün
 *    sahibkarın WhatsApp nömrəsinə mesaj WhatsApp Web vasitəsilə avtomatik göndərilir.
 *  - Hər mesaj bir dəfə göndərilir (jurnal: borcWaLog). Göndərişi YALNIZ seçilmiş kompüter edir.
 *  - Şərt: Chrome açıq olmalı və bu kompüterdə WhatsApp Web-ə bir dəfə QR ilə daxil olunmalıdır.
 */
// wa-common.js əvvəlcədən background.js-də importScripts ilə yüklənir.

(function () {
  'use strict';
  const W = self.BorcWA;
  const WA_URL = 'https://web.whatsapp.com';
  const ALARM_EXACT = 'borc-wa-exact', ALARM_TICK = 'borc-wa-tick';
  const ICON = 'modules/borc-xatirlatici/icons/icon128.png';
  const MAX_TRIES = 5, RETRY_MIN = 25, LOG_KEEP_DAYS = 120;
  let running = false;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function keepAliveSleep(ms) { const end = Date.now() + ms; while (Date.now() < end) { await sleep(Math.min(15000, end - Date.now())); try { await chrome.runtime.getPlatformInfo(); } catch (e) { /* */ } } }

  async function getState() {
    const d = await chrome.storage.local.get(['records', 'borcSettings', 'borcWaLog', 'ammoDeviceId', 'borcWaState']);
    const wa = { ...W.DEFAULTS, ...((d.borcSettings || {}).wa || {}) };
    return { records: d.records || [], settings: d.borcSettings || {}, wa, log: d.borcWaLog || {}, deviceId: d.ammoDeviceId || '', state: d.borcWaState || {} };
  }
  async function setState(patch) { const { borcWaState = {} } = await chrome.storage.local.get('borcWaState'); await chrome.storage.local.set({ borcWaState: { ...borcWaState, ...patch } }); }
  async function writeLog(entries) {
    const { borcWaLog = {} } = await chrome.storage.local.get('borcWaLog');
    const cutoff = Date.now() - LOG_KEEP_DAYS * 86400000;
    for (const [k, v] of Object.entries(borcWaLog)) if (new Date(v.at || 0).getTime() < cutoff) delete borcWaLog[k];
    Object.assign(borcWaLog, entries);
    await chrome.storage.local.set({ borcWaLog });
  }
  function notify(title, message, prio = 1) {
    try { chrome.notifications.create('borc-wa-' + Date.now(), { type: 'basic', iconUrl: ICON, title, message, priority: prio }); } catch (e) { /* */ }
  }

  // ---------------------------------------------------------------- planlama
  async function schedule() {
    const { wa } = await getState();
    const now = new Date();
    let at = W.sendTimeToday(wa.time, now);
    if (at <= now) at = new Date(at.getTime() + 86400000);
    await chrome.alarms.create(ALARM_EXACT, { when: at.getTime() });
    await chrome.alarms.create(ALARM_TICK, { periodInMinutes: 5 });
  }
  chrome.runtime.onInstalled.addListener(() => { schedule(); setTimeout(() => run({ reason: 'install' }), 20000); });
  chrome.runtime.onStartup.addListener(() => { schedule(); setTimeout(() => run({ reason: 'startup' }), 45000); });
  chrome.alarms.onAlarm.addListener((a) => {
    if (a.name === ALARM_EXACT) { schedule(); run({ reason: 'time' }); }
    else if (a.name === ALARM_TICK) run({ reason: 'tick' });
  });

  // ---------------------------------------------------------------- əsas yoxlama
  /** opts.force: saatı gözləmədən indi yoxla (panel düyməsi). */
  async function run(opts = {}) {
    if (running) return { ok: false, busy: true };
    const st = await getState();
    const { wa, log } = st;
    if (!wa.enabled) return { ok: true, skipped: 'disabled' };
    if (!wa.deviceId || wa.deviceId !== st.deviceId) return { ok: true, skipped: 'device' };
    const now = new Date();
    if (!opts.force && now < W.sendTimeToday(wa.time, now)) return { ok: true, skipped: 'time' };
    // eyni anda iki proses (məs. SW yenidən başladıqda) — saxlanılan kilid
    if (st.state.lockAt && Date.now() - st.state.lockAt < 12 * 60000) return { ok: false, busy: true };

    const today = W.ymd(now);
    const events = W.dueEvents(st.records, wa, today);
    const queue = [], pre = {};
    for (const e of events) {
      const L = log[e.key];
      if (L && L.status === 'sent') continue;
      if (!e.phone) { if (!L) pre[e.key] = entry(e, 'failed', 'nophone', 'WhatsApp nömrəsi yazılmayıb və ya səhvdir'); continue; }
      if (L && (L.code === 'invalid' || (L.tries || 0) >= MAX_TRIES)) continue;
      if (L && L.status === 'failed' && !opts.force && Date.now() - new Date(L.at).getTime() < RETRY_MIN * 60000) continue;
      queue.push({ ...e, tries: (L && L.tries) || 0 });
    }
    if (Object.keys(pre).length) {
      await writeLog(pre);
      notify('WhatsApp mesajı göndərilmədi', `${Object.values(pre).map((x) => x.person).join(', ')} — WhatsApp nömrəsi yoxdur. Borc Xatırladıcıda qeydə nömrə əlavə edin.`, 2);
    }
    if (!queue.length) { await setState({ lastCheck: new Date().toISOString() }); return { ok: true, sent: 0 }; }
    return sendBatch(queue, { reason: opts.reason || 'auto' });
  }

  function entry(e, status, code, error, tries) {
    return { key: e.key, recordId: e.recordId, person: e.person, ownerName: e.ownerName, phone: e.phone || e.rawPhone || '', period: e.period, due: e.due, amount: e.amount, total: e.total, currency: e.currency, status, code: code || '', error: error || '', tries: tries || 0, at: new Date().toISOString(), text: e.text, manual: !!e.manual };
  }

  // ---------------------------------------------------------------- WhatsApp Web ilə göndərmə
  async function waitComplete(tabId, ms = 60000) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      try { const t = await chrome.tabs.get(tabId); if (t.status === 'complete' && /web\.whatsapp\.com/.test(t.url || t.pendingUrl || '')) return true; } catch (e) { return false; }
      await sleep(700);
    }
    return false;
  }

  async function sendBatch(items, meta = {}) {
    running = true;
    await setState({ lockAt: Date.now(), lastRunStart: new Date().toISOString() });
    let tabId = null, created = false;
    const results = [];
    try {
      const existing = await chrome.tabs.query({ url: WA_URL + '/*' });
      if (existing.length) tabId = existing[0].id;
      else { const t = await chrome.tabs.create({ url: WA_URL + '/', active: false, pinned: true }); tabId = t.id; created = true; await waitComplete(tabId, 90000); }

      for (let i = 0; i < items.length; i++) {
        const e = items[i];
        const url = `${WA_URL}/send?phone=${e.phone}&text=${encodeURIComponent(e.text)}`;
        let res;
        try {
          await chrome.tabs.update(tabId, { url });
          await sleep(1500);
          await waitComplete(tabId, 90000);
          const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: injectedSend, args: [100000] });
          res = (r && r.result) || { ok: false, code: 'noresult' };
        } catch (err) { res = { ok: false, code: 'error', detail: String(err && err.message || err) }; }
        const tries = (e.tries || 0) + 1;
        const L = res.ok ? entry(e, 'sent', '', '', tries) : entry(e, 'failed', res.code, describe(res), tries);
        results.push(L);
        if (!e.test) await writeLog({ [e.key]: L });
        if (!res.ok && res.code === 'login') { // qalanları da eyni səbəbdən göndərilməyəcək
          for (const rest of items.slice(i + 1)) { const R = entry(rest, 'failed', 'login', describe(res), (rest.tries || 0) + 1); results.push(R); if (!rest.test) await writeLog({ [rest.key]: R }); }
          break;
        }
        if (i < items.length - 1) await keepAliveSleep(7000 + Math.floor(Math.random() * 6000)); // spam sayılmasın
      }
    } catch (err) {
      for (const e of items.filter((x) => !results.some((r) => r.key === x.key))) { const R = entry(e, 'failed', 'error', String(err && err.message || err), (e.tries || 0) + 1); results.push(R); if (!e.test) await writeLog({ [e.key]: R }); }
    } finally {
      if (created && tabId) { await keepAliveSleep(4000); try { await chrome.tabs.remove(tabId); } catch (e) { /* */ } }
      running = false;
      await setState({ lockAt: 0, lastRun: new Date().toISOString(), lastResult: { sent: results.filter((r) => r.status === 'sent').length, failed: results.filter((r) => r.status !== 'sent').length } });
    }
    const ok = results.filter((r) => r.status === 'sent'), bad = results.filter((r) => r.status !== 'sent');
    if (ok.length) notify(`WhatsApp: ${ok.length} mesaj göndərildi`, ok.map((r) => `${r.person} — ${W.fmtMoney(r.total, r.currency)}`).join('\n'));
    if (bad.length) {
      const login = bad.some((r) => r.code === 'login');
      notify(login ? 'WhatsApp Web-ə daxil olun' : `WhatsApp: ${bad.length} mesaj göndərilmədi`,
        login ? 'Mesajları göndərmək üçün bu kompüterdə web.whatsapp.com açıb QR kodu telefonla skan edin. Proqram 25 dəqiqədən sonra yenidən cəhd edəcək.'
          : bad.map((r) => `${r.person}: ${r.error}`).join('\n'), 2);
    }
    return { ok: !bad.length, sent: ok.length, failed: bad.length, results };
  }

  function describe(res) {
    return ({
      login: 'WhatsApp Web-ə daxil olunmayıb (QR kod skan edilməlidir)',
      invalid: 'Bu nömrə WhatsApp-da qeydiyyatda deyil və ya səhvdir',
      timeout: 'WhatsApp Web vaxtında açılmadı (internet yavaş ola bilər)',
      nosend: 'Göndər düyməsi işləmədi',
      noresult: 'WhatsApp səhifəsi cavab vermədi',
      error: 'Xəta: ' + (res.detail || '')
    })[res.code] || ('Xəta: ' + (res.detail || res.code || ''));
  }

  /** WhatsApp Web səhifəsinin içində işləyir: mətn yazılmış söhbətdə "Göndər" düyməsini basır. */
  async function injectedSend(timeoutMs) {
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const txt = (el) => (el && (el.innerText || el.textContent) || '').trim();
    const t0 = Date.now(); let qrSeen = 0, boxSince = 0;
    const SEND_SEL = ['[data-icon="send"]', '[data-icon="wds-ic-send-filled"]', '[data-icon="send-light"]', 'button[aria-label="Send"]', 'button[aria-label="Göndər"]', 'button[aria-label="Отправить"]', 'button[aria-label="Gönder"]'];
    while (Date.now() - t0 < timeoutMs) {
      // "WhatsApp başqa pəncərədə açıqdır" → "Burada istifadə et"
      for (const b of document.querySelectorAll('button, div[role="button"]')) {
        const t = txt(b).toLowerCase();
        if (t === 'use here' || t === 'burada istifadə edin' || t === 'burada istifadə et' || t === 'использовать здесь' || t === 'burada kullan') { b.click(); await sleep(4000); }
      }
      // yanlış nömrə pəncərəsi
      const dlg = document.querySelector('div[role="dialog"], [data-animate-modal-popup="true"]');
      if (dlg && /invalid|not on whatsapp|yanlış|səhv|etibarsız|düzgün deyil|qeydiyyatda deyil|недейств|неверн|geçersiz/i.test(txt(dlg))) return { ok: false, code: 'invalid', detail: txt(dlg).slice(0, 160) };
      // QR (daxil olunmayıb)
      const loggedIn = document.querySelector('#side, #pane-side, [data-testid="chat-list"], #main');
      const qr = document.querySelector('canvas[aria-label*="QR" i], canvas[aria-label*="scan" i], [data-testid="qrcode"], div[data-ref] canvas, [data-ref]');
      if (qr && !loggedIn) { if (++qrSeen > 30) return { ok: false, code: 'login' }; }
      // yazı sahəsi və göndər düyməsi
      const box = document.querySelector('#main footer div[contenteditable="true"], footer div[contenteditable="true"][role="textbox"], #main div[contenteditable="true"][data-tab]');
      if (box && txt(box).length) {
        if (!boxSince) boxSince = Date.now();
        let btn = null;
        for (const s of SEND_SEL) { const el = document.querySelector('#main ' + s) || document.querySelector('footer ' + s); if (el) { btn = el.closest('button, [role="button"]') || el; break; } }
        if (btn || Date.now() - boxSince > 6000) {
          if (btn) btn.click();
          else { box.focus(); box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); }
          for (let i = 0; i < 24 && txt(box).length; i++) await sleep(500);
          if (txt(box).length) {
            box.focus(); box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
            await sleep(2500);
            if (txt(box).length) return { ok: false, code: 'nosend' };
          }
          // mesaj serverə çatana qədər (saat işarəsi yox olana qədər) gözlə
          for (let i = 0; i < 40; i++) { await sleep(500); if (!document.querySelector('#main [data-icon="msg-time"], #main [data-icon="msg-time-filled"]')) break; }
          return { ok: true };
        }
      }
      await sleep(600);
    }
    return { ok: false, code: qrSeen ? 'login' : 'timeout' };
  }

  // ---------------------------------------------------------------- paneldən gələn əmrlər
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('BORC_WA_')) return;
    (async () => {
      try {
        if (msg.type === 'BORC_WA_RESCHEDULE') { await schedule(); return sendResponse({ ok: true }); }
        if (msg.type === 'BORC_WA_RUN') return sendResponse(await run({ force: true, reason: 'manual' }));
        if (msg.type === 'BORC_WA_STATUS') { const st = await getState(); return sendResponse({ ok: true, running, deviceId: st.deviceId, state: st.state }); }
        if (msg.type === 'BORC_WA_SEND') {
          // panel: { items:[{key,phone,text,person,...}], test }
          if (running) return sendResponse({ ok: false, busy: true });
          const items = (msg.items || []).map((x) => ({ ...x, phone: W.normalizePhone(x.phone), manual: true, test: !!msg.test })).filter((x) => x.phone && x.text);
          if (!items.length) return sendResponse({ ok: false, error: 'Nömrə yanlışdır' });
          return sendResponse(await sendBatch(items, { reason: msg.test ? 'test' : 'manual' }));
        }
        sendResponse({ ok: false, error: 'unknown' });
      } catch (e) { running = false; sendResponse({ ok: false, error: String(e && e.message || e) }); }
    })();
    return true;
  });

  schedule();
})();
