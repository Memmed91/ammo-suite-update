/* Borc Xatırladıcı — WhatsApp avtomatik mesaj: ortaq məntiq.
 * Həm panel (dashboard.html), həm də arxa fon (background.js → importScripts) istifadə edir.
 * Burada DOM yoxdur. */
(function (root) {
  'use strict';

  const AZM = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];

  const DEFAULT_TEMPLATE = [
    'Hörmətli {sahibkar},',
    '',
    '"{sirket}" üzrə {ay} ödənişinin vaxtı {son_tarix} tarixində çatıb.',
    '',
    'Ödəniləcək məbləğ: {mebleg}',
    '{evvelki_borc}',
    '',
    'Ödənişi bu karta edə bilərsiniz:',
    '💳 {kart}',
    '{kart_sahibi}',
    '',
    'Ödənişdən sonra qəbzi bu nömrəyə göndərməyinizi xahiş edirik. Təşəkkür edirik!'
  ].join('\n');

  const DEFAULTS = {
    enabled: true,
    time: '10:10',
    card: '',
    cardHolder: '',
    template: DEFAULT_TEMPLATE,
    catchupDays: 3,     // kompüter həmin gün sönülü idisə, neçə gün sonra da göndərilsin
    deviceId: ''        // mesajları YALNIZ bu kompüter göndərir (dublikatın qarşısı)
  };

  const PLACEHOLDERS = [
    ['{sahibkar}', 'Sahibkarın adı (yoxdursa şirkət adı)'],
    ['{sirket}', 'Şəxs / şirkət adı'],
    ['{ay}', 'Ay (məs. Sentyabr 2026)'],
    ['{son_tarix}', 'Ödəniş tarixi'],
    ['{mebleg}', 'Bu ayın məbləği'],
    ['{evvelki_borc}', 'Əvvəlki aylardan qalıq + cəmi (yoxdursa sətir silinir)'],
    ['{cemi}', 'Cəmi ödəniləcək'],
    ['{kart}', 'Kart nömrəsi'],
    ['{kart_sahibi}', 'Kart sahibi (yoxdursa sətir silinir)']
  ];

  // ---------------------------------------------------------------- tarix köməkçiləri (yerli vaxt)
  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  function addMonths(ds, k) {
    const d = new Date(ds + 'T00:00:00'); const day = d.getDate();
    d.setDate(1); d.setMonth(d.getMonth() + k);
    const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(day, last)); return ymd(d);
  }
  function addDays(ds, k) { const d = new Date(ds + 'T00:00:00'); d.setDate(d.getDate() + k); return ymd(d); }
  const monthLabel = (ds) => { const d = new Date(ds + 'T00:00:00'); return `${AZM[d.getMonth()]} ${d.getFullYear()}`; };
  const fmtDate = (ds) => { if (!ds) return ''; const [y, m, d] = String(ds).slice(0, 10).split('-'); return `${d}.${m}.${y}`; };
  const fmtMoney = (n, c = 'AZN') => `${new Intl.NumberFormat('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(n || 0))} ${c || 'AZN'}`;

  // ---------------------------------------------------------------- telefon və kart
  /** "+994 50 123 45 67", "050-123-45-67", "501234567" → "994501234567". Yanlışdırsa ''. */
  function normalizePhone(v) {
    let d = String(v || '').replace(/\D/g, '');
    if (!d) return '';
    if (d.startsWith('00')) d = d.slice(2);
    if (d.length === 10 && d.startsWith('0')) d = '994' + d.slice(1);
    else if (d.length === 9) d = '994' + d;
    if (d.startsWith('994') && d.length !== 12) return '';
    return d.length >= 10 && d.length <= 15 ? d : '';
  }
  const prettyPhone = (d) => { d = normalizePhone(d); return d.length === 12 && d.startsWith('994') ? `+994 ${d.slice(3, 5)} ${d.slice(5, 8)} ${d.slice(8, 10)} ${d.slice(10)}` : (d ? '+' + d : ''); };
  const cardDigits = (v) => String(v || '').replace(/\D/g, '');
  const prettyCard = (v) => { const d = cardDigits(v); return d.length >= 12 ? d.replace(/(\d{4})(?=\d)/g, '$1 ') : String(v || '').trim(); };
  const maskCard = (v) => { const d = cardDigits(v); return d.length >= 8 ? `•••• ${d.slice(-4)}` : String(v || '').trim(); };

  // ---------------------------------------------------------------- borc hesabı (panel açılmasa da)
  const isOneTime = (r) => r.paymentMode === 'one_time' || r.isMonthly === false;
  const eachOf = (r) => Number(r.monthlyAmount || r.baseAmount || (r.installments && r.installments[0] && r.installments[0].amount) || r.amount || 0);

  /** Qeydin bu günə qədər yaranmış bütün ödəniş dövrləri (status ilə). */
  function periodsOf(r, today) {
    const ins = Array.isArray(r.installments) ? r.installments : [];
    if (isOneTime(r)) {
      const i = ins[0] || { id: r.id + '-legacy', dueDate: r.dueDate, amount: r.amount, status: r.status };
      if (!i.dueDate) return [];
      return [{ id: i.id, periodStart: i.periodStart || i.dueDate, due: i.dueDate, amount: Number(i.amount || 0), paid: i.status === 'paid', label: '1 dəfəlik' }];
    }
    const start = r.startDate || (ins.slice().sort((a, b) => String(a.periodStart).localeCompare(String(b.periodStart)))[0] || {}).periodStart;
    if (!start) return [];
    const byStart = new Map(ins.map((i) => [i.periodStart, i]));
    const out = [];
    for (let k = 0; k < 600; k++) {
      const ps = addMonths(start, k), due = addMonths(start, k + 1);
      if (due > today) break;
      const i = byStart.get(ps);
      out.push({ id: i ? i.id : 'auto-' + ps, periodStart: ps, due, amount: Number(i ? (i.amount || eachOf(r)) : eachOf(r)), paid: !!(i && i.status === 'paid'), label: monthLabel(ps) });
    }
    return out;
  }

  /** Bu gün (və ya buraxılmış son N gündə) ödəniş vaxtı çatan alacaqlar → hər qeyd üçün 1 mesaj. */
  function dueEvents(records, s, today = ymd()) {
    s = { ...DEFAULTS, ...(s || {}) };
    const from = addDays(today, -Math.max(0, Number(s.catchupDays) || 0));
    const out = [];
    for (const r of records || []) {
      if (r.type !== 'receivable' || r.waAuto === false) continue;
      const periods = periodsOf(r, today);
      const hits = periods.filter((p) => !p.paid && p.due >= from && p.due <= today);
      if (!hits.length) continue;
      const p = hits[hits.length - 1];
      out.push(buildMessage(r, p, periods, s));
    }
    return out;
  }

  /** Əl ilə "indi göndər": ən son ödənilməmiş dövr üzrə mesaj. */
  function manualEvent(r, s, today = ymd()) {
    s = { ...DEFAULTS, ...(s || {}) };
    const periods = periodsOf(r, today);
    const open = periods.filter((p) => !p.paid);
    if (!open.length) return null;
    return buildMessage(r, open[open.length - 1], periods, s);
  }

  function buildMessage(r, p, periods, s) {
    const prev = periods.filter((x) => !x.paid && x.due < p.due);
    const prevSum = prev.reduce((a, x) => a + x.amount, 0);
    const total = prevSum + p.amount;
    const cur = r.currency || 'AZN';
    const card = (r.cardNumber || s.card || '').trim();
    const vars = {
      sahibkar: (r.ownerName || '').trim() || r.person || '',
      sirket: r.person || '',
      ay: p.label,
      son_tarix: fmtDate(p.due),
      mebleg: fmtMoney(p.amount, cur),
      evvelki_borc: prev.length ? `Əvvəlki aylardan qalıq: ${fmtMoney(prevSum, cur)} (${prev.map((x) => x.label).join(', ')})\nCəmi ödəniləcək: ${fmtMoney(total, cur)}` : '',
      cemi: fmtMoney(total, cur),
      kart: prettyCard(card),
      kart_sahibi: (s.cardHolder || '').trim() ? `Kart sahibi: ${s.cardHolder.trim()}` : ''
    };
    return {
      key: `${r.id}:${p.periodStart}:${p.due}`,
      recordId: r.id, person: r.person, ownerName: r.ownerName || '',
      phone: normalizePhone(r.phone), rawPhone: r.phone || '',
      due: p.due, period: p.label, amount: p.amount, total, currency: cur, card,
      text: render(s.template || DEFAULT_TEMPLATE, vars)
    };
  }

  /** Şablonu doldurur; dəyəri boş qalan dəyişənin sətri silinir, artıq boş sətirlər yığılır. */
  function render(tpl, vars) {
    const lines = String(tpl || '').replace(/\r/g, '').split('\n');
    const out = [];
    for (const line of lines) {
      const keys = [...line.matchAll(/\{([a-z_]+)\}/gi)].map((m) => m[1].toLowerCase()).filter((k) => k in vars);
      if (keys.length && keys.every((k) => !vars[k])) continue; // sətirdəki bütün dəyişənlər boşdursa — sətri at
      out.push(line.replace(/\{([a-z_]+)\}/gi, (m, k) => (k.toLowerCase() in vars ? vars[k.toLowerCase()] : m)));
    }
    return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  /** "10:10" → bu günün həmin dəqiqəsi (Date). */
  function sendTimeToday(time, now = new Date()) {
    const [h, m] = String(time || '10:10').split(':').map(Number);
    const d = new Date(now); d.setHours(Number.isFinite(h) ? h : 10, Number.isFinite(m) ? m : 10, 0, 0); return d;
  }

  const api = { AZM, DEFAULT_TEMPLATE, DEFAULTS, PLACEHOLDERS, ymd, addMonths, addDays, fmtDate, fmtMoney, monthLabel, normalizePhone, prettyPhone, prettyCard, maskCard, cardDigits, periodsOf, dueEvents, manualEvent, render, sendTimeToday };
  root.BorcWA = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
