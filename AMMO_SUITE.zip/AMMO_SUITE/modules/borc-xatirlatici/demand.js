/* Borc Xatırladıcı — "Tələb et": ready-to-send payment demand (alacaq) or debt notice (verəcək).
 * Counts the unpaid months, lists them, totals the debt, and gives copy / WhatsApp / e-mail / print in one click. */
(function () {
  'use strict';

  const TONES = {
    receivable: [
      ['polite', 'Nəzakətli'],
      ['formal', 'Rəsmi'],
      ['short', 'Qısa mesaj'],
    ],
    payable: [
      ['polite', 'Təsdiq'],
      ['formal', 'Rəsmi'],
      ['short', 'Qısa mesaj'],
    ],
  };
  let cur = null; // { r, tone, sender, table }
  const st = { tone: 'polite', table: true };

  // ---------------------------------------------------------------- number to Azerbaijani words
  const ONES = ['', 'bir', 'iki', 'üç', 'dörd', 'beş', 'altı', 'yeddi', 'səkkiz', 'doqquz'];
  const TENS = ['', 'on', 'iyirmi', 'otuz', 'qırx', 'əlli', 'altmış', 'yetmiş', 'səksən', 'doxsan'];
  function words999(n) {
    const h = Math.floor(n / 100), t = Math.floor((n % 100) / 10), o = n % 10;
    return [h ? (h === 1 ? 'yüz' : ONES[h] + ' yüz') : '', TENS[t], ONES[o]].filter(Boolean).join(' ');
  }
  function words(n) {
    n = Math.floor(Math.abs(n));
    if (!n) return 'sıfır';
    const parts = [];
    const scales = [[1e9, 'milyard'], [1e6, 'milyon'], [1e3, 'min']];
    for (const [v, w] of scales) {
      const k = Math.floor(n / v);
      if (k) { parts.push(k === 1 && v === 1e3 ? 'min' : `${words999(k)} ${w}`); n %= v; }
    }
    if (n) parts.push(words999(n));
    return parts.join(' ');
  }
  const amountWords = (x, cur) => {
    const v = Math.round(Number(x || 0) * 100);
    const main = Math.floor(v / 100), cents = v % 100;
    const unit = cur === 'AZN' || !cur ? ['manat', 'qəpik'] : cur === 'USD' ? ['ABŞ dolları', 'sent'] : cur === 'EUR' ? ['avro', 'sent'] : [cur, ''];
    return `${words(main)} ${unit[0]}${cents && unit[1] ? ` ${String(cents).padStart(2, '0')} ${unit[1]}` : ''}`;
  };

  // ---------------------------------------------------------------- facts about one record
  function facts(r) {
    const open = openInstallments(r).slice().sort((a, b) => String(a.dueDate).localeCompare(String(b.dueDate)));
    const total = open.reduce((s, i) => s + Number(i.amount || 0), 0);
    const overdue = open.filter((i) => dayDiff(i.dueDate) < 0);
    const months = open.map((i) => ({
      label: installmentLabel(i, r), due: i.dueDate, amount: Number(i.amount || 0),
      late: dayDiff(i.dueDate) < 0 ? overdueDuration(i.dueDate).label : dayDiff(i.dueDate) === 0 ? 'bu gün' : `${dayDiff(i.dueDate)} gün qalıb`,
    }));
    const oneTime = isOneTime(r);
    let period;
    if (oneTime) period = `${fmtDate(open[0] && open[0].dueDate)} tarixinədək ödənilməli olan`;
    else if (open.length === 1) period = `${months[0].label} ayı üzrə`;
    else period = `${open.length} ay (${months[0].label} – ${months[months.length - 1].label}) üzrə`;
    const oldest = overdue[0] ? overdueDuration(overdue[0].dueDate).label : '';
    return { open, total, overdue, months, oneTime, period, oldest, count: open.length };
  }

  // ---------------------------------------------------------------- the letter text
  function letter(r, f, tone, sender) {
    const who = (r.ownerName || '').trim() || r.person;
    const me = sender || '';
    const cardRaw = (r.cardNumber || (settings.wa && settings.wa.card) || '').trim();
    const card = cardRaw && window.BorcWA ? BorcWA.prettyCard(cardRaw) : cardRaw;
    const holder = settings.wa && settings.wa.cardHolder ? ` (kart sahibi: ${settings.wa.cardHolder})` : '';
    const payLine = card && r.type === 'receivable' ? `Ödənişi ${card} nömrəli karta${holder} edə bilərsiniz.` : '';
    const firmNote = (r.ownerName || '').trim() && r.person && r.ownerName.trim() !== r.person ? ` (${r.person})` : '';
    const sum = fmt(f.total, r.currency);
    const words = amountWords(f.total, r.currency);
    const today = fmtDate(ymd());
    const late = f.overdue.length ? (f.oneTime ? ` Ödəniş müddəti ${f.oldest} gecikib.` : ` Ödənilməmiş ayların ən köhnəsi ${f.oldest} gecikib.`) : '';
    if (r.type === 'receivable') {
      if (tone === 'short') {
        return {
          subject: `Ödəniş xatırlatması — ${sum}`,
          body: `Hörmətli ${who}${firmNote}, ${me ? me + ' olaraq ' : ''}xatırladırıq ki, ${f.period} ${sum} ödənilməmiş borcunuz var.${late} Xahiş edirik, ödənişi bu gün edəsiniz.${payLine ? ' ' + payLine : ''} Təşəkkür edirik!`,
        };
      }
      if (tone === 'formal') {
        return {
          subject: `Ödəniş tələbi: ${sum} məbləğində borc`,
          body: [
            `Hörmətli ${who}${firmNote},`,
            `${me ? me + ' ' : ''}Sizə bildirir ki, ${f.period} ${sum} (${words}) məbləğində borcunuz ödənilməmiş qalır.${late}`,
            '@TABLE',
            `Bu məktubla Sizdən borcun tam məbləğinin bu gün, ${today} tarixində ödənilməsini tələb edirik.${payLine ? ' ' + payLine : ''} Ödəniş həyata keçirilibsə, xahiş edirik ödənişi təsdiq edən sənədi bizə göndərəsiniz.`,
            'Hörmətlə,',
            me || '________________',
          ],
        };
      }
      return {
        subject: `Borc xatırlatması — ${sum}`,
        body: [
          `Hörmətli ${who}${firmNote},`,
          `${me ? me + ' olaraq ' : ''}Sizə bildiririk ki, ${f.period} ${sum} (${words}) məbləğində ödənilməmiş borcunuz var.${late}`,
          '@TABLE',
          `Xahiş edirik, ödənişi bu gün, ${today} tarixində edəsiniz.${payLine ? ' ' + payLine : ''} Ödəniş artıq edilibsə, bu bildirişi nəzərə almayın və bizə məlumat verin.`,
          'Əməkdaşlığınız üçün təşəkkür edirik.',
          'Hörmətlə,',
          me || '________________',
        ],
      };
    }
    // payable: we owe them — a clear notice that confirms the debt
    if (tone === 'short') {
      return {
        subject: `Borc təsdiqi — ${sum}`,
        body: `Hörmətli ${who}, ${me ? me + ' olaraq ' : ''}təsdiq edirik ki, ${f.period} Sizə ${sum} borcumuz var. Ödənişi ən qısa müddətdə edəcəyik.`,
      };
    }
    return {
      subject: `Borc barədə bildiriş — ${sum}`,
      body: [
        `Hörmətli ${who},`,
        `${me ? me + ' ' : ''}${tone === 'formal' ? 'bu məktubla təsdiq edir' : 'olaraq təsdiq edirik'} ki, ${f.period} Sizə ${sum} (${words}) məbləğində borcumuz var.${late}`,
        '@TABLE',
        `Ödənişi ən qısa müddətdə həyata keçirəcəyik və ödəniş edildikdən sonra Sizə məlumat verəcəyik.`,
        'Hörmətlə,',
        me || '________________',
      ],
    };
  }

  // plain text version (for copy / WhatsApp / e-mail)
  function plain(r, f, L, withTable) {
    if (typeof L.body === 'string') return L.body;
    const table = withTable && f.count > 1
      ? f.months.map((m, i) => `${i + 1}. ${m.label} — ${fmt(m.amount, r.currency)} (son tarix ${fmtDate(m.due)}, ${m.late})`).join('\n') + `\nCƏMİ: ${fmt(f.total, r.currency)}`
      : '';
    return L.body.filter((x) => x !== '@TABLE' || table).map((x) => (x === '@TABLE' ? table : x)).join('\n\n');
  }

  // ---------------------------------------------------------------- modal
  function ensureModal() {
    if (document.getElementById('demandModal')) return;
    const m = document.createElement('div');
    m.id = 'demandModal';
    m.className = 'modal hidden demand-modal';
    m.setAttribute('role', 'dialog');
    m.setAttribute('aria-modal', 'true');
    m.innerHTML = `
      <div class="modal-card demand-card">
        <div class="modal-head"><div><h2 id="dmTitle">Ödəniş tələbi</h2><p id="dmSub"></p></div><button class="modal-close" id="dmClose" aria-label="Bağla">×</button></div>
        <div class="dm-grid">
          <aside class="dm-side">
            <div class="dm-total"><span id="dmTotalCap">Tələb olunan məbləğ</span><strong id="dmTotal"></strong><small id="dmWords"></small></div>
            <div class="dm-months" id="dmMonths"></div>
            <label class="dm-lbl">Məktubun tonu</label>
            <div class="dm-tones" id="dmTones"></div>
            <label class="dm-lbl" for="dmSender">Kimin adından</label>
            <input id="dmSender" placeholder="Məs.: “AMMO” MMC">
            <label class="dm-check"><input type="checkbox" id="dmTable" checked> Aylar cədvəlini əlavə et</label>
          </aside>
          <section class="dm-paper-wrap">
            <article class="dm-paper" id="dmPaper"></article>
          </section>
        </div>
        <div class="dm-actions">
          <button class="primary" id="dmCopy">Mətni kopyala</button>
          <button class="secondary" id="dmWa">WhatsApp ilə göndər</button>
          <button class="secondary" id="dmMail">E-poçt ilə göndər</button>
          <button class="secondary" id="dmPrint">Çap et / PDF</button>
        </div>
      </div>`;
    document.body.appendChild(m);
    m.addEventListener('click', (e) => { if (e.target === m) close(); });
    document.getElementById('dmClose').onclick = close;
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !m.classList.contains('hidden')) close(); });
    document.getElementById('dmSender').oninput = async (e) => {
      settings.senderName = e.target.value; render();
      try { await chrome.storage.local.set({ borcSettings: settings }); } catch (err) { /* ignore */ }
    };
    document.getElementById('dmTable').onchange = (e) => { st.table = e.target.checked; render(); };
    document.getElementById('dmCopy').onclick = () => send('copy');
    document.getElementById('dmWa').onclick = () => send('whatsapp');
    document.getElementById('dmMail').onclick = () => send('email');
    document.getElementById('dmPrint').onclick = () => send('print');
  }
  function close() { document.getElementById('demandModal').classList.add('hidden'); cur = null; }

  function render() {
    if (!cur) return;
    const r = cur.r, f = facts(r);
    const rec = r.type === 'receivable';
    const L = letter(r, f, st.tone, (settings.senderName || '').trim());
    document.getElementById('dmTitle').textContent = rec ? 'Ödəniş tələbi' : 'Borc barədə bildiriş';
    document.getElementById('dmSub').textContent = `${r.person} — ${f.oneTime ? '1 dəfəlik ödəniş' : `${f.count} ödənilməmiş ay`}${f.overdue.length ? `, ən köhnəsi ${f.oldest} gecikib` : ''}`;
    document.getElementById('dmTotalCap').textContent = rec ? 'Tələb olunan məbləğ' : 'Bizim borcumuz';
    document.getElementById('dmTotal').textContent = fmt(f.total, r.currency);
    document.getElementById('dmWords').textContent = amountWords(f.total, r.currency);
    document.getElementById('dmMonths').innerHTML = f.months.map((m) =>
      `<div class="dm-m ${dayDiff(m.due) < 0 ? 'late' : ''}"><span>${esc(m.label)}</span><b>${fmt(m.amount, r.currency)}</b><small>${esc(m.late)}</small></div>`).join('');
    document.getElementById('dmTones').innerHTML = TONES[r.type].map(([k, l]) => `<button class="${k === st.tone ? 'on' : ''}" data-tone="${k}">${l}</button>`).join('');
    document.querySelectorAll('#dmTones [data-tone]').forEach((b) => { b.onclick = () => { st.tone = b.dataset.tone; render(); }; });
    document.getElementById('dmWa').disabled = false;

    // paper preview
    const tableHtml = f.count > 1 && st.table
      ? `<table class="dm-table"><thead><tr><th>№</th><th>Dövr</th><th>Son tarix</th><th>Vəziyyət</th><th>Məbləğ</th></tr></thead><tbody>${
        f.months.map((m, i) => `<tr class="${dayDiff(m.due) < 0 ? 'late' : ''}"><td>${i + 1}</td><td>${esc(m.label)}</td><td>${fmtDate(m.due)}</td><td>${esc(m.late)}</td><td>${fmt(m.amount, r.currency)}</td></tr>`).join('')
      }</tbody><tfoot><tr><td colspan="4">Cəmi</td><td>${fmt(f.total, r.currency)}</td></tr></tfoot></table>`
      : '';
    const head = `<header class="dm-ph"><div><b>${esc((settings.senderName || '').trim() || 'Göndərən')}</b><small>${fmtDate(ymd())}</small></div><span class="dm-stamp ${rec ? '' : 'pay'}">${rec ? 'TƏLƏB' : 'BİLDİRİŞ'}</span></header>`;
    const subj = `<p class="dm-subject">${esc(L.subject)}</p>`;
    const body = typeof L.body === 'string'
      ? `<p>${esc(L.body)}</p>`
      : L.body.map((x) => (x === '@TABLE' ? tableHtml : `<p>${esc(x)}</p>`)).join('');
    document.getElementById('dmPaper').innerHTML = head + subj + body;
    cur.text = plain(r, f, L, st.table);
    cur.subject = L.subject;
    cur.total = f.total;
  }

  async function logDemand(channel) {
    const r = cur.r;
    r.demands = [{ at: new Date().toISOString(), total: cur.total, channel, tone: st.tone }, ...(r.demands || [])].slice(0, 20);
    try { await persist(); } catch (e) { /* ignore */ }
    renderTables();
  }

  async function send(channel) {
    if (!cur) return;
    const r = cur.r;
    if (channel === 'copy') {
      try { await navigator.clipboard.writeText(cur.text); toast('Mətn kopyalandı — istədiyiniz yerə yapışdırın'); }
      catch (e) { toast('Kopyalamaq alınmadı'); return; }
    } else if (channel === 'whatsapp') {
      const phone = window.BorcWA ? BorcWA.normalizePhone(r.phone) : String(r.phone || '').replace(/\D/g, '');
      const url = `https://wa.me/${phone && phone.length >= 11 ? phone : ''}?text=${encodeURIComponent(cur.text)}`;
      window.open(url, '_blank', 'noopener');
      if (!(phone && phone.length >= 11)) toast('Telefon nömrəsi qeyddə yoxdur — WhatsApp-da alıcını özünüz seçin');
    } else if (channel === 'email') {
      window.open(`mailto:?subject=${encodeURIComponent(cur.subject)}&body=${encodeURIComponent(cur.text)}`, '_blank');
    } else if (channel === 'print') {
      const w = window.open('', '_blank');
      if (!w) { toast('Yeni pəncərə açılmadı — brauzerdə pop-up icazəsini yoxlayın'); return; }
      w.document.write(`<!doctype html><html lang="az"><head><meta charset="utf-8"><title>${esc(cur.subject)}</title><style>${PRINT_CSS}</style></head><body><article class="dm-paper">${document.getElementById('dmPaper').innerHTML}</article><script>setTimeout(()=>print(),300)<\/script></body></html>`);
      w.document.close();
    }
    await logDemand(channel);
  }

  const PRINT_CSS = `body{font-family:"Times New Roman",serif;color:#111;margin:0;padding:48px 56px;font-size:15px;line-height:1.6}
  .dm-ph{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #111;padding-bottom:12px;margin-bottom:22px}
  .dm-ph b{display:block;font-size:17px}.dm-ph small{color:#555}
  .dm-stamp{border:2px solid #b42318;color:#b42318;padding:4px 12px;border-radius:6px;font:700 13px Arial,sans-serif;letter-spacing:2px;transform:rotate(-6deg)}
  .dm-stamp.pay{border-color:#1d4ed8;color:#1d4ed8}
  .dm-subject{font-weight:700;font-size:16px}
  table{width:100%;min-width:0;border-collapse:collapse;margin:10px 0 16px;font-size:13.5px}th,td{border:1px solid #999;padding:6px 8px;text-align:left}td:last-child,th:last-child{text-align:right}
  tfoot td{font-weight:700}tr.late td{color:#b42318}`;

  window.openDemand = function (id) {
    const r = records.find((x) => x.id === id);
    if (!r) return;
    ensureModal();
    cur = { r };
    st.tone = 'polite';
    document.getElementById('dmSender').value = settings.senderName || '';
    document.getElementById('dmTable').checked = st.table;
    render();
    document.getElementById('demandModal').classList.remove('hidden');
    setTimeout(() => document.getElementById('dmCopy').focus({ preventScroll: true }), 30);
  };
})();
