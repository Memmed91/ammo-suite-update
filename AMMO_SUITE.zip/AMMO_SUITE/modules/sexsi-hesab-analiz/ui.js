/* AMMO — Şəxsi hesab vərəqəsi · Analiz paneli (interfeys) */
(() => {
  'use strict';
  const A = window.SHA, E = window.SHEngine, K = window.SHAsk;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = A.money;
  const num = A.fmt;
  const sgn = (c) => (c > 0 ? `<span class="plus">+${num(c)}</span>` : c < 0 ? `<span class="minus">−${num(-c)}</span>` : '<span class="muted">0,00</span>');
  const fd = (d) => (d ? `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}` : '—');
  const gl = (g) => (A.GROUPS[g] || { label: g || '—' }).label;
  const CACHE = 'ammo_shv_cache_v1', DEC = 'ammo_shv_decisions_v1';
  const KIND_LABEL = { acc: 'Hesablama', red: 'Azalma', pay: 'Ödəniş', adj: 'Düzəliş' };

  const st = { M: null, raw: null, tab: 'overview', sec: 'tax', group: null, openP: null, pOnlyOpen: true, pYear: '',
    f: { sec: '', g: '', kind: '', year: '', q: '', hideZero: true, ids: null, idsLabel: '', limit: 300 }, fsev: 'all', fstat: 'open', dec: {}, me: '' };

  function toast(t) { const e = $('#toast'); e.textContent = t; e.classList.add('show'); clearTimeout(e._t); e._t = setTimeout(() => e.classList.remove('show'), 2600); }
  function bar(kind, html) { const b = $('#bar'); if (!html) { b.className = 'bar hidden'; return; } b.className = 'bar ' + (kind || ''); b.innerHTML = html; }

  // ================= Yükləmə =================
  function itemsFromText(text) { return E.streamFromHtml(text); }
  async function itemsFromFile(file) {
    const buf = await file.arrayBuffer();
    const head = new TextDecoder('utf-8').decode(buf.slice(0, 2000));
    if (/^\s*</.test(head) || /<html|<table/i.test(head)) { const text = new TextDecoder('utf-8').decode(buf); return { text, items: itemsFromText(text) }; }
    const wb = XLSX.read(buf, { type: 'array' });
    const rows = wb.SheetNames.flatMap((n) => XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, raw: false, defval: '' }));
    return { text: null, rows, items: E.streamFromRows(rows) };
  }
  const isFaiz = (items) => items.some((it) => it.type === 'row' && it.cells.some((c) => /^Gün sayı$/i.test(c)));

  async function loadFiles(files) {
    if (!files || !files.length) return;
    bar('', 'Vərəqə oxunur...');
    try {
      let ops = st.raw?.opsItems || null, faiz = null, opsText = null, faizText = null, name = '';
      for (const f of files) {
        const r = await itemsFromFile(f);
        if (isFaiz(r.items)) { faiz = r.items; faizText = r.text; } else { ops = r.items; opsText = r.text; name = f.name; }
      }
      if (!ops) { bar('warn', 'Bu fayl “Faiz hesablaması tarixçəsi”dir. Əvvəlcə “Əməliyyat tarixçəsi” vərəqəsini yükləyin (faiz tarixçəsi əlavə kimi qəbul olunur).'); return; }
      st.raw = { opsItems: ops, faizItems: faiz || st.raw?.faizItems || null, liab: st.raw?.liab || null, source: 'Fayl: ' + name, at: Date.now() };
      await build({ opsText, faizText });
    } catch (e) { console.error(e); bar('warn', 'Fayl oxunmadı: ' + esc(e.message)); }
  }
  async function loadEtax() {
    const btn = $('#etaxBtn'); btn.disabled = true; btn.textContent = 'Kabinetdən oxunur...';
    bar('', 'e-taxes kabinetindən şəxsi hesab vərəqəsi, faiz tarixçəsi və rəsmi qalıqlar oxunur. Bütün tarixçə 10–30 saniyə çəkə bilər...');
    try {
      const r = await new Promise((res) => { try { chrome.runtime.sendMessage({ type: 'AMMO_ETAX_SHV', opts: {} }, (x) => res(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : x || { ok: false, error: 'empty' })); } catch (e) { res({ ok: false, error: e.message }); } });
      if (!r.ok) {
        const m = { no_tab: 'e-taxes kabineti açıq deyil. Chrome-da new.e-taxes.gov.az-da şirkətin kabinetinə daxil olun və yenidən basın.', no_token: 'e-taxes səhifəsi açıqdır, amma kabinetə giriş edilməyib (ASAN İmza ilə daxil olun).', expired: 'e-taxes sessiyasının vaxtı bitib — kabinetə yenidən daxil olun.', no_sheet: 'Kabinet vərəqəni vermədi. Kabinetdə “Şəxsi hesab vərəqəsi” səhifəsini bir dəfə açıb yenidən cəhd edin.' }[r.error] || ('Kabinet oxunmadı: ' + r.error);
        bar('warn', esc(m)); return;
      }
      st.raw = { opsItems: itemsFromText(r.ops), faizItems: r.faiz ? itemsFromText(r.faiz) : null, liab: r.liabilities, source: 'e-taxes kabineti', at: r.at };
      await build({ opsText: r.ops, faizText: r.faiz });
    } finally { btn.disabled = false; btn.textContent = '⤓ e-taxes-dən yüklə'; }
  }
  async function build(save) {
    const t0 = performance.now();
    st.M = A.build(st.raw.opsItems, { liabilities: st.raw.liab, faizItems: st.raw.faizItems });
    const M = st.M;
    if (!M.rows.length) { bar('warn', 'Vərəqədə əməliyyat tapılmadı. Faylın “Şəxsi hesab vərəqəsi — Əməliyyat tarixçəsi” olduğuna əmin olun.'); st.M = null; return; }
    st.group = null; st.openP = null; st.f.ids = null;
    bar('ok', `✓ ${esc(M.entity.name || 'Vergi ödəyicisi')} — ${M.rows.length.toLocaleString('az-AZ')} əməliyyat analiz edildi (${Math.round(performance.now() - t0)} ms). Mənbə: ${esc(st.raw.source)}${st.raw.faizItems ? ' · faiz tarixçəsi ilə' : ''}${st.raw.liab ? ' · kabinetin rəsmi qalıqları ilə' : ''}.`);
    setTimeout(() => bar(), 9000);
    if (save && (save.opsText || st.raw.liab)) {
      try {
        const cur = (await chrome.storage.local.get(CACHE))[CACHE] || { items: {} };
        const v = M.entity.voen || 'x';
        cur.items[v] = { name: M.entity.name, ops: save.opsText || cur.items[v]?.ops, faiz: save.faizText || cur.items[v]?.faiz || null, liab: st.raw.liab || null, source: st.raw.source, at: st.raw.at };
        cur.last = v;
        const keys = Object.keys(cur.items).sort((a, b) => (cur.items[b].at || 0) - (cur.items[a].at || 0));
        keys.slice(4).forEach((k) => delete cur.items[k]);
        await chrome.storage.local.set({ [CACHE]: cur });
      } catch (e) { console.warn('cache', e); }
    }
    showApp();
  }
  async function restore() {
    try {
      const cur = (await chrome.storage.local.get(CACHE))[CACHE];
      const it = cur?.items?.[cur.last];
      if (!it?.ops) return false;
      st.raw = { opsItems: itemsFromText(it.ops), faizItems: it.faiz ? itemsFromText(it.faiz) : null, liab: it.liab, source: it.source + ' · ' + new Date(it.at).toLocaleString('az-AZ'), at: it.at };
      st.M = A.build(st.raw.opsItems, { liabilities: st.raw.liab, faizItems: st.raw.faizItems });
      showApp();
      return true;
    } catch (e) { console.warn(e); return false; }
  }

  // ================= Qərarlar (bütün kompüterlərdə) =================
  async function loadDecisions() {
    try { st.dec = (await chrome.storage.local.get(DEC))[DEC] || {}; } catch (e) { st.dec = {}; }
    try { const { suiteAuth } = await chrome.storage.local.get('suiteAuth'); st.me = suiteAuth?.email || ''; } catch (e) { /* */ }
  }
  const decOf = (fid) => (st.dec[st.M?.entity.voen || 'x'] || {})[fid] || null;
  let decTimer = null;
  function setDecision(fid, patch) {
    const v = st.M.entity.voen || 'x';
    st.dec[v] = st.dec[v] || {};
    st.dec[v][fid] = { ...(st.dec[v][fid] || { s: 'open', n: '' }), ...patch, at: Date.now(), by: st.me };
    clearTimeout(decTimer); decTimer = setTimeout(() => chrome.storage.local.set({ [DEC]: st.dec }), 400);
  }

  // ================= Ümumi görünüş =================
  function showApp() {
    const M = st.M;
    $('#empty').classList.add('hidden'); $('#tabs').classList.remove('hidden'); $('#exportBtn').disabled = false;
    $('#whoName').textContent = M.entity.name || 'Vergi ödəyicisi';
    $('#whoSub').innerHTML = `VÖEN ${esc(M.entity.voen || '—')} · dövr ${fd(M.period.from)} – ${fd(M.period.to)} · məlumat tarixi ${fd(M.asOf)} · <span title="Mənbə">${esc(st.raw.source)}</span>`;
    const open = M.findings.filter((f) => f.sev === 'high' && !['done', 'skip'].includes(decOf(f.id)?.s)).length;
    $('#fCount').textContent = open || '';
    setTab(st.tab);
  }
  function setTab(t) {
    st.tab = t;
    $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
    $$('.tab').forEach((s) => s.classList.add('hidden'));
    $('#tab-' + t).classList.remove('hidden');
    ({ overview: rOverview, findings: rFindings, groups: rGroups, ops: rOps, ask: rAsk })[t]();
    window.scrollTo(0, 0);
  }

  // ---------- İcmal ----------
  function rOverview() {
    const M = st.M, T = M.sections.tax;
    const prin = Object.values(M.sections).reduce((a, s) => a + Math.max(0, s.finalBal), 0);
    const daily = Math.round(prin * A.FAIZ_RATE);
    const recon = M.findings.find((f) => f.type === 'ok' || f.type === 'recon');
    const highs = M.findings.filter((f) => f.sev === 'high' || f.sev === 'med').filter((f) => !['done', 'skip'].includes(decOf(f.id)?.s)).slice(0, 3);
    let h = '';
    if (recon) h += `<div class="recon ${recon.sev === 'ok' ? '' : 'bad'}">${recon.sev === 'ok' ? '✓' : '⚠'} <span><b>${esc(recon.title)}.</b> ${esc(recon.text)}</span></div>`;
    h += `<div class="kpis">
      <div class="kpi bad"><small>Cəmi ödənməli</small><b>${money(M.totals.total)}</b><em>bütün bölmələr</em></div>
      <div class="kpi"><small>Əsas borc</small><b>${money(M.totals.principal)}</b><em>${M.totals.overpay ? 'artıq ödəmə ' + money(M.totals.overpay) : 'vergi + sosial'}</em></div>
      <div class="kpi warn"><small>Faiz / penya</small><b>${money(M.totals.penalty)}</b><em>yığılmış</em></div>
      <div class="kpi warn"><small>Hər gün artır</small><b>≈ ${money(daily)}</b><em>ayda ≈ ${money(daily * 30)}</em></div>
      <div class="kpi ${M.findings.some((f) => f.sev === 'high') ? 'bad' : 'ok'}"><small>Tapılan məsələ</small><b>${M.findings.filter((f) => f.sev !== 'ok').length}</b><em>${M.findings.filter((f) => f.sev === 'high').length} kritik</em></div>
    </div>`;
    if (highs.length) h += `<div class="todo">${highs.map((f) => `<div class="card ${f.sev}" data-fid="${esc(f.id)}"><h4>${esc(f.title)}</h4><p>${esc(f.action || '')}</p><span class="imp">${f.impact ? money(f.impact) : ''}</span></div>`).join('')}</div>`;
    // növlər üzrə borc
    const gs = T ? Object.values(T.groups).filter((g) => g.debt > 0).sort((a, b) => b.debt - a.debt) : [];
    const max = gs.length ? gs[0].debt : 1;
    const barsHtml = gs.map((g) => {
      const old = g.lots.filter((l) => l.pdt && A.days(l.pdt, M.asOf) > 365).reduce((a, l) => a + l.amt, 0);
      return `<div class="barrow" data-group="${g.g}" data-sec="tax"><span class="lbl" title="${esc(g.full)}">${esc(g.label)}</span><span class="track"><span class="fill old" style="width:${old / max * 100}%"></span><span class="fill" style="width:${(g.debt - old) / max * 100}%"></span></span><span class="val">${money(g.debt)}</span></div>`;
    }).join('') || '<p class="muted">Vergilər üzrə əsas borc yoxdur.</p>';
    const secRows = Object.values(M.sections).map((s) => {
      const off = M.official ? (s.key === 'tax' ? M.official.list.reduce((a, x) => a + x.principal + x.sanction - x.overpay, 0) : s.key === 'mdss' ? M.official.social.mdss : s.key === 'unemp' ? M.official.social.unemp : null) : null;
      return `<tr class="click" data-sec="${s.key}"><td><b>${esc(s.label)}</b></td><td class="m">${money(Math.max(0, s.finalBal))}${s.finalBal < 0 ? `<div class="explain">artıq ${money(-s.finalBal)}</div>` : ''}</td><td class="m">${money(s.finalPen)}</td>${M.official ? `<td class="m">${off == null ? '—' : money(off)}</td>` : ''}<td>${fd(s.lastDate)}</td></tr>`;
    }).join('');
    h += `<div class="grid g2">
      <div class="card"><h3>Vergi borcu hansı növdədir</h3><p class="sub">Kabinetin bölgü qaydası ilə: ödəniş ödəmə tarixi ən köhnə olan borcu bağlayır. Növə basın — dövrlərə bölünmüş kartı açılır.</p><div class="bars">${barsHtml}</div>
        <div class="legend"><span><i style="background:var(--a-bad)"></i>1 ildən köhnə</span><span><i style="background:var(--a-brand)"></i>son 1 il</span></div></div>
      <div class="card"><h3>Bölmələr</h3><p class="sub">Vərəqənin hər bölməsinin son vəziyyəti${M.official ? ' və kabinetdəki rəsmi əsas borc' : ''}.</p>
        <div class="tw"><table class="t"><tr><th>Bölmə</th><th class="m">Əsas borc</th><th class="m">Faiz/penya</th>${M.official ? '<th class="m">Kabinet (rəsmi)</th>' : ''}<th>Son əməliyyat</th></tr>${secRows}</table></div></div>
    </div>`;
    h += `<div class="grid g2" style="margin-top:14px">
      <div class="card chart"><h3>Borcun dinamikası</h3><p class="sub">Vergilər bölməsi — hər ayın sonuna əsas borc və faiz (son 36 ay).</p>${chartSvg()}</div>
      <div class="card"><h3>Pul hara gedib — son 12 ay</h3><p class="sub">Ödəniş tapşırığında yazılan vergi ilə ödənişin əslində bağladığı borc.</p>${moneyFlow()}</div>
    </div>`;
    $('#tab-overview').innerHTML = h;
  }
  function chartSvg() {
    const T = st.M.sections.tax; if (!T) return '<p class="muted">Vergilər bölməsi yoxdur.</p>';
    const end = st.M.asOf, pts = [];
    for (let i = 35; i >= 0; i--) {
      const d = new Date(end.getFullYear(), end.getMonth() - i + 1, 0);
      let last = null; for (const r of T.rows) { if (r.dt && r.dt <= d) last = r; else if (r.dt && r.dt > d) break; }
      pts.push({ d, b: last ? Math.max(0, last.bal) : 0, p: last ? last.pen : 0 });
    }
    const W = 640, H = 220, L = 58, B = 26, mx = Math.max(1, ...pts.map((p) => Math.max(p.b, p.p)));
    const x = (i) => L + i * (W - L - 10) / (pts.length - 1), y = (v) => H - B - v / mx * (H - B - 12);
    const line = (k) => pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p[k]).toFixed(1)}`).join('');
    const ticks = [0, .5, 1].map((t) => `<line class="ax" x1="${L}" x2="${W - 10}" y1="${y(mx * t)}" y2="${y(mx * t)}"/><text x="${L - 6}" y="${y(mx * t) + 4}" text-anchor="end">${Math.round(mx * t / 100000)}k</text>`).join('');
    const lab = pts.map((p, i) => (i % 6 === 0 || i === pts.length - 1) ? `<text x="${x(i)}" y="${H - 8}" text-anchor="middle">${String(p.d.getMonth() + 1).padStart(2, '0')}.${String(p.d.getFullYear()).slice(2)}</text>` : '').join('');
    return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${ticks}${lab}<path d="${line('b')}" fill="none" stroke="#1463d8" stroke-width="2.4"/><path d="${line('p')}" fill="none" stroke="#d92d20" stroke-width="2" stroke-dasharray="5 4"/></svg>
      <div class="legend"><span><i style="background:#1463d8"></i>Əsas borc (indi ${money(pts.at(-1).b)})</span><span><i style="background:#d92d20"></i>Faiz (indi ${money(pts.at(-1).p)})</span></div>`;
  }
  function moneyFlow() {
    const T = st.M.sections.tax; if (!T) return '<p class="muted">—</p>';
    const from = new Date(st.M.asOf.getTime() - 365 * 86400000);
    const pays = T.rows.filter((r) => r.kindN === 'pay' && r.dt >= from);
    if (!pays.length) return '<p class="muted">Son 12 ayda vergi ödənişi yoxdur.</p>';
    const named = {}, real = {};
    let toPen = 0, spill = 0;
    for (const r of pays) {
      const g = A.groupOfCode(r.code) || 'OTHER'; named[g] = (named[g] || 0) + r.amount;
      for (const [k, v] of Object.entries(r.alloc || {})) { const gg = k.split('|')[0]; real[gg] = (real[gg] || 0) + v; }
      toPen += r.toPenalty || 0; spill += r.spill || 0;
    }
    const keys = [...new Set([...Object.keys(named), ...Object.keys(real)])].sort((a, b) => (real[b] || 0) + (named[b] || 0) - (real[a] || 0) - (named[a] || 0));
    return `<div class="tw"><table class="t"><tr><th>Vergi</th><th class="m">Bu adla ödənilib</th><th class="m">Əslində bağladığı</th></tr>${keys.map((g) => `<tr><td>${esc(gl(g))}</td><td class="m">${money(named[g] || 0)}</td><td class="m"><b>${money(real[g] || 0)}</b></td></tr>`).join('')}
      <tr><td class="muted">Faizə gedib</td><td></td><td class="m">${money(toPen)}</td></tr>${spill ? `<tr><td class="muted">Artıq ödəmə qalıb</td><td></td><td class="m">${money(spill)}</td></tr>` : ''}</table></div>
      <p class="explain">${pays.length} ödəniş, cəmi ${money(pays.reduce((a, r) => a + r.amount, 0))}. ${link('Bu ödənişlərə bax →', pays)}</p>`;
  }
  const link = (label, rows) => `<button class="ask-link" data-ids="${rows.map((r) => r.id).join(',')}">${esc(label)}</button>`;

  // ---------- Uyğunsuzluqlar ----------
  const SEV = { high: 'Kritik', med: 'Diqqət', info: 'Məlumat', ok: 'Qaydasındadır' };
  const STAT = [['open', 'Açıq'], ['review', 'Baxılır'], ['filed', 'Ərizə verildi'], ['done', 'Həll edildi'], ['skip', 'Əhəmiyyətsiz']];
  function rFindings() {
    const M = st.M;
    let F = M.findings;
    if (st.fsev !== 'all') F = F.filter((f) => f.sev === st.fsev);
    if (st.fstat === 'open') F = F.filter((f) => !['done', 'skip'].includes(decOf(f.id)?.s || 'open'));
    if (st.fstat === 'done') F = F.filter((f) => ['done', 'skip'].includes(decOf(f.id)?.s));
    const cnt = (s) => M.findings.filter((f) => f.sev === s).length;
    let h = `<div class="fbar"><div class="seg" id="fsev">${[['all', 'Hamısı ' + M.findings.length], ['high', 'Kritik ' + cnt('high')], ['med', 'Diqqət ' + cnt('med')], ['info', 'Məlumat ' + cnt('info')]].map(([k, v]) => `<button data-v="${k}" class="${st.fsev === k ? 'on' : ''}">${v}</button>`).join('')}</div>
      <div class="seg" id="fstat">${[['open', 'Açıq olanlar'], ['all', 'Hamısı'], ['done', 'Həll edilənlər']].map(([k, v]) => `<button data-v="${k}" class="${st.fstat === k ? 'on' : ''}">${v}</button>`).join('')}</div>
      <span class="muted" style="font-size:12.5px">Qərar və qeydləriniz bütün AMMO kompüterlərində görünür.</span></div>`;
    h += F.map((f) => {
      const d = decOf(f.id) || { s: 'open', n: '' };
      const tpl = ['offset', 'refund', 'misroute', 'official', 'overpay', 'overdue', 'social', 'dup', 'faiz'].includes(f.type);
      return `<div class="find ${f.sev} ${['done', 'skip'].includes(d.s) ? 'done' : ''}" id="F-${esc(f.id)}"><div class="sv"></div><div class="in">
        <div class="hd"><div><div class="tag">${SEV[f.sev]}</div><h4>${esc(f.title)}</h4></div>${f.impact ? `<span class="imp">${money(f.impact)}</span>` : ''}</div>
        <p class="tx">${esc(f.text)}</p>
        ${f.action ? `<div class="act"><b>Nə etməli:</b> ${esc(f.action)}</div>` : ''}
        ${f.sev === 'ok' ? '' : `<div class="ft">
          ${f.rows && f.rows.length ? `<button class="btn sm" data-rows="${esc(f.id)}">Sətirlərə bax (${f.rows.length})</button>` : ''}
          ${f.group && f.section ? `<button class="btn sm" data-group="${f.group}" data-sec="${f.section}">Növün kartı</button>` : ''}
          ${tpl ? `<button class="btn sm" data-tpl="${esc(f.id)}">Ərizə / məktub mətni</button>` : ''}
          <select data-dec="${esc(f.id)}">${STAT.map(([k, v]) => `<option value="${k}" ${d.s === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
          <input class="note" data-note="${esc(f.id)}" placeholder="Qeyd: kim, nə vaxt, nə edildi..." value="${esc(d.n || '')}">
          ${d.at ? `<span class="who">${esc(d.by || '')} · ${new Date(d.at).toLocaleDateString('az-AZ')}</span>` : ''}
        </div>`}
      </div></div>`;
    }).join('') || '<div class="card"><p class="muted">Bu filtrə uyğun məsələ yoxdur.</p></div>';
    $('#tab-findings').innerHTML = h;
  }
  function template(f) {
    const M = st.M, T = M.sections.tax;
    const head = `Vergi orqanına\n\n${M.entity.name || '________'} (VÖEN: ${M.entity.voen || '________'})\n\nTarix: ${fd(new Date())}\n\n`;
    const debts = T ? Object.values(T.groups).filter((g) => g.debt > 0).sort((a, b) => b.debt - a.debt) : [];
    const sign = '\n\nHörmətlə,\nRəhbər: ____________________\nBaş mühasib: ____________________';
    if (f.type === 'offset' || f.type === 'overpay') return head + `Mövzu: Artıq ödənilmiş vergi məbləğinin vergi borcunun ödənilməsinə yönəldilməsi (əvəzləşdirilməsi) haqqında\n\nŞəxsi hesab vərəqəsinə əsasən ${gl(f.group)} üzrə ${money(f.impact)} artıq ödəmə yaranmışdır. Eyni zamanda aşağıdakı vergilər üzrə borcumuz mövcuddur:\n${debts.map((g) => `  – ${g.label}: ${money(g.debt)}`).join('\n')}\n\nVergi qanunvericiliyinə uyğun olaraq, artıq ödənilmiş ${money(f.impact)} məbləğin göstərilən vergi borclarının ödənilməsinə yönəldilməsini (əvəzləşdirilməsini) xahiş edirik.` + sign;
    if (f.type === 'refund') return head + `Mövzu: Artıq ödənilmiş vergi məbləğinin qaytarılması haqqında\n\nŞəxsi hesab vərəqəsinə əsasən ${gl(f.group)} üzrə ${money(f.impact)} artıq ödəmə yaranmışdır. Vergi borcumuz yoxdur. Həmin məbləğin bank hesabımıza qaytarılmasını xahiş edirik.\n\nBank rekvizitləri: ____________________` + sign;
    if (f.type === 'misroute' || f.type === 'official') {
      const rows = (f.rows || []).map((id) => M.byId[id]).filter(Boolean).slice(-15);
      return head + `Mövzu: Ödənişlərin dəqiqləşdirilməsi və şəxsi hesab vərəqəsi üzrə üzləşmə aktının verilməsi haqqında\n\nŞəxsi hesab vərəqəmizdə ödəniş tapşırıqlarında göstərilən vergi növü ilə ödənişin aid edildiyi öhdəlik arasında fərqlər müəyyən edilmişdir${rows.length ? ':\n' + rows.map((r) => `  – ${r.date}, ${r.name}, ${money(r.amount)}`).join('\n') : '.'}\n\nXahiş edirik:\n1) göstərilən ödənişlərin hansı öhdəliklərə aid edildiyini izah edəsiniz;\n2) vergi növləri üzrə üzləşmə aktı (borc / artıq ödəmə / faiz) təqdim edəsiniz;\n3) lazım olduqda ödənişlərin ödəniş tapşırığında göstərilən vergi növünə aid edilməsini təmin edəsiniz.` + sign;
    }
    if (f.type === 'overdue' || f.type === 'faiz') return head + `Mövzu: Vergi borcunun hissə-hissə ödənilməsi (möhlət verilməsi) haqqında\n\nŞəxsi hesab vərəqəsinə əsasən hazırda vergi borcumuz ${debts.map((g) => `${g.label} — ${money(g.debt)}`).join('; ')} təşkil edir. Maliyyə vəziyyətimizlə əlaqədar borcun aşağıdakı qrafik üzrə ödənilməsinə icazə verilməsini xahiş edirik:\n\n  Ay 1: ____________ ₼\n  Ay 2: ____________ ₼\n  Ay 3: ____________ ₼\n\nCari vergiləri vaxtında ödəməyi öhdəmizə götürürük.` + sign;
    if (f.type === 'social') return head + `Mövzu: Bölüşdürülməmiş sosial sığorta ödənişinin dəqiqləşdirilməsi haqqında\n\nŞəxsi hesab vərəqəsində ${money(f.impact)} məbləğində bölüşdürülməmiş sosial sığorta ödənişi göstərilir. Həmin məbləğin müvafiq öhdəliklərə (məcburi dövlət sosial sığorta / işsizlikdən sığorta / icbari tibbi sığorta) aid edilməsini xahiş edirik.` + sign;
    if (f.type === 'dup') return head + `Mövzu: Təkrar ödənişin dəqiqləşdirilməsi haqqında\n\n${f.text}\n\nBank çıxarışı əlavə olunur. Səhvən təkrar ödənilmiş məbləğin digər vergi borcuna yönəldilməsini və ya qaytarılmasını xahiş edirik.` + sign;
    return head + f.text + sign;
  }
  function showTemplate(f) {
    const t = template(f);
    openDrawer(`<h3>Ərizə / məktub mətni</h3><p class="muted">Mətni yoxlayın, boş yerləri doldurun. Hüquqi əsası (maddə nömrəsini) mühasib və ya hüquqşünas əlavə etməlidir.</p>
      <textarea id="tplText" style="width:100%;height:420px;border:1px solid var(--a-line);border-radius:10px;padding:12px;font:13px/1.5 var(--a-font)">${esc(t)}</textarea>
      <div style="display:flex;gap:8px;margin-top:10px"><button class="btn primary" id="tplCopy">Kopyala</button><button class="btn" id="tplDl">.txt kimi saxla</button></div>`);
    $('#tplCopy').onclick = async () => { await navigator.clipboard.writeText($('#tplText').value); toast('Mətn kopyalandı'); };
    $('#tplDl').onclick = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([$('#tplText').value], { type: 'text/plain;charset=utf-8' })); a.download = 'erize.txt'; a.click(); };
  }

  // ---------- Vergi növləri və dövrlər ----------
  function rGroups() {
    const M = st.M;
    if (!M.sections[st.sec]) st.sec = Object.keys(M.sections)[0];
    const S = M.sections[st.sec];
    const gs = Object.values(S.groups).filter((g) => g.g !== 'OPEN' || g.debt).sort((a, b) => b.debt - a.debt || b.acc - a.acc);
    if (!st.group || !S.groups[st.group]) st.group = gs[0]?.g;
    const G = S.groups[st.group];
    let h = `<div class="gwrap"><div class="glist"><div class="secsw">${Object.values(M.sections).map((s) => `<button data-secsw="${s.key}" class="${s.key === st.sec ? 'on' : ''}">${esc(s.label)}</button>`).join('')}</div>
      ${gs.map((g) => `<button class="gitem ${g.g === st.group ? 'on' : ''}" data-g="${g.g}"><span>${esc(g.label)}<small>${g.codes.slice(0, 3).join(', ') || '—'}</small></span><span class="d ${g.debt ? '' : 'z'}">${g.debt ? money(g.debt) : (g.credit ? '−' + money(g.credit) : 'bağlanıb')}</span></button>`).join('')}</div><div>`;
    if (!G) { $('#tab-groups').innerHTML = h + '<div class="card"><p class="muted">Bu bölmədə əməliyyat yoxdur.</p></div></div></div>'; return; }
    const periods = S.periods.filter((p) => p.g === G.g);
    const lotsAll = S.allLots.filter((l) => l.g === G.g);
    const years = [...new Set(periods.map((p) => String(p.key).slice(0, 4)).filter((y) => /^\d{4}$/.test(y)))].sort().reverse();
    let list = periods.map((p) => {
      const lots = lotsAll.filter((l) => l.pkey === p.key);
      const gross = lots.reduce((a, l) => a + l.orig, 0), open = lots.reduce((a, l) => a + l.amt, 0);
      const pdt = p.pdts.length ? new Date(Math.max(...p.pdts)) : (lots[0]?.pdt || null);
      const oldest = lots.filter((l) => l.amt > 0).reduce((m, l) => (!m || (l.pdt && l.pdt < m) ? l.pdt : m), null);
      return { ...p, gross, open, pdt, oldest, lots, late: open > 0 && oldest && oldest < M.asOf ? A.days(oldest, M.asOf) : 0 };
    });
    list.sort((a, b) => String(b.key).localeCompare(String(a.key)));
    if (st.pYear) list = list.filter((p) => String(p.key).startsWith(st.pYear));
    const openCount = list.filter((p) => p.open > 0).length;
    if (st.pOnlyOpen && openCount) list = list.filter((p) => p.open > 0);
    h += `<div class="card" style="margin-bottom:12px"><h3>${esc(G.full)}</h3><p class="sub">Kodlar vərəqədə: ${esc(G.codes.join(', ') || '—')} · ${G.rows} əməliyyat</p>
      <div class="gkpis"><div class="kpi"><small>Hesablanıb</small><b>${money(G.acc)}</b></div><div class="kpi"><small>Azaldılıb</small><b>${money(G.red)}</b></div><div class="kpi"><small>Bu adla ödənilib</small><b>${money(G.paid)}</b><em>${G.payCount} ödəniş</em></div>
      <div class="kpi ${G.debt ? 'bad' : 'ok'}"><small>Açıq əsas borc</small><b>${money(G.debt)}</b>${G.credit ? `<em>artıq ödəmə ${money(G.credit)}</em>` : ''}</div><div class="kpi warn"><small>Gündə faiz</small><b>≈ ${money(Math.round(G.debt * A.FAIZ_RATE))}</b></div></div>
      ${M.officialByGroup && M.officialByGroup[G.g] && st.sec === 'tax' ? `<p class="explain">Kabinetin rəsmi qalığı: əsas borc ${money(M.officialByGroup[G.g].principal)}, faiz ${money(M.officialByGroup[G.g].faiz)}, sanksiya ${money(M.officialByGroup[G.g].sanction)}, artıq ödəmə ${money(M.officialByGroup[G.g].overpay)}.</p>` : ''}</div>`;
    h += `<div class="fbar"><div class="seg" id="ponly"><button data-v="1" class="${st.pOnlyOpen ? 'on' : ''}">Açıq dövrlər (${openCount})</button><button data-v="0" class="${!st.pOnlyOpen ? 'on' : ''}">Bütün dövrlər (${periods.length})</button></div>
      <select id="pyear" class="btn sm"><option value="">Bütün illər</option>${years.map((y) => `<option ${st.pYear === y ? 'selected' : ''}>${y}</option>`).join('')}</select>
      <span class="muted" style="font-size:12.5px">Dövrə basın — bütün bəyannamələri və borcu hansı ödənişin bağladığı açılır.</span></div>`;
    h += `<div class="tw"><table class="t"><tr><th>Dövr</th><th>Bəyannamələr</th><th class="m">Hesablanıb</th><th class="m">Azaldılıb</th><th class="m">Yekun</th><th>Ödəmə tarixi</th><th class="m">Açıq qalıq</th><th>Vəziyyət</th></tr>
      ${list.map((p) => {
        const isOpen = st.openP === p.g + '|' + p.key;
        const status = p.open > 0 ? (p.late ? `<span class="st late">${p.late} gün gecikir</span>` : '<span class="st open">açıq</span>') : '<span class="st closed">bağlanıb</span>';
        const nDecl = S.rows.filter((x) => x.g === p.g && (x.per ? x.per.key : '—') === p.key && x.decl === 'Dəqiqləşdirilmiş' && !x.zero).length;
        let row = `<tr class="click ${isOpen ? 'open' : ''}" data-p="${esc(p.g + '|' + p.key)}"><td><b>${esc(p.label)}</b></td><td>${p.decls.map((d) => `<span class="chip ${d === 'Dəqiqləşdirilmiş' ? 'd' : 'p'}">${esc(d)}${d === 'Dəqiqləşdirilmiş' && nDecl > 1 ? ' ×' + nDecl : ''}</span>`).join('') || '—'}</td><td class="m">${num(p.acc)}</td><td class="m">${p.red ? num(p.red) : '—'}</td><td class="m"><b>${num(p.net)}</b></td><td>${fd(p.pdt)}</td><td class="m">${p.open ? `<b class="plus">${num(p.open)}</b>` : '<span class="muted">0,00</span>'}</td><td>${status}</td></tr>`;
        if (isOpen) row += `<tr class="detail"><td colspan="8">${periodDetail(S, p)}</td></tr>`;
        return row;
      }).join('') || '<tr><td colspan="8" class="muted">Dövr yoxdur.</td></tr>'}</table></div></div></div>`;
    $('#tab-groups').innerHTML = h;
  }
  function periodDetail(S, p) {
    const rows = S.rows.filter((x) => x.g === p.g && (x.per ? x.per.key : '—') === p.key && !x.zero);
    const cl = {};
    p.lots.forEach((l) => (l.cleared || []).forEach((c) => { cl[c.by] = (cl[c.by] || 0) + c.amt; }));
    const fromCredit = p.lots.reduce((a, l) => a + (l.fromCredit || 0), 0);
    const clRows = Object.entries(cl).map(([id, amt]) => ({ r: st.M.byId[id], amt })).filter((x) => x.r).sort((a, b) => a.r.dt - b.r.dt);
    return `<div class="box">
      <h5>Bu dövrün bütün əməliyyatları (${rows.length})</h5>
      <table class="mini"><tr><th>Yazılış</th><th>Əməliyyat</th><th>Növ</th><th>Ödəmə tarixi</th><th class="m">Məbləğ</th><th class="m">Borca təsir</th></tr>
      ${rows.map((x) => `<tr><td>${esc(x.date)}</td><td>${esc(x.name)}</td><td><span class="chip ${x.kindN}">${esc(x.kind)}</span></td><td>${esc(x.payDate)}</td><td class="m">${num(x.amount)}</td><td class="m">${sgn(x.dBal)}</td></tr>`).join('')}</table>
      <h5>Bu dövrün borcunu nə bağlayıb</h5>
      ${clRows.length || fromCredit ? `<table class="mini"><tr><th>Tarix</th><th>Əməliyyat</th><th class="m">Bağladığı məbləğ</th></tr>${fromCredit ? `<tr><td>—</td><td>Əvvəlki artıq ödəmədən avtomatik</td><td class="m">${num(fromCredit)}</td></tr>` : ''}${clRows.map((x) => `<tr><td>${esc(x.r.date)}</td><td>${esc(x.r.name)}${x.r.kindN === 'pay' && x.r.payTarget && x.r.payTarget !== p.g ? ` <span class="chip adj">${esc(gl(x.r.payTarget))} adı ilə ödənilib</span>` : ''}</td><td class="m">${num(x.amt)}</td></tr>`).join('')}</table>` : '<p class="muted">Hələ heç nə bağlamayıb.</p>'}
      ${p.open ? `<div class="note-box">Açıq qalıq <b>${money(p.open)}</b>. Ödəmə tarixindən ${p.late || 0} gün keçib; bu borca gündə ≈ ${money(Math.round(p.open * A.FAIZ_RATE))} faiz hesablanır.</div>` : ''}
    </div>`;
  }

  // ---------- Əməliyyatlar ----------
  function opsFiltered() {
    const f = st.f, M = st.M;
    let rows = M.rows;
    if (f.ids) { const s = new Set(f.ids); rows = rows.filter((r) => s.has(r.id)); }
    if (f.sec) rows = rows.filter((r) => r.sec === f.sec);
    if (f.g) rows = rows.filter((r) => r.g === f.g || (r.kindN === 'pay' && A.groupOfCode(r.code) === f.g) || (r.alloc && Object.keys(r.alloc).some((k) => k.startsWith(f.g + '|'))));
    if (f.kind) rows = rows.filter((r) => r.kindN === f.kind);
    if (f.year) rows = rows.filter((r) => r.date.endsWith(f.year));
    if (f.hideZero && !f.ids) rows = rows.filter((r) => !r.zero);
    if (f.q) { const q = f.q.toLocaleLowerCase('az'); rows = rows.filter((r) => (r.name + ' ' + r.date + ' ' + r.payDate + ' ' + num(r.amount)).toLocaleLowerCase('az').includes(q)); }
    return rows;
  }
  function explain(x) {
    const out = [];
    if (x.kindN === 'pay') {
      if (x.alloc && Object.keys(x.alloc).length) out.push('bağladı: ' + Object.entries(x.alloc).map(([k, v]) => `${gl(k.split('|')[0])} ${k.split('|')[1] || ''} (${num(v)})`).join(', '));
      if (x.toPenalty) out.push(`faizə: ${num(x.toPenalty)}`);
      if (x.spill) out.push(`artıq ödəmə yaratdı: ${num(x.spill)}`);
      if (x.payTarget && x.alloc && !Object.keys(x.alloc).some((k) => k.startsWith(x.payTarget + '|'))) out.push(`⚠ ${gl(x.payTarget)} adı ilə ödənilib, amma başqa borca yazılıb`);
    } else if (x.zero) out.push('məbləğsiz texniki sətir — qalığa təsiri yoxdur');
    else if (x.kindN === 'acc' && x.dBal !== x.amount && x.amount) out.push(`borca təsiri məbləğdən fərqlidir (${num(x.dBal)})`);
    if (x.kindN === 'acc' && x.pdt && x.dt && A.days(x.pdt, x.dt) > 45 && !/^VAH[İI]D/i.test(x.name)) out.push(`ödəmə tarixindən ${A.days(x.pdt, x.dt)} gün sonra yazılıb`);
    return out.join(' · ');
  }
  function rOps() {
    const M = st.M, f = st.f;
    const secs = Object.values(M.sections);
    const gs = f.sec ? Object.values(M.sections[f.sec].groups) : Object.values(M.sections.tax?.groups || {});
    const years = [...new Set(M.rows.map((r) => r.date.slice(-4)))].sort().reverse();
    const rows = opsFiltered();
    const sum = (k) => rows.filter((r) => r.kindN === k).reduce((a, r) => a + r.amount, 0);
    const shown = rows.slice().reverse().slice(0, f.limit);
    const zeroHidden = !f.ids && f.hideZero ? M.rows.filter((r) => r.zero).length : 0;
    let h = `<div class="filters">
      ${f.ids ? `<span class="idchip">${esc(f.idsLabel || 'Seçilmiş sətirlər')} (${f.ids.length}) <button id="idsX" title="Filtri sil">✕</button></span>` : ''}
      <select id="fSec"><option value="">Bütün bölmələr</option>${secs.map((s) => `<option value="${s.key}" ${f.sec === s.key ? 'selected' : ''}>${esc(s.label)}</option>`).join('')}</select>
      <select id="fG"><option value="">Bütün növlər</option>${gs.map((g) => `<option value="${g.g}" ${f.g === g.g ? 'selected' : ''}>${esc(g.label)}</option>`).join('')}</select>
      <select id="fKind"><option value="">Hesablama, azalma, ödəniş</option>${Object.entries(KIND_LABEL).map(([k, v]) => `<option value="${k}" ${f.kind === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
      <select id="fYear"><option value="">Bütün illər</option>${years.map((y) => `<option ${f.year === y ? 'selected' : ''}>${y}</option>`).join('')}</select>
      <input id="fQ" type="search" placeholder="Axtar: ad, sənəd nömrəsi, tarix, məbləğ" value="${esc(f.q)}">
      <label class="ck"><input id="fZero" type="checkbox" ${f.hideZero ? 'checked' : ''}> Məbləğsiz sətirləri gizlət${zeroHidden ? ` (${zeroHidden})` : ''}</label>
    </div>
    <div class="opsum"><span><b>${rows.length.toLocaleString('az-AZ')}</b> əməliyyat</span><span>Hesablama <b>${money(sum('acc'))}</b></span><span>Azalma <b>${money(sum('red'))}</b></span><span>Ödəniş <b>${money(sum('pay'))}</b></span><span class="muted">Ən yenisi yuxarıda · sətrə basın — izah açılır</span></div>
    <div class="tw tall"><table class="t"><tr><th>Yazılış</th><th>Ödəmə tarixi</th><th>Əməliyyat</th><th>Növ</th><th class="m">Məbləğ</th><th class="m">Borca təsir</th><th class="m">Faizə təsir</th><th class="m">Borc qalığı</th><th class="m">Faiz qalığı</th></tr>
    ${shown.map((x) => {
      const ex = explain(x);
      return `<tr class="click" data-row="${esc(x.id)}"><td>${esc(x.date)}</td><td>${esc(x.payDate)}</td><td>${esc(x.name)}<div>${x.g && x.kindN !== 'pay' ? `<span class="chip g">${esc(gl(x.g))}</span>` : ''}${x.per ? `<span class="chip p">${esc(x.per.label)}</span>` : ''}${x.decl ? `<span class="chip ${x.decl === 'Dəqiqləşdirilmiş' ? 'd' : 'p'}">${esc(x.decl)}</span>` : ''}${x.sec !== 'tax' ? `<span class="chip">${esc(A.SECTION_LABEL[x.sec])}</span>` : ''}</div>${ex ? `<div class="explain">${esc(ex)}</div>` : ''}</td>
        <td><span class="chip ${x.kindN}">${esc(x.kind || '—')}</span></td><td class="m">${num(x.amount)}</td><td class="m">${sgn(x.dBal)}</td><td class="m">${sgn(x.dPen)}</td><td class="m">${x.bal < 0 ? `<span class="minus">artıq ${num(-x.bal)}</span>` : num(x.bal)}</td><td class="m">${num(x.pen)}</td></tr>`;
    }).join('') || '<tr><td colspan="9" class="muted">Uyğun əməliyyat yoxdur.</td></tr>'}</table></div>
    ${rows.length > f.limit ? `<button class="btn more" id="more">Daha ${Math.min(500, rows.length - f.limit)} sətir göstər (cəmi ${rows.length})</button>` : ''}`;
    $('#tab-ops').innerHTML = h;
  }
  function rowDrawer(id) {
    const x = st.M.byId[id]; if (!x) return;
    const S = st.M.sections[x.sec];
    const lots = S.allLots.filter((l) => l.rowId === x.id);
    const cleared = lots.flatMap((l) => (l.cleared || []).map((c) => ({ r: st.M.byId[c.by], amt: c.amt }))).filter((c) => c.r);
    openDrawer(`<h3>${esc(x.name)}</h3><p class="muted">${esc(A.SECTION_LABEL[x.sec])} · sətir ${x.i + 1}</p>
      <div class="kv"><span>Yazılış tarixi</span><b>${esc(x.date)}</b><span>Ödəmə tarixi</span><b>${esc(x.payDate || '—')}</b><span>Əməliyyat növü</span><b>${esc(x.kind)}</b>
      <span>Vergi növü</span><b>${esc(x.kindN === 'pay' ? (x.payTarget ? gl(x.payTarget) + ' (tapşırıqda)' : x.code || '—') : gl(x.g))}</b><span>Dövr</span><b>${esc(x.per ? x.per.label : '—')}</b>${x.decl ? `<span>Bəyannamə</span><b>${esc(x.decl)}</b>` : ''}${x.tags.length ? `<span>İşarələr</span><b>${x.tags.map(esc).join(', ')}</b>` : ''}
      <span>Məbləğ</span><b>${money(x.amount)}</b><span>Əsas borca təsiri</span><b>${sgn(x.dBal)} ₼</b><span>${S.penLabel === "Penya" ? "Penyaya" : "Faizə"} təsiri</span><b>${sgn(x.dPen)} ₼</b><span>Sonra borc qalığı</span><b>${x.bal < 0 ? 'artıq ödəmə ' + money(-x.bal) : money(x.bal)}</b><span>Sonra ${S.penLabel.toLowerCase()} qalığı</span><b>${money(x.pen)}</b></div>
      ${explainLong(x, lots, cleared)}`);
  }
  function explainLong(x, lots, cleared) {
    const p = [];
    if (x.kindN === 'pay') {
      p.push(`Bu ödəniş ${money(x.amount)}-dır. ${x.toPrincipal ? `Əsas borcu ${money(x.toPrincipal)} azaldıb` : 'Əsas borcu azaltmayıb'}${x.toPenalty ? `, ${money(x.toPenalty)} faizə gedib` : ''}${x.spill ? `, ${money(x.spill)} artıq ödəmə kimi qalıb` : ''}.`);
      if (x.alloc && Object.keys(x.alloc).length) p.push('Vahid hesab qaydası ilə bağladığı borclar (ödəmə tarixi ən köhnə olandan başlayaraq):<br>' + Object.entries(x.alloc).map(([k, v]) => `• ${esc(gl(k.split('|')[0]))} ${esc(k.split('|')[1] || '')} — ${money(v)}`).join('<br>'));
      if (x.payTarget && x.alloc && !Object.keys(x.alloc).some((k) => k.startsWith(x.payTarget + '|'))) p.push(`<b>Diqqət:</b> tapşırıqda “${esc(gl(x.payTarget))}” yazılıb, amma pul köhnə borcu bağlayıb. Ona görə ${esc(gl(x.payTarget))} üzrə cari borc açıq qalıb və faiz yaradır.`);
    } else if (x.zero) p.push('Bu sətir məbləğsizdir — vərəqəyə texniki qeyd kimi düşüb (məsələn, vahid bəyannamədə ödəniş edilməyən ay). Qalığa təsiri yoxdur.');
    else {
      if (x.dBal > 0) p.push(`Bu əməliyyat əsas borcu ${money(x.dBal)} artırıb. Faiz ödəmə tarixindən (${esc(x.payDate)}) sonra ödənilməyən hissəyə hesablanır.`);
      if (x.dBal < 0) p.push(`Bu əməliyyat əsas borcu ${money(-x.dBal)} azaldıb${x.decl === 'Dəqiqləşdirilmiş' ? ' — adətən dəqiqləşdirilmiş bəyannamə əvvəlki hesablamanı azaldır və yenisini yazır' : ''}.`);
      if (x.amount && x.dBal && Math.abs(x.dBal) !== x.amount) p.push(`Məbləğ (${money(x.amount)}) ilə qalığa təsir (${money(Math.abs(x.dBal))}) fərqlidir — fərq eyni sətirdə faiz/qalıq düzəlişindən yaranır.`);
      if (cleared.length) p.push('Bu hesablamanın borcunu bağlayanlar:<br>' + cleared.map((c) => `• ${esc(c.r.date)} ${esc(c.r.name)} — ${money(c.amt)}`).join('<br>'));
      const open = lots.reduce((a, l) => a + l.amt, 0);
      if (open) p.push(`<b>Hələ açıq: ${money(open)}</b>.`);
    }
    return p.map((t) => `<div class="note-box">${t}</div>`).join('');
  }

  // ---------- Sual ver ----------
  const SUGG = ['Ümumi borc nə qədərdir?', 'Nə etməliyəm?', 'Faiz niyə bu qədərdir?', 'Son ödənişlər hara gedib?', 'Hansı borcların vaxtı keçib?', 'ƏDV borcu hansı aylardandır?', 'Mənfəət vergisi borcu', 'Bu il nə qədər ödənilib?', 'Artıq ödəmə varmı?', 'Pensiya (MDSS) borcu'];
  function rAsk() {
    $('#chatSugg').innerHTML = SUGG.map((s) => `<button>${esc(s)}</button>`).join('');
    if (!$('#chatLog').children.length) addMsg('bot', `<p>Salam! Mən <b>${esc(st.M.entity.name || 'şirkətin')}</b> şəxsi hesab vərəqəsini oxumuşam (${st.M.rows.length.toLocaleString('az-AZ')} əməliyyat). Borc, faiz, ödəniş, dövr, vergi növü — istədiyinizi soruşun.</p>`);
    $('#chatQ').focus();
  }
  function addMsg(who, html) { const d = document.createElement('div'); d.className = 'msg ' + who; d.innerHTML = html; $('#chatLog').appendChild(d); d.scrollIntoView({ block: 'end', behavior: 'smooth' }); }
  function ask(q) { if (!q.trim()) return; addMsg('me', esc(q)); const r = K.answer(st.M, q); addMsg('bot', r.html); }

  // ---------- Drawer ----------
  function openDrawer(html) { $('#drawerBody').innerHTML = html; $('#drawer').classList.remove('hidden'); }
  function closeDrawer() { $('#drawer').classList.add('hidden'); }

  // ---------- Excel ----------
  function exportXlsx() {
    const M = st.M; if (!M) return;
    const c = (v) => Math.round(v) / 100;
    const wb = XLSX.utils.book_new();
    const sh = (name, aoa, w) => { const ws = XLSX.utils.aoa_to_sheet(aoa); if (w) ws['!cols'] = w.map((x) => ({ wch: x })); XLSX.utils.book_append_sheet(wb, ws, name); };
    sh('İcmal', [['Vergi ödəyicisi', M.entity.name], ['VÖEN', M.entity.voen], ['Məlumat tarixi', fd(M.asOf)], ['Mənbə', st.raw.source], [], ['Cəmi ödənməli', c(M.totals.total)], ['Əsas borc', c(M.totals.principal)], ['Faiz / penya', c(M.totals.penalty)], [],
      ['Bölmə', 'Əsas borc', 'Faiz / penya'], ...Object.values(M.sections).map((s) => [s.label, c(s.finalBal), c(s.finalPen)])], [28, 22, 18]);
    sh('Uyğunsuzluqlar', [['Ciddilik', 'Məsələ', 'Məbləğ', 'İzah', 'Nə etməli', 'Qərar', 'Qeyd'], ...M.findings.map((f) => [SEV[f.sev], f.title, c(f.impact || 0), f.text, f.action || '', (STAT.find((s) => s[0] === (decOf(f.id)?.s || 'open')) || [, 'Açıq'])[1], decOf(f.id)?.n || ''])], [12, 60, 16, 90, 60, 14, 30]);
    const gRows = [['Bölmə', 'Növ', 'Hesablanıb', 'Azaldılıb', 'Bu adla ödənilib', 'Açıq borc', 'Artıq ödəmə', 'Kodlar']];
    Object.values(M.sections).forEach((s) => Object.values(s.groups).forEach((g) => gRows.push([s.label, g.label, c(g.acc), c(g.red), c(g.paid), c(g.debt), c(g.credit), g.codes.join(', ')])));
    sh('Vergi növləri', gRows, [20, 30, 16, 16, 16, 16, 14, 30]);
    const pRows = [['Bölmə', 'Növ', 'Dövr', 'Bəyannamələr', 'Hesablanıb', 'Azaldılıb', 'Yekun', 'Açıq qalıq']];
    Object.values(M.sections).forEach((s) => s.periods.slice().sort((a, b) => String(b.key).localeCompare(String(a.key))).forEach((p) => pRows.push([s.label, gl(p.g), p.label, p.decls.join(', '), c(p.acc), c(p.red), c(p.net), c(p.open || 0)])));
    sh('Dövrlər', pRows, [20, 28, 16, 26, 14, 14, 14, 14]);
    sh('Əməliyyatlar', [['Bölmə', 'Yazılış', 'Ödəmə tarixi', 'Əməliyyat', 'Növ', 'Vergi növü', 'Dövr', 'Məbləğ', 'Borca təsir', 'Faizə təsir', 'Borc qalığı', 'Faiz qalığı', 'İzah'],
      ...M.rows.map((x) => [A.SECTION_LABEL[x.sec], x.date, x.payDate, x.name, x.kind, x.kindN === 'pay' ? gl(x.payTarget) : gl(x.g), x.per ? x.per.label : '', c(x.amount), c(x.dBal), c(x.dPen), c(x.bal), c(x.pen), explain(x)])], [16, 11, 11, 50, 12, 22, 14, 14, 14, 14, 14, 14, 60]);
    XLSX.writeFile(wb, `Sexsi_hesab_analiz_${M.entity.voen || ''}_${A.iso(M.asOf)}.xlsx`);
  }

  // ================= Hadisələr =================
  function goRows(ids, label) { st.f = { ...st.f, ids, idsLabel: label, sec: '', g: '', kind: '', year: '', q: '', limit: 300 }; setTab('ops'); }
  document.addEventListener('click', (e) => {
    const t = e.target;
    const tab = t.closest('#tabs button'); if (tab) return setTab(tab.dataset.tab);
    if (t.closest('#drawerX') || t.id === 'drawer') return closeDrawer();
    const al = t.closest('.ask-link');
    if (al) {
      if (al.dataset.ids) return goRows(al.dataset.ids.split(',').filter(Boolean), 'Köməkçidən');
      if (al.dataset.go === 'group') { st.sec = al.dataset.section || 'tax'; st.group = al.dataset.group; st.openP = null; return setTab('groups'); }
      if (al.dataset.go === 'findings') return setTab('findings');
    }
    const todo = t.closest('.todo .card'); if (todo) { setTab('findings'); setTimeout(() => document.getElementById('F-' + todo.dataset.fid)?.scrollIntoView({ block: 'center' }), 50); return; }
    const br = t.closest('.barrow,[data-group]');
    if (br && br.dataset.group) { st.sec = br.dataset.sec || 'tax'; st.group = br.dataset.group; st.openP = null; return setTab('groups'); }
    const secRow = t.closest('tr[data-sec]'); if (secRow) { st.sec = secRow.dataset.sec; st.group = null; return setTab('groups'); }
    const sv = t.closest('#fsev button'); if (sv) { st.fsev = sv.dataset.v; return rFindings(); }
    const ss = t.closest('#fstat button'); if (ss) { st.fstat = ss.dataset.v; return rFindings(); }
    const fr = t.closest('[data-rows]'); if (fr) { const f = st.M.findings.find((x) => x.id === fr.dataset.rows); return goRows(f.rows, f.title.slice(0, 60)); }
    const ft = t.closest('[data-tpl]'); if (ft) return showTemplate(st.M.findings.find((x) => x.id === ft.dataset.tpl));
    const sw = t.closest('[data-secsw]'); if (sw) { st.sec = sw.dataset.secsw; st.group = null; st.openP = null; return rGroups(); }
    const gi = t.closest('.gitem'); if (gi) { st.group = gi.dataset.g; st.openP = null; st.pYear = ''; return rGroups(); }
    const po = t.closest('#ponly button'); if (po) { st.pOnlyOpen = po.dataset.v === '1'; return rGroups(); }
    const pr = t.closest('tr[data-p]'); if (pr) { st.openP = st.openP === pr.dataset.p ? null : pr.dataset.p; return rGroups(); }
    const orow = t.closest('tr[data-row]'); if (orow) return rowDrawer(orow.dataset.row);
    if (t.id === 'more') { st.f.limit += 500; return rOps(); }
    if (t.id === 'idsX') { st.f.ids = null; return rOps(); }
    const sg = t.closest('#chatSugg button'); if (sg) return ask(sg.textContent);
  });
  document.addEventListener('change', (e) => {
    const t = e.target;
    if (t.dataset.dec) { setDecision(t.dataset.dec, { s: t.value }); showApp(); return; }
    if (t.dataset.note) { setDecision(t.dataset.note, { n: t.value }); toast('Qeyd yadda saxlanıldı'); return; }
    const map = { fSec: 'sec', fG: 'g', fKind: 'kind', fYear: 'year' };
    if (map[t.id]) { st.f[map[t.id]] = t.value; if (t.id === 'fSec') st.f.g = ''; st.f.limit = 300; return rOps(); }
    if (t.id === 'fZero') { st.f.hideZero = t.checked; return rOps(); }
    if (t.id === 'pyear') { st.pYear = t.value; return rGroups(); }
  });
  let qT = null;
  document.addEventListener('input', (e) => { if (e.target.id === 'fQ') { clearTimeout(qT); const v = e.target.value; qT = setTimeout(() => { st.f.q = v; st.f.limit = 300; rOps(); const i = $('#fQ'); i.focus(); i.setSelectionRange(v.length, v.length); }, 250); } });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDrawer(); });
  $('#chatForm').addEventListener('submit', (e) => { e.preventDefault(); const q = $('#chatQ').value; $('#chatQ').value = ''; ask(q); });
  $('#fileInput').addEventListener('change', (e) => { loadFiles([...e.target.files]); e.target.value = ''; });
  $('#dropInput').addEventListener('change', (e) => { loadFiles([...e.target.files]); e.target.value = ''; });
  $('#etaxBtn').addEventListener('click', loadEtax);
  $('#exportBtn').addEventListener('click', exportXlsx);
  const drop = $('#drop');
  ['dragenter', 'dragover'].forEach((ev) => document.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((ev) => document.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  document.addEventListener('drop', (e) => { if (e.dataTransfer?.files?.length) loadFiles([...e.dataTransfer.files]); });
  try { chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch[DEC] && st.M) { st.dec = ch[DEC].newValue || {}; if (st.tab === 'findings' && !document.activeElement?.dataset?.note) rFindings(); } }); } catch (e) { /* */ }

  (async () => { await loadDecisions(); await restore(); })();
})();
