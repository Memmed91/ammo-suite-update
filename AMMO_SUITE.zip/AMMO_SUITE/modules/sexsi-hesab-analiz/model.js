/* AMMO — Şəxsi hesab vərəqəsi ANALİZ mühərriki (UI yoxdur).
   Giriş: SHEngine (../sexsi-hesab/engine.js) ilə oxunmuş vərəqə.
   Çıxış: vergi növləri → dövrlər → açıq borclar, ödənişlərin hara getdiyi, faiz, uyğunsuzluqlar.
   Bütün məbləğlər qəpiklə (tam ədəd). Qalıq işarəsi: + borc, − artıq ödəmə. */
(function (root) {
  'use strict';
  const E = root.SHEngine;
  const DAY = 86400000;
  const FAIZ_RATE = 0.001; // gündə 0,1% (vərəqədəki faiz tarixçəsində yoxlanılıb)

  // ---------- Vergi növləri ----------
  // Ödənişlər vergi koduna gedir; eyni koda ödənilən növlər bir "qrup"da birləşir.
  const GROUPS = {
    EDV: { label: 'ƏDV', full: 'Əlavə dəyər vergisi' },
    MV: { label: 'Mənfəət vergisi', full: 'Mənfəət vergisi' },
    OMV: { label: 'ÖMV', full: 'Ödəmə mənbəyində vergi' },
    MUZDLU: { label: 'Muzdlu işdən gəlir vergisi', full: 'Muzdlu işdən gəlir vergisi (MÖMV / vahid bəyannamə)' },
    EMLAK: { label: 'Əmlak vergisi', full: 'Əmlak vergisi' },
    TORPAQ: { label: 'Torpaq vergisi', full: 'Torpaq vergisi' },
    YOL: { label: 'Yol vergisi', full: 'Yol vergisi' },
    SV: { label: 'Sadələşdirilmiş vergi', full: 'Sadələşdirilmiş vergi' },
    AKSIZ: { label: 'Aksiz', full: 'Aksiz' },
    MEDEN: { label: 'Mədən vergisi', full: 'Mədən vergisi' },
    GV: { label: 'Gəlir vergisi', full: 'Gəlir vergisi (fərdi sahibkar)' },
    SANK: { label: 'Maliyyə sanksiyaları', full: 'Maliyyə sanksiyaları (vergi orqanının qərarı ilə)' },
    OPEN: { label: 'Açılış qalığı', full: 'Vərəqənin əvvəlindən gələn qalıq' },
    OTHER: { label: 'Digər əməliyyatlar', full: 'Növü müəyyən olunmayan əməliyyatlar' },
    // sosial bölmələr
    'S:EDEN': { label: 'Sığortaedən (işəgötürən)', full: 'Sığortaedənin (işəgötürənin) haqqı' },
    'S:OLUNAN': { label: 'Sığortaolunan (işçidən tutulan)', full: 'Sığortaolunandan (işçidən) tutulan haqq' },
    'S:MULKI': { label: 'Mülki müqavilə', full: 'Mülki-hüquqi müqavilə üzrə haqq' },
    'S:FIZIKI': { label: 'Fiziki şəxs / F/Ş özü', full: 'Fiziki şəxsin / fərdi sahibkarın öz haqqı' },
    'S:SANATORIYA': { label: 'Sanatoriya', full: 'Sanatoriya-kurort' },
    'S:OTHER': { label: 'Digər', full: 'Növü müəyyən olunmayan' }
  };
  const CODE_GROUP = [
    [/^(ƏDV|EDV)$/, 'EDV'], [/^MV$/, 'MV'], [/^ÖMV$/, 'OMV'], [/^(MÖMV|VAHID MUZDLU|VAHİD MUZDLU|MUZDLU)$/, 'MUZDLU'],
    [/^(HŞƏV|ƏV|EV|ƏMLAK)$/, 'EMLAK'], [/^(HŞTV|TV|TORPAQ)$/, 'TORPAQ'], [/^(HŞYV|YV|YOL)$/, 'YOL'],
    [/^(SV|SVY|SADƏ)$/, 'SV'], [/^AKSİZ$/, 'AKSIZ'], [/^MƏDƏN$/, 'MEDEN'], [/^(GV|FŞGV)$/, 'GV']
  ];
  const SECTION_LABEL = { tax: 'Vergilər', mdss: 'MDSS (pensiya)', unemp: 'İşsizlikdən sığorta', its: 'İcbari tibbi sığorta' };
  const SECTION_PEN = { tax: 'Faiz', mdss: 'Penya', unemp: 'Penya', its: 'Faiz' };

  const U = (s) => String(s || '').toLocaleUpperCase('az');
  const toDate = (s) => { const m = String(s || '').match(/(\d{1,2})[./](\d{1,2})[./](\d{4})/); return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null; };
  const days = (a, b) => (a && b ? Math.round((b - a) / DAY) : 0);
  const iso = (d) => (d ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` : '');

  function codeOf(name, kindN) {
    const n = U(name).replace(/\s+/g, ' ').trim();
    if (kindN === 'pay') {
      const tail = n.split(/\s-\s|\s-$/).filter((x) => x.trim()).pop() || '';
      return tail.replace(/^[-\s]+/, '').replace(/[0-9]+$/, '').trim();
    }
    const m = n.match(/^([A-ZƏÖÜĞÇŞİI]+(?: [A-ZƏÖÜĞÇŞİI]+)*?)(?=\s*(?:-|\d|\(|\/|$))/);
    return m ? m[1].trim() : '';
  }
  function groupOfCode(code) {
    for (const [rx, g] of CODE_GROUP) if (rx.test(code)) return g;
    return null;
  }
  function periodOf(name) {
    const n = String(name || '');
    let m = n.match(/\b(\d{4})\/(\d{2})\b/);
    if (m) return { key: `${m[1]}-${m[2]}`, label: `${m[2]}.${m[1]}`, y: +m[1], sort: +m[1] * 100 + +m[2] };
    m = n.match(/(\d)\s*\.?\s*R[üu]b\s*(\d{4})/i) || n.match(/(\d{4})\s*(\d)\s*\.?\s*R[üu]b/i);
    if (m) { const y = m[1].length === 4 ? +m[1] : +m[2], q = m[1].length === 4 ? +m[2] : +m[1]; return { key: `${y}-Q${q}`, label: `${q}-ci rüb ${y}`, y, sort: y * 100 + q * 3 }; }
    m = n.match(/\b(19\d{2}|20\d{2})\b/);
    if (m) return { key: `${m[1]}`, label: `${m[1]}-ci il`, y: +m[1], sort: +m[1] * 100 + 13 };
    return null;
  }
  function declOf(name) {
    const u = U(name);
    if (/DƏQİQLƏŞ/.test(u)) return 'Dəqiqləşdirilmiş';
    if (/LƏĞV/.test(u)) return 'Ləğv';
    if (/CARİ/.test(u)) return 'Cari';
    return '';
  }
  function tagsOf(name) { return [...String(name || '').matchAll(/\(([A-ZƏÖÜĞÇŞİ]{1,6})\)/g)].map((m) => m[1]); }
  function kindOf(k) {
    const f = U(k);
    if (/HESABLAMA/.test(f)) return 'acc';
    if (/AZALMA/.test(f)) return 'red';
    if (/ÖDƏNİŞ|ODENIS/.test(f)) return 'pay';
    return 'adj';
  }
  function payDocOf(name) { const m = String(name).match(/^(.*?)\s*-\s*([A-Z]*\d[\w]*)\s*-/); return m ? { doc: m[1].trim(), no: m[2] } : null; }

  // ---------- Qrup üzrə FIFO hesabı ----------
  function makeBook() { return { lots: {}, credit: {}, general: 0, all: [] }; }
  function lotsOf(B, g) { return (B.lots[g] = B.lots[g] || []); }
  function addDebt(B, g, amt, lot) {
    if (amt <= 0) return;
    let a = amt;
    const c = B.credit[g] || 0;
    lot.fromCredit = 0;
    if (c > 0) { const u = Math.min(c, a); B.credit[g] = c - u; a -= u; lot.fromCredit += u; }
    if (a > 0 && B.general > 0) { const u = Math.min(B.general, a); B.general -= u; a -= u; lot.fromCredit += u; }
    const rec = { ...lot, amt: a, orig: amt };
    B.all.push(rec);
    if (a > 0) lotsOf(B, g).push(rec);
  }
  /** borcu azalt: əvvəl istənilən dövr, sonra ən köhnə ödəmə tarixi. Qalan → həmin qrupun artıq ödəməsi. */
  function reduce(B, g, amt, prefKey, by, noCredit) {
    let r = amt;
    const L = lotsOf(B, g);
    const take = (lot) => { const u = Math.min(lot.amt, r); lot.amt -= u; r -= u; (lot.cleared = lot.cleared || []).push({ by, amt: u }); };
    if (prefKey) for (const lot of L) { if (r <= 0) break; if (lot.amt > 0 && lot.pkey === prefKey) take(lot); }
    const ordered = L.filter((l) => l.amt > 0).sort((a, b) => (a.pdt || 0) - (b.pdt || 0));
    for (const lot of ordered) { if (r <= 0) break; take(lot); }
    B.lots[g] = L.filter((l) => l.amt > 0 || l.keep);
    if (r > 0 && !noCredit) B.credit[g] = (B.credit[g] || 0) + r;
    return r; // borcdan artıq qalan hissə
  }
  /** Qrupu məlum olmayan azalma — bütün qruplarda ən köhnə borc */
  function reduceAny(B, amt, by, alloc) {
    let r = amt;
    const all = Object.entries(B.lots).flatMap(([g, L]) => L.filter((l) => l.amt > 0).map((l) => ({ g, l }))).sort((a, b) => (a.l.pdt || 0) - (b.l.pdt || 0));
    for (const { g, l } of all) {
      if (r <= 0) break; const u = Math.min(l.amt, r); l.amt -= u; r -= u; (l.cleared = l.cleared || []).push({ by, amt: u });
      if (alloc) { const k = g + '|' + (l.plabel || l.pkey); alloc[k] = (alloc[k] || 0) + u; }
    }
    for (const g in B.lots) B.lots[g] = B.lots[g].filter((l) => l.amt > 0);
    if (r > 0) B.general += r;
    return r;
  }
  const sumLots = (L) => (L || []).reduce((a, l) => a + l.amt, 0);

  // ---------- Bölmənin analizi ----------
  function analyzeSection(sec, ctx) {
    const isTax = sec.key === 'tax';
    const rows = sec.rows;
    const B = makeBook();
    const periods = {}; // g|pkey → statistika
    const P = (g, per) => {
      const k = g + '|' + (per ? per.key : '—');
      return (periods[k] = periods[k] || { g, key: per ? per.key : '—', label: per ? per.label : 'Dövr göstərilməyib', sort: per ? per.sort : 0, acc: 0, red: 0, paid: 0, decls: new Set(), rowIds: [], pdts: [], accRows: 0 });
    };
    // açılış
    const r0 = rows[0];
    const open = r0 ? r0.bal - (r0.dBal || 0) : 0;
    if (open > 0) addDebt(B, 'OPEN', open, { g: 'OPEN', pkey: 'OPEN', plabel: 'Açılış', pdt: toDate(r0.date), rowId: null });
    else if (open < 0) B.general = -open;
    let faizPaid = 0, faizAccrued = 0, faizReduced = 0;
    const out = [];
    rows.forEach((r, i) => {
      const kindN = kindOf(r.kind);
      const code = codeOf(r.name, kindN);
      let g;
      if (isTax) g = /-\s*MS\s*-|SANKSİYA/.test(U(r.name)) && kindN !== 'pay' ? 'SANK' : (groupOfCode(code) || (kindN === 'pay' ? null : (/SALDO/.test(U(r.name)) ? null : 'OTHER')));
      else {
        const c = r.cat && r.cat.split(':')[1];
        g = kindN === 'pay' ? null : 'S:' + (c === 'EDEN' || c === 'SIGORTALI' ? 'EDEN' : c === 'OLUNAN' ? 'OLUNAN' : c === 'MULKI' ? 'MULKI' : c === 'FIZIKI' || c === 'FS' ? 'FIZIKI' : c === 'SANATORIYA' ? 'SANATORIYA' : 'OTHER');
      }
      const per = kindN === 'pay' ? null : periodOf(r.name);
      const dt = toDate(r.date), pdt = toDate(r.payDate);
      const x = {
        id: sec.key + ':' + i, sec: sec.key, i, date: r.date, payDate: r.payDate, dt, pdt, name: r.name, kind: r.kind, kindN,
        amount: r.amount, bal: r.bal, pen: r.pen, dBal: r.dBal || 0, dPen: r.dPen || 0,
        code, g, per, decl: declOf(r.name), tags: tagsOf(r.name), pay: kindN === 'pay' ? payDocOf(r.name) : null,
        zero: !r.amount && !r.dBal && !r.dPen, notes: []
      };
      // ödənişin bölgüsü: əsas borca / faizə
      if (kindN === 'pay') {
        x.toPrincipal = Math.max(0, -x.dBal);
        x.toPenalty = Math.max(0, Math.min(x.amount - x.toPrincipal, x.dPen < 0 ? -x.dPen : x.amount - x.toPrincipal));
        faizPaid += x.toPenalty;
        if (x.dPen > 0) faizAccrued += x.dPen;
      } else {
        if (x.dPen > 0) faizAccrued += x.dPen; else if (x.dPen < 0) faizReduced += -x.dPen;
      }
      // əsas borc kitabı
      const d = x.dBal;
      if (d > 0) {
        const gg = g || 'OTHER';
        if (per || gg) { const st = P(gg, per); }
        addDebt(B, gg, d, { g: gg, pkey: per ? per.key : '—', plabel: per ? per.label : '', pdt: pdt || dt, rowId: x.id });
      } else if (d < 0) {
        // Ödəniş: vahid hesab — ödəmə tarixi ən köhnə olan borc bağlanır (kabinetin rəsmi bölgüsü belədir).
        // Azalma / düzəliş: əvvəlcə həmin vergi və dövr, sonra həmin vergi, sonra ən köhnə borc.
        if (kindN === 'pay' || !g) { x.alloc = {}; const over = reduceAny(B, -d, x.id, x.alloc); if (over > 0) x.spill = over; }
        else {
          let over = reduce(B, g, -d, per ? per.key : null, x.id, true);
          if (over > 0) over = reduceAny(B, over, x.id);
          if (over > 0) x.spill = over;
        }
        x.payTarget = kindN === 'pay' ? groupOfCode(x.code) : null;
      }
      // dövr statistikası
      if (g && kindN !== 'pay') {
        const st = P(g, per);
        if (kindN === 'acc') { st.acc += x.amount; st.accRows++; } else if (kindN === 'red') st.red += x.amount;
        if (x.decl) st.decls.add(x.decl);
        st.rowIds.push(x.id);
        if (pdt) st.pdts.push(pdt);
      }
      out.push(x);
    });
    // nəticə qrupları
    const last = rows[rows.length - 1];
    const groups = {};
    const gKeys = new Set([...Object.keys(B.lots), ...Object.keys(B.credit), ...out.map((x) => x.g).filter(Boolean)]);
    for (const g of gKeys) {
      const L = (B.lots[g] || []).filter((l) => l.amt > 0);
      const rs = out.filter((x) => x.g === g);
      const payRows = out.filter((x) => x.kindN === 'pay' && groupOfCode(x.code) === g);
      groups[g] = {
        g, label: (GROUPS[g] || { label: g }).label, full: (GROUPS[g] || { full: g }).full,
        debt: sumLots(L), credit: B.credit[g] || 0, lots: L,
        acc: rs.filter((x) => x.kindN === 'acc').reduce((a, x) => a + x.amount, 0),
        red: rs.filter((x) => x.kindN === 'red').reduce((a, x) => a + x.amount, 0),
        paid: payRows.reduce((a, x) => a + x.amount, 0), payCount: payRows.length,
        codes: [...new Set(rs.map((x) => x.code).filter(Boolean))],
        rows: rs.length, lastDate: rs.length ? rs[rs.length - 1].dt : null
      };
    }
    // dövrlərin qalığı (açıq lotlar dövr üzrə)
    for (const [g, L] of Object.entries(B.lots)) for (const l of L) {
      if (l.amt <= 0) continue;
      const k = g + '|' + l.pkey;
      const st = periods[k] || (periods[k] = { g, key: l.pkey, label: l.plabel || l.pkey, sort: 0, acc: 0, red: 0, paid: 0, decls: new Set(), rowIds: [], pdts: [], accRows: 0 });
      st.open = (st.open || 0) + l.amt;
      st.oldestPdt = !st.oldestPdt || (l.pdt && l.pdt < st.oldestPdt) ? l.pdt : st.oldestPdt;
    }
    const periodList = Object.values(periods).map((p) => ({ ...p, decls: [...p.decls], net: p.acc - p.red, open: p.open || 0 }));
    return {
      key: sec.key, label: SECTION_LABEL[sec.key] || sec.key, penLabel: SECTION_PEN[sec.key] || 'Faiz',
      rows: out, groups, periods: periodList, book: B, allLots: B.all,
      opening: open, finalBal: last ? last.bal : 0, finalPen: last ? last.pen : 0,
      generalCredit: B.general, faizPaid, faizAccrued, faizReduced,
      firstDate: rows.length ? toDate(rows[0].date) : null, lastDate: last ? toDate(last.date) : null
    };
  }

  // ---------- Rəsmi qalıqlar (kabinet: /budget/liabilities) ----------
  function officialFromLiabilities(j) {
    if (!j || !j.taxLiabilities) return null;
    const list = (j.taxLiabilities.budgetLiabilities || []).map((x) => {
      const name = x.budgetClassificationName?.az || '';
      const f = U(name);
      let g = null;
      if (/ƏLAVƏ DƏYƏR/.test(f)) g = 'EDV'; else if (/MƏNFƏƏT/.test(f)) g = 'MV'; else if (/MUZDLU/.test(f)) g = 'MUZDLU';
      else if (/DİVİDEND|FAİZ|İCARƏ|ROYALTİ|ÖDƏMƏ MƏNBƏYİ/.test(f)) g = 'OMV'; else if (/ƏMLAK/.test(f)) g = 'EMLAK'; else if (/TORPAQ/.test(f)) g = 'TORPAQ';
      else if (/YOL/.test(f)) g = 'YOL'; else if (/SADƏLƏŞ/.test(f)) g = 'SV'; else if (/AKSİZ/.test(f)) g = 'AKSIZ'; else if (/MƏDƏN/.test(f)) g = 'MEDEN';
      const c = (v) => Math.round((Number(v) || 0) * 100);
      return {
        kbt: x.budgetClassificationCode, name, g, sheet: x.categoryName?.az || '',
        principal: c(x.overdueDebt?.taxPayments) + c(x.accruedDebt?.taxPayments), faiz: c(x.overdueDebt?.fine) + c(x.accruedDebt?.fine),
        sanction: c(x.overdueDebt?.penalty) + c(x.accruedDebt?.penalty), overpay: c(x.overpayment), toPay: c(x.toPayByBudget), unverified: c(x.unverifiedReductions)
      };
    });
    const soc = j.socialLiabilities || {};
    const socTot = (o) => (o?.activityLiabilities || []).reduce((a, x) => a + Math.round((Number(x.toPayByActivity) || 0) * 100), 0);
    return {
      at: j.informationOn || '', list,
      social: { mdss: socTot(soc.pensionContributionLiabilities), unemp: socTot(soc.socialInsuranceLiabilities), unallocated: Math.round((Number(soc.pensionContributionLiabilities?.unallocatedSocialBenefits) || 0) * 100) + Math.round((Number(soc.socialInsuranceLiabilities?.unallocatedSocialBenefits) || 0) * 100) }
    };
  }

  // ---------- Faiz tarixçəsi (istəyə görə) ----------
  function parseFaizReport(items) {
    // sətir: tarix | ad | növ | ödəmə tarixi | məbləğ | cəmi qalıq | faiz hesablanan | faiz hesablanmayan | artıq ödəmə | gün | hesablanmış | silinmiş | faiz qalıq
    const rows = [];
    let inTax = false, seen = false;
    for (const it of items) {
      if (it.type === 'heading') { const f = E.fold(it.text); if (/VERGILER UZRE/.test(f)) { inTax = true; seen = true; } else if (/MDSS|ISSIZLIK|TIBBI/.test(f)) inTax = false; continue; }
      const c = it.cells;
      if (!/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(c[0] || '') || c.length !== 13) continue;
      if (seen && !inTax) continue;
      rows.push({ date: c[0], name: c[1], kind: c[2], payDate: c[3], amount: E.cents(c[4]), total: E.cents(c[5]), base: E.cents(c[6]), nobase: E.cents(c[7]), over: E.cents(c[8]), days: Number(c[9]) || 0, accrued: E.cents(c[10]), written: E.cents(c[11]), faiz: E.cents(c[12]) });
    }
    return rows;
  }

  // ---------- Uyğunsuzluqlar ----------
  // e-taxes formatı: 309.598,66 (brauzerin dil ayarından asılı deyil)
  const fmt = (c) => { const neg = c < 0; const v = Math.abs(Math.round(c)); const i = String(Math.floor(v / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); return (neg ? '−' : '') + i + ',' + String(v % 100).padStart(2, '0'); };
  const money = (c) => fmt(c) + ' ₼';
  function findings(M) {
    const F = [];
    const add = (o) => F.push({ id: o.type + ':' + (o.key || F.length), ...o });
    const T = M.sections.tax;
    const today = M.asOf;
    const allSecs = Object.values(M.sections);

    // 0) Uyğunlaşdırma — vərəqənin öz yekunu ilə
    if (T) {
      const sumDebt = Object.values(T.groups).reduce((a, g) => a + g.debt, 0) - Object.values(T.groups).reduce((a, g) => a + g.credit, 0) - T.generalCredit;
      if (Math.abs(sumDebt - T.finalBal) > 1) add({ type: 'recon', key: 'tax-book', sev: 'high', title: 'Hesablanan qalıq vərəqənin son qalığı ilə uyğun gəlmir', impact: Math.abs(sumDebt - T.finalBal), text: `Vergi növləri üzrə toplanan qalıq ${money(sumDebt)}, vərəqədəki son qalıq isə ${money(T.finalBal)}. Fərq ${money(sumDebt - T.finalBal)}. Bu, vərəqədə tanınmayan əməliyyat olduğunu göstərir — "Digər əməliyyatlar" bölməsinə baxın.`, action: 'Fərqi yaradan sətirləri "Əməliyyatlar" bölməsində "Digər" filtri ilə yoxlayın.' });
      const tot = M.summary['CEMI ODENMELI BORC'];
      const pf = M.summary['CAP TARIXINE FAIZ BORCU'];
      if (tot != null) {
        const t = E.cents(tot), f = pf != null ? E.cents(pf) : T.finalPen;
        const principal = Math.max(0, T.finalBal);
        if (Math.abs(t - (principal + f)) > 1) add({ type: 'recon', key: 'summary', sev: 'med', title: 'Vərəqənin yekun cədvəli sətirlərlə tam üst-üstə düşmür', impact: Math.abs(t - principal - f), text: `Yekunda "Cəmi ödənməli borc" ${money(t)} göstərilib. Sətirlərə görə: əsas borc ${money(principal)} + faiz ${money(f)} = ${money(principal + f)}.`, action: 'Fərq çap tarixinədək hesablanmış faizdən və ya vərəqəyə düşməmiş əməliyyatdan ola bilər. Vergi orqanından üzləşmə aktı istəyin.' });
        else add({ type: 'ok', key: 'summary', sev: 'ok', title: 'Vərəqənin yekunu sətirlərlə qəpiyinədək üst-üstə düşür', impact: 0, text: `Cəmi ödənməli borc ${money(t)} = əsas borc ${money(principal)} + faiz ${money(f)}.` });
      }
    }
    // 1) Rəsmi kabinet qalıqları ilə müqayisə
    if (M.official && T) {
      const off = {};
      for (const x of M.official.list) { const g = x.g || 'OTHER'; off[g] = off[g] || { principal: 0, faiz: 0, sanction: 0, overpay: 0, names: [] }; off[g].principal += x.principal; off[g].faiz += x.faiz; off[g].sanction += x.sanction; off[g].overpay += x.overpay; off[g].names.push(x.name); }
      M.officialByGroup = off;
      for (const [g, o] of Object.entries(off)) {
        const mine = T.groups[g] ? T.groups[g].debt - T.groups[g].credit : 0;
        const theirs = o.principal + o.sanction - o.overpay;
        if (Math.abs(mine - theirs) > 100) add({ type: 'official', key: g, sev: 'med', title: `${(GROUPS[g] || { label: g }).label}: vərəqədən hesablanan qalıq kabinetdəki rəsmi qalıqdan fərqlənir`, impact: Math.abs(mine - theirs), group: g, text: `Vərəqəyə görə ${money(mine)}, kabinetin "Şəxsi hesab vərəqəsi icmalı"nda ${money(theirs)} (${o.names.join('; ')}). Fərq: ${money(mine - theirs)}.`, action: 'Ödənişlərin hansı büdcə təsnifat koduna (KBT) yazıldığını yoxlayın — ödəniş bir vergiyə edilib, borc başqasındadırsa, bu fərq yaranır. Lazım gələrsə ödənişin dəqiqləşdirilməsi barədə ərizə verin.' });
        if (o.overpay > 0) add({ type: 'overpay', key: 'off-' + g, sev: 'high', title: `${(GROUPS[g] || { label: g }).label} üzrə rəsmi artıq ödəmə var: ${money(o.overpay)}`, impact: o.overpay, group: g, text: `Kabinetə görə bu vergidə ${money(o.overpay)} artıq ödəmə durur.`, action: 'Başqa vergi üzrə borc varsa, artıq ödəmənin həmin borca yönəldilməsi (əvəzləşdirmə) üçün ərizə verin; borc yoxdursa, qaytarılmasını tələb edin.' });
      }
      if (M.official.social.unallocated > 0) add({ type: 'social', key: 'unalloc', sev: 'high', title: `Sosial üzrə bölüşdürülməmiş ödəniş: ${money(M.official.social.unallocated)}`, impact: M.official.social.unallocated, text: 'Ödənilmiş sosial sığorta haqqı heç bir öhdəliyə bağlanmayıb — borc azalmır, penya artmağa davam edir.', action: 'DSMF / vergi orqanına ödənişin dəqiqləşdirilməsi barədə müraciət edin.' });
    }
    // 2) Bir növdə artıq ödəmə, digərində borc → əvəzləşdirmə
    for (const S of allSecs) {
      const credits = Object.values(S.groups).filter((g) => g.credit > 100);
      const debts = Object.values(S.groups).filter((g) => g.debt > 100);
      for (const c of credits) {
        const spills = S.rows.filter((x) => x.spill && x.g === c.g);
        add({ type: 'offset', key: S.key + ':' + c.g, sev: debts.length ? 'high' : 'med', group: c.g, section: S.key, impact: c.credit,
          title: `${c.label}: ${money(c.credit)} artıq ödənilib${debts.length ? `, amma ${debts.map((d) => d.label).join(', ')} üzrə borc var` : ''}`,
          text: `Bu vergiyə edilən ödənişlər (və ya azalmalar) onun borcundan ${money(c.credit)} çox olub.${debts.length ? ` Eyni vaxtda ${debts.map((d) => `${d.label} — ${money(d.debt)}`).join(', ')} borc var və bu borclara gündə təxminən ${money(Math.round(debts.reduce((a, d) => a + d.debt, 0) * FAIZ_RATE))} faiz hesablanır.` : ''} Artıq hissəni yaradan sətirlər: ${spills.slice(-5).map((x) => `${x.date} ${x.name} (${money(x.spill)})`).join('; ') || 'açılış qalığı'}.`,
          action: debts.length ? 'Vergi orqanına artıq ödənilmiş məbləğin digər vergi borcunun ödənilməsinə yönəldilməsi (əvəzləşdirmə) barədə ərizə verin. Ərizə mətni aşağıdadır.' : 'Artıq ödəmənin qaytarılması və ya gələcək ödənişlərə sayılması barədə ərizə verin.',
          rows: spills.map((x) => x.id), template: debts.length ? 'offset' : 'refund' });
      }
    }
    // 2b) Ödəniş bir vergi adı ilə edilib, sistem onu başqa (köhnə) borca yazıb
    if (T) {
      const mis = T.rows.filter((x) => x.kindN === 'pay' && x.alloc && x.payTarget).map((x) => {
        const other = Object.entries(x.alloc).filter(([k]) => k.split('|')[0] !== x.payTarget);
        return { x, other, amt: other.reduce((a, [, v]) => a + v, 0) };
      }).filter((o) => o.amt >= 100);
      if (mis.length) {
        const sum = mis.reduce((a, o) => a + o.amt, 0);
        const recent = mis.filter((o) => days(o.x.dt, today) <= 730);
        const by = {};
        mis.forEach((o) => o.other.forEach(([k, v]) => { const g = k.split('|')[0]; by[g] = (by[g] || 0) + v; }));
        add({ type: 'misroute', key: 'tax', sev: recent.length ? 'high' : 'med', section: 'tax', impact: sum, rows: mis.map((o) => o.x.id),
          title: `${mis.length} ödəniş göstərilən vergini yox, başqa köhnə borcu bağlayıb (${money(sum)})`,
          text: `Vergilər vərəqəsi vahid hesabdır: ödəniş tapşırığında yazılan vergidən asılı olmayaraq, pul ödəmə tarixi ən köhnə olan borca yazılır. Belə ödənişlər bu borcları bağlayıb: ${Object.entries(by).sort((a, b) => b[1] - a[1]).map(([g, v]) => `${(GROUPS[g] || { label: g }).label} — ${money(v)}`).join('; ')}.${recent.length ? ` Son 2 ildə ${recent.length} belə ödəniş var, məsələn: ${recent.slice(-3).map((o) => `${o.x.date} ${o.x.code} ${money(o.x.amount)} → ${o.other.map(([k, v]) => `${(GROUPS[k.split('|')[0]] || { label: k }).label} ${k.split('|')[1] || ''} (${money(v)})`).join(', ')}`).join('; ')}.` : ''}`,
          action: 'Cari vergini vaxtında bağlamaq üçün əvvəlcə köhnə borcları ödəyin; əks halda hər yeni ödəniş köhnə borca gedəcək və cari vergi gecikmiş sayılıb faiz yaradacaq.' });
      }
    }
    // 3) Vaxtı ötmüş açıq borclar (ən böyük faiz mənbəyi)
    for (const S of allSecs) for (const g of Object.values(S.groups)) {
      const od = g.lots.filter((l) => l.pdt && l.pdt < today && l.amt > 0);
      const sum = od.reduce((a, l) => a + l.amt, 0);
      if (sum < 100) continue;
      const oldest = od.reduce((m, l) => (!m || l.pdt < m ? l.pdt : m), null);
      const dd = days(oldest, today);
      const per = {};
      od.forEach((l) => { per[l.plabel || l.pkey] = (per[l.plabel || l.pkey] || 0) + l.amt; });
      const top = Object.entries(per).sort((a, b) => b[1] - a[1]).slice(0, 4);
      add({ type: 'overdue', key: S.key + ':' + g.g, sev: sum > 1000000 || (dd > 365 && sum > 100000) ? 'high' : 'med', section: S.key, group: g.g, impact: sum,
        title: `${g.label}: ${money(sum)} borcun ödəmə vaxtı keçib (ən köhnəsi ${dd} gün)`,
        text: `Ödənilməmiş dövrlər: ${top.map(([k, v]) => `${k} — ${money(v)}`).join('; ')}${Object.keys(per).length > 4 ? ` və daha ${Object.keys(per).length - 4} dövr` : ''}. Bu borca gündə təxminən ${money(Math.round(sum * FAIZ_RATE))} ${S.penLabel.toLowerCase()} hesablanır (ayda ≈ ${money(Math.round(sum * FAIZ_RATE * 30))}).`,
        action: 'Ödəniş tapşırığını məhz bu vergi növünün büdcə təsnifat koduna edin. Ödəmək mümkün deyilsə, vergi orqanından möhlət / hissə-hissə ödəmə istəyin.' });
    }
    // 4) Geriyə tarixli hesablamalar (faiz ödəmə tarixindən hesablanır)
    for (const S of allSecs) {
      // Vahid bəyannamə rüblük verilir, ödəmə isə aylıqdır — bu normaldır, sayılmır. Son 3 il.
      const late = S.rows.filter((x) => x.kindN === 'acc' && x.dBal >= 10000 && x.dt && x.pdt && days(x.pdt, x.dt) > 45 && days(x.dt, today) <= 1095 && !/^VAH[İI]D/.test(U(x.name)));
      if (!late.length) continue;
      const sum = late.reduce((a, x) => a + x.amount, 0);
      const rec = late.slice().sort((a, b) => b.dt - a.dt).slice(0, 6);
      add({ type: 'retro', key: S.key, sev: 'med', section: S.key, impact: sum, rows: late.map((x) => x.id),
        title: `${S.label}: ${late.length} hesablama ödəmə tarixindən 45 gündən çox sonra yazılıb (${money(sum)})`,
        text: `Bu məbləğlər vərəqəyə gec düşüb, amma faiz onların ödəmə tarixindən hesablanır. Son nümunələr: ${rec.map((x) => `${x.name} — yazılıb ${x.date}, ödəmə tarixi ${x.payDate} (${days(x.pdt, x.dt)} gün)`).join('; ')}.`,
        action: 'Səbəb gec verilmiş və ya dəqiqləşdirilmiş bəyannamə, yaxud yoxlama aktıdır. Bəyannamələri vaxtında verin; dəqiqləşdirmədən əvvəl faiz təsirini hesablayın.' });
    }
    // 4b) Çox dəfə dəqiqləşdirilmiş dövrlər (qarışıqlığın əsas mənbəyi)
    for (const S of allSecs) {
      const busy = S.periods.filter((p) => p.g !== 'OTHER' && p.key !== '—' && p.rowIds.filter((id) => { const r = M.byId ? null : null; return true; }).length && p.decls.includes('Dəqiqləşdirilmiş'))
        .map((p) => ({ p, n: S.rows.filter((x) => x.g === p.g && x.per && x.per.key === p.key && x.decl === 'Dəqiqləşdirilmiş' && !x.zero).length }))
        .filter((o) => o.n >= 3).sort((a, b) => b.n - a.n);
      if (busy.length) add({ type: 'churn', key: S.key, sev: 'info', section: S.key, impact: busy.reduce((a, o) => a + Math.abs(o.p.net), 0),
        rows: busy.flatMap((o) => S.rows.filter((x) => x.g === o.p.g && x.per && x.per.key === o.p.key).map((x) => x.id)),
        title: `${S.label}: ${busy.length} dövr 3 və daha çox dəfə dəqiqləşdirilib`,
        text: busy.slice(0, 8).map((o) => `${(GROUPS[o.p.g] || { label: o.p.g }).label} ${o.p.label} — ${o.n} dəqiqləşmə, yekun hesablanmış ${money(o.p.net)}`).join('; ') + '. Hər dəqiqləşmə əvvəlki hesablamanı azaldıb yenisini yazır — vərəqədə eyni dövr təkrar-təkrar görünür.',
        action: '"Vergi növləri" bölməsində dövrü açın: bütün bəyannamələr ardıcıllıqla və yekun məbləğlə göstərilir.' });
    }
    // 5) Təkrar ödəniş şübhəsi
    for (const S of allSecs.filter((s) => s.key === 'tax')) {
      const seen = {};
      for (const x of S.rows.filter((r) => r.kindN === 'pay' && r.amount >= 1000)) {
        const k = x.date + '|' + x.code + '|' + x.amount;
        (seen[k] = seen[k] || []).push(x);
      }
      const dup = Object.values(seen).filter((a) => a.length > 1);
      if (dup.length) add({ type: 'dup', key: S.key, sev: 'info', section: S.key, impact: dup.reduce((a, d) => a + d[0].amount * (d.length - 1), 0), rows: dup.flat().map((x) => x.id),
        title: `${S.label}: eyni gün, eyni vergi və eyni məbləğdə ${dup.length} cüt ödəniş — yoxlayın`,
        text: dup.slice(0, 6).map((d) => `${d[0].date} — ${d[0].code || 'kodsuz'} ${money(d[0].amount)} × ${d.length}`).join('; ') + '.',
        action: 'Bank çıxarışı ilə yoxlayın. Səhvən iki dəfə ödənilibsə, artıq hissə artıq ödəmə kimi qalır — əvəzləşdirmə və ya qaytarma istəyin.' });
    }
    // 6) Qeyri-standart əməliyyatlar
    for (const S of allSecs) {
      const odd = S.rows.filter((x) => (x.kindN === 'adj' || x.g === 'OTHER') && !x.zero && !/SALDO/.test(U(x.name)));
      if (!odd.length) continue;
      const sum = odd.reduce((a, x) => a + Math.abs(x.dBal || x.amount), 0);
      const names = {};
      odd.forEach((x) => { const k = (x.code || x.kind || '').slice(0, 30) || x.name.slice(0, 30); names[k] = (names[k] || 0) + 1; });
      add({ type: 'odd', key: S.key, sev: 'info', section: S.key, impact: sum, rows: odd.map((x) => x.id),
        title: `${S.label}: növü tanınmayan ${odd.length} əməliyyat (qərar, akt, sistem düzəlişi)`,
        text: 'Növlər: ' + Object.entries(names).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => `${k} × ${v}`).join(', ') + '. Bunlar adətən yoxlama aktı, inzibati qərar və ya sistem düzəlişidir.',
        action: 'Hər birinin əsasını (akt, qərar nömrəsi) yoxlayın. Əsaslandırılmamış hesablama varsa, vergi orqanına izahat sorğusu göndərin.' });
    }
    // 7) Qeyri-adi böyük hesablamalar
    if (T) for (const g of Object.values(T.groups).filter((g) => g.g !== 'OTHER' && g.g !== 'OPEN')) {
      const acc = T.rows.filter((x) => x.g === g.g && x.kindN === 'acc' && x.amount > 0).map((x) => x.amount).sort((a, b) => a - b);
      if (acc.length < 6) continue;
      const med = acc[Math.floor(acc.length / 2)];
      const big = T.rows.filter((x) => x.g === g.g && x.kindN === 'acc' && x.amount > Math.max(med * 8, 500000));
      if (big.length) add({ type: 'spike', key: g.g, sev: 'info', group: g.g, section: 'tax', impact: big.reduce((a, x) => a + x.amount, 0), rows: big.map((x) => x.id),
        title: `${g.label}: adi səviyyədən 8 dəfədən çox böyük ${big.length} hesablama`,
        text: `Bu vergi üzrə adi hesablama ≈ ${money(med)}. Böyüklər: ${big.slice(-5).map((x) => `${x.date} ${x.name} — ${money(x.amount)}`).join('; ')}.`,
        action: 'Səbəbini yoxlayın: yoxlama aktı, birdəfəlik əməliyyat və ya bəyannamədə səhv ola bilər.' });
    }
    // 8) Faiz yükü
    if (T && T.finalPen > 0) {
      const last12 = T.rows.filter((x) => x.kindN === 'pay' && x.dt && days(x.dt, today) <= 365);
      const paid = last12.reduce((a, x) => a + x.amount, 0), toPen = last12.reduce((a, x) => a + (x.toPenalty || 0), 0);
      add({ type: 'faiz', key: 'tax', sev: T.finalPen > 100000 ? 'high' : 'med', section: 'tax', impact: T.finalPen,
        title: `Vergilər üzrə yığılmış faiz: ${money(T.finalPen)}`,
        text: `Faiz əsas borcdan ayrı uçotdadır: əsas borc ödənilsə də, yığılmış faiz qalır. Son 12 ayda ${money(paid)} ödənilib, bundan cəmi ${money(toPen)} faizi azaldıb. Hazırda əsas borca gündə təxminən ${money(Math.round(Math.max(0, T.finalBal) * FAIZ_RATE))} faiz əlavə olunur.`,
        action: 'Əvvəlcə əsas borcu bağlayın (faizin artması dayansın), sonra faizi ayrıca ödəyin. Faizin hesablanmasına etirazınız varsa, faiz tarixçəsini (Çıxarış növü: "Faiz hesablaması tarixçəsi") yükləyib yoxlayın.' });
    }
    // 9) Yekundakı xüsusi göstəricilər
    const S = M.summary;
    const chk = (k, sev, title, action) => { const v = S[k]; if (v != null && E.cents(v) > 0) add({ type: 'summary', key: k, sev, impact: E.cents(v), title: `${title}: ${money(E.cents(v))}`, text: `Vərəqənin yekun cədvəlində göstərilib.`, action }); };
    chk('SOSIAL UZRE BOLUSDURULMEMIS ODENISLER', 'high', 'Sosial üzrə bölüşdürülməmiş ödənişlər', 'Ödənişin hansı öhdəliyə aid olduğunu dəqiqləşdirin — bölüşdürülməyənədək borc bağlanmır.');
    chk('VAXTI OTMUS ARTIQ ODEME', 'med', 'Vaxtı ötmüş artıq ödəmə', 'Artıq ödəmənin qaytarılması və ya əvəzləşdirilməsi üçün müddət bitməmiş ərizə verin.');
    chk('KAMERAL YOXLANILMALI MEBLEG', 'med', 'Kameral yoxlanılmalı məbləğ', 'Bu məbləğ kameral yoxlamadan sonra borca çevrilə bilər — sənədləri hazırlayın.');
    chk('VERGI UZRE MOHLET VERILMISDIR', 'info', 'Vergi üzrə möhlət', 'Möhlət qrafikinə əməl edin.');
    const sev = { high: 0, med: 1, info: 2, ok: 3 };
    return F.sort((a, b) => sev[a.sev] - sev[b.sev] || b.impact - a.impact);
  }

  // ---------- Əsas giriş ----------
  function build(items, extra = {}) {
    const st = E.parseStatement(items);
    const res = E.analyze(items); // dBal / dPen / cat sətirlərə yazılır
    const asOf = res.printDate || extra.asOf || new Date();
    const ent = { ...st.entity, name: String(st.entity.name || '').replace(/^.*\}\s*/, '').replace(/İnternet Vergi İdarəsi/g, '').trim() };
    const M = { entity: ent, summary: st.summary, asOf, sections: {}, official: officialFromLiabilities(extra.liabilities), notes: res.notes };
    for (const [k, s] of Object.entries(res.sections)) if (s && s.rows && s.rows.length) M.sections[k] = analyzeSection({ key: k, rows: s.rows });
    M.rows = Object.values(M.sections).flatMap((s) => s.rows);
    M.byId = Object.fromEntries(M.rows.map((r) => [r.id, r]));
    const T = M.sections.tax;
    M.totals = {
      principal: Object.values(M.sections).reduce((a, s) => a + Math.max(0, s.finalBal), 0),
      overpay: Object.values(M.sections).reduce((a, s) => a + Math.max(0, -s.finalBal), 0),
      penalty: Object.values(M.sections).reduce((a, s) => a + Math.max(0, s.finalPen), 0) - (T ? T.finalPen : 0) + (T ? (st.summary['CAP TARIXINE FAIZ BORCU'] != null ? E.cents(st.summary['CAP TARIXINE FAIZ BORCU']) : T.finalPen) : 0)
    };
    M.totals.total = M.totals.principal + M.totals.penalty;
    M.period = { from: M.rows.reduce((m, r) => (!m || (r.dt && r.dt < m) ? r.dt : m), null), to: M.rows.reduce((m, r) => (!m || (r.dt && r.dt > m) ? r.dt : m), null) };
    if (extra.faizItems) M.faiz = parseFaizReport(extra.faizItems);
    M.findings = findings(M);
    return M;
  }

  const api = { build, fmt, GROUPS, SECTION_LABEL, FAIZ_RATE, money, iso, days, periodOf, codeOf, groupOfCode, kindOf, parseFaizReport, officialFromLiabilities };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.SHA = api;
})(typeof window !== 'undefined' ? window : globalThis);
