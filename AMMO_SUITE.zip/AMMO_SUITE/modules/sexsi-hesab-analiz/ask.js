/* AMMO — Şəxsi hesab vərəqəsi: "Sual ver" köməkçisi.
   Sualı Azərbaycan dilində başa düşür (vergi növü, dövr, il, ay, rüb, niyyət) və cavabı
   YALNIZ yüklənmiş vərəqənin rəqəmlərindən qurur. Heç nə internetə göndərilmir. */
(function (root) {
  'use strict';
  const A = root.SHA;
  const money = A.money;
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fold = (s) => String(s || '').toLocaleLowerCase('az').replace(/ə/g, 'e').replace(/ı/g, 'i').replace(/ö/g, 'o').replace(/ü/g, 'u').replace(/ş/g, 's').replace(/ç/g, 'c').replace(/ğ/g, 'g').replace(/i̇/g, 'i');
  const MONTHS = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avqust', 'sentyabr', 'oktyabr', 'noyabr', 'dekabr'];
  const GROUP_WORDS = [
    [/\bedv\b|elave deyer/, 'EDV'], [/menfeet|\bmv\b/, 'MV'], [/\bomv\b|odeme menbe|dividend|icare|royalti/, 'OMV'],
    [/muzdlu|momv|gelir vergisi|maas|emek haqq/, 'MUZDLU'], [/emlak/, 'EMLAK'], [/torpaq/, 'TORPAQ'], [/\byol\b/, 'YOL'],
    [/sadeles|\bsv\b/, 'SV'], [/aksiz/, 'AKSIZ'], [/meden/, 'MEDEN']
  ];
  const SECTION_WORDS = [[/mdss|pensiya|sosial sig/, 'mdss'], [/issizlik/, 'unemp'], [/tibbi|\bits\b/, 'its']];

  function parseQ(q, today) {
    const f = ' ' + fold(q).replace(/[?!.,;:]/g, ' ') + ' ';
    const out = { f, groups: [], section: null, years: [], month: null, quarter: null, from: null, to: null };
    for (const [rx, g] of GROUP_WORDS) if (rx.test(f)) out.groups.push(g);
    for (const [rx, s] of SECTION_WORDS) if (rx.test(f)) out.section = s;
    for (const m of f.matchAll(/\b(19\d{2}|20\d{2})\b/g)) out.years.push(+m[1]);
    MONTHS.forEach((m, i) => { if (new RegExp('\\b' + fold(m) + '[a-z]{0,4}\\b').test(f)) out.month = i + 1; });
    let m = f.match(/\b([1-4])\s*-?\s*(ci|cu|cü|nci|ncu|nc[iu])?\s*rub/);
    if (m) out.quarter = +m[1];
    m = f.match(/\b(\d{1,2})[./](20\d{2})\b/) || f.match(/\b(20\d{2})\/(\d{2})\b/);
    if (m) { if (m[1].length === 4) { out.years = [+m[1]]; out.month = +m[2]; } else { out.month = +m[1]; out.years = [+m[2]]; } }
    const y = today.getFullYear();
    if (/\bbu il/.test(f)) out.years = [y];
    if (/kecen il|otan il/.test(f)) out.years = [y - 1];
    m = f.match(/son\s+(\d+)\s+(ay|gun|il)/);
    if (m) { const n = +m[1]; const d = new Date(today); if (m[2] === 'ay') d.setMonth(d.getMonth() - n); else if (m[2] === 'gun') d.setDate(d.getDate() - n); else d.setFullYear(d.getFullYear() - n); out.from = d; out.to = today; }
    if (/\bbu ay/.test(f)) { out.from = new Date(y, today.getMonth(), 1); out.to = today; }
    if (out.years.length && !out.from) {
      const yy = out.years[0];
      if (out.month) { out.from = new Date(yy, out.month - 1, 1); out.to = new Date(yy, out.month, 0); }
      else if (out.quarter) { out.from = new Date(yy, (out.quarter - 1) * 3, 1); out.to = new Date(yy, out.quarter * 3, 0); }
      else { out.from = new Date(yy, 0, 1); out.to = new Date(yy, 11, 31); }
    }
    return out;
  }
  const has = (P, rx) => rx.test(P.f);
  const gl = (g) => (A.GROUPS[g] || { label: g }).label;
  const link = (label, attrs) => `<button class="ask-link" ${Object.entries(attrs).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ')}>${esc(label)}</button>`;
  const opsLink = (rows, label) => rows.length ? link(label || `${rows.length} əməliyyata bax →`, { go: 'ops', ids: rows.slice(0, 400).map((r) => r.id).join(',') }) : '';
  const periodMatch = (P, per) => {
    if (!per) return false;
    if (P.years.length && per.y !== P.years[0]) return false;
    if (P.month && !(per.key === `${per.y}-${String(P.month).padStart(2, '0')}`)) return false;
    if (P.quarter && !(per.key === `${per.y}-Q${P.quarter}` || (/^\d{4}-\d{2}$/.test(per.key) && Math.ceil(+per.key.slice(5) / 3) === P.quarter))) return false;
    return true;
  };
  function lotMatch(P, l) {
    if (!P.years.length) return true;
    const k = String(l.pkey || ''), y = Number(k.slice(0, 4));
    if (y !== P.years[0]) return false;
    if (P.month) return k === `${y}-${String(P.month).padStart(2, '0')}`;
    if (P.quarter) return k === `${y}-Q${P.quarter}` || (/^\d{4}-\d{2}$/.test(k) && Math.ceil(+k.slice(5) / 3) === P.quarter);
    return true;
  }
  const inRange = (P, d) => !P.from || (d && d >= P.from && d <= new Date(P.to.getTime() + 86399999));
  const rangeLabel = (P) => {
    if (P.years.length && P.month) return `${A.iso(P.from).slice(8)}.${String(P.month).padStart(2, '0')}.${P.years[0]}`.replace(/^\d\d\./, '') + ' ayında';
    if (P.years.length && P.quarter) return `${P.years[0]}-ci il ${P.quarter}-cü rübdə`;
    if (P.years.length) return `${P.years[0]}-ci ildə`;
    if (P.from) return `${A.iso(P.from).split('-').reverse().join('.')} – ${A.iso(P.to).split('-').reverse().join('.')} arasında`;
    return 'bütün dövr üzrə';
  };

  function sectionsFor(M, P) {
    if (P.section) return M.sections[P.section] ? [M.sections[P.section]] : [];
    return Object.values(M.sections);
  }
  function groupsFor(M, P) {
    const T = M.sections[P.section || 'tax'];
    if (!T) return [];
    if (P.groups.length) return P.groups.map((g) => T.groups[g]).filter(Boolean);
    return Object.values(T.groups).filter((g) => g.debt > 0 || g.credit > 0).sort((a, b) => b.debt - a.debt);
  }

  // ---------- Cavablar ----------
  function aDebt(M, P) {
    const T = M.sections.tax;
    if (P.groups.length && T) {
      return P.groups.map((g) => {
        const G = T.groups[g];
        if (!G) return `<p><b>${esc(gl(g))}</b> üzrə vərəqədə əməliyyat yoxdur.</p>`;
        const lots = G.lots.filter((l) => l.amt > 0 && lotMatch(P, l));
        const per = {};
        lots.forEach((l) => { per[l.plabel || l.pkey] = (per[l.plabel || l.pkey] || 0) + l.amt; });
        const rows = Object.entries(per).sort((a, b) => b[1] - a[1]);
        const sum = lots.reduce((a, l) => a + l.amt, 0);
        const amt = P.years.length ? sum : G.debt;
        return `<p><b>${esc(G.label)}</b>${P.years.length ? ` (${esc(rangeLabel(P).replace(/də$|da$/, ''))})` : ''}: açıq əsas borc <b>${money(amt)}</b>${G.credit ? `, artıq ödəmə ${money(G.credit)}` : ''}. Bu borca gündə ≈ ${money(Math.round(amt * A.FAIZ_RATE))} faiz hesablanır.</p>` +
          (rows.length ? `<table class="ask-t"><tr><th>Dövr</th><th>Açıq qalıq</th></tr>${rows.slice(0, 12).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${money(v)}</td></tr>`).join('')}</table>${rows.length > 12 ? `<p class="muted">…və daha ${rows.length - 12} dövr</p>` : ''}` : '<p>Bu vergi üzrə açıq dövr yoxdur — hamısı bağlanıb.</p>') +
          link(`${G.label} kartını aç →`, { go: 'group', group: g, section: 'tax' });
      }).join('');
    }
    const secs = sectionsFor(M, P);
    const t = M.totals;
    let h = P.section ? '' : `<p>Cəmi ödənməli: <b>${money(t.total)}</b> — əsas borc ${money(t.principal)} + faiz/penya ${money(t.penalty)}.</p>`;
    h += `<table class="ask-t"><tr><th>Bölmə</th><th>Əsas borc</th><th>Faiz / penya</th></tr>${secs.map((s) => `<tr><td>${esc(s.label)}</td><td>${money(Math.max(0, s.finalBal))}${s.finalBal < 0 ? ` (artıq ${money(-s.finalBal)})` : ''}</td><td>${money(s.finalPen)}</td></tr>`).join('')}</table>`;
    const T2 = M.sections[P.section || 'tax'];
    if (T2) {
      const gs = Object.values(T2.groups).filter((g) => g.debt > 0).sort((a, b) => b.debt - a.debt);
      if (gs.length) h += `<p>${esc(T2.label)} üzrə borc bu növlərdədir:</p><table class="ask-t">${gs.map((g) => `<tr><td>${link(g.label, { go: 'group', group: g.g, section: T2.key })}</td><td>${money(g.debt)}</td></tr>`).join('')}</table>`;
    }
    return h;
  }
  function aFaiz(M, P, why) {
    const secs = sectionsFor(M, P);
    let h = `<p>${secs.map((s) => `${esc(s.label)}: <b>${money(s.finalPen)}</b> ${s.penLabel.toLowerCase()}`).join(' · ')}.</p>`;
    const T = M.sections.tax;
    if (why && T) {
      const gs = Object.values(T.groups).filter((g) => g.debt > 0).sort((a, b) => b.debt - a.debt);
      h += `<p>Faiz <b>ödəmə tarixi keçmiş əsas borc</b> üzərinə gündə 0,1% hesablanır. Hazırda əsas borc ${money(Math.max(0, T.finalBal))}-dır, yəni hər gün təxminən <b>${money(Math.round(Math.max(0, T.finalBal) * A.FAIZ_RATE))}</b> faiz əlavə olunur.</p>`;
      if (gs.length) h += `<p>Faizi ən çox yaradan borclar:</p><table class="ask-t"><tr><th>Vergi</th><th>Borc</th><th>Gündə faiz</th><th>Ən köhnə ödəmə tarixi</th></tr>${gs.slice(0, 6).map((g) => { const o = g.lots.reduce((m, l) => (!m || (l.pdt && l.pdt < m) ? l.pdt : m), null); return `<tr><td>${esc(g.label)}</td><td>${money(g.debt)}</td><td>${money(Math.round(g.debt * A.FAIZ_RATE))}</td><td>${o ? A.iso(o).split('-').reverse().join('.') + ` (${A.days(o, M.asOf)} gün)` : '—'}</td></tr>`; }).join('')}</table>`;
      h += `<p>Bütün tarixçə ərzində ${money(T.faizAccrued)} faiz hesablanıb, ${money(T.faizReduced)} azaldılıb (dəqiqləşmə və silinmə ilə), ödənişlər isə ${money(T.faizPaid)} faizi bağlayıb.</p>`;
      if (M.faiz && M.faiz.length) {
        const yr = {}; M.faiz.forEach((r) => { const y = r.date.slice(-4); yr[y] = (yr[y] || 0) + r.accrued; });
        h += `<p>Faiz tarixçəsinə görə illər üzrə hesablanmış faiz: ${Object.entries(yr).map(([y, v]) => `${y} — ${money(v)}`).join('; ')}.</p>`;
      }
    }
    return h;
  }
  function aPayments(M, P, where) {
    const secs = sectionsFor(M, P);
    if (where && !P.section) secs.splice(0, secs.length, ...(M.sections.tax ? [M.sections.tax] : secs));
    if (where && !P.from) { P.from = new Date(M.asOf.getTime() - 365 * 86400000); P.to = M.asOf; }
    let rows = secs.flatMap((s) => s.rows.filter((r) => r.kindN === 'pay' && inRange(P, r.dt))).sort((a, b) => a.dt - b.dt);
    if (P.groups.length) rows = rows.filter((r) => P.groups.includes(A.groupOfCode(r.code)));
    if (!rows.length) return `<p>${esc(rangeLabel(P))} ödəniş tapılmadı.</p>`;
    const sum = rows.reduce((a, r) => a + r.amount, 0);
    let h = `<p>${esc(rangeLabel(P))}${P.groups.length ? ' ' + P.groups.map(gl).join(', ') + ' adı ilə' : ''} <b>${rows.length}</b> ödəniş, cəmi <b>${money(sum)}</b>.</p>`;
    const show = rows.slice(-10).reverse();
    h += `<table class="ask-t"><tr><th>Tarix</th><th>Sənəd</th><th>Məbləğ</th>${where ? '<th>Əslində hansı borcu bağlayıb</th>' : ''}</tr>${show.map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.name)}</td><td>${money(r.amount)}</td>${where ? `<td>${r.alloc ? Object.entries(r.alloc).map(([k, v]) => `${esc(gl(k.split('|')[0]))} ${esc(k.split('|')[1] || '')} — ${money(v)}`).join('<br>') : (r.dPen < 0 ? `${r.sec === 'tax' || r.sec === 'its' ? 'faizi' : 'penyanı'} azaldıb — ${money(-r.dPen)}` : (r.dBal >= 0 ? 'əsas borcu azaltmayıb' : '—'))}${r.spill ? `<br><b>artıq ödəmə: ${money(r.spill)}</b>` : ''}</td>` : ''}</tr>`).join('')}</table>`;
    if (!where && M.sections.tax) h += `<p class="muted">"Ödənişlər hara gedib?" yazsanız, hər ödənişin əslində hansı borcu bağladığını göstərərəm.</p>`;
    return h + opsLink(rows);
  }
  function aAccruals(M, P, red) {
    const secs = sectionsFor(M, P);
    let rows = secs.flatMap((s) => s.rows.filter((r) => r.kindN === (red ? 'red' : 'acc') && !r.zero));
    if (P.groups.length) rows = rows.filter((r) => P.groups.includes(r.g));
    const byPer = P.years.length || P.month || P.quarter;
    rows = rows.filter((r) => (byPer ? periodMatch(P, r.per) : true));
    if (!byPer && P.from) rows = rows.filter((r) => inRange(P, r.dt));
    if (!rows.length) return `<p>Uyğun ${red ? 'azalma' : 'hesablama'} tapılmadı.</p>`;
    const sum = rows.reduce((a, r) => a + r.amount, 0);
    if (!red && byPer) {
      let other = secs.flatMap((s) => s.rows.filter((r) => r.kindN === 'red' && !r.zero && periodMatch(P, r.per)));
      if (P.groups.length) other = other.filter((r) => P.groups.includes(r.g));
      const rs = other.reduce((a, r) => a + r.amount, 0);
      const all = rows.concat(other).sort((a, b) => a.dt - b.dt);
      return `<p>Göstərilən dövr üzrə ${rows.length} hesablama (${money(sum)}) və ${other.length} azalma (${money(rs)}) — <b>yekun hesablanmış vergi ${money(sum - rs)}</b>. Eyni dövr bir neçə dəfə dəqiqləşdirildiyi üçün vərəqədə təkrar görünür:</p>` +
        `<table class="ask-t"><tr><th>Yazılış</th><th>Əməliyyat</th><th>Növ</th><th>Məbləğ</th></tr>${all.slice(-14).map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.name)}</td><td>${esc(r.kind)}</td><td>${r.kindN === 'red' ? '−' : '+'}${money(r.amount)}</td></tr>`).join('')}</table>` + opsLink(all);
    }
    const g = {}; rows.forEach((r) => { const k = gl(r.g) + ' ' + (r.per ? r.per.label : ''); g[k] = (g[k] || 0) + r.amount; });
    return `<p>${byPer ? 'Göstərilən dövr' : esc(rangeLabel(P))} üzrə <b>${rows.length}</b> ${red ? 'azalma' : 'hesablama'}, cəmi <b>${money(sum)}</b>.</p>` +
      `<table class="ask-t">${Object.entries(g).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${money(v)}</td></tr>`).join('')}</table>` + opsLink(rows);
  }
  function aOverdue(M, P) {
    const secs = sectionsFor(M, P);
    const items = secs.flatMap((s) => Object.values(s.groups).filter((g) => !P.groups.length || P.groups.includes(g.g)).flatMap((g) => g.lots.filter((l) => l.amt > 0 && l.pdt && l.pdt < M.asOf).map((l) => ({ s, g, l }))));
    if (!items.length) return '<p>Ödəmə vaxtı keçmiş borc yoxdur.</p>';
    items.sort((a, b) => a.l.pdt - b.l.pdt);
    const sum = items.reduce((a, x) => a + x.l.amt, 0);
    return `<p>Ödəmə vaxtı keçmiş əsas borc: <b>${money(sum)}</b>. Ən köhnələri:</p><table class="ask-t"><tr><th>Növ</th><th>Dövr</th><th>Ödəmə tarixi</th><th>Gecikmə</th><th>Qalıq</th></tr>${items.slice(0, 12).map((x) => `<tr><td>${esc(x.g.label)}</td><td>${esc(x.l.plabel || x.l.pkey)}</td><td>${A.iso(x.l.pdt).split('-').reverse().join('.')}</td><td>${A.days(x.l.pdt, M.asOf)} gün</td><td>${money(x.l.amt)}</td></tr>`).join('')}</table>`;
  }
  function aCredit(M) {
    const items = Object.values(M.sections).flatMap((s) => Object.values(s.groups).filter((g) => g.credit > 0).map((g) => ({ s, g })));
    const off = M.official ? M.official.list.filter((x) => x.overpay > 0) : [];
    if (!items.length && !off.length && !Object.values(M.sections).some((s) => s.finalBal < 0)) return '<p>Artıq ödəmə yoxdur.</p>';
    let h = '';
    Object.values(M.sections).filter((s) => s.finalBal < 0).forEach((s) => { h += `<p>${esc(s.label)}: vərəqənin son qalığı <b>${money(-s.finalBal)}</b> artıq ödəmədir.</p>`; });
    if (items.length) h += `<table class="ask-t">${items.map((x) => `<tr><td>${esc(x.s.label)} — ${esc(x.g.label)}</td><td>${money(x.g.credit)}</td></tr>`).join('')}</table>`;
    if (off.length) h += `<p>Kabinetə görə rəsmi artıq ödəmə: ${off.map((x) => `${esc(x.name)} — ${money(x.overpay)}`).join('; ')}.</p>`;
    return h + '<p>Artıq ödəməni başqa vergi borcuna yönəltmək (əvəzləşdirmə) və ya qaytarmaq üçün ərizə verilir. "Uyğunsuzluqlar" bölməsində ərizə mətni var.</p>';
  }
  function aFindings(M, todo) {
    const F = M.findings.filter((f) => f.sev !== 'ok');
    if (!F.length) return '<p>Ciddi uyğunsuzluq tapılmadı. Vərəqə öz yekunu ilə üst-üstə düşür.</p>';
    const top = F.filter((f) => f.sev === 'high').slice(0, todo ? 5 : 8);
    const list = (top.length ? top : F.slice(0, 5));
    return `<p>${todo ? 'Ən vacib addımlar (təsir məbləğinə görə):' : `<b>${F.length}</b> məsələ tapıldı, ${F.filter((f) => f.sev === 'high').length} kritik:`}</p><ol class="ask-ol">${list.map((f) => `<li><b>${esc(f.title)}</b><br>${todo ? esc(f.action || '') : esc(f.text).slice(0, 260) + (f.text.length > 260 ? '…' : '')}</li>`).join('')}</ol>` + link('Uyğunsuzluqlar bölməsini aç →', { go: 'findings' });
  }
  function aBiggest(M) {
    const T = M.sections.tax; if (!T) return aDebt(M, { groups: [], f: '' });
    const g = Object.values(T.groups).sort((a, b) => b.debt - a.debt)[0];
    const lot = Object.values(T.groups).flatMap((G) => G.lots.map((l) => ({ G, l }))).filter((x) => x.l.amt > 0).sort((a, b) => b.l.amt - a.l.amt)[0];
    return `<p>Ən böyük borc <b>${esc(g.label)}</b> üzrədir: ${money(g.debt)}.</p>${lot ? `<p>Ən böyük tək açıq dövr: <b>${esc(lot.G.label)} ${esc(lot.l.plabel || lot.l.pkey)}</b> — ${money(lot.l.amt)} (ödəmə tarixi ${A.iso(lot.l.pdt).split('-').reverse().join('.')}).</p>` : ''}${link(`${g.label} kartını aç →`, { go: 'group', group: g.g, section: 'tax' })}`;
  }
  function aLast(M, P) {
    const rows = sectionsFor(M, P).flatMap((s) => s.rows.filter((r) => r.kindN === 'pay')).sort((a, b) => b.dt - a.dt).slice(0, 8);
    return rows.length ? `<p>Son ödənişlər:</p><table class="ask-t">${rows.map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.name)}</td><td>${money(r.amount)}</td></tr>`).join('')}</table>` : '<p>Ödəniş yoxdur.</p>';
  }
  function aSearch(M, q) {
    const words = fold(q).split(/\s+/).filter((w) => w.length > 2 && !/^(nedir|hansi|nece|olub|var|ucun|uzre|haqqinda|gostar|goster|mene)$/.test(w));
    if (!words.length) return '';
    const rows = M.rows.filter((r) => { const t = fold(r.name + ' ' + r.kind + ' ' + r.date); return words.every((w) => t.includes(w)); });
    if (!rows.length) return '';
    return `<p>"${esc(q)}" üzrə ${rows.length} əməliyyat tapıldı:</p><table class="ask-t">${rows.slice(-8).reverse().map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.name)}</td><td>${esc(r.kind)}</td><td>${money(r.amount)}</td></tr>`).join('')}</table>` + opsLink(rows);
  }
  const HELP = `<p>Mən yüklənmiş şəxsi hesab vərəqəsinin rəqəmləri ilə cavab verirəm. Məsələn soruşun:</p><ul class="ask-ul"><li>Ümumi borc nə qədərdir?</li><li>ƏDV borcu hansı aylardandır?</li><li>Faiz niyə bu qədərdir?</li><li>2025-ci ildə nə qədər ödənilib?</li><li>Son ödənişlər hara gedib?</li><li>Mənfəət vergisi 2024 4-cü rüb</li><li>Hansı borcların vaxtı keçib?</li><li>Nə etməliyəm?</li></ul>`;

  function answer(M, q) {
    if (!M) return { html: '<p>Əvvəlcə şəxsi hesab vərəqəsini yükləyin.</p>' };
    const P = parseQ(q, M.asOf);
    const f = P.f;
    let html = '';
    if (/^\s*(salam|kömək|komek|help|ne bilirsen|nə bacarırsan)\s*$/.test(fold(q)) || has(P, /\b(komek|help)\b/)) html = HELP;
    else if (has(P, /ne etmel|ne edim|tovsiy|meslehet|\bplan\b|ne edek|neyneyim/)) html = aFindings(M, true);
    else if (has(P, /uygunsuz|problem|sehv|xeta|ferq|yoxla|risk/)) html = aFindings(M, false);
    else if (has(P, /faiz|penya/) && has(P, /niye|niy|hardan|haradan|sebeb|nece yaran|nedi/)) html = aFaiz(M, P, true);
    else if (has(P, /faiz|penya/)) html = aFaiz(M, P, has(P, /hansi|harda/));
    else if (has(P, /artiq od|artiq ode|qaytar|evezles/)) html = aCredit(M);
    else if (has(P, /hara ged|hara get|hansi borcu|nereye|hara yaz|bagla/)) html = aPayments(M, P, true);
    else if (has(P, /son odenis|axirinci odenis|en son/)) html = aLast(M, P);
    else if (has(P, /odeni|odedik|odemisik|odenil|odenmis|odemis/)) html = aPayments(M, P, false);
    else if (has(P, /azal|deqiqles/)) html = aAccruals(M, P, true);
    else if (has(P, /hesabla|beyanname/)) html = aAccruals(M, P, false);
    else if (has(P, /gecik|vaxti kec|vaxt kec|nece gun|kohne borc/)) html = aOverdue(M, P);
    else if (has(P, /en boyuk|en cox/)) html = aBiggest(M);
    else if (has(P, /borc|qaliq|ne qeder|neqeder|cemi|umumi/) || P.groups.length || P.section) html = aDebt(M, P);
    else html = aSearch(M, q) || `<p>Sualı tam başa düşmədim.</p>${HELP}`;
    return { html, parsed: P };
  }

  const api = { answer, parseQ, HELP };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.SHAsk = api;
})(typeof window !== 'undefined' ? window : globalThis);
