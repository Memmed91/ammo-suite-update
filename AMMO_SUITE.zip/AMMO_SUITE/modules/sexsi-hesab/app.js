/* AMMO — Şəxsi hesab → Vergi və DSMF borcu (UI) */
(function () {
  'use strict';
  const E = window.SHEngine;
  const $ = (s) => document.querySelector(s);
  const AZ_MONTHS = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
  const LS_KEY = 'ammo_sexsi_hesab_v1';

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  const fmt = (c) => { const v = (c || 0) / 100; const s = Math.abs(v).toFixed(2).split('.'); return (v < 0 ? '-' : '') + s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + '.' + s[1]; };
  const qSuffix = (q) => (q === 3 || q === 4 ? 'cü' : 'ci');
  function toast(t) { const x = $('#toast'); x.textContent = t; x.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => x.classList.remove('show'), 2800); }

  // ---------- Saxlanan seçimlər ----------
  let settings = { manager: '', prepared: '', seal: '', mapping: {}, detailed: false, showZeroExtra: false };
  try { const s = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); if (s) settings = { ...settings, ...s, mapping: s.mapping || {} }; } catch (e) { /* boş */ }
  function save() { try { localStorage.setItem(LS_KEY, JSON.stringify(settings)); } catch (e) { toast('Seçimlər yadda saxlanmadı (yaddaş dolu ola bilər).'); } }

  // ---------- Vəziyyət ----------
  let pendingFile = null;
  let result = null;
  let overrides = {};
  const docInfo = { name: '', voen: '', period: '', docDate: '', notice: '' };

  function isoToday() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
  function periodFor(d) { const q = Math.floor(d.getMonth() / 3) + 1; return { text: `${AZ_MONTHS[d.getMonth()]} ${d.getFullYear()} · ${q} RÜB`, q }; }
  function noticeFor(q) { return `Salam, ${q}-${qSuffix(q)} rüb DSMF və vergi öhdəlikləri. Diqqət! Öhdəliklər 5 iş günü içində ödənilmədiyi halda bankınıza sərəncam daxil olacaq.`; }
  function shortName(n) {
    return E.clean(n)
      .replace(/Məhdud\s+Məsuliyyətli\s+Cəmiyyəti/i, 'MMC')
      .replace(/Açıq\s+Səhmdar\s+Cəmiyyəti/i, 'ASC')
      .replace(/Qapalı\s+Səhmdar\s+Cəmiyyəti/i, 'QSC')
      .replace(/Səhmdar\s+Cəmiyyəti/i, 'SC');
  }

  // ---------- Faylın oxunması ----------
  async function readStatement(file) {
    const buf = new Uint8Array(await file.arrayBuffer());
    const head = String.fromCharCode(...buf.slice(0, 8));
    const isZip = head.startsWith('PK'), isOle = buf[0] === 0xD0 && buf[1] === 0xCF;
    if (!isZip && !isOle) {
      let text;
      try { text = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (e) { text = new TextDecoder('windows-1252').decode(buf); }
      if (/<t[dr][\s>]/i.test(text)) return E.streamFromHtml(text);
    }
    if (!window.XLSX) throw new Error('Excel oxuyucu yüklənmədi.');
    const wb = XLSX.read(buf, { type: 'array', raw: false });
    let items = [];
    for (const name of wb.SheetNames) items = items.concat(E.streamFromRows(XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, raw: false, defval: '' })));
    return items;
  }

  function setFile(f) {
    if (!f) return;
    pendingFile = f;
    $('#drop').classList.add('loaded');
    $('#dropTitle').textContent = f.name;
    $('#dropSub').textContent = `${(f.size / 1024).toFixed(0)} KB · hazırdır — DOLDUR düyməsini basın`;
    $('#fillBtn').disabled = false;
    showMsg('');
  }
  function showMsg(t, err) { const m = $('#msg'); if (!t) { m.classList.add('hidden'); return; } m.textContent = t; m.classList.toggle('err', !!err); m.classList.remove('hidden'); }

  async function fill() {
    if (!pendingFile) return;
    $('#fillBtn').disabled = true; $('#fillBtn').textContent = 'Hesablanır…';
    try {
      const items = await readStatement(pendingFile);
      const res = E.analyze(items);
      if (!Object.keys(res.sections).length) throw new Error('Bu faylda şəxsi hesab vərəqəsinin cədvəlləri tapılmadı. e-taxes-dən yüklənmiş "Şəxsi hesab vərəqəsi" faylını seçin.');
      result = res; overrides = {};
      const d = res.printDate || new Date(); const p = periodFor(d);
      docInfo.name = res.entity.name ? shortName(res.entity.name) : '';
      docInfo.voen = res.entity.voen || '';
      docInfo.period = p.text;
      docInfo.docDate = isoToday();
      docInfo.notice = noticeFor(p.q);
      syncDocInputs();
      render();
      const allOk = Object.values(res.sections).every((s) => s.check.ok);
      showMsg(allOk ? '✓ Forma dolduruldu. Bütün bölmələr vərəqədəki qalıqla qəpiyinədək uyğundur.' : 'Forma dolduruldu, lakin bəzi bölmələrdə fərq var — yuxarıdakı xəbərdarlığa baxın.', !allOk);
    } catch (e) {
      console.error(e);
      showMsg(e.message || 'Fayl oxunmadı.', true);
    } finally {
      $('#fillBtn').disabled = false; $('#fillBtn').textContent = 'DOLDUR';
    }
  }

  // ---------- Model (forma, PDF və Excel üçün eyni) ----------
  function buildModel() {
    const f = result ? E.buildForm(result, settings.mapping) : null;
    const mk = (defs) => defs.map((d) => {
      const r = f ? f[d.key] : { principal: 0, penalty: 0, sources: [] };
      const o = overrides[d.key] || {};
      const principal = o.principal != null ? o.principal : r.principal;
      const penalty = o.penalty != null ? o.penalty : r.penalty;
      return { key: d.key, label: d.label, side: d.side || '', extra: !!d.extra, principal, penalty, total: principal + penalty, manual: o.principal != null || o.penalty != null, sources: r.sources || [] };
    }).filter((r) => !r.extra || settings.showZeroExtra || r.total !== 0);
    const taxRows = mk(E.TAX_ROWS), socialRows = mk(E.SOCIAL_ROWS);
    const sum = (a, k) => a.reduce((x, r) => x + r[k], 0);
    const t = { principal: sum(taxRows, 'principal'), penalty: sum(taxRows, 'penalty'), total: sum(taxRows, 'total') };
    const s = { principal: sum(socialRows, 'principal'), penalty: sum(socialRows, 'penalty'), total: sum(socialRows, 'total') };
    const emp = sum(socialRows.filter((r) => r.side === 'emp'), 'total');
    const er = sum(socialRows.filter((r) => r.side === 'er'), 'total');
    return {
      ...docInfo, manager: settings.manager, prepared: settings.prepared, seal: settings.seal, detailed: settings.detailed,
      taxRows, socialRows, taxTotal: t, socialTotal: s,
      grand: { principal: t.principal + s.principal, penalty: t.penalty + s.penalty, total: t.total + s.total },
      empTotal: emp, erTotal: er, otherSocialTotal: s.total - emp - er,
      result, mapping: settings.mapping
    };
  }

  // ---------- Formanın çəkilməsi ----------
  function amtCell(r, part) {
    const v = part === 'total' ? r.total : r[part];
    return `<td class="num"><input class="amt${r.manual ? ' manual' : ''}" data-key="${r.key}" data-part="${part}" value="${fmt(v)}" ${result ? '' : 'readonly'} title="Düzəliş etmək üçün klikləyin"></td>`;
  }
  function renderPaper(m) {
    const det = m.detailed;
    const head = det ? '<th>VERGİ ÖHDƏLİYİ</th><th>ƏSAS BORC</th><th>FAİZ / PENYA</th><th>CƏMİ (AZN)</th>' : '<th>VERGİ ÖHDƏLİYİ</th><th>BORC (AZN)</th>';
    const cols = det ? 4 : 2;
    const row = (r) => `<tr class="${r.extra ? 'extra' : ''}"><td><span class="req-link" data-req="${r.key}" title="Rekvizitlərə bax / redaktə et">${esc(r.label)}</span></td>${det ? amtCell(r, 'principal') + amtCell(r, 'penalty') + `<td class="num">${fmt(r.total)}</td>` : amtCell(r, 'total')}</tr>`;
    const tot = (label, t, cls) => `<tr class="${cls}"><td>${label}</td>${det ? `<td class="num">${fmt(t.principal)}</td><td class="num">${fmt(t.penalty)}</td>` : ''}<td class="num">${fmt(t.total)}</td></tr>`;
    const seal = m.seal ? `<img class="seal-img" src="${m.seal}" alt="Möhür"><small>Möhür</small>` : '<div class="seal-ph">M.Y.</div><small>Möhür yeri</small>';
    $('#paper').innerHTML = `
      <div class="doc-header"><div class="doc-brand">ƏMƏK HAQQI VƏ HESABATLAR</div><h1>VERGİ VƏ DSMF ÖHDƏLİKLƏRİ</h1></div>
      <table class="doc-meta"><tr><td>Vergi ödəyicisi:</td><td>${esc(m.name || '—')}</td><td>VÖEN:</td><td>${esc(m.voen || '—')}</td></tr>
      <tr><td>Dövr:</td><td>${esc(m.period || '—')}</td><td>Sənəd tarixi:</td><td>${esc(m.docDate || '—')}</td></tr></table>
      <table class="doc-table${det ? ' detailed' : ''}"><thead><tr>${head}</tr></thead><tbody>
      ${m.taxRows.map(row).join('')}
      ${tot('CƏMİ VERGİ BORCU', m.taxTotal, 'subtotal')}
      <tr class="section"><td colspan="${cols}">DSMF ÖHDƏLİKLƏRİ</td></tr>
      ${m.socialRows.map(row).join('')}
      ${tot('CƏMİ DSMF ÖHDƏLİKLƏRİ', m.socialTotal, 'subtotal')}
      ${tot('CƏMİ VERGİ VƏ CƏMİ DSMF BORCU', m.grand, 'grand')}
      </tbody></table>
      <div class="notice">${esc(m.notice)}</div>
      <table class="doc-signatures"><tr>
        <td><b>Rəhbər:</b><div class="sig-line">${esc(m.manager)}</div><small>Ad, soyad / imza</small></td>
        <td class="seal-box">${seal}</td>
        <td><b>Hazırladı:</b><div class="sig-line">${esc(m.prepared)}</div><small>Ad, soyad / imza</small></td>
      </tr></table>`;
  }

  function renderChecks(m) {
    const box = $('#checks');
    if (!result) { box.innerHTML = ''; return; }
    const chips = [];
    chips.push(`<span class="chip info">Vergi borcu: <b>${fmt(m.taxTotal.total)}</b></span>`);
    chips.push(`<span class="chip info">DSMF — işçidən tutulan: <b>${fmt(m.empTotal)}</b></span>`);
    chips.push(`<span class="chip info">DSMF — işəgötürən hesabına: <b>${fmt(m.erTotal)}</b></span>`);
    if (m.otherSocialTotal) chips.push(`<span class="chip info">DSMF — F/Ş və digər: <b>${fmt(m.otherSocialTotal)}</b></span>`);
    chips.push(`<span class="chip info">Cəmi: <b>${fmt(m.grand.total)} AZN</b></span>`);
    box.innerHTML = chips.join('');
    const manual = Object.keys(overrides).length;
    let sub = `${esc(result.entity.name || '')} · ${Object.values(result.sections).map((s) => s.title).join(', ')}`;
    if (manual) sub += ` · <b>${manual} xanada əl ilə düzəliş</b> <button class="link" id="resetOverrides">sıfırla</button>`;
    $('#subline').innerHTML = sub;
    const ro = $('#resetOverrides'); if (ro) ro.onclick = () => { overrides = {}; render(); };
  }

  function targetOptions(section, current) {
    const defs = section === 'tax' ? E.TAX_ROWS : E.SOCIAL_ROWS;
    const other = section === 'tax' ? E.SOCIAL_ROWS : E.TAX_ROWS;
    const opt = (d) => `<option value="${d.key}"${d.key === current ? ' selected' : ''}>${esc(d.label)}</option>`;
    return `<optgroup label="${section === 'tax' ? 'Vergi bölməsi' : 'DSMF bölməsi'}">${defs.map(opt).join('')}</optgroup><optgroup label="${section === 'tax' ? 'DSMF bölməsi' : 'Vergi bölməsi'}">${other.map(opt).join('')}</optgroup>`;
  }
  function renderDetail() {
    const card = $('#detailCard');
    if (!result) { card.classList.add('hidden'); return; }
    card.classList.remove('hidden');
    const cats = Object.values(result.cats);
    let html = '<thead><tr><th>Vərəqədəki öhdəlik</th><th class="n">Əsas borc</th><th class="n">Faiz / penya</th><th class="n">Cəmi</th><th>Formada sətir</th></tr></thead><tbody>';
    let gp = 0, gq = 0;
    for (const sk of Object.keys(E.SECTIONS)) {
      const s = result.sections[sk]; if (!s) continue;
      const c = s.check;
      const status = c.ok ? '✓ vərəqə ilə uyğun' : `⚠ fərq: vərəqə ${fmt(c.expectedPrincipal)} / ${fmt(c.expectedPenalty)}`;
      const extra = [];
      if (s.credit > 0 && s.finalBal <= 0) extra.push(`artıq ödəmə ${fmt(s.credit)}`);
      if (s.printAdjusted) extra.push(`faiz çap tarixinə (${result.summary['CAP OLUNMA TARIXI'] || ''}) yenilənib`);
      html += `<tr class="sec"><td colspan="5">${esc(s.title)} <span style="font-weight:500;color:${c.ok ? '#067647' : '#b54708'};margin-left:8px">${status}</span>${extra.length ? `<span style="font-weight:500;color:#667085;margin-left:8px">· ${esc(extra.join(' · '))}</span>` : ''}<span style="float:right;font-weight:500;color:#667085">son yazılış: ${esc(s.lastDate)} · ${s.rowCount} sətir</span></td></tr>`;
      const list = cats.filter((x) => x.section === sk);
      if (!list.length) html += '<tr><td colspan="5" style="color:#667085">Borc yoxdur</td></tr>';
      for (const x of list) {
        const target = settings.mapping[x.key] || x.defaultTarget;
        const def = E.ALL_ROWS.find((r) => r.key === target) || {};
        const tag = def.side === 'emp' ? '<span class="side-tag emp">işçi</span>' : def.side === 'er' ? '<span class="side-tag er">işəgötürən</span>' : '';
        gp += x.principal; gq += x.penalty;
        html += `<tr><td>${esc(x.label)}${tag}</td><td class="n">${fmt(x.principal)}</td><td class="n">${fmt(x.penalty)}</td><td class="n"><b>${fmt(x.principal + x.penalty)}</b></td><td><select data-cat="${esc(x.key)}">${targetOptions(x.section, target)}</select></td></tr>`;
      }
    }
    html += `<tr class="tot"><td>Cəmi</td><td class="n">${fmt(gp)}</td><td class="n">${fmt(gq)}</td><td class="n">${fmt(gp + gq)}</td><td></td></tr></tbody>`;
    if (result.notes.length) html += `<tfoot><tr><td colspan="5" style="color:#b54708;font-size:12px">${result.notes.map(esc).join('<br>')}</td></tr></tfoot>`;
    $('#detailTable').innerHTML = html;
  }

  function render() {
    const m = buildModel();
    renderPaper(m); renderChecks(m); renderDetail();
    ['#xlsxBtn', '#pdfBtn', '#printBtn'].forEach((s) => { $(s).disabled = !result; });
  }

  function syncDocInputs() {
    $('#fName').value = docInfo.name; $('#fVoen').value = docInfo.voen; $('#fPeriod').value = docInfo.period;
    $('#fDocDate').value = docInfo.docDate; $('#fNotice').value = docInfo.notice;
  }

  // ---------- Hadisələr ----------
  const drop = $('#drop');
  $('#fileInput').addEventListener('change', (e) => { setFile(e.target.files[0]); e.target.value = ''; });
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => { const f = e.dataTransfer.files[0]; if (f) setFile(f); });
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', (e) => { e.preventDefault(); const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) setFile(f); });
  $('#fillBtn').addEventListener('click', fill);

  const bindDoc = (sel, key) => $(sel).addEventListener('input', (e) => { docInfo[key] = e.target.value; render(); });
  bindDoc('#fName', 'name'); bindDoc('#fVoen', 'voen'); bindDoc('#fPeriod', 'period'); bindDoc('#fDocDate', 'docDate'); bindDoc('#fNotice', 'notice');
  const bindSet = (sel, key) => $(sel).addEventListener('input', (e) => { settings[key] = e.target.value; save(); render(); });
  bindSet('#fManager', 'manager'); bindSet('#fPrepared', 'prepared');
  $('#fDetailed').addEventListener('change', (e) => { settings.detailed = e.target.checked; save(); render(); });
  $('#fShowZeroExtra').addEventListener('change', (e) => { settings.showZeroExtra = e.target.checked; save(); render(); });

  $('#paper').addEventListener('change', (e) => {
    const el = e.target.closest('.amt'); if (!el) return;
    const key = el.dataset.key, part = el.dataset.part;
    const v = E.cents(el.value.replace(/\s/g, '').replace(',', '.'));
    const m = buildModel(); const r = [...m.taxRows, ...m.socialRows].find((x) => x.key === key); if (!r) return;
    const o = overrides[key] = overrides[key] || {};
    if (part === 'total') { o.penalty = r.penalty; o.principal = v - r.penalty; }
    else { o[part] = v; if (o.principal == null) o.principal = r.principal; if (o.penalty == null) o.penalty = r.penalty; }
    render();
  });
  $('#paper').addEventListener('focusin', (e) => { if (e.target.classList.contains('amt')) e.target.select(); });
  $('#paper').addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.classList.contains('amt')) e.target.blur(); });

  $('#detailTable').addEventListener('change', (e) => {
    const sel = e.target.closest('select[data-cat]'); if (!sel) return;
    const cat = result.cats[sel.dataset.cat];
    if (sel.value === cat.defaultTarget) delete settings.mapping[cat.key]; else settings.mapping[cat.key] = sel.value;
    save(); overrides = {}; render(); toast('Uyğunlaşdırma yadda saxlanıldı.');
  });

  $('#sealInput').addEventListener('change', async (e) => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    try {
      const url = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
      const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
      const k = Math.min(1, 500 / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
      const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0, c.width, c.height);
      const d = ctx.getImageData(0, 0, c.width, c.height); // ağ fonu şəffaf et
      for (let i = 0; i < d.data.length; i += 4) { const r = d.data[i], g = d.data[i + 1], b = d.data[i + 2]; if (r > 235 && g > 235 && b > 235) d.data[i + 3] = 0; }
      ctx.putImageData(d, 0, 0);
      settings.seal = c.toDataURL('image/png'); save(); syncSeal(); render();
    } catch (err) { toast('Şəkil oxunmadı.'); }
  });
  $('#sealClear').addEventListener('click', () => { settings.seal = ''; save(); syncSeal(); render(); });
  function syncSeal() { $('#sealPreview').src = settings.seal || ''; $('#sealPreview').classList.toggle('hidden', !settings.seal); $('#sealClear').classList.toggle('hidden', !settings.seal); }

  function fileBase() { return `Vergi_DSMF_${(docInfo.voen || 'borc').replace(/[^\w-]/g, '')}_${docInfo.docDate || isoToday()}`; }
  $('#pdfBtn').addEventListener('click', async () => {
    try { await window.SHExport.pdf(buildModel(), fileBase() + '.pdf'); toast('PDF yükləndi.'); } catch (e) { console.error(e); toast('PDF yaradılmadı: ' + e.message); }
  });
  $('#xlsxBtn').addEventListener('click', async () => {
    try { await window.SHExport.xlsx(buildModel(), fileBase() + '.xlsx'); toast('Excel yükləndi.'); } catch (e) { console.error(e); toast('Excel yaradılmadı: ' + e.message); }
  });
  $('#printBtn').addEventListener('click', () => window.print());

  // ---------- Başlanğıc ----------
  $('#fManager').value = settings.manager; $('#fPrepared').value = settings.prepared;
  $('#fDetailed').checked = settings.detailed; $('#fShowZeroExtra').checked = settings.showZeroExtra;
  const p0 = periodFor(new Date());
  docInfo.period = p0.text; docInfo.docDate = isoToday(); docInfo.notice = noticeFor(p0.q);
  syncDocInputs(); syncSeal(); render();

  window.addEventListener('ammo-cloud-updated', () => {
    try { const s = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); if (s) settings = { ...settings, ...s, mapping: s.mapping || {} }; } catch (e) { /* boş */ }
    $('#fManager').value = settings.manager; $('#fPrepared').value = settings.prepared;
    $('#fDetailed').checked = settings.detailed; $('#fShowZeroExtra').checked = settings.showZeroExtra; syncSeal(); render();
  });
  window.__SH = { setFile, fill, buildModel }; // test üçün
})();
