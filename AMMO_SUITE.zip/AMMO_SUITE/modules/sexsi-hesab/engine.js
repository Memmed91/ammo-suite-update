/* AMMO — Şəxsi hesab vərəqəsi → Vergi və DSMF borcları
   Bu fayl yalnız hesablama məntiqidir (UI yoxdur). Bütün məbləğlər qəpiklə (tam ədəd) hesablanır.

   Məntiq:
   - Vərəqənin hər bölməsində (Vergilər, MDSS, İşsizlik, İTS) "Qalıq/Artıq ödəmə" və
     "Faiz/Penya" sütunları işlək (running) saldodur.
   - Hər sətirdə saldonun dəyişməsi (delta) tapılır və həmin sətrin öhdəlik növünə yazılır.
   - Azalma/ödəniş saldonu azaldanda əvvəlcə adı çəkilən növ, sonra ən köhnə borclar bağlanır (FIFO).
   - Beləliklə son qalıq növlər üzrə dəqiq bölünür və cəmi vərəqədəki qalıqla qəpiyinədək üst-üstə düşür. */
(function (root) {
  'use strict';

  // ---------- Formadakı sətirlər ----------
  const TAX_ROWS = [
    { key: 'sv', label: 'SV' },
    { key: 'edv', label: 'ƏDV', extra: true },
    { key: 'omv', label: 'ÖMV' },
    { key: 'muzdlu', label: 'Muzdlu işdən gəlir vergisi', extra: true },
    { key: 'mv', label: 'MV / Gəlir-Mənfəət vergisi' },
    { key: 'property', label: 'Əmlak vergisi' },
    { key: 'land', label: 'Torpaq vergisi' },
    { key: 'road', label: 'Yol vergisi' },
    { key: 'otherTax', label: 'Digər vergi borcları', extra: true }
  ];
  const SOCIAL_ROWS = [
    { key: 'fsIncome', label: 'Fərdi sahibkar Gəlir vergisi' },
    { key: 'fsMedical', label: 'F/Ş tərəfindən ödənilən İcbari Tibbi Sığorta' },
    { key: 'fsSocial', label: 'Fərdi sahibkarın öz DSMF haqqı', extra: true },
    { key: 'empP', label: 'Pensiya Fondu (işçidən tutulan)', side: 'emp' },
    { key: 'erP', label: 'Pensiya Fondu (işəgötürən tərəfindən)', side: 'er' },
    { key: 'empUn', label: 'İşsizlikdən Sığorta Haqqı (sığortaolunan tərəfindən)', side: 'emp' },
    { key: 'erUn', label: 'İşsizlikdən Sığorta Haqqı (sığortaedən tərəfindən)', side: 'er' },
    { key: 'empMed', label: 'İcbari sığorta (işçidən tutulan)', side: 'emp' },
    { key: 'erMed', label: 'İcbari sığorta (işəgötürən tərəfindən)', side: 'er' },
    { key: 'otherSocial', label: 'Digər DSMF borcları', extra: true }
  ];
  const ALL_ROWS = [...TAX_ROWS, ...SOCIAL_ROWS];

  // ---------- Vərəqədə tanınan öhdəlik növləri və formadakı default sətir ----------
  const CATS = {
    'T:SV': { label: 'Sadələşdirilmiş vergi', target: 'sv' },
    'T:EDV': { label: 'ƏDV', target: 'edv' },
    'T:OMV': { label: 'ÖMV (ödəmə mənbəyində vergi)', target: 'omv' },
    'T:MUZDLU': { label: 'Muzdlu işdən gəlir vergisi (vahid bəyannamə)', target: 'muzdlu' },
    'T:MV': { label: 'Mənfəət vergisi', target: 'mv' },
    'T:GV': { label: 'Gəlir vergisi (fərdi sahibkar)', target: 'mv' },
    'T:EMLAK': { label: 'Əmlak vergisi', target: 'property' },
    'T:TORPAQ': { label: 'Torpaq vergisi', target: 'land' },
    'T:YOL': { label: 'Yol vergisi', target: 'road' },
    'T:AKSIZ': { label: 'Aksiz', target: 'otherTax' },
    'T:MEDEN': { label: 'Mədən vergisi', target: 'otherTax' },
    'T:OTHER': { label: 'Digər vergi əməliyyatları', target: 'otherTax' },
    'T:OPEN': { label: 'Vergilər — dövrün əvvəlindən keçən qalıq', target: 'otherTax' },

    'P:OLUNAN': { label: 'MDSS — sığortaolunan (işçidən tutulan)', target: 'empP' },
    'P:EDEN': { label: 'MDSS — sığortaedən (işəgötürən)', target: 'erP' },
    'P:SANATORIYA': { label: 'MDSS — sanatoriya', target: 'erP' },
    'P:MULKI': { label: 'MDSS — mülki müqavilə', target: 'empP' },
    'P:FS': { label: 'MDSS — fərdi sahibkarın özü', target: 'fsSocial' },
    'P:OTHER': { label: 'MDSS — digər', target: 'otherSocial' },
    'P:OPEN': { label: 'MDSS — dövrün əvvəlindən keçən qalıq', target: 'otherSocial' },

    'U:OLUNAN': { label: 'İşsizlik — sığortaolunan (işçidən tutulan)', target: 'empUn' },
    'U:EDEN': { label: 'İşsizlik — sığortaedən (işəgötürən)', target: 'erUn' },
    'U:OTHER': { label: 'İşsizlik — digər', target: 'otherSocial' },
    'U:OPEN': { label: 'İşsizlik — dövrün əvvəlindən keçən qalıq', target: 'otherSocial' },

    'M:OLUNAN': { label: 'İTS — sığortaolunan (işçidən tutulan)', target: 'empMed' },
    'M:SIGORTALI': { label: 'İTS — sığortalı (işəgötürən)', target: 'erMed' },
    'M:MULKI': { label: 'İTS — mülki müqavilə', target: 'empMed' },
    'M:FIZIKI': { label: 'İTS — fiziki şəxs / F/Ş özü', target: 'fsMedical' },
    'M:OTHER': { label: 'İTS — digər', target: 'otherSocial' },
    'M:OPEN': { label: 'İTS — dövrün əvvəlindən keçən qalıq', target: 'otherSocial' }
  };

  const SECTIONS = {
    tax: { title: 'Vergilər', prefix: 'T', penaltyName: 'Faiz' },
    mdss: { title: 'MDSS (pensiya)', prefix: 'P', penaltyName: 'Penya' },
    unemp: { title: 'İşsizlikdən sığorta', prefix: 'U', penaltyName: 'Penya' },
    its: { title: 'İcbari tibbi sığorta', prefix: 'M', penaltyName: 'Faiz' }
  };

  // ---------- Köməkçilər ----------
  const clean = (s) => String(s == null ? '' : s).replace(/ /g, ' ').replace(/\s+/g, ' ').trim();
  function fold(s) {
    return clean(s).toLocaleUpperCase('az')
      .replace(/İ/g, 'I').replace(/Ə/g, 'E').replace(/Ö/g, 'O').replace(/Ü/g, 'U')
      .replace(/Ş/g, 'S').replace(/Ç/g, 'C').replace(/Ğ/g, 'G').replace(/I/g, 'I');
  }
  /** "3.476,15" → 347615 (qəpik). Boş → 0. */
  function cents(v) {
    if (typeof v === 'number') return Math.round(v * 100);
    let s = clean(v).replace(/\s/g, '').replace(/[^\d,.\-]/g, '');
    if (!s || s === '-' ) return 0;
    if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
    else if ((s.match(/\./g) || []).length > 1) s = s.replace(/\./g, '');
    else if (/^\-?\d{1,3}\.\d{3}$/.test(s)) s = s.replace('.', ''); // "1.234" → min ayırıcı
    const n = Number(s);
    return Number.isFinite(n) ? Math.round(n * 100) : 0;
  }
  const isDate = (s) => /^\d{1,2}[./]\d{1,2}[./]\d{4}$/.test(clean(s));
  function parseDate(s) {
    const m = clean(s).match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);
    return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null;
  }

  // ---------- Fayl → "axın" (başlıqlar və cədvəl sətirləri ardıcıllıqla) ----------
  function streamFromHtml(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const items = [];
    let buf = '';
    const flush = () => { const t = clean(buf); if (t) items.push({ type: 'heading', text: t }); buf = ''; };
    const walker = doc.createTreeWalker(doc.body || doc.documentElement, 1 | 4); // ELEMENT | TEXT
    let node;
    while ((node = walker.nextNode())) {
      if (node.nodeType === 3) {
        if (!node.parentElement || !node.parentElement.closest('table')) buf += ' ' + node.nodeValue;
      } else if (node.tagName === 'TABLE') {
        flush();
      } else if (node.tagName === 'TR') {
        // yalnız bu cədvəlin öz xanaları (iç-içə cədvəl olarsa)
        const cells = [...node.children].filter((c) => c.tagName === 'TD' || c.tagName === 'TH').map((c) => clean(c.textContent));
        items.push({ type: 'row', cells });
      } else if (node.tagName === 'BR') {
        buf += ' ';
      }
    }
    flush();
    return items;
  }
  function streamFromRows(rows) { // SheetJS sheet_to_json(header:1)
    const items = [];
    for (const r of rows) {
      const cells = (r || []).map((v) => clean(v));
      const filled = cells.filter(Boolean);
      if (!filled.length) continue;
      if (filled.length === 1 && !isDate(filled[0]) && filled[0].length > 12) items.push({ type: 'heading', text: filled[0] });
      else items.push({ type: 'row', cells });
    }
    return items;
  }

  // ---------- Növlərin tanınması ----------
  function classifyHeading(text) {
    const f = fold(text);
    const marks = [
      ['mdss', f.lastIndexOf('MDSS')],
      ['unemp', f.lastIndexOf('ISSIZLIK')],
      ['its', f.lastIndexOf('TIBBI')],
      ['tax', Math.max(f.lastIndexOf('VERGILER UZRE'), f.lastIndexOf('VERGI UZRE'))]
    ].filter((x) => x[1] >= 0).sort((a, b) => b[1] - a[1]);
    return marks.length ? marks[0][0] : null;
  }
  function taxCatOf(text) {
    const f = ' ' + fold(text) + ' ';
    if (/MUZDLU/.test(f)) return 'T:MUZDLU';
    if (/\bEDV\b/.test(f)) return 'T:EDV';
    if (/\bOMV\b|ODEME MENBEYINDE/.test(f)) return 'T:OMV';
    if (/SADELESDIRILMIS|\bSV\b/.test(f)) return 'T:SV';
    if (/\bMV\b|MENFEET/.test(f)) return 'T:MV';
    if (/GELIR VERGISI|\bGV\b/.test(f)) return 'T:GV';
    if (/EMLAK/.test(f)) return 'T:EMLAK';
    if (/TORPAQ/.test(f)) return 'T:TORPAQ';
    if (/\bYOL\b/.test(f)) return 'T:YOL';
    if (/AKSIZ/.test(f)) return 'T:AKSIZ';
    if (/MEDEN/.test(f)) return 'T:MEDEN';
    return null;
  }
  function socialSideOf(prefix, text) {
    const f = fold(text);
    const inside = (f.match(/\(([^)]*)\)/) || [])[1] || f;
    if (/OLUNAN/.test(inside)) return prefix + ':OLUNAN';
    if (/EDEN/.test(inside)) return prefix === 'M' ? 'M:SIGORTALI' : prefix + ':EDEN';
    if (/SIGORTALI/.test(inside)) return prefix === 'M' ? 'M:SIGORTALI' : prefix + ':EDEN';
    if (/SANATORIYA/.test(inside) && prefix === 'P') return 'P:SANATORIYA';
    if (/MULKI/.test(inside)) return prefix === 'U' ? 'U:OTHER' : prefix + ':MULKI';
    if (/FIZIKI|FERDI|SAHIBKAR|OZ XEYRINE/.test(inside)) return prefix === 'M' ? 'M:FIZIKI' : prefix === 'P' ? 'P:FS' : 'U:OTHER';
    return null;
  }
  function isPaymentRow(name, kind) {
    const k = fold(kind), n = fold(name);
    return /ODENIS/.test(k) || /^ODEME TAPSIRIGI|^SERENCAM|^INKASSO/.test(n);
  }

  // ---------- Bölmə sətirlərinin oxunması ----------
  function parseStatement(items) {
    const out = { entity: { name: '', voen: '' }, sections: {}, summary: {}, warnings: [] };
    let section = null, layout = null, headingSeen = false;
    for (const it of items) {
      if (it.type === 'heading') {
        if (!out.entity.voen) {
          const m = it.text.match(/^(.*?)\(\s*V[ÖO]EN\s*:?\s*(\d{6,})\s*\)/i);
          if (m) { out.entity.name = clean(m[1]); out.entity.voen = m[2]; }
        }
        const s = classifyHeading(it.text);
        if (s) { section = s; layout = null; headingSeen = true; }
        continue;
      }
      const c = it.cells;
      const f0 = fold(c[0]);
      if (/YAZILIS TARIXI/.test(f0)) {
        const head = fold(c.join(' | '));
        layout = /PENYA/.test(head) ? 'B' : 'A';
        // başlıq yoxdursa — sütunlardan təxmin et
        if (!section) section = layout === 'B' ? 'mdss' : 'tax';
        continue;
      }
      if (isDate(c[0]) && c.length >= 6 && section && layout) {
        const r = { date: c[0], name: c[1] || '', kind: c[2] || '', payDate: c[3] || '', amount: cents(c[4]) };
        if (layout === 'A') { r.bal = cents(c[5]) - cents(c[6]); r.pen = cents(c[7]); r.raw = { qaliq: c[5], artiq: c[6], faiz: c[7] }; }
        else { r.bal = cents(c[5]) - cents(c[6]) + cents(c[9]) - cents(c[10]); r.pen = cents(c[7]) - cents(c[8]); r.raw = { qaliq: c[5], artiq: c[6], penya: c[7], penyaArtiq: c[8], diger: c[9], digerArtiq: c[10] }; }
        (out.sections[section] = out.sections[section] || { key: section, rows: [] }).rows.push(r);
        continue;
      }
      // Yekun cədvəli: "Etiket | Dəyər"
      const filled = c.filter(Boolean);
      if (filled.length === 2 && !isDate(filled[0])) out.summary[fold(filled[0])] = filled[1];
    }
    if (!headingSeen && !Object.keys(out.sections).length) out.warnings.push('Vərəqədə bölmə tapılmadı.');
    return out;
  }

  // ---------- Bölüşdürmə mühərriki ----------
  function makeLedger() {
    return { lots: [], credit: 0 };
  }
  function ledgerAdd(L, cat, d) {
    if (d <= 0) return;
    if (L.credit > 0) { const u = Math.min(L.credit, d); L.credit -= u; d -= u; }
    if (d > 0) {
      const last = L.lots[L.lots.length - 1];
      if (last && last.cat === cat) last.amt += d; else L.lots.push({ cat, amt: d });
    }
  }
  function ledgerReduce(L, d, prefCats) {
    let r = d;
    if (prefCats && prefCats.length) {
      for (const lot of L.lots) { if (r <= 0) break; if (prefCats.includes(lot.cat) && lot.amt > 0) { const u = Math.min(lot.amt, r); lot.amt -= u; r -= u; } }
    }
    for (const lot of L.lots) { if (r <= 0) break; if (lot.amt > 0) { const u = Math.min(lot.amt, r); lot.amt -= u; r -= u; } }
    L.lots = L.lots.filter((l) => l.amt > 0);
    if (r > 0) L.credit += r;
  }
  function ledgerTotals(L) {
    const t = {};
    for (const l of L.lots) t[l.cat] = (t[l.cat] || 0) + l.amt;
    return t;
  }
  /** Məbləği çəkilərə görə qəpik dəqiqliyi ilə böl (ən böyük qalıq üsulu). */
  function splitByWeights(total, weights) {
    const keys = Object.keys(weights).filter((k) => weights[k] > 0);
    const sum = keys.reduce((a, k) => a + weights[k], 0);
    const res = {};
    if (!sum || !total) return res;
    let used = 0;
    const rem = keys.map((k) => { const exact = total * weights[k] / sum; const fl = Math.floor(exact); res[k] = fl; used += fl; return [k, exact - fl]; });
    rem.sort((a, b) => b[1] - a[1]);
    for (let i = 0; used < total && i < rem.length; i++, used++) res[rem[i][0]]++;
    return res;
  }

  function catForRow(prefix, r) {
    const pay = isPaymentRow(r.name, r.kind);
    if (pay) {
      const tail = r.name.split(' - ').slice(-1)[0];
      const named = prefix === 'T' ? taxCatOf(tail) : null;
      return { pay: true, cat: named, fallback: prefix + ':OTHER' };
    }
    const cat = prefix === 'T' ? taxCatOf(r.name) : socialSideOf(prefix, r.name);
    return { pay: false, cat: cat || prefix + ':OTHER', fallback: prefix + ':OTHER' };
  }

  function allocateSection(sec) {
    const meta = SECTIONS[sec.key];
    const P = meta.prefix;
    const main = makeLedger(), pen = makeLedger();
    const rows = sec.rows;
    if (!rows.length) return null;

    // Açılış saldosu: ilk sətirdən geriyə hesablanır
    const r0 = rows[0];
    const c0 = catForRow(P, r0);
    const isDown = c0.pay || /AZALMA/.test(fold(r0.kind));
    const opening = r0.bal - (isDown ? -r0.amount : r0.amount);
    let prevBal = 0, prevPen = 0;
    if (opening > 0) { ledgerAdd(main, P + ':OPEN', opening); prevBal = opening; }
    else if (opening < 0) { main.credit = -opening; prevBal = opening; }

    for (const r of rows) {
      const info = catForRow(P, r);
      const dBal = r.bal - prevBal;
      const dPen = r.pen - prevPen;
      r.cat = info.cat || null;
      r.dBal = dBal; r.dPen = dPen;
      // Əsas borc
      if (dBal > 0) ledgerAdd(main, info.cat || info.fallback, dBal);
      else if (dBal < 0) ledgerReduce(main, -dBal, info.cat ? [info.cat] : null);
      // Faiz / penya
      if (dPen > 0) {
        if (!info.pay && info.cat) ledgerAdd(pen, info.cat, dPen);
        else {
          // ödəniş sətirində faiz artımı — hesablanma anına qədər yığılan faizdir, cari borcla mütənasib bölünür
          const w = ledgerTotals(main);
          if (Object.keys(w).length) { const parts = splitByWeights(dPen, w); for (const k in parts) ledgerAdd(pen, k, parts[k]); }
          else {
            const pw = ledgerTotals(pen);
            if (Object.keys(pw).length) { const parts = splitByWeights(dPen, pw); for (const k in parts) ledgerAdd(pen, k, parts[k]); }
            else ledgerAdd(pen, info.cat || info.fallback, dPen);
          }
        }
      } else if (dPen < 0) ledgerReduce(pen, -dPen, info.cat ? [info.cat] : null);
      prevBal = r.bal; prevPen = r.pen;
    }
    const last = rows[rows.length - 1];
    return {
      key: sec.key, title: meta.title, penaltyName: meta.penaltyName,
      principal: ledgerTotals(main), penalty: ledgerTotals(pen),
      finalBal: last.bal, finalPen: last.pen,
      credit: main.credit, penCredit: pen.credit,
      lastDate: last.date, rowCount: rows.length, rows
    };
  }

  /** Vərəqənin sonundakı "Çap tarixinə faiz borcu" — vergi bölməsinə tətbiq olunur (uyğun gələrsə). */
  function applyPrintDateInterest(tax, summary, notes) {
    if (!tax) return;
    const printFaiz = summary['CAP TARIXINE FAIZ BORCU'];
    const total = summary['CEMI ODENMELI BORC'];
    if (printFaiz == null) return;
    const pf = cents(printFaiz);
    const principalSum = Object.values(tax.principal).reduce((a, b) => a + b, 0);
    if (total != null && Math.abs(cents(total) - (principalSum + pf)) > 1) {
      notes.push('Vərəqənin yekun cədvəlindəki "Cəmi ödənməli borc" vergi bölməsi ilə uyğun gəlmədi — faiz son sətirdəki kimi götürüldü.');
      return;
    }
    const cur = Object.values(tax.penalty).reduce((a, b) => a + b, 0);
    const diff = pf - cur;
    if (!diff) { tax.printAdjusted = 0; return; }
    if (diff > 0) {
      const w = Object.keys(tax.principal).length ? tax.principal : tax.penalty;
      const parts = splitByWeights(diff, w);
      if (!Object.keys(parts).length) parts['T:OTHER'] = diff;
      for (const k in parts) tax.penalty[k] = (tax.penalty[k] || 0) + parts[k];
    } else {
      const parts = splitByWeights(-diff, tax.penalty);
      for (const k in parts) tax.penalty[k] = Math.max(0, (tax.penalty[k] || 0) - parts[k]);
    }
    tax.printAdjusted = diff;
    tax.finalPenEffective = pf;
  }

  /** Əsas giriş nöqtəsi: axın → nəticə */
  function analyze(items) {
    const st = parseStatement(items);
    const res = { entity: st.entity, summary: st.summary, notes: st.warnings.slice(), sections: {}, cats: {} };
    for (const k of Object.keys(SECTIONS)) {
      if (st.sections[k]) res.sections[k] = allocateSection(st.sections[k]);
    }
    applyPrintDateInterest(res.sections.tax, st.summary, res.notes);
    for (const s of Object.values(res.sections)) {
      if (!s) continue;
      const keys = new Set([...Object.keys(s.principal), ...Object.keys(s.penalty)]);
      for (const k of keys) {
        const p = s.principal[k] || 0, q = s.penalty[k] || 0;
        if (!p && !q) continue;
        res.cats[k] = { key: k, section: s.key, label: (CATS[k] || { label: k }).label, principal: p, penalty: q, defaultTarget: (CATS[k] || {}).target || (s.key === 'tax' ? 'otherTax' : 'otherSocial') };
      }
    }
    // Yoxlama: hər bölmədə bölüşdürülən = vərəqədəki son qalıq
    for (const s of Object.values(res.sections)) {
      if (!s) continue;
      const p = Object.values(s.principal).reduce((a, b) => a + b, 0);
      const q = Object.values(s.penalty).reduce((a, b) => a + b, 0);
      const expP = Math.max(0, s.finalBal), expQ = Math.max(0, s.finalPenEffective != null ? s.finalPenEffective : s.finalPen);
      s.check = { principal: p, penalty: q, expectedPrincipal: expP, expectedPenalty: expQ, ok: p === expP && q === expQ };
    }
    // Dövr (çap tarixi)
    const pd = st.summary['CAP OLUNMA TARIXI'];
    res.printDate = pd && parseDate(pd) ? parseDate(pd) : null;
    return res;
  }

  /** Bölüşdürmə + istifadəçinin seçdiyi uyğunlaşdırma → formadakı sətirlər */
  function buildForm(result, mapping) {
    const rows = {};
    for (const r of ALL_ROWS) rows[r.key] = { key: r.key, principal: 0, penalty: 0, sources: [] };
    for (const c of Object.values(result.cats)) {
      const target = (mapping && mapping[c.key]) || c.defaultTarget;
      const row = rows[target] || rows[c.section === 'tax' ? 'otherTax' : 'otherSocial'];
      row.principal += c.principal; row.penalty += c.penalty; row.sources.push(c.key);
    }
    return rows;
  }

  const api = { TAX_ROWS, SOCIAL_ROWS, ALL_ROWS, CATS, SECTIONS, fold, cents, clean, parseDate, streamFromHtml, streamFromRows, parseStatement, analyze, buildForm, splitByWeights };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.SHEngine = api;
})(typeof window !== 'undefined' ? window : globalThis);
