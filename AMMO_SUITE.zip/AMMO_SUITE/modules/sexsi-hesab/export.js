/* AMMO — Şəxsi hesab → Borc: PDF (jsPDF) və Excel (.xlsx, JSZip) ixracı */
(function () {
  'use strict';
  const E = window.SHEngine;
  const NAVY = [15, 59, 117], GRID = [148, 163, 184];
  const fmt = (c) => { const v = (c || 0) / 100; const s = Math.abs(v).toFixed(2).split('.'); return (v < 0 ? '-' : '') + s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + '.' + s[1]; };

  function download(blob, name) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  // =====================================================================
  // PDF
  // =====================================================================
  async function pdf(m, filename) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4', compress: true });
    doc.addFileToVFS('LS-Regular.ttf', window.SH_FONTS.Regular); doc.addFont('LS-Regular.ttf', 'LS', 'normal');
    doc.addFileToVFS('LS-Bold.ttf', window.SH_FONTS.Bold); doc.addFont('LS-Bold.ttf', 'LS', 'bold');
    doc.setProperties({ title: 'Vergi və DSMF öhdəlikləri', subject: `${m.name} · ${m.voen}`, creator: 'AMMO SUITE' });

    const PW = 297, PH = 210, L = 12, R = PW - 12, W = R - L;
    const font = (style, size, color) => { doc.setFont('LS', style); doc.setFontSize(size); doc.setTextColor(...(color || [17, 17, 17])); };
    const fitText = (t, maxW) => { t = String(t ?? ''); if (doc.getTextWidth(t) <= maxW) return t; while (t.length > 1 && doc.getTextWidth(t + '…') > maxW) t = t.slice(0, -1); return t + '…'; };
    function cell(x, y, w, h, text, o = {}) {
      doc.setLineWidth(0.2); doc.setDrawColor(...(o.stroke || GRID));
      if (o.fill) { doc.setFillColor(...o.fill); doc.rect(x, y, w, h, 'FD'); } else doc.rect(x, y, w, h, 'S');
      if (text == null || text === '') return;
      font(o.bold ? 'bold' : 'normal', o.size || 8.6, o.color);
      const ty = y + h / 2 + (o.size || 8.6) * 0.353 / 2 - 0.35;
      if (o.align === 'right') doc.text(fitText(text, w - 3), x + w - 1.6, ty, { align: 'right' });
      else if (o.align === 'center') doc.text(fitText(text, w - 3), x + w / 2, ty, { align: 'center' });
      else doc.text(fitText(text, w - 3), x + 1.6, ty);
    }

    // --- Başlıq ---
    font('bold', 7.5, [100, 116, 139]);
    doc.text('Ə M Ə K   H A Q Q I   V Ə   H E S A B A T L A R', PW / 2, 14, { align: 'center' });
    font('bold', 17, NAVY);
    doc.text('VERGİ VƏ DSMF ÖHDƏLİKLƏRİ', PW / 2, 21.5, { align: 'center' });
    doc.setDrawColor(...NAVY); doc.setLineWidth(0.7); doc.line(L, 24.5, R, 24.5);

    // --- Meta ---
    let y = 27.5; const mh = 5.2;
    const mw = [W * 0.12, W * 0.38, W * 0.12, W * 0.38];
    const metaRow = (a, b, c, d) => {
      let x = L;
      [[a, true], [b, false], [c, true], [d, false]].forEach(([t, lab], i) => {
        cell(x, y, mw[i], mh, t, lab ? { fill: [231, 239, 249], color: NAVY, bold: true, size: 8.3 } : { fill: [247, 250, 253], size: 8.3 });
        x += mw[i];
      });
      y += mh;
    };
    metaRow('Vergi ödəyicisi:', m.name || '—', 'VÖEN:', m.voen || '—');
    metaRow('Dövr:', m.period || '—', 'Sənəd tarixi:', m.docDate || '—');
    y += 3;

    // --- Cədvəl ---
    const det = m.detailed;
    const cw = det ? [W * 0.58, W * 0.14, W * 0.14, W * 0.14] : [W * 0.78, W * 0.22];
    const nRows = 1 + m.taxRows.length + 1 + 1 + m.socialRows.length + 1 + 1;
    const available = PH - 10 - 34 - 13 - y; // imza + xəbərdarlıq üçün yer
    const rh = Math.max(3.9, Math.min(5.6, available / nRows));
    const fs = rh >= 5 ? 9 : 8.4;
    const line = (cells, o = {}) => {
      let x = L;
      cells.forEach((t, i) => { cell(x, y, cw[i], rh, t, { ...o, size: o.size || fs, align: i === 0 ? 'left' : 'right' }); x += cw[i]; });
      y += rh;
    };
    // başlıq
    {
      const heads = det ? ['VERGİ ÖHDƏLİYİ', 'ƏSAS BORC', 'FAİZ / PENYA', 'CƏMİ (AZN)'] : ['VERGİ ÖHDƏLİYİ', 'BORC (AZN)'];
      let x = L;
      heads.forEach((t, i) => { cell(x, y, cw[i], rh, t, { fill: NAVY, stroke: [14, 56, 111], color: [255, 255, 255], bold: true, size: fs - 0.4, align: i === 0 ? 'left' : 'center' }); x += cw[i]; });
      y += rh;
    }
    const rowCells = (r) => det ? [r.label, fmt(r.principal), fmt(r.penalty), fmt(r.total)] : [r.label, fmt(r.total)];
    const totCells = (label, t) => det ? [label, fmt(t.principal), fmt(t.penalty), fmt(t.total)] : [label, fmt(t.total)];
    m.taxRows.forEach((r) => line(rowCells(r)));
    line(totCells('CƏMİ VERGİ BORCU', m.taxTotal), { fill: [239, 244, 251], bold: true });
    cell(L, y, W, rh, 'DSMF ÖHDƏLİKLƏRİ', { fill: [231, 239, 249], color: NAVY, bold: true, size: fs }); y += rh;
    m.socialRows.forEach((r) => line(rowCells(r)));
    line(totCells('CƏMİ DSMF ÖHDƏLİKLƏRİ', m.socialTotal), { fill: [239, 244, 251], bold: true });
    line(totCells('CƏMİ VERGİ VƏ CƏMİ DSMF BORCU', m.grand), { fill: NAVY, stroke: [14, 56, 111], color: [255, 255, 255], bold: true });

    // --- Xəbərdarlıq ---
    y += 3;
    font('bold', 8.6, [192, 0, 0]);
    const nLines = doc.splitTextToSize(m.notice || '', W - 6);
    const nh = Math.max(8, nLines.length * 3.8 + 4);
    doc.setFillColor(255, 247, 204); doc.setDrawColor(234, 179, 8); doc.setLineWidth(0.3); doc.rect(L, y, W, nh, 'FD');
    doc.text(nLines, L + 3, y + 5.1);
    y += nh;

    // --- İmzalar və möhür ---
    const sealD = 26;
    const sy = Math.min(PH - 10 - sealD - 6, Math.max(y + 8, PH - 10 - sealD - 6 - 12));
    const cx = PW / 2, cy = sy + sealD / 2;
    if (m.seal) { try { doc.addImage(m.seal, 'PNG', cx - sealD / 2, sy, sealD, sealD); } catch (e) { /* şəkil xətası — yer tutucu */ } }
    else {
      doc.setDrawColor(100, 116, 139); doc.setLineWidth(0.25);
      if (doc.setLineDashPattern) doc.setLineDashPattern([1.2, 1], 0);
      doc.circle(cx, cy, sealD / 2, 'S');
      if (doc.setLineDashPattern) doc.setLineDashPattern([], 0);
      font('bold', 8, [100, 116, 139]); doc.text('M.Y.', cx, cy + 1, { align: 'center' });
    }
    font('normal', 7.5, [100, 116, 139]); doc.text(m.seal ? 'Möhür' : 'Möhür yeri', cx, sy + sealD + 3.5, { align: 'center' });
    const lineY = cy + 6, colW = W * 0.4;
    const sig = (x, label, name) => {
      font('bold', 8.6); doc.text(label, x + 1, lineY - 7);
      if (name) { font('normal', 9); doc.text(name, x + 1, lineY - 1); }
      doc.setDrawColor(17, 17, 17); doc.setLineWidth(0.25); doc.line(x, lineY, x + colW - 4, lineY);
      font('normal', 7.5, [100, 116, 139]); doc.text('Ad, soyad / imza', x + 1, lineY + 3.5);
    };
    sig(L, 'Rəhbər:', m.manager);
    sig(R - colW + 4, 'Hazırladı:', m.prepared);

    const blob = doc.output('blob');
    download(blob, filename);
    return blob;
  }

  // =====================================================================
  // XLSX (stilizə olunmuş, JSZip ilə)
  // =====================================================================
  const xesc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');
  const colName = (i) => { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };

  // Stil indeksləri (styles.xml cellXfs sırası ilə)
  const S = { def: 0, brand: 1, title: 2, meta: 3, th: 4, thL: 5, td: 6, num: 7, subL: 8, subN: 9, sec: 10, grandL: 11, grandN: 12, notice: 13, bold: 14, small: 15, sigLine: 16, hdr: 17, txt: 18, center: 19, ok: 20, warn: 21, numPlain: 22 };
  const STYLES_XML = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>
<fonts count="10">
<font><sz val="10"/><name val="Arial"/></font>
<font><b/><sz val="10"/><name val="Arial"/></font>
<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
<font><b/><sz val="16"/><color rgb="FF0F3B75"/><name val="Arial"/></font>
<font><b/><sz val="10"/><color rgb="FF0F3B75"/><name val="Arial"/></font>
<font><b/><sz val="8"/><color rgb="FF64748B"/><name val="Arial"/></font>
<font><b/><sz val="10"/><color rgb="FFC00000"/><name val="Arial"/></font>
<font><sz val="8"/><color rgb="FF64748B"/><name val="Arial"/></font>
<font><b/><sz val="10"/><color rgb="FF067647"/><name val="Arial"/></font>
<font><b/><sz val="10"/><color rgb="FFB54708"/><name val="Arial"/></font>
</fonts>
<fills count="8">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF0F3B75"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE7EFF9"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF7FAFD"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFEFF4FB"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFF7CC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF6F8FC"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="5">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FF94A3B8"/></left><right style="thin"><color rgb="FF94A3B8"/></right><top style="thin"><color rgb="FF94A3B8"/></top><bottom style="thin"><color rgb="FF94A3B8"/></bottom><diagonal/></border>
<border><left/><right/><top/><bottom style="thin"><color rgb="FF111111"/></bottom><diagonal/></border>
<border><left style="thin"><color rgb="FFEAB308"/></left><right style="thin"><color rgb="FFEAB308"/></right><top style="thin"><color rgb="FFEAB308"/></top><bottom style="thin"><color rgb="FFEAB308"/></bottom><diagonal/></border>
<border><left/><right/><top/><bottom style="medium"><color rgb="FF0F3B75"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="23">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center"/></xf>
<xf numFmtId="0" fontId="3" fillId="0" borderId="4" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
<xf numFmtId="164" fontId="1" fillId="5" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="4" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
<xf numFmtId="164" fontId="2" fillId="2" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="6" fillId="6" borderId="3" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="7" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="2" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="bottom"/></xf>
<xf numFmtId="0" fontId="1" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center"/></xf>
<xf numFmtId="0" fontId="8" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"/>
<xf numFmtId="0" fontId="9" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

  /** Sadə vərəq qurucusu */
  function Sheet(name) {
    this.name = name; this.rows = {}; this.merges = []; this.cols = []; this.heights = {}; this.landscape = false; this.fit = false; this.freeze = null;
  }
  Sheet.prototype.set = function (r, c, v, s, opt = {}) { (this.rows[r] = this.rows[r] || {})[c] = { v, s, f: opt.f, rich: opt.rich }; };
  Sheet.prototype.merge = function (r1, c1, r2, c2) { this.merges.push(`${colName(c1)}${r1}:${colName(c2)}${r2}`); };
  Sheet.prototype.xml = function () {
    const rowsXml = Object.keys(this.rows).map(Number).sort((a, b) => a - b).map((r) => {
      const cells = this.rows[r];
      const cx = Object.keys(cells).map(Number).sort((a, b) => a - b).map((c) => {
        const { v, s, f, rich } = cells[c]; const ref = colName(c) + r; const st = s ? ` s="${s}"` : '';
        if (rich) return `<c r="${ref}"${st} t="inlineStr"><is>${rich.map(([t, b]) => `<r><rPr>${b ? '<b/>' : ''}<sz val="10"/>${b ? '<color rgb="FF0F3B75"/>' : ''}<rFont val="Arial"/></rPr><t xml:space="preserve">${xesc(t)}</t></r>`).join('')}</is></c>`;
        if (f) return `<c r="${ref}"${st}><f>${xesc(f)}</f>${v != null ? `<v>${v}</v>` : ''}</c>`;
        if (v == null || v === '') return `<c r="${ref}"${st}/>`;
        if (typeof v === 'number') return `<c r="${ref}"${st}><v>${v}</v></c>`;
        return `<c r="${ref}"${st} t="inlineStr"><is><t xml:space="preserve">${xesc(v)}</t></is></c>`;
      }).join('');
      const h = this.heights[r] ? ` ht="${this.heights[r]}" customHeight="1"` : '';
      return `<row r="${r}"${h}>${cx}</row>`;
    }).join('');
    const cols = this.cols.length ? `<cols>${this.cols.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols>` : '';
    const merges = this.merges.length ? `<mergeCells count="${this.merges.length}">${this.merges.map((m) => `<mergeCell ref="${m}"/>`).join('')}</mergeCells>` : '';
    const pane = this.freeze ? `<pane ySplit="${this.freeze - 1}" topLeftCell="A${this.freeze}" activePane="bottomLeft" state="frozen"/>` : '';
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetPr>${this.fit ? '<pageSetUpPr fitToPage="1"/>' : ''}</sheetPr>
<sheetViews><sheetView workbookViewId="0" showGridLines="${this.fit ? 0 : 1}">${pane}</sheetView></sheetViews>
<sheetFormatPr defaultRowHeight="15"/>${cols}<sheetData>${rowsXml}</sheetData>${merges}
<pageMargins left="0.4" right="0.4" top="0.4" bottom="0.4" header="0.2" footer="0.2"/>
<pageSetup paperSize="9" orientation="${this.landscape ? 'landscape' : 'portrait'}"${this.fit ? ' fitToWidth="1" fitToHeight="1"' : ''}/>
</worksheet>`;
  };

  function buildFormSheet(m) {
    const sh = new Sheet('Öhdəliklər'); sh.landscape = true; sh.fit = true;
    const det = m.detailed, last = det ? 3 : 1;
    sh.cols = det ? [66, 18, 18, 20] : [86, 24];
    let r = 1;
    sh.set(r, 0, 'ƏMƏK HAQQI VƏ HESABATLAR', S.brand); sh.merge(r, 0, r, last); r++;
    sh.set(r, 0, 'VERGİ VƏ DSMF ÖHDƏLİKLƏRİ', S.title); for (let c = 1; c <= last; c++) sh.set(r, c, '', S.title); sh.merge(r, 0, r, last); sh.heights[r] = 26; r++;
    r++;
    const meta = (a, av, b, bv) => {
      sh.set(r, 0, null, S.meta, { rich: [[a + ' ', true], [av || '—', false]] });
      sh.set(r, 1, null, S.meta, { rich: [[b + ' ', true], [bv || '—', false]] });
      for (let c = 2; c <= last; c++) sh.set(r, c, '', S.meta);
      if (last > 1) sh.merge(r, 1, r, last);
      sh.heights[r] = 17; r++;
    };
    meta('Vergi ödəyicisi:', m.name, 'VÖEN:', m.voen);
    meta('Dövr:', m.period, 'Sənəd tarixi:', m.docDate);
    r++;
    const heads = det ? ['VERGİ ÖHDƏLİYİ', 'ƏSAS BORC', 'FAİZ / PENYA', 'CƏMİ (AZN)'] : ['VERGİ ÖHDƏLİYİ', 'BORC (AZN)'];
    heads.forEach((h, i) => sh.set(r, i, h, i ? S.th : S.thL)); sh.heights[r] = 18; r++;
    const amtCols = det ? [1, 2, 3] : [1];
    const writeRows = (rows) => {
      const start = r;
      rows.forEach((x) => {
        sh.set(r, 0, x.label, S.td);
        if (det) { sh.set(r, 1, x.principal / 100, S.num); sh.set(r, 2, x.penalty / 100, S.num); sh.set(r, 3, null, S.num, { f: `B${r}+C${r}` }); sh.rows[r][3].v = x.total / 100; }
        else sh.set(r, 1, x.total / 100, S.num);
        sh.heights[r] = 16; r++;
      });
      return [start, r - 1];
    };
    const subtotal = (label, range, t, sl, sn) => {
      sh.set(r, 0, label, sl);
      const vals = det ? [t.principal, t.penalty, t.total] : [t.total];
      amtCols.forEach((c, i) => sh.set(r, c, vals[i] / 100, sn, { f: range[1] >= range[0] ? `SUM(${colName(c)}${range[0]}:${colName(c)}${range[1]})` : '0' }));
      sh.heights[r] = 17; return r++;
    };
    const tr = writeRows(m.taxRows);
    const taxSub = subtotal('CƏMİ VERGİ BORCU', tr, m.taxTotal, S.subL, S.subN);
    sh.set(r, 0, 'DSMF ÖHDƏLİKLƏRİ', S.sec); for (let c = 1; c <= last; c++) sh.set(r, c, '', S.sec); sh.merge(r, 0, r, last); sh.heights[r] = 17; r++;
    const sr = writeRows(m.socialRows);
    const socSub = subtotal('CƏMİ DSMF ÖHDƏLİKLƏRİ', sr, m.socialTotal, S.subL, S.subN);
    sh.set(r, 0, 'CƏMİ VERGİ VƏ CƏMİ DSMF BORCU', S.grandL);
    const gv = det ? [m.grand.principal, m.grand.penalty, m.grand.total] : [m.grand.total];
    amtCols.forEach((c, i) => sh.set(r, c, gv[i] / 100, S.grandN, { f: `${colName(c)}${taxSub}+${colName(c)}${socSub}` }));
    sh.heights[r] = 18; r += 2;
    sh.set(r, 0, m.notice || '', S.notice); for (let c = 1; c <= last; c++) sh.set(r, c, '', S.notice); sh.merge(r, 0, r, last); sh.heights[r] = 32; r += 3;
    sh.set(r, 0, 'Rəhbər:', S.bold); sh.set(r, last, 'Hazırladı:', S.bold); r++;
    sh.set(r, 0, m.manager || '', S.sigLine); sh.set(r, last, m.prepared || '', S.sigLine); sh.heights[r] = 22;
    if (det) { sh.set(r, 1, 'M.Y.', S.center); sh.merge(r, 1, r, 2); }
    r++;
    sh.set(r, 0, 'Ad, soyad / imza', S.small); sh.set(r, last, 'Ad, soyad / imza', S.small);
    if (!det) { r += 2; sh.set(r, 0, 'M.Y.', S.center); sh.merge(r, 0, r, last); }
    return sh;
  }

  function buildDetailSheet(m) {
    const sh = new Sheet('Ətraflı'); sh.cols = [24, 50, 46, 16, 16, 16]; sh.landscape = true;
    const res = m.result; let r = 1;
    sh.set(r, 0, 'Hesablamanın açılışı — şəxsi hesab vərəqəsi üzrə', S.bold); r++;
    sh.set(r, 0, `${m.name || ''} · VÖEN ${m.voen || ''} · ${m.period || ''}`, S.small); r += 2;
    ['Bölmə', 'Vərəqədəki öhdəlik', 'Formada sətir', 'Əsas borc', 'Faiz / penya', 'Cəmi'].forEach((h, i) => sh.set(r, i, h, S.hdr)); sh.freeze = r + 1; r++;
    const first = r;
    for (const sk of Object.keys(E.SECTIONS)) {
      const s = res && res.sections[sk]; if (!s) continue;
      for (const c of Object.values(res.cats).filter((x) => x.section === sk)) {
        const target = (m.mapping && m.mapping[c.key]) || c.defaultTarget;
        const row = E.ALL_ROWS.find((x) => x.key === target);
        sh.set(r, 0, s.title, S.td); sh.set(r, 1, c.label, S.td); sh.set(r, 2, row ? row.label : target, S.td);
        sh.set(r, 3, c.principal / 100, S.num); sh.set(r, 4, c.penalty / 100, S.num); sh.set(r, 5, (c.principal + c.penalty) / 100, S.num, { f: `D${r}+E${r}` });
        r++;
      }
    }
    sh.set(r, 0, 'Cəmi', S.subL); sh.set(r, 1, '', S.subL); sh.set(r, 2, '', S.subL);
    [3, 4, 5].forEach((c) => sh.set(r, c, 0, S.subN, { f: `SUM(${colName(c)}${first}:${colName(c)}${r - 1})` }));
    const sumCats = res ? Object.values(res.cats).reduce((a, x) => [a[0] + x.principal, a[1] + x.penalty], [0, 0]) : [0, 0];
    sh.rows[r][3].v = sumCats[0] / 100; sh.rows[r][4].v = sumCats[1] / 100; sh.rows[r][5].v = (sumCats[0] + sumCats[1]) / 100;
    r += 2;

    sh.set(r, 0, 'DSMF — tərəflər üzrə', S.bold); r++;
    [['İşçidən tutulanlar (pensiya, işsizlik, İTS)', m.empTotal], ['İşəgötürən hesabına (pensiya, işsizlik, İTS)', m.erTotal], ['Fərdi sahibkar və digər', m.otherSocialTotal], ['Cəmi DSMF', m.socialTotal.total]].forEach(([l, v], i) => {
      sh.set(r, 0, l, i === 3 ? S.subL : S.td); sh.set(r, 1, '', i === 3 ? S.subL : S.td); sh.merge(r, 0, r, 1); sh.set(r, 2, v / 100, i === 3 ? S.subN : S.num); r++;
    });
    r++;
    sh.set(r, 0, 'Vərəqə ilə tutuşdurma', S.bold); r++;
    ['Bölmə', 'Vərəqədə son qalıq', 'Vərəqədə faiz / penya', 'Bölüşdürülən borc', 'Bölüşdürülən faiz', 'Nəticə'].forEach((h, i) => sh.set(r, i, h, S.hdr)); r++;
    for (const s of Object.values((res && res.sections) || {})) {
      if (!s) continue;
      sh.set(r, 0, s.title, S.td); sh.set(r, 1, s.check.expectedPrincipal / 100, S.num); sh.set(r, 2, s.check.expectedPenalty / 100, S.num);
      sh.set(r, 3, s.check.principal / 100, S.num); sh.set(r, 4, s.check.penalty / 100, S.num);
      sh.set(r, 5, s.check.ok ? '✓ uyğundur' : '⚠ fərq var', s.check.ok ? S.ok : S.warn); r++;
    }
    const manual = [...m.taxRows, ...m.socialRows].filter((x) => x.manual);
    if (manual.length) { r++; sh.set(r, 0, `Əl ilə düzəliş edilmiş xanalar: ${manual.map((x) => x.label).join(', ')}`, S.small); r++; }
    if (res && res.notes.length) { r++; res.notes.forEach((n) => { sh.set(r, 0, n, S.small); r++; }); }
    r++;
    sh.set(r, 0, 'Qayda: işlək qalığın hər dəyişməsi həmin sətrin öhdəlik növünə yazılır; ödəniş/azalma əvvəlcə adı çəkilən növü, sonra ən köhnə borcu bağlayır. Faiz/penya eyni qayda ilə bölünür.', S.small);
    return sh;
  }

  function buildRowsSheet(m) {
    const sh = new Sheet('Vərəqə sətirləri'); sh.cols = [16, 12, 58, 12, 12, 13, 13, 13, 13, 13, 40];
    let r = 1;
    ['Bölmə', 'Yazılış', 'Əməliyyat adı', 'Növ', 'Ödəmə tarixi', 'Miqdar', 'Saldo (borc +)', 'Faiz/penya saldo', 'Borc dəyişməsi', 'Faiz dəyişməsi', 'Aid edilən öhdəlik'].forEach((h, i) => sh.set(r, i, h, S.hdr));
    sh.freeze = 2; r++;
    for (const s of Object.values((m.result && m.result.sections) || {})) {
      if (!s) continue;
      for (const x of s.rows) {
        sh.set(r, 0, s.title, S.txt); sh.set(r, 1, x.date, S.txt); sh.set(r, 2, x.name, S.txt); sh.set(r, 3, x.kind, S.txt); sh.set(r, 4, x.payDate, S.txt);
        sh.set(r, 5, x.amount / 100, S.numPlain); sh.set(r, 6, x.bal / 100, S.numPlain); sh.set(r, 7, x.pen / 100, S.numPlain);
        sh.set(r, 8, x.dBal ? x.dBal / 100 : null, S.numPlain); sh.set(r, 9, x.dPen ? x.dPen / 100 : null, S.numPlain);
        sh.set(r, 10, x.cat ? (E.CATS[x.cat] || { label: x.cat }).label : (x.dBal || x.dPen ? 'ödəniş — ən köhnə borca' : ''), S.txt);
        r++;
      }
    }
    return sh;
  }

  async function xlsx(m, filename) {
    const sheets = [buildFormSheet(m), buildDetailSheet(m), buildRowsSheet(m)];
    const zip = new JSZip();
    zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>`);
    zip.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`);
    zip.file('docProps/core.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Vergi və DSMF öhdəlikləri</dc:title><dc:creator>AMMO SUITE</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString().slice(0, 19)}Z</dcterms:created></cp:coreProperties>`);
    zip.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>${sheets.map((s, i) => `<sheet name="${xesc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
    zip.file('xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
    zip.file('xl/styles.xml', STYLES_XML);
    sheets.forEach((s, i) => zip.file(`xl/worksheets/sheet${i + 1}.xml`, s.xml()));
    const blob = await zip.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', compression: 'DEFLATE' });
    download(blob, filename);
    return blob;
  }

  window.SHExport = { pdf, xlsx };
})();
