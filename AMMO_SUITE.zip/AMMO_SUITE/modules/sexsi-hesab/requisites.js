/* AMMO — Şəxsi hesab → Borc: ödəniş rekvizitləri (V30.2)
   Formadakı sətrin adına (SV, ÖMV, Pensiya Fondu ...) klikləyəndə həmin öhdəliyin rekvizitləri açılır.
   "Redaktə et" ilə dəyişmək olar. Dəyişikliklər localStorage → cloud-sync ilə Firebase-ə yazılır
   və bütün kompüterlərdə eyni görünür. */
(function () {
  'use strict';
  const LS = 'ammo_sexsi_requisites_v1';
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));

  // Alan bankı — Dövlət Xəzinədarlıq Agentliyi (bütün sətirlər üçün eyni)
  const BANK = { bank: 'Dövlət Xəzinədarlıq Agentliyi', bankCode: '210005', bankVoen: '1401555071', corrAccount: 'AZ41NABZ01360100000000003944', swift: 'CTREAZ22' };
  const VN = { receiverVoen: '1602473621', account: 'AZ17CTRE00000000000002117131', levelCode: '1', receiver: 'Vergilər Nazirliyinin Milli Gəlirlər Baş İdarəsi' };
  const DSMF = { receiverVoen: '1300115511', account: 'AZ36CTRE00000000000007017617', levelCode: '4', receiver: 'DSMF-nin Sosial Sığorta və Fərdi Uçot üzrə Mərkəzi Filialı' };
  const ITS = { receiverVoen: '1009670801', account: 'AZ57CTRE00000000000008197632', levelCode: '7', receiver: 'Dövlət Tibbi Sığorta və Ekspertiza Agentliyi' };

  // VERGİ.xlsx əsasında başlanğıc dəyərlər
  const DEFAULTS = {
    sv:          { name: 'S/V', ...VN, classCode: '114300' },
    edv:         { name: 'ƏDV', ...VN, classCode: '' },
    omv:         { name: 'ÖMV', ...VN, classCode: '1112540' },
    muzdlu:      { name: 'Muzdlu işdən gəlir vergisi', ...VN, classCode: '111110' },
    mv:          { name: 'M/V Gəlir-Mənfəət vergisi', ...VN, classCode: '111000' },
    property:    { name: 'Əmlak vergisi', ...VN, classCode: '113200' },
    land:        { name: 'Torpaq vergisi', ...VN, classCode: '113100' },
    road:        { name: 'Yol vergisi', ...VN, classCode: '114700' },
    otherTax:    { name: 'Digər vergi borcları', ...VN, classCode: '' },
    fsIncome:    { name: 'Fərdi sahibkar gəlir vergisi', ...VN, classCode: '' },
    fsMedical:   { name: 'F/Ş tərəfindən ödənilən İcbari Tibbi Sığorta', ...ITS, classCode: '' },
    fsSocial:    { name: 'Fərdi sahibkarın öz DSMF haqqı', ...DSMF, classCode: '' },
    empP:        { name: 'Pensiya Fondu (işçidən tutulan)', ...DSMF, classCode: '' },
    erP:         { name: 'Pensiya Fondu (işəgötürəndən tutulan)', ...DSMF, classCode: '' },
    empUn:       { name: 'İşsizlikdən sığorta haqqı (sığortaolunan tərəfdən)', ...DSMF, classCode: '12320001' },
    erUn:        { name: 'İşsizlikdən sığorta haqqı (sığortaedən tərəfdən)', ...DSMF, classCode: '12310001' },
    empMed:      { name: 'İcbari sığorta (işçidən tutulan)', ...ITS, classCode: '124210' },
    erMed:       { name: 'İcbari sığorta (işəgötürən tərəfindən)', ...ITS, classCode: '124110' },
    otherSocial: { name: 'Digər DSMF borcları', ...DSMF, classCode: '' }
  };
  Object.values(DEFAULTS).forEach((d) => Object.assign(d, BANK, { note: '' }));

  const FIELDS = [
    ['name', 'Ödənişin adı'],
    ['receiver', 'Alan təşkilat (struktur bölmə)'],
    ['receiverVoen', 'Alanın VÖEN-i'],
    ['account', 'Yığım hesabı (IBAN)'],
    ['levelCode', 'Büdcə səviyyəsinin kodu'],
    ['classCode', 'Büdcə təsnifatı kodu'],
    ['bank', 'Bank'],
    ['bankCode', 'Bankın kodu'],
    ['bankVoen', 'Bankın VÖEN-i'],
    ['corrAccount', 'Müxbir hesab'],
    ['swift', 'SWIFT'],
    ['note', 'Qeyd']
  ];

  let custom = {};
  function load() { try { custom = JSON.parse(localStorage.getItem(LS) || '{}') || {}; } catch (e) { custom = {}; } }
  function persist() { localStorage.setItem(LS, JSON.stringify(custom)); }
  function get(key) { return { ...(DEFAULTS[key] || { name: key, ...VN, ...BANK, classCode: '', note: '' }), ...(custom[key] || {}) }; }
  load();
  window.addEventListener('ammo-cloud-updated', () => { load(); if (current && !editing) draw(); });

  // ---------- Modal ----------
  const box = document.createElement('div');
  box.id = 'reqModal'; box.className = 'req-overlay hidden';
  box.innerHTML = '<div class="req-card" role="dialog" aria-modal="true"><div class="req-head"><div><small>ÖDƏNİŞ REKVİZİTLƏRİ</small><h3 id="reqTitle"></h3></div><button class="req-x" id="reqClose" title="Bağla">✕</button></div><div id="reqBody"></div><div class="req-foot" id="reqFoot"></div></div>';
  document.body.appendChild(box);
  let current = null, editing = false;

  function toast(t) { const x = $('#toast'); if (!x) return; x.textContent = t; x.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => x.classList.remove('show'), 2400); }
  function copy(text) { navigator.clipboard.writeText(text).then(() => toast('Kopyalandı: ' + text), () => toast('Kopyalanmadı')); }

  function draw() {
    const r = get(current), changed = !!custom[current];
    $('#reqTitle').textContent = r.name || current;
    if (!editing) {
      $('#reqBody').innerHTML = '<table class="req-table">' + FIELDS.filter(([k]) => k !== 'name').map(([k, l]) =>
        `<tr><th>${esc(l)}</th><td>${r[k] ? esc(r[k]) : '<span class="req-empty">— yazılmayıb</span>'}</td><td>${r[k] ? `<button class="req-copy" data-copy="${esc(r[k])}" title="Kopyala">⧉</button>` : ''}</td></tr>`).join('') + '</table>' +
        (changed ? '<p class="req-mark">✎ Bu rekvizitlər əl ilə düzəldilib (bütün kompüterlərdə eyni görünür).</p>' : '');
      $('#reqFoot').innerHTML = `<button class="ghost" id="reqCopyAll">⧉ Hamısını kopyala</button><span></span><button class="primary" id="reqEdit">✎ Redaktə et</button>`;
      $('#reqEdit').onclick = () => { editing = true; draw(); };
      $('#reqCopyAll').onclick = () => copy(FIELDS.filter(([k]) => r[k]).map(([k, l]) => `${l}: ${r[k]}`).join('\n'));
      $('#reqBody').querySelectorAll('[data-copy]').forEach((b) => b.onclick = () => copy(b.dataset.copy));
    } else {
      $('#reqBody').innerHTML = '<div class="req-form">' + FIELDS.map(([k, l]) =>
        `<label>${esc(l)}${k === 'note' ? `<textarea data-f="${k}" rows="2">${esc(r[k])}</textarea>` : `<input data-f="${k}" value="${esc(r[k])}">`}</label>`).join('') + '</div>';
      $('#reqFoot').innerHTML = `<button class="ghost" id="reqReset" ${changed ? '' : 'disabled'}>↺ Standarta qaytar</button><button class="ghost" id="reqCancel">Ləğv et</button><button class="primary" id="reqSave">✓ Yadda saxla</button>`;
      $('#reqCancel').onclick = () => { editing = false; draw(); };
      $('#reqReset').onclick = () => { if (!confirm('Bu sətrin rekvizitləri standart (VERGİ.xlsx) dəyərlərə qaytarılsın?')) return; delete custom[current]; persist(); editing = false; draw(); toast('Standart rekvizitlər bərpa olundu.'); };
      $('#reqSave').onclick = () => {
        const base = DEFAULTS[current] || {}, out = {};
        $('#reqBody').querySelectorAll('[data-f]').forEach((i) => { const v = i.value.trim(); if (v !== String(base[i.dataset.f] ?? '')) out[i.dataset.f] = v; });
        if (Object.keys(out).length) custom[current] = out; else delete custom[current];
        persist(); editing = false; draw(); toast('Rekvizitlər yadda saxlanıldı və buluda yazıldı.');
      };
      const first = $('#reqBody').querySelector('input'); if (first) first.focus();
    }
  }
  function open(key) { current = key; editing = false; draw(); box.classList.remove('hidden'); }
  function close() { box.classList.add('hidden'); current = null; editing = false; }
  $('#reqClose').onclick = close;
  box.addEventListener('click', (e) => { if (e.target === box) close(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !box.classList.contains('hidden')) close(); });

  // Formadakı sətir adlarına klik
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-req]'); if (!el) return;
    e.preventDefault(); open(el.dataset.req);
  });

  // ---------- Bütün rekvizitlər siyahısı ----------
  function openList() {
    current = null;
    $('#reqTitle').textContent = 'Bütün öhdəliklər';
    const rows = Object.keys(DEFAULTS).map((k) => { const r = get(k); return `<tr class="req-row" data-open="${k}"><td><b>${esc(r.name)}</b>${custom[k] ? ' <span class="req-tag">düzəldilib</span>' : ''}<small>${esc(r.receiver)}</small></td><td class="mono">${esc(r.account)}</td><td class="mono">${esc(r.classCode || '—')}</td></tr>`; }).join('');
    $('#reqBody').innerHTML = `<table class="req-table list"><thead><tr><th>Öhdəlik</th><th>Yığım hesabı</th><th>Təsnifat kodu</th></tr></thead><tbody>${rows}</tbody></table>`;
    $('#reqFoot').innerHTML = '<span class="req-hint">Sətrə klikləyin — açılan pəncərədə “Redaktə et”.</span>';
    $('#reqBody').querySelectorAll('[data-open]').forEach((tr) => tr.onclick = () => open(tr.dataset.open));
    box.classList.remove('hidden');
  }
  const btn = $('#reqListBtn'); if (btn) btn.onclick = openList;

  window.SHRequisites = { get, open, openList, DEFAULTS };
})();
