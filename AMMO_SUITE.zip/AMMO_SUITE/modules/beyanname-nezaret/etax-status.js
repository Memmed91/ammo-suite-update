/* Bəyannamə nəzarət — V30.2: açıq e-taxes kabinetindən status yenilənməsi.
   "↻ Yenilə" → hansı şirkətin kabineti açıqdırsa onun bəyannamələri oxunur (cari və keçən il),
   buradakı statuslarla müqayisə olunur → fərq varsa yuxarıda "🔔 Yenilənmə" çıxır →
   üzərinə basanda həmin şirkətin statusları dəyişir və Firebase-ə yazılır.
   app.js-dən sonra yüklənir (data, apiFetch, BASE, toFsFields, saveLocal, renderAll, fetchFirebaseRecords, statuses qlobaldır). */
(() => {
  'use strict';
  const E = window.AmmoEtax; if (!E) return;
  const MAP_KEY = 'ammo_bn_etax_map_v1';   // {status:{RAW:'TƏSDİQLƏNDİ'}, code:{_0300:'edv'}} — cloud-sync ilə Firebase-ə gedir
  const SEEN_KEY = 'ammo_bn_etax_seen_v1'; // görülmüş xam status və vergi kodları
  const TYPES = { edv: 'ƏDV', omv: 'ÖMV', vvb: 'VVB', sv: 'SV', emlak: 'Əmlak', menfeet: 'Mənfəət', torpaq: 'Torpaq' };
  const PERIOD = { edv: 'month', omv: 'rub', vvb: 'rub', sv: 'rub', emlak: 'year', menfeet: 'year', torpaq: 'year' };
  // TaxPro ilə eyni vergi kodları; Əmlak/Torpaq kodları adla tanınır və ya ⚙-dən təyin olunur
  const CODE_DEFAULT = { _0300: 'edv', _1600: 'omv', _0901: 'vvb', _0800: 'sv', _0200: 'menfeet', _1200: 'menfeet' };
  const MONTHS = ['YANVAR', 'FEVRAL', 'MART', 'APREL', 'MAY', 'İYUN', 'İYUL', 'AVQUST', 'SENTYABR', 'OKTYABR', 'NOYABR', 'DEKABR'];

  const readJson = (k, d) => { try { return JSON.parse(localStorage.getItem(k) || 'null') || d; } catch (e) { return d; } };
  const userMap = () => { const m = readJson(MAP_KEY, {}); return { status: m.status || {}, code: m.code || {} }; };

  function typeOf(d) {
    const um = userMap().code;
    if (um[d.taxCode]) return um[d.taxCode] === 'skip' ? null : um[d.taxCode];
    if (CODE_DEFAULT[d.taxCode]) return CODE_DEFAULT[d.taxCode];
    const txt = Object.values(d.strings || {}).join(' ');
    if (/əmlak|emlak|property/i.test(txt)) return 'emlak';
    if (/torpaq|land/i.test(txt)) return 'torpaq';
    if (/mənfəət|menfeet|profit/i.test(txt)) return 'menfeet';
    return null;
  }
  function mapStatus(raw, kind) {
    const um = userMap().status;
    let s = um[raw] || '', known = !!s;
    if (!s) {
      if (/DRAFT/i.test(raw)) return { status: '', known: true, draft: true };
      if (/MISMATCH|INCONSIST|DISCREP|NONCOMPL|UYGUNSUZ|UYĞUNSUZ/i.test(raw)) { s = 'UYĞUNSUZLUQ YOXLAMASINDA'; known = true; }
      else if (/ACCEPT|APPROV|CONFIRM|SUCCESS|COMPLET|REGISTER|VERIFIED|TESDIQ|TƏSDİQ/i.test(raw)) { s = 'TƏSDİQLƏNDİ'; known = true; }
      else if (/SENT|SUBMIT|SIGN|PENDING|PROCESS|NEW|WAIT|REVIEW/i.test(raw)) { s = 'TƏQDİM OLUNAN'; known = true; }
      else s = 'TƏQDİM OLUNAN';
    }
    if (kind === 'CAMERAL' && !um[raw]) s = s === 'TƏSDİQLƏNDİ' ? 'KAMERAL TƏSDİQLƏNDİ' : (s === 'TƏQDİM OLUNAN' ? 'KAMERAL' : s);
    return { status: s, known };
  }
  function periodOf(type, d) {
    const p = PERIOD[type], year = String(d.year || '');
    if (p === 'month') return d.month ? { year, month: String(d.month).padStart(2, '0'), label: `${MONTHS[d.month - 1] || d.month} ${year}` } : null;
    if (p === 'rub') { const q = d.quarter || (d.month ? Math.ceil(d.month / 3) : 0); return q ? { year, rub: `${q} RÜB`, label: `${q} RÜB ${year}` } : null; }
    return { year, label: year };
  }
  const isoDay = (v) => E.isoDate(v) || '';

  function remember(decls) {
    const seen = readJson(SEEN_KEY, { status: {}, code: {} });
    let changed = false;
    decls.forEach((d) => {
      if (d.status && !seen.status[d.status]) { seen.status[d.status] = 1; changed = true; }
      if (d.taxCode && !seen.code[d.taxCode]) { seen.code[d.taxCode] = Object.values(d.strings || {}).find((x) => /vergi|bəyannamə|tax|declar/i.test(x)) || 1; changed = true; }
    });
    if (changed) localStorage.setItem(SEEN_KEY, JSON.stringify(seen));
  }

  // ---------- UI ----------
  const main = document.querySelector('main.main');
  const header = main.querySelector('header.top');
  const bar = E.bar(main, header.nextElementSibling);
  const actions = header.querySelector('.topActions');
  const chip = E.topChip(actions, actions.firstChild);
  const cfgBtn = document.createElement('button'); cfgBtn.textContent = '⚙ e-taxes'; cfgBtn.title = 'e-taxes statuslarının və vergi kodlarının uyğunlaşdırılması';
  actions.insertBefore(cfgBtn, document.getElementById('refreshBtn'));
  const st = document.createElement('style'); st.textContent = '.ammo-etax-modal table{min-width:0!important}.ammo-etax-modal th,.ammo-etax-modal td{text-align:left!important;border:0;border-bottom:1px solid #eef2f7}.ammo-etax-modal select{height:auto}'; document.head.appendChild(st);

  let plan = null, busy = false;

  function companyName(tp) {
    return data.find((r) => r.voen === tp.voen && r.teskilat)?.teskilat
      || [...document.querySelectorAll('#ammoCompaniesList option')].find((o) => o.textContent.trim() === tp.voen)?.value
      || tp.name || ('VÖEN ' + tp.voen);
  }
  function slotMatch(r, type, per) {
    if (r[`${type}Year`] !== per.year) return false;
    if (per.month) return r[`${type}Month`] === per.month;
    if (per.rub) return r[`${type}Rub`] === per.rub;
    return true;
  }

  function buildPlan(voen, decls) {
    // hər (növ, dövr) üçün ən son bəyannamə
    const best = new Map(), unknown = new Set(), unmapped = new Set();
    for (const d of decls) {
      const type = typeOf(d); if (!type) { if (d.taxCode) unmapped.add(d.taxCode); continue; }
      const per = periodOf(type, d); if (!per) continue;
      const ms = mapStatus(d.status, d.kind); if (ms.draft || !ms.status) continue;
      if (!ms.known) unknown.add(d.status);
      const key = `${type}|${per.year}|${per.month || per.rub || ''}`;
      const cur = best.get(key);
      const score = (d.lastClarifying ? 2 : 0) + 0;
      if (!cur || score > cur.score || (score === cur.score && String(d.regDate) > String(cur.d.regDate))) best.set(key, { type, per, d, status: ms.status, score });
    }
    const rows = data.filter((r) => r.voen === voen);
    const items = [];
    for (const b of best.values()) {
      const row = rows.find((r) => slotMatch(r, b.type, b.per));
      if (row) { if ((row[`${b.type}Status`] || '') !== b.status) items.push({ kind: 'change', row, ...b, old: row[`${b.type}Status`] || '' }); }
      else items.push({ kind: 'add', ...b, old: '' });
    }
    items.sort((a, b) => String(b.per.year).localeCompare(String(a.per.year)) || a.type.localeCompare(b.type));
    return { items, unknown: [...unknown], unmapped: [...unmapped] };
  }

  async function check(manual) {
    if (busy) return; busy = true;
    try {
      const r = await E.snapshot({ declarations: true });
      if (!r.ok) { plan = null; chip.classList.add('hidden'); if (manual) bar.show('warn', E.errorText(r)); else bar.hide(); return; }
      const tp = r.taxpayer || {};
      if (r.declInfo === 'expired') { bar.show('warn', 'e-taxes sessiyasının vaxtı bitib — kabinetə yenidən daxil olun.'); return; }
      if (!tp.voen) { if (manual) bar.show('warn', 'e-taxes kabineti açıqdır, amma şirkətin VÖEN-i müəyyən edilmədi.', 'Kabinetin ana səhifəsini bir dəfə açıb yenidən “Yenilə” basın.'); return; }
      const decls = r.declarations || [];
      remember(decls);
      const who = { voen: tp.voen, name: companyName(tp) };
      const p = buildPlan(who.voen, decls);
      plan = { who, ...p };
      const n = p.items.length;
      chip.textContent = `🔔 Yenilənmə (${n})`; chip.classList.toggle('hidden', !n);
      const extra = [p.unknown.length ? `Naməlum status: ${p.unknown.join(', ')} — “⚙ e-taxes”-dən uyğunlaşdırın` : '', p.unmapped.length ? `Tanınmayan vergi kodu: ${p.unmapped.join(', ')}` : ''].filter(Boolean).join(' · ');
      if (n) {
        const ch = p.items.filter((x) => x.kind === 'change').length, ad = n - ch;
        const preview = p.items.slice(0, 3).map((x) => `${TYPES[x.type]} ${x.per.label}: ${x.old ? x.old + ' → ' : ''}${x.status}`).join('  |  ');
        bar.show('new', `Yenilənmə — ${who.name} (${who.voen}): ${ch ? ch + ' status dəyişib' : ''}${ch && ad ? ', ' : ''}${ad ? ad + ' yeni bəyannamə' : ''}`, preview + (n > 3 ? '  …' : '') + (extra ? '  ·  ' + extra : ''), apply, 'Yenilənmə ⤵');
      } else if (manual || extra) {
        bar.show(extra ? 'info' : 'ok', `${who.name} (${who.voen}): statuslar kabinetlə eynidir`, (extra || `${decls.length} bəyannamə yoxlanıldı`) + ` · ${new Date().toLocaleTimeString('az-AZ')}`);
      }
    } finally { busy = false; }
  }

  async function apply() {
    if (!plan || !plan.items.length) return;
    const { who, items } = plan; plan = null; chip.classList.add('hidden');
    bar.show('info', 'Statuslar yenilənir...');
    const touched = new Map();
    for (const it of items) {
      const t = it.type, date = isoDay(it.d.regDate);
      let row = it.kind === 'change' ? it.row : null;
      if (!row) row = data.find((r) => r.voen === who.voen && !r[`${t}Status`] && !r[`${t}Year`]);
      if (!row) { row = { id: 'id_' + Date.now() + '_' + Math.random().toString(16).slice(2), teskilat: who.name, voen: who.voen, deleted: false }; data.unshift(row); }
      row[`${t}Year`] = it.per.year;
      if (it.per.month) row[`${t}Month`] = it.per.month;
      if (it.per.rub) row[`${t}Rub`] = it.per.rub;
      row[`${t}Status`] = it.status;
      if (date && (!row[`${t}Date`] || it.kind === 'add')) row[`${t}Date`] = date;
      row.updatedAt = String(Date.now()); row.etaxSyncedAt = new Date().toISOString();
      touched.set(row.id, row);
    }
    saveLocal(); renderAll();
    let ok = 0;
    for (const row of touched.values()) {
      try { await apiFetch(`${BASE}/${encodeURIComponent(row.id)}`, { method: 'PATCH', body: JSON.stringify({ fields: toFsFields(row) }) }); ok++; }
      catch (e) { console.warn('AMMO status Firebase', e); }
    }
    if (ok) window.AMMO_REV?.bump('beyannameNezaret');
    try { await fetchFirebaseRecords(); } catch (e) { /* lokal qalır */ }
    bar.show(ok === touched.size ? 'ok' : 'warn', `${who.name}: ${items.length} status yeniləndi`, ok === touched.size ? 'Firebase serverə yazıldı — bütün kompüterlərdə görünəcək.' : `${touched.size - ok} sətir hələ Firebase-ə yazılmadı (internet?).`);
  }

  // ---------- ⚙ uyğunlaşdırma ----------
  cfgBtn.onclick = () => {
    const seen = readJson(SEEN_KEY, { status: {}, code: {} }), um = userMap();
    const sOpts = (cur) => '<option value="">Avtomatik</option>' + statuses.map((s) => `<option${cur === s ? ' selected' : ''}>${E.esc(s)}</option>`).join('');
    const cOpts = (cur) => `<option value="">Avtomatik</option>` + Object.entries(TYPES).map(([k, v]) => `<option value="${k}"${cur === k ? ' selected' : ''}>${v}</option>`).join('') + `<option value="skip"${cur === 'skip' ? ' selected' : ''}>Nəzərə alma</option>`;
    const sRows = Object.keys(seen.status).map((s) => `<tr><td><code>${E.esc(s)}</code></td><td>${E.esc(mapStatus(s, '').status || '— (qaralama, keçilir)')}</td><td><select data-s="${E.esc(s)}">${sOpts(um.status[s])}</select></td></tr>`).join('') || '<tr><td colspan="3">Hələ status görülməyib — əvvəlcə kabinet açıq ikən “Yenilə” basın.</td></tr>';
    const cRows = Object.entries(seen.code).map(([c, n]) => `<tr><td><code>${E.esc(c)}</code>${typeof n === 'string' ? `<br><small>${E.esc(n)}</small>` : ''}</td><td>${E.esc(TYPES[typeOf({ taxCode: c, strings: { n: typeof n === 'string' ? n : '' } })] || '—')}</td><td><select data-c="${E.esc(c)}">${cOpts(um.code[c])}</select></td></tr>`).join('') || '<tr><td colspan="3">Hələ vergi kodu görülməyib.</td></tr>';
    E.modal('e-taxes uyğunlaşdırma', 'Kabinetdən gələn xam status və vergi kodlarının bu paneldə necə göstərilməsi. Seçim Firebase-ə yazılır, bütün kompüterlərdə eyni olur.',
      `<h4 style="margin:6px 0">Statuslar</h4><table><thead><tr><th>e-taxes statusu</th><th>İndi</th><th>Göstər</th></tr></thead><tbody>${sRows}</tbody></table>
       <h4 style="margin:16px 0 6px">Vergi kodları</h4><table><thead><tr><th>Kod</th><th>İndi</th><th>Sütun</th></tr></thead><tbody>${cRows}</tbody></table>`,
      [{ text: 'Ləğv et' }, { text: 'Yadda saxla', primary: true, onClick: (m) => {
        const next = { status: {}, code: {} };
        m.querySelectorAll('[data-s]').forEach((x) => { if (x.value) next.status[x.dataset.s] = x.value; });
        m.querySelectorAll('[data-c]').forEach((x) => { if (x.value) next.code[x.dataset.c] = x.value; });
        localStorage.setItem(MAP_KEY, JSON.stringify(next));
        check(true);
      } }]);
  };

  chip.onclick = apply;
  document.getElementById('refreshBtn')?.addEventListener('click', () => check(true));
  setTimeout(() => check(false), 3000);
  setInterval(() => { if (document.visibilityState === 'visible') check(false); }, 60000);
})();
