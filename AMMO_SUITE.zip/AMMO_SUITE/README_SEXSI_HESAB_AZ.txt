AMMO SUITE — "Şəxsi hesab → Borc" paneli
=========================================

NƏ EDİR
 e-taxes.gov.az-dan yüklənən "Şəxsi hesab vərəqəsi" faylını (.xls) atırsınız, DOLDUR basırsınız —
 "VERGİ VƏ DSMF ÖHDƏLİKLƏRİ" forması avtomatik dolur:
  • hər vergi növünün qalığı + faizi bir yerdə (məs. qalıq 1000 + faiz 300 = 1300);
  • DSMF: pensiya, işsizlik və İTS — işçidən tutulan və işəgötürən hesabına ayrıca, penya/faizi ilə;
  • cəmilər vərəqədəki son qalıqla qəpiyinədək yoxlanılır (yaşıl ✓ işarəsi).
 Sonra "⬇ Excel" (.xlsx, 3 vərəq: forma, ətraflı açılış, vərəqə sətirləri) və ya "⬇ PDF" yükləyin.

QURAŞDIRMA
 1) Bu AMMO_SUITE qovluğunu köhnəsinin yerinə qoyun (və ya yalnız bunları köçürün:
      modules\sexsi-hesab\  (bütün qovluq)
      suite.js              (yeni panel menyuya əlavə olunub)
 2) chrome://extensions → AMMO SUITE → ↻ (Reload).
 3) Menyuda "🧮 Şəxsi hesab → Borc" görünəcək.

QEYD — AVTOMATİK YENİLƏNMƏ
 AMMO-Updater serverdə yeni versiya tapanda AMMO_SUITE qovluğunu tam əvəz edir.
 Panelin itməməsi üçün bu iki dəyişiklik (modules\sexsi-hesab və suite.js-dəki "sexsiHesab" sətri)
 növbəti yeniləmə paketinə də daxil edilməlidir.

FORMADA SƏTİRLƏR
 Vərəqədəki hər öhdəlik növü formada uyğun sətrə yazılır. "Hesablamanın açılışı" cədvəlində
 istənilən növün hansı sətrə düşəcəyini dəyişə bilərsiniz (seçim yadda qalır).
 Nümunədə olmayan növlər (ƏDV, muzdlu işdən gəlir vergisi, digər) yalnız borc olduqda əlavə sətir kimi görünür.
