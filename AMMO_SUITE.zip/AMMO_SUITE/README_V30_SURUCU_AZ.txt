SÜRÜCÜ GƏLİR HESABATI — V10.1
==============================

V10.1 YENİLİKLƏRİ
- Direktor hesabatı düzəldildi:
    10% gəlir vergisi        = Gəlirlər × 10%
    − Nağdlaşdırma           = Gəlirlər × 2%
    − Turnisə xanım          = 10% × 5%
    = Hesablanacaq məbləğ
    Məmməd = Hesablanacaq × 20% + xidmət haqqı (ALLAHVERDİYEV M. sətrinə avtomatik yazılır)
    Aydın  = Hesablanacaq × 10%
    Xəyalə xanım = Hesablanacaq − Məmməd(20%) − Aydın(10%)
  Nümunə 12.10.2026: 19 802,39 → 1 980,24 − 396,05 − 99,01 = 1 485,18 → Xəyalə xanım 1 039,63
- Hesablama cədvəlində "Xidmət haqqı" başlığında quş: basanda hamısından 50 ₼ tutulur.
- Xidmət haqqı bölməsi sadə siyahı oldu: ay seçimi, Ödəməyənlər / Ödəyənlər / Hamısı.
- PDF və Excel çıxışları səliqəli formatda (Azərbaycan hərfləri, başlıq, cəm, imza yerləri).
- Ayarlar: şirkət və imzalar, ödəniş formaları, direktor bölgüsü (tutulma/pay əlavə et, faiz,
  nədən hesablanır, xidmət haqqı əlavə olunsun, kimin kartına yazılsın).
- Rənglər sakitləşdirildi — bir əsas rəng.


NƏ DƏYİŞDİ
- Köhnə "Sürücü bazası" silindi. Baza 16.09, 25.09 və 06.10.2026 Excel hesabatlarından
  yenidən quruldu (40 sürücü, ən son kart nömrələri). 3 hesabat da arxivə yazıldı.
  Köhnə (V9) məlumat silinmir: Ayarlar → "Köhnə (V9) bazanı yüklə".
- Hesablama:  2% NAĞDLAŞDIRMA = Gəlirlər × 2%
              10% GƏLİR VERGİSİ = Gəlirlər × 10%
              CƏMİ TUTULAN = 2% + 10% (+ xidmət haqqı, + digər tutulma varsa)
              ƏLİNƏ ÇATAN = Gəlirlər − Cəmi tutulan
  Faizlər Ayarlardan dəyişilir. Arxivdəki köhnə sətirlər öz faizi (1,5%) ilə qalır.

BÖLMƏLƏR
⚡ Hesablama — PDF reyestri (və ya Excel reyestri) atın. Reyestrin yekun məbləği oxunan
   reyslərlə müqayisə olunur. "Yoxlama mərkəzi" 3 addımı göstərir:
   1) Reyestr oxundu  2) Yeni maşınlar  3) Xidmət haqqı  → sonra "Arxivə yaz".
   • YENİ MAŞIN: bazada olmayan nömrə sarı yanıb-sönür və avtomatik pəncərə açılır —
     yeni sürücü kimi yazın və ya mövcud sürücüyə bağlayın.
   • XİDMƏT HAQQI (50 ₼/ay): həmin ay ödəməyən sürücü qırmızı yanıb-sönür. Ödəniş yazılmadan
     arxivə yazmaq olmur. Seçimlər: maaşdan tut / nağd / köçürmə / bu ay azad / sonraya saxla.
   • Maşınsız şəxslər (məs. ALLAHVERDİYEV M.) hər hesabata avtomatik əlavə olunur — məbləği yazın.
🗂 Arxiv — tarix kartları, filtr, düzəliş, Excel / PDF / Karta köçürmə.
   Excel hesabatı (SURUCULER_ETRAFLI_HESABAT_...) atılan kimi arxivə yazılır; yeni sürücülər
   və dəyişmiş kart nömrələri bazaya avtomatik düşür.
👥 Sürücü paneli — əlavə et, düzəliş, maşın köçür, iki sürücünü birləşdir, passiv et, tarixçə.
💳 Xidmət haqqı — 6 aylıq cədvəl (✓ / ✗ / —), yığılan məbləğ, ödəniş yazmaq.
👔 Direktor hesabatı — seçilmiş tarixin 10% gəlir vergisi cəmi əsas götürülür:
     10% cəmi − əlavə komissiya → −5% → −2% → yerdə qalan
     yerdə qalan × 20%, yerdə qalan × 10% → qalan məbləğ Xəyalə xanıma.
   Faizləri, adları və addımları Ayarlarda dəyişmək/söndürmək olar. PDF və Excel çıxışı var.
⚙ Ayarlar — faizlər, xidmət haqqı, direktor bölgüsü, ehtiyat nüsxə (JSON) yüklə/bərpa et.

QURAŞDIRMA
AMMO_SUITE qovluğunu köhnəsi ilə əvəz edin → chrome://extensions → AMMO SUITE → ↻ (yenilə).
İlk açılışda baza və arxiv avtomatik qurulur və buludla sinxronlaşır.
