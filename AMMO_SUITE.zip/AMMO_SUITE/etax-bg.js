/* AMMO SUITE V30.2 — e-taxes körpüsü (service worker).
   Vergi məktubları və Bəyannamə nəzarət panelləri "Yenilə" basanda:
     → açıq new.e-taxes.gov.az tabını tapır,
     → həmin tabda (kabinetin öz sessiyası ilə) şirkəti, məktubları və bəyannamələri oxuyur,
     → nəticəni panelə qaytarır. Heç nə göndərmir/imzalamır — yalnız oxuyur. */

const AMMO_ETAX_URL = 'https://new.e-taxes.gov.az/*';

// Bu funksiya e-taxes səhifəsinin içində (MAIN world) işləyir — tam müstəqil olmalıdır.
async function ammoEtaxCollect(opts) {
  const TIN_RX = /^\d{10}$/;
  const out = { ok: true, at: Date.now(), url: location.href, taxpayer: { voen: '', name: '', source: '' }, letters: null, lettersInfo: '', declarations: null, declInfo: '' };
  const rawJwt = localStorage.getItem('aztax-jwt') || '';
  const token = rawJwt.replace(/^Bearer\s+/i, '').replace(/^"|"$/g, '');
  if (!token) return { ok: false, error: 'no_token', url: location.href };
  const H = { Accept: 'application/json, text/plain, */*', 'Content-Type': 'application/json', 'x-authorization': 'Bearer ' + token };
  const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k) || 'null') ?? d; } catch (e) { return d; } };

  function findTaxpayer(o, depth = 0, best = { voen: '', name: '', score: 0 }) {
    if (!o || typeof o !== 'object' || depth > 5) return best;
    let tin = '', name = '', tinKey = '';
    for (const [k, v] of Object.entries(o)) {
      if ((typeof v === 'string' || typeof v === 'number') && /tin|voen/i.test(k) && TIN_RX.test(String(v))) { if (!tin || /org|company|legal|taxpayer|entity/i.test(k)) { tin = String(v); tinKey = k; } }
      if (typeof v === 'string' && /name|title/i.test(k) && !/user|login|first|last|middle|father|ata/i.test(k) && v.trim().length > 2) name = name || v.trim();
    }
    if (tin) { const sc = (name ? 2 : 1) + (/org|company|legal|taxpayer|entity/i.test(tinKey) ? 2 : 0); if (sc > best.score) Object.assign(best, { voen: tin, name, score: sc }); }
    for (const v of Object.values(o)) if (v && typeof v === 'object') findTaxpayer(v, depth + 1, best);
    return best;
  }
  function biggestArray(o, depth = 0) {
    let best = null;
    if (!o || depth > 5) return null;
    if (Array.isArray(o)) { if (o.length && o[0] && typeof o[0] === 'object') best = o; o.slice(0, 3).forEach((x) => { const b = biggestArray(x, depth + 1); if (b && (!best || b.length > best.length)) best = b; }); return best; }
    if (typeof o === 'object') for (const v of Object.values(o)) { const b = biggestArray(v, depth + 1); if (b && (!best || b.length > best.length)) best = b; }
    return best;
  }

  // 1) Şirkət: JWT → səhifənin öyrəndiyi profil cavabı → səhifə mətni
  try {
    const p = JSON.parse(decodeURIComponent(escape(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')))));
    const tp = findTaxpayer(p);
    if (tp.voen) out.taxpayer = { voen: tp.voen, name: tp.name, source: 'jwt' };
  } catch (e) { /* JWT oxunmadı */ }
  const cap = load('ammo_etax_taxpayer', null);
  if (cap && cap.voen && (!out.taxpayer.voen || cap.voen === out.taxpayer.voen)) out.taxpayer = { voen: cap.voen, name: cap.name || out.taxpayer.name, source: out.taxpayer.source || 'profile' };
  if (!out.taxpayer.voen || !out.taxpayer.name) {
    const text = (document.querySelector('header')?.innerText || '') + '\n' + (document.body?.innerText || '').slice(0, 6000);
    const m = text.match(/(?:VÖEN|VOEN)\s*[:№]?\s*(\d{10})/i) || text.match(/\b(\d{10})\b/);
    if (m && !out.taxpayer.voen) out.taxpayer = { ...out.taxpayer, voen: m[1], source: 'page' };
  }

  // 2) Bəyannamələr
  if (opts.declarations) {
    const yNow = new Date().getFullYear();
    const years = opts.years && opts.years.length ? opts.years : [yNow, yNow - 1];
    const all = [];
    for (const y of years) {
      try {
        const r = await fetch('https://new.e-taxes.gov.az/api/po/declaration/public/v1/declaration/list?year=' + encodeURIComponent(y), { method: 'GET', headers: H, credentials: 'include' });
        if (r.status === 401 || r.status === 403) { out.declInfo = 'expired'; break; }
        if (!r.ok) { out.declInfo = 'HTTP ' + r.status; continue; }
        const j = await r.json();
        if (!out.taxpayer.voen) { const tp = findTaxpayer(j); if (tp.voen) out.taxpayer = { voen: tp.voen, name: tp.name, source: 'declarations' }; }
        for (const item of (j.declarations || biggestArray(j) || [])) {
          const d = item.declaration || item;
          const strings = {};
          for (const [k, v] of Object.entries(d || {})) if (typeof v === 'string' && v.length < 200) strings[k] = v;
          all.push({
            id: d.id || '', taxCode: d.taxCode || '', status: d.declarationStatus || d.status || '', kind: d.declarationType || '',
            month: Number(d.reportingPeriod?.month || 0), year: Number(d.reportingPeriod?.year || y), quarter: Number(d.reportingPeriod?.quarter || 0),
            regDate: d.registrationDate || d.submissionDate || d.createdDate || '', lastClarifying: d.lastClarifying === true, strings
          });
        }
      } catch (e) { out.declInfo = String(e.message || e); }
    }
    out.declarations = all;
  }

  // 3) Məktublar — kabinetin özünün istifadə etdiyi ünvan (etax-capture.js öyrənir)
  if (opts.letters) {
    const eps = load('ammo_etax_letter_eps', []);
    const rows = [];
    // V31.0.3: kabinetin rəsmi "Daxil olanlar" ünvanı — qeydiyyat nömrəsi, tarix, göndərən, .adoc faylı ilə
    try {
      const pad = (n) => String(n).padStart(2, '0'), now = new Date();
      const endDate = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
      const startDate = `${now.getFullYear() - 1}-01-01`;
      for (let offset = 0; offset < 1000; offset += 100) {
        const r = await fetch('https://new.e-taxes.gov.az/api/po/edi/public/v1/message/find.inbox', { method: 'POST', headers: H, credentials: 'include',
          body: JSON.stringify({ offset, maxCount: 100, containsText: '', categoryCodes: [], docGroups: null, unreadOnly: null, registerNumber: null, withActionOnly: null, withAttachmentsOnly: null, startDate, endDate, correspondent: { kind: 'taxauthority', tin: null, taxAuthorityCode: null, name: null, fin: null } }) });
        if (r.status === 401 || r.status === 403) { out.lettersInfo = 'expired'; break; }
        if (!r.ok) break;
        const j = await r.json();
        for (const m of (j.messages || [])) {
          rows.push({ id: m.id, documentNumber: m.newRegisterNumber || m.registerNumber || '', registerNumber: m.registerNumber || '', sentDate: m.createdAt || '',
            subject: m.subject || '', senderName: m.correspondent?.name?.az || '', hasAttachment: !!m.hasAttachment, deadlineDate: m.deadlineDate || '', __ammoApi: true, __raw: m });
        }
        if (!j.hasMore || !(j.messages || []).length) break;
      }
      if (rows.length) out.lettersInfo = 'api';
      // V31.3: oxunmamış (kabinetdə qara/qalın görünən) məktubları ayır — AMMO-ya yalnız onlar düşür
      if (rows.length) {
        const unreadIds = new Set(); let unreadOk = false;
        try {
          for (let offset = 0; offset < 1000; offset += 100) {
            const r = await fetch('https://new.e-taxes.gov.az/api/po/edi/public/v1/message/find.inbox', { method: 'POST', headers: H, credentials: 'include',
              body: JSON.stringify({ offset, maxCount: 100, containsText: '', categoryCodes: [], docGroups: null, unreadOnly: true, registerNumber: null, withActionOnly: null, withAttachmentsOnly: null, startDate, endDate, correspondent: { kind: 'taxauthority', tin: null, taxAuthorityCode: null, name: null, fin: null } }) });
            if (!r.ok) break;
            const j = await r.json(); unreadOk = true;
            for (const m of (j.messages || [])) unreadIds.add(String(m.id));
            if (!j.hasMore || !(j.messages || []).length) break;
          }
        } catch (e) { unreadOk = false; }
        // Server filtri işləməyibsə (hamısını qaytarıbsa) məktubun öz sahəsindən oxu
        if (unreadOk && unreadIds.size >= rows.length && rows.length > 1) unreadOk = false;
        for (const x of rows) {
          if (unreadOk) { x.unread = unreadIds.has(String(x.id)); continue; }
          const m = x.__raw || {};
          const flag = [m.unread, m.isUnread, m.isNew].find((v) => typeof v === 'boolean');
          const read = [m.read, m.isRead, m.seen, m.isSeen, m.opened].find((v) => typeof v === 'boolean');
          if (typeof flag === 'boolean') x.unread = flag;
          else if (typeof read === 'boolean') x.unread = !read;
          else if ('readAt' in m || 'readDate' in m) x.unread = !(m.readAt || m.readDate);
          else x.unread = null; // bilinmir
        }
        rows.forEach((x) => { delete x.__raw; });
        out.unreadInfo = unreadOk ? 'server' : (rows.some((x) => x.unread !== null) ? 'field' : 'unknown');
      }
    } catch (e) { /* köhnə üsula keç */ }
    for (const ep of (rows.length ? [] : eps.slice(0, 3))) {
      try {
        const init = { method: ep.method || 'GET', headers: H, credentials: 'include' };
        if (ep.method && ep.method !== 'GET' && ep.body) init.body = ep.body;
        const r = await fetch(ep.url, init);
        if (r.status === 401 || r.status === 403) { out.lettersInfo = 'expired'; break; }
        if (!r.ok) continue;
        const arr = biggestArray(await r.json()) || [];
        arr.slice(0, 500).forEach((x) => rows.push({ ...x, __ammoEp: ep.path }));
      } catch (e) { /* növbəti ünvan */ }
    }
    if (!eps.length && !rows.length) out.lettersInfo = 'no_endpoint';
    // Ehtiyat: məktublar səhifəsi açıqdırsa ekrandakı cədvəli oxu
    if (!rows.length && /letter|mektub|message|notif|bildiri|inbox|mail/i.test(location.href)) {
      const table = [...document.querySelectorAll('table')].sort((a, b) => b.rows.length - a.rows.length)[0];
      if (table && table.rows.length > 1) {
        const head = [...table.rows[0].cells].map((c) => c.innerText.trim());
        [...table.rows].slice(1).forEach((tr) => { const o = { __ammoDom: true }; [...tr.cells].forEach((c, i) => { o[head[i] || 'col' + i] = c.innerText.trim(); }); rows.push(o); });
        out.lettersInfo = 'dom';
      }
    }
    out.letters = rows;
  }
  return out;
}

// V31.0.3: məktubun .adoc faylını kabinetdən oxu (MAIN world). Heç nə göndərmir/imzalamır.
async function ammoEtaxLetterFile(opts) {
  const rawJwt = localStorage.getItem('aztax-jwt') || '';
  const token = rawJwt.replace(/^Bearer\s+/i, '').replace(/^"|"$/g, '');
  if (!token) return { ok: false, error: 'no_token' };
  const H = { Accept: 'application/json, text/plain, */*', 'x-authorization': 'Bearer ' + token };
  try {
    const r = await fetch('https://new.e-taxes.gov.az/api/po/edi/public/v1/message/' + encodeURIComponent(opts.id) + '?sourceSystem=avis', { headers: H, credentials: 'include' });
    if (r.status === 401 || r.status === 403) return { ok: false, error: 'expired' };
    if (!r.ok) return { ok: false, error: 'HTTP ' + r.status };
    const d = await r.json();
    const tin = d.recipient?.tin || '';
    if (opts.voen && tin && tin !== opts.voen) return { ok: false, error: 'wrong_company', tin };
    const files = d.files || [];
    const f = files.find((x) => x.kind === 'main' && /\.adoc$/i.test(x.name)) || files.find((x) => /\.adoc$/i.test(x.name)) || files[0];
    if (!f) return { ok: false, error: 'no_file' };
    const fr = await fetch('https://new.e-taxes.gov.az/api/po/filestorage/public/v1/download/' + encodeURIComponent(f.id) + '?type=avis', { headers: H, credentials: 'include' });
    if (!fr.ok) return { ok: false, error: 'file HTTP ' + fr.status };
    const u8 = new Uint8Array(await fr.arrayBuffer());
    let bin = ''; for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return { ok: true, name: f.name, size: u8.length, b64: btoa(bin), tin, regNo: d.newRegisterNumber || d.registerNumber || '' };
  } catch (e) { return { ok: false, error: String(e.message || e) }; }
}

// V31.1: Şəxsi hesab vərəqəsi — əməliyyat tarixçəsi + faiz tarixçəsi + rəsmi qalıqlar (yalnız oxuyur)
async function ammoEtaxShv(opts) {
  const token = (localStorage.getItem('aztax-jwt') || '').replace(/^Bearer\s+/i, '').replace(/^"|"$/g, '');
  if (!token) return { ok: false, error: 'no_token' };
  const H = { Accept: 'application/json, text/plain, */*', 'x-authorization': 'Bearer ' + token };
  const pad = (n) => String(n).padStart(2, '0'), now = new Date();
  const end = `${now.getFullYear()}/${pad(now.getMonth() + 1)}/${pad(now.getDate())}`;
  const B = 'https://new.e-taxes.gov.az/api/po/budget/public/v1';
  const sheet = async (start, type) => {
    const r = await fetch(`${B}/operations/shv/extract/html?startDate=${start}&endDate=${end}&amountType=1&reportType=${type}&format=html&detail=0&customBalance=0`, { headers: H, credentials: 'include' });
    if (r.status === 401 || r.status === 403) { const e = new Error('expired'); e.code = r.status; throw e; }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  };
  try {
    let ops = '';
    for (const start of [opts.from || '2000/01/01', '2004/01/01', `${now.getFullYear() - 5}/01/01`]) { try { ops = await sheet(start, 2); if (ops.length > 500) break; } catch (e) { if (e.message === 'expired') throw e; } }
    if (!ops) return { ok: false, error: 'no_sheet' };
    let faiz = '';
    try { faiz = await sheet(`${now.getFullYear() - 1}/01/01`, 1); } catch (e) { /* faiz tarixçəsi məcburi deyil */ }
    let liabilities = null;
    try { const r = await fetch(`${B}/liabilities`, { headers: { ...H, Accept: 'application/json' }, credentials: 'include' }); if (r.ok) liabilities = await r.json(); } catch (e) { /* məcburi deyil */ }
    return { ok: true, ops, faiz, liabilities, at: Date.now() };
  } catch (e) { return { ok: false, error: e.message === 'expired' ? 'expired' : String(e.message || e) }; }
}

async function ammoEtaxFindTab() {
  const tabs = await chrome.tabs.query({ url: AMMO_ETAX_URL });
  if (!tabs.length) return null;
  tabs.sort((a, b) => (b.active - a.active) || ((b.lastAccessed || 0) - (a.lastAccessed || 0)));
  return tabs[0];
}

async function ammoEtaxSnapshot(opts = {}) {
  const tab = await ammoEtaxFindTab();
  if (!tab) return { ok: false, error: 'no_tab' };
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: ammoEtaxCollect, args: [opts] });
    const r = res && res.result;
    if (!r) return { ok: false, error: 'no_result' };
    return { ...r, tabTitle: tab.title || '' };
  } catch (e) {
    return { ok: false, error: 'script_failed', detail: String(e.message || e) };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'AMMO_ETAX_FILE') {
    (async () => {
      const tab = await ammoEtaxFindTab();
      if (!tab) return { ok: false, error: 'no_tab' };
      const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: ammoEtaxLetterFile, args: [message.opts || {}] });
      return (res && res.result) || { ok: false, error: 'no_result' };
    })().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (message?.type === 'AMMO_ETAX_SHV') {
    (async () => {
      const tab = await ammoEtaxFindTab();
      if (!tab) return { ok: false, error: 'no_tab' };
      const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: ammoEtaxShv, args: [message.opts || {}] });
      return (res && res.result) || { ok: false, error: 'no_result' };
    })().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (message?.type !== 'AMMO_ETAX_SNAPSHOT') return;
  ammoEtaxSnapshot(message.opts || {}).then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
  return true;
});
