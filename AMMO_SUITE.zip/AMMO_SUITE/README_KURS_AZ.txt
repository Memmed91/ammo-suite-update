AMMO SUITE — 🎓 Kurs İdarəetmə
=============================

AMMO menyusunda "🎓 Kurs İdarəetmə". Proqram açılan kimi QƏBUL ekranı — müəllimlərin həftəlik boş saatları.

PANELLƏR
 🏠 Qəbul · Boş saatlar — müəllimlərin hər gün üzrə boş saatları, "Boş vaxt axtar" (kurs + 2×/3×/intensiv
    + günlər + saat → uyğun müəllimlər), müəllimin həftəlik vizual cədvəli, bu günün dərsləri.
 🎓 Tələbələr — ad, soyad, vəsiqə məlumatları və şəkli (ön/arxa), kurs, müəllim, həftədə neçə dəfə,
    günlər (tək/cüt/hər gün), saat, dərs müddəti (avtomatik), kursa yazıldığı məbləğ, güzəşt
    (faiz + səbəb + hansı aylara), status. Müəllim məşğuldursa xəbərdarlıq edir.
 👩‍🏫 Müəllimlər — şəxsi məlumat, vəsiqə, DİPLOM, faiz, kurslar, iş günləri və saatları, gəlmədiyi günlər.
 📚 Kurslar — ad, müddət (1/4/8… ay), aylıq qiymət.
 🗓 Davamiyyət — gün üzrə: Gəldi / Üzrlü (sayılmır, əvəz olunur) / Üzrsüz (sayılır), müəllim gəlmədi,
    bayram günü, əvəz dərsi.
 💳 Ödənişlər — ay üzrə ödəniş qəbulu (güzəşt avtomatik), borclular.
 💼 Əmək haqqı — bir müəllim və ya hamısı; ay / gün / iki tarix arası / il → "Hesabla".
 📝 İmtahanlar — a, b, c, d variantlı testlər, mətndən toplu əlavə, imtahan keçirmə, avtomatik bal.
 📄 Hesabatlar — tələbə hesabatı (valideyn üçün) və müəllim hesabatı: Excel + PDF.
 📊 Direktor — maliyyə, kurslar, müəllimlər, davamiyyət, borclar, bütün əməliyyatlar: Excel (5 vərəq) + PDF.
 ⚙ Modullar və ayarlar — panelləri açıb-bağlamaq, sıralamaq, YENİ PANEL əlavə etmək
    (cədvəl / qeyd / link), dərs ayarları, bayram günləri, ehtiyat nüsxə.

HESABLAMA QAYDALARI
 • 1 ay = 12 saat. 2×/həftə → 1.5 saat (8 dərs), 3×/həftə → 1 saat (12 dərs), intensiv → 1 saat (12 dərs).
 • Tələbənin ayı 12-ci saat keçiriləndə bitir. Həmin gün müəllimin payı hesablanır:
   o ay üçün ödənilən məbləğ × müəllimin faizi. Ödəniş edilməyibsə pay hesablanmır (qeyd edilir).
 • Üzrlü buraxılış, müəllimin gəlmədiyi gün və bayram sayılmır → ay uzanır. Üzrsüz buraxılış sayılır.
 • Keçmiş dərs işarələnməyibsə "keçirilib" sayılır.

QURAŞDIRMA
 AMMO_SUITE qovluğunu Chrome-un yüklədiyi qovluqla əvəz edin → chrome://extensions → AMMO SUITE → ↻.
