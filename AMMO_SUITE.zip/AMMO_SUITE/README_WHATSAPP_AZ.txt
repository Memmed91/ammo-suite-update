AMMO SUITE — Borc Xatırladıcı: avtomatik WhatsApp mesajı
=========================================================

YENİLİKLƏR
 • Qeyd formasında: "Sahibkarın adı", "WhatsApp / əlaqə nömrəsi", "Kart nömrəsi" xanaları
   və "📲 Avtomatik WhatsApp mesajı" seçimi.
 • "Tələb et" məktubu artıq sahibkarın adına yazılır və kart nömrəsini göstərir.
 • Yeni "📲 WhatsApp" bölməsi: kart nömrəsi, göndərmə saatı (standart 10:10), mesaj şablonu,
   önizləmə, test mesajı, bu günün siyahısı və göndəriş jurnalı.
 • Hər gün saat 10:10-da ödəniş vaxtı çatan alacaqlara sahibkarın WhatsApp nömrəsinə mesaj
   ÖZÜ göndərilir (ay, məbləğ, əvvəlki aylardan qalan borc, kart nömrəsi). Hər mesaj 1 dəfə gedir.

QURAŞDIRMA
 1) Chrome-da AMMO SUITE hansı qovluqdan yüklənibsə (chrome://extensions → AMMO SUITE → "Details"
    → "Source"/"Mənbə"), o qovluğu bu AMMO_SUITE ilə əvəz edin.
 2) chrome://extensions → AMMO SUITE → ↻ (Reload).

İLK DƏFƏ (vacib)
 1) Borc Xatırladıcı → 📲 WhatsApp → "WhatsApp Web-i aç" → telefonla QR kodu skan edin.
 2) "Bizim kart nömrəmiz" xanasına kartı yazın → "Bu kartı bütün alacaqlara yaz".
 3) Hər alacaq qeydinə sahibkarın adını və WhatsApp nömrəsini yazın (✎ Redaktə).
 4) "Test mesajı" ilə öz nömrənizə yoxlayın.

ŞƏRTLƏR
 • Saat 10:10-da bu kompüterdə Chrome açıq olmalıdır (pəncərə kiçildilmiş ola bilər).
 • Kompüter sönülü olubsa, açılan kimi göndərilir (3 günə qədər — ayarlanır).
 • Mesajları yalnız bir kompüter göndərir ("Bu kompüterdən göndər"), dublikat getmir.
