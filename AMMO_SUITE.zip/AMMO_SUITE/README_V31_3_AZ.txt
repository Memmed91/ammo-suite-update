AMMO SUITE V31.3.0

Vergi məktubları:
- «↻ Yenilə» basanda e-taxes kabinetindən AMMO-ya YALNIZ OXUNMAMIŞ məktublar düşür
  (kabinetdə qara/qalın yazılanlar). Oxunmuş (boz) məktublar düşmür.
- Əvvəl cədvələ əlavə olunmuş məktublar yerində qalır.
