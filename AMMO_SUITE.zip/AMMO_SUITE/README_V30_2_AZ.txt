AMMO SUITE V30.2 — YENİLİKLƏR
==============================

1) LƏĞV EDİLDİ
   • 🧾 Sənəd hazırla və 📈 ƏDV analizi panelləri silindi (qovluqlar da paketdən çıxarıldı).
   • Firebase-dəki modul reyestrində qalsalar belə menyuda görünmürlər; admin (memmed@ammo.az)
     ilk girişdə onları reyestrdən avtomatik silir.

2) 🧮 ŞƏXSİ HESAB → BORC — REKVİZİTLƏR
   • Formadakı sətir adına (SV, ÖMV, Pensiya Fondu, İşsizlikdən sığorta ...) klikləyin —
     həmin öhdəliyin ödəniş rekvizitləri açılır: alan təşkilat, VÖEN, yığım hesabı, büdcə səviyyəsi,
     büdcə təsnifatı kodu, bank məlumatları. Hər sətrin yanında ⧉ kopyala düyməsi var.
   • "✎ Redaktə et" → dəyişin → "✓ Yadda saxla". "↺ Standarta qaytar" ilk dəyərləri bərpa edir.
   • Yuxarıdakı "🏦 Rekvizitlər" düyməsi bütün öhdəliklərin siyahısını açır.
   • Başlanğıc dəyərlər VERGİ.xlsx-dəndir. ƏDV, Fərdi sahibkar gəlir vergisi, Pensiya Fondu
     sətirlərində təsnifat kodu cədvəldə boş idi — Redaktə ilə yazın.
   • Bank (Dövlət Xəzinədarlıq Agentliyi, kod 210005, VÖEN 1401555071, m/h AZ41NABZ01360100000000003944,
     SWIFT CTREAZ22) əlavə olunub — ilk istifadədə bir dəfə yoxlayın.
   • Rekvizitlər və panel ayarları artıq Firebase-ə yazılır — bir kompüterdə düzəliş hamısında görünür.

3) 📬 VERGİ MƏKTUBLARI — KABİNETDƏN YENİLƏNMƏ
   • Chrome-da new.e-taxes.gov.az-da hansı şirkətin şəxsi kabineti açıqdırsa, "↻ Yenilə" basanda
     AMMO həmin kabinetin məktublarını oxuyur.
   • Yeni məktub varsa yuxarıda narıncı "🔔 Yenilənmə — ŞİRKƏT (VÖEN): N yeni məktub" çıxır.
     Üzərinə basan kimi məktublar cədvələ düşür (Təşkilat, VÖEN, Nömrə, Növ, Tarix gələn, Qeyd)
     və Firebase serverə yazılır. Eyni məktub ikinci dəfə əlavə olunmur.
   • Panel açıq olduqca hər dəqiqə səssiz yoxlanılır — "Yenilə" basmasanız da zolaq özü çıxır.
   • İLK DƏFƏ: yeni versiya quraşdırıldıqdan sonra e-taxes səhifəsini yeniləyin (F5) və kabinetdə
     bir dəfə "Məktublar / Bildirişlər" bölməsini açın. AMMO kabinetin məktub ünvanını öyrənir;
     bundan sonra həmin bölməyə girmək lazım deyil.

4) 📊 BƏYANNAMƏ NƏZARƏT — STATUSLARIN AVTOMATİK YENİLƏNMƏSİ
   • "↻ Yenilə" → açıq kabinetin cari və keçən il bəyannamələri oxunur (ƏDV, ÖMV, VVB, SV,
     Mənfəət/Gəlir, Əmlak, Torpaq) və buradakı statuslarla müqayisə olunur.
   • Fərq varsa "🔔 Yenilənmə — ŞİRKƏT: N status dəyişib, M yeni bəyannamə" çıxır. Üzərinə basan
     kimi həmin şirkətin statusları dəyişir və Firebase-ə yazılır.
   • "⚙ e-taxes" — kabinetdən gələn statusların (məs. ACCEPTED → TƏSDİQLƏNDİ) və vergi kodlarının
     (məs. Əmlak vergisinin kodu) hansı sütuna düşəcəyini seçirsiniz. Naməlum status çıxanda zolaqda
     yazılır — bir dəfə seçin, bütün kompüterlərdə qüvvədə olur.
   • Qaralamalar (DRAFT) nəzərə alınmır.

5) ☁ BÜTÜN PANELLƏR FIREBASE SERVERİNDƏ
   • Əlavə olaraq Şəxsi hesab və Hesabat Vaxtı panelləri də buluda bağlandı.
   • AMMO SUITE açılanda (və girişdən dərhal sonra) bütün panellərin serverdəki məlumatı bu
     kompüterə gətirilir — yeni kompüter, yenidən quraşdırma və ya yeni versiya fərq etmir.
     Sol altda "☁ Serverdən bərpa: N məlumat" görünür.
   • Yenidən başlamadan əvvəl açıq panellərin son dəyişiklikləri mütləq serverə yazılır.

6) 🔄 TAM AVTOMATİK YENİLƏNMƏ (TaxPro kimi)
   • Yeni versiya serverdə HƏR DƏQİQƏ yoxlanılır (update-config.json → "checkEveryMinutes": 1).
   • Yeni versiya tapılan kimi AMMO-Updater faylları özü əvəz edir — chrome://extensions-a girmək,
     silib yenidən yükləmək lazım deyil.
   • AMMO SUITE açıq deyilsə dərhal yenidən başlayır; açıqdırsa 60 saniyəlik zolaq çıxır:
     "İndi yenidən başlat" və ya "5 dəq. sonra". Yenidən açılanda "✅ yeniləndi" və qeydləriniz görünür.
   • Avtomatik quraşdırma alınmasa (məs. AMMO-Updater.exe həmin kompüterdə qeydiyyatda deyil)
     köhnə qayda ilə "🔔 Yeni versiya → İndi yenilə" zolağı və səbəbi göstərilir.
   • Söndürmək: update-config.json → "autoApply": false (onda yalnız bildiriş gəlir).

YAYIM (sizin kompüterinizdə, hər dəfə ki kimi)
   1) Bu AMMO_SUITE qovluğunu AMMO_ADMIN\AMMO_SUITE-in yerinə qoyun.
   2) manifest.json → "version": "30.2.0". Serverdəki (update.json) versiyadan BÖYÜK olmalıdır —
      serverdə artıq 30.2.x və ya daha yuxarı varsa, nömrəni artırın.
   3) AMMO-Yayim.exe → qeydlər → yayim\ qovluğundakı update.json və AMMO_SUITE.zip-i GitHub-a yükləyin.
   4) İşçi kompüterlərində heç nə etmək lazım deyil — 1-2 dəqiqə ərzində özləri yenilənəcək.
      (Bu versiyadan əvvəlki 29.x yoxlamanı hər 3 saatda edir — ilk keçid ən çox 3 saat çəkə bilər,
      və ya işçi "⟳ Yeniləməni yoxla" basar.)

QEYD — e-taxes oxunuşu
   • AMMO kabinetdə heç nə göndərmir, imzalamır, dəyişmir — yalnız oxuyur, həm də yalnız siz
     "Yenilə" basanda və ya panel açıq olanda dəqiqədə bir dəfə.
   • Kabinet sessiyası bitibsə zolaqda "sessiyanın vaxtı bitib" yazılır — kabinetə yenidən daxil olun.


AMMO SUITE V30.3 — ƏLAVƏLƏR
===========================
7) ⏰ Hesabat Vaxtı — kompüterə gələn Chrome/Windows bildirişləri ("HV ... son tarixinə N gün qalıb")
   ləğv edildi. Ekranda qalmış köhnə bildirişlər də silinir. Panelin özündə xəbərdarlıqlar qalır;
   Gmail/telefon kanalı aktivdirsə, onlar işləməyə davam edir.
8) ☰ Panelləri idarə et — İNDİ YALNIZ ADMİN (memmed@ammo.az) üçündür və BÜTÜN KOMPÜTERLƏRƏ təsir edir:
   • Açarı bağlayanda panel bütün işçilərdə ~5 saniyəyə yox olur; açanda hamıda görünür.
   • ▲▼ sıra hamı üçün eynidir.
   • "👥 Hamı" düyməsi — paneli yalnız seçdiyiniz işçilərə göstərmək (siyahıda AMMO-ya girmiş işçilər
     görünür, yeni e-poçt da yazmaq olar). "Hamı görsün" — məhdudiyyəti götürür.
   • İşçilərdə bu düymə görünmür, onların köhnə "gizli panel" seçimləri silinir.
