AMMO SUITE V31 — YENİLİKLƏR
===========================

1) YENİ İNTERFEYS
   • Sol menyu qruplara bölündü: Vergi · Maliyyə və kadr · Komanda. Emoji əvəzinə vahid xətti ikonlar.
   • Yuxarıda nazik zolaq: hansı bölmədəsiniz, server vəziyyəti və "yenilə" düyməsi.
   • Admin düymələri (Panellər, Modullar, Cihazlar), "Yeniləməni yoxla" və "Çıxış" — sol aşağıda
     adınıza basanda açılan menyudadır.
   • Yeni giriş ekranı.
   • Bütün panellər vahid rəngdədir: bir əsas mavi, neytral boz, ağ kartlar. Panellərin öz daxili menyusu
     açıq rəngli alt-menyu oldu (iki tünd menyu yan-yana durmur). Rənglər bir fayldadır: theme/ammo-ui.css.

2) GÖMRÜK NƏZARƏT PANELİ LƏĞV EDİLDİ
   • Panel paketdən çıxarıldı; admin ilk girişdə onu Firebase modul reyestrindən də silir.
   • İstifadə olunmayan köhnə fayllar (popup, Mənfəət-visual və s.) da silindi.

3) HAMISI BİR FIREBASE LAYİHƏSİNDƏ (Konsalting)
   • Bəyannamə nəzarət və Vergi məktubları artıq GOMRUK-NEZARET-də deyil, Konsalting-dədir
     (kolleksiyalar: beyannameNezaret, beyannameUcotu). Giriş AMMO SUITE hesabı ilə — ayrıca parol yoxdur.
   • Köçürmə avtomatikdir: panel açılanda köhnə layihədəki qeydlər Konsalting-ə yazılır. Eyni qeyd iki dəfə
     yazılmır; köhnə layihədəki daha yenidirsə yenilənir; Konsalting-də silinən qeyd geri qayıtmır.
   • Silmə artıq "yumşaq"dır (deleted: true) — bütün kompüterlərdə silinir.
   • GOMRUK-NEZARET layihəsini, bütün işçilər V31-ə keçəndən və panellərdə məlumatı yoxlayandan SONRA
     silmək olar. Silindikdən sonra köçürmə özü dayanır.

V31.0.1
   • Admin bağladığı paneli öz menyusunda görməyə davam edir ("gizli" işarəsi ilə); işçilərdə görünmür.
   • Panelləri idarə et: sol aşağıda adınıza basın → "Panelləri idarə et" (yalnız memmed@ammo.az).

V31.0.2 — FIREBASE OXUMA LİMİTİ
   • Konsalting layihəsinin gündəlik pulsuz oxuma limiti (50 000) bitmişdi: panellər hər 3–5 saniyədə
     bütün məlumatı yenidən oxuyurdu (Bəyannamə nəzarət tək başına saatda ~100 000 oxuma).
   • İndi hər bölmənin kiçik "dəyişiklik nişanı" var (suiteSharedV3/_rev_*). Kompüterlər yalnız bu nişanı
     30–60 saniyədə bir oxuyur; məlumat yalnız kimsə nəsə dəyişəndə yenidən yüklənir. Pəncərə görünmürsə
     yoxlama dayanır. Bir açıq AMMO saatda təxminən 300 oxuma edir (əvvəl on minlərlə).
   • Başqa kompüterdə edilən dəyişiklik ən çox 30 saniyəyə görünür; panel bağlama/açma ən çox 1 dəqiqəyə.

V31.0.3 — SÜRÜCÜ XİDMƏT HAQQI VƏ VERGİ MƏKTUBLARI
   • Sürücü gəlirləri: 50 ₼ xidmət haqqı artıq avtomatik tutulur — ayda BİR dəfə. Yeni reyslər əlavə
     olunanda arxivə baxılır: həmin ay bu maşın nömrəsindən (və ya bu sürücüdən) 50 ₼ tutulubsa, bir daha
     tutulmur ("✓ bu ay ödənib"); tutulmayıbsa qarşısına 50 ₼ yazılır. Maşın başqa sürücüyə keçsə də
     nömrəyə görə tanınır. Ayarlarda köhnə "mən yazım" rejimini yenə seçmək olar.
   • Vergi məktubları: "Nömrə" sütununa məktubun qeydiyyat nömrəsi düşür (köhnə qeydlərdə "Qeyd"dən
     götürülüb avtomatik yazıldı). Cavab verilməyən məktubda gecikmə günü hər gün artır (qırmızı "N gün").
   • Yeni "Sənəd (.adoc)" sütunu: şirkətin e-taxes kabineti açıq olanda hər məktubun .adoc faylı avtomatik
     götürülür və serverdə saxlanılır — "⬇ ADOC" ilə istənilən vaxt, istənilən kompüterdən yükləmək olar.
     Faylı olmayan məktubda "⤓ Al" düyməsi var (həmin şirkətin kabineti açıq olmalıdır).
   • e-taxes məktubları artıq kabinetin rəsmi "Daxil olanlar" siyahısından oxunur (son 2 il); yeni kimi yalnız
     bu ilin məktubları təklif olunur.

V31.1.0 — ŞƏXSİ HESAB VƏRƏQƏSİ: ANALİZ
   • Menyuda "Şəxsi hesab vərəqəsi" — üzərinə gələndə sağda iki panel açılır: "Şəxsi hesab → Borc" (köhnə
     panel) və yeni "Şəxsi hesab → Analiz".
   • Analiz: vərəqə "e-taxes-dən yüklə" ilə birbaşa açıq kabinetdən (əməliyyat tarixçəsi + faiz tarixçəsi +
     kabinetin rəsmi qalıqları) və ya fayl ilə (.xls/.html) yüklənir. Yalnız bu kompüterdə oxunur.
   • İcmal: cəmi borc, əsas borc, faiz, gündəlik faiz artımı, ən vacib 3 addım, vergi növləri üzrə borc,
     borcun dinamikası, "pul hara gedib" (ödəniş tapşırığındakı vergi ↔ əslində bağladığı borc).
   • Uyğunsuzluqlar: ödənişin başqa (köhnə) borca yazılması, vaxtı keçmiş dövrlər, faiz yükü, artıq ödəmə
     + borc (əvəzləşdirmə), gec yazılmış hesablamalar, çox dəfə dəqiqləşdirilmiş dövrlər, təkrar ödəniş,
     tanınmayan əməliyyatlar, kabinetin rəsmi qalığı ilə fərq. Hər birində səbəb, məbləğ, "nə etməli",
     ərizə mətni; qərar (Açıq / Baxılır / Ərizə verildi / Həll edildi) və qeyd bütün kompüterlərdə görünür.
   • Vergi növləri və dövrlər: hər vergi ay/rüb/il üzrə — hesablanıb, azaldılıb, yekun, ödəmə tarixi, açıq
     qalıq, gecikmə günü; dövrə basanda bütün bəyannamələr və borcu hansı ödənişin bağladığı açılır.
     Bölgü kabinetin qaydası ilədir (ödəniş ödəmə tarixi ən köhnə borcu bağlayır) — rəsmi qalıqlarla yoxlanılıb.
   • Əməliyyatlar: filtr, axtarış, məbləğsiz texniki sətirləri gizlətmə, hər sətrin izahı.
   • Sual ver: "ƏDV borcu hansı aylardandır?", "Faiz niyə bu qədərdir?", "Son ödənişlər hara gedib?" kimi
     suallara vərəqənin öz rəqəmləri ilə cavab verən köməkçi (oflayn).
   • Excel: icmal, uyğunsuzluqlar, növlər, dövrlər, bütün əməliyyatlar izahı ilə.
