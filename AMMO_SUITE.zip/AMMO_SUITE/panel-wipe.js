/* AMMO SUITE V31.2 — Panelin məlumatını TAM silmək (yalnız admin).
   Admin «Panelləri idarə et» → panel → «⚙ İdarə et» → «🗑 Hamısını sil» (2 dəfə təsdiq).
   Nə edir:
     1) Buludda (Firebase · Konsalting) həmin panelin bütün açarları boşaldılır (silinmiş nişanı qalır —
        köhnə versiyada olan kompüterlər də öz yerli surətini silsin və geri yükləməsin).
        Paneldən asılı olaraq ayrıca kolleksiyalar da silinir (TaskPanel: tapşırıqlar və faylları,
        Bəyannamə nəzarət / Vergi məktubları: qeydlər).
     2) suiteSharedV3/_wipes sənədinə «silmə nişanı» yazılır. Hər kompüterdəki AMMO SUITE bu nişanı görən kimi
        həmin panelin bu kompüterdəki məlumatını da silir (chrome.storage, localStorage, IndexedDB).
   Bu fayl modul səhifəsində cloud-sync.js-dən ƏVVƏL yüklənməlidir (orijinal yaddaş funksiyaları lazımdır). */
(() => {
  'use strict';
  if (window.AmmoWipe) return;
  const PROJECT = 'konsalting-79c40', API_KEY = 'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg';
  const ROOT = `https://firestore.googleapis.com/v1/projects/${PROJECT}/databases/(default)/documents`;
  const MARK = `${ROOT}/suiteSharedV3/_wipes`;
  const SEEN_KEY = 'ammo_cloud_wipeSeen';
  const ADMIN_EMAILS = ['memmed@ammo.az'];

  // orijinal funksiyalar (cloud-sync.js bürüməmişdən əvvəl) — yerli silmə buluda «dəyişiklik» kimi getməsin
  const cs = chrome.storage.local;
  const oGet = cs.get.bind(cs), oSet = cs.set.bind(cs), oRemove = cs.remove.bind(cs);
  const lsRemove = (k) => { try { Storage.prototype.removeItem.call(localStorage, k); } catch (e) { /* */ } };

  /* Panel → məlumat xəritəsi.
     ns: suiteSharedV3/<ns>/keys (cloud-sync), chrome/ls: dəqiq açarlar, *Prefix: açar başlanğıcı,
     idb: IndexedDB bazaları, tomb: qeydləri «silinmiş» edilən kolleksiyalar (köçürmə geri qaytarmasın),
     del: tam silinən kolleksiyalar, rev: dəyişiklik nişanları */
  const SPEC = {
    taskpanel: { ns: ['taskpanel'], chromePrefix: ['taskFiles_'], del: [{ c: 'tasks' }, { c: 'taskFileManifests' }, { c: 'taskFileChunks', mask: ['taskId'], keep: (f) => String(f.taskId?.stringValue || '').startsWith('letter:') }], rev: ['taskpanel'], what: 'bütün tapşırıqlar, onların faylları və hesabatları' },
    emekhaqqi: { ns: ['emekhaqqi'], ls: ['eh_state_v2', 'eh_monthly_archives_v2', 'ammo_calendar_fix_v257'], what: 'şirkətlər, işçilər, hesablamalar, aylıq arxiv' },
    kurs: { ns: ['kurs'], chromePrefix: ['kurs_'], ls: ['kurs_last_panel'], what: 'kurslar, müəllimlər, tələbələr, ödənişlər, imtahanlar, şəkillər' },
    sexsiHesab: { ns: ['sexsi-hesab'], ls: ['ammo_sexsi_hesab_v1', 'ammo_sexsi_requisites_v1'], what: 'seçimlər, uyğunlaşdırmalar, rekvizitlər' },
    sexsiHesabAnaliz: { ns: ['sexsi-hesab-analiz'], chrome: ['ammo_shv_cache_v1', 'ammo_shv_decisions_v1'], what: 'analiz keşi və qərarlar' },
    surucu: { ns: ['surucu-gelir'], chrome: ['archive', 'archive2', 'drivers', 'drivers2', 'sgDrivers', 'sgPayments', 'sgSettings', 'sgDirector', 'sgMeta', 'sgDraft'], chromePrefix: ['sgArchive_'], what: 'sürücülər, ödənişlər, aylıq arxiv, ayarlar' },
    beyannameUcotu: { ns: ['vergi-mektublari'], chrome: ['beyannameUcotuLocalCache'], tomb: [{ c: 'beyannameUcotu', upd: 'int' }], del: [{ c: 'taskFileChunks', mask: ['taskId'], keep: (f) => !String(f.taskId?.stringValue || '').startsWith('letter:') }], rev: ['beyannameUcotu'], what: 'bütün vergi məktubları və əlavə faylları' },
    beyannameNezaret: { ns: ['beyanname-nezaret'], ls: ['ammo_beyanname_nezaret_fixed_local', 'ammo_bn_etax_map_v1', 'ammo_bn_etax_seen_v1'], tomb: [{ c: 'beyannameNezaret', upd: 'str' }], rev: ['beyannameNezaret'], what: 'bütün bəyannamə nəzarət qeydləri və e-taxes status xəritəsi' },
    menfeet: { ns: ['menfeet'], chrome: ['menfeetHtmlFull'], ls: ['menfeetHtmlFull'], what: 'doldurulmuş bəyannamə məlumatları' },
    links: { ns: ['links'], what: 'əlavə edilmiş linklər (əsas siyahı qalır)' },
    hesabatVaxti: { ns: ['hesabat-vaxti'], chrome: ['reports', 'emails', 'phones', 'settings', 'periodStatusMap', 'dataVersion', 'initialized', 'basePeriodStart', 'notificationLog'], what: 'hesabatlar, statuslar, e-poçt/telefon siyahıları, bildiriş tarixçəsi' },
    borcXatirlatici: { ns: ['borc-xatirlatici'], chrome: ['records', 'borcSettings', 'notified', 'borcWaState', 'borcWaLog'], what: 'borc qeydləri, ayarlar, WhatsApp göndəriş tarixçəsi' },
    malHereketi: { ns: ['mal-hereketi-pro'], idb: ['mal_harakati_pro'], what: 'yüklənmiş fayllar və mal hərəkəti məlumatı' },
  };
  // Əlavə (admin tərəfindən yaradılmış) modullar: məlumat qovluq adı ilə saxlanılır
  function specOf(mod) {
    const id = typeof mod === 'string' ? mod : mod?.id;
    if (SPEC[id]) return SPEC[id];
    const m = /modules\/([^/]+)\//.exec(String(mod?.url || ''));
    return { ns: [m ? m[1].replace(/[^a-zA-Z0-9_-]/g, '_') : String(id || '').replace(/[^a-zA-Z0-9_-]/g, '_')], what: 'panelin buludda saxlanan bütün məlumatı' };
  }

  // ------------------------------------------------------------------ köməkçilər
  const enc = (v) => {
    if (v === null || v === undefined) return { nullValue: null };
    if (Array.isArray(v)) return { arrayValue: { values: v.map(enc) } };
    if (typeof v === 'boolean') return { booleanValue: v };
    if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
    if (typeof v === 'object') return { mapValue: { fields: Object.fromEntries(Object.entries(v).map(([k, x]) => [k, enc(x)])) } };
    return { stringValue: String(v) };
  };
  const dec = (v) => {
    if (!v) return null;
    if ('stringValue' in v) return v.stringValue; if ('integerValue' in v) return Number(v.integerValue); if ('doubleValue' in v) return v.doubleValue;
    if ('booleanValue' in v) return v.booleanValue; if ('timestampValue' in v) return v.timestampValue; if ('nullValue' in v) return null;
    if ('arrayValue' in v) return (v.arrayValue.values || []).map(dec);
    if ('mapValue' in v) return Object.fromEntries(Object.entries(v.mapValue.fields || {}).map(([k, x]) => [k, dec(x)]));
    return null;
  };
  const decFields = (f) => Object.fromEntries(Object.entries(f || {}).map(([k, x]) => [k, dec(x)]));
  const withTimeout = (p, ms, fallback) => Promise.race([p, new Promise((r) => setTimeout(() => r(fallback), ms))]);

  async function auth(force) {
    let { suiteAuth: a } = await oGet('suiteAuth');
    if (!a?.idToken) return null;
    if (a.refreshToken && (force || Date.now() > Number(a.expiresAt || 0) - 120000)) {
      try {
        const r = await fetch(`https://securetoken.googleapis.com/v1/token?key=${API_KEY}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: a.refreshToken }) });
        const d = await r.json();
        if (r.ok) { a = { ...a, idToken: d.id_token, refreshToken: d.refresh_token || a.refreshToken, uid: d.user_id || a.uid, expiresAt: Date.now() + Number(d.expires_in || 3600) * 1000 }; await oSet({ suiteAuth: a }); }
      } catch (e) { /* oflayn */ }
    }
    return a;
  }
  async function req(url, opt = {}, retried) {
    const a = await auth(retried); if (!a?.idToken) { const e = new Error('Giriş yoxdur'); e.status = 401; throw e; }
    const r = await fetch(url, { ...opt, cache: 'no-store', headers: { Authorization: 'Bearer ' + a.idToken, 'Content-Type': 'application/json', ...(opt.headers || {}) } });
    if (r.status === 401 && !retried) return req(url, opt, true);
    if (r.status === 404) return null;
    const t = await r.text(); let j = {}; try { j = t ? JSON.parse(t) : {}; } catch (e) { /* */ }
    if (!r.ok) { const e = new Error(j?.error?.message || ('Firebase HTTP ' + r.status)); e.status = r.status; throw e; }
    return j;
  }
  async function listAll(url, mask) {
    const out = []; let tok = '';
    const mq = mask ? '&' + mask.map((f) => 'mask.fieldPaths=' + encodeURIComponent(f)).join('&') : '';
    do {
      const j = await req(`${url}?pageSize=300${mq}${tok ? '&pageToken=' + encodeURIComponent(tok) : ''}`);
      if (!j) break; (j.documents || []).forEach((d) => out.push(d)); tok = j.nextPageToken || '';
    } while (tok);
    return out;
  }
  async function pool(items, n, fn, onStep) {
    let i = 0, done = 0; const errs = [];
    await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
      while (i < items.length) { const it = items[i++]; try { await fn(it); } catch (e) { errs.push(e); } done++; onStep && onStep(done, items.length); }
    }));
    return errs;
  }
  async function bump(name) {
    try { await req(`${ROOT}/suiteSharedV3/_rev_${String(name).replace(/[^A-Za-z0-9_-]/g, '_')}?updateMask.fieldPaths=rev`, { method: 'PATCH', body: JSON.stringify({ fields: { rev: { integerValue: String(Date.now()) } } }) }); } catch (e) { /* */ }
  }
  const isAdminNow = async () => ADMIN_EMAILS.includes(String((await auth())?.email || '').toLowerCase());

  // ------------------------------------------------------------------ yerli (bu kompüter) silmə
  async function clearIdb(name) {
    try {
      if (indexedDB.databases) { const list = await indexedDB.databases(); if (!list.some((d) => d.name === name)) return 0; }
      const db = await new Promise((res, rej) => { const r = indexedDB.open(name); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); r.onblocked = () => rej(new Error('blocked')); });
      const stores = [...db.objectStoreNames]; let n = 0;
      if (stores.length) await new Promise((res, rej) => { const tx = db.transaction(stores, 'readwrite'); stores.forEach((s) => tx.objectStore(s).clear()); tx.oncomplete = res; tx.onerror = () => rej(tx.error); n = stores.length; });
      db.close(); return n;
    } catch (e) { return 0; }
  }
  /** Bu kompüterdəki məlumatı silir. keys: buludda olan «scope:key» siyahısı (nişandan) */
  async function wipeLocal(id, keys) {
    const sp = SPEC[id] || { ns: [] };
    const all = await oGet(null);
    const chromeDel = new Set(sp.chrome || []);
    Object.keys(all).forEach((k) => { if ((sp.chromePrefix || []).some((p) => k.startsWith(p))) chromeDel.add(k); });
    const lsDel = new Set(sp.ls || []);
    for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && (sp.lsPrefix || []).some((p) => k.startsWith(p))) lsDel.add(k); }
    (keys || []).forEach((sk) => { const i = String(sk).indexOf(':'); if (i < 0) return; const s = sk.slice(0, i), k = sk.slice(i + 1); if (/^(suiteAuth|ammoLastEmail|ammoDeviceId|ammo_cloud_)/.test(k)) return; (s === 'chrome' ? chromeDel : lsDel).add(k); });
    const cDel = [...chromeDel].filter((k) => k in all);
    if (cDel.length) await oRemove(cDel);
    let ls = 0; lsDel.forEach((k) => { if (localStorage.getItem(k) !== null) { lsRemove(k); ls++; } });
    let idb = 0; for (const n of sp.idb || []) idb += await clearIdb(n);
    return { chrome: cDel.length, local: ls, idb };
  }

  /** Buludda silmə nişanlarını yoxlayır, bu kompüterdə hələ tətbiq olunmayanları tətbiq edir. Tətbiq olunan panel id-lərini qaytarır. */
  let checking = null;
  function check() {
    if (checking) return checking;
    checking = (async () => {
      const a = await auth(); if (!a?.idToken) return [];
      const doc = await req(MARK).catch(() => null); if (!doc?.fields) return [];
      const marks = decFields(doc.fields);
      const seen = (await oGet(SEEN_KEY))[SEEN_KEY] || {};
      const applied = [];
      for (const [id, m] of Object.entries(marks)) {
        const at = Number(m?.at || 0); if (!at || at <= Number(seen[id] || 0)) continue;
        try { await wipeLocal(id, Array.isArray(m.keys) ? m.keys : []); } catch (e) { console.warn('AMMO wipe local', id, e); }
        seen[id] = at; applied.push(id);
      }
      if (applied.length) await oSet({ [SEEN_KEY]: seen });
      return applied;
    })().catch((e) => { console.warn('AMMO wipe check', e); return []; }).finally(() => { setTimeout(() => { checking = null; }, 0); });
    return checking;
  }

  // ------------------------------------------------------------------ statistika və ehtiyat surəti (admin)
  async function stats(mod) {
    const sp = specOf(mod); const out = { keys: 0, records: 0, files: 0, lastWipe: null };
    for (const ns of sp.ns) { const d = await listAll(`${ROOT}/suiteSharedV3/${ns}/keys`, ['deleted']); out.keys += d.filter((x) => x.fields?.deleted?.booleanValue !== true).length; }
    for (const t of sp.tomb || []) { const d = await listAll(`${ROOT}/${t.c}`, ['deleted']); out.records += d.filter((x) => x.fields?.deleted?.booleanValue !== true).length; }
    for (const t of sp.del || []) { const d = await listAll(`${ROOT}/${t.c}`, t.mask || ['__name__']); const n = d.filter((x) => !(t.keep && t.keep(x.fields || {}))).length; if (t.c === 'taskFileChunks') out.files += n; else out.records += n; }
    try { const m = await req(MARK); const v = m?.fields?.[typeof mod === 'string' ? mod : mod.id]; if (v) out.lastWipe = dec(v); } catch (e) { /* */ }
    return out;
  }
  async function backup(mod) {
    const sp = specOf(mod), id = typeof mod === 'string' ? mod : mod.id;
    const data = { app: 'AMMO SUITE', panel: id, title: mod?.title || id, at: new Date().toISOString(), cloud: {}, collections: {}, local: { chrome: {}, localStorage: {} } };
    for (const ns of sp.ns) {
      const docs = await listAll(`${ROOT}/suiteSharedV3/${ns}/keys`);
      data.cloud[ns] = docs.map((d) => decFields(d.fields)).filter((x) => x.deleted !== true).map((x) => ({ scope: x.scope, key: x.key, value: x.value, updatedAt: x.updatedAt, updatedBy: x.updatedBy }));
    }
    for (const t of [...(sp.tomb || []), ...(sp.del || [])]) {
      if (t.c === 'taskFileChunks') { data.collections[t.c] = '(fayl hissələri ehtiyat surətinə daxil edilmir)'; continue; }
      const docs = await listAll(`${ROOT}/${t.c}`);
      data.collections[t.c] = docs.map((d) => ({ id: d.name.split('/').pop(), ...decFields(d.fields) })).filter((x) => x.deleted !== true);
    }
    const all = await oGet(null);
    Object.keys(all).forEach((k) => { if ((sp.chrome || []).includes(k) || (sp.chromePrefix || []).some((p) => k.startsWith(p))) data.local.chrome[k] = all[k]; });
    (sp.ls || []).forEach((k) => { const v = localStorage.getItem(k); if (v !== null) data.local.localStorage[k] = v; });
    const blob = new Blob([JSON.stringify(data, null, 1)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `AMMO_${id}_ehtiyat_${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.json`;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
    return data;
  }

  // ------------------------------------------------------------------ TAM SİLMƏ (admin)
  async function wipePanel(mod, { doBackup = true, onProgress = () => {} } = {}) {
    if (!(await isAdminNow())) throw new Error('Yalnız admin silə bilər');
    const id = typeof mod === 'string' ? mod : mod.id, sp = specOf(mod);
    const a = await auth(); const by = a.email || a.uid || '';
    const res = { keys: 0, records: 0, deleted: 0, local: null, errors: 0 };
    if (doBackup) { onProgress('Ehtiyat surəti hazırlanır…'); await backup(mod); }
    const keyList = [];
    // 1) cloud-sync açarları → silinmiş nişanı (dəyər boşaldılır)
    for (const ns of sp.ns) {
      onProgress(`Bulud oxunur (${ns})…`);
      const docs = await listAll(`${ROOT}/suiteSharedV3/${ns}/keys`);
      const now = new Date().toISOString();
      const errs = await pool(docs, 8, async (d) => {
        const f = d.fields || {}; const scope = dec(f.scope) || 'local', key = dec(f.key) || '';
        if (key) keyList.push(`${scope}:${key}`);
        const body = { fields: { module: { stringValue: ns }, scope: { stringValue: scope }, key: { stringValue: key }, deleted: { booleanValue: true }, updatedAt: { timestampValue: now }, updatedBy: { stringValue: by }, wiped: { booleanValue: true }, value: { nullValue: null } } };
        await req(`https://firestore.googleapis.com/v1/${d.name}`, { method: 'PATCH', body: JSON.stringify(body) });
      }, (n, t) => onProgress(`Buludda silinir: ${n} / ${t}`));
      res.keys += docs.length; res.errors += errs.length;
      try { await req(`${ROOT}/suiteSharedV2/${ns}`, { method: 'DELETE' }); } catch (e) { /* köhnə sənəd yoxdur */ }
    }
    // 2) qeyd kolleksiyaları → silinmiş (köhnə layihədən köçürmə geri qaytarmasın)
    for (const t of sp.tomb || []) {
      onProgress(`${t.c} oxunur…`);
      const docs = (await listAll(`${ROOT}/${t.c}`, ['deleted'])).filter((d) => d.fields?.deleted?.booleanValue !== true);
      const errs = await pool(docs, 8, async (d) => {
        const now = Date.now();
        const body = { fields: { deleted: { booleanValue: true }, updatedAt: t.upd === 'str' ? { stringValue: String(now) } : { integerValue: String(now) }, wipedAt: { integerValue: String(now) }, wipedBy: { stringValue: by } } };
        await req(`https://firestore.googleapis.com/v1/${d.name}`, { method: 'PATCH', body: JSON.stringify(body) });
      }, (n, tt) => onProgress(`Qeydlər silinir: ${n} / ${tt}`));
      res.records += docs.length; res.errors += errs.length;
    }
    // 3) tam silinən kolleksiyalar
    for (const t of sp.del || []) {
      onProgress(`${t.c} oxunur…`);
      const docs = (await listAll(`${ROOT}/${t.c}`, t.mask || ['__name__'])).filter((d) => !(t.keep && t.keep(d.fields || {})));
      const errs = await pool(docs, 8, (d) => req(`https://firestore.googleapis.com/v1/${d.name}`, { method: 'DELETE' }), (n, tt) => onProgress(`${t.c === 'taskFileChunks' ? 'Fayllar' : 'Qeydlər'} silinir: ${n} / ${tt}`));
      res.deleted += docs.length; res.errors += errs.length;
    }
    // 4) bütün kompüterlər üçün silmə nişanı
    onProgress('Bütün kompüterlərə bildirilir…');
    const at = Date.now();
    await req(`${MARK}?updateMask.fieldPaths=${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ fields: { [id]: enc({ at, by, title: mod?.title || id, keys: keyList.slice(0, 3000) }) } }) });
    await Promise.all([bump('wipes'), ...sp.ns.map((ns) => bump('mod_' + ns)), ...(sp.rev || []).map(bump)]);
    // 5) bu kompüter — dərhal
    onProgress('Bu kompüterdə silinir…');
    res.local = await wipeLocal(id, keyList);
    const seen = (await oGet(SEEN_KEY))[SEEN_KEY] || {}; seen[id] = at; await oSet({ [SEEN_KEY]: seen });
    return res;
  }

  window.AmmoWipe = { SPEC, specOf, check, wipeLocal, wipePanel, stats, backup };
  // Modul səhifəsi: bulud sinxronu başlamazdan əvvəl silmə nişanları tətbiq olunur (ən çox 6 saniyə gözlənilir)
  window.AmmoWipeReady = withTimeout(check(), 6000, []).then((applied) => {
    const inModule = /\/modules\//.test(location.pathname);
    if (inModule && applied.length) {
      const g = 'ammo_wipe_reload', last = Number(sessionStorage.getItem(g) || 0);
      if (Date.now() - last > 15000) { sessionStorage.setItem(g, String(Date.now())); location.reload(); return new Promise(() => {}); }
    }
    return applied;
  }).catch(() => []);
  // Açıq qalan səhifələr: admin silən kimi (ən çox ~1 dəqiqə) məlumat bu kompüterdən də silinir və səhifə yenilənir
  try {
    if (window.AMMO_REV) window.AMMO_REV.watch('wipes', { every: 60000, fallback: 1800000 }, async () => {
      const ap = await check(); if (!ap.length) return;
      window.dispatchEvent(new CustomEvent('ammo-wiped', { detail: ap }));
      if (/\/modules\//.test(location.pathname)) location.reload();
    });
  } catch (e) { /* */ }
})();
