AMMO SUITE V31.2 — PANELİN İDARƏETMƏ MODULU və «HAMISINI SİL»
==============================================================

Yalnız admin (memmed@ammo.az) görür və istifadə edə bilər.

HARADA
  Sağ yuxarıda istifadəçi menyusu → «Panelləri idarə et» → istənilən panelin sətrində «⚙ İdarə et».

İDARƏETMƏ PƏNCƏRƏSİNDƏ
  • Vəziyyət, kimlər görür, buludda neçə açar / qeyd var, son tam silmə tarixi.
  • 📥 Ehtiyat surəti — panelin bütün məlumatı JSON faylı kimi kompüterə yüklənir (heç nə silinmir).
  • 🗑 Hamısını sil — 2 dəfə soruşur:
        1) «… hamısı silinsin?»            → Xeyr / Bəli
        2) «Son təsdiq — əminsiniz?»       → Xeyr / Bəli, tam sil
           (burada «Silməzdən əvvəl ehtiyat surətini yüklə» işarəsi standart olaraq qoyulub)
    «Bəli, tam sil» basılanda həmin panelin işlənmiş məlumatı:
        – Firebase-dən (Konsalting) silinir;
        – bu kompüterdən dərhal, digər bütün kompüterlərdən ~1 dəqiqə ərzində silinir
          (kompüter sönülüdürsə — növbəti açılışda).
    Panelin özü menyuda qalır və boş açılır. Geri qaytarmaq yalnız ehtiyat surəti faylından mümkündür.

HƏR PANELDƏ NƏ SİLİNİR
  TaskPanel ............ bütün tapşırıqlar, faylları və manifestləri (işçi və şirkət siyahısı QALIR)
  Əməkhaqqı ............ şirkətlər, işçilər, hesablamalar, aylıq arxiv
  Kurs İdarəetmə ....... kurslar, müəllimlər, tələbələr, ödənişlər, imtahanlar, şəkillər
  Şəxsi hesab → Borc ... seçimlər, uyğunlaşdırmalar, rekvizitlər
  Şəxsi hesab → Analiz . analiz keşi və qərarlar
  Sürücü gəliri ........ sürücülər, ödənişlər, aylıq arxiv, ayarlar
  Vergi məktubları ..... bütün məktublar və əlavə faylları
  Bəyannamə nəzarət .... bütün qeydlər və e-taxes status xəritəsi
  Mənfəət .............. doldurulmuş bəyannamə məlumatı
  Linklər .............. əlavə edilmiş linklər (əsas siyahı qalır)
  Hesabat Vaxtı ........ hesabatlar, statuslar, e-poçt/telefon siyahıları, bildiriş tarixçəsi
  Borc Xatırladıcı ..... borc qeydləri, ayarlar, WhatsApp göndəriş tarixçəsi
  Mal Hərəkəti PRO ..... yüklənmiş fayllar və hesablamalar
  Admin əlavə etdiyi modullar — buludda saxlanan bütün məlumatı

TEXNİKİ
  • Yeni fayl: panel-wipe.js (suite.html və bütün modul səhifələrində cloud-sync.js-dən əvvəl yüklənir).
  • Silmə nişanı: Firestore → suiteSharedV3/_wipes (sahə = panel kodu: at, by, keys).
  • Buluddakı açarlar «deleted: true» edilir və dəyəri boşaldılır — köhnə versiyada qalan kompüterlər də
    öz surətini silir və məlumatı geri yükləmir. Bəyannamə nəzarət / Vergi məktubları qeydləri də «silinmiş»
    edilir ki, köhnə layihədən (gomruk-nezaret) köçürmə onları geri qaytarmasın.
  • Firestore qaydalarını dəyişmək lazım deyil.
