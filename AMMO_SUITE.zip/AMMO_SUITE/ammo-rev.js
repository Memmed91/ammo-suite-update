/* AMMO SUITE V31.0.2 — Firebase oxumalarına qənaət ("dəyişiklik nişanı").
   Əvvəl panellər hər 3–5 saniyədə BÜTÜN məlumatı yenidən oxuyurdu və Firebase-in gündəlik pulsuz
   oxuma limiti (50 000) bitirdi. İndi hər bölmənin bir kiçik "nişan" sənədi var
   (suiteSharedV3/_rev_<ad>). Kim nəsə yazırsa nişanı yeniləyir; digər kompüterlər yalnız bu 1 sənədi
   yoxlayır və dəyişiklik olanda tam məlumatı oxuyur. Panel görünmürsə yoxlama dayanır.
   Köhnə versiyalarda yazılanlar üçün 10 dəqiqədən bir tam yoxlama da qalır. */
(() => {
  'use strict';
  if (window.AMMO_REV) return;
  const PROJECT = 'konsalting-79c40', KEY = 'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg';
  const BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT}/databases/(default)/documents/suiteSharedV3`;
  async function token() {
    let { suiteAuth: a } = await chrome.storage.local.get('suiteAuth');
    if (!a?.idToken) return null;
    if (a.refreshToken && Date.now() > Number(a.expiresAt || 0) - 120000) {
      try {
        const r = await fetch(`https://securetoken.googleapis.com/v1/token?key=${KEY}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: a.refreshToken }) });
        const d = await r.json();
        if (r.ok) { a = { ...a, idToken: d.id_token, refreshToken: d.refresh_token || a.refreshToken, expiresAt: Date.now() + Number(d.expires_in || 3600) * 1000 }; await chrome.storage.local.set({ suiteAuth: a }); }
      } catch (e) { /* oflayn */ }
    }
    return a.idToken;
  }
  const safe = (n) => String(n).replace(/[^A-Za-z0-9_-]/g, '_');
  async function bump(name) {
    try {
      const t = await token(); if (!t) return;
      await fetch(`${BASE}/_rev_${safe(name)}?updateMask.fieldPaths=rev`, { method: 'PATCH', headers: { Authorization: 'Bearer ' + t, 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: { rev: { integerValue: String(Date.now()) } } }) });
    } catch (e) { /* növbəti yazıda */ }
  }
  async function read(name) {
    const t = await token(); if (!t) throw new Error('no_auth');
    const r = await fetch(`${BASE}/_rev_${safe(name)}`, { headers: { Authorization: 'Bearer ' + t }, cache: 'no-store' });
    if (r.status === 404) return '0';
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const d = await r.json();
    return d.fields?.rev?.integerValue || '0';
  }
  /* watch(ad, {every, fallback}, onChange) — dəyişiklik olanda onChange() çağırılır. */
  function watch(name, opts, onChange) {
    const every = opts?.every || 15000, fallback = opts?.fallback || 600000;
    let last = null, lastFull = Date.now(), busy = false;
    const tick = async () => {
      if (busy || document.visibilityState !== 'visible') return;
      busy = true;
      try {
        const rev = await read(name);
        if (last === null) last = rev;
        else if (rev !== last) { last = rev; lastFull = Date.now(); await onChange(); }
        else if (Date.now() - lastFull > fallback) { lastFull = Date.now(); await onChange(); }
      } catch (e) { /* internet / limit — növbəti dəfə */ }
      finally { busy = false; }
    };
    tick();
    const id = setInterval(tick, every);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') tick(); });
    return () => clearInterval(id);
  }
  window.AMMO_REV = { bump, read, watch };
})();
