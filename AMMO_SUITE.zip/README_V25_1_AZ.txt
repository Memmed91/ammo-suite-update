AMMO SUITE V25.1 — BƏYANNAMƏ NƏZARƏT STATUS YENİLƏNMƏSİ

Dəyişikliklər:
- “TƏSDİQLƏNMƏDİ” statusu “UYĞUNSUZLUQ YOXLAMASINDA” ilə əvəz edildi.
- “ANOLOJİ” statusu əlavə edildi (bənövşəyi).
- “ANOLOJİ TƏSDİQLƏNDİ” statusu əlavə edildi (yaşıl).
- “TƏQDİM OLUNAN” statusu əlavə edildi (açıq göy).
- Köhnə “TƏSDİQLƏNMƏDİ” qeydləri ekranda avtomatik yeni adla göstərilir.
