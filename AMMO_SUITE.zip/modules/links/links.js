const LINKS = [
  {
    "name": "BirBank Business",
    "desc": "Kapital Bank biznes kabineti",
    "url": "https://my.birbank.business/login",
    "icon": "🏦"
  },
  {
    "name": "ABB Business",
    "desc": "ABB korporativ internet bank",
    "url": "https://cb.abb-bank.az/login/az",
    "icon": "🏦"
  },
  {
    "name": "Azər-Türk Bank Business",
    "desc": "ATB korporativ giriş",
    "url": "https://business.atb.az/corporate/login",
    "icon": "🏦"
  },
  {
    "name": "Bank Respublika iOfis",
    "desc": "Bank Respublika biznes kabineti",
    "url": "https://iofis.bankrespublika.az/login",
    "icon": "🏦"
  },
  {
    "name": "Unibank Business",
    "desc": "Unibank korporativ giriş",
    "url": "https://online.unibank.az/corporate/?_gl=1*5c1veh*_ga*MTMxNjMxNTk4OS4xNzQzNTE3NzI0*_ga_N6WPPQZFVJ*czE3ODA4MjczOTMkbzE4JGcxJHQxNzgwODI3NDAzJGo1MCRsMCRoMA..",
    "icon": "🏦"
  },
  {
    "name": "E-Taxes",
    "desc": "Yeni e-taxes portalı",
    "url": "https://new.e-taxes.gov.az/eportal/login/asan",
    "icon": "🧾"
  },
  {
    "name": "E-Customs",
    "desc": "Elektron gömrük portalı",
    "url": "https://e.customs.gov.az/auth/asan",
    "icon": "🚛"
  },
  {
    "name": "MyGovID",
    "desc": "ASAN login / dövlət giriş sistemi",
    "url": "https://mygovid.gov.az/auth/with-asan-login",
    "icon": "🆔"
  },
  {
    "name": "ASAN Doc",
    "desc": "Elektron sənəd imzalama",
    "url": "https://asandoc.az/",
    "icon": "✍️"
  },
  {
    "name": "ChatGPT",
    "desc": "Süni intellekt köməkçisi",
    "url": "https://chatgpt.com/",
    "icon": "🤖"
  },
  {
    "name": "Firebase Console",
    "desc": "Gömrük Nəzarət Firebase paneli",
    "url": "https://console.firebase.google.com/project/gomruk-nezaret/authentication/providers?utm_source=chatgpt.com",
    "icon": "🔥"
  },
  {
    "name": "E-Qanun",
    "desc": "Azərbaycan qanunvericilik bazası",
    "url": "https://e-qanun.az/",
    "icon": "⚖️"
  },
  {
    "name": "iLovePDF",
    "desc": "PDF alətləri",
    "url": "https://www.ilovepdf.com/download/nAnwz0dzA8ss6sk25gzl3kn7AA3f53drv9qpzp2Apc9ry9cljm97y0jygxv8jdtkp3mfd7087zdlfwdhhbj1Ag452gjsx1px33vkgnpwpw3qk9gvy525jyg9x7vqxdbydc2hljgtz1ylqkw6n262g71b4fv2c4v1s42zgmpwz9pbqhg0jr11/12o",
    "icon": "📄"
  },
  {
    "name": "MyAccess",
    "desc": "MyAccess giriş sistemi",
    "url": "https://myaccess.az/login",
    "icon": "🔐"
  },
  {
    "name": "ASB Internet Bank",
    "desc": "ASB Bank internet bank",
    "url": "https://internet.asb.az/CustomLogin/Retail.aspx?sID=-1",
    "icon": "🏦"
  },
  {
    "name": "Bank of Baku E-Bank",
    "desc": "Bank of Baku internet bank",
    "url": "https://www.e-bankofbaku.com/InterBankNew/login?_gl=1*1gm0otb*_gcl_aw*R0NMLjE3ODA4Mjc3MDUuQ2owS0NRandyWlRSQmhEU0FSSXNBSGlkWWZjYTFfRzhfT3BmZFZyZjNhX1l1TEJ4S05HR1F6eE1YSFhoNmxpUzZVdmNPTmNVT1hJYzIxZ2FBampoRUFMd193Y0I.*_gcl_au*NjcyODU2MjkwLjE3ODA0Nzk4NjA.",
    "icon": "🏦"
  },
  {
    "name": "XalqOnline",
    "desc": "Xalq Bank online giriş",
    "url": "https://xalqonline.az/az/auth/login",
    "icon": "🏦"
  },
  {
    "name": "PASHA Bank Digital",
    "desc": "Paşa Bank biznes giriş",
    "url": "https://pashabank.digital/login#/asan-login",
    "icon": "🏦"
  },
  {
    "name": "TuranBank Online",
    "desc": "TuranBank ASAN giriş",
    "url": "https://online.turanbank.az/login/individual/asan/",
    "icon": "🏦"
  },
  {
    "name": "Yelo Business",
    "desc": "Yelo Bank biznes giriş",
    "url": "https://yelo.business/az/login",
    "icon": "🏦"
  },
  {
    "name": "Yapı Kredi Internet Bank",
    "desc": "Yapı Kredi korporativ giriş",
    "url": "https://intbank.yapikredi.com.az/WebApplication.UI/Default.aspx?CustomerType=Corporate",
    "icon": "🏦"
  }
];

const list = document.getElementById("list");
const searchInput = document.getElementById("searchInput");
const count = document.getElementById("count");

function render(items) {
  count.textContent = `${items.length} link`;
  if (!items.length) {
    list.innerHTML = `<div class="empty">Nəticə tapılmadı</div>`;
    return;
  }

  list.innerHTML = items.map((x, i) => `
    <div class="card" data-index="${i}">
      <div class="icon">${x.icon}</div>
      <div>
        <div class="title">${x.name}</div>
        <div class="desc">${x.desc}</div>
        <div class="url">${x.url}</div>
      </div>
    </div>
  `).join("");

  document.querySelectorAll(".card").forEach((card, idx) => {
    card.addEventListener("click", () => {
      chrome.tabs.create({ url: items[idx].url });
    });
  });
}

function normalize(s) {
  return String(s || "")
    .toLowerCase()
    .replaceAll("ə","e").replaceAll("ı","i").replaceAll("ö","o")
    .replaceAll("ü","u").replaceAll("ğ","g").replaceAll("ş","s").replaceAll("ç","c");
}

function filter() {
  const q = normalize(searchInput.value.trim());
  const items = LINKS.filter(x => {
    const hay = normalize(`${x.name} ${x.desc} ${x.url}`);
    return !q || hay.includes(q);
  });
  render(items);
}

searchInput.addEventListener("input", filter);
render(LINKS);
