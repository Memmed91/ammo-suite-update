V29 DÜZƏLİŞİ: Vergi borcları xanalarında fokus itkisi aradan qaldırıldı. Xanaya bir dəfə klik edib 6870 və ya 125000.50 kimi məbləği fasiləsiz yazmaq mümkündür. Dəyər Enter və ya xanadan çıxanda hesablamalara tətbiq olunur.

ƏMƏK HAQQI VƏ DSMF AVTOMATLAŞDIRMA — v7

DÜZƏLİŞ:
- İşəgötürmə müqaviləsində eyni işçinin bir neçə dəfə işə qəbul olunması ayrıca əmək dövrü kimi tanınır.
- Xitam əmrləri tarix ardıcıllığı ilə uyğun işəgötürmə müqaviləsinə bağlanır.
- Seçilən ayda ən azı bir gün əmək münasibəti olan işçi Hesablama və Tabel cədvəlində görünür.
- Seçilən aydan əvvəl çıxmış və ya həmin aydan sonra işə başlamış işçi göstərilmir.
- Xitam günü işlənmiş günə daxil edilir.
- İşçi çıxıb yenidən işə qəbul olunubsa, hər iki əmək dövrü nəzərə alınır və ad bir dəfə göstərilir.
- Excel tarixləri həm mətn, həm də rəqəmsal Excel tarix formatında oxunur.

QURAŞDIRMA:
1. ZIP-i ayrıca qovluğa çıxarın.
2. chrome://extensions açın.
3. Developer mode aktiv edin.
4. Load unpacked düyməsi ilə EMEK_HAQQI_AVTOMATLASDIRMA qovluğunu seçin.
5. Şirkət adları, İşəgötürmə müqaviləsi və Xitam fayllarını yenidən yükləyin.


V10: V7 bazası saxlanılıb. Məzuniyyət, iş stajı və avtomatik son haqq-hesab modulu əlavə edilib.

V13 DÜZƏLİŞLƏRİ
- Son 12 aylıq gəlir əl ilə deyil, seçilmiş məzuniyyət ayından əvvəlki 12 təqvim ayı üzrə müqavilə, xitam, aylıq əməkhaqqı və faktiki iş günləri əsasında avtomatik hesablanır.
- Ayın ortasında işə qəbul və ya xitam olduqda həmin ayın gəliri iş günlərinə mütənasib hesablanır.
- Ümumi səhifənin yuxarı sağ hissəsinə “Yenilə” düyməsi əlavə edilib. Cari interfeysi sıfırlayır, arxiv məlumatlarını silmir.

V25: A4 çap sənədlərində cədvəl şrifti 10 px olaraq tənzimləndi.


v27: İmza-möhür bölməsinə yüklənən JPG/PNG/JPEG/WEBP şəkilləri avtomatik şəffaf PNG-yə çevrilir, kəsilir və A4 çap sənədlərində 35 mm standart ölçüdə möhür yerinə yerləşdirilir.


V28 düzəlişi:
- Qüvvədən düşən əmək müqavilələri faylındakı əməkhaqqı, vəzifə, FİN və işə başlama tarixləri oxunur.
- Xitam verilmiş işçinin maaşı aktiv müqavilədə yoxdursa, qüvvədən düşən müqavilədən götürülür.
- Eyni işçinin köhnə və yeni müqavilə dövrləri tarixə görə uyğunlaşdırılır.


v30 YENİLİKLƏRİ
- Məzuniyyətə başlama tarixi ayrıca daxil edilir.
- Əsas və staj üzrə əlavə günlər cəmlənərək yalnız iş günləri üzrə sayılır.
- Şənbə, bazar və bayram günləri məzuniyyət müddətinə daxil edilmir.
- Məzuniyyətin bitmə tarixi avtomatik göstərilir.
- Tabeldə məzuniyyət iş günləri M kimi qeyd edilir.
- Məzuniyyət günləri faktiki iş günlərindən çıxılır və həmin günlərə əməkhaqqı hesablanmır.
- Məzuniyyət haqqı seçilmiş başlanma ayının Hesablama Ödəmə Cədvəlində göstərilir.


v31: Təqvim PDF-i PDF.js ilə lokal oxunur; PDF-dəki il və bütün 12 ayın iş günü sayları avtomatik təqvim bazasına yazılır.

v33 düzəlişləri:
- Təqvim PDF/Excel-dən götürülən aylıq iş günü norması faktiki iş gününün əsas mənbəyidir.
- İşləmədiyi gün boş və ya 0 olduqda gizli -1 çıxılmır.
- 2026 rəsmi qeyri-iş günləri istehsalat təqviminə uyğunlaşdırılıb.
- Ay seçildikdə rüb avtomatik seçilir və əl ilə zidd rüb seçiminə icazə verilmir.


V25.8 VVB DÜZƏLİŞİ:
- VVB ixracında hər ay üzrə Əsas iş yeri olan işçinin 'Azadolunan və güzəşt verilən cəmi gəlirin məbləği' xanasına 200 yazılır.
- Əlavə iş yeri olduqda həmin xana boş saxlanılır.
