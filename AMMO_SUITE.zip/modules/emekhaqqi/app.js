const AZ_MONTHS=['Yanvar','Fevral','Mart','Aprel','May','İyun','İyul','Avqust','Sentyabr','Oktyabr','Noyabr','Dekabr'];
const TAX_KEYS=[['sv','SV'],['omv','ÖMV'],['mv','MV / Gəlir-Mənfəət vergisi'],['property','Əmlak vergisi'],['land','Torpaq vergisi'],['road','Yol vergisi']];
const SOCIAL_KEYS=[['fsIncome','Fərdi sahibkar Gəlir vergisi'],['fsMedical','F/Ş tərəfindən ödənilən İcbari Tibbi Sığorta'],['empP','Pensiya Fondu (işçidən tutulan)'],['erP','Pensiya Fondu (işəgötürən tərəfindən)'],['empUn','İşsizlikdən Sığorta Haqqı (sığortaolunan tərəfindən)'],['erUn','İşsizlikdən Sığorta Haqqı (sığortaedən tərəfindən)'],['empMed','İcbari sığorta (işçidən tutulan)'],['erMed','İcbari sığorta (işəgötürən tərəfindən)']];
const state={files:{},companies:[],contracts:[],expiredContracts:[],terminations:[],employees:[],calendar:{},calendarMeta:{},outgoing:[],cash:[],debts:{},selectedCompany:'',year:new Date().getFullYear(),month:new Date().getMonth(),quarter:1,org:'legal',leaveRecords:[],managerName:'',preparedBy:'',sealPng:'',leaveDraft:{employee:'',position:'ordinary',year:new Date().getFullYear(),quarter:1,month:new Date().getMonth(),startDate:'',income:0,used:0,baseDays:21,intervals:[]}};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)], norm=s=>(s??'').toString().trim().replace(/\s+/g,' ').toLocaleUpperCase('az');
const num=v=>Number(String(v??0).replace(/\s/g,'').replace(',','.'))||0, money=v=>`${num(v).toLocaleString('az-AZ',{minimumFractionDigits:2,maximumFractionDigits:2})} ₼`;
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function toast(t){const x=$('#toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),2500)}
function parseDate(v){if(v instanceof Date)return new Date(v.getFullYear(),v.getMonth(),v.getDate());if(v===null||v===undefined||v==='')return null;if(typeof v==='number'&&Number.isFinite(v)){const d=new Date(Date.UTC(1899,11,30)+Math.round(v)*86400000);return new Date(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate())}let s=String(v).trim().split(/[ T]/)[0],m=s.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);if(m)return new Date(+m[3],+m[2]-1,+m[1]);m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);return m?new Date(+m[1],+m[2]-1,+m[3]):null}
function findHeader(rows,needles){return rows.findIndex(r=>needles.some(n=>(r||[]).some(v=>norm(v).includes(norm(n)))))}
function rowsToObjects(rows,needles=['TAM AD','VÖEN','ADI VƏ SOYADI']){let hi=findHeader(rows,needles);if(hi<0)hi=0;const h=(rows[hi]||[]).map(norm);return rows.slice(hi+1).filter(r=>r&&r.some(v=>v!==''&&v!=null)).map(r=>{const o={};h.forEach((k,i)=>{if(k)o[k]=r[i]??''});return o})}
function pick(o,...keys){for(const k of keys){const nk=norm(k),exact=Object.keys(o).find(x=>x===nk)||Object.keys(o).find(x=>x.includes(nk));if(exact&&o[exact]!==''&&o[exact]!=null)return o[exact]}return ''}
function monthIndex(v){const n=norm(v).replace('Ə','E');return AZ_MONTHS.findIndex(m=>norm(m).replace('Ə','E')===n||n.includes(norm(m).replace('Ə','E')))}
function fileToDataUrl(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(new Error('Şəkil oxunmadı'));r.readAsDataURL(file)})}
function loadImage(src){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Şəkil formatı tanınmadı'));img.src=src})}
async function normalizeSealImage(file){
 if(file.type==='application/pdf'||/\.pdf$/i.test(file.name))throw new Error('Möhür üçün JPG, PNG, JPEG və ya WEBP şəkli seçin');
 const src=await fileToDataUrl(file),img=await loadImage(src);
 const maxSide=1200,scale=Math.min(1,maxSide/Math.max(img.naturalWidth,img.naturalHeight));
 const w=Math.max(1,Math.round(img.naturalWidth*scale)),h=Math.max(1,Math.round(img.naturalHeight*scale));
 const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0,w,h);
 const im=ctx.getImageData(0,0,w,h),d=im.data;
 // Ağ və çox açıq fonu yumşaq şəkildə şəffaflaşdırır; möhürün rəngli xətləri saxlanılır.
 for(let i=0;i<d.length;i+=4){const r=d[i],g=d[i+1],b=d[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),brightness=(r+g+b)/3;
   if(brightness>248&&mx-mn<12)d[i+3]=0;
   else if(brightness>220&&mx-mn<22)d[i+3]=Math.min(d[i+3],Math.round(255*(248-brightness)/28));
 }
 ctx.putImageData(im,0,0);
 const dd=ctx.getImageData(0,0,w,h).data;let minX=w,minY=h,maxX=-1,maxY=-1;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){if(dd[(y*w+x)*4+3]>18){if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y}}
 if(maxX<minX||maxY<minY)throw new Error('Möhür təsviri aşkar edilmədi');
 const cw=maxX-minX+1,ch=maxY-minY+1,pad=Math.round(Math.max(cw,ch)*0.06),side=Math.max(cw,ch)+pad*2;
 const out=document.createElement('canvas');out.width=700;out.height=700;const oc=out.getContext('2d');oc.clearRect(0,0,700,700);
 const ratio=Math.min((700-pad*2)/cw,(700-pad*2)/ch),dw=cw*ratio,dh=ch*ratio;
 oc.drawImage(c,minX,minY,cw,ch,(700-dw)/2,(700-dh)/2,dw,dh);
 return out.toDataURL('image/png');
}
function renderSealStatus(){const st=$('#signsealStatus'),card=st?.closest('.upload-card');if(!st||!card)return;let preview=card.querySelector('.seal-preview');if(state.sealPng){st.textContent=(state.files.signseal||'Möhür')+' · PNG hazırdır';if(!preview){preview=document.createElement('img');preview.className='seal-preview';card.appendChild(preview)}preview.src=state.sealPng;preview.hidden=false}else{if(preview)preview.hidden=true}}
function parseContractObjects(rows){
 const objs=rowsToObjects(rows,['TAM AD','FİN','İŞÇİNİN AYLIQ','VƏZİFƏNİN ADI']);
 return objs.map(o=>{
  const baseStart=parseDate(pick(o,'Əsas müqavilənin başlama tarixi','İşçinin işə başlama tarixi','Müqavilənin bağlanma tarixi'));
  const effectiveStart=parseDate(pick(o,'İşçinin işə başlama tarixi','Müqavilənin bağlanma tarixi','Əsas müqavilənin başlama tarixi'));
  return {
   name:pick(o,'Tam adı','Adı və soyadı','Soyadı, adı, atasının adı'),
   fin:String(pick(o,'FİN','FIN')).trim(),
   salary:num(pick(o,'İşçinin aylıq əmək haqqı','Əmək haqqı','Maaş')),
   position:pick(o,'Vəzifənin adı','Vəzifə'),
   // Əmək münasibətinin başlanğıcı əsas müqavilənin başlanma tarixidir.
   start:baseStart,
   baseStart,
   // Dəyişiklik tarixini maaş/vəzifənin hansı tarixdən qüvvədə olduğunu seçmək üçün saxlayırıq.
   effectiveStart,
   contractEnd:parseDate(pick(o,'Müqavilənin bitmə tarixi')),
   status:pick(o,'Müqavilənin statusu'),
   validity:pick(o,'Etibarlılıq statusu')
  }
 }).filter(x=>x.name||x.fin)
}
function dedupeContractRecords(items){
 const seen=new Set(),out=[];
 for(const x of items){
  const key=[employeeKey(x),x.start?dateKeyLocal(x.start):'',x.effectiveStart?dateKeyLocal(x.effectiveStart):'',num(x.salary).toFixed(2),norm(x.position),norm(x.status)].join('|');
  if(seen.has(key))continue;seen.add(key);out.push(x)
 }
 return out
}
async function readUpload(file,type){
 state.files[type]=file.name;
 if(type==='signseal'){state.sealPng=await normalizeSealImage(file);renderAll();return}
 if(file.name.toLowerCase().endsWith('.pdf')){
   if(type!=='calendar')throw new Error('Bu bölmə üçün Excel/CSV faylı seçin');
   await parseCalendarPdf(file);
   persistStateSilent();
   renderAll();
   return;
 }
 const wb=await XLSXMini.read(file),rows=Object.values(wb)[0]||[];
 if(type==='contracts')state.contracts=parseContractObjects(rows)
 if(type==='expiredContracts')state.expiredContracts=parseContractObjects(rows)
 if(type==='terminations'){const objs=rowsToObjects(rows,['TAM AD','XİTAM TARİXİ']);state.terminations=objs.map(o=>({name:pick(o,'Tam adı','Adı və soyadı'),fin:String(pick(o,'FİN','FIN')).trim(),start:parseDate(pick(o,'İşə başlama tarixi','Əsas müqavilənin başlama tarixi')),end:parseDate(pick(o,'Xitam tarixi')),position:pick(o,'Vəzifə','Vəzifənin adı'),status:pick(o,'Əmrin statusu')})).filter(x=>(x.name||x.fin)&&x.end)}
 if(type==='companies'){
  // Şirkət siyahısında sütunların yeri dəyişsə belə ADLAR və VÖEN başlıqlarını tapırıq.
  let headerIndex=rows.findIndex(r=>(r||[]).some(v=>['ADLAR','AD','ŞİRKƏT ADI','VERGİ ÖDƏYİCİSİ','VERGİ ÖDƏYİCİSİNİN ADI'].includes(norm(v)))&&(r||[]).some(v=>norm(v).includes('VÖEN')||norm(v)==='VOEN'));
  if(headerIndex<0)headerIndex=findHeader(rows,['ADLAR','VÖEN','ŞİRKƏT ADI','VERGİ ÖDƏYİCİSİ']);
  const headers=(rows[headerIndex]||[]).map(norm);
  const nameCol=headers.findIndex(h=>['ADLAR','AD','ŞİRKƏT ADI','VERGİ ÖDƏYİCİSİ','VERGİ ÖDƏYİCİSİNİN ADI','MÜƏSSİSƏNİN ADI','HÜQUQİ ŞƏXSİN ADI','FƏRDİ SAHİBKAR','TAM ADI','ADI VƏ SOYADI'].includes(h)||h.includes('ADLAR'));
  const voenCol=headers.findIndex(h=>h.includes('VÖEN')||h==='VOEN'||h.includes('EYNİLƏŞDİRMƏ NÖMRƏSİ'));
  let list=[];
  if(headerIndex>=0&&nameCol>=0&&voenCol>=0){
    list=rows.slice(headerIndex+1).map(r=>({name:String(r?.[nameCol]??'').trim(),voen:String(r?.[voenCol]??'').replace(/\D/g,'')})).filter(x=>x.name&&/^\d{10}$/.test(x.voen));
  }
  if(!list.length){
    const objs=rowsToObjects(rows,['ADLAR','VÖEN','ŞİRKƏT ADI','VERGİ ÖDƏYİCİSİ']);
    list=objs.map(o=>({name:pick(o,'Adlar','Şirkət adı','Vergi ödəyicisinin adı','Vergi ödəyicisi','Müəssisənin adı','Hüquqi şəxsin adı','Fərdi sahibkar','Tam adı','Adı və soyadı','Adı','Ad'),voen:String(pick(o,'VÖEN','VOEN','Vergi ödəyicisinin eyniləşdirmə nömrəsi')).replace(/\D/g,'')})).filter(x=>x.name&&/^\d{10}$/.test(x.voen));
  }
  if(!list.length){
    for(const r of rows){
      const vi=(r||[]).findIndex(v=>/^\d{10}$/.test(String(v??'').replace(/\D/g,'')));
      if(vi>=0){const voen=String(r[vi]).replace(/\D/g,''), candidates=[r[vi-1],r[vi+1],r[0],r[1]].map(v=>String(v??'').trim()).filter(v=>v&&!/^\d{10}$/.test(v.replace(/\D/g,''))&&!['ADLAR','VÖEN','VOEN'].includes(norm(v)));if(candidates[0])list.push({name:candidates[0],voen});}
    }
  }
  const seen=new Set(); state.companies=list.filter(x=>{const k=x.voen+'|'+norm(x.name);if(seen.has(k))return false;seen.add(k);return true}); state.selectedCompany='';
}
 if(type==='calendar'||type==='tabel')parseCalendarTable(rows);
 if(type==='outgoing')parseOutgoing(rows);
 if(type==='cash')parseCash(rows);
 rebuildEmployees();
}
function parseOutgoing(rows){const hi=findHeader(rows,['QAİMƏ TARİXİ']);if(hi<0){state.outgoing=[];return}const headers=(rows[hi]||[]).map(norm),dateCol=headers.findIndex(x=>x.includes('QAİMƏ TARİXİ')),amountCol=headers.findIndex(x=>x.includes('ƏDV-SİZ ÜMUMİ DƏYƏRİ'));state.outgoing=rows.slice(hi+1).map(r=>({date:parseDate(r?.[dateCol]),amount:num(r?.[amountCol])})).filter(x=>x.date&&x.amount>=0)}
function parseCash(rows){state.cash=[];const hi=findHeader(rows,['İL','AY','MƏBLƏĞ']);if(hi>=0&&hi<3){const h=(rows[hi]||[]).map(norm),yc=h.findIndex(x=>x==='İL'),mc=h.findIndex(x=>x==='AY'),ac=h.findIndex(x=>x.includes('MƏBLƏĞ')||x.includes('SATIŞ'));for(const r of rows.slice(hi+1)){const y=+r?.[yc],m=monthIndex(r?.[mc]),a=num(r?.[ac]);if(y&&m>=0)state.cash.push({year:y,month:m,amount:a})}}else{for(const r of rows){const y=+r?.[0],m=monthIndex(r?.[1]),a=num(r?.[2]);if(y&&m>=0)state.cash.push({year:y,month:m,amount:a})}}}

async function parseCalendarPdf(file){
 const pdfjs=await import(chrome.runtime.getURL('pdfjs/pdf.min.mjs'));
 pdfjs.GlobalWorkerOptions.workerSrc=chrome.runtime.getURL('pdfjs/pdf.worker.min.mjs');
 const bytes=new Uint8Array(await file.arrayBuffer());
 const doc=await pdfjs.getDocument({data:bytes}).promise;
 const items=[];
 for(let pageNo=1;pageNo<=doc.numPages;pageNo++){
   const page=await doc.getPage(pageNo),tc=await page.getTextContent();
   for(const it of tc.items){
     const text=String(it.str||'').trim();
     if(text)items.push({text,x:Number(it.transform?.[4]||0),y:Number(it.transform?.[5]||0),page:pageNo});
   }
 }
 const allText=items.map(x=>x.text).join(' '),ym=allText.match(/20\d{2}/);
 if(!ym)throw new Error('Təqvim faylında il müəyyən edilmədi');
 const year=Number(ym[0]),monthHeads=[];
 for(const it of items){
   const mi=AZ_MONTHS.findIndex(m=>norm(m)===norm(it.text));
   if(mi>=0)monthHeads.push({...it,month:mi});
 }
 const unique=[];
 for(const h of monthHeads.sort((a,b)=>b.y-a.y||a.x-b.x))if(!unique.some(x=>x.month===h.month))unique.push(h);
 if(unique.length<12)throw new Error(`Təqvimdə yalnız ${unique.length} ay başlığı tanındı; standart istehsalat təqvimi PDF-i seçin`);
 const rows=[];
 for(const h of unique){let row=rows.find(r=>Math.abs(r.y-h.y)<4);if(!row){row={y:h.y,heads:[]};rows.push(row)}row.heads.push(h)}
 rows.sort((a,b)=>b.y-a.y);rows.forEach(r=>r.heads.sort((a,b)=>a.x-b.x));
 const counts=Array(12).fill(0);
 // Hər ay blokunun aşağısındakı xülasə sətrini tapırıq. Xülasədə sıra belədir:
 // [iş günləri] [bayram/istirahət] [40 saat] [36 saat] [24 saat].
 // Əvvəlki üsul dar X sahəsində təsadüfi təqvim tarixini (məsələn, 21) seçə bilirdi.
 for(let ri=0;ri<rows.length;ri++){
   const row=rows[ri],nextY=ri+1<rows.length?rows[ri+1].y:190;
   for(let hi=0;hi<row.heads.length;hi++){
     const h=row.heads[hi],nextX=hi+1<row.heads.length?row.heads[hi+1].x:h.x+125;
     const block=items.filter(it=>it.page===h.page&&it.y<row.y-18&&it.y>nextY+4&&it.x>=h.x-8&&it.x<nextX-6&&/^\d+(?:[.,]\d+)?$/.test(it.text));
     const lines=[];
     for(const it of block){
       let line=lines.find(x=>Math.abs(x.y-it.y)<2.5);
       if(!line){line={y:it.y,items:[]};lines.push(line)}
       line.items.push(it);
     }
     // PDF koordinatında aşağı sətirlərin Y göstəricisi daha kiçikdir.
     const summaryLines=lines.filter(x=>x.items.length>=5).sort((a,b)=>a.y-b.y);
     for(const line of summaryLines){
       const vals=line.items.sort((a,b)=>a.x-b.x).map(x=>Number(String(x.text).replace(',','.'))).filter(Number.isFinite);
       // İstehsalat təqviminin aylıq xülasəsində soldan ilk ədəd iş günüdür:
       // iş günü, bayram/istirahət günü, 40/36/24 saatlıq norma.
       // Saat normalarını da yoxlayırıq ki, təqvim tarixləri olan sətrə düşməsin.
       if(vals.length>=5){
         const [work,off,h40,h36,h24]=vals;
         const looksLikeSummary=Number.isInteger(work)&&work>=10&&work<=27&&Number.isInteger(off)&&off>=4&&off<=21&&h40>=70&&h40<=200&&h36>=60&&h36<=180&&h24>=40&&h24<=130;
         if(looksLikeSummary){counts[h.month]=work;break}
       }
     }
   }
 }
 const missing=counts.map((v,i)=>v?null:AZ_MONTHS[i]).filter(Boolean);
 if(missing.length)throw new Error('İş günü sayı tapılmayan aylar: '+missing.join(', '));
 for(let m=0;m<12;m++)state.calendar[`${year}-${m}`]=counts[m];
 state.calendarMeta[year]={source:file.name,counts:[...counts],loadedAt:new Date().toISOString()};
 state.year=year;state.quarter=Math.floor(state.month/3)+1;
 const ys=$('#yearSelect');if(ys){if(![...ys.options].some(o=>Number(o.value)===year))ys.insertAdjacentHTML('beforeend',`<option value="${year}">${year}</option>`);ys.value=year}
 toast(`${year} təqvimi qəbul edildi: ${counts.map((v,i)=>AZ_MONTHS[i]+' '+v).join(' · ')}`);
}
function parseCalendarTable(rows){const found={};for(let r=0;r<rows.length;r++){const line=(rows[r]||[]).map(String),text=norm(line.join(' ')),mi=AZ_MONTHS.findIndex(m=>text.includes(norm(m))),ym=text.match(/20\d{2}/);if(mi>=0&&ym){const year=+ym[0];let hdr=rows.findIndex((x,i)=>i>=r&&i<r+10&&(x||[]).some(v=>String(v).trim()==='01'));if(hdr>=0){let work=0;for(let c=0;c<31;c++){const vals=rows.slice(hdr+1,hdr+22).map(x=>x?.[7+c]).filter(v=>v!==undefined);if(vals.some(v=>num(v)>0))work++}if(work){state.calendar[`${year}-${mi}`]=work;(found[year]||(found[year]=Array(12).fill(0)))[mi]=work}}}}for(const [y,c] of Object.entries(found)){state.calendarMeta[y]={source:state.files.calendar||state.files.tabel||'Excel/CSV',counts:c,loadedAt:new Date().toISOString()};state.year=Number(y)}persistStateSilent()}
function calendarDefaults(){return {'2025-0':18,'2025-1':20,'2025-2':14,'2025-3':21,'2025-4':20,'2025-5':17,'2025-6':23,'2025-7':21,'2025-8':22,'2025-9':23,'2025-10':18,'2025-11':22,'2026-0':19,'2026-1':20,'2026-2':14,'2026-3':22,'2026-4':17,'2026-5':20,'2026-6':23,'2026-7':21,'2026-8':22,'2026-9':22,'2026-10':19,'2026-11':22}}
function employeeKey(x){return norm(x.fin||x.name)}
function rebuildEmployees(){
 const old=new Map(state.employees.map(e=>[employeeKey(e),e]));
 const activeBy=new Map(),expiredBy=new Map(),termsBy=new Map();
 const add=(map,x)=>{const k=employeeKey(x);if(!k)return;if(!map.has(k))map.set(k,[]);map.get(k).push(x)};
 for(const c of dedupeContractRecords(state.contracts||[]))add(activeBy,c);
 for(const c of dedupeContractRecords(state.expiredContracts||[]))add(expiredBy,c);
 for(const t of state.terminations||[])add(termsBy,t);
 const keys=new Set([...activeBy.keys(),...expiredBy.keys(),...termsBy.keys()]),result=[];
 const when=x=>x?.effectiveStart?.getTime?.()||x?.start?.getTime?.()||0;
 const latestBefore=(records,dt)=>records.filter(c=>!dt||!c.effectiveStart||c.effectiveStart<=dt).sort((a,b)=>when(b)-when(a))[0]||records.slice().sort((a,b)=>when(b)-when(a))[0]||{};
 for(const k of keys){
  const active=(activeBy.get(k)||[]).slice().sort((a,b)=>when(a)-when(b));
  const expired=(expiredBy.get(k)||[]).slice().sort((a,b)=>when(a)-when(b));
  const terms=(termsBy.get(k)||[]).slice().filter(t=>t.end).sort((a,b)=>a.end-b.end);
  const allContracts=[...expired,...active],periods=[];

  // Xitam əmri əsas mənbədir: xitam verilmiş hər əmək münasibəti yalnız öz başlanğıc–xitam aralığında qüvvədə sayılır.
  for(const t of terms){
   const source=latestBefore(allContracts,t.end);
   const start=t.start||source.baseStart||source.start||null;
   periods.push({
    ...source,
    name:t.name||source.name||'',fin:t.fin||source.fin||'',position:t.position||source.position||'',
    start,end:t.end,salary:num(source.salary),terminated:true
   });
  }

  // Qüvvədə olan müqavilələrdən yalnız son xitamdan sonra başlayan (rehire) və ya heç xitamı olmayan əmək münasibəti açıq saxlanılır.
  if(active.length){
   const latestActive=active.slice().sort((a,b)=>when(b)-when(a))[0];
   const baseStart=latestActive.baseStart||latestActive.start||null;
   const latestTerm=terms.length?terms[terms.length-1].end:null;
   const isRehire=!latestTerm||!baseStart||baseStart>latestTerm;
   if(isRehire){
    periods.push({...latestActive,start:baseStart,end:null,terminated:false});
   }
  }

  // Xitam faylı yoxdursa, qüvvədən düşən müqavilənin müqavilə bitmə tarixi varsa qapalı dövr kimi saxlanılır.
  if(!terms.length&&!active.length&&expired.length){
   const latestExpired=expired.slice().sort((a,b)=>when(b)-when(a))[0];
   const end=latestExpired.contractEnd||null;
   if(end)periods.push({...latestExpired,start:latestExpired.baseStart||latestExpired.start||null,end,terminated:true});
  }

  // Eyni başlanğıc/bitmə dövrünü təkrar saxlamırıq.
  const uniq=[],seen=new Set();
  for(const p of periods){const pk=[p.start?dateKeyLocal(p.start):'',p.end?dateKeyLocal(p.end):'',num(p.salary).toFixed(2)].join('|');if(seen.has(pk))continue;seen.add(pk);uniq.push(p)}
  if(!uniq.length)continue;
  const latest=uniq.slice().sort((a,b)=>(b.start?.getTime()||0)-(a.start?.getTime()||0))[0]||{},prev=old.get(k)||{};
  result.push({...latest,name:latest.name||prev.name||'',fin:latest.fin||prev.fin||'',employmentPeriods:uniq,staff:prev.staff||'tam',base:prev.base||'Əsas iş yeri',absent:num(prev.absent),final:num(prev.final),vacation:num(prev.vacation),bonus:num(prev.bonus),aid:num(prev.aid),finalEnabled:!!prev.finalEnabled,leaveUsed:num(prev.leaveUsed)})
 }
 state.employees=result;renderAll()
}

function monthWorkdays(y,m){return state.calendar[`${y}-${m}`]??(()=>{let n=0,d=new Date(y,m,1);while(d.getMonth()===m){if(d.getDay()!=0&&d.getDay()!=6)n++;d.setDate(d.getDate()+1)}return n})()}
function employeePeriods(e){return Array.isArray(e.employmentPeriods)&&e.employmentPeriods.length?e.employmentPeriods:[{start:e.start||null,end:e.end||null,salary:e.salary,position:e.position,name:e.name,fin:e.fin}]}
function overlapsMonth(p){const first=new Date(state.year,state.month,1),last=new Date(state.year,state.month+1,0);return !(p.start&&p.start>last)&&!(p.end&&p.end<first)}
function isEmployedInPeriod(e){return employeePeriods(e).some(overlapsMonth)}
function periodEmployees(){return state.employees.filter(isEmployedInPeriod)}
function effectiveEmployment(e){const first=new Date(state.year,state.month,1),last=new Date(state.year,state.month+1,0),ps=employeePeriods(e).filter(overlapsMonth).sort((a,b)=>(b.start?.getTime()||0)-(a.start?.getTime()||0));return ps[0]||e}
function employmentForDate(e,dt){return employeePeriods(e).filter(p=>(!p.start||dt>=p.start)&&(!p.end||dt<=p.end)).sort((a,b)=>(b.start?.getTime()||0)-(a.start?.getTime()||0))[0]||null}
function trailing12Income(e,year,month){
 if(!e)return 0;let total=0;
 for(let back=12;back>=1;back--){
  const cursor=new Date(year,month-back,1),y=cursor.getFullYear(),m=cursor.getMonth(),wd=monthWorkdays(y,m);
  if(!wd)continue;
  const last=new Date(y,m+1,0);
  for(let d=new Date(y,m,1);d<=last;d.setDate(d.getDate()+1)){
   if(!isOfficialWorkday(d))continue;
   const period=employmentForDate(e,d);if(!period)continue;
   total+=num(period.salary??e.salary)/wd;
  }
 }
 return Math.round((total+Number.EPSILON)*100)/100
}
function isEmployedOnDate(e,dt){return employeePeriods(e).some(p=>(!p.start||dt>=p.start)&&(!p.end||dt<=p.end))}
function leaveRecordDates(rec){
 const start=parseDate(rec?.startDate)||new Date(+rec.year,+rec.month,1),count=Math.max(0,Math.round(num(rec?.eligible||rec?.baseDays||0))),dates=[];
 if(!start||!count)return dates;
 for(let d=new Date(start),guard=0;dates.length<count&&guard<800;d.setDate(d.getDate()+1),guard++){
  if(!isOfficialWorkday(d))continue;
  dates.push(new Date(d.getFullYear(),d.getMonth(),d.getDate()));
 }
 return dates
}
function leaveDateKeysForEmployee(e){const key=employeeKey(e),out=new Set();for(const r of (state.leaveRecords||[]).filter(x=>x.employee===key))for(const d of leaveRecordDates(r))out.add(dateKeyLocal(d));return out}
function leaveAmountForPeriod(e){const key=employeeKey(e);return (state.leaveRecords||[]).filter(r=>r.employee===key&&+r.year===state.year&&+r.month===state.month).reduce((a,r)=>a+num(r.amount),0)}
function activeDays(e){if(!isEmployedInPeriod(e))return 0;const first=new Date(state.year,state.month,1),last=new Date(state.year,state.month+1,0),leaveKeys=leaveDateKeysForEmployee(e);let n=0;for(let d=new Date(first);d<=last;d.setDate(d.getDate()+1)){const key=dateKeyLocal(d);if(!isOfficialWorkday(d)||leaveKeys.has(key))continue;if(isEmployedOnDate(e,d))n++}const absent=Math.max(0,num(e.absent)||0);return Math.max(0,n-absent)}
function calc(e){const wd=monthWorkdays(state.year,state.month),fd=Math.min(wd,activeDays(e)),ep=effectiveEmployment(e),salary=num(ep.salary??e.salary)*(e.staff==='½'?0.5:e.staff==='¼'?0.25:1),earned=wd?salary/wd*fd:0,finalAmount=e.finalEnabled?autoFinalComp(e):num(e.final),vacationAmount=leaveAmountForPeriod(e)||num(e.vacation),total=earned+finalAmount+vacationAmount+num(e.bonus)+num(e.aid);const income=e.base==='Əsas iş yeri'?Math.max(0,total-200)*.03:total*.03;const empP=total<=200?total*.03:6+(total-200)*.10,empUn=total*.005,empMed=total*.02;const erP=total<=200?total*.22:44+(total-200)*.15,erUn=total*.005,erMed=total*.02;const withheld=income+empP+empUn+empMed;return {wd,fd,salary,earned,finalAmount,vacationAmount,total,income,empP,empUn,empMed,erP,erUn,erMed,withheld,net:total-withheld}}
function filteredCompanies(){return state.companies.filter(c=>state.org==='legal'?c.voen.endsWith('1'):c.voen.endsWith('2'))}
function currentCompany(){return state.companies.find(c=>`${c.name}|${c.voen}`===state.selectedCompany)||filteredCompanies()[0]||{name:'—',voen:'—'}}
function salesSummary(){const invoice=state.outgoing.filter(x=>x.date.getFullYear()===state.year&&x.date.getMonth()===state.month).reduce((a,x)=>a+x.amount,0),cash=state.cash.filter(x=>x.year===state.year&&x.month===state.month).reduce((a,x)=>a+x.amount,0);return {invoice,cash,total:invoice+cash}}
function debtKey(){const c=currentCompany();return `${c.voen}|${state.year}|${state.quarter}|${state.month}`}
function currentDebts(){const k=debtKey();if(!state.debts[k])state.debts[k]={};return state.debts[k]}
function periodText(){return `${AZ_MONTHS[state.month]} ${state.year} · ${state.quarter} RÜB`}

function dateOnly(d){return d?new Date(d.getFullYear(),d.getMonth(),d.getDate()):null}
function mergeIntervals(intervals){const xs=intervals.map(x=>({start:dateOnly(parseDate(x.start)),end:dateOnly(parseDate(x.end))})).filter(x=>x.start&&x.end&&x.end>=x.start).sort((a,b)=>a.start-b.start),out=[];for(const x of xs){const last=out[out.length-1];if(last&&x.start<=new Date(last.end.getTime()+86400000)){if(x.end>last.end)last.end=x.end}else out.push({...x})}return out}
function intervalDays(intervals){return mergeIntervals(intervals).reduce((a,x)=>a+Math.floor((x.end-x.start)/86400000)+1,0)}
function ymdFromDays(days){const years=Math.floor(days/365.2425),rem=Math.max(0,days-Math.floor(years*365.2425)),months=Math.floor(rem/30.4369),d=Math.round(rem-months*30.4369);return {years,months,days:d}}
function seniorityBonus(days){const years=days/365.2425;return years>=15?6:years>=10?4:years>=5?2:0}
function draftEmployee(){return state.employees.find(e=>employeeKey(e)===state.leaveDraft.employee)||null}
function leaveSeniorityIntervals(){
 const d=state.leaveDraft,e=draftEmployee(),until=new Date(+d.year,+d.month+1,0),items=[];
 if(e){for(const p of employeePeriods(e)){const start=parseDate(p.start),rawEnd=parseDate(p.end),end=rawEnd&&rawEnd<until?rawEnd:until;if(start&&start<=until&&end>=start)items.push({start,end})}}
 for(const x of (d.intervals||[])){const start=parseDate(x.start),rawEnd=parseDate(x.end),end=rawEnd&&rawEnd<until?rawEnd:until;if(start&&start<=until&&end>=start)items.push({start,end})}
 return items
}
function leaveDraftCalc(){const d=state.leaveDraft,e=draftEmployee(),days=intervalDays(leaveSeniorityIntervals()),bonus=seniorityBonus(days),base=d.position==='specialist'?30:21,eligible=base+bonus,start=parseDate(d.startDate),income=trailing12Income(e,+d.year,+d.month),daily=(income/12)/30.4,temp={year:d.year,month:d.month,startDate:start?dateKeyLocal(start):'',eligible,baseDays:base},leaveDates=start?leaveRecordDates(temp):[];d.income=income;d.baseDays=base;d.used=bonus;return {days,bonus,base,eligible,daily,amount:daily*eligible,start,end:leaveDates.at(-1)||null,leaveDates}}
function serviceDaysForEmployee(e,until=new Date()){let intervals=employeePeriods(e).map(p=>({start:p.start,end:p.end&&p.end<until?p.end:until})).filter(x=>x.start&&x.end&&x.end>=x.start);return intervalDays(intervals)}
function autoFinalComp(e){if(!e.finalEnabled)return 0;const record=(state.leaveRecords||[]).filter(r=>r.employee===employeeKey(e)).sort((a,b)=>(b.savedAt||'').localeCompare(a.savedAt||''))[0];const income=num(record?.income)||num(effectiveEmployment(e).salary??e.salary)*12;const used=num(record?.used)||num(e.leaveUsed);const serviceDays=serviceDaysForEmployee(e,new Date(state.year,state.month+1,0));const annualDays=num(record?.baseDays)||21;const accrued=Math.max(0,annualDays*(serviceDays/365.2425)-used);return (income/12/30.4)*accrued}
function renderAll(){state.quarter=Math.floor(Number(state.month)/3)+1;renderSealStatus();$('#managerName').value=state.managerName||'';$('#preparedBy').value=state.preparedBy||'';renderCompanies();renderGeneral();renderPayroll();renderCalendar();renderTimesheet();renderDebtPage();renderArchiveLists();renderTax();renderReports();renderLeave();const s=salesSummary();$('#employeeCount').textContent=periodEmployees().length;$('#workdayCount').textContent=monthWorkdays(state.year,state.month);$('#monthOrb').textContent=`${AZ_MONTHS[state.month]} ${state.year}`;$('#payrollTotal').textContent=money(periodEmployees().reduce((a,e)=>a+calc(e).total,0));$('#payrollPeriod').textContent=periodText();$('#invoiceSales').textContent=money(s.invoice);$('#cashSales').textContent=money(s.cash);$('#totalSales').textContent=money(s.total)}
function renderCompanies(){const opts=filteredCompanies();if(!opts.some(c=>`${c.name}|${c.voen}`===state.selectedCompany))state.selectedCompany=opts.length?`${opts[0].name}|${opts[0].voen}`:'';$('#companyLabel').textContent=state.org==='legal'?'Şirkət adı':'Fərdi sahibkar';$('#companySelect').innerHTML=opts.length?opts.map(c=>`<option value="${esc(c.name)}|${esc(c.voen)}" ${`${c.name}|${c.voen}`===state.selectedCompany?'selected':''}>${esc(c.name)} — ${esc(c.voen)}</option>`).join(''):'<option value="">Uyğun qeyd yoxdur — Şirkət adları faylını yoxlayın</option>';$('#companyVoen').value=currentCompany().voen==='—'?'':currentCompany().voen}
function renderGeneral(){const tb=$('#generalTable tbody');tb.innerHTML=state.employees.map((e,i)=>{const c=calc(e);return `<tr><td>${i+1}</td><td>${esc(e.name)}</td><td><select data-i="${i}" data-k="staff"><option>tam</option><option>½</option><option>¼</option><option>digər</option></select></td><td><select data-i="${i}" data-k="base"><option>Əsas iş yeri</option><option>Əlavə iş yeri</option></select></td><td>${c.wd}</td><td><input type="number" min="0" step="0.01" data-i="${i}" data-k="absent" value="${e.absent||''}"></td><td><label class="final-check"><input type="checkbox" data-i="${i}" data-k="finalEnabled" ${e.finalEnabled?'checked':''}><span>${e.finalEnabled?money(c.finalAmount):'Hesabla'}</span></label></td>${['vacation','bonus','aid'].map(k=>`<td><input type="number" min="0" step="0.01" data-i="${i}" data-k="${k}" value="${e[k]||''}"></td>`).join('')}<td><span class="status ${c.fd<c.wd?'partial':'active'}">${c.fd?`${c.fd} gün`:'Dövrdə yoxdur'}</span></td></tr>`}).join('');tb.querySelectorAll('select').forEach(x=>x.value=state.employees[+x.dataset.i][x.dataset.k])}
const heads=['№','Soyadı, adı, atasının adı','FİN','Vəzifəsi','Əmək haqqı','Ştat','Əsas/Əlavə','Ayın iş günləri','Faktiki iş günləri','Hesablanmış əmək haqqı','Son haqq-hesab','Məzuniyyət','Mükafat','Maddi yardım','Yekun ə/h','Gəlir vergisi','Pensiya Fondu (işçi)','İ.S.H. (işçi)','İcbari sığorta (işçi)','Pensiya Fondu (işəgötürən)','İ.S.H. (işəgötürən)','İcbari sığorta (işəgötürən)','Cəmi tutulmuşdur','Əlinə çatan'];
function renderPayroll(){const t=$('#payrollTable'),employees=periodEmployees();t.querySelector('thead').innerHTML='<tr>'+heads.map(h=>`<th>${h}</th>`).join('')+'</tr>';let sums=Array(24).fill(0);t.querySelector('tbody').innerHTML=employees.map((e,i)=>{const c=calc(e),v=[i+1,e.name,e.fin,effectiveEmployment(e).position||e.position,c.salary,e.staff,e.base,c.wd,c.fd,c.earned,c.finalAmount,c.vacationAmount,e.bonus,e.aid,c.total,c.income,c.empP,c.empUn,c.empMed,c.erP,c.erUn,c.erMed,c.withheld,c.net];v.forEach((x,j)=>{if(j>3&&j!==5&&j!==6)sums[j]+=num(x)});return '<tr>'+v.map((x,j)=>`<td class="${j>3?'num':''}">${j>3&&j!==5&&j!==6?num(x).toFixed(2):esc(x??'')}</td>`).join('')+'</tr>'}).join('');t.querySelector('tfoot').innerHTML='<tr><td colspan="4">CƏMİ</td>'+sums.slice(4).map((x,j)=>`<td class="num">${[1,2].includes(j)?'':x.toFixed(2)}</td>`).join('')+'</tr>'}
function renderCalendar(){const y=state.year,m=state.month,grid=$('#calendarGrid'),days=['B.e.','Ç.a.','Ç.','C.a.','C.','Ş.','B.'],holidays=effectiveHolidayKeysForMonth(y,m);let h=`<div class="calendar-loaded-note">${esc(state.calendarMeta?.[y]?.source||'Avtomatik təqvim')} · ${AZ_MONTHS[m]}: <b>${monthWorkdays(y,m)} iş günü</b></div>`+days.map(x=>`<div class="cal-head">${x}</div>`).join(''),first=(new Date(y,m,1).getDay()+6)%7;h+='<div></div>'.repeat(first);for(let d=1;d<=new Date(y,m+1,0).getDate();d++){const dt=new Date(y,m,d),holiday=holidays.has(dateKeyLocal(dt)),off=dt.getDay()==0||dt.getDay()==6||holiday;h+=`<div class="cal-day ${off?'off':''}"><b>${d}</b><small>${holiday?'Bayram':off?'İstirahət':'İş günü'}</small></div>`}grid.innerHTML=h}


function dateKeyLocal(dt){return `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`}
function holidayKeysForYear(year){
 const fixed=[`${year}-01-01`,`${year}-01-02`,`${year}-01-20`,`${year}-03-08`,`${year}-03-20`,`${year}-03-21`,`${year}-03-22`,`${year}-03-23`,`${year}-03-24`,`${year}-05-09`,`${year}-05-28`,`${year}-06-15`,`${year}-06-26`,`${year}-11-08`,`${year}-11-09`,`${year}-12-31`];
 const movable={
  2025:['2025-03-25','2025-03-26','2025-03-30','2025-03-31','2025-06-06','2025-06-07','2025-06-09','2025-06-16'],
  2026:['2026-03-09','2026-03-25','2026-03-26','2026-03-27','2026-03-30','2026-05-11','2026-05-27','2026-05-29','2026-11-10']
 };
 return new Set([...fixed,...(movable[year]||[])]);
}

function fixedHolidayKeysForYear(year){
 return new Set([`${year}-01-01`,`${year}-01-02`,`${year}-01-20`,`${year}-03-08`,`${year}-03-20`,`${year}-03-21`,`${year}-03-22`,`${year}-03-23`,`${year}-03-24`,`${year}-05-09`,`${year}-05-28`,`${year}-06-15`,`${year}-06-26`,`${year}-11-08`,`${year}-11-09`,`${year}-12-31`]);
}
function movableHolidayKeysForYear(year){
 const movable={
  2025:['2025-03-25','2025-03-26','2025-03-30','2025-03-31','2025-06-06','2025-06-07','2025-06-09','2025-06-16'],
  2026:['2026-03-09','2026-03-25','2026-03-26','2026-03-27','2026-03-30','2026-05-11','2026-05-27','2026-05-29','2026-11-10']
 };
 return new Set(movable[year]||[]);
}
function effectiveHolidayKeysForMonth(year,month){
 const all=holidayKeysForYear(year), fixed=fixedHolidayKeysForYear(year), movable=movableHolidayKeysForYear(year);
 const weekdays=[]; for(let d=new Date(year,month,1);d.getMonth()===month;d.setDate(d.getDate()+1)){if(d.getDay()!==0&&d.getDay()!==6)weekdays.push(dateKeyLocal(d))}
 const nonwork=new Set(weekdays.filter(k=>all.has(k)));
 const target=Number(state.calendar?.[`${year}-${month}`]);
 if(!Number.isFinite(target)||target<0||target>weekdays.length)return nonwork;
 let current=weekdays.length-nonwork.size;
 if(current<target){
  const restore=[...nonwork].sort((a,b)=>{const am=movable.has(a)?0:fixed.has(a)?1:2,bm=movable.has(b)?0:fixed.has(b)?1:2;return am-bm||a.localeCompare(b)});
  for(const k of restore){if(current>=target)break;nonwork.delete(k);current++}
 }else if(current>target){
  const candidates=weekdays.filter(k=>!nonwork.has(k)).sort((a,b)=>{
   const da=new Date(a+'T00:00:00'),db=new Date(b+'T00:00:00');
   const pa=(da.getDay()===1||da.getDay()===5)?0:1,pb=(db.getDay()===1||db.getDay()===5)?0:1;
   return pa-pb||a.localeCompare(b)
  });
  for(const k of candidates){if(current<=target)break;nonwork.add(k);current--}
 }
 return nonwork;
}
function isOfficialWorkday(dt){if(!dt||Number.isNaN(dt.getTime()))return false;if(dt.getDay()===0||dt.getDay()===6)return false;return !effectiveHolidayKeysForMonth(dt.getFullYear(),dt.getMonth()).has(dateKeyLocal(dt))}
function vacationCalendarDaysForEmployee(e){
 const out=new Set(),key=employeeKey(e);
 for(const rec of (state.leaveRecords||[]).filter(r=>r.employee===key))for(const dt of leaveRecordDates(rec))if(dt.getFullYear()===state.year&&dt.getMonth()===state.month)out.add(dt.getDate());
 return out;
}
function dayCode(e,day,vacationDays,holidayKeys){
 const dt=new Date(state.year,state.month,day),key=dateKeyLocal(dt);
 if(holidayKeys.has(key))return 'B';
 if(dt.getDay()===0||dt.getDay()===6)return 'İ';
 if(!isEmployedOnDate(e,dt))return '';
 if(vacationDays&&vacationDays.has(day))return 'M';
 return 8;
}

function renderTimesheet(){
 const t=$('#timesheetTable'); if(!t)return; const days=new Date(state.year,state.month+1,0).getDate();
 const fixed=['№','Adı və soyadı','Vəzifəsi','FİN','Maaş','Ştat','Vəzifə maaşı (AZN)'];
 t.querySelector('thead').innerHTML='<tr>'+fixed.map(h=>`<th>${h}</th>`).join('')+Array.from({length:days},(_,i)=>`<th>${String(i+1).padStart(2,'0')}</th>`).join('')+'<th>İş günü</th><th>İş saatı</th></tr>';
 const employees=periodEmployees(),holidayKeys=effectiveHolidayKeysForMonth(state.year,state.month);t.querySelector('tbody').innerHTML=employees.map((e,i)=>{let wd=0,hours=0;const vacationDays=vacationCalendarDaysForEmployee(e);const cells=Array.from({length:days},(_,d)=>{const v=dayCode(e,d+1,vacationDays,holidayKeys);if(v===8){wd++;hours+=8}const cls=v==='İ'?'timesheet-off':v==='B'?'timesheet-holiday':v==='M'?'timesheet-leave':'timesheet-work';return `<td class="${cls}">${v}</td>`}).join('');return `<tr><td>${i+1}</td><td>${esc(e.name)}</td><td>${esc(effectiveEmployment(e).position||e.position)}</td><td>${esc(e.fin)}</td><td class="num">${num(effectiveEmployment(e).salary??e.salary).toFixed(2)}</td><td>${esc(e.staff)}</td><td class="num">${calc(e).salary.toFixed(2)}</td>${cells}<td class="num">${wd}</td><td class="num">${hours}</td></tr>`}).join('');
 const totals=employees.reduce((acc,e)=>{const vacationDays=vacationCalendarDaysForEmployee(e);for(let d=1;d<=days;d++){if(dayCode(e,d,vacationDays,holidayKeys)===8){acc.days++;acc.hours+=8}}return acc},{days:0,hours:0});
 t.querySelector('tfoot').innerHTML=`<tr><td colspan="${fixed.length+days}">CƏMİ</td><td class="num">${totals.days}</td><td class="num">${totals.hours}</td></tr>`;$('#timesheetPeriod').textContent=`${AZ_MONTHS[state.month].toLocaleUpperCase('az')} (${state.year}) · hər iş günü 8 saat`;
}

function payrollSums(){const a=periodEmployees().map(calc),sum=k=>a.reduce((x,c)=>x+c[k],0);return {fund:sum('total'),income:sum('income'),empP:sum('empP'),empUn:sum('empUn'),empMed:sum('empMed'),erP:sum('erP'),erUn:sum('erUn'),erMed:sum('erMed')}}
function computedObligations(){const p=payrollSums(),s=salesSummary(),physical=state.org==='physical';return {sv:0,omv:0,mv:0,property:0,land:0,road:0,fsIncome:physical?Math.min(s.total*.02,400):0,fsMedical:physical?400*.04:0,empP:p.empP,erP:p.erP,empUn:p.empUn,erUn:p.erUn,empMed:p.empMed,erMed:p.erMed}}
function renderDebtPage(){const c=currentCompany(),d=currentDebts(),make=(arr)=>arr.map(([k,label])=>`<label class="debt-input"><span>${label}</span><input type="text" inputmode="decimal" autocomplete="off" data-debt="${k}" value="${d[k]??''}" placeholder="0.00"></label>`).join('');$('#taxDebtInputs').innerHTML=make(TAX_KEYS);const social=$('#socialDebtInputs');if(social)social.innerHTML='';$('#debtEntityName').textContent=c.name;$('#debtEntityVoen').textContent=c.voen;$('#debtPeriod').textContent=periodText();$('#manualDebtTotal').textContent=money(TAX_KEYS.reduce((a,[k])=>a+num(d[k]),0))}
function renderTax(){const c=currentCompany(),agg=selectedArchiveTaxAggregate(),d=agg?agg.debts:currentDebts(),co=agg?agg.computed:computedObligations(),p=agg?{fund:agg.fund}:payrollSums(),rows=[...TAX_KEYS,...SOCIAL_KEYS],taxManual=TAX_KEYS.reduce((a,[k])=>a+num(d[k]),0),socialCalc=SOCIAL_KEYS.reduce((a,[k])=>a+num(co[k]),0),socialDebt=SOCIAL_KEYS.reduce((a,[k])=>a+num(d[k]),0),grand=taxManual+socialCalc+socialDebt;$('#taxEntityName').textContent=c.name;$('#taxEntityVoen').textContent=c.voen;$('#taxPeriod').textContent=agg?agg.selected.map(a=>`${AZ_MONTHS[a.month]} ${a.year}`).join(', '):periodText();$('#taxKpis').innerHTML=[['Əməkhaqqı fondu',p.fund],['Vergi borcları',taxManual],['DSMF öhdəlikləri',socialCalc+socialDebt],['Ümumi vergi + DSMF borcu',grand]].map(x=>`<div class="kpi"><span>${x[0]}</span><strong>${money(x[1])}</strong></div>`).join('');$('#taxDetails').innerHTML=rows.map(([k,label],i)=>{const cv=num(co[k]),dv=num(d[k]),total=cv+dv;return `${i===TAX_KEYS.length?'<div class="section-separator"><span>DSMF ÖHDƏLİKLƏRİ</span></div>':''}<div class="tax-row four"><span>${label}</span><b>${money(cv)}</b><b>${money(dv)}</b><b>${money(total)}</b></div>`}).join('')+`<div class="tax-grand"><span>ÜMUMİ BORC</span><strong>${money(grand)}</strong></div>`;$('#taxWarning').innerHTML=agg?`Salam, <b>seçilmiş aylar üzrə DSMF və vergi öhdəlikləri.</b> Diqqət! Öhdəliklər 5 iş günü içində ödənilmədiyi halda bankınıza sərəncam daxil olacaq.`:`Salam, <b>${state.quarter}-ci rüb DSMF və vergi öhdəlikləri.</b> Diqqət! Öhdəliklər 5 iş günü içində ödənilmədiyi halda bankınıza sərəncam daxil olacaq.`}

function renderLeave(){
 if(!$('#leaveEmployee'))return;const d=state.leaveDraft||{},employees=state.employees;
 $('#leaveEmployee').innerHTML='<option value="">İşçi seçin</option>'+employees.map(e=>`<option value="${esc(employeeKey(e))}">${esc(e.name)}</option>`).join('');$('#leaveEmployee').value=d.employee||'';
 $('#leavePosition').value=d.position||'ordinary';$('#leaveYear').value=d.year||state.year;$('#leaveQuarter').value=d.quarter||state.quarter;$('#leaveMonth').value=d.month??state.month;$('#leaveStartDate').value=d.startDate||'';
 const c=leaveDraftCalc();$('#leaveIncome').value=c.income?c.income.toFixed(2):'0.00';$('#leaveUsed').value=c.bonus;$('#leaveBaseDays').value=c.base;const ymd=ymdFromDays(c.days);$('#seniorityText').textContent=`${ymd.years} il ${ymd.months} ay ${ymd.days} gün`;$('#seniorityBonus').textContent=`${c.bonus} gün`;$('#leaveAmount').textContent=money(c.amount);$('#leaveEndDate').value=c.end?dateKeyLocal(c.end):'';
 $('#stajList').innerHTML=(d.intervals||[]).map((x,i)=>`<div><span>${formatDate(parseDate(x.start))} — ${formatDate(parseDate(x.end))}</span><button data-del-staj="${i}">Sil</button></div>`).join('');
 $('#leaveTable tbody').innerHTML=(state.leaveRecords||[]).map((r,i)=>`<tr><td>${esc(r.name)}</td><td>${r.position==='specialist'?'Mütəxəssis':'Adi'}</td><td>${r.year}</td><td>${r.quarter} RÜB</td><td>${AZ_MONTHS[r.month]}</td><td>${esc(r.startDate||'—')}</td><td>${esc(r.endDate||'—')}</td><td class="num">${num(r.income).toFixed(2)}</td><td class="num">${r.bonus}</td><td class="num">${num(r.eligible).toFixed(2)}</td><td class="num">${num(r.amount).toFixed(2)}</td><td><button class="leave-delete" data-del-leave="${i}" title="Bu hesablamanı sil">Sil</button></td></tr>`).join('');
}
function syncEmployeeVacationAfterLeaveDelete(employeeId){
 const e=state.employees.find(x=>employeeKey(x)===employeeId);if(!e)return;
 const remaining=(state.leaveRecords||[]).filter(r=>r.employee===employeeId).sort((a,b)=>(b.savedAt||'').localeCompare(a.savedAt||''));
 e.vacation=remaining.length?num(remaining[0].amount):0;
}
function persistStateSilent(){localStorage.setItem('eh_state_v2',JSON.stringify(serializeState()))}
function formatDate(d){return d?`${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}.${d.getFullYear()}`:'—'}

function renderReports(){
 const c=currentCompany();if(!$('#reportEntity'))return;
 const opts=filteredCompanies();
 $('#reportOrgType').value=state.org;
 $('#reportCompanySelect').innerHTML=opts.length?opts.map(x=>`<option value="${esc(x.name)}|${esc(x.voen)}" ${`${x.name}|${x.voen}`===state.selectedCompany?'selected':''}>${esc(x.name)} — ${esc(x.voen)}</option>`).join(''):'<option value="">Uyğun vergi ödəyicisi yoxdur</option>';
 if(!$('#reportYearSelect').options.length){for(let y=2020;y<=2035;y++)$('#reportYearSelect').insertAdjacentHTML('beforeend',`<option value="${y}">${y}</option>`)}
 if(!$('#reportMonthSelect').options.length){AZ_MONTHS.forEach((m,i)=>$('#reportMonthSelect').insertAdjacentHTML('beforeend',`<option value="${i}">${m}</option>`))}
 $('#reportYearSelect').value=state.year;$('#reportQuarterSelect').value=state.quarter;$('#reportMonthSelect').value=state.month;
 $('#reportEntity').textContent=c.name;$('#reportVoen').textContent=c.voen;$('#reportYear').textContent=state.year;$('#reportQuarter').textContent=state.quarter+' RÜB';$('#reportMonth').textContent=AZ_MONTHS[state.month]
}
function documentDate(){return new Date().toLocaleDateString('az-AZ',{day:'2-digit',month:'2-digit',year:'numeric'})}
function signerLabel(){return state.org==='physical'?'Fərdi sahibkar':'Rəhbər'}
function formalHeader(title,subtitle=''){
 const c=currentCompany();
 return `<div class="doc-header"><div class="doc-brand">ƏMƏK HAQQI VƏ HESABATLAR</div><h1>${esc(title)}</h1>${subtitle?`<div class="doc-subtitle">${esc(subtitle)}</div>`:''}</div>
 <table class="doc-meta"><tr><td><b>Vergi ödəyicisi:</b></td><td>${esc(c.name)}</td><td><b>VÖEN:</b></td><td>${esc(c.voen)}</td></tr><tr><td><b>Dövr:</b></td><td>${esc(periodText())}</td><td><b>Sənəd tarixi:</b></td><td>${documentDate()}</td></tr></table>`;
}
function formalHeaderForPeriod(title,period,subtitle=''){
 const c=currentCompany();
 return `<div class="doc-header"><div class="doc-brand">ƏMƏK HAQQI VƏ HESABATLAR</div><h1>${esc(title)}</h1>${subtitle?`<div class="doc-subtitle">${esc(subtitle)}</div>`:''}</div>
 <table class="doc-meta"><tr><td><b>Vergi ödəyicisi:</b></td><td>${esc(c.name)}</td><td><b>VÖEN:</b></td><td>${esc(c.voen)}</td></tr><tr><td><b>Dövr:</b></td><td>${esc(period)}</td><td><b>Sənəd tarixi:</b></td><td>${documentDate()}</td></tr></table>`;
}
function taxReportData(){
 const agg=selectedArchiveTaxAggregate(),d=agg?agg.debts:currentDebts(),co=agg?agg.computed:computedObligations();
 const selected=agg?.selected||[];
 const period=selected.length?selected.map(a=>`${AZ_MONTHS[a.month]} ${a.year} · ${a.quarter} RÜB`).join(', '):periodText();
 const taxRows=TAX_KEYS.map(([k,label])=>({label,amount:num(co[k])+num(d[k])}));
 const socialRows=SOCIAL_KEYS.map(([k,label])=>({label,amount:num(co[k])+num(d[k])}));
 const taxTotal=taxRows.reduce((a,r)=>a+r.amount,0),socialTotal=socialRows.reduce((a,r)=>a+r.amount,0);
 const quarters=[...new Set(selected.map(a=>a.quarter))];
 const warningPeriod=selected.length?(quarters.length===1?`${quarters[0]}-ci rüb`:'seçilmiş dövrlər'):`${state.quarter}-ci rüb`;
 return {agg,d,co,selected,period,taxRows,socialRows,taxTotal,socialTotal,grand:taxTotal+socialTotal,warningPeriod};
}
function taxFormalBody(data){
 return `<table class="doc-table tax-debt-only"><thead><tr><th>VERGİ ÖHDƏLİYİ</th><th>BORC (AZN)</th></tr></thead><tbody>
 ${data.taxRows.map(r=>`<tr><td>${esc(r.label)}</td><td class="num">${r.amount.toFixed(2)}</td></tr>`).join('')}
 <tr class="subtotal"><td>CƏMİ VERGİ BORCU</td><td class="num">${data.taxTotal.toFixed(2)}</td></tr>
 <tr class="section-title"><td colspan="2">DSMF ÖHDƏLİKLƏRİ</td></tr>
 ${data.socialRows.map(r=>`<tr><td>${esc(r.label)}</td><td class="num">${r.amount.toFixed(2)}</td></tr>`).join('')}
 <tr class="subtotal"><td>CƏMİ DSMF ÖHDƏLİKLƏRİ</td><td class="num">${data.socialTotal.toFixed(2)}</td></tr>
 </tbody><tfoot><tr><td>CƏMİ VERGİ VƏ CƏMİ DSMF BORCU</td><td class="num">${data.grand.toFixed(2)}</td></tr></tfoot></table>`;
}
function sealMarkup(src=state.sealPng){return src?`<div class="seal-holder"><img class="seal-image" src="${src}" alt="Möhür"></div><small>Möhür</small>`:`<div class="seal-placeholder">M.Y.</div><small>Möhür yeri</small>`}
function formalFooter(){
 return `<table class="doc-signatures"><tr><td><b>${signerLabel()}:</b><div class="sig-line">${esc(state.managerName||'')}</div><small>Ad, soyad / imza</small></td><td class="seal-box">${sealMarkup()}</td><td><b>Hazırladı:</b><div class="sig-line">${esc(state.preparedBy||'')}</div><small>Ad, soyad / imza</small></td></tr></table>`;
}
function formalStyles(landscape=true){return `<style>
 @page{size:${landscape?'A4 landscape':'A4 portrait'};margin:5mm}
 *{box-sizing:border-box}
 html,body{margin:0;padding:0;background:#fff;color:#111;font-family:Arial,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}
 body{font-size:10px;width:${landscape?'287mm':'200mm'}}
 .doc-wrap{width:100%;max-width:100%;margin:0 auto;overflow:visible}.doc-wrap.payroll,.doc-wrap.timesheet{min-height:120mm}
 .doc-header{text-align:center;border-bottom:2px solid #0f3b75;padding-bottom:4px;margin-bottom:5px}
 .doc-brand{font-size:10px;letter-spacing:1.4px;color:#64748b;font-weight:700}
 .doc-header h1{font-size:20px;line-height:1.05;color:#0f3b75;margin:2px 0}
 .doc-subtitle{font-size:10px;color:#475569}
 .doc-meta{width:100%;border-collapse:collapse;margin:4px 0 6px;table-layout:fixed}
 .doc-meta td{border:1px solid #94a3b8;padding:3px;background:#f7fafd;font-size:10px;overflow-wrap:anywhere}
 .doc-meta td:nth-child(odd){width:12%;background:#e7eff9;color:#0f3b75}
 .doc-table{width:100%!important;max-width:100%!important;border-collapse:collapse;table-layout:fixed}
 .doc-table th{background:#0f3b75;color:#fff;border:1px solid #0e386f;padding:2px 1px;text-align:center;font-size:10px;line-height:1.08;white-space:normal;overflow-wrap:anywhere;word-break:break-word}
 .doc-table td{border:1px solid #94a3b8;padding:2px 1px;text-align:center;vertical-align:middle;font-size:10px;line-height:1.1;white-space:normal;overflow-wrap:anywhere;word-break:break-word}
 .doc-table td:nth-child(2){text-align:left}
 .doc-table tfoot td{font-weight:700;background:#e7eff9}
 .doc-wrap.payroll .doc-table th,.doc-wrap.payroll .doc-table td{font-size:10px;padding:3px 2px;line-height:1.1;height:8mm}
 .doc-wrap.payroll .doc-table th:nth-child(1),.doc-wrap.payroll .doc-table td:nth-child(1){width:2%}
 .doc-wrap.payroll .doc-table th:nth-child(2),.doc-wrap.payroll .doc-table td:nth-child(2){width:10%}
 .doc-wrap.payroll .doc-table th:nth-child(3),.doc-wrap.payroll .doc-table td:nth-child(3){width:4%}
 .doc-wrap.payroll .doc-table th:nth-child(4),.doc-wrap.payroll .doc-table td:nth-child(4){width:4.5%}
 .doc-wrap.payroll .doc-table th:nth-child(5),.doc-wrap.payroll .doc-table td:nth-child(5){width:4%}
 .doc-wrap.payroll .doc-table th:nth-child(6),.doc-wrap.payroll .doc-table td:nth-child(6){width:2.8%}
 .doc-wrap.payroll .doc-table th:nth-child(7),.doc-wrap.payroll .doc-table td:nth-child(7){width:4.2%}
 .doc-wrap.timesheet .doc-table th,.doc-wrap.timesheet .doc-table td{font-size:10px;padding:3px 2px;line-height:1.1;height:8mm}
 .doc-wrap.timesheet .doc-table th:nth-child(1),.doc-wrap.timesheet .doc-table td:nth-child(1){width:1.8%}
 .doc-wrap.timesheet .doc-table th:nth-child(2),.doc-wrap.timesheet .doc-table td:nth-child(2){width:11%}
 .doc-wrap.timesheet .doc-table th:nth-child(3),.doc-wrap.timesheet .doc-table td:nth-child(3){width:4.5%}
 .doc-wrap.timesheet .doc-table th:nth-child(4),.doc-wrap.timesheet .doc-table td:nth-child(4){width:3.8%}
 .doc-wrap.timesheet .doc-table th:nth-child(5),.doc-wrap.timesheet .doc-table td:nth-child(5){width:3.5%}
 .doc-wrap.timesheet .doc-table th:nth-child(6),.doc-wrap.timesheet .doc-table td:nth-child(6){width:2.8%}
 .doc-wrap.timesheet .doc-table th:nth-child(7),.doc-wrap.timesheet .doc-table td:nth-child(7){width:5.2%}
 .doc-signatures{width:100%;border-collapse:collapse;margin-top:12mm;page-break-inside:avoid}
 .doc-signatures td{width:40%;padding:4px 10px;vertical-align:bottom;text-align:left;font-size:10px}
 .doc-signatures .seal-box{width:20%;text-align:center}
 .seal-holder{width:35mm;height:35mm;display:flex;align-items:center;justify-content:center;margin:auto}.seal-image{width:35mm;height:35mm;object-fit:contain;display:block}.seal-placeholder{width:35mm;height:35mm;border:1px dashed #64748b;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:auto;font-weight:bold;color:#64748b}
 .sig-line{height:23px;border-bottom:1px solid #111;margin-top:4px;display:flex;align-items:flex-end;padding-bottom:2px}
 .doc-signatures small{display:block;margin-top:2px;color:#64748b;font-size:10px}
 .notice{margin-top:6px;border:1px solid #eab308;background:#fff7cc;padding:7px;font-size:10px;color:#c00000;font-weight:700}
 .tax-debt-only th:first-child,.tax-debt-only td:first-child{width:72%;text-align:left}
 .tax-debt-only th:last-child,.tax-debt-only td:last-child{width:28%}
 .tax-debt-only .section-title td{background:#e7eff9;color:#0f3b75;font-weight:700;text-align:left}
 .tax-debt-only .subtotal td{background:#eff4fb;font-weight:700}
 .tax-debt-only tfoot td{background:#0f3b75;color:#fff;font-weight:700}
 .num{mso-number-format:"0.00";text-align:right!important}
 @media print{
   html,body{width:${landscape?'287mm':'200mm'};min-width:${landscape?'287mm':'200mm'};height:auto;overflow:visible}
   .doc-wrap{width:100%!important;max-width:100%!important;transform:none!important;zoom:1!important}
   button{display:none!important}
 }
 </style>`}
function buildFormalDocument(title,tableId,opts={}){
 const table=document.getElementById(tableId).cloneNode(true);table.className='doc-table';
 table.querySelectorAll('button,input,select').forEach(el=>el.remove());
 const subtitle=opts.subtitle||'';
 const kind=tableId==='payrollTable'?'payroll':tableId==='timesheetTable'?'timesheet':tableId==='leaveTable'?'leave':'generic';
 return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${formalStyles(opts.landscape!==false)}</head><body><div class="doc-wrap ${kind}">${formalHeader(title,subtitle)}${table.outerHTML}${opts.notice?`<div class="notice">${opts.notice}</div>`:''}${formalFooter()}</div></body></html>`;
}
function fitPrintWindow(w){
 try{
  const wrap=w.document.querySelector('.doc-wrap');
  if(!wrap)return;
  const maxWidth=(287/25.4)*96;
  const natural=Math.max(wrap.scrollWidth,wrap.getBoundingClientRect().width);
  if(natural>maxWidth+2){
    const scale=Math.max(.55,Math.min(1,maxWidth/natural));
    wrap.style.zoom=String(scale);
  }
 }catch(e){}
}
function printFormal(title,tableId,opts={}){const w=window.open('','_blank');w.document.write(buildFormalDocument(title,tableId,opts));w.document.close();setTimeout(()=>{fitPrintWindow(w);w.focus();w.print()},700)}
function downloadFormalXls(title,tableId,file,opts={}){const html=buildFormalDocument(title,tableId,opts),blob=new Blob(['\ufeff'+html],{type:'application/vnd.ms-excel'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=file+'.xls';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}

function exportTaxFormalExcel(){
 const c=currentCompany(),data=taxReportData(),body=taxFormalBody(data);
 const notice=`Salam, ${data.warningPeriod} DSMF və vergi öhdəlikləri. Diqqət! Öhdəliklər 5 iş günü içində ödənilmədiyi halda bankınıza sərəncam daxil olacaq.`;
 const html=`<!doctype html><html><head><meta charset="utf-8">${formalStyles(true)}</head><body><div class="doc-wrap">${formalHeaderForPeriod('VERGİ VƏ DSMF ÖHDƏLİKLƏRİ',data.period)}${body}<div class="notice">${notice}</div>${formalFooter()}</div></body></html>`;
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+html],{type:'application/vnd.ms-excel'}));a.download=`Vergi_DSMF_${c.voen}_secilmis_dovrler.xls`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)
}
function printTaxFormal(){
 const data=taxReportData(),body=taxFormalBody(data);
 const notice=`Salam, ${data.warningPeriod} DSMF və vergi öhdəlikləri. Diqqət! Öhdəliklər 5 iş günü içində ödənilmədiyi halda bankınıza sərəncam daxil olacaq.`;
 const w=window.open('','_blank');w.document.write(`<!doctype html><html><head><meta charset="utf-8">${formalStyles(true)}</head><body><div class="doc-wrap">${formalHeaderForPeriod('VERGİ VƏ DSMF ÖHDƏLİKLƏRİ',data.period)}${body}<div class="notice">${notice}</div>${formalFooter()}</div></body></html>`);w.document.close();setTimeout(()=>{fitPrintWindow(w);w.focus();w.print()},700)
}
function tableHtml(title,tableId){const c=currentCompany(),table=document.getElementById(tableId);return `<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Arial;padding:24px;color:#0b1c3f}h1{text-align:center;color:#0f3b75}p{text-align:center}table{border-collapse:collapse;width:100%;font-size:11px}th{background:#0f3b75;color:white}th,td{border:1px solid #cbd5e1;padding:6px;text-align:left}.meta{display:flex;justify-content:space-between;background:#eef4fb;padding:12px;margin:15px 0}.num{text-align:right}</style></head><body><h1>${title}</h1><p>${esc(c.name)}</p><div class="meta"><b>VÖEN: ${esc(c.voen)}</b><b>${periodText()}</b></div>${table.outerHTML}</body></html>`}
function downloadXls(title,tableId,file){const blob=new Blob(['\ufeff'+tableHtml(title,tableId)],{type:'application/vnd.ms-excel'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=file+'.xls';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function printSection(sectionId,title){const w=window.open('','_blank');const c=currentCompany();let body=sectionId==='taxPrintable'?document.getElementById(sectionId).innerHTML:tableHtml(title,sectionId).match(/<body>([\s\S]*)<\/body>/)[1];w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><link rel="stylesheet" href="styles.css"><style>body{padding:24px;background:white}.report-toolbar,button{display:none!important}</style></head><body><div class="formal-report-title"><h2>${title}</h2><p>${esc(c.name)} · VÖEN ${esc(c.voen)} · ${periodText()}</p></div>${body}</body></html>`);w.document.close();setTimeout(()=>{w.focus();w.print()},500)}
function exportTaxExcel(){const c=currentCompany(),d=currentDebts(),co=computedObligations(),rows=[['VERGİ ÖDƏYİCİSİ',c.name],['VÖEN',c.voen],['DÖVR',periodText()],[],['ÖHDƏLİYİN ADI','HESABLANMIŞ','BORC','YEKUN'],...TAX_KEYS.map(([k,l])=>[l,num(co[k]),num(d[k]),num(co[k])+num(d[k])]),['DSMF ÖHDƏLİKLƏRİ'],...SOCIAL_KEYS.map(([k,l])=>[l,num(co[k]),num(d[k]),num(co[k])+num(d[k])])];const html=`<table>${rows.map(r=>'<tr>'+r.map(v=>`<td>${esc(v)}</td>`).join('')+'</tr>').join('')}</table>`,a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+html],{type:'application/vnd.ms-excel'}));a.download=`Vergi_DSMF_${c.voen}_${state.year}_${state.month+1}.xls`;a.click()}


function currentVvbRows(){
 return periodEmployees().map(e=>{const c=calc(e);return {name:e.name||'',fin:e.fin||'',base:e.base||'',factDays:num(c.fd),total:num(c.total)}})
}
function archivedVvbRows(a){
 if(Array.isArray(a?.vvbRows))return a.vvbRows;
 const doc=new DOMParser().parseFromString(String(a?.payrollHtml||''),'text/html');
 return [...doc.querySelectorAll('tbody tr')].map(tr=>{const td=[...tr.cells].map(x=>x.textContent.trim());return {name:td[1]||'',fin:td[2]||'',base:td[6]||'',factDays:num(td[8]),total:num(td[14])}}).filter(x=>x.name||x.fin)
}
function vvbQuarterMonths(){const start=(Math.max(1,Math.min(4,state.quarter))-1)*3;return [start,start+1,start+2]}
function vvbMonthRows(year,month){
 if(year===state.year&&month===state.month)return currentVvbRows();
 const a=monthlyArchiveStore()[archiveKeyFor(currentCompany(),year,month)];
 return a?archivedVvbRows(a):[];
}
function normalizeVvbKey(r){return norm(r.fin)||norm(r.name)}
async function getVvbTemplateBuffer(){
 if(state.vvbTemplateData){const r=await fetch(state.vvbTemplateData);return r.arrayBuffer()}
 const r=await fetch('vvb-template.xlsx');if(!r.ok)throw new Error('VVB nümunə faylı tapılmadı');return r.arrayBuffer()
}
async function downloadVvb(){
 try{
  const company=currentCompany();if(!company.voen){toast('Əvvəl şirkəti seçin');return}
  const months=vvbQuarterMonths(),monthData=months.map(m=>vvbMonthRows(state.year,m)),missing=months.filter((m,i)=>!monthData[i].length);
  if(missing.length){toast(`Əvvəl ${missing.map(m=>AZ_MONTHS[m]).join(', ')} ayını hesablayıb Yadda saxla edin`);return}
  const maps=monthData.map(rows=>new Map(rows.map(r=>[normalizeVvbKey(r),r]))),all=new Map();monthData.flat().forEach(r=>{const k=normalizeVvbKey(r);if(k&&!all.has(k))all.set(k,r)});
  const blob=await VVBXlsx.generate(await getVvbTemplateBuffer(),[...all.entries()],maps),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`VVB_${company.voen}_${state.year}_${state.quarter}_RUB.xlsx`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500);toast('VVB cədvəli hazırlandı')
 }catch(e){console.error(e);toast('VVB hazırlanmadı: '+e.message)}
}
function updateHeaderActions(pageId){const b=$('#vvbDownloadBtn');if(b)b.hidden=pageId!=='payroll'}
function renderVvbTemplateStatus(){const el=$('#vvbTemplateStatus');if(el)el.textContent=state.vvbTemplateName?`${state.vvbTemplateName} aktivdir`:'Standart nümunə aktivdir'}

function exportCSV(){downloadFormalXls('HESABLAMA ÖDƏMƏ CƏDVƏLİ','payrollTable',`Hesablama_${AZ_MONTHS[state.month]}_${state.year}`,{subtitle:'Əmək haqqı, tutulmalar və ödənişlər üzrə hesabat'})}
function serializeState(){return {...state,contracts:state.contracts.map(x=>({...x,start:x.start?.toISOString(),baseStart:x.baseStart?.toISOString(),effectiveStart:x.effectiveStart?.toISOString(),contractEnd:x.contractEnd?.toISOString()})),employees:state.employees.map(x=>({...x,start:x.start?.toISOString(),end:x.end?.toISOString(),employmentPeriods:(x.employmentPeriods||[]).map(p=>({...p,start:p.start?.toISOString(),end:p.end?.toISOString()}))})),terminations:state.terminations.map(x=>({...x,start:x.start?.toISOString(),end:x.end?.toISOString()})),outgoing:state.outgoing.map(x=>({...x,date:x.date?.toISOString()}))}}

function monthlyArchiveStore(){try{return JSON.parse(localStorage.getItem('eh_monthly_archives_v2')||'{}')}catch(e){return {}}}
function saveMonthlyArchiveStore(x){localStorage.setItem('eh_monthly_archives_v2',JSON.stringify(x))}
function archiveKeyFor(c=currentCompany(),year=state.year,month=state.month){return `${c.voen}|${year}|${month}`}
function currentTaxSnapshot(){const d={...currentDebts()},co={...computedObligations()},p=payrollSums();return {computed:co,debts:d,fund:num(p.fund)}}
function saveMonthlyArchive(){
 const c=currentCompany(); if(!c.voen){toast('Əvvəl şirkət və ya fərdi sahibkar seçin');return}
 renderPayroll();renderTimesheet();
 const store=monthlyArchiveStore(),key=archiveKeyFor(c,state.year,state.month),prev=store[key]||{};
 store[key]={id:key,company:{...c},org:state.org,year:state.year,month:state.month,quarter:state.quarter,period:`${AZ_MONTHS[state.month]} ${state.year} · ${state.quarter} RÜB`,savedAt:new Date().toISOString(),selected:!!prev.selected,managerName:state.managerName||'',preparedBy:state.preparedBy||'',sealPng:state.sealPng||'',payrollHtml:$('#payrollTable')?.outerHTML||'',timesheetHtml:$('#timesheetTable')?.outerHTML||'',vvbRows:currentVvbRows(),tax:currentTaxSnapshot()};
 saveMonthlyArchiveStore(store);renderArchiveLists();renderTax();
}
function archivesForCurrentCompany(){const c=currentCompany();return Object.values(monthlyArchiveStore()).filter(a=>a.company?.voen===c.voen).sort((a,b)=>a.year-b.year||a.month-b.month)}
function renderArchiveLists(){
 const list=archivesForCurrentCompany();
 const make=(kind)=>list.length?list.map(a=>`<div class="archive-row"><input type="checkbox" data-archive-select="${esc(a.id)}" ${a.selected?'checked':''} title="Vergi-DSMF cəminə daxil et"><div class="archive-info"><b>${esc(AZ_MONTHS[a.month])} ${a.year} · ${a.quarter} RÜB</b><small>${esc(a.company.name)} · VÖEN ${esc(a.company.voen)} · ${new Date(a.savedAt).toLocaleString('az-AZ')}</small></div><button class="small" data-archive-print="${esc(a.id)}" data-kind="${kind}">🖨 Print</button><button class="small danger" data-archive-delete="${esc(a.id)}">Sil</button></div>`).join(''):'<div class="archive-empty">Hələ aylıq arxiv yoxdur. Dövrü hesablayıb “Yadda saxla” düyməsini vurun.</div>';
 if($('#payrollArchiveList'))$('#payrollArchiveList').innerHTML=make('payroll');
 if($('#timesheetArchiveList'))$('#timesheetArchiveList').innerHTML=make('timesheet');
 const selected=list.filter(a=>a.selected);if($('#taxSelectedMonths'))$('#taxSelectedMonths').innerHTML=selected.length?selected.map(a=>`<span class="month-chip">${esc(AZ_MONTHS[a.month])} ${a.year}</span>`).join(''):'<span class="month-chip empty">Ay seçilməyib — cari dövr göstərilir</span>';
}
function setArchiveSelected(id,checked){const store=monthlyArchiveStore();if(store[id]){store[id].selected=checked;saveMonthlyArchiveStore(store);renderArchiveLists();renderTax()}}
function deleteMonthlyArchive(id){const store=monthlyArchiveStore();if(!store[id])return;if(!confirm(`${store[id].period} arxivini silmək istəyirsiniz?`))return;delete store[id];saveMonthlyArchiveStore(store);renderArchiveLists();renderTax();toast('Aylıq arxiv silindi')}
function archivedFormalHeader(a,title,subtitle=''){return `<div class="doc-header"><div class="doc-brand">ƏMƏK HAQQI VƏ HESABATLAR</div><h1>${esc(title)}</h1>${subtitle?`<div class="doc-subtitle">${esc(subtitle)}</div>`:''}</div><table class="doc-meta"><tr><td><b>Vergi ödəyicisi:</b></td><td>${esc(a.company.name)}</td><td><b>VÖEN:</b></td><td>${esc(a.company.voen)}</td></tr><tr><td><b>Dövr:</b></td><td>${esc(a.period)}</td><td><b>Sənəd tarixi:</b></td><td>${documentDate()}</td></tr></table>`}
function archivedFormalFooter(a){const label=a.org==='physical'?'Fərdi sahibkar':'Rəhbər';return `<table class="doc-signatures"><tr><td><b>${label}:</b><div class="sig-line">${esc(a.managerName||'')}</div><small>Ad, soyad / imza</small></td><td class="seal-box">${sealMarkup(a.sealPng||'')}</td><td><b>Hazırladı:</b><div class="sig-line">${esc(a.preparedBy||'')}</div><small>Ad, soyad / imza</small></td></tr></table>`}
function printMonthlyArchive(id,kind){const a=monthlyArchiveStore()[id];if(!a)return;const isPayroll=kind==='payroll',title=isPayroll?'HESABLAMA ÖDƏMƏ CƏDVƏLİ':'TABEL CƏDVƏLİ',subtitle=isPayroll?'Əmək haqqı, tutulmalar və ödənişlər üzrə hesabat':'İş vaxtının uçotu — hər iş günü 8 saat',html=isPayroll?a.payrollHtml:a.timesheetHtml,cls=isPayroll?'payroll':'timesheet';const w=window.open('','_blank');w.document.write(`<!doctype html><html><head><meta charset="utf-8">${formalStyles(true)}</head><body><div class="doc-wrap ${cls}">${archivedFormalHeader(a,title,subtitle)}${String(html).replace('<table','<table class="doc-table"')}${archivedFormalFooter(a)}</div></body></html>`);w.document.close();setTimeout(()=>{fitPrintWindow(w);w.focus();w.print()},700)}
function selectedArchiveTaxAggregate(){const selected=archivesForCurrentCompany().filter(a=>a.selected);if(!selected.length)return null;const computed={},debts={};[...TAX_KEYS,...SOCIAL_KEYS].forEach(([k])=>{computed[k]=0;debts[k]=0});let fund=0;for(const a of selected){fund+=num(a.tax?.fund);for(const [k] of [...TAX_KEYS,...SOCIAL_KEYS]){computed[k]+=num(a.tax?.computed?.[k]);debts[k]+=num(a.tax?.debts?.[k])}}return {computed,debts,fund,selected}}
function saveState(){const data=serializeState();localStorage.setItem('eh_state_v2',JSON.stringify(data));saveMonthlyArchive();toast('Məlumatlar yadda saxlandı və aylıq arxivə əlavə edildi')}
function resetInterface(){
 if(!confirm('Cari ekrandakı məlumatlar sıfırlansın? Arxivdə saxlanmış hesabatlar silinməyəcək.'))return;
 const now=new Date();Object.assign(state,{files:{},companies:[],contracts:[],expiredContracts:[],terminations:[],employees:[],calendar:{...calendarDefaults()},calendarMeta:{},outgoing:[],cash:[],debts:{},selectedCompany:'',year:now.getFullYear(),month:now.getMonth(),quarter:Math.floor(now.getMonth()/3)+1,org:'legal',leaveRecords:[],managerName:'',preparedBy:'',sealPng:'',leaveDraft:{employee:'',position:'ordinary',year:now.getFullYear(),quarter:Math.floor(now.getMonth()/3)+1,month:now.getMonth(),startDate:'',income:0,used:0,baseDays:21,intervals:[]}});
 localStorage.removeItem('eh_state_v2');
 $$('input[type=file]').forEach(x=>x.value='');['companies','contracts','calendar','terminations','tabel','outgoing','cash','signseal','expiredContracts'].forEach(k=>{const el=$('#'+k+'Status');if(el)el.textContent='Fayl seçilməyib'});if($('#seniorityStatus'))$('#seniorityStatus').textContent='Fayl seçilməyib';
 $('#orgType').value='legal';$('#yearSelect').value=state.year;$('#monthSelect').value=state.month;$('#quarterSelect').value=state.quarter+' RÜB';renderAll();toast('Cari interfeys sıfırlandı — arxiv qorundu')
}
function loadState(){try{const d=JSON.parse(localStorage.getItem('eh_state_v2')||'null');if(!d)return;Object.assign(state,d);state.contracts=(d.contracts||[]).map(x=>({...x,start:x.start?new Date(x.start):null,baseStart:x.baseStart?new Date(x.baseStart):null,effectiveStart:x.effectiveStart?new Date(x.effectiveStart):null,contractEnd:x.contractEnd?new Date(x.contractEnd):null}));state.expiredContracts=(d.expiredContracts||[]).map(x=>({...x,start:x.start?new Date(x.start):null,baseStart:x.baseStart?new Date(x.baseStart):null,effectiveStart:x.effectiveStart?new Date(x.effectiveStart):null,contractEnd:x.contractEnd?new Date(x.contractEnd):null}));state.employees=(d.employees||[]).map(x=>({...x,start:x.start?new Date(x.start):null,end:x.end?new Date(x.end):null,employmentPeriods:(x.employmentPeriods||[]).map(p=>({...p,start:p.start?new Date(p.start):null,end:p.end?new Date(p.end):null}))}));state.terminations=(d.terminations||[]).map(x=>({...x,start:x.start?new Date(x.start):null,end:x.end?new Date(x.end):null}));state.outgoing=(d.outgoing||[]).map(x=>({...x,date:x.date?new Date(x.date):null}))}catch(e){console.warn(e)}}
const nav=[['dashboard','⌂','Ümumi'],['leave','✹','Məzuniyyət hesablanması'],['payroll','▦','Hesablama cədvəli'],['timesheet','▦','Tabel cədvəli'],['calendarPage','▣','Təqvim'],['taxDebts','₼','Vergi borcları'],['tax','⌁','Vergi-DSMF yükü'],['reports','◫','Hesabatlar']];$('#nav').innerHTML=nav.map((x,i)=>`<button class="nav-btn ${i?'':'active'}" data-page="${x[0]}"><span>${x[1]}</span>${x[2]}</button>`).join('');$$('.nav-btn').forEach(b=>b.onclick=()=>{$$('.nav-btn,.page').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#'+b.dataset.page).classList.add('active');$('#pageTitle').textContent=b.textContent.trim();updateHeaderActions(b.dataset.page)});updateHeaderActions('dashboard');
loadState();for(let y=2020;y<=2035;y++)$('#yearSelect').insertAdjacentHTML('beforeend',`<option ${y===state.year?'selected':''}>${y}</option>`);AZ_MONTHS.forEach((m,i)=>$('#monthSelect').insertAdjacentHTML('beforeend',`<option value="${i}" ${i===state.month?'selected':''}>${m}</option>`));$('#quarterSelect').value=state.quarter+' RÜB';$('#quarterSelect').disabled=true;$('#reportQuarterSelect').disabled=true;$('#leaveQuarter').disabled=true;$('#orgType').value=state.org;for(let y=2020;y<=2035;y++)$('#leaveYear').insertAdjacentHTML('beforeend',`<option value="${y}">${y}</option>`);AZ_MONTHS.forEach((m,i)=>$('#leaveMonth').insertAdjacentHTML('beforeend',`<option value="${i}">${m}</option>`));
$$('input[type=file]').forEach(inp=>inp.onchange=async()=>{try{const f=inp.files[0];if(!f)return;if(inp.dataset.type==='vvbTemplate'){state.vvbTemplateData=await fileToDataUrl(f);state.vvbTemplateName=f.name;persistStateSilent();renderVvbTemplateStatus();toast('VVB nümunəsi yadda saxlandı');return}await readUpload(f,inp.dataset.type);const st=$('#'+inp.dataset.type+'Status');if(st&&inp.dataset.type!=='signseal')st.textContent=f.name;if(inp.dataset.type==='signseal'){renderSealStatus();persistStateSilent();toast('Möhür şəffaf PNG-yə çevrildi və sənədlərə əlavə edildi')}else toast(`${f.name} analiz edildi`)}catch(e){console.error(e);toast('Fayl oxunmadı: '+e.message)}});
$('#orgType').onchange=e=>{state.org=e.target.value;state.selectedCompany='';renderAll()};$('#companySelect').onchange=e=>{state.selectedCompany=e.target.value;renderAll()};$('#yearSelect').onchange=e=>{state.year=+e.target.value;renderAll()};$('#monthSelect').onchange=e=>{state.month=+e.target.value;state.quarter=Math.floor(state.month/3)+1;$('#quarterSelect').value=state.quarter+' RÜB';renderAll()};$('#quarterSelect').onchange=e=>{state.quarter=Math.floor(state.month/3)+1;e.target.value=state.quarter+' RÜB';renderAll()};$('#managerName').oninput=e=>{state.managerName=e.target.value};$('#preparedBy').oninput=e=>{state.preparedBy=e.target.value};
$('#reportOrgType').onchange=e=>{state.org=e.target.value;state.selectedCompany='';$('#orgType').value=state.org;renderAll()};$('#reportCompanySelect').onchange=e=>{state.selectedCompany=e.target.value;$('#companySelect').value=state.selectedCompany;renderAll()};$('#reportYearSelect').onchange=e=>{state.year=+e.target.value;$('#yearSelect').value=state.year;renderAll()};$('#reportQuarterSelect').onchange=e=>{state.quarter=Math.floor(state.month/3)+1;e.target.value=state.quarter;$('#quarterSelect').value=state.quarter+' RÜB';renderAll()};$('#reportMonthSelect').onchange=e=>{state.month=+e.target.value;state.quarter=Math.floor(state.month/3)+1;$('#monthSelect').value=state.month;$('#quarterSelect').value=state.quarter+' RÜB';renderAll()};
$('#generalTable').onchange=e=>{const i=+e.target.dataset.i,k=e.target.dataset.k;if(Number.isInteger(i)&&k){state.employees[i][k]=k==='finalEnabled'?e.target.checked:['absent','final','vacation','bonus','aid'].includes(k)?num(e.target.value):e.target.value;renderAll()}};
// Vergi borcu xanalarında yazı zamanı interfeysi yenidən qurma: fokus itməsin.
$('#taxDebts').oninput=e=>{const k=e.target.dataset.debt;if(!k)return;let raw=String(e.target.value??'').replace(/[^0-9,.-]/g,'');const firstComma=raw.indexOf(','),firstDot=raw.indexOf('.');if(firstComma>=0&&firstDot>=0){const decimalPos=Math.min(firstComma,firstDot);raw=raw.slice(0,decimalPos+1)+raw.slice(decimalPos+1).replace(/[,.]/g,'')}else{const sep=firstComma>=0?',':firstDot>=0?'.':'';if(sep){const pos=raw.indexOf(sep);raw=raw.slice(0,pos+1)+raw.slice(pos+1).replace(/[,.]/g,'')}}e.target.value=raw;currentDebts()[k]=raw;$('#manualDebtTotal').textContent=money(TAX_KEYS.reduce((a,[key])=>a+num(currentDebts()[key]),0))};
$('#taxDebts').onchange=e=>{const k=e.target.dataset.debt;if(!k)return;currentDebts()[k]=e.target.value===''?'':num(e.target.value);persistStateSilent();renderDebtPage();renderTax()};
$('#taxDebts').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();e.target.blur()}};
$('#fillBtn').onclick=()=>{rebuildEmployees();toast('Bütün cədvəllər yenidən hesablandı')};$('#exportCsv').onclick=exportCSV;$('#vvbDownloadBtn').onclick=downloadVvb;$('#saveBtn').onclick=saveState;$('#refreshBtn').onclick=resetInterface;renderVvbTemplateStatus();$('#copyTax').onclick=()=>{navigator.clipboard.writeText(`${$('#taxEntityName').innerText}\nVÖEN: ${$('#taxEntityVoen').innerText}\n${$('#taxDetails').innerText}\n${$('#taxWarning').innerText}`);toast('Vergi yükü kopyalandı')};

$('#taxExcel').onclick=exportTaxFormalExcel;$('#taxPdf').onclick=printTaxFormal;
$('#timesheetExcel').onclick=()=>downloadFormalXls('TABEL CƏDVƏLİ','timesheetTable',`Tabel_${AZ_MONTHS[state.month]}_${state.year}`,{subtitle:'İş vaxtının uçotu — hər iş günü 8 saat'});$('#timesheetPrint').onclick=()=>printFormal('TABEL CƏDVƏLİ','timesheetTable',{subtitle:'İş vaxtının uçotu — hər iş günü 8 saat'});
$('#payrollPrint').onclick=()=>printFormal('HESABLAMA ÖDƏMƏ CƏDVƏLİ','payrollTable',{subtitle:'Əmək haqqı, tutulmalar və ödənişlər üzrə hesabat'});
$('#leavePrint').onclick=()=>printFormal('MƏZUNİYYƏT VƏ SON HAQQ-HESAB','leaveTable',{subtitle:'Məzuniyyət haqqı və son haqq-hesab üzrə hesablamalar'});
$$('[data-report]').forEach(b=>b.onclick=()=>{const r=b.dataset.report;const target=r==='timesheet'?'timesheet':r;const nb=$(`.nav-btn[data-page="${target}"]`);if(nb)nb.click()});
$$('[data-print-report]').forEach(b=>b.onclick=()=>{const r=b.dataset.printReport;if(r==='payroll')return printFormal('HESABLAMA ÖDƏMƏ CƏDVƏLİ','payrollTable',{subtitle:'Əmək haqqı, tutulmalar və ödənişlər üzrə hesabat'});if(r==='timesheet')return printFormal('TABEL CƏDVƏLİ','timesheetTable',{subtitle:'İş vaxtının uçotu — hər iş günü 8 saat'});if(r==='leave')return printFormal('MƏZUNİYYƏT VƏ SON HAQQ-HESAB','leaveTable',{subtitle:'Məzuniyyət haqqı və son haqq-hesab üzrə hesablamalar'});if(r==='tax')return printTaxFormal()});


function syncLeaveDraft(){const d=state.leaveDraft;d.employee=$('#leaveEmployee').value;d.position=$('#leavePosition').value;d.year=+$('#leaveYear').value;d.quarter=+$('#leaveQuarter').value;d.month=+$('#leaveMonth').value;d.startDate=$('#leaveStartDate').value||'';const sd=parseDate(d.startDate);if(sd){d.year=sd.getFullYear();d.month=sd.getMonth();d.quarter=Math.floor(d.month/3)+1;$('#leaveYear').value=d.year;$('#leaveMonth').value=d.month;$('#leaveQuarter').value=d.quarter}d.income=trailing12Income(draftEmployee(),d.year,d.month);d.baseDays=d.position==='specialist'?30:21;d.used=seniorityBonus(intervalDays(leaveSeniorityIntervals()))}
['leaveEmployee','leavePosition','leaveYear','leaveQuarter','leaveMonth','leaveStartDate'].forEach(id=>$('#'+id).onchange=()=>{syncLeaveDraft();if(id==='leaveMonth'){state.leaveDraft.quarter=Math.floor(state.leaveDraft.month/3)+1}renderLeave()});
$('#addStaj').onclick=()=>{syncLeaveDraft();const s=parseDate($('#stajStart').value),e=parseDate($('#stajEnd').value);if(!s||!e||e<s){toast('Tarix aralığını düzgün daxil edin');return}state.leaveDraft.intervals.push({start:s.toISOString(),end:e.toISOString()});$('#stajStart').value='';$('#stajEnd').value='';renderLeave()};
$('#stajList').onclick=e=>{const i=e.target.dataset.delStaj;if(i!==undefined){state.leaveDraft.intervals.splice(+i,1);renderLeave()}};
$('#leaveTable tbody').onclick=e=>{const raw=e.target.dataset.delLeave;if(raw===undefined)return;const i=+raw,rec=state.leaveRecords[i];if(!rec)return;if(!confirm(`${rec.name} — ${AZ_MONTHS[rec.month]} ${rec.year} məzuniyyət hesablaması silinsin?`))return;state.leaveRecords.splice(i,1);syncEmployeeVacationAfterLeaveDelete(rec.employee);persistStateSilent();renderAll();toast('Məzuniyyət hesablaması silindi')};
$('#seniorityFile').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;$('#seniorityStatus').textContent=f.name;const wb=await XLSXMini.read(f),rows=Object.values(wb)[0]||[];let found=0;for(const r of rows){const dates=(r||[]).map(parseDate).filter(Boolean);for(let i=0;i+1<dates.length;i+=2){if(dates[i+1]>=dates[i]){state.leaveDraft.intervals.push({start:dates[i].toISOString(),end:dates[i+1].toISOString()});found++}}}toast(found?`${found} staj aralığı əlavə edildi`:'Faylda tarix aralığı tapılmadı');renderLeave()}catch(err){console.error(err);toast('Staj faylı oxunmadı: '+err.message)}};
$('#applyLeave').onclick=()=>{syncLeaveDraft();const e=draftEmployee(),c=leaveDraftCalc();if(!e){toast('İşçi seçin');return}if(!c.start){toast('Məzuniyyətə başlama tarixini seçin');return}if(!c.leaveDates.length){toast('Məzuniyyət tarixləri hesablana bilmədi');return}
 const rec={employee:employeeKey(e),name:e.name,position:state.leaveDraft.position,year:c.start.getFullYear(),quarter:Math.floor(c.start.getMonth()/3)+1,month:c.start.getMonth(),startDate:dateKeyLocal(c.start),endDate:dateKeyLocal(c.end),income:state.leaveDraft.income,used:0,extraDays:c.bonus,baseDays:c.base,bonus:c.bonus,eligible:c.eligible,amount:c.amount,intervals:[...state.leaveDraft.intervals],savedAt:new Date().toISOString()};
 state.leaveRecords.push(rec);e.vacation=0;
 state.year=state.leaveDraft.year;state.month=state.leaveDraft.month;state.quarter=Math.floor(state.month/3)+1;
 $('#yearSelect').value=state.year;$('#monthSelect').value=state.month;$('#quarterSelect').value=state.quarter+' RÜB';
 renderAll();toast(`${AZ_MONTHS[state.month]} ${state.year} dövrü üzrə məzuniyyət Hesablama cədvəlinə əlavə edildi`) };
state.calendar={...calendarDefaults(),...(state.calendar||{})};
if(!localStorage.getItem('ammo_calendar_fix_v257')){Object.assign(state.calendar,Object.fromEntries(Object.entries(calendarDefaults()).filter(([k])=>k.startsWith('2026-'))));localStorage.setItem('ammo_calendar_fix_v257','1');persistStateSilent()}
state.calendarMeta=state.calendarMeta||{};renderAll();


document.addEventListener('change',e=>{const id=e.target?.dataset?.archiveSelect;if(id)setArchiveSelected(id,e.target.checked)});
document.addEventListener('click',e=>{const pb=e.target.closest?.('[data-archive-print]');if(pb){printMonthlyArchive(pb.dataset.archivePrint,pb.dataset.kind);return}const db=e.target.closest?.('[data-archive-delete]');if(db){deleteMonthlyArchive(db.dataset.archiveDelete);return}});

// AMMO V14: qarşı kompüterdən məlumat gələndə ekranı tam refresh etmədən cədvəlləri yenilə.
// İstifadəçi xana yazırsa fokus və yarımçıq mətn qorunur; yenilənmə blur-dan sonra edilir.
(()=>{
 let pendingCloudRender=false;
 function editing(){const el=document.activeElement;return !!el&&['INPUT','TEXTAREA','SELECT'].includes(el.tagName);}
 function applyCloudState(){
  if(editing()){pendingCloudRender=true;return;}
  try{loadState();renderAll();pendingCloudRender=false;toast('Bulud məlumatları yeniləndi');}catch(e){console.warn('Əməkhaqqı cloud render',e)}
 }
 window.addEventListener('ammo-cloud-updated',applyCloudState);
 document.addEventListener('focusout',()=>{if(pendingCloudRender)setTimeout(applyCloudState,120)},true);
})();
