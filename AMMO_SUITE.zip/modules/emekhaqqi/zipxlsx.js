/* Minimal local XLSX reader: ZIP + workbook XML, no external library. */
const XLSXMini=(()=>{
 const td=new TextDecoder();
 const u16=(d,o)=>d[o]|d[o+1]<<8, u32=(d,o)=>(u16(d,o)|(u16(d,o+2)<<16))>>>0;
 async function inflate(data){return new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer())}
 async function unzip(buf){const d=new Uint8Array(buf), files={};let e=d.length-22;while(e>=0&&u32(d,e)!==0x06054b50)e--;if(e<0)throw Error('ZIP formatı oxunmadı');let n=u16(d,e+10),p=u32(d,e+16);for(let i=0;i<n;i++){if(u32(d,p)!==0x02014b50)break;let method=u16(d,p+10),cs=u32(d,p+20),nl=u16(d,p+28),el=u16(d,p+30),cl=u16(d,p+32),lo=u32(d,p+42),name=td.decode(d.slice(p+46,p+46+nl));let lnl=u16(d,lo+26),lel=u16(d,lo+28),raw=d.slice(lo+30+lnl+lel,lo+30+lnl+lel+cs);files[name]=method===0?raw:await inflate(raw);p+=46+nl+el+cl}return files}
 const xml=s=>new DOMParser().parseFromString(s,'application/xml');
 const colNum=ref=>{let n=0;for(const c of ref.match(/[A-Z]+/)[0])n=n*26+c.charCodeAt(0)-64;return n-1};
 async function read(file){const f=await unzip(await file.arrayBuffer()),txt=k=>td.decode(f[k]);let shared=[];
  if(f['xl/sharedStrings.xml'])shared=[...xml(txt('xl/sharedStrings.xml')).getElementsByTagName('si')].map(si=>[...si.getElementsByTagName('t')].map(t=>t.textContent).join(''));
  const wb=xml(txt('xl/workbook.xml')),rels=xml(txt('xl/_rels/workbook.xml.rels')),rm={};[...rels.getElementsByTagName('Relationship')].forEach(x=>rm[x.getAttribute('Id')]=x.getAttribute('Target'));
  const out={};for(const sh of wb.getElementsByTagName('sheet')){let target=rm[sh.getAttribute('r:id')];if(!target)continue;target='xl/'+target.replace(/^\//,'').replace(/^xl\//,'');const doc=xml(txt(target)),rows=[];
   for(const row of doc.getElementsByTagName('row')){const arr=[];for(const c of row.getElementsByTagName('c')){const ix=colNum(c.getAttribute('r')),t=c.getAttribute('t');let v='';if(t==='inlineStr')v=[...c.getElementsByTagName('t')].map(x=>x.textContent).join('');else{const ve=c.getElementsByTagName('v')[0];v=ve?ve.textContent:'';if(t==='s'&&v!=='')v=shared[+v]??v}arr[ix]=v}rows.push(arr)}out[sh.getAttribute('name')]=rows}
  return out;
 }
 return {read};
})();
