# Tapşırıq Paneli v34 — avtomatik Firebase giriş hesabı

Bu versiyada əməkdaş yaratdıqda Firebase Authentication hesabı, Firestore əməkdaş profili və şəxsi kabinet əlaqəsi avtomatik qurulur.

## Şəbinəni mövcud qeyddən bağlamaq
1. İdarəetmə → Əməkdaşlar bölməsində `sebine` qarşısında **Düzəlt** basın.
2. Giriş e-poçtu `sebine@ammo.az` qalsın.
3. Parol sahəsinə `sebine123` yazın.
4. **Əməkdaşı yenilə** basın.
5. Sistem Firebase Authentication hesabını yaradacaq, UID-ni əməkdaş profilinə bağlayacaq və köhnə tapşırıqlardakı əməkdaş ID-sini yeni UID ilə əvəz edəcək.

Əgər Firebase-də həmin e-poçt artıq varsa, sistem yeni hesab yaratmır və məlumatları saxlayır. Belə halda Firebase-dəki hesabın UID-si ilə profil sənədinin uyğunluğunu ayrıca yoxlamaq tələb oluna bilər.
