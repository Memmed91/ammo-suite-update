# Tapşırıq Paneli v32

Bu versiyada Ana səhifəyə iki ayrıca bölmə əlavə edildi:

- Gələn tapşırıqlar — digər əməkdaşların sizə göndərdiyi tapşırıqlar.
- Göndərilən tapşırıqlar — sizin göndərdiyiniz tapşırıqlar və onların cari statusu.

Hər kartda şirkət, VÖEN, kimdən/kimə, göndərilmə tarixi, son icra tarixi, gecikmə günü, status, məzmun və son yenilənmə görünür. Kartın üzərinə klik etdikdə tam tapşırıq açılır.

## Quraşdırma
1. Köhnə Chrome uzantısını `chrome://extensions` səhifəsindən silin.
2. ZIP-i çıxarın.
3. `Load unpacked` düyməsi ilə `taskpanel_v32` qovluğunu seçin.
4. Apps Script kodunda dəyişiklik yoxdur; əvvəlki deploy ünvanı saxlanılıb.
