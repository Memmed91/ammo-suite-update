# Konsalting Tapşırıq Paneli v2.2

## Düzəliş
Bu versiya Firestore-da istifadəçi profili olmadıqda onu ilk girişdə avtomatik yaradır. `Document ... not found` xətası düzəldilib.

## Quraşdırma
1. Firebase Firestore → Rules bölməsinə `firestore.rules` məzmununu yerləşdirib **Publish** edin.
2. Firebase Storage → Rules bölməsinə `storage.rules` məzmununu yerləşdirib **Publish** edin.
3. Chrome-da köhnə uzantını silin və ya **Reload** edin.
4. `chrome://extensions` → **Load unpacked** ilə bu qovluğu seçin.
5. `memmed@ammo.az` hesabı ilə daxil olun. İlk girişdə profil avtomatik admin kimi yaradılacaq.

Authentication-dakı `memmed@ammo.az` istifadəçisini silməyin. Firestore-da yarımçıq `users/{UID}` sənədi varsa, onu silmək olar; proqram yenisini yaradacaq.
