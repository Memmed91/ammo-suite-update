const FIREBASE={apiKey:'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg',authDomain:'konsalting-79c40.firebaseapp.com',projectId:'konsalting-79c40',storageBucket:'konsalting-79c40.firebasestorage.app',messagingSenderId:'796041584153',appId:'1:796041584153:web:635c6e5eb4e153ad345488'};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const statusMap={new:'Yeni',progress:'İcraya götürülüb',done:'İcra olunub',wrong:'Yanlış tapşırıq'};
let state={currentUser:null,token:'',refreshToken:'',uid:'',users:[],companies:[],tasks:[],audioBlob:null,mediaRecorder:null,audioChunks:[],poll:null,pastedFiles:[],editingEmployeeId:'',editingCompanyId:'',selectedAssigneeIds:[],selectedCompanyIds:[],dashboardFlow:'incoming'};
const AUTH='https://identitytoolkit.googleapis.com/v1';
const FS=`https://firestore.googleapis.com/v1/projects/${FIREBASE.projectId}/databases/(default)/documents`;
const APPS_SCRIPT_URL='https://script.google.com/macros/s/AKfycbzNfq2z5uxaU1CLxjGG1gVS1K1FaiRA5dFKvmUkzDNGRz1f2qsHOVdFu3-sy4zygkZN/exec';
function toast(t,type='info',duration=4500){const el=$('#toast');if(!el)return;clearTimeout(window.__ammoToastTimer);el.textContent=t;el.className='toast show '+type;window.__ammoToastTimer=setTimeout(()=>el.classList.remove('show'),duration)}
function esc(v=''){return String(v).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]))}
function initials(n=''){return n.split(' ').filter(Boolean).map(x=>x[0]).slice(0,2).join('').toUpperCase()}
function formatDate(v){if(!v)return '-';const d=new Date(v);if(Number.isNaN(d.getTime()))return '-';const z=n=>String(n).padStart(2,'0');return `${z(d.getDate())}.${z(d.getMonth()+1)}.${d.getFullYear()} ${z(d.getHours())}:${z(d.getMinutes())}`}
function daysLate(t){const end=t.status==='done'?(t.completedAt||t.updatedAt):new Date().toISOString();return Math.max(0,Math.ceil((new Date(end)-new Date(t.dueAt))/86400000))}
function dueText(t){const d=daysLate(t);return d?`<span class="late">${d} gün gecikib</span>`:'Vaxtındadır'}
function person(id){return state.users.find(x=>x.id===id)||{name:'Naməlum',loginEmail:'',email:'',secondaryEmail:''}}
function company(id){return state.companies.find(x=>x.id===id)||{name:'Naməlum',voen:''}}
function fv(v){if(v===null)return{nullValue:null};if(Array.isArray(v))return{arrayValue:{values:v.map(fv)}};if(typeof v==='boolean')return{booleanValue:v};if(typeof v==='number')return Number.isInteger(v)?{integerValue:String(v)}:{doubleValue:v};if(typeof v==='object')return{mapValue:{fields:Object.fromEntries(Object.entries(v).map(([k,x])=>[k,fv(x)]))}};return{stringValue:String(v)}}
function un(v){if(!v)return null;if('stringValue'in v)return v.stringValue;if('integerValue'in v)return Number(v.integerValue);if('doubleValue'in v)return v.doubleValue;if('booleanValue'in v)return v.booleanValue;if('timestampValue'in v)return v.timestampValue;if('nullValue'in v)return null;if('arrayValue'in v)return(v.arrayValue.values||[]).map(un);if('mapValue'in v)return Object.fromEntries(Object.entries(v.mapValue.fields||{}).map(([k,x])=>[k,un(x)]));return null}
function docObj(d){const o=Object.fromEntries(Object.entries(d.fields||{}).map(([k,v])=>[k,un(v)]));o.id=d.name.split('/').pop();return o}
async function refreshAccessToken(){
  if(!state.refreshToken) throw new Error('Giriş sessiyası bitib. Proqramdan çıxıb yenidən daxil olun.');
  const r=await fetch(`https://securetoken.googleapis.com/v1/token?key=${FIREBASE.apiKey}`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',refresh_token:state.refreshToken})});
  const d=await r.json(); if(!r.ok) throw new Error(d.error?.message||'Giriş yenilənmədi');
  state.token=d.id_token; state.refreshToken=d.refresh_token||state.refreshToken; state.uid=d.user_id||state.uid;
  const cur=(await chrome.storage.local.get('suiteAuth')).suiteAuth||{}; await chrome.storage.local.set({suiteAuth:{...cur,idToken:state.token,refreshToken:state.refreshToken,uid:state.uid,expiresAt:Date.now()+Number(d.expires_in||3600)*1000}});
}
async function request(url,opt={},retried=false){const headers={'Content-Type':'application/json',...(opt.auth!==false&&state.token?{Authorization:`Bearer ${state.token}`}:{}) ,...(opt.headers||{})};const r=await fetch(url,{...opt,headers});const text=await r.text();let data={};try{data=text?JSON.parse(text):{}}catch{data={message:text}}if(!r.ok){const msg=data.error?.message||data.message||`HTTP ${r.status}`;if(!retried&&opt.auth!==false&&(r.status===401||String(msg).includes('UNAUTHENTICATED')||String(msg).includes('invalid authentication'))){await refreshAccessToken();return request(url,opt,true)}const err=new Error(msg);err.status=r.status;err.code=data.error?.status||data.error?.code||'';throw err}return data}
async function uploadTaskFile(taskId,file){
  // Faylları Firestore-da hissələrə bölərək saxlayırıq. Bu üsul bütün kompüterlərdə
  // işləyir və Firebase Storage bucket/rules qurulmadıqda yaranan “Not Found” xətasını aradan qaldırır.
  const packed=await fileToData(file);
  const fileId=(crypto.randomUUID?crypto.randomUUID():`${Date.now()}_${Math.random().toString(36).slice(2)}`).replaceAll('-','');
  const chunkSize=480000;
  const chunks=[];
  for(let i=0;i<packed.data.length;i+=chunkSize)chunks.push(packed.data.slice(i,i+chunkSize));
  for(let i=0;i<chunks.length;i++){
    await setDoc('taskFileChunks',`${taskId}_${fileId}_${String(i).padStart(4,'0')}`,{
      taskId,fileId,index:i,total:chunks.length,data:chunks[i],createdAt:new Date().toISOString()
    });
  }
  return {name:packed.name,type:packed.type,size:packed.size,backend:'firestoreChunks',fileId,chunks:chunks.length};
}
async function taskFileBlob(f,taskId=''){
  if(f&&f.backend==='firestoreChunks'&&f.fileId){
    const parts=[];
    for(let i=0;i<Number(f.chunks||0);i++){
      const d=await getDoc('taskFileChunks',`${taskId}_${f.fileId}_${String(i).padStart(4,'0')}`);
      if(!d||typeof d.data!=='string')throw new Error('Faylın bir hissəsi tapılmadı. Firebase qaydalarını V23 paketindəki qaydalarla yayımlayın.');
      parts.push(d.data);
    }
    const bin=atob(parts.join(''));const bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
    return new Blob([bytes],{type:f.type||'application/octet-stream'});
  }
  if(f&&f.storagePath){
    const url=`https://firebasestorage.googleapis.com/v0/b/${FIREBASE.storageBucket}/o/${encodeURIComponent(f.storagePath)}?alt=media`;
    let r=await fetch(url,{headers:{Authorization:`Bearer ${state.token}`}});if(r.status===401){await refreshAccessToken();r=await fetch(url,{headers:{Authorization:`Bearer ${state.token}`}})}
    if(!r.ok)throw new Error('Fayl açıla bilmədi');return await r.blob();
  }
  if(f&&f.data){
    const bin=atob(f.data);const bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
    return new Blob([bytes],{type:f.type||'application/octet-stream'});
  }
  throw new Error('Fayl məlumatı tapılmadı');
}
async function downloadTaskFile(f,taskId='',mode='download'){
  const blob=await taskFileBlob(f,taskId);const u=URL.createObjectURL(blob);
  if(mode==='view'){
    const w=window.open(u,'_blank');
    if(!w){const a=document.createElement('a');a.href=u;a.target='_blank';a.rel='noopener';a.click()}
    setTimeout(()=>URL.revokeObjectURL(u),120000);return;
  }
  const a=document.createElement('a');a.href=u;a.download=f.name||'fayl';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),30000);
}
async function signIn(email,password){return request(`${AUTH}/accounts:signInWithPassword?key=${FIREBASE.apiKey}`,{method:'POST',auth:false,body:JSON.stringify({email,password,returnSecureToken:true})})}
async function createAuthUser(email,password){return request(`${AUTH}/accounts:signUp?key=${FIREBASE.apiKey}`,{method:'POST',auth:false,body:JSON.stringify({email,password,returnSecureToken:true})})}
async function listCol(col){let out=[],token='';do{const q=token?`&pageToken=${encodeURIComponent(token)}`:'';const d=await request(`${FS}/${col}?pageSize=500${q}`);out.push(...(d.documents||[]).map(docObj));token=d.nextPageToken||''}while(token);return out}
async function getDoc(col,id){try{return docObj(await request(`${FS}/${col}/${id}`))}catch(e){const msg=String(e.message||'').toLowerCase();if(e.status===404||String(e.code).toUpperCase()==='NOT_FOUND'||msg.includes('not found'))return null;throw e}}
async function setDoc(col,id,obj){return request(`${FS}/${col}/${id}`,{method:'PATCH',body:JSON.stringify({fields:Object.fromEntries(Object.entries(obj).map(([k,v])=>[k,fv(v)]))})})}
async function addDoc(col,obj){const d=await request(`${FS}/${col}`,{method:'POST',body:JSON.stringify({fields:Object.fromEntries(Object.entries(obj).map(([k,v])=>[k,fv(v)]))})});return docObj(d)}
async function delDoc(col,id){return request(`${FS}/${col}/${id}`,{method:'DELETE'})}
async function saveLocalTaskFiles(taskId, attachments){
  return new Promise((resolve,reject)=>chrome.storage.local.set({['taskFiles_'+taskId]:attachments},()=>{
    const err=chrome.runtime.lastError;if(err)reject(new Error(err.message));else resolve();
  }));
}
async function getLocalTaskFiles(taskId){
  return new Promise(resolve=>chrome.storage.local.get(['taskFiles_'+taskId],r=>resolve(r['taskFiles_'+taskId]||[])));
}
async function removeLocalTaskFiles(taskId){return new Promise(resolve=>chrome.storage.local.remove(['taskFiles_'+taskId],resolve))}
async function queryTasks(field,value){
  const body={structuredQuery:{from:[{collectionId:'tasks'}],where:{fieldFilter:{field:{fieldPath:field},op:'EQUAL',value:{stringValue:value}}},limit:500}};
  const rows=await request(`${FS}:runQuery`,{method:'POST',body:JSON.stringify(body)});
  return (Array.isArray(rows)?rows:[]).filter(x=>x.document).map(x=>docObj(x.document));
}
async function loadVisibleTasks(){
  if(state.currentUser?.role==='admin')return listCol('tasks');
  const [incoming,sent]=await Promise.all([queryTasks('assigneeId',state.uid),queryTasks('senderId',state.uid)]);
  return [...new Map([...incoming,...sent].map(x=>[x.id,x])).values()];
}
async function loadData(){state.users=await listCol('users');state.companies=await listCol('companies');state.tasks=await loadVisibleTasks();populate();renderAll()}
function showApp(u){state.currentUser=u;$('#loginView').classList.add('hidden');$('#appView').classList.remove('hidden');$('#currentName').textContent=u.name;$('#currentEmail').textContent=u.loginEmail||u.email;$('#currentRole').textContent=u.role==='admin'?'Admin':'İşçi';$('#avatar').textContent=initials(u.name);$$('.admin-only').forEach(x=>x.style.display=u.role==='admin'?'block':'none');loadData().then(handleDeepLink).catch(e=>toast(e.message));state.poll=setInterval(()=>loadData().catch(console.warn),15000)}
function renderMultiPickers(){
  const render=(pickerId,items,selected,keyText,placeholder)=>{
    const root=$(pickerId);if(!root)return;
    const menu=root.querySelector('.multi-menu'),toggle=root.querySelector('.multi-toggle');
    menu.innerHTML=items.map(item=>`<label class="multi-option"><input type="checkbox" value="${item.id}" ${selected.includes(item.id)?'checked':''}><span>${keyText(item)}</span></label>`).join('')||'<div class="meta">Məlumat yoxdur</div>';
    const chosen=items.filter(x=>selected.includes(x.id));toggle.textContent=chosen.length?chosen.map(keyText).join(', '):placeholder;
    menu.querySelectorAll('input').forEach(input=>input.onchange=()=>{const arr=[...menu.querySelectorAll('input:checked')].map(x=>x.value);if(pickerId==='#taskAssigneePicker')state.selectedAssigneeIds=arr;else state.selectedCompanyIds=arr;renderMultiPickers();updateSelectedVoens()});
  };
  render('#taskAssigneePicker',state.users.filter(u=>u.active!==false),state.selectedAssigneeIds,u=>`${u.name} — ${u.position||''}`,'Əməkdaş seçin');
  render('#taskCompanyPicker',state.companies,state.selectedCompanyIds,c=>c.name,'Şirkət seçin');
}
function updateSelectedVoens(){const names=state.companies.filter(c=>state.selectedCompanyIds.includes(c.id)).map(c=>c.voen).filter(Boolean);$('#taskVoen').value=names.join(', ')}
function populate(){const keepReport=$('#reportEmployee')?.value||'',keepFilter=$('#taskCompanyFilter')?.value||'';state.selectedAssigneeIds=state.selectedAssigneeIds.filter(id=>state.users.some(u=>u.id===id));state.selectedCompanyIds=state.selectedCompanyIds.filter(id=>state.companies.some(c=>c.id===id));renderMultiPickers();updateSelectedVoens();const uOpts=state.users.filter(u=>u.active!==false).map(u=>`<option value="${u.id}">${esc(u.name)} — ${esc(u.position||'')}</option>`).join('');$('#reportEmployee').innerHTML='<option value="">Bütün əməkdaşlar</option>'+uOpts;const cOpts=state.companies.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');$('#taskCompanyFilter').innerHTML='<option value="">Bütün şirkətlər</option>'+cOpts;if([...$('#reportEmployee').options].some(o=>o.value===keepReport))$('#reportEmployee').value=keepReport;if([...$('#taskCompanyFilter').options].some(o=>o.value===keepFilter))$('#taskCompanyFilter').value=keepFilter}
function navigate(id){$$('.view').forEach(x=>x.classList.remove('active-view'));$('#'+id).classList.add('active-view');$$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.view===id));const titles={dashboard:['Ana səhifə','Tapşırıqların ümumi vəziyyəti'],newTask:['Yeni tapşırıq','Əməkdaşa tapşırıq göndərin'],myTasks:['Tapşırıqlar','Tapşırıqları izləyin və status bildirin'],admin:['İdarəetmə','Əməkdaş və şirkət məlumatları'],reports:['Hesabat','İcra, gecikmə və əməkdaş performansı']};$('#pageTitle').textContent=titles[id][0];$('#pageSubtitle').textContent=titles[id][1];if(id==='reports')renderReports()}
function visibleTasks(){return state.currentUser.role==='admin'?state.tasks:state.tasks.filter(t=>t.assigneeId===state.uid||t.senderId===state.uid)}
function taskCard(t,detailed=false){const c=company(t.companyId),a=person(t.assigneeId),s=person(t.senderId);return `<article class="task-card" data-task="${t.id}"><div class="task-top"><div><div class="task-title">${esc(t.title)}</div><div class="meta">${esc(c.name)} · ${esc(c.voen)} · Kimdən: ${esc(s.name)} · Kimə: ${esc(a.name)}</div></div><span class="status status-${t.status}">${statusMap[t.status]}</span></div><div class="meta">Son tarix: ${formatDate(t.dueAt)} · ${dueText(t)}</div>${detailed?`<div class="task-actions"><button class="btn ghost statusBtn" data-id="${t.id}" data-status="progress">İcraya götür</button><button class="btn ghost statusBtn" data-id="${t.id}" data-status="done">İcra olundu</button><button class="btn ghost statusBtn" data-id="${t.id}" data-status="wrong">Yanlış tapşırıq</button>${state.currentUser.role==='admin'?`<button class="btn ghost deleteBtn" data-id="${t.id}">Sil</button>`:''}</div>`:''}</article>`}
function dashboardIncomingTasks(){return state.tasks.filter(t=>t.assigneeId===state.uid&&t.senderId!==state.uid)}
function dashboardSentTasks(){return state.tasks.filter(t=>t.senderId===state.uid)}
function dashboardOwnTasks(){const map=new Map();[...dashboardIncomingTasks(),...dashboardSentTasks()].forEach(t=>map.set(t.id,t));return [...map.values()]}
function descriptionExcerpt(v='',limit=150){const clean=String(v||'').replace(/\s+/g,' ').trim();return clean.length>limit?clean.slice(0,limit).trim()+'…':clean}
function dashboardTaskCard(t,flow){
  const c=company(t.companyId),a=person(t.assigneeId),s=person(t.senderId),late=daysLate(t);
  const delay=(late>0&&t.status!=='done')?`${late} gün`:(t.status==='done'?'0 gün':'0 gün');
  const statusSelect=flow==='incoming'?`<select class="dashboard-status-select" data-status-task="${t.id}" aria-label="Status seç"><option value="" selected disabled>Status seç</option><option value="progress">İcraya götürüldü</option><option value="done">İcra edildi</option><option value="wrong">Yanlış tapşırıq</option></select>`:'';
  return `<article class="dashboard-table-row ${flow==='sent'?'sent-row':''}" data-task="${t.id}" title="Ətraflı baxmaq üçün klik edin">
    <div class="dashboard-cell company-cell" data-label="Şirkət"><b>${esc(c.name||t.companyName||'-')}</b><small>${esc(t.title||'')}</small></div>
    <div class="dashboard-cell" data-label="VÖEN">${esc(c.voen||t.companyVoen||'-')}</div>
    <div class="dashboard-cell" data-label="Kimdən">${esc(s.name||'-')}</div>
    <div class="dashboard-cell" data-label="Kimə">${esc(a.name||'-')}</div>
    <div class="dashboard-cell date-cell" data-label="Göndərilmə tarixi">${formatDate(t.createdAt)}</div>
    <div class="dashboard-cell date-cell" data-label="Son icra tarixi">${formatDate(t.dueAt)}</div>
    <div class="dashboard-cell delay-cell ${late>0&&t.status!=='done'?'is-late':''}" data-label="Gecikmə günü">${delay}</div>
    <div class="dashboard-cell" data-label="Status"><span class="status status-${t.status}">${statusMap[t.status]}</span></div>
    ${flow==='incoming'?`<div class="dashboard-cell status-select-cell" data-label="Status seç">${statusSelect}</div>`:''}
  </article>`
}
function renderDashboardFlow(){
  const incoming=dashboardIncomingTasks().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)),sent=dashboardSentTasks().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  $('#incomingCount').textContent=incoming.length;$('#sentCount').textContent=sent.length;
  $$('.flow-tab').forEach(b=>b.classList.toggle('active',b.dataset.flow===state.dashboardFlow));
  const flow=state.dashboardFlow==='sent'?'sent':'incoming',list=flow==='sent'?sent:incoming,active=flow==='sent'?'Göndərilən':'Gələn';
  $('#dashboardTaskSummary').innerHTML=`<b>${active} tapşırıqlar: ${list.length}</b><span>${flow==='sent'?'Göndərdiyiniz tapşırıqların hazırkı statusunu burada izləyirsiniz.':'Sizə göndərilən tapşırıqların statusunu sağdakı seçimdən dəyişə bilərsiniz.'}</span>`;
  const header=`<div class="dashboard-table-head ${flow==='sent'?'sent-head':''}"><span>Şirkət</span><span>VÖEN</span><span>Kimdən</span><span>Kimə</span><span>Göndərilmə tarixi</span><span>Son icra tarixi</span><span>Gecikmə günü</span><span>Status</span>${flow==='incoming'?'<span>Status seç</span>':''}</div>`;
  $('#dashboardTasks').innerHTML=list.length?header+list.map(t=>dashboardTaskCard(t,flow)).join(''):`<div class="empty-flow"><b>${active} tapşırıq yoxdur</b><span>Bu bölmədə məlumat yarandıqda avtomatik görünəcək.</span></div>`;
  $$('#dashboardTasks [data-task]').forEach(c=>c.onclick=e=>{if(e.target.closest('.dashboard-status-select'))return;openTask(c.dataset.task)});
  $$('#dashboardTasks [data-status-task]').forEach(sel=>{sel.onclick=e=>e.stopPropagation();sel.onchange=async e=>{e.stopPropagation();const id=sel.dataset.statusTask,status=sel.value;if(status)await updateStatus(id,status)}})
}
function renderAll(){const ts=dashboardOwnTasks();$('#statTotal').textContent=ts.length;$('#statProgress').textContent=ts.filter(t=>t.status==='progress').length;$('#statDone').textContent=ts.filter(t=>t.status==='done').length;$('#statLate').textContent=ts.filter(t=>daysLate(t)>0&&t.status!=='done').length;renderDashboardFlow();const groups=['new','progress','done','wrong'];$('#statusBars').innerHTML=groups.map(k=>{const n=ts.filter(t=>t.status===k).length,p=ts.length?Math.round(n/ts.length*100):0;return `<div class="bar-row"><span>${statusMap[k]}</span><div class="bar"><i style="width:${p}%"></i></div><b>${n}</b></div>`}).join('');renderTasks();renderAdmin();renderReports()}
function renderTasks(){let ts=visibleTasks();const q=$('#taskSearch').value.toLowerCase(),st=$('#taskStatusFilter').value,co=$('#taskCompanyFilter').value;ts=ts.filter(t=>{const text=(t.title+' '+(t.description||'')+' '+company(t.companyId).name+' '+person(t.assigneeId).name).toLowerCase();return(!q||text.includes(q))&&(!st||t.status===st)&&(!co||t.companyId===co)});$('#allTasks').innerHTML=ts.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).map(t=>taskCard(t,true)).join('')||'<div class="meta">Nəticə tapılmadı.</div>';bindTaskButtons()}
function bindTaskButtons(){$$('.statusBtn').forEach(b=>b.onclick=e=>{e.stopPropagation();updateStatus(b.dataset.id,b.dataset.status)});$$('.deleteBtn').forEach(b=>b.onclick=async e=>{e.stopPropagation();if(confirm('Tapşırıq silinsin?')){await delDoc('tasks',b.dataset.id);await removeLocalTaskFiles(b.dataset.id);await loadData();toast('Tapşırıq silindi')}});$$('[data-task]').forEach(c=>c.onclick=()=>openTask(c.dataset.task))}
async function updateStatus(id,status){const t=state.tasks.find(x=>x.id===id);if(!t)return;if(state.currentUser.role!=='admin'&&t.assigneeId!==state.uid)return toast('Bu tapşırığın statusunu dəyişə bilməzsiniz');const now=new Date().toISOString();t.status=status;t.updatedAt=now;if(status==='done')t.completedAt=now;t.history=[{at:now,user:state.currentUser.name,userId:state.uid,status},...(t.history||[])];await setDoc('tasks',id,t);await loadData();toast('Status yeniləndi')}
function renderAdmin(){if(!state.currentUser||state.currentUser.role!=='admin')return;$('#employeeCount').textContent=state.users.length;$('#companyCount').textContent=state.companies.length;$('#employeeList').innerHTML=state.users.map(u=>`<div class="admin-row"><div><b>${esc(u.name)}</b><small>${esc(u.position||'')} · Giriş: ${esc(u.loginEmail||u.email||'-')} · Əsas: ${esc(u.email||'-')}${u.secondaryEmail?' · İkinci: '+esc(u.secondaryEmail):''} · ${esc(u.phone||'-')}</small></div><div class="admin-actions"><span class="badge">${u.role==='admin'?'Admin':'İşçi'}</span><button class="btn ghost editEmployee" data-id="${u.id}">Düzəlt</button><button class="btn ghost deleteEmployee" data-id="${u.id}">Sil</button></div></div>`).join('');$('#companyList').innerHTML=state.companies.map(c=>`<div class="admin-row"><div><b>${esc(c.name)}</b><small>VÖEN: ${esc(c.voen)}</small></div><div class="admin-actions"><button class="btn ghost editCompany" data-id="${c.id}">Düzəlt</button><button class="btn ghost deleteCompany" data-id="${c.id}">Sil</button></div></div>`).join('');bindAdminButtons()}
function bindAdminButtons(){
  $$('.editEmployee').forEach(b=>b.onclick=()=>{const u=person(b.dataset.id);state.editingEmployeeId=u.id;$('#empName').value=u.name||'';$('#empLoginEmail').value=u.loginEmail||u.email||'';$('#empEmail').value=u.email||'';$('#empEmail2').value=u.secondaryEmail||'';$('#empPosition').value=u.position||'';$('#empPhone').value=u.phone||'';$('#empRole').value=u.role||'employee';$('#empPassword').value='';$('#addEmployeeBtn').textContent='Əməkdaşı yenilə';navigate('admin');window.scrollTo({top:0,behavior:'smooth'})});
  $$('.deleteEmployee').forEach(b=>b.onclick=async()=>{const u=person(b.dataset.id);if(u.id===state.uid)return toast('Öz hesabınızı silə bilməzsiniz');if(!confirm(`${u.name} silinsin?`))return;await delDoc('users',u.id);await loadData();toast('Əməkdaş silindi')});
  $$('.editCompany').forEach(b=>b.onclick=()=>{const c=company(b.dataset.id);state.editingCompanyId=c.id;$('#companyName').value=c.name||'';$('#companyVoen').value=c.voen||'';$('#addCompanyBtn').textContent='Şirkəti yenilə';navigate('admin');window.scrollTo({top:0,behavior:'smooth'})});
  $$('.deleteCompany').forEach(b=>b.onclick=async()=>{const c=company(b.dataset.id);if(!confirm(`${c.name} silinsin?`))return;await delDoc('companies',c.id);await loadData();toast('Şirkət silindi')});
}
function clearTaskForm(){['taskTitle','taskDescription','taskDue'].forEach(id=>$('#'+id).value='');state.selectedCompanyIds=[];state.selectedAssigneeIds=[];renderMultiPickers();$('#taskVoen').value='';$('#taskFiles').value='';$('#selectedFiles').innerHTML='';$('#pastedPreview').innerHTML='';state.pastedFiles=[];state.audioBlob=null;$('#recordState').textContent='Səs yazılmır';$('#recordState').classList.remove('audio-ready');$('#recordBtn').textContent='🎙 Səs yazmağa başla';toast('Yeni tapşırıq forması təmizləndi')}
function fileToData(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve({name:file.name||`file_${Date.now()}`,type:file.type||'application/octet-stream',data:String(r.result).split(',')[1]||'',size:file.size||0});r.onerror=()=>reject(new Error('Fayl oxunmadı'));r.readAsDataURL(file)})}
function addPastedFile(file){if(!file)return;const max=8*1024*1024;if(file.size>max)return toast('Fayl maksimum 8 MB ola bilər');state.pastedFiles.push(file);renderPastedFiles()}
function renderPastedFiles(){$('#pastedPreview').innerHTML=state.pastedFiles.map((f,i)=>`<div class="preview-item">${f.type.startsWith('image/')?`<img src="${URL.createObjectURL(f)}">`:`<div>📎 ${esc(f.name)}</div>`}<button class="remove-preview" data-i="${i}">×</button></div>`).join('');$$('.remove-preview').forEach(b=>b.onclick=()=>{state.pastedFiles.splice(Number(b.dataset.i),1);renderPastedFiles()})}
function handleDeepLink(){const id=new URLSearchParams(location.search).get('task');if(id&&state.tasks.some(t=>t.id===id)){navigate('myTasks');setTimeout(()=>openTask(id),300);history.replaceState({},'',location.pathname)}}
function reportFiltered(){let ts=state.tasks.slice();const f=$('#reportFrom').value,t=$('#reportTo').value,e=$('#reportEmployee').value,s=$('#reportStatus').value;if(f)ts=ts.filter(x=>new Date(x.createdAt)>=new Date(f));if(t)ts=ts.filter(x=>new Date(x.createdAt)<=new Date(t+'T23:59:59'));if(e)ts=ts.filter(x=>x.assigneeId===e||x.senderId===e);if(s)ts=ts.filter(x=>x.status===s);return ts}
function renderReports(){if(!state.currentUser||state.currentUser.role!=='admin')return;$('#reportBody').innerHTML=reportFiltered().map(x=>`<tr><td>${formatDate(x.createdAt)}</td><td>${esc(company(x.companyId).name)}<br>${esc(company(x.companyId).voen)}</td><td>${esc(x.title)}</td><td>${esc(person(x.senderId).name)}</td><td>${esc(person(x.assigneeId).name)}</td><td>${formatDate(x.dueAt)}</td><td><span class="status status-${x.status}">${statusMap[x.status]}</span></td><td>${daysLate(x)} gün</td><td>${formatDate(x.updatedAt)}</td></tr>`).join('')}
function dataUrlOf(f){return f&&f.data?'data:'+(f.type||'application/octet-stream')+';base64,'+f.data:''}
function renderTaskFiles(files=[]){
  if(!files.length)return '<div class="meta">Fayl yoxdur.</div>';
  return `<div class="task-file-grid">${files.map((f,i)=>{const type=(f.type||'').toLowerCase(),name=esc(f.name||'Fayl'),icon=type.startsWith('image/')?'🖼️':type.includes('pdf')?'📕':type.includes('sheet')||type.includes('excel')?'📊':type.includes('word')?'📘':type.startsWith('audio/')?'🔊':'📎';return `<div class="task-file-card"><div class="task-file-name">${icon} ${name}</div><div class="task-file-actions"><button class="openCloudFile" data-file-index="${i}" data-mode="view">Bax</button><button class="openCloudFile" data-file-index="${i}" data-mode="download">Yüklə</button></div></div>`}).join('')}</div>`
}
async function openTask(id){
  const t=state.tasks.find(x=>x.id===id);if(!t)return;
  const localFiles=await getLocalTaskFiles(id);
  let cloudFiles=(t.files||[]);
  if(!cloudFiles.length){
    try{
      const manifest=await getDoc('taskFileManifests',id);
      if(manifest&&Array.isArray(manifest.files)) cloudFiles=manifest.files;
    }catch(err){ console.warn('Fayl manifesti oxunmadı',err); }
  }
  const files=localFiles.length?localFiles:cloudFiles;
  $('#dialogContent').innerHTML=`<h2>${esc(t.title)}</h2><div class="dialog-block"><span class="status status-${t.status}">${statusMap[t.status]}</span></div><div class="dialog-block"><b>Şirkət:</b> ${esc(company(t.companyId).name)} (${esc(company(t.companyId).voen)})</div><div class="dialog-block"><b>Kimdən:</b> ${esc(person(t.senderId).name)}<br><b>Kimə:</b> ${esc(person(t.assigneeId).name)}<br><b>Yaradılma tarixi:</b> ${formatDate(t.createdAt)}<br><b>Son tarix:</b> ${formatDate(t.dueAt)} · ${dueText(t)}</div><div class="dialog-block"><b>Məzmun:</b><p>${esc(t.description||'')}</p></div><div class="dialog-block"><b>Fayllar:</b>${renderTaskFiles(files)}${!localFiles.length&&cloudFiles.length?'<div class="meta">Fayllar buluddan təhlükəsiz açılır və yüklənir.</div>':''}</div><div class="dialog-block"><b>Status tarixçəsi:</b><div class="history">${(t.history||[]).map(h=>`<div>${formatDate(h.at)} · ${esc(h.user)} · ${statusMap[h.status]}</div>`).join('')||'Dəyişiklik yoxdur'}</div></div>`;
  $$('.openCloudFile').forEach(b=>b.onclick=async()=>{try{const f=files[Number(b.dataset.fileIndex)];await downloadTaskFile(f,id,b.dataset.mode||'download')}catch(e){toast(e.message)}});
  $('#taskDialog').showModal();
}
const BOOTSTRAP_ADMIN_EMAIL='memmed@ammo.az';
async function ensureUserProfile(authData,email){
  let u=await getDoc('users',authData.localId);
  if(u)return u;
  const normalized=(email||authData.email||'').trim().toLowerCase();
  const isBootstrapAdmin=normalized===BOOTSTRAP_ADMIN_EMAIL;
  const profile={
    name:isBootstrapAdmin?'Məmməd Allahverdiyev':(normalized.split('@')[0]||'Yeni istifadəçi'),
    loginEmail:normalized,
    email:normalized,
    position:isBootstrapAdmin?'Administrator':'İşçi',
    phone:isBootstrapAdmin?'0705539141':'',
    role:isBootstrapAdmin?'admin':'employee',
    active:true,
    createdAt:new Date().toISOString(),
    createdBy:authData.localId,
    autoCreated:true
  };
  try{
    await setDoc('users',authData.localId,profile);
  }catch(e){
    const existing=await getDoc('users',authData.localId);
    if(existing)return existing;
    throw e;
  }
  return {...profile,id:authData.localId};
}
$('#loginBtn').onclick=async()=>{try{const email=$('#loginEmail').value.trim();const d=await signIn(email,$('#loginPassword').value);state.token=d.idToken;state.refreshToken=d.refreshToken;state.uid=d.localId;const u=await ensureUserProfile(d,email);if(u.active===false)throw new Error('Bu istifadəçi deaktiv edilib');showApp(u)}catch(e){toast('Giriş alınmadı: '+e.message)}};
$$('.flow-tab').forEach(b=>b.onclick=()=>{state.dashboardFlow=b.dataset.flow;renderDashboardFlow()});
$('#demoBtn').style.display='none';$('#logoutBtn').onclick=()=>{clearInterval(state.poll);location.reload()};$$('.nav').forEach(b=>b.onclick=()=>navigate(b.dataset.view));$$('[data-go]').forEach(b=>b.onclick=()=>navigate(b.dataset.go));document.addEventListener('click',e=>{const picker=e.target.closest('.multi-picker');$$('.multi-picker').forEach(x=>{if(x!==picker)x.classList.remove('open')});if(e.target.closest('.multi-toggle')){e.preventDefault();picker.classList.toggle('open')}});['taskSearch','taskStatusFilter','taskCompanyFilter'].forEach(id=>$('#'+id).addEventListener('input',renderTasks));['reportFrom','reportTo','reportEmployee','reportStatus'].forEach(id=>$('#'+id).addEventListener('input',renderReports));
async function migrateEmployeeIdentity(oldId,newId,userData){
  await setDoc('users',newId,userData);
  for(const t of state.tasks){
    let changed=false,copy={...t};
    if(copy.assigneeId===oldId){copy.assigneeId=newId;changed=true}
    if(copy.senderId===oldId){copy.senderId=newId;changed=true}
    if(changed){copy.updatedAt=new Date().toISOString();await setDoc('tasks',copy.id,copy)}
  }
  if(oldId!==newId)await delDoc('users',oldId);
}
$('#addEmployeeBtn').onclick=async()=>{try{
  const name=$('#empName').value.trim(),loginEmail=$('#empLoginEmail').value.trim().toLowerCase(),email=$('#empEmail').value.trim().toLowerCase(),secondaryEmail=$('#empEmail2').value.trim().toLowerCase(),position=$('#empPosition').value.trim(),phone=$('#empPhone').value.trim(),password=$('#empPassword').value,role=$('#empRole').value;
  if(!name||!loginEmail||!email)return toast('Ad, sistemə giriş e-poçtu və əsas e-poçt vacibdir');
  if(state.editingEmployeeId){
    const old=person(state.editingEmployeeId);
    if((old.loginEmail||old.email||'').toLowerCase()!==loginEmail)return toast('Mövcud əməkdaşın giriş e-poçtu dəyişdirilmir. Lazım olsa əməkdaşı silib yenidən yaradın.');
    const userData={...old,name,loginEmail,email,secondaryEmail,position,phone,role,active:true,updatedAt:new Date().toISOString()};
    if(password){
      try{
        const a=await createAuthUser(loginEmail,password);
        await migrateEmployeeIdentity(old.id,a.localId,{...userData,authUid:a.localId,authLinkedAt:new Date().toISOString()});
        toast('Giriş hesabı yaradıldı və əməkdaş şəxsi kabinetə bağlandı');
      }catch(authErr){
        if(String(authErr.message||'').includes('EMAIL_EXISTS')){
          await setDoc('users',old.id,{...userData,authEmailExists:true});
          toast('Bu giriş e-poçtu Firebase-də artıq mövcuddur. Məlumatlar yeniləndi.');
        }else throw authErr;
      }
    }else{
      await setDoc('users',old.id,userData);toast('Əməkdaş yeniləndi');
    }
    state.editingEmployeeId='';$('#addEmployeeBtn').textContent='Əməkdaş yarat';
  }else{
    if(!password)return toast('Yeni əməkdaş üçün giriş parolu vacibdir');
    const a=await createAuthUser(loginEmail,password);
    await setDoc('users',a.localId,{name,loginEmail,email,secondaryEmail,position,phone,role,active:true,authUid:a.localId,createdAt:new Date().toISOString(),createdBy:state.uid});
    toast('Əməkdaş, giriş hesabı və şəxsi kabinet yaradıldı');
  }
  await loadData();['empName','empLoginEmail','empEmail','empEmail2','empPosition','empPhone','empPassword'].forEach(id=>$('#'+id).value='')
}catch(e){toast('Əməliyyat alınmadı: '+e.message)}};
$('#addCompanyBtn').onclick=async()=>{try{const name=$('#companyName').value.trim(),voen=$('#companyVoen').value.trim();if(!name||!voen)return toast('Şirkət adı və VÖEN vacibdir');if(state.editingCompanyId){const old=company(state.editingCompanyId);await setDoc('companies',old.id,{...old,name,voen,updatedAt:new Date().toISOString()});state.editingCompanyId='';$('#addCompanyBtn').textContent='Şirkət yarat';toast('Şirkət yeniləndi')}else{await addDoc('companies',{name,voen,createdAt:new Date().toISOString(),createdBy:state.uid});toast('Şirkət yaradıldı')}await loadData();$('#companyName').value=$('#companyVoen').value=''}catch(e){toast(e.message)}};
$('#resetTaskBtn').onclick=()=>{navigate('newTask');clearTaskForm()};
$('#pasteZone').addEventListener('paste',e=>{for(const item of e.clipboardData.items){if(item.kind==='file')addPastedFile(item.getAsFile())}});
$('#pasteZone').addEventListener('dragover',e=>{e.preventDefault();$('#pasteZone').classList.add('drag')});
$('#pasteZone').addEventListener('dragleave',()=>$('#pasteZone').classList.remove('drag'));
$('#pasteZone').addEventListener('drop',e=>{e.preventDefault();$('#pasteZone').classList.remove('drag');[...e.dataTransfer.files].forEach(addPastedFile)});
$('#taskFiles').onchange=()=>{[...$('#taskFiles').files].forEach(addPastedFile);$('#selectedFiles').innerHTML=state.pastedFiles.map(f=>`<span class="chip">📎 ${esc(f.name)}</span>`).join('')};
$('#recordBtn').onclick=async()=>{if(state.mediaRecorder&&state.mediaRecorder.state==='recording'){state.mediaRecorder.stop();return}try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});state.audioChunks=[];state.mediaRecorder=new MediaRecorder(stream);state.mediaRecorder.ondataavailable=e=>state.audioChunks.push(e.data);state.mediaRecorder.onstop=()=>{state.audioBlob=new Blob(state.audioChunks,{type:'audio/webm'});$('#recordState').textContent='Səs yazısı hazırdır';$('#recordState').classList.add('audio-ready');$('#recordBtn').textContent='🎙 Yenidən yaz';stream.getTracks().forEach(t=>t.stop())};state.mediaRecorder.start();$('#recordState').textContent='Səs yazılır...';$('#recordBtn').textContent='■ Yazını bitir'}catch(e){toast('Mikrofon icazəsi verilmədi')}};
async function finishTaskInBackground(task,base,allFiles){
  try{
    const attachments=[];for(const f of allFiles)attachments.push(await fileToData(f));
    const cloudFiles=[];for(const f of allFiles)cloudFiles.push(await uploadTaskFile(task.id,f));
    task.files=cloudFiles;task.fileUpload={state:'ready',completedAt:new Date().toISOString()};
    // Fayl siyahısını ayrıca manifest kolleksiyasında saxlayırıq. Beləliklə,
    // işçi göndərən olduqda task sənədinin update icazəsi geciksə belə fayllar itməyəcək.
    await setDoc('taskFileManifests',task.id,{taskId:task.id,senderId:base.senderId,assigneeId:base.assigneeId,files:cloudFiles,state:'ready',updatedAt:new Date().toISOString()});
    await saveLocalTaskFiles(task.id,attachments);
    try{
      const emailResult=await chrome.runtime.sendMessage({type:'SEND_TASK_EMAIL',payload:{taskId:task.id,task:{title:base.title,description:base.description,companyName:base.companyName,companyVoen:base.companyVoen,assigneeName:base.assigneeName,senderName:base.senderName,dueAt:base.dueAt,createdAt:base.createdAt},to:[base.assigneeEmail,base.assigneeSecondaryEmail].filter(Boolean),subject:`Yeni tapşırıq: ${base.title}`,attachments}});
      if(!emailResult?.success)throw new Error(emailResult?.error||'E-poçt göndərilmədi');task.emailDelivery={state:'sent',sentAt:new Date().toISOString(),provider:'google-apps-script'};
    }catch(err){task.emailDelivery={state:'error',error:err.message,updatedAt:new Date().toISOString(),provider:'google-apps-script'}}
    try{await setDoc('tasks',task.id,task)}catch(updateErr){console.warn('Tapşırıq fayl sahəsi yenilənmədi, manifest saxlanıldı',updateErr)}
  }catch(err){
    task.fileUpload={state:'error',error:err.message,updatedAt:new Date().toISOString()};
    try{await setDoc('tasks',task.id,task)}catch{}
    console.error('Fayl fon yükləmə xətası',err);
  }
}
$('#saveTaskBtn').onclick=async()=>{const sendBtn=$('#saveTaskBtn');const oldText=sendBtn.textContent;sendBtn.disabled=true;sendBtn.textContent='Göndərilir...';try{
  const companyIds=[...state.selectedCompanyIds],assigneeIds=[...state.selectedAssigneeIds],title=$('#taskTitle').value.trim(),dueAt=$('#taskDue').value;
  if(!companyIds.length||!assigneeIds.length||!title||!dueAt){toast('Ən azı bir şirkət, bir əməkdaş, başlıq və son tarix seçilməlidir','error');return}
  const now=new Date().toISOString(),allFiles=[...state.pastedFiles];
  if(state.audioBlob)allFiles.push(new File([state.audioBlob],`ses_yazisi_${Date.now()}.webm`,{type:'audio/webm'}));
  const totalSize=allFiles.reduce((s,f)=>s+(f.size||0),0);if(totalSize>18*1024*1024){toast('Faylların ümumi həcmi 18 MB-dan çox ola bilməz','error');return}
  const jobs=[];
  for(const companyId of companyIds){for(const assigneeId of assigneeIds){
    const selectedAssignee=person(assigneeId),selectedCompany=company(companyId);
    const base={companyId,companyName:selectedCompany.name||'',companyVoen:selectedCompany.voen||'',assigneeId,assigneeName:selectedAssignee.name||'',assigneeEmail:(selectedAssignee.email||'').trim().toLowerCase(),assigneeSecondaryEmail:(selectedAssignee.secondaryEmail||'').trim().toLowerCase(),senderId:state.uid,senderName:state.currentUser.name||'',senderEmail:(state.currentUser.email||'').trim().toLowerCase(),title,description:$('#taskDescription').value.trim(),dueAt,createdAt:now,updatedAt:now,status:'new',files:[],fileUpload:{state:allFiles.length?'uploading':'ready',queuedAt:now},history:[],emailDelivery:{state:'queued',queuedAt:now,provider:'google-apps-script'}};
    const task=await addDoc('tasks',base);jobs.push({task,base});
  }}
  toast('✓ Tapşırıq göndərildi. Fayllar arxa planda hazırlanır.','success',7000);
  chrome.runtime.sendMessage({type:'TASK_CREATED',title});
  const backgroundFiles=[...allFiles];
  clearTaskForm();await loadData();navigate('myTasks');
  jobs.forEach(({task,base})=>finishTaskInBackground(task,base,backgroundFiles));
}catch(e){toast('Tapşırıq göndərilmədi: '+e.message,'error',9000)}finally{sendBtn.disabled=false;sendBtn.textContent=oldText}};
$('#exportCsvBtn').onclick=()=>{const rows=[['Tarix','Şirkət','VÖEN','Tapşırıq','Kimdən','Kimə','Son tarix','Status','Gecikmə günü','Son yenilənmə'],...reportFiltered().map(x=>[formatDate(x.createdAt),company(x.companyId).name,company(x.companyId).voen,x.title,person(x.senderId).name,person(x.assigneeId).name,formatDate(x.dueAt),statusMap[x.status],daysLate(x),formatDate(x.updatedAt)])];const csv='\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(';')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='tapsiriq_hesabati.csv';a.click();URL.revokeObjectURL(a.href)};
$('#closeDialog').onclick=()=>$('#taskDialog').close();

async function trySuiteSession(){
  try{
    const r=await chrome.storage.local.get('suiteAuth'),a=r.suiteAuth;
    if(!a?.idToken||!a?.uid)throw new Error('AMMO SUITE girişi tapılmadı');
    state.token=a.idToken;state.refreshToken=a.refreshToken;state.uid=a.uid;
    if(a.expiresAt && Date.now()>Number(a.expiresAt)-120000) await refreshAccessToken();
    const u=await ensureUserProfile({localId:a.uid,email:a.email},a.email);
    if(u.active===false)throw new Error('Bu istifadəçi deaktiv edilib');
    showApp(u);
  }catch(e){
    console.warn('Suite auto login:',e);
    const msg=String(e?.message||e);
    const authProblem=/girişi tapılmadı|deaktiv|INVALID|TOKEN_EXPIRED|USER_NOT_FOUND|USER_DISABLED|401|403/i.test(msg);
    if(authProblem){
      await chrome.storage.local.remove('suiteAuth');
      // V28: AMMO SUITE pəncərəsinin içində ikinci SUITE açılmasın — əsas pəncərəni yönləndir
      const target=chrome.runtime.getURL('suite.html');
      try{ if(window.top!==window){ window.top.location.replace(target); return; } }catch(_){}
      location.replace(target);
      return;
    }
    // İnternet / server xətası: istifadəçini sistemdən çıxarma, yenidən cəhd et
    document.body.innerHTML=`<div style="min-height:100vh;display:grid;place-items:center;font-family:system-ui;background:#f4f7fc"><div style="background:#fff;border:1px solid #dce6f5;border-radius:16px;padding:28px 30px;max-width:420px;text-align:center;box-shadow:0 18px 50px #0a1f4d18"><div style="font-size:34px">☁</div><h2 style="margin:8px 0;color:#0a1f4d">TaskPanel bağlantısı alınmadı</h2><p style="color:#64748b;margin:0 0 18px">İnternet və ya server müvəqqəti əlçatan deyil. Siz sistemdən çıxarılmadınız.</p><button id="tpRetry" style="border:0;background:#0b6be8;color:#fff;border-radius:10px;padding:11px 18px;font-weight:700;cursor:pointer">Yenidən cəhd et</button></div></div>`;
    document.getElementById('tpRetry').onclick=()=>location.reload();
    setTimeout(()=>location.reload(),20000);
  }
}
trySuiteSession();
