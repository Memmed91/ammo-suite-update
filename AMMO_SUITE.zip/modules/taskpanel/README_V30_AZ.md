# Tapşırıq Paneli v3.0 — quraşdırma

Bu versiyada Firebase Storage tam çıxarılıb. Buna görə “Fayl Storage-a yüklənmədi” xətası artıq yaranmır.

## Nə işləyir
- əməkdaş üçün əsas və ikinci e-poçt;
- eyni məktubun hər iki ünvana göndərilməsi;
- Ctrl+V ilə əlavə olunan ekran şəkillərinin e-poçtun daxilində görünməsi;
- seçilmiş şəkillərin e-poçtun daxilində görünməsi;
- PDF, Word, Excel və digər sənədlərin məktuba əlavə edilməsi;
- səs yazısının məktuba audio fayl kimi əlavə edilməsi;
- tarix formatı: 16.07.2026 02:58;
- çoxlu şirkət və çoxlu əməkdaş seçimi;
- göndərənin kompüterində “Tapşırığa bax” pəncərəsində şəkil, səs və faylların açılması.

## Vacib: Google Apps Script-i bir dəfə yeniləyin
1. `script.google.com` saytında əvvəl istifadə etdiyiniz layihəni açın.
2. Köhnə kodu tam silin və ZIP-dəki `Code.gs` faylının məzmununu yerləşdirin.
3. **Deploy → Manage deployments → Edit** seçin.
4. **New version** seçib **Deploy** edin.
5. İcra edən: **Me**; giriş icazəsi: **Anyone** olmalıdır.
6. Web App URL dəyişibsə, onu `app.js` və `background.js` fayllarındakı URL ilə əvəz edin.

## Chrome-a quraşdırma
1. `chrome://extensions` açın.
2. Developer mode aktiv edin.
3. Köhnə versiyanı silin.
4. **Load unpacked** seçib bu qovluğu göstərin.

## Həcm limiti
Bir tapşırıq üzrə bütün faylların ümumi həcmi maksimum 18 MB-dır.

## Faylların paneldə saxlanması
Faylların tam nüsxəsi göndərənin Chrome yaddaşında saxlanır. Tapşırığın mətn məlumatları Firestore-da qalır. Əməkdaş faylları e-poçtda görür və yükləyir.
