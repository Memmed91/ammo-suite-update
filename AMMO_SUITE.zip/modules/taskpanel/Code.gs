function doPost(e) {
  try {
    const data = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const recipients = normalizeRecipients_(data.to);
    if (!recipients.length) throw new Error('Alıcı e-poçtu göstərilməyib.');
    const task = data.task || {};
    const inlineImages = {};
    const attachments = [];
    const imageBlocks = [];
    const fileBlocks = [];

    (data.attachments || []).forEach(function(item, index) {
      if (!item || !item.data) return;
      const type = String(item.type || 'application/octet-stream').toLowerCase();
      const name = String(item.name || ('fayl_' + (index + 1)));
      const blob = Utilities.newBlob(Utilities.base64Decode(item.data), type, name);
      if (type.indexOf('image/') === 0) {
        const cid = 'task_image_' + index;
        inlineImages[cid] = blob;
        imageBlocks.push('<div style="margin:18px 0"><div style="font-size:13px;font-weight:700;color:#344054;margin-bottom:7px">📷 ' + escapeHtml_(name) + '</div><img src="cid:' + cid + '" alt="' + escapeHtml_(name) + '" style="display:block;max-width:100%;height:auto;border-radius:14px;border:1px solid #dfe5ef"></div>');
      } else {
        attachments.push(blob);
        const icon = type.indexOf('audio/') === 0 ? '🎤' : '📎';
        fileBlocks.push('<div style="padding:10px 12px;margin:7px 0;border:1px solid #e3e8f2;border-radius:10px;background:#fff">' + icon + ' ' + escapeHtml_(name) + ' <span style="color:#667085;font-size:12px">(məktuba əlavə olunub)</span></div>');
      }
    });

    const htmlBody = buildEmailHtml_(task, imageBlocks.join(''), fileBlocks.join(''));
    GmailApp.sendEmail(recipients.join(','), data.subject || ('Yeni tapşırıq: ' + (task.title || '')), 'Yeni tapşırıq göndərildi. Məktubu HTML görünüşündə açın.', {
      htmlBody: htmlBody,
      attachments: attachments,
      inlineImages: inlineImages,
      name: 'Tapşırıq Paneli'
    });
    return json_({success:true, recipients:recipients.length, inlineImages:imageBlocks.length, attachments:attachments.length});
  } catch (err) {
    return json_({success:false, error:String(err && err.message ? err.message : err)});
  }
}

function doGet() {
  return HtmlService.createHtmlOutput('<!doctype html><meta charset="utf-8"><div style="font-family:Arial;padding:40px;max-width:700px;margin:auto"><h2>Tapşırıq Paneli e-poçt xidməti aktivdir</h2><p>Tapşırığın bütün məzmunu, şəkilləri və faylları e-poçtun özündə göndərilir.</p></div>');
}

function buildEmailHtml_(t, imagesHtml, filesHtml) {
  const h = escapeHtml_;
  const company = h(t.companyName || '-') + (t.companyVoen ? ' (' + h(t.companyVoen) + ')' : '');
  const description = h(t.description || t.title || '').replace(/\n/g, '<br>');
  const media = imagesHtml || filesHtml ? '<div style="margin-top:22px"><div style="font-size:16px;font-weight:800;color:#172033;margin-bottom:10px">Əlavələr</div>' + imagesHtml + filesHtml + '</div>' : '';
  return '<!doctype html><html><body style="margin:0;background:#f3f6fb;font-family:Arial,sans-serif;color:#172033">' +
    '<div style="padding:24px 10px"><div style="max-width:720px;margin:auto;background:#fff;border:1px solid #dfe5ef;border-radius:20px;overflow:hidden">' +
    '<div style="padding:26px 28px;background:#5364f5;color:#fff"><div style="font-size:13px;font-weight:700;opacity:.9">YENİ TAPŞIRIQ</div><div style="font-size:26px;font-weight:800;margin-top:8px">' + h(t.title || 'Tapşırıq') + '</div></div>' +
    '<div style="padding:26px 28px">' +
    infoRow_('Kimdən', h(t.senderName || '-')) + infoRow_('Kimə', h(t.assigneeName || '-')) + infoRow_('Şirkət', company) + infoRow_('Yaradılma tarixi', formatDate_(t.createdAt)) + infoRow_('Son tarix', formatDate_(t.dueAt)) +
    '<div style="margin-top:20px;padding:18px;border-radius:14px;background:#f6f8fc;border:1px solid #e5eaf2"><div style="font-size:13px;font-weight:800;color:#475467;margin-bottom:8px">TAPŞIRIĞIN MƏZMUNU</div><div style="font-size:15px;line-height:1.65">' + description + '</div></div>' +
    media +
    '<div style="margin-top:24px;padding-top:16px;border-top:1px solid #eaecf0;color:#667085;font-size:12px">Bu məktub Tapşırıq Paneli tərəfindən avtomatik göndərilib.</div>' +
    '</div></div></div></body></html>';
}
function infoRow_(label, value) { return '<div style="display:table;width:100%;border-bottom:1px solid #edf0f5;padding:11px 0"><div style="display:table-cell;width:155px;color:#667085;font-size:13px;font-weight:700">' + label + '</div><div style="display:table-cell;color:#172033;font-size:14px">' + value + '</div></div>'; }
function normalizeRecipients_(value) { const arr = Array.isArray(value) ? value : String(value || '').split(','); const seen = {}; return arr.map(function(x){return String(x || '').trim().toLowerCase();}).filter(function(x){if(!x || seen[x])return false;seen[x]=true;return true;}); }
function formatDate_(value) { if (!value) return '-'; const d = new Date(value); if (isNaN(d.getTime())) return '-'; return Utilities.formatDate(d, 'Asia/Baku', 'dd.MM.yyyy HH:mm'); }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function escapeHtml_(value) { return String(value == null ? '' : value).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];}); }
