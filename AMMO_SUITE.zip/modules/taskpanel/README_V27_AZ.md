# Tapşırıq Paneli v2.7

- Bir neçə şirkət eyni anda seçilə bilər.
- Bir neçə əməkdaş eyni anda seçilə bilər.
- Hər şirkət–əməkdaş kombinasiyası üçün ayrıca tapşırıq yaradılır.
- Hər əməkdaşa tapşırıq linki olan ayrıca Gmail məktubu göndərilir.
- Code.gs yenilənməlidir: Apps Script-də köhnə kodu bununla əvəz edin və yeni versiya deploy edin.
