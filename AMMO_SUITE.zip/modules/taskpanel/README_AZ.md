# Tapşırıq Paneli Pro — quraşdırma

## Hazır demo
1. Qovluğu ZIP-dən çıxarın.
2. Chrome-da `chrome://extensions` açın.
3. **Developer mode / Tərtibatçı rejimi** aktiv edin.
4. **Load unpacked / Paketlənməmiş uzantını yüklə** seçib bu qovluğu göstərin.
5. Uzantının ikonuna vurun və **Demo rejimini aç** seçin.

Demo admin hesabı: `admin@demo.az`  
Parol: `123456`

Demo məlumatları həmin kompüterin Chrome localStorage yaddaşında saxlanılır. Bu rejim interfeysi yoxlamaq üçündür.

## Real çoxistifadəçili sistem üçün
Bu proqramın müxtəlif kompüterlərdə 10 işçi ilə işləməsi, real giriş/parol, fayl və səs saxlanması və avtomatik e-poçt göndərməsi üçün server bazası tələb olunur. Paketdə Supabase sxemi və e-poçt funksiyası nümunəsi verilib.

1. Supabase layihəsi yaradın.
2. `supabase_schema.sql` faylını SQL Editor-də icra edin.
3. Authentication bölməsində istifadəçiləri yaradın. Admin istifadəçisinin `profiles.role` sahəsini `admin` edin.
4. `app.js` faylının əvvəlindəki `CONFIG` dəyişəninə layihə URL-i, anon key və Edge Function URL-ni daxil edin.
5. Real rejimə keçərkən localStorage funksiyalarını Supabase REST/Auth sorğuları ilə əvəz edin. Verilən SQL buna hazırdır.
6. E-poçt üçün `email_function_example.js` faylını Supabase Edge Function kimi yerləşdirin və Resend API açarını secret edin.

## Daxil edilən funksiyalar
- Admin və işçi giriş ekranı
- Admin üçün əməkdaş, vəzifə, telefon, e-poçt, rol və ilkin parol yaratma forması
- Şirkət adı və VÖEN reyestri; şirkət seçiləndə VÖEN avtomatik göstərilir
- İşçidən işçiyə və admindən işçiyə tapşırıq göndərilməsi
- Son icra tarixi və avtomatik gecikmə günü
- Statuslar: Yeni, İcraya götürülüb, İcra olunub, Yanlış tapşırıq
- Statuslara uyğun rənglər
- İşçinin tapşırığı silə bilməməsi; silmə yalnız admin üçündür
- Fayl seçimi və mikrofonla səs yazısı
- Axtarış, status və şirkət filtrləri
- Admin hesabatı: kimdən, kimə, tarix, şirkət/VÖEN, status, son tarix, gecikmə, son yenilənmə
- Excel-də açılan UTF-8 CSV hesabatı
- Chrome bildirişi və e-poçt funksiyasına qoşulma nöqtəsi

## Təhlükəsizlik qeydi
Real sistemdə parolları heç vaxt adi mətn kimi bazada saxlamayın. Supabase Auth parolları təhlükəsiz hash formasında idarə edir. Admin yeni işçi yaradarkən bunu server/Edge Function üzərindən etməlidir ki, service-role açarı Chrome uzantısına yazılmasın.

## TAM EKRANDA AÇILMA — v1.1
Bu versiyada panel artıq yan paneldə açılmır. Chrome uzantısının ikonuna basdıqda proqram ayrıca yeni tabda açılır və brauzerin bütün iş sahəsini tutur. Panel artıq açıqdırsa, ikinci tab yaratmır, mövcud panelə keçir.
