# Tapşırıq Paneli v36

Ana səhifədə Gələn və Göndərilən tapşırıqlar cədvəl formasına keçirildi.

- Gələn tapşırıqlarda status seçimi var: İcraya götürüldü, İcra edildi, Yanlış tapşırıq.
- Seçilən status dərhal tapşırığa tətbiq olunur.
- Göndərilən tapşırıqlarda status yalnız izlənilir, dəyişdirilə bilmir.
- Sətirə klik etməklə tapşırığın ətraflı məlumatları açılır.
- Şirkət, VÖEN, kimdən, kimə, tarixlər, gecikmə günü və status eyni sətirdə göstərilir.

Quraşdırma: ZIP-i çıxarın, chrome://extensions bölməsində köhnə uzantını silin və Load unpacked ilə taskpanel_v36_build qovluğunu seçin. Apps Script-i yenidən deploy etməyə ehtiyac yoxdur.
