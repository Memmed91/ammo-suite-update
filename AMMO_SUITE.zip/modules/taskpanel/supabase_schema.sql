-- Supabase SQL Editor-də bir dəfə icra edin.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text unique not null,
  position text,
  phone text,
  role text not null default 'employee' check (role in ('admin','employee')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  voen text not null unique,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id),
  sender_id uuid not null references public.profiles(id),
  assignee_id uuid not null references public.profiles(id),
  title text not null,
  description text,
  due_at timestamptz not null,
  status text not null default 'new' check (status in ('new','progress','done','wrong')),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.task_files (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  file_name text not null,
  storage_path text not null,
  mime_type text,
  size_bytes bigint,
  is_audio boolean not null default false,
  uploaded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.task_history (
  id bigint generated always as identity primary key,
  task_id uuid not null references public.tasks(id) on delete cascade,
  changed_by uuid not null references public.profiles(id),
  old_status text,
  new_status text not null,
  note text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.companies enable row level security;
alter table public.tasks enable row level security;
alter table public.task_files enable row level security;
alter table public.task_history enable row level security;

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and active=true)
$$;

create policy "profiles visible to signed users" on public.profiles for select to authenticated using (active=true);
create policy "admin manages profiles" on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "companies visible" on public.companies for select to authenticated using (true);
create policy "admin manages companies" on public.companies for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "tasks visible to participants or admin" on public.tasks for select to authenticated using (public.is_admin() or sender_id=auth.uid() or assignee_id=auth.uid());
create policy "signed users create tasks" on public.tasks for insert to authenticated with check (sender_id=auth.uid());
create policy "participants update task status" on public.tasks for update to authenticated using (public.is_admin() or sender_id=auth.uid() or assignee_id=auth.uid());
create policy "only admin deletes tasks" on public.tasks for delete to authenticated using (public.is_admin());
create policy "task files visible to participants" on public.task_files for select to authenticated using (exists(select 1 from public.tasks t where t.id=task_id and (public.is_admin() or t.sender_id=auth.uid() or t.assignee_id=auth.uid())));
create policy "signed users upload task files" on public.task_files for insert to authenticated with check (uploaded_by=auth.uid());
create policy "history visible to participants" on public.task_history for select to authenticated using (exists(select 1 from public.tasks t where t.id=task_id and (public.is_admin() or t.sender_id=auth.uid() or t.assignee_id=auth.uid())));
create policy "signed users add history" on public.task_history for insert to authenticated with check (changed_by=auth.uid());

insert into storage.buckets (id,name,public) values ('task-files','task-files',false) on conflict (id) do nothing;
create policy "authenticated upload task files" on storage.objects for insert to authenticated with check (bucket_id='task-files');
create policy "authenticated read task files" on storage.objects for select to authenticated using (bucket_id='task-files');
