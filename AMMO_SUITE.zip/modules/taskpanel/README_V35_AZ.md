# Tapşırıq Paneli v35

Ana səhifədə Gələn və Göndərilən tapşırıq kartları artıq tam en üzrə bir sətirdə göstərilir. Növbəti tapşırıqlar aşağıdan ardıcıl davam edir. Digər funksiyalar dəyişdirilməyib.

## Quraşdırma
1. ZIP faylını çıxarın.
2. Chrome-da `chrome://extensions` açın.
3. Developer mode aktiv edin.
4. Köhnə uzantıda Remove basın.
5. Load unpacked ilə `taskpanel_v35_build` qovluğunu seçin.

Apps Script-i yenidən deploy etməyə ehtiyac yoxdur.
