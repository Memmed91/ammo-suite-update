# Google Apps Script e-poçt inteqrasiyası

Bu versiya Brevo və Firebase Cloud Function istifadə etmir. Yeni tapşırıq yaradıldıqda e-poçt birbaşa Google Apps Script Web App vasitəsilə Gmail-dən göndərilir.

## Quraşdırma
1. `chrome://extensions` açın.
2. Köhnə Tapşırıq Panelini silin.
3. ZIP-i çıxarın.
4. Developer mode aktiv edin.
5. Load unpacked seçin və `taskpanel_v23` qovluğunu göstərin.
6. Yeni test tapşırığı yaradın.

Uğurlu olduqda proqram `Tapşırıq və e-poçt uğurla göndərildi` mesajını göstərəcək.
