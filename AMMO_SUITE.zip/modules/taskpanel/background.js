const APP_URL = chrome.runtime.getURL('index.html');

async function openTaskPanel() {
  const tabs = await chrome.tabs.query({ url: `${APP_URL}*` });

  if (tabs.length > 0) {
    const tab = tabs[0];
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
    return;
  }

  await chrome.tabs.create({ url: APP_URL, active: true });
}

chrome.action.onClicked.addListener(() => {
  openTaskPanel().catch(console.error);
});

chrome.runtime.onInstalled.addListener(() => {
  openTaskPanel().catch(console.error);
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === 'TASK_CREATED') {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon128.png',
      title: 'Yeni tapşırıq yaradıldı',
      message: message.title || 'Tapşırıq uğurla göndərildi.'
    });
  }
});


const EMAIL_WEB_APP_URL = 'https://script.google.com/macros/s/AKfycbzNfq2z5uxaU1CLxjGG1gVS1K1FaiRA5dFKvmUkzDNGRz1f2qsHOVdFu3-sy4zygkZN/exec';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'SEND_TASK_EMAIL') return;

  (async () => {
    try {
      const response = await fetch(EMAIL_WEB_APP_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(message.payload || {}),
        redirect: 'follow'
      });

      const text = await response.text();
      let result;
      try { result = JSON.parse(text); } catch { result = { success: response.ok, raw: text }; }
      if (!response.ok || result.success === false) {
        throw new Error(result.error || `HTTP ${response.status}`);
      }
      sendResponse({ success: true, result });
    } catch (error) {
      sendResponse({ success: false, error: error?.message || String(error) });
    }
  })();

  return true;
});
