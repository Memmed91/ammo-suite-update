# Tapşırıq Paneli v2.6

## Vacib: Google Apps Script kodunu bir dəfə yeniləyin

1. https://script.google.com ünvanında `Konsalting Email Sistemi` layihəsini açın.
2. `Kod.gs` daxilindəki köhnə kodu tam silin.
3. Bu paketdəki `Code.gs` faylının bütün mətnini ora yapışdırın.
4. `Ctrl+S` edin.
5. **Dağıt → Dağıtımları yönet → Düzenle (qələm) → Yeni sürüm → Dağıt** edin.
6. Erişim yenə **Herkes** qalmalıdır.

Bundan sonra:
- fayl və ekran şəkilləri Gmail əlavəsi kimi gedir;
- səs yazısı Gmail əlavəsi kimi gedir;
- məktubdakı `Tapşırığa bax` düyməsi brauzerdə tapşırıq səhifəsini açır.

## Chrome uzantısı

Köhnə uzantını silin və `taskpanel_v23` qovluğunu `chrome://extensions` səhifəsində **Paketlenmemiş öğe yükle** ilə seçin.
