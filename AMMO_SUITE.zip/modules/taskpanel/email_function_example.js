// Supabase Edge Function nümunəsi (Deno). RESEND_API_KEY secret kimi əlavə edilir.
// supabase functions deploy send-task-email
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', {headers:cors()});
  const {to, assignee, sender, title, dueAt, link} = await req.json();
  const res = await fetch('https://api.resend.com/emails', {
    method:'POST',
    headers:{'Authorization':`Bearer ${Deno.env.get('RESEND_API_KEY')}`,'Content-Type':'application/json'},
    body:JSON.stringify({
      from:'Tapşırıq Paneli <tasks@yourdomain.az>', to:[to],
      subject:`Yeni tapşırıq: ${title}`,
      html:`<h2>Salam, ${assignee}</h2><p>${sender} sizə yeni tapşırıq göndərib.</p><p><b>${title}</b></p><p>Son tarix: ${new Date(dueAt).toLocaleString('az-AZ')}</p><p><a href="${link}">Tapşırığı aç</a></p>`
    })
  });
  return new Response(await res.text(), {status:res.status,headers:{...cors(),'Content-Type':'application/json'}});
});
function cors(){return {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type'}}
