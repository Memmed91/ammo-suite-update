# v2.4 E-poçt düzəlişi

Tapşırıq yaradılan anda alıcının e-poçtu, adı, göndərənin məlumatı və şirkət məlumatları birbaşa `tasks` sənədinə yazılır. Bu, Cloud Function-un yalnız `users` kolleksiyasından asılı qalmasının qarşısını alır.
