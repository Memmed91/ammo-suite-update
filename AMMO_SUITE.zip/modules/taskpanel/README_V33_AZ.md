# Tapşırıq Paneli v33 — giriş hesabı və bildiriş e-poçtları

Bu versiyada sistemə giriş e-poçtu ilə tapşırığın göndərildiyi e-poçtlar ayrılıb.

## Əməkdaş yaradarkən
- Sistemə giriş e-poçtu: məsələn `sebine@ammo.az`
- Sistemə giriş parolu: məsələn `sebine123`
- Əsas e-poçt: əməkdaşın tapşırıq məktubunu alacağı ünvan
- İkinci e-poçt: istəyə görə ikinci bildiriş ünvanı

Tapşırıqlar şəxsi kabinetdə Firebase Auth UID ilə görünür. Buna görə əməkdaşı həm Firebase Console-da ayrıca, həm də paneldə ayrıca yaratmaq olmaz. Əməkdaşı yalnız paneldəki “Yeni əməkdaş” bölməsindən yaradın. Panel həm giriş hesabını, həm də əməkdaş profilini eyni UID ilə yaradır.

## Mövcud əməkdaşlar
Əgər Firebase Authentication-da hesab ayrıca yaradılıb, amma paneldə əməkdaş ayrıca başqa hesabla yaradılıbsa, UID-lər fərqli olduğuna görə tapşırıq şəxsi kabinetdə görünməyəcək. Belə əməkdaşı paneldən silib bu versiyada yenidən yaradın. Köhnə tapşırıqların saxlanması vacibdirsə, əvvəlcə onları hesabat kimi ixrac edin.

## Firestore qaydaları
`firestore.rules` faylındakı yeni qaydaları Firebase Console > Firestore Database > Rules bölməsinə yerləşdirib Publish edin.
