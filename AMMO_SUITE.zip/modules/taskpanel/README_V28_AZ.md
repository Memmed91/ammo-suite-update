# Tapşırıq Paneli v2.8

Əlavə olunanlar:
- Əməkdaş üçün əsas və ikinci e-poçt
- Məktubun hər iki ünvana göndərilməsi
- Şəkillərin e-poçtun daxilində göstərilməsi
- Sənəd və səs fayllarının əlavə kimi göndərilməsi
- “Tapşırığa bax” səhifəsində şəkil, səs və sənədlərin açılması
- Tarix formatı: 16.07.2026 02:58
- Çoxlu şirkət və çoxlu əməkdaş seçimi saxlanılıb

## Vacib quraşdırma
1. `Code.gs` faylındakı yeni kodu Google Apps Script layihəsinə köçürün.
2. Apps Script-də **Deploy > Manage deployments > Edit > New version > Deploy** edin.
3. Firebase Storage Rules bölməsinə `storage.rules` məzmununu yerləşdirib **Publish** edin. Bu, e-poçtdakı “Tapşırığa bax” səhifəsində tapşırıq fayllarının açılması üçündür.
4. Chrome-da köhnə uzantını silin və bu qovluğu **Load unpacked / Paketlənməmiş uzantını yüklə** ilə açın.
