import * as XLSX from "xlsx";

import { initializeApp } from "firebase/app";
import {
  getAuth,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "firebase/auth";

import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  onSnapshot,
  serverTimestamp
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCwcYEbn6WAIhgYgYwCPsEde1uPjPL7n_8",
  authDomain: "gomruk-nezaret.firebaseapp.com",
  projectId: "gomruk-nezaret",
  storageBucket: "gomruk-nezaret.firebasestorage.app",
  messagingSenderId: "1055442363796",
  appId: "1:1055442363796:web:b3de53d144db4f854d9b81",
  measurementId: "G-RPQTPIY9DY"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

let allRows = [];
let filteredRows = [];
let selectedFile = null;
let unsubscribeRows = null;
let currentUser = null;

const qs = (s) => document.querySelector(s);

const cleanKey = (v) =>
  String(v ?? "")
    .toLowerCase()
    .replace(/ə/g, "e")
    .replace(/ö/g, "o")
    .replace(/ü/g, "u")
    .replace(/ı/g, "i")
    .replace(/ğ/g, "g")
    .replace(/ş/g, "s")
    .replace(/ç/g, "c")
    .replace(/[^a-z0-9]/g, "");

const norm = (v) =>
  String(v ?? "")
    .toLowerCase()
    .replace(/ə/g, "e")
    .replace(/ö/g, "o")
    .replace(/ü/g, "u")
    .replace(/ı/g, "i")
    .replace(/ğ/g, "g")
    .replace(/ş/g, "s")
    .replace(/ç/g, "c")
    .trim();

const money = (v) => {
  if (v === null || v === undefined || v === "") return 0;
  const s = String(v).replace(/\s/g, "").replace(",", ".");
  const n = Number(s);
  return isNaN(n) ? 0 : n;
};

const get = (obj, names) => {
  const keys = Object.keys(obj);
  for (const n of names) {
    const wanted = cleanKey(n);
    const found = keys.find((k) => cleanKey(k) === wanted);
    if (found) return obj[found];
  }
  return "";
};

function createLoginScreen() {
  const old = qs("#loginScreen");
  if (old) old.remove();

  const div = document.createElement("div");
  div.id = "loginScreen";
  div.innerHTML = `
    <div style="
      position:fixed; inset:0; z-index:999999;
      background:linear-gradient(135deg,#eef5ff,#ffffff);
      display:flex; align-items:center; justify-content:center;
      font-family:Arial, sans-serif;
    ">
      <div style="
        width:380px; background:white; border-radius:24px;
        padding:30px; box-shadow:0 20px 60px rgba(0,0,0,.12);
        border:1px solid #dbebff;
      ">
        <h1 style="margin:0 0 8px;color:#0a2459;">GÖMRÜK RƏZARƏT</h1>
        <p style="margin:0 0 22px;color:#1964c7;">Sistemə giriş edin</p>

        <input id="loginEmail" placeholder="Email" autocomplete="username" style="
          width:100%; padding:14px; margin-bottom:12px;
          border:1px solid #cce2ff; border-radius:12px;
          box-sizing:border-box;
        ">

        <input id="loginPassword" type="password" placeholder="Şifrə" autocomplete="current-password" style="
          width:100%; padding:14px; margin-bottom:16px;
          border:1px solid #cce2ff; border-radius:12px;
          box-sizing:border-box;
        ">

        <button id="loginBtn" style="
          width:100%; padding:14px; border:0; border-radius:14px;
          background:#3d8bf2; color:white; font-weight:700;
          cursor:pointer;
        ">DAXİL OL</button>

        <p id="loginError" style="color:red;font-size:13px;margin-top:14px;min-height:18px;"></p>
      </div>
    </div>
  `;
  document.body.appendChild(div);

  qs("#loginBtn").onclick = async () => {
    const email = qs("#loginEmail").value.trim();
    const pass = qs("#loginPassword").value.trim();
    const errorBox = qs("#loginError");
    const btn = qs("#loginBtn");

    if (!email || !pass) {
      errorBox.textContent = "Email və şifrəni yazın.";
      return;
    }

    try {
      btn.disabled = true;
      btn.textContent = "YOXLANILIR...";
      errorBox.textContent = "";

      const result = await signInWithEmailAndPassword(auth, email, pass);

      currentUser = result.user;
      removeLoginScreen();
      addLogoutButton();
      listenFirebaseRows();

    } catch (e) {
      console.error("LOGIN ERROR:", e.code, e.message);

      let msg = "Giriş mümkün olmadı: " + e.code;

      if (e.code === "auth/invalid-credential") msg = "Email və ya şifrə yanlışdır.";
      if (e.code === "auth/user-not-found") msg = "Bu email Firebase istifadəçilərində yoxdur.";
      if (e.code === "auth/wrong-password") msg = "Şifrə yanlışdır.";
      if (e.code === "auth/network-request-failed") msg = "İnternet bağlantısı yoxdur.";
      if (e.code === "auth/too-many-requests") msg = "Çox cəhd edilib. Bir az gözləyin.";
      if (e.code === "auth/operation-not-allowed") msg = "Firebase-də Email/Password aktiv deyil.";
      if (e.code === "auth/unauthorized-domain") msg = "Firebase Authorized domains ayarında problem var.";

      errorBox.textContent = msg;
    } finally {
      btn.disabled = false;
      btn.textContent = "DAXİL OL";
    }
  };
}

function removeLoginScreen() {
  const el = qs("#loginScreen");
  if (el) el.remove();
}

function addLogoutButton() {
  if (qs("#logoutBtn")) return;

  const btn = document.createElement("button");
  btn.id = "logoutBtn";
  btn.textContent = "ÇIXIŞ";
  btn.style.cssText = `
    position:fixed; right:25px; top:20px; z-index:9999;
    background:#ef4444; color:white; border:0;
    border-radius:12px; padding:10px 18px;
    font-weight:700; cursor:pointer;
  `;
  btn.onclick = async () => {
    await signOut(auth);
    location.reload();
  };
  document.body.appendChild(btn);
}

function normalizeRow(r) {
  const statAzn = money(get(r, [
    "STATİSTİK DƏYƏR AZN",
    "STATISTIK DƏYƏR AZN",
    "STATISTIK DEYER AZN",
    "STATİSTİK DEYER AZN"
  ]));

  const brokerFaiziRaw = String(get(r, [
    "BROKER FAİZİ",
    "BROKER FAIZI",
    "BROKER FAIZ",
    "BROKER FAİZ"
  ])).replace(",", ".");

  const brokerFaizi = brokerFaiziRaw.includes("1.5") ? 1.5 : 1;
  const mebleg = statAzn * brokerFaizi / 100;

  const odenilecek = money(get(r, [
    "ÖDƏNİLƏCƏK",
    "ODENILECEK",
    "ODENILECAK",
    "ÖDƏNİLƏCƏK MƏBLƏĞ",
    "ODENILECEK MEBLEG"
  ]));

  const avans = money(get(r, [
    "AVANS ÖDƏNİŞİ",
    "AVANS ODENISI",
    "AVANS ÖDƏNİSİ",
    "AVANS"
  ]));

  const net = mebleg - avans - odenilecek;

  return {
    teskilat: get(r, ["TƏŞKİLAT", "TESKILAT", "TƏSKILAT"]),
    voen: get(r, ["VÖEN", "VOEN"]),
    broker: get(r, ["BROKER"]),
    kargo: get(r, ["KARGO", "KARQO"]),
    ygb: get(r, ["YGB №", "YGB NO", "YGB No", "YGB NÖMRƏSİ", "YGB NOMRESI", "YGB"]),
    ygbTarix: get(r, ["YGB TARİX", "YGB TARIX", "TARİX", "TARIX"]),
    malAdi: get(r, ["MALIN ADI", "MALİN ADI", "MAL ADI", "MALINADI", "MALİNADI", "MAL"]),
    malKodu: get(r, ["MAL KODU", "KODU", "MALKODU"]),
    olcu: get(r, ["ÖLÇÜ VAHİDİ", "OLCU VAHIDI", "ÖLCU VAHIDI", "OLCU"]),
    miqdar: money(get(r, ["MİQDAR", "MIQDAR"])),
    statAzn,
    edv: money(get(r, ["ƏDV", "EDV"])),
    vergiBorcu: money(get(r, ["VERGİ BORCU", "VERGI BORCU"])),
    brokerFaizi,
    brokerMebleg: mebleg,
    odenilecek,
    avans,
    net,
    updatedAt: Date.now()
  };
}

function readExcel(file) {
  const reader = new FileReader();

  reader.onload = async (e) => {
    const workbook = XLSX.read(e.target.result, { type: "array" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const json = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    const rows = json
      .map(normalizeRow)
      .filter(r => r.teskilat || r.voen || r.broker || r.malAdi || r.ygb);

    await uploadRowsToFirebase(rows);
    alert("Excel məlumatları Firebase sisteminə yükləndi.");
  };

  reader.readAsArrayBuffer(file);
}

async function uploadRowsToFirebase(rows) {
  const old = await getDocs(collection(db, "customsData"));

  for (const d of old.docs) {
    await deleteDoc(doc(db, "customsData", d.id));
  }

  for (let i = 0; i < rows.length; i++) {
    await setDoc(doc(db, "customsData", String(i + 1)), {
      ...rows[i],
      createdBy: currentUser?.email || "",
      serverTime: serverTimestamp()
    });
  }
}

function listenFirebaseRows() {
  if (unsubscribeRows) unsubscribeRows();

  unsubscribeRows = onSnapshot(
    collection(db, "customsData"),
    (snap) => {
      allRows = snap.docs
        .map(d => d.data())
        .filter(r => r.teskilat || r.voen || r.broker || r.malAdi || r.ygb);

      refreshAll();
    },
    (error) => {
      console.error("FIRESTORE ERROR:", error.code, error.message);
      alert("Firestore xətası: " + error.code);
    }
  );
}

function unique(field) {
  return [...new Set(allRows.map(r => r[field]).filter(Boolean))].sort();
}

function makeDropdown(inputId, dropId, field) {
  const input = qs(inputId);
  const drop = qs(dropId);
  if (!input || !drop) return;

  input.setAttribute("autocomplete", "off");

  const show = () => {
    const val = norm(input.value);
    const list = unique(field).filter(x => norm(x).includes(val));

    drop.innerHTML = list.map(x => `<div class="dropdown-item">${x}</div>`).join("");
    drop.style.display = list.length ? "block" : "none";

    drop.querySelectorAll(".dropdown-item").forEach(item => {
      item.onclick = () => {
        input.value = item.textContent;
        drop.style.display = "none";
        applyFilters();
      };
    });
  };

  input.onfocus = show;
  input.onclick = show;
  input.oninput = () => {
    show();
    applyFilters();
  };
}

function applyFilters() {
  const broker = norm(qs("#brokerInput")?.value);
  const ygb = norm(qs("#ygbInput")?.value);
  const kargo = norm(qs("#kargoInput")?.value);
  const teskilat = norm(qs("#teskilatInput")?.value);

  filteredRows = allRows.filter(r =>
    (!broker || norm(r.broker).includes(broker)) &&
    (!ygb || norm(r.ygb).includes(ygb)) &&
    (!kargo || norm(r.kargo).includes(kargo)) &&
    (!teskilat || norm(r.teskilat).includes(teskilat))
  );

  renderTable();
  renderBroker();
}

function renderTable() {
  if (!qs("#dataBody")) return;

  qs("#resultCount").textContent = `${filteredRows.length} nəticə`;

  qs("#dataBody").innerHTML = filteredRows.map(r => `
    <tr>
      <td>${r.teskilat || ""}</td>
      <td>${r.voen || ""}</td>
      <td>${r.broker || ""}</td>
      <td>${r.malAdi || ""}</td>
      <td>${r.malKodu || ""}</td>
      <td>${r.olcu || ""}</td>
      <td>${Number(r.miqdar || 0).toFixed(2)}</td>
      <td>${Number(r.statAzn || 0).toFixed(2)}</td>
      <td>${Number(r.edv || 0).toFixed(2)}</td>
      <td>${Number(r.vergiBorcu || 0).toFixed(2)}</td>
    </tr>
  `).join("");

  if (qs("#sumMiqdar")) qs("#sumMiqdar").textContent = filteredRows.reduce((a, r) => a + Number(r.miqdar || 0), 0).toFixed(2);
  if (qs("#sumStat")) qs("#sumStat").textContent = filteredRows.reduce((a, r) => a + Number(r.statAzn || 0), 0).toFixed(2);
  if (qs("#sumEdv")) qs("#sumEdv").textContent = filteredRows.reduce((a, r) => a + Number(r.edv || 0), 0).toFixed(2);
  if (qs("#sumBorc")) qs("#sumBorc").textContent = filteredRows.reduce((a, r) => a + Number(r.vergiBorcu || 0), 0).toFixed(2);
}

function renderBroker() {
  if (!qs("#brokerBody")) return;

  const one = filteredRows.filter(r => Number(r.brokerFaizi) === 1);
  const oneHalf = filteredRows.filter(r => Number(r.brokerFaizi) === 1.5);

  const calc = (arr) => {
    const meb = arr.reduce((a, r) => a + Number(r.brokerMebleg || 0), 0);
    const avans = arr.reduce((a, r) => a + Number(r.avans || 0), 0);
    const od = arr.reduce((a, r) => a + Number(r.odenilecek || 0), 0);
    const net = meb - avans - od;
    return { meb, avans, od, net };
  };

  const row = (name, arr) => {
    const c = calc(arr);
    const label = c.net < 0 ? "Artıq ödənilib" : "Qalıq borc";

    return `
      <tr>
        <td>${name}</td>
        <td>${c.meb.toFixed(2)}</td>
        <td>${c.avans.toFixed(2)}</td>
        <td>${c.od.toFixed(2)}</td>
        <td>${label}: ${Math.abs(c.net).toFixed(2)}</td>
      </tr>
    `;
  };

  const total = calc(filteredRows);
  const totalLabel = total.net < 0 ? "ARTIQ ÖDƏNİLİB" : "QALIQ BORC";

  qs("#brokerBody").innerHTML =
    row("1%", one) +
    row("1,5%", oneHalf) +
    `
      <tr class="total">
        <td>CƏM</td>
        <td>${total.meb.toFixed(2)}</td>
        <td>${total.avans.toFixed(2)}</td>
        <td>${total.od.toFixed(2)}</td>
        <td>${totalLabel}: ${Math.abs(total.net).toFixed(2)}</td>
      </tr>
    `;
}

function refreshAll() {
  filteredRows = [...allRows];
  renderTable();
  renderBroker();

  makeDropdown("#brokerInput", "#brokerDropdown", "broker");
  makeDropdown("#ygbInput", "#ygbDropdown", "ygb");
  makeDropdown("#kargoInput", "#kargoDropdown", "kargo");
  makeDropdown("#teskilatInput", "#teskilatDropdown", "teskilat");
}

function clearFilters() {
  if (qs("#brokerInput")) qs("#brokerInput").value = "";
  if (qs("#ygbInput")) qs("#ygbInput").value = "";
  if (qs("#kargoInput")) qs("#kargoInput").value = "";
  if (qs("#teskilatInput")) qs("#teskilatInput").value = "";

  refreshAll();
}

function exportExcel() {
  const data = filteredRows.map(r => ({
    "TƏŞKİLAT": r.teskilat,
    "VÖEN": r.voen,
    "BROKER": r.broker,
    "MAL ADI": r.malAdi,
    "MAL KODU": r.malKodu,
    "ÖLÇÜ VAHİDİ": r.olcu,
    "MİQDAR": r.miqdar,
    "STATİSTİK DƏYƏR AZN": r.statAzn,
    "ƏDV": r.edv,
    "VERGİ BORCU": r.vergiBorcu,
    "BROKER FAİZİ": r.brokerFaizi + "%",
    "BROKER MƏBLƏĞİ": r.brokerMebleg,
    "AVANS ÖDƏNİŞİ": r.avans,
    "ÖDƏNİLƏCƏK": r.odenilecek,
    "QALIQ": r.net
  }));

  const ws = XLSX.utils.json_to_sheet(data, { origin: "A4" });

  XLSX.utils.sheet_add_aoa(ws, [
    ["GÖMRÜK RƏZARƏT"],
    ["Excel əsaslı axtarış, broker faizi və hesabat paneli"],
    []
  ], { origin: "A1" });

  ws["!cols"] = [
    { wch: 35 }, { wch: 16 }, { wch: 16 }, { wch: 40 }, { wch: 18 },
    { wch: 14 }, { wch: 14 }, { wch: 22 }, { wch: 14 }, { wch: 16 },
    { wch: 14 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "GOMRUK_REZARET");
  XLSX.writeFile(wb, "GOMRUK_REZARET_HESABAT.xlsx");
}

document.addEventListener("DOMContentLoaded", () => {
  onAuthStateChanged(auth, (user) => {
    currentUser = user;

    if (user) {
      removeLoginScreen();
      addLogoutButton();
      listenFirebaseRows();
    } else {
      if (unsubscribeRows) unsubscribeRows();
      allRows = [];
      filteredRows = [];
      renderTable();
      renderBroker();
      createLoginScreen();
    }
  });

  qs("#fileBtn")?.addEventListener("click", () => qs("#fileInput")?.click());

  qs("#fileInput")?.addEventListener("change", (e) => {
    selectedFile = e.target.files[0];
    if (qs("#fileName")) {
      qs("#fileName").textContent = selectedFile ? selectedFile.name : "Fayl seçilməyib";
    }
  });

  qs("#refreshBtn")?.addEventListener("click", () => {
    if (!currentUser) {
      alert("Əvvəl sistemə daxil olun.");
      return;
    }

    if (selectedFile) readExcel(selectedFile);
    else alert("Əvvəl Excel faylı seçin.");
  });

  qs("#clearBtn")?.addEventListener("click", clearFilters);
  qs("#exportExcelBtn")?.addEventListener("click", exportExcel);

  qs("#pdfBtn")?.addEventListener("click", () => {
    document.body.classList.add("print-mode");
    window.print();
    setTimeout(() => document.body.classList.remove("print-mode"), 1000);
  });

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".search-card")) {
      document.querySelectorAll(".dropdown").forEach(d => d.style.display = "none");
    }
  });
});