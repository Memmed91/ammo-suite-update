const path = require("path");

module.exports = {
  mode: "production",
  entry: {
    main: "./js/main-clean.js"
  },
  output: {
    filename: "main.bundle.js",
    path: path.resolve(__dirname, "dist"),
    clean: true
  }
};