MAL HƏRƏKƏTİ PRO — QURAŞDIRMA

1. ZIP faylını ayrıca qovluğa çıxarın.
2. Google Chrome-da chrome://extensions/ ünvanını açın.
3. Sağ yuxarıdan “Developer mode / Tərtibatçı rejimi”ni aktiv edin.
4. “Load unpacked / Paketdən çıxarılmışı yüklə” düyməsinə basın.
5. ZIP-dən çıxardığınız MAL_HEREKETI_PRO qovluğunu seçin.
6. Chrome alətlər panelində əlavənin işarəsinə vurun. Proqram tam ekran açılacaq.

İSTİFADƏ
- ALIŞ QAİMƏSİ: gələn qaimə siyahısını seçin.
- GÖMRÜK: gömrük hesabatını əlavə edin.
- ALIŞ AKTI: mal adı, mal kodu, miqdar və qiymət olan detallı faylı əlavə edin.
- SATIŞ QAİMƏSİ: göndərilən qaimə və mal sətirləri faylını seçin.
- Faylları seçdikdən sonra sağ yuxarıdakı yaşıl DOLDUR düyməsinə basın.

QEYD
Qaimələrin ümumi siyahısında mal kodu və miqdar yoxdursa, proqram həmin fayldan
yalnız qaimə/şirkət/məbləğ məlumatlarını oxuyur. Dəqiq mal qalığı üçün mal kodu və
miqdar olan detallı akt və ya qaimə faylı da yüklənməlidir.

Məlumatlar internetə göndərilmir; Chrome-un bu kompüterdəki yerli yaddaşında saxlanır.

VERSİYA 1.2
Excel fayllarının Chrome daxilində açılması üçün daxili ZIP/XLSX oxuyucusu yeniləndi.
“0 fayl analiz edildi” halında həqiqi xəta artıq gizlədilmir və faylın adı ilə göstərilir.

VERSİYA 1.3
Gömrük Komitəsinin standartdan fərqli, birləşdirilmiş xanalı və inlineStr quruluşlu
Excel hesabatları üçün xüsusi oxuma dəstəyi əlavə edildi. Fayldakı A1 ölçü göstəricisi
yanlış olsa belə, proqram bütün real sətirləri birbaşa XML-dən tapır.

VERSİYA 1.4
Miqdar sahəsinin daxili dəyişən adı düzəldildi (`qty is not defined` xətası aradan qaldırıldı).

VERSİYA 2.0 — MAL KODU ÜZRƏ ANBAR NƏZARƏTİ
- Alış qaiməsi, alış aktı və gömrük mal kodu üzrə MƏDAXİL sayılır.
- Satış qaiməsi mal kodu üzrə MƏXARİC sayılır.
- Cari qalıq = bütün mədaxil miqdarı − bütün məxaric miqdarı.
- Xidmət sətrləri, avans qaimələri, passiv və ləğv olunmuş qaimələr qalığa daxil edilmir.
- Alışda “Təqdim edənin adı”, satışda “Əldə edənin adı” qarşı tərəf kimi götürülür.
- Eyni bölməyə yeni fayl yüklənəndə əvvəlki fayl əvəz olunur və iki dəfə hesablanmır.
- Eyni mal koduna aid fərqli mal adları qalıq cədvəlində birlikdə göstərilir.

VERSİYA 2.1
- İdarə panelindəki alış, satış, qalıq və mal kodu kartları uyğun cədvələ keçid edir.
- “Əməliyyat” sayına basdıqda geniş material hərəkəti hesabatı açılır.
- Excel ixracı həqiqi XLSX formatına keçirildi; miqdar, qiymət və məbləğlər rəqəm kimi
  və minlik ayırıcı/iki onluq formatında göstərilir.
