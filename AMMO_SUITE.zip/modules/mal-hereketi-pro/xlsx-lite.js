/* Offline XLSX/CSV reader: ZIP central-directory parser + SpreadsheetML decoder. */
(function(){
  const td=new TextDecoder("utf-8");
  const u16=(a,o)=>a[o]|a[o+1]<<8, u32=(a,o)=>(a[o]|a[o+1]<<8|a[o+2]<<16|a[o+3]<<24)>>>0;
  async function inflate(data){const ds=new DecompressionStream("deflate-raw");return new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(ds)).arrayBuffer())}
  async function unzip(buf){
    if(window.JSZip){const zip=await JSZip.loadAsync(buf),out={};for(const [name,entry] of Object.entries(zip.files))if(!entry.dir)out[name]=await entry.async("uint8array");return out}
    const a=new Uint8Array(buf);let e=a.length-22;while(e>=0&&u32(a,e)!==0x06054b50)e--;if(e<0)throw Error("XLSX ZIP quruluşu tanınmadı");const n=u16(a,e+10),cd=u32(a,e+16);let p=cd,out={};for(let i=0;i<n;i++){if(u32(a,p)!==0x02014b50)break;const method=u16(a,p+10),cs=u32(a,p+20),nl=u16(a,p+28),el=u16(a,p+30),cl=u16(a,p+32),lo=u32(a,p+42),name=td.decode(a.slice(p+46,p+46+nl));const lnl=u16(a,lo+26),lel=u16(a,lo+28),start=lo+30+lnl+lel,raw=a.slice(start,start+cs);out[name]=method===8?await inflate(raw):raw;p+=46+nl+el+cl}return out
  }
  const xml=s=>{const d=new DOMParser().parseFromString(s,"application/xml");if(d.getElementsByTagName("parsererror").length)throw Error("Excel XML məlumatı oxunmadı");return d};
  const nodes=(root,name)=>[...root.getElementsByTagNameNS("*",name)];
  const child=(root,name)=>[...root.children].find(x=>x.localName===name);
  const txt=(files,name)=>files[name]?td.decode(files[name]):"";
  const colIndex=ref=>{let n=0;for(const c of (ref.match(/[A-Z]+/i)||[""])[0].toUpperCase())n=n*26+c.charCodeAt(0)-64;return n-1};
  async function readXlsx(buf){
    const f=await unzip(buf);if(!f["xl/workbook.xml"])throw Error("Bu fayl düzgün XLSX kitabı deyil");
    const wb=xml(txt(f,"xl/workbook.xml")),rel=xml(txt(f,"xl/_rels/workbook.xml.rels")),rels={};
    nodes(rel,"Relationship").forEach(x=>rels[x.getAttribute("Id")]=x.getAttribute("Target"));
    let shared=[];if(f["xl/sharedStrings.xml"])nodes(xml(txt(f,"xl/sharedStrings.xml")),"si").forEach(si=>shared.push(nodes(si,"t").map(x=>x.textContent).join("")));
    const sheets=[];for(const s of nodes(wb,"sheet")){
      let target=rels[s.getAttribute("r:id")||s.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id")];if(!target)continue;
      target=target.replace(/^\/?xl\//,"").replace(/^\.\.\//,"");const path="xl/"+target;if(!f[path])continue;
      const sx=xml(txt(f,path)),rows=[];
      for(const rn of nodes(sx,"row")){const row=[];for(const c of [...rn.children].filter(x=>x.localName==="c")){
        const idx=colIndex(c.getAttribute("r")||"A1"),t=c.getAttribute("t"),v=child(c,"v"),inline=child(c,"is");let val="";
        if(t==="s")val=shared[Number(v?.textContent||0)]??"";else if(t==="inlineStr")val=inline?nodes(inline,"t").map(x=>x.textContent).join(""):"";else if(t==="b")val=v?.textContent==="1";else val=v?.textContent??"";row[idx]=val
      }rows.push(row)}sheets.push({name:s.getAttribute("name")||"Sheet",rows})
    }return sheets
  }
  function readCsv(text){const sep=(text.split("\n")[0].match(/;/g)||[]).length>(text.split("\n")[0].match(/,/g)||[]).length?";":",";const rows=[];let row=[],cell="",q=false;for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'&&q&&n==='"'){cell+='"';i++}else if(c==='"')q=!q;else if(c===sep&&!q){row.push(cell);cell=""}else if((c==='\n'||c==='\r')&&!q){if(c==='\r'&&n==='\n')i++;row.push(cell);if(row.some(x=>x!==""))rows.push(row);row=[];cell=""}else cell+=c}row.push(cell);if(row.some(x=>x!==""))rows.push(row);return[{name:"CSV",rows}]}
  window.XLSXLite={read:async file=>file.name.toLowerCase().endsWith(".csv")?readCsv(await file.text()):readXlsx(await file.arrayBuffer())};
})();
