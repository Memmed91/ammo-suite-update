chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL("app.html");
  const found = await chrome.tabs.query({ url });
  if (found[0]) {
    await chrome.tabs.update(found[0].id, { active: true });
    if (found[0].windowId) await chrome.windows.update(found[0].windowId, { focused: true, state: "fullscreen" });
    return;
  }
  await chrome.windows.create({ url, type: "popup", state: "fullscreen" });
});
