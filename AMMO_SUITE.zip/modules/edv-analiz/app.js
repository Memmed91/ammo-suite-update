/* AMMO SUITE — ƏDV analizi (V29.1)
   e-taxes-dən yüklənən e-qaimə siyahılarını (satış / alış) oxuyur və ƏDV-ni təhlil edir.
   Məlumat yalnız bu kompüterdə, yaddaşda emal olunur — heç yerə göndərilmir. */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => new Intl.NumberFormat('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(n) || 0);
  const r2 = (x) => Math.round((x + Number.EPSILON) * 100) / 100;
  const AZM = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
  const monthName = (ym) => { const [y, m] = ym.split('-'); return `${AZM[Number(m) - 1]} ${y}`; };
  const fmtD = (iso) => iso ? iso.split('-').reverse().join('.') : '—';
  const LS_PREFS = 'edvColumnPrefs_v1';

  /* ---------- Sütunların tanınması ---------- */
  const FIELDS = {
    date: { label: 'Tarix', re: [/tarix/, /date/] },
    serial: { label: 'Seriya', re: [/seriya/, /serial/] },
    number: { label: 'Nömrə', re: [/^n[öo]mr[əe]/, /qaim[əe].*n[öo]mr/, /^№$/, /number/] },
    voen: { label: 'Kontragent VÖEN', re: [/v[öo]en/, /tin/] },
    name: { label: 'Kontragent adı', re: [/(al[ıi]c[ıi]|sat[ıi]c[ıi]|t[əe]chizat|kontragent|v[əe]rgi [öo]d[əe]y).*ad/, /ad[ıi]$/, /^ad$/, /name/, /al[ıi]c[ıi]|sat[ıi]c[ıi]/] },
    net: { label: 'Məbləğ (ƏDV-siz)', re: [/[əe]dv.?siz/, /[əe]dv.?d[əe]n.?kanar/, /xalis/, /^m[əe]bl[əe]ğ$/, /mal.*d[əe]y[əe]r/, /net/] },
    vat: { label: 'ƏDV məbləği', re: [/^[əe]dv( m[əe]bl[əe]ğ)?$/, /[əe]dv m[əe]bl[əe]ğ/, /[əe]dv.*\(/, /^vat/] },
    gross: { label: 'Cəmi (ƏDV ilə)', re: [/c[əe]mi/, /yekun/, /[əe]dv.?il[əe]/, /[üu]mumi/, /total/] },
    status: { label: 'Status', re: [/status/, /v[əe]ziyy[əe]t/] }
  };
  const norm = (s) => String(s ?? '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim().toLocaleLowerCase('az');

  function detectHeader(rows) {
    let best = { row: -1, score: 0, map: {} };
    for (let r = 0; r < Math.min(rows.length, 25); r++) {
      const cells = rows[r].map(norm); const map = {}; let score = 0; const used = new Set();
      for (const [f, def] of Object.entries(FIELDS)) {
        for (const re of def.re) {
          const i = cells.findIndex((c, ci) => c && !used.has(ci) && re.test(c) && !(f === 'net' && /[əe]dv il[əe]/.test(c)) && !(f === 'vat' && /siz|kənar|kanar|il[əe]/.test(c)));
          if (i >= 0) { map[f] = i; used.add(i); score++; break; }
        }
      }
      if (score > best.score) best = { row: r, score, map };
    }
    return best.score >= 2 ? best : { row: -1, score: 0, map: {} };
  }

  const parseNum = (v) => {
    if (typeof v === 'number') return v;
    let s = String(v ?? '').replace(/\s| |AZN|manat/gi, '');
    if (!s) return 0;
    if (s.includes(',') && s.includes('.')) s = s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
    else if (s.includes(',')) s = s.replace(',', '.');
    const x = parseFloat(s); return Number.isFinite(x) ? x : 0;
  };
  const parseDate = (v) => {
    if (v instanceof Date && !isNaN(v)) return v.toISOString().slice(0, 10);
    if (typeof v === 'number' && v > 20000 && v < 80000) { const d = new Date(Math.round((v - 25569) * 86400000)); return d.toISOString().slice(0, 10); }
    const s = String(v ?? '').trim(); let m;
    if ((m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})/))) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
    if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})/))) return `${m[1]}-${m[2]}-${m[3]}`;
    return '';
  };
  const voenOf = (v) => { const x = String(v ?? '').replace(/\.0$/, '').replace(/\D/g, ''); return x.length >= 9 && x.length <= 10 ? x.padStart(10, '0') : ''; };

  function guessDir(name, rows, hdr) {
    const n = norm(name);
    if (/g[öo]nd[əe]ril|sat[ıi]ş|output|sales|cixan|çıxan/.test(n)) return 'sale';
    if (/daxil|al[ıi]ş|input|purchase|gel[əe]n|gələn/.test(n)) return 'buy';
    const head = rows.slice(0, Math.max(hdr.row, 0) + 1).flat().map(norm).join(' ');
    if (/al[ıi]c[ıi]n[ıi]n v[öo]en|g[öo]nd[əe]rilmiş/.test(head)) return 'sale';
    if (/sat[ıi]c[ıi]n[ıi]n v[öo]en|daxil olan/.test(head)) return 'buy';
    return '';
  }

  /* ---------- Vəziyyət ---------- */
  let files = []; // {id, name, dir, rows(raw), hdr, map, sheet}
  let period = { from: '', to: '' };

  function buildRecords() {
    const out = [];
    for (const f of files) {
      if (!f.dir) continue;
      const m = f.map;
      for (let r = f.hdr + 1; r < f.rows.length; r++) {
        const row = f.rows[r];
        const get = (k) => (m[k] >= 0 ? row[m[k]] : '');
        const date = parseDate(get('date'));
        let net = parseNum(get('net')), vat = parseNum(get('vat')), gross = parseNum(get('gross'));
        if (!net && gross && m.vat >= 0) net = r2(gross - vat);
        if (!gross) gross = r2(net + vat);
        if (!vat && m.vat < 0 && gross && net) vat = r2(gross - net);
        const name = String(get('name') ?? '').trim(), voen = voenOf(get('voen'));
        const serial = String(get('serial') ?? '').trim(), number = String(get('number') ?? '').trim();
        if (!date && !net && !vat && !gross) continue; // boş / cəm sətri
        if (/c[əe]mi|yekun|total/i.test(String(row.join(' '))) && !voen && !number) continue;
        const status = String(get('status') ?? '').trim();
        out.push({ dir: f.dir, file: f.name, date, ym: date.slice(0, 7), serial, number, doc: [serial, number].filter(Boolean).join(' '), voen, name, net: r2(net), vat: r2(vat), gross: r2(gross), status, cancelled: /l[əe]ğv|annul|cancel|silin/i.test(status) });
      }
    }
    return out;
  }
  const inPeriod = (x) => (!period.from || (x.date && x.date >= period.from)) && (!period.to || (x.date && x.date <= period.to));
  let all = [], data = [];
  function recompute() {
    all = buildRecords();
    data = all.filter((x) => !x.cancelled && inPeriod(x));
    $('#exportBtn').disabled = !data.length;
    renderAll();
  }

  /* ---------- Fayl yükləmə ---------- */
  async function addFiles(list) {
    for (const file of list) {
      try {
        const wb = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: true });
        let best = null;
        for (const sn of wb.SheetNames) {
          const rows = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, defval: '', raw: true });
          const hdr = detectHeader(rows);
          if (!best || hdr.score > best.hdr.score) best = { sn, rows, hdr };
        }
        if (!best || !best.rows.length) throw new Error('boş fayl');
        const prefs = JSON.parse(localStorage.getItem(LS_PREFS) || '{}');
        const sig = best.hdr.row >= 0 ? best.rows[best.hdr.row].map(norm).join('|') : '';
        const saved = prefs[sig];
        const map = Object.fromEntries(Object.keys(FIELDS).map((k) => [k, saved?.[k] ?? best.hdr.map[k] ?? -1]));
        files.push({ id: Date.now() + Math.random(), name: file.name, sheet: best.sn, rows: best.rows, hdr: Math.max(best.hdr.row, 0), sig, map, dir: guessDir(file.name, best.rows, best.hdr) });
      } catch (e) { alert(`"${file.name}" oxunmadı: ${e.message}`); }
    }
    recompute();
  }
  $('#fileInput').addEventListener('change', (e) => { addFiles([...e.target.files]); e.target.value = ''; });
  const drop = $('#drop');
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => addFiles([...e.dataTransfer.files]));

  function renderFiles() {
    const host = $('#fileList');
    if (!files.length) { host.innerHTML = ''; return; }
    host.innerHTML = files.map((f, fi) => {
      const head = f.rows[f.hdr] || [];
      const opts = (sel) => `<option value="-1">—</option>` + head.map((h, i) => `<option value="${i}" ${i === sel ? 'selected' : ''}>${esc(String(h).slice(0, 40) || 'Sütun ' + (i + 1))}</option>`).join('');
      const cnt = all.filter((x) => x.file === f.name).length;
      const missing = !f.dir ? '<span class="warn">Növünü seçin</span>' : (f.map.net < 0 && f.map.gross < 0) ? '<span class="warn">Məbləğ sütunu tapılmadı</span>' : `<span class="ok">${cnt} qaimə</span>`;
      return `<div class="file"><div class="file-head"><div><b>${esc(f.name)}</b><small>Vərəq: ${esc(f.sheet)} · başlıq sətri ${f.hdr + 1}</small></div>
        <div class="file-tools"><select data-dir="${fi}"><option value="">— növ —</option><option value="sale" ${f.dir === 'sale' ? 'selected' : ''}>Satış (göndərilən)</option><option value="buy" ${f.dir === 'buy' ? 'selected' : ''}>Alış (daxil olan)</option></select>${missing}<button class="x" data-rm="${fi}" title="Faylı çıxar">✕</button></div></div>
        <details><summary>Sütunlar</summary><div class="map">${Object.entries(FIELDS).map(([k, d]) => `<label>${d.label}<select data-map="${fi}.${k}">${opts(f.map[k])}</select></label>`).join('')}
        <label>Başlıq sətri<input type="number" min="1" value="${f.hdr + 1}" data-hdr="${fi}"></label></div></details></div>`;
    }).join('');
    $$('[data-dir]').forEach((s) => s.onchange = () => { files[s.dataset.dir].dir = s.value; recompute(); });
    $$('[data-rm]').forEach((b) => b.onclick = () => { files.splice(Number(b.dataset.rm), 1); recompute(); });
    $$('[data-map]').forEach((s) => s.onchange = () => {
      const [fi, k] = s.dataset.map.split('.'); const f = files[fi]; f.map[k] = Number(s.value);
      const prefs = JSON.parse(localStorage.getItem(LS_PREFS) || '{}'); if (f.sig) { prefs[f.sig] = f.map; localStorage.setItem(LS_PREFS, JSON.stringify(prefs)); }
      recompute();
    });
    $$('[data-hdr]').forEach((i) => i.onchange = () => { const f = files[i.dataset.hdr]; f.hdr = Math.max(0, Number(i.value) - 1); recompute(); });
  }

  /* ---------- Hesablamalar ---------- */
  const sum = (arr, k) => r2(arr.reduce((s, x) => s + (x[k] || 0), 0));
  function byKey(arr, keyFn) { const m = new Map(); for (const x of arr) { const k = keyFn(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); } return m; }

  function checks() {
    const out = [];
    const rateOf = (x) => (x.net ? x.vat / x.net : 0);
    for (const x of data) {
      if (x.net && x.vat && Math.abs(x.vat - x.net * 0.18) > Math.max(0.05, x.net * 0.0005)) out.push({ kind: 'rate', x, text: `ƏDV ${money(x.vat)} — məbləğin ${(rateOf(x) * 100).toFixed(2)}%-i (18% gözlənilir: ${money(x.net * 0.18)})` });
      if (x.net > 0 && !x.vat) out.push({ kind: 'zero', x, text: 'ƏDV sıfırdır — ƏDV-dən azad / 0% dərəcəli əməliyyat olduğunu yoxlayın' });
      if (!x.voen) out.push({ kind: 'voen', x, text: 'Kontragentin VÖEN-i yoxdur və ya səhvdir' });
      if (!x.date) out.push({ kind: 'date', x, text: 'Tarix oxunmadı' });
      if (x.net < 0 || x.vat < 0) out.push({ kind: 'neg', x, text: 'Mənfi məbləğ — düzəliş / qaytarma qaiməsi' });
    }
    for (const [k, arr] of byKey(data.filter((x) => x.doc), (x) => `${x.dir}|${x.doc}`)) if (arr.length > 1) arr.slice(1).forEach((x) => out.push({ kind: 'dup', x, text: `Təkrarlanan qaimə nömrəsi (${arr.length} dəfə)` }));
    const sv = new Set(data.filter((x) => x.dir === 'sale' && x.voen).map((x) => x.voen));
    const both = [...new Set(data.filter((x) => x.dir === 'buy' && sv.has(x.voen)).map((x) => x.voen))];
    both.forEach((v) => { const x = data.find((y) => y.voen === v); out.push({ kind: 'both', x, text: 'Bu VÖEN həm alıcı, həm təchizatçıdır — qarşılıqlı əməliyyatları yoxlayın' }); });
    const cancelled = all.filter((x) => x.cancelled && inPeriod(x));
    cancelled.forEach((x) => out.push({ kind: 'cancel', x, text: `Ləğv edilmiş qaimə (${esc(x.status)}) — hesablamaya daxil edilmədi` }));
    return out;
  }

  /* ---------- Render ---------- */
  const table = (headers, rows, cls = '') => `<div class="tbl-wrap"><table class="tbl ${cls}"><thead><tr>${headers.map((h) => `<th class="${h.r ? 'r' : ''}">${h.t}</th>`).join('')}</tr></thead><tbody>${rows.join('') || `<tr><td colspan="${headers.length}" class="empty">Məlumat yoxdur</td></tr>`}</tbody></table></div>`;

  function renderSummary() {
    const s = data.filter((x) => x.dir === 'sale'), b = data.filter((x) => x.dir === 'buy');
    const sv = sum(s, 'vat'), bv = sum(b, 'vat'), diff = r2(sv - bv);
    const dates = data.map((x) => x.date).filter(Boolean).sort();
    $('#sumPeriod').textContent = data.length ? `Dövr: ${fmtD(period.from || dates[0])} — ${fmtD(period.to || dates[dates.length - 1])} · ${data.length} qaimə` : 'Əvvəlcə "Fayllar" bölməsində faylları əlavə edin.';
    $('#cards').innerHTML = [
      ['Satış (ƏDV-siz)', sum(s, 'net'), `${s.length} qaimə`, ''],
      ['Hesablanmış ƏDV', sv, 'satış üzrə', 'blue'],
      ['Alış (ƏDV-siz)', sum(b, 'net'), `${b.length} qaimə`, ''],
      ['Əvəzləşdirilən ƏDV', bv, 'alış üzrə', 'green'],
      [diff >= 0 ? 'Ödəniləcək ƏDV' : 'Növbəti dövrə keçən ƏDV', Math.abs(diff), 'hesablanmış − əvəzləşdirilən', diff >= 0 ? 'red' : 'green']
    ].map(([t, v, s2, c]) => `<div class="card ${c}"><small>${t}</small><b>${money(v)}</b><span>${s2}</span></div>`).join('');
    $('#sumNote').innerHTML = data.length ? `Bu hesablama yalnız yüklənmiş e-qaimələrə əsaslanır. Bəyannamədə idxal, depozit hesabından ödənişlər, ƏDV-dən azad və 0% dərəcəli əməliyyatlar ayrıca nəzərə alınmalıdır.` : '';
    const top = (arr) => { const g = [...byKey(arr, (x) => x.voen || x.name)].map(([k, a]) => ({ name: a[0].name || '—', voen: a[0].voen, net: sum(a, 'net'), n: a.length })).sort((x, y) => y.net - x.net).slice(0, 8); const tot = sum(arr, 'net') || 1;
      return g.length ? g.map((x) => `<div class="bar"><div class="bar-l"><b>${esc(x.name)}</b><small>${esc(x.voen)} · ${x.n} qaimə</small></div><div class="bar-r">${money(x.net)}</div><div class="bar-fill" style="width:${Math.max(2, x.net / tot * 100)}%"></div></div>`).join('') : '<p class="muted">—</p>'; };
    $('#topSales').innerHTML = top(s); $('#topBuys').innerHTML = top(b);
  }

  function monthRows() {
    const months = [...new Set(data.map((x) => x.ym).filter(Boolean))].sort();
    return months.map((ym) => { const a = data.filter((x) => x.ym === ym); const s = a.filter((x) => x.dir === 'sale'), b = a.filter((x) => x.dir === 'buy');
      return { ym, sNet: sum(s, 'net'), sVat: sum(s, 'vat'), bNet: sum(b, 'net'), bVat: sum(b, 'vat'), diff: r2(sum(s, 'vat') - sum(b, 'vat')), n: a.length }; });
  }
  function renderMonths() {
    const rows = monthRows();
    const max = Math.max(1, ...rows.map((r) => Math.max(r.sVat, r.bVat)));
    $('#monthChart').innerHTML = rows.length ? `<div class="legend"><span class="l-s">Hesablanmış ƏDV</span><span class="l-b">Əvəzləşdirilən ƏDV</span></div><div class="cols">${rows.map((r) => `<div class="col" title="${monthName(r.ym)}: ${money(r.sVat)} / ${money(r.bVat)}"><div class="pair"><i class="s" style="height:${r.sVat / max * 100}%"></i><i class="b" style="height:${r.bVat / max * 100}%"></i></div><small>${AZM[Number(r.ym.slice(5)) - 1].slice(0, 3)}<br>${r.ym.slice(2, 4)}</small></div>`).join('')}</div>` : '';
    const tot = rows.reduce((a, r) => ({ sNet: a.sNet + r.sNet, sVat: a.sVat + r.sVat, bNet: a.bNet + r.bNet, bVat: a.bVat + r.bVat, diff: a.diff + r.diff }), { sNet: 0, sVat: 0, bNet: 0, bVat: 0, diff: 0 });
    $('#monthTable').innerHTML = table([{ t: 'Ay' }, { t: 'Satış (ƏDV-siz)', r: 1 }, { t: 'Hesablanmış ƏDV', r: 1 }, { t: 'Alış (ƏDV-siz)', r: 1 }, { t: 'Əvəzləşdirilən ƏDV', r: 1 }, { t: 'Fərq', r: 1 }],
      rows.map((r) => `<tr><td>${monthName(r.ym)}</td><td class="r">${money(r.sNet)}</td><td class="r">${money(r.sVat)}</td><td class="r">${money(r.bNet)}</td><td class="r">${money(r.bVat)}</td><td class="r ${r.diff >= 0 ? 'pos' : 'neg'}">${money(r.diff)}</td></tr>`)
        .concat(rows.length ? [`<tr class="total"><td>Cəmi</td><td class="r">${money(tot.sNet)}</td><td class="r">${money(tot.sVat)}</td><td class="r">${money(tot.bNet)}</td><td class="r">${money(tot.bVat)}</td><td class="r">${money(tot.diff)}</td></tr>`] : []));
  }

  function partyRows(dir) {
    const arr = data.filter((x) => x.dir === dir); const tot = sum(arr, 'net') || 1;
    return [...byKey(arr, (x) => x.voen || 'VÖEN-siz: ' + x.name)].map(([k, a]) => ({ voen: a[0].voen, name: a.find((x) => x.name)?.name || '—', n: a.length, net: sum(a, 'net'), vat: sum(a, 'vat'), gross: sum(a, 'gross'), share: sum(a, 'net') / tot * 100, last: a.map((x) => x.date).sort().pop() })).sort((x, y) => y.net - x.net);
  }
  function renderParties() {
    const q = norm($('#partyQ').value);
    const rows = partyRows($('#partyDir').value).filter((r) => !q || norm(r.name).includes(q) || r.voen.includes(q));
    $('#partyTable').innerHTML = table([{ t: 'Ad' }, { t: 'VÖEN' }, { t: 'Qaimə', r: 1 }, { t: 'ƏDV-siz', r: 1 }, { t: 'ƏDV', r: 1 }, { t: 'Cəmi', r: 1 }, { t: 'Pay', r: 1 }, { t: 'Son tarix' }],
      rows.map((r) => `<tr><td>${esc(r.name)}</td><td class="mono">${esc(r.voen)}</td><td class="r">${r.n}</td><td class="r">${money(r.net)}</td><td class="r">${money(r.vat)}</td><td class="r">${money(r.gross)}</td><td class="r">${r.share.toFixed(1)}%</td><td>${fmtD(r.last)}</td></tr>`));
  }

  const KIND = { rate: ['Dərəcə', 'amber'], zero: ['ƏDV yoxdur', 'gray'], voen: ['VÖEN', 'red'], date: ['Tarix', 'red'], neg: ['Mənfi', 'amber'], dup: ['Təkrar', 'red'], both: ['Qarşılıqlı', 'blue'], cancel: ['Ləğv', 'gray'] };
  function renderChecks() {
    const list = checks();
    const b = $('#checkCount'); b.textContent = list.length; b.classList.toggle('hidden', !list.length);
    const groups = Object.keys(KIND).map((k) => [k, list.filter((c) => c.kind === k)]).filter(([, a]) => a.length);
    $('#checks').innerHTML = groups.length ? groups.map(([k, a]) => `<details class="chk" ${a.length <= 30 ? 'open' : ''}><summary><span class="tag ${KIND[k][1]}">${KIND[k][0]}</span> ${a.length} qeyd</summary>
      ${table([{ t: 'Növ' }, { t: 'Tarix' }, { t: 'Qaimə' }, { t: 'Kontragent' }, { t: 'ƏDV-siz', r: 1 }, { t: 'ƏDV', r: 1 }, { t: 'Qeyd' }],
        a.slice(0, 500).map((c) => `<tr><td>${c.x.dir === 'sale' ? 'Satış' : 'Alış'}</td><td>${fmtD(c.x.date)}</td><td class="mono">${esc(c.x.doc)}</td><td>${esc(c.x.name)}<small class="mono"> ${esc(c.x.voen)}</small></td><td class="r">${money(c.x.net)}</td><td class="r">${money(c.x.vat)}</td><td>${c.text}</td></tr>`))}</details>`).join('')
      : `<p class="muted">${data.length ? '✓ Diqqət tələb edən qaimə tapılmadı.' : 'Əvvəlcə faylları əlavə edin.'}</p>`;
  }

  function renderRows() {
    const q = norm($('#rowQ').value), d = $('#rowDir').value;
    const rows = data.filter((x) => (!d || x.dir === d) && (!q || norm(x.name).includes(q) || x.voen.includes(q) || norm(x.doc).includes(q))).sort((a, b) => (a.date < b.date ? -1 : 1));
    $('#rowTable').innerHTML = `<p class="muted">${rows.length} qaimə${rows.length > 1000 ? ' (ilk 1000-i göstərilir — hamısı Excel ixracındadır)' : ''}</p>` + table([{ t: 'Növ' }, { t: 'Tarix' }, { t: 'Qaimə' }, { t: 'Kontragent' }, { t: 'VÖEN' }, { t: 'ƏDV-siz', r: 1 }, { t: 'ƏDV', r: 1 }, { t: 'Cəmi', r: 1 }],
      rows.slice(0, 1000).map((x) => `<tr><td>${x.dir === 'sale' ? 'Satış' : 'Alış'}</td><td>${fmtD(x.date)}</td><td class="mono">${esc(x.doc)}</td><td>${esc(x.name)}</td><td class="mono">${esc(x.voen)}</td><td class="r">${money(x.net)}</td><td class="r">${money(x.vat)}</td><td class="r">${money(x.gross)}</td></tr>`));
  }

  function renderAll() { renderFiles(); renderSummary(); renderMonths(); renderParties(); renderChecks(); renderRows(); }

  /* ---------- Excel ixracı ---------- */
  $('#exportBtn').addEventListener('click', () => {
    const wb = XLSX.utils.book_new();
    const add = (name, rows) => { const ws = XLSX.utils.json_to_sheet(rows); ws['!cols'] = Object.keys(rows[0] || { a: 1 }).map((k) => ({ wch: Math.max(12, k.length + 2) })); XLSX.utils.book_append_sheet(wb, ws, name); };
    const s = data.filter((x) => x.dir === 'sale'), b = data.filter((x) => x.dir === 'buy');
    add('Xülasə', [{ Göstərici: 'Satış (ƏDV-siz)', Məbləğ: sum(s, 'net') }, { Göstərici: 'Hesablanmış ƏDV', Məbləğ: sum(s, 'vat') }, { Göstərici: 'Alış (ƏDV-siz)', Məbləğ: sum(b, 'net') }, { Göstərici: 'Əvəzləşdirilən ƏDV', Məbləğ: sum(b, 'vat') }, { Göstərici: 'Fərq (ödəniləcək +)', Məbləğ: r2(sum(s, 'vat') - sum(b, 'vat')) }]);
    add('Aylar', monthRows().map((r) => ({ Ay: monthName(r.ym), 'Satış ƏDV-siz': r.sNet, 'Hesablanmış ƏDV': r.sVat, 'Alış ƏDV-siz': r.bNet, 'Əvəzləşdirilən ƏDV': r.bVat, Fərq: r.diff })));
    add('Alıcılar', partyRows('sale').map((r) => ({ Ad: r.name, VÖEN: r.voen, Qaimə: r.n, 'ƏDV-siz': r.net, ƏDV: r.vat, Cəmi: r.gross, 'Pay %': r2(r.share) })));
    add('Təchizatçılar', partyRows('buy').map((r) => ({ Ad: r.name, VÖEN: r.voen, Qaimə: r.n, 'ƏDV-siz': r.net, ƏDV: r.vat, Cəmi: r.gross, 'Pay %': r2(r.share) })));
    add('Yoxlamalar', checks().map((c) => ({ Qeyd: c.text.replace(/<[^>]+>/g, ''), Növ: c.x.dir === 'sale' ? 'Satış' : 'Alış', Tarix: fmtD(c.x.date), Qaimə: c.x.doc, Kontragent: c.x.name, VÖEN: c.x.voen, 'ƏDV-siz': c.x.net, ƏDV: c.x.vat })));
    add('Qaimələr', data.map((x) => ({ Növ: x.dir === 'sale' ? 'Satış' : 'Alış', Tarix: fmtD(x.date), Seriya: x.serial, Nömrə: x.number, Kontragent: x.name, VÖEN: x.voen, 'ƏDV-siz': x.net, ƏDV: x.vat, Cəmi: x.gross, Fayl: x.file })));
    XLSX.writeFile(wb, `EDV_analiz_${new Date().toISOString().slice(0, 10)}.xlsx`);
  });

  /* ---------- Naviqasiya və filtrlər ---------- */
  $$('#tabs [data-tab]').forEach((b) => b.addEventListener('click', () => {
    $$('#tabs [data-tab]').forEach((x) => x.classList.toggle('active', x === b));
    $$('.tab').forEach((t) => t.classList.toggle('hidden', t.id !== 'tab-' + b.dataset.tab));
  }));
  $('#from').addEventListener('change', (e) => { period.from = e.target.value; recompute(); });
  $('#to').addEventListener('change', (e) => { period.to = e.target.value; recompute(); });
  $('#clearPeriod').addEventListener('click', () => { period = { from: '', to: '' }; $('#from').value = ''; $('#to').value = ''; recompute(); });
  $('#resetBtn').addEventListener('click', () => { if (files.length && !confirm('Yüklənmiş fayllar çıxarılsın?')) return; files = []; recompute(); });
  ['partyDir', 'partyQ'].forEach((id) => $('#' + id).addEventListener('input', renderParties));
  ['rowDir', 'rowQ'].forEach((id) => $('#' + id).addEventListener('input', renderRows));

  window.AMMO_EDV = { addFiles, get data() { return data; }, checks }; // test üçün
  recompute();
})();
