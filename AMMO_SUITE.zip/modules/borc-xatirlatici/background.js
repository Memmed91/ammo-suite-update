const ALARM_NAME = 'debt-reminder-check';

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: 60 });
  await runReminderCheck();
});

chrome.runtime.onStartup.addListener(async () => {
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: 60 });
  await runReminderCheck();
});

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) runReminderCheck();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'RUN_REMINDER_CHECK') {
    runReminderCheck().then(() => sendResponse({ ok: true }));
    return true;
  }
});

function dayStart(value = new Date()) {
  const d = new Date(value);
  d.setHours(0, 0, 0, 0);
  return d;
}

function daysBetween(from, to) {
  return Math.round((dayStart(to) - dayStart(from)) / 86400000);
}

async function runReminderCheck() {
  const { records = [], borcSettings, settings: legacySettings = {}, notified = {} } = await chrome.storage.local.get(['records', 'borcSettings', 'settings', 'notified']);
  const settings = borcSettings || (('reminderDays' in legacySettings) ? legacySettings : {});
  const today = dayStart();
  const reminderDays = Number.isFinite(Number(settings.reminderDays)) ? Number(settings.reminderDays) : 5;
  const newNotified = { ...notified };

  for (const item of records) {
    const installments = Array.isArray(item.installments) && (item.installments.length || item.paymentMode === 'monthly')
      ? item.installments
      : [{ id: `${item.id}-legacy`, dueDate: item.dueDate, amount: item.amount, status: item.status, paidAt: item.paidAt }];

    // V28.2: aylıq qeyddə növbəti (hələ yazılmamış) ay üçün əvvəlcədən xatırlatma
    const list = installments.slice();
    if (item.paymentMode !== 'one_time' && item.startDate) {
      const addM = (ds, k) => { const d = new Date(ds + 'T00:00:00'); const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + k); const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); d.setDate(Math.min(day, last)); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
      const have = new Set(installments.map(i => i.periodStart));
      let k = 0; while (k < 600 && have.has(addM(item.startDate, k))) k++;
      const ps = addM(item.startDate, k);
      list.push({ id: 'next-' + ps, periodStart: ps, dueDate: addM(item.startDate, k + 1), amount: item.monthlyAmount || item.baseAmount || 0, status: 'pending' });
    }
    for (const installment of list) {
      if (installment.status === 'paid' || !installment.dueDate) continue;
      const due = dayStart(installment.dueDate + 'T00:00:00');
      const daysLeft = daysBetween(today, due);
      const overdueDays = daysLeft < 0 ? Math.abs(daysLeft) : 0;
      const notifyKey = `${item.id}:${installment.id}:${installment.dueDate}:${daysLeft}`;
      if (daysLeft > reminderDays || newNotified[notifyKey]) continue;

      const typeText = item.type === 'receivable' ? 'Alacağınız' : 'Verəcəyiniz';
      const amountText = new Intl.NumberFormat('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(installment.amount || 0));
      const AZM=['Yanvar','Fevral','Mart','Aprel','May','İyun','İyul','Avqust','Sentyabr','Oktyabr','Noyabr','Dekabr'];
      const per = item.paymentMode === 'one_time' ? null : new Date((installment.periodStart || installment.dueDate) + 'T00:00:00');
      const monthText = per ? `${AZM[per.getMonth()]} ${per.getFullYear()}` : '1 dəfəlik ödəniş';
      let message;
      if (overdueDays > 0) message = `${item.person} — ${monthText}: ${amountText} ${item.currency || 'AZN'}. ${overdueDays} gündür gecikib.`;
      else if (daysLeft === 0) message = `${item.person} — ${monthText}: ${amountText} ${item.currency || 'AZN'}. Son tarix bu gündür.`;
      else message = `${item.person} — ${monthText}: ${amountText} ${item.currency || 'AZN'}. Son tarixə ${daysLeft} gün qalıb.`;

      await chrome.notifications.create(`debt-${item.id}-${installment.id}-${Date.now()}`, {
        type: 'basic', iconUrl: 'icons/icon128.png', title: `${typeText} üzrə ${item.paymentMode === 'one_time' ? '1 dəfəlik' : 'aylıq'} xatırlatma`, message, priority: overdueDays > 0 ? 2 : 1
      });
      newNotified[notifyKey] = Date.now();
    }
  }

  const cutoff = Date.now() - 45 * 86400000;
  for (const [key, timestamp] of Object.entries(newNotified)) {
    if (timestamp < cutoff) delete newNotified[key];
  }
  await chrome.storage.local.set({ notified: newNotified });
}
