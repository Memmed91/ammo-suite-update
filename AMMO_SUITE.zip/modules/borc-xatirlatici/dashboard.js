let records = [];
const expandedRecords = new Set();
let settings = { reminderDays: 5 };
const listMode = { receivable:'all', payable:'all' };
const $ = (id) => document.getElementById(id);
const fmt = (n, c='AZN') => `${new Intl.NumberFormat('az-AZ',{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(n||0))} ${c}`;
const dayStart = (v=new Date()) => { const d=new Date(v); d.setHours(0,0,0,0); return d; };
const dayDiff = (date) => Math.round((dayStart(date+'T00:00:00')-dayStart())/86400000);
const esc = (s='') => String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const csvEsc = (v='') => `"${String(v).replace(/"/g,'""')}"`;
const xmlEsc = (v='') => String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));


// Yerli tarix (toISOString UTC-yə çevirir və Bakı saatı ilə 1 gün geri sürüşdürürdü — DÜZƏLDİLDİ)
const ymd = (d=new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const AZ_MONTHS=['Yanvar','Fevral','Mart','Aprel','May','İyun','İyul','Avqust','Sentyabr','Oktyabr','Noyabr','Dekabr'];
const AZ_DAYS=['Bazar','Bazar ertəsi','Çərşənbə axşamı','Çərşənbə','Cümə axşamı','Cümə','Şənbə'];
const fmtDate = (s) => { if(!s) return '—'; const [y,m,d]=String(s).slice(0,10).split('-'); return `${d}.${m}.${y}`; };
const fmtDateTime = (iso) => { if(!iso) return ''; const d=new Date(iso); return `${fmtDate(ymd(d))} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`; };
const isOneTime = (r) => r.paymentMode==='one_time';
function addMonths(dateStr, offset){const d=new Date(dateStr+'T00:00:00');const day=d.getDate();d.setDate(1);d.setMonth(d.getMonth()+offset);const last=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();d.setDate(Math.min(day,last));return ymd(d);}
function monthLabel(dateStr){const d=new Date(dateStr+'T00:00:00');return `${AZ_MONTHS[d.getMonth()]} ${d.getFullYear()}`;}
function installmentLabel(i,r){if(r&&isOneTime(r))return '1 dəfəlik ödəniş';return monthLabel(i.periodStart||i.dueDate);}
function monthIndex(dateStr){const d=new Date(dateStr+'T00:00:00');return d.getFullYear()*12+d.getMonth();}
function currentMonthStart(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`;}
function rebaseInstallmentsToStartDate(r){
  if(!r.startDate || !Array.isArray(r.installments) || !r.installments.length) return false;
  const sorted=r.installments.slice().sort((a,b)=>String(a.periodStart||a.dueDate||'').localeCompare(String(b.periodStart||b.dueDate||'')));
  let changed=false;
  r.installments=sorted.map((item,idx)=>{
    const periodStart=addMonths(r.startDate,idx);
    const dueDate=addMonths(periodStart,1);
    if(item.periodStart!==periodStart || item.dueDate!==dueDate) changed=true;
    return {...item,periodStart,dueDate,amount:Number(item.amount||r.monthlyAmount||r.baseAmount||r.amount||0)};
  });
  return changed;
}
// V28.2: Ay bitdikdən sonra (son tarix gələndə) həmin ay üzrə borc yazılır.
// Məs: 01.09.2026 başlanğıc → 01.10.2026-da "Sentyabr 2026" borcu yaranır.
function accruedMonths(startDate){let n=0;const today=ymd();while(n<600&&addMonths(startDate,n+1)<=today)n++;return n;}
function nextAccrual(r){
  if(isOneTime(r)) return null;
  const start=r.startDate||ensureInstallments(r)[0]?.periodStart; if(!start) return null;
  const have=new Set(ensureInstallments(r).map(i=>i.periodStart));
  let k=0;while(k<600&&have.has(addMonths(start,k)))k++;
  const periodStart=addMonths(start,k);
  return {id:'next-'+periodStart,periodStart,dueDate:addMonths(periodStart,1),amount:monthlyEach(r),status:'pending',virtual:true};
}
function expandAutomaticMonthlyRecord(r){
  if(r.paymentMode==='one_time' || r.isMonthly===false) return false;
  const existing=Array.isArray(r.installments)?r.installments.slice():[];
  const firstExisting=existing.slice().sort((a,b)=>(a.periodStart||a.dueDate).localeCompare(b.periodStart||b.dueDate))[0];
  const firstStart=r.startDate || firstExisting?.periodStart || r.dueDate;
  if(!firstStart) return false;

  // Yalnız son tarixi gəlmiş (bitmiş) aylar borc kimi yaradılır. Hər ay ayrıca bağlanır.
  const needed=accruedMonths(firstStart);
  const each=Number(r.monthlyAmount || r.baseAmount || firstExisting?.amount || r.amount || 0);
  let changed=false;

  r.isMonthly=true;
  r.autoRecurring=true;
  r.startDate=firstStart;
  r.monthlyAmount=each;
  r.baseAmount=each;

  const byPeriod=new Map();
  existing.forEach((item,idx)=>{
    const period=item.periodStart || addMonths(firstStart,idx);
    byPeriod.set(period,{...item,periodStart:period,dueDate:addMonths(period,1),amount:Number(item.amount||each)});
  });

  const installments=[];
  for(let idx=0;idx<needed;idx++){
    const periodStart=addMonths(firstStart,idx);
    const old=byPeriod.get(periodStart);
    installments.push(old || {
      id:crypto.randomUUID(),
      periodStart,
      dueDate:addMonths(periodStart,1),
      amount:each,
      status:'open',
      paidAt:null
    });
    if(!old) changed=true;
  }

  // Əvvəlcədən ödənilmiş (hələ hesablanmamış) aylar itməsin
  byPeriod.forEach((item,period)=>{if(item.status==='paid'&&!installments.some(i=>i.periodStart===period))installments.push(item);});
  installments.sort((a,b)=>a.periodStart.localeCompare(b.periodStart));
  if(existing.length!==installments.length) changed=true;
  r.installments=installments;
  syncRecordStatus(r);
  return changed;
}
function ensureInstallments(r){if(Array.isArray(r.installments)&&(r.installments.length||r.paymentMode==='monthly'))return r.installments;return [{id:r.id+'-legacy',dueDate:r.dueDate,amount:Number(r.amount||0),status:r.status==='paid'?'paid':'open',paidAt:r.paidAt||null}];}
function openInstallments(r){return ensureInstallments(r).filter(i=>i.status!=='paid');}
function outstandingAmount(r){return openInstallments(r).reduce((a,i)=>a+Number(i.amount||0),0);}
function paidAmount(r){return ensureInstallments(r).filter(i=>i.status==='paid').reduce((a,i)=>a+Number(i.amount||0),0);}
function monthlyEach(r){return Number(r.monthlyAmount||r.baseAmount||ensureInstallments(r)[0]?.amount||0);}
function recordFace(r){return isOneTime(r)?Number(ensureInstallments(r)[0]?.amount||r.baseAmount||0):monthlyEach(r);}
function nextDueDate(r){const x=openInstallments(r).sort((a,b)=>a.dueDate.localeCompare(b.dueDate))[0];if(x)return x.dueDate;const n=nextAccrual(r);return n?n.dueDate:(r.dueDate||ymd());}
function overdueInstallments(r){return openInstallments(r).filter(i=>dayDiff(i.dueDate)<0);}
function overdueDuration(dateStr, endDate=new Date()){
  const start=dayStart(dateStr+'T00:00:00');
  const end=dayStart(endDate);
  if(start>=end)return{months:0,days:0,totalDays:0,label:'0 gün'};
  let months=(end.getFullYear()-start.getFullYear())*12+(end.getMonth()-start.getMonth());
  let anchor=new Date(start);
  anchor.setMonth(anchor.getMonth()+months);
  if(anchor>end){months--;anchor=new Date(start);anchor.setMonth(anchor.getMonth()+months);}
  const days=Math.floor((end-anchor)/86400000);
  const totalDays=Math.floor((end-start)/86400000);
  const parts=[];
  if(months)parts.push(`${months} ay`);
  if(days||!months)parts.push(`${days} gün`);
  return{months,days,totalDays,label:parts.join(' ')};
}
function syncRecordStatus(r){const ins=ensureInstallments(r);r.installments=ins;r.status=(ins.length&&ins.every(i=>i.status==='paid'))||(!ins.length&&!isOneTime(r))?'paid':'open';r.paidAt=r.status==='paid'?(r.paidAt||new Date().toISOString()):null;r.amount=ins.reduce((a,i)=>a+Number(i.amount||0),0);r.dueDate=ins.map(i=>i.dueDate).filter(Boolean).sort()[0]||r.dueDate;}

async function init(){
  const data=await chrome.storage.local.get(['records','borcSettings','settings']);
  records=data.records||[];
  // V28: "settings" açarı Hesabat Vaxtı modulu ilə toqquşurdu — Borc artıq "borcSettings" istifadə edir
  const legacy=data.settings&&('reminderDays' in data.settings)?{reminderDays:data.settings.reminderDays,dataVersion:data.settings.dataVersion}:{};
  settings={...settings,...legacy,...(data.borcSettings||{})};
  if((settings.dataVersion||0)<4){
    records.forEach(r=>{if(Array.isArray(r.installments)){r.installments.forEach(i=>{if(!i.periodStart && !String(i.id||'').endsWith('-legacy')){i.periodStart=i.dueDate;i.dueDate=addMonths(i.dueDate,1);}});syncRecordStatus(r);}});
    settings.dataVersion=4;
  }
  let monthlyChanged=false;
  records.forEach(r=>{if(expandAutomaticMonthlyRecord(r))monthlyChanged=true;});
  if((settings.dataVersion||0)<6){settings.dataVersion=6;records.forEach(r=>{if(expandAutomaticMonthlyRecord(r))monthlyChanged=true;});monthlyChanged=true;}
  if((settings.dataVersion||0)<7){records.forEach(r=>{if(rebaseInstallmentsToStartDate(r))monthlyChanged=true;if(expandAutomaticMonthlyRecord(r))monthlyChanged=true;});settings.dataVersion=7;monthlyChanged=true;}
  if((settings.dataVersion||0)<8){
    // v8: köhnə UTC tarix sürüşməsini düzəlt + ödəniş növünü açıq yaz
    records.forEach(r=>{normalizeRecord(r);if(!isOneTime(r))rebaseInstallmentsToStartDate(r);expandAutomaticMonthlyRecord(r);});
    settings.dataVersion=8;monthlyChanged=true;
  }
  if(monthlyChanged||!data.borcSettings)await chrome.storage.local.set({records,borcSettings:settings});
  $('reminderDays').value=settings.reminderDays;
  const now=new Date();$('todayText').textContent=`${now.getDate()} ${AZ_MONTHS[now.getMonth()]} ${now.getFullYear()}, ${AZ_DAYS[now.getDay()]}`;
  bind(); renderAll();
  window.addEventListener('ammo-cloud-updated', reloadFromCloudStorage);
}

function normalizeRecord(r){
  if(r.paymentMode!=='one_time'&&r.paymentMode!=='monthly') r.paymentMode=(r.isMonthly===false)?'one_time':'monthly';
  if(isOneTime(r)){r.isMonthly=false;r.autoRecurring=false;r.monthlyAmount=null;}
  return r;
}
async function reloadFromCloudStorage(){
  const data=await chrome.storage.local.get(['records','borcSettings']);
  records=(data.records||[]).map(normalizeRecord); settings={...settings,...(data.borcSettings||{})};
  renderAll();
}

function bind(){
  document.querySelectorAll('.nav-item').forEach(b=>b.onclick=()=>showPanel(b.dataset.panel));
  document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>showPanel(b.dataset.go));
  document.querySelectorAll('[data-stat-go]').forEach(b=>b.onclick=()=>openStatTarget(b.dataset.statGo));
  document.querySelectorAll('.clear-filter').forEach(b=>b.onclick=()=>clearListFilters(b.dataset.clear));
  $('quickAdd').onclick=()=>showPanel('manage');
  $('excelExport').onclick=downloadExcel;
  $('recordForm').onsubmit=saveRecord;
  document.querySelectorAll('input[name="paymentMode"]').forEach(x=>x.onchange=updatePaymentModeUI);
  $('closeMonthModal').onclick=closeMonthModal;
  $('monthModal').onclick=e=>{if(e.target.id==='monthModal')closeMonthModal();};
  $('historySearch').oninput=renderHistory;
  $('historyType').oninput=renderHistory;
  $('cancelEdit').onclick=resetForm;
  $('reminderDays').onchange=async e=>{settings.reminderDays=Number(e.target.value);await chrome.storage.local.set({borcSettings:settings});toast('Bildiriş ayarı yadda saxlanıldı');renderAll();};
  $('testNotification').onclick=async()=>{await chrome.runtime.sendMessage({type:'RUN_REMINDER_CHECK'});toast('Bildiriş yoxlaması başladıldı');};
  $('exportData').onclick=exportData;
  $('importData').onchange=importData;
  $('clearData').onclick=clearData;
  ['receivableSearch','receivableFilter','receivableCategory','receivableFrom','receivableTo','payableSearch','payableFilter','payableCategory','payableFrom','payableTo'].forEach(id=>$(id).oninput=renderTables);
  document.querySelectorAll('[data-mode-tab]').forEach(b=>b.onclick=()=>{const p=b.dataset.modeTab;document.querySelectorAll(`[data-mode-tab="${p}"]`).forEach(x=>x.classList.toggle('active',x===b));listMode[p]=b.dataset.mode;renderTables();});
  ['reportType','reportMode','reportStatus','reportCategory','reportFrom','reportTo','reportSearch'].forEach(id=>$(id).oninput=renderReport);
  $('downloadCsv').onclick=downloadCsv;
  $('downloadHtmlReport').onclick=downloadHtmlReport;
}

function showPanel(id){
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===id));
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.panel===id));
  const names={overview:'Ümumi baxış',receivables:'Alacaqlarım',payables:'Verəcəklərim',statistics:'Statistika',reports:'Hesabatlar',history:'Alınanlar və verilənlər',manage:'İdarəetmə paneli'};
  $('pageTitle').textContent=names[id]||'Borc Xatırladıcı';
  if(id==='statistics') renderStatistics();
  if(id==='reports') renderReport();
  if(id==='history') renderHistory();
  window.scrollTo({top:0,behavior:'smooth'});
}

function openStatTarget(target){
  if(target==='overdue'){
    const rec=records.filter(r=>r.type==='receivable'&&overdueInstallments(r).length).length;
    const pay=records.filter(r=>r.type==='payable'&&overdueInstallments(r).length).length;
    if(rec>=pay){$('receivableFilter').value='overdue';showPanel('receivables');renderTables();}
    else {$('payableFilter').value='overdue';showPanel('payables');renderTables();}
    return;
  }
  showPanel(target);
}

function updatePaymentModeUI(){
  const mode=document.querySelector('input[name="paymentMode"]:checked')?.value||'';
  const info=$('monthlyInfo'); if(info) info.classList.toggle('is-off',mode!=='monthly');
  const one=$('oneTimeInfo'); if(one) one.classList.toggle('is-off',mode!=='one_time');
  if($('amountLabel')) $('amountLabel').textContent=mode==='monthly'?'Aylıq məbləğ (hər ay)':mode==='one_time'?'Məbləğ (1 dəfəlik)':'Məbləğ';
  if($('dateLabel')) $('dateLabel').textContent=mode==='monthly'?'Hesablaşmanın başlama tarixi':'Son ödəniş tarixi';
}

async function saveRecord(e){
  e.preventDefault();
  const id=$('recordId').value||crypto.randomUUID();
  const existing=records.find(r=>r.id===id);
  const startDate=$('dueDate').value;
  const each=Number($('amount').value||0);
  const paymentMode=document.querySelector('input[name="paymentMode"]:checked')?.value;
  if(paymentMode!=='monthly'&&paymentMode!=='one_time'){toast('Ödəniş növünü seçin: 1 dəfəlik və ya hər ay üzrə');return;}
  if(!(each>0)){toast('Məbləği düzgün daxil edin');return;}
  const record={
    id,type:document.querySelector('input[name="type"]:checked').value,person:$('person').value.trim(),
    amount:each,monthlyAmount:paymentMode==='monthly'?each:null,baseAmount:each,currency:$('currency').value,
    dueDate:startDate,startDate,category:$('category').value,phone:$('phone').value.trim(),note:$('note').value.trim(),
    status:'open',paymentMode,isMonthly:paymentMode==='monthly',autoRecurring:paymentMode==='monthly',
    createdAt:existing?.createdAt||new Date().toISOString()
  };
  if(paymentMode==='monthly'){
    record.installments=(existing && !isOneTime(existing) && existing.startDate===startDate ? (existing.installments||[]) : (existing && !isOneTime(existing) ? rebasePaid(existing,startDate) : [])).map(i=>({...i,amount:each}));
    expandAutomaticMonthlyRecord(record);
  }else{
    const old=(existing?.paymentMode==='one_time' ? existing.installments?.[0] : null);
    record.installments=[{id:old?.id||crypto.randomUUID(),periodStart:startDate,dueDate:startDate,amount:each,status:old?.status||'open',paidAt:old?.paidAt||null}];
  }
  syncRecordStatus(record);
  const idx=records.findIndex(r=>r.id===id);
  if(idx>=0) records[idx]=record; else records.unshift(record);
  await persist(); resetForm(); renderAll(); showPanel(record.type==='receivable'?'receivables':'payables');
  toast(paymentMode==='monthly'?'Aylıq qeyd yadda saxlanıldı':'1 dəfəlik qeyd yadda saxlanıldı');
}
function rebasePaid(existing,startDate){
  // Başlama tarixi dəyişdikdə: ödənilmiş ayların statusunu eyni aylarda saxla
  const paid=new Map(ensureInstallments(existing).filter(i=>i.status==='paid').map(i=>[monthIndex(i.periodStart||i.dueDate),i]));
  const out=[];const need=accruedMonths(startDate);
  for(let k=0;k<need;k++){const ps=addMonths(startDate,k);const old=paid.get(monthIndex(ps));out.push({id:old?.id||crypto.randomUUID(),periodStart:ps,dueDate:addMonths(ps,1),amount:0,status:old?'paid':'open',paidAt:old?.paidAt||null});}
  return out;
}
async function persist(){await chrome.storage.local.set({records});}
function resetForm(){
  $('recordForm').reset();
  $('recordId').value='';
  $('formTitle').textContent='Yeni qeyd yarat';
  $('cancelEdit').classList.add('hidden');
  document.querySelector('input[name="type"][value="receivable"]').checked=true;
  document.querySelectorAll('input[name="paymentMode"]').forEach(x=>x.checked=false); updatePaymentModeUI();
}
function editRecord(id){
  const r=records.find(x=>x.id===id);if(!r)return;
  showPanel('manage');
  $('recordId').value=r.id;
  document.querySelector(`input[name="type"][value="${r.type}"]`).checked=true;
  $('person').value=r.person;
  $('amount').value=recordFace(r);
  document.querySelector(`input[name="paymentMode"][value="${r.paymentMode==='one_time'?'one_time':'monthly'}"]`).checked=true; updatePaymentModeUI();
  $('currency').value=r.currency;
  $('dueDate').value=r.startDate||ensureInstallments(r)[0]?.periodStart||r.dueDate;
  $('category').value=r.category;
  $('phone').value=r.phone||'';
  $('note').value=r.note||'';
  $('formTitle').textContent='Qeydi redaktə et';
  $('cancelEdit').classList.remove('hidden');
}
async function togglePaid(id){const r=records.find(x=>x.id===id);if(!r)return;if(!isOneTime(r)||ensureInstallments(r).length>1){openMonthModal(id);return;}const i=ensureInstallments(r)[0];if(!i)return;i.status=i.status==='paid'?'open':'paid';i.paidAt=i.status==='paid'?new Date().toISOString():null;syncRecordStatus(r);await persist();renderAll();toast(i.status==='paid'?'Ödəniş tamamlandı':'Qeyd yenidən açıldı');}
async function toggleInstallment(recordId,installmentId){const r=records.find(x=>x.id===recordId);if(!r)return;const i=ensureInstallments(r).find(x=>x.id===installmentId);if(!i)return;i.status=i.status==='paid'?'open':'paid';i.paidAt=i.status==='paid'?new Date().toISOString():null;syncRecordStatus(r);await persist();expandedRecords.add(recordId);renderAll();toast(i.status==='paid'?(r.type==='receivable'?'Seçilmiş ay üzrə alındı':'Seçilmiş ay üzrə ödənildi'):'Ay yenidən açıldı');}
function closeMonthModal(){$('monthModal').classList.add('hidden');}
function openMonthModal(id){toggleExpandedRecord(id);}
function toggleExpandedRecord(id){if(expandedRecords.has(id))expandedRecords.delete(id);else expandedRecords.add(id);renderTables();}
function installmentRows(r){
  const ins=ensureInstallments(r).slice().sort((a,b)=>a.dueDate.localeCompare(b.dueDate));
  const n=nextAccrual(r);
  const nextRow=n?`<div class="inline-month-row pending"><div><strong>${esc(monthLabel(n.periodStart))}</strong><small>Borc ${fmtDate(n.dueDate)}-də yazılacaq</small></div><strong>${fmt(n.amount,r.currency)}</strong><span class="month-status pending">Hələ hesablanmayıb</span><span></span></div>`:'';
  const emptyRow=!ins.length?`<div class="empty" style="padding:12px">Hələ heç bir ay bitməyib — ilk borc ${n?fmtDate(n.dueDate):''} tarixində yazılacaq.</div>`:'';
  return `<div class="inline-month-panel"><div class="inline-month-head"><div><strong>${esc(r.person)}</strong><span>${r.type==='receivable'?'Alacaq ayları':'Verəcək ayları'} · Qalıq ${fmt(outstandingAmount(r),r.currency)}</span></div></div><div class="inline-month-list">${ins.map(i=>{const d=dayDiff(i.dueDate);const paid=i.status==='paid';const cls=paid?'paid':d<0?'overdue':'upcoming';const status=paid?'Tamamlanıb':d<0?`${overdueDuration(i.dueDate).label} gecikib`:d===0?'Bu gün':`${d} gün qalıb`;const action=paid?'Yenidən aç':(r.type==='receivable'?'Aldım':'Ödədim');return `<div class="inline-month-row ${cls}"><div><strong>${esc(installmentLabel(i,r))}</strong><small>Son tarix: ${fmtDate(i.dueDate)}</small></div><strong>${fmt(i.amount,r.currency)}</strong><span class="month-status ${cls}">${esc(status)}</span><button class="month-action ${paid?'reopen':''}" data-inline-installment="${i.id}" data-record="${r.id}">${esc(action)}</button></div>`}).join('')}${emptyRow}${nextRow}</div></div>`;
}
async function convertMode(id){
  const r=records.find(x=>x.id===id);if(!r)return;
  const toOne=!isOneTime(r);const face=recordFace(r);
  const msg=toOne?`"${r.person}" qeydi 1 DƏFƏLİK ödənişə çevrilsin?\nMəbləğ: ${fmt(face,r.currency)} (aylar silinəcək, yalnız bir ödəniş qalacaq).`:`"${r.person}" qeydi HƏR AY ÜZRƏ ödənişə çevrilsin?\nHər ay: ${fmt(face,r.currency)}.`;
  if(!confirm(msg))return;
  const start=r.startDate||ensureInstallments(r)[0]?.periodStart||r.dueDate||ymd();
  if(toOne){
    const allPaid=ensureInstallments(r).every(i=>i.status==='paid');
    r.paymentMode='one_time';r.isMonthly=false;r.autoRecurring=false;r.monthlyAmount=null;r.baseAmount=face;r.startDate=start;
    r.installments=[{id:crypto.randomUUID(),periodStart:start,dueDate:start,amount:face,status:allPaid?'paid':'open',paidAt:allPaid?new Date().toISOString():null}];
  }else{
    r.paymentMode='monthly';r.isMonthly=true;r.monthlyAmount=face;r.baseAmount=face;r.startDate=start;r.installments=[];
    expandAutomaticMonthlyRecord(r);
  }
  syncRecordStatus(r);await persist();renderAll();toast(toOne?'1 dəfəlik ödənişə çevrildi':'Hər ay üzrə ödənişə çevrildi');
}
async function removeRecord(id){if(!confirm('Bu qeydi silmək istədiyinizə əminsiniz?'))return;records=records.filter(r=>r.id!==id);await persist();renderAll();toast('Qeyd silindi');}

function renderAll(){
  let grew=false;records.forEach(r=>{normalizeRecord(r);if(expandAutomaticMonthlyRecord(r))grew=true;});
  if(grew)persist();
  renderModeOverview();
  populateCategoryFilters();renderStats();renderAlerts();renderTables();renderStatistics();renderReport();renderHistory();
  $('receivableCount').textContent=records.filter(r=>r.type==='receivable'&&(outstandingAmount(r)>0||!isOneTime(r))).length;
  $('payableCount').textContent=records.filter(r=>r.type==='payable'&&(outstandingAmount(r)>0||!isOneTime(r))).length;
}

function populateCategoryFilters(){
  const cats=[...new Set(records.map(r=>r.category).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'az'));
  ['receivableCategory','payableCategory','reportCategory'].forEach(id=>{
    const el=$(id); const current=el.value||'all';
    el.innerHTML='<option value="all">Bütün kateqoriyalar</option>'+cats.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
    el.value=cats.includes(current)?current:'all';
  });
}

function sumBy(type, category=null, status='open'){
  return records.filter(r=>(!type||r.type===type)&&(!category||r.category===category)&&(status==='all'||(status==='open'?r.status!=='paid':r.status===status))).reduce((a,r)=>a+outstandingAmount(r),0);
}

function renderStats(){
  const open=records.filter(r=>outstandingAmount(r)>0);const rec=open.filter(r=>r.type==='receivable').reduce((a,r)=>a+outstandingAmount(r),0);const pay=open.filter(r=>r.type==='payable').reduce((a,r)=>a+outstandingAmount(r),0);
  $('totalReceivable').textContent=fmt(rec);$('totalPayable').textContent=fmt(pay);$('netBalance').textContent=fmt(rec-pay);$('overdueCount').textContent=open.reduce((a,r)=>a+overdueInstallments(r).length,0);
  const part=(type,one)=>open.filter(r=>r.type===type&&isOneTime(r)===one).reduce((a,r)=>a+outstandingAmount(r),0);
  $('receivableOpenText').textContent=`1 dəfəlik: ${fmt(part('receivable',true))} · Aylıq qalıq: ${fmt(part('receivable',false))}`;
  $('payableOpenText').textContent=`1 dəfəlik: ${fmt(part('payable',true))} · Aylıq qalıq: ${fmt(part('payable',false))}`;
  const odRec=records.filter(r=>overdueInstallments(r).length).length;$('overdueCount').textContent=odRec;
  if($('overdueSub'))$('overdueSub').textContent=`${open.reduce((a,r)=>a+overdueInstallments(r).length,0)} gecikmiş ödəniş / ay`;
  const net=c=>open.filter(r=>r.category===c).reduce((a,r)=>a+(r.type==='receivable'?1:-1)*outstandingAmount(r),0);$('businessNet').textContent=fmt(net('Biznes'));$('personalNet').textContent=fmt(net('Şəxsi'));
}

function timing(r){const open=openInstallments(r);if(!open.length){const n=nextAccrual(r);if(n){const any=ensureInstallments(r).length;return{cls:any?'paid':'open',label:any?'Ödənilib':'Gözləyir',detail:`${monthLabel(n.periodStart)} borcu ${fmtDate(n.dueDate)}-də yazılacaq`};}return{cls:'paid',label:'Tamamlanıb',detail:'Ödəniş bağlanıb'};}const overdue=overdueInstallments(r);if(overdue.length){const oldest=overdue.slice().sort((a,b)=>a.dueDate.localeCompare(b.dueDate))[0];const duration=overdueDuration(oldest.dueDate);const monthly=ensureInstallments(r).length>1;return{cls:'overdue',label:'Gecikib',detail:monthly?`${overdue.length} ödənilməmiş ay · ${duration.label} gecikib`:`${duration.label} gecikib`};}const d=dayDiff(nextDueDate(r));if(d===0)return{cls:'open',label:'Bu gün',detail:'Növbəti son tarix bu gündür'};return{cls:'open',label:'Gözləyir',detail:`${d} gün qalıb`};}

function alertCard(r,i){const d=dayDiff(i.dueDate);const overdue=d<0;const text=overdue?`${overdueDuration(i.dueDate).label} gecikib`:d===0?'Bu gün':`${d} gün qalıb`;return `<article class="payment-alert-card ${r.type} ${overdue?'is-overdue':''}" data-alert-record="${r.id}"><div><span class="tag ${r.type}">${r.type==='receivable'?'ALACAĞIM':'VERƏCƏYİM'}</span><h3>${esc(r.person)}</h3><p>${esc(installmentLabel(i,r))} · son tarix ${fmtDate(i.dueDate)}</p></div><div class="alert-amount"><strong>${fmt(i.amount,r.currency)}</strong><span class="countdown ${overdue?'overdue':''}">${esc(text)}</span></div></article>`;}
function renderAlerts(){
  const all=[];records.forEach(r=>{openInstallments(r).forEach(i=>all.push({r,i,d:dayDiff(i.dueDate)}));const n=nextAccrual(r);if(n){const d=dayDiff(n.dueDate);if(d>0&&d<=5)all.push({r,i:n,d});}});
  const upcoming=all.filter(x=>x.d>=0&&x.d<=5).sort((a,b)=>a.i.dueDate.localeCompare(b.i.dueDate));
  const overdue=all.filter(x=>x.d<0).sort((a,b)=>a.i.dueDate.localeCompare(b.i.dueDate));
  $('upcomingFiveList').innerHTML=upcoming.length?upcoming.map(x=>alertCard(x.r,x.i)).join(''):'<div class="empty">Son tarixə 5 gün qalan ödəniş yoxdur.</div>';
  $('overdueList').innerHTML=overdue.length?overdue.map(x=>alertCard(x.r,x.i)).join(''):'<div class="empty">Gecikmiş ödəniş yoxdur.</div>';
  document.querySelectorAll('[data-alert-record]').forEach(x=>x.onclick=()=>{const r=records.find(y=>y.id===x.dataset.alertRecord);if(!r)return;expandedRecords.add(r.id);showPanel(r.type==='receivable'?'receivables':'payables');renderTables();setTimeout(()=>document.querySelector(`[data-months="${r.id}"]`)?.scrollIntoView({behavior:'smooth',block:'center'}),50);});
}

function filtered(type){
  const p=type==='receivable'?'receivable':'payable';
  const search=$(p+'Search').value.toLowerCase(); const filter=$(p+'Filter').value; const category=$(p+'Category').value; const from=$(p+'From').value; const to=$(p+'To').value;
  return records.filter(r=>r.type===type)
    .filter(r=>`${r.person} ${r.note||''} ${r.phone||''} ${recordFace(r)} ${outstandingAmount(r)} ${r.category}`.toLowerCase().includes(search))
    .filter(r=>category==='all'||r.category===category)
    .filter(r=>!from||nextDueDate(r)>=from).filter(r=>!to||nextDueDate(r)<=to)
    .filter(r=>filter==='all'||(filter==='paid'&&outstandingAmount(r)===0)||(filter==='open'&&(outstandingAmount(r)>0||!isOneTime(r)))||(filter==='overdue'&&overdueInstallments(r).length>0)||(filter==='upcoming'&&outstandingAmount(r)>0&&dayDiff(nextDueDate(r))>=0&&dayDiff(nextDueDate(r))<=5))
    .sort((a,b)=>nextDueDate(a).localeCompare(nextDueDate(b)));
}
function clearListFilters(type){const p=type==='receivable'?'receivable':'payable';$(p+'Search').value='';$(p+'Filter').value='open';$(p+'Category').value='all';$(p+'From').value='';$(p+'To').value='';renderTables();}
function renderTables(){['receivable','payable'].forEach(type=>{
  const arr=filtered(type);const mode=listMode[type];
  const monthly=arr.filter(r=>!isOneTime(r)), one=arr.filter(isOneTime);
  const sum=a=>a.reduce((x,r)=>x+outstandingAmount(r),0);
  const mBox=$(type+'MonthlySection'), oBox=$(type+'OneTimeSection');
  mBox.classList.toggle('hidden',mode==='one_time'); oBox.classList.toggle('hidden',mode==='monthly');
  $(type+'MonthlySum').innerHTML=`<b>${monthly.length}</b> qeyd · Aylıq cəm: <b>${fmt(monthly.reduce((x,r)=>x+monthlyEach(r),0))}</b> · Ödənilməmiş qalıq: <b>${fmt(sum(monthly))}</b>`;
  $(type+'OneTimeSum').innerHTML=`<b>${one.length}</b> qeyd · Açıq qalıq: <b>${fmt(sum(one))}</b>`;
  renderTable(type,monthly,$(type+'MonthlyTable'),true);
  renderTable(type,one,$(type+'OneTimeTable'),false);
  document.querySelectorAll(`[data-mode-tab="${type}"]`).forEach(b=>{const c=b.dataset.mode==='all'?arr.length:b.dataset.mode==='monthly'?monthly.length:one.length;const n=b.querySelector('i');if(n)n.textContent=c;});
});}
function renderTable(type,arr,body,monthly){
  const cols=monthly?8:7;
  body.innerHTML=arr.length?arr.map(r=>{
    const t=timing(r),ins=ensureInstallments(r),expanded=expandedRecords.has(r.id);
    const openCnt=openInstallments(r).length;
    const nameCell=`<td><button class="clickable-name" data-months="${r.id}"><strong>${monthly?(expanded?'▾ ':'▸ '):''}${esc(r.person)}</strong></button><br><small>${esc(r.note||'Qeyd yoxdur')}</small>${monthly?`<br><span class="month-badge">${ins.length} ay hesablanıb · ${openCnt} ödənilməyib · ayları açmaq üçün klik edin</span>`:''}</td>`;
    const amountCells=monthly
      ?`<td><strong class="face-amount">${fmt(monthlyEach(r),r.currency)}</strong><br><small>hər ay</small></td><td><strong>${fmt(outstandingAmount(r),r.currency)}</strong><br><small>${openCnt} ay × ${fmt(monthlyEach(r),r.currency)}</small></td>`
      :`<td><strong class="face-amount">${fmt(recordFace(r),r.currency)}</strong><br><small>${outstandingAmount(r)>0?'Ödənilməyib':(r.type==='receivable'?'Alınıb':'Ödənilib')}</small></td>`;
    const payBtn=!monthly?`<button class="icon-btn ok" data-action="pay" data-id="${r.id}" title="${ins[0]?.status==='paid'?'Yenidən aç':(r.type==='receivable'?'Aldım':'Ödədim')}">${ins[0]?.status==='paid'?'↺':'✓'}</button>`:'';
    const main=`<tr class="record-main-row ${expanded?'expanded':''}">${nameCell}${amountCells}<td>${esc(r.category)}</td><td>${fmtDate(nextDueDate(r))}</td><td><span class="status ${t.cls}">${t.label}</span></td><td>${esc(t.detail)}</td><td><div class="row-actions">${payBtn}<button class="icon-btn" data-action="convert" data-id="${r.id}" title="${monthly?'1 dəfəlik ödənişə çevir':'Hər ay üzrə ödənişə çevir'}">⇄</button><button class="icon-btn" data-action="edit" data-id="${r.id}" title="Redaktə et">✎</button><button class="icon-btn" data-action="delete" data-id="${r.id}" title="Sil">×</button></div></td></tr>`;
    const detail=monthly&&expanded?`<tr class="record-detail-row"><td colspan="${cols}">${installmentRows(r)}</td></tr>`:'';
    return main+detail;
  }).join(''):`<tr><td colspan="${cols}" class="empty">${monthly?'Hər ay üzrə uyğun qeyd yoxdur.':'1 dəfəlik uyğun qeyd yoxdur.'}</td></tr>`;
  body.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>({edit:editRecord,delete:removeRecord,convert:convertMode,pay:togglePaid}[b.dataset.action](b.dataset.id)));
  body.querySelectorAll('[data-months]').forEach(b=>b.onclick=()=>{if(monthly)toggleExpandedRecord(b.dataset.months);});
  body.querySelectorAll('[data-inline-installment]').forEach(b=>b.onclick=()=>toggleInstallment(b.dataset.record,b.dataset.inlineInstallment));
}
function renderModeOverview(){
  const open=records.filter(r=>outstandingAmount(r)>0);
  const monthlyAll=records.filter(r=>!isOneTime(r)), oneOpen=open.filter(isOneTime);
  const mSum=(type)=>monthlyAll.filter(r=>r.type===type).reduce((a,r)=>a+monthlyEach(r),0);
  const mOpen=(type)=>monthlyAll.filter(r=>r.type===type).reduce((a,r)=>a+outstandingAmount(r),0);
  const mCnt=(type)=>monthlyAll.filter(r=>r.type===type).reduce((a,r)=>a+openInstallments(r).length,0);
  $('mRecMonthly').textContent=fmt(mSum('receivable'));$('mPayMonthly').textContent=fmt(mSum('payable'));
  $('mRecOpen').textContent=fmt(mOpen('receivable'));$('mRecOpenTxt').textContent=`${mCnt('receivable')} ödənilməmiş ay`;
  $('mPayOpen').textContent=fmt(mOpen('payable'));$('mPayOpenTxt').textContent=`${mCnt('payable')} ödənilməmiş ay`;
  const oSum=(type)=>oneOpen.filter(r=>r.type===type).reduce((a,r)=>a+outstandingAmount(r),0);
  $('oRecOpen').textContent=fmt(oSum('receivable'));$('oRecTxt').textContent=`${oneOpen.filter(r=>r.type==='receivable').length} açıq qeyd`;
  $('oPayOpen').textContent=fmt(oSum('payable'));$('oPayTxt').textContent=`${oneOpen.filter(r=>r.type==='payable').length} açıq qeyd`;
  const row=(r,monthly)=>`<button class="mode-row" data-open-record="${r.id}"><span class="tag ${r.type}">${r.type==='receivable'?'ALACAQ':'VERƏCƏK'}</span><span class="mode-name"><b>${esc(r.person)}</b><small>${monthly?(openInstallments(r).length?`${openInstallments(r).length} ay ödənilməyib · qalıq ${fmt(outstandingAmount(r),r.currency)}`:`borc yoxdur · növbəti ${fmtDate(nextAccrual(r)?.dueDate)}`):`son tarix ${fmtDate(nextDueDate(r))} · ${esc(timing(r).label)}`}</small></span><strong>${fmt(monthly?monthlyEach(r):recordFace(r),r.currency)}${monthly?'<em>/ay</em>':''}</strong></button>`;
  const mList=monthlyAll.slice().sort((a,b)=>outstandingAmount(b)-outstandingAmount(a));
  $('monthlyOverviewList').innerHTML=mList.length?mList.map(r=>row(r,true)).join(''):'<div class="empty">Hər ay üzrə qeyd yoxdur.</div>';
  $('oneTimeOverviewList').innerHTML=oneOpen.length?oneOpen.sort((a,b)=>nextDueDate(a).localeCompare(nextDueDate(b))).map(r=>row(r,false)).join(''):'<div class="empty">1 dəfəlik açıq ödəniş yoxdur.</div>';
  document.querySelectorAll('[data-open-record]').forEach(x=>x.onclick=()=>{const r=records.find(y=>y.id===x.dataset.openRecord);if(!r)return;if(!isOneTime(r))expandedRecords.add(r.id);showPanel(r.type==='receivable'?'receivables':'payables');renderTables();setTimeout(()=>document.querySelector(`[data-months="${r.id}"]`)?.scrollIntoView({behavior:'smooth',block:'center'}),60);});
}

function renderStatistics(){
  const open=records.filter(r=>outstandingAmount(r)>0);const paid=records.filter(r=>outstandingAmount(r)===0);const overdue=records.filter(r=>overdueInstallments(r).length>0);
  const rec=open.filter(r=>r.type==='receivable');const pay=open.filter(r=>r.type==='payable');
  $('statOpenRec').textContent=fmt(rec.reduce((a,r)=>a+outstandingAmount(r),0));$('statOpenRecCount').textContent=`${rec.length} qeyd`;
  $('statOpenPay').textContent=fmt(pay.reduce((a,r)=>a+outstandingAmount(r),0));$('statOpenPayCount').textContent=`${pay.length} qeyd`;
  $('statPaidTotal').textContent=fmt(records.reduce((a,r)=>a+paidAmount(r),0));$('statPaidCount').textContent=`${paid.length} qeyd`;
  $('statOverdueAmount').textContent=fmt(records.reduce((a,r)=>a+overdueInstallments(r).reduce((s,i)=>s+Number(i.amount),0),0));$('statOverdueText').textContent=`${overdue.length} qeyd`;
  renderMonthlyChart();renderCategoryNet();
}
function renderMonthlyChart(){
  const monthNames=['Yanvar','Fevral','Mart','Aprel','May','İyun','İyul','Avqust','Sentyabr','Oktyabr','Noyabr','Dekabr'];
  const months=[];const now=new Date();
  for(let i=5;i>=0;i--){
    const d=new Date(now.getFullYear(),now.getMonth()-i,1);
    months.push({key:`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`,label:`${monthNames[d.getMonth()]} ${d.getFullYear()}`});
  }
  const data=months.map(m=>{
    let rec=0,pay=0;
    records.forEach(r=>{
      ensureInstallments(r).forEach(i=>{
        if(i.dueDate.startsWith(m.key)){
          if(r.type==='receivable')rec+=Number(i.amount||0);else pay+=Number(i.amount||0);
        }
      });
    });
    return {...m,rec,pay};
  });
  const max=Math.max(...data.flatMap(x=>[x.rec,x.pay]),1);
  $('monthlyChart').innerHTML=data.map(x=>`<div class="chart-row"><span>${esc(x.label)}</span><div class="dual-bars"><div class="chart-bar receivable" style="width:${Math.max(2,x.rec/max*100)}%"><b>${fmt(x.rec)}</b></div><div class="chart-bar payable" style="width:${Math.max(2,x.pay/max*100)}%"><b>${fmt(x.pay)}</b></div></div></div>`).join('');
}
function renderCategoryNet(){
  const cats=[...new Set(records.map(r=>r.category).filter(Boolean))];
  const data=cats.map(c=>({c,net:records.filter(r=>r.category===c).reduce((a,r)=>a+(r.type==='receivable'?1:-1)*outstandingAmount(r),0)})).sort((a,b)=>Math.abs(b.net)-Math.abs(a.net));
  const max=Math.max(...data.map(x=>Math.abs(x.net)),1);
  $('categoryNetChart').innerHTML=data.length?data.map(x=>`<div class="net-row"><div><span>${esc(x.c)}</span><strong class="${x.net>=0?'positive':'negative'}">${fmt(x.net)}</strong></div><div class="net-track"><i class="${x.net>=0?'positive-bg':'negative-bg'}" style="width:${Math.max(3,Math.abs(x.net)/max*100)}%"></i></div></div>`).join(''):'<div class="empty">Statistika üçün məlumat yoxdur.</div>';
}

function renderHistory(){
  const search=($('historySearch')?.value||'').toLowerCase();const type=$('historyType')?.value||'all';const items=[];
  records.forEach(r=>ensureInstallments(r).filter(i=>i.status==='paid').forEach(i=>items.push({r,i})));
  const filtered=items.filter(x=>type==='all'||x.r.type===type).filter(x=>`${x.r.person} ${installmentLabel(x.i,x.r)} ${x.r.category}`.toLowerCase().includes(search)).sort((a,b)=>String(b.i.paidAt||'').localeCompare(String(a.i.paidAt||'')));
  if(!$('historyList'))return;
  $('historyList').innerHTML=filtered.length?filtered.map(({r,i})=>`<article class="history-item"><div><span class="tag ${r.type}">${r.type==='receivable'?'ALDIM':'ÖDƏDİM'}</span><h3>${esc(r.person)}</h3><p>${esc(installmentLabel(i,r))} · ${esc(r.category)}</p></div><div><strong>${fmt(i.amount,r.currency)}</strong><small>${i.paidAt?fmtDateTime(i.paidAt):'Tarix saxlanılmayıb'}</small></div></article>`).join(''):'<div class="empty">Hələ tamamlanmış ödəniş yoxdur.</div>';
}

function reportFiltered(){
  const type=$('reportType').value,status=$('reportStatus').value,category=$('reportCategory').value,from=$('reportFrom').value,to=$('reportTo').value,search=$('reportSearch').value.toLowerCase();
  return records.filter(r=>type==='all'||r.type===type).filter(r=>category==='all'||r.category===category).filter(r=>!from||nextDueDate(r)>=from).filter(r=>!to||nextDueDate(r)<=to).filter(r=>`${r.person} ${r.note||''} ${r.phone||''} ${recordFace(r)}`.toLowerCase().includes(search)).filter(r=>{const o=outstandingAmount(r)>0,d=dayDiff(nextDueDate(r));return status==='all'||(status==='paid'&&!o)||(status==='open'&&o)||(status==='overdue'&&overdueInstallments(r).length>0)||(status==='upcoming'&&o&&d>=0&&d<=5);}).filter(r=>{const m=$('reportMode')?.value||'all';return m==='all'||(m==='one_time')===isOneTime(r);}).sort((a,b)=>nextDueDate(a).localeCompare(nextDueDate(b)));
}
function renderReport(){
  const arr=reportFiltered();const rec=arr.filter(r=>r.type==='receivable').reduce((a,r)=>a+outstandingAmount(r),0);const pay=arr.filter(r=>r.type==='payable').reduce((a,r)=>a+outstandingAmount(r),0);
  $('reportSummary').innerHTML=`<div><span>Qeyd sayı</span><strong>${arr.length}</strong></div><div><span>Alacaq</span><strong>${fmt(rec)}</strong></div><div><span>Verəcək</span><strong>${fmt(pay)}</strong></div><div><span>Xalis</span><strong>${fmt(rec-pay)}</strong></div>`;
  $('reportTable').innerHTML=arr.length?arr.map(r=>{const t=timing(r);return `<tr><td><span class="tag ${r.type}">${r.type==='receivable'?'Alacaq':'Verəcək'}</span></td><td><strong>${esc(r.person)}</strong><br><small>${isOneTime(r)?'1 dəfəlik':'Hər ay üzrə'}${r.phone?' · '+esc(r.phone):''}</small></td><td><strong>${fmt(outstandingAmount(r),r.currency)}</strong><br><small>${isOneTime(r)?'Məbləğ: '+fmt(recordFace(r),r.currency):'Aylıq: '+fmt(monthlyEach(r),r.currency)}</small></td><td>${esc(r.category)}</td><td>${fmtDate(nextDueDate(r))}</td><td>${esc(t.label)} — ${esc(t.detail)}</td><td>${esc(r.note||'')}</td></tr>`}).join(''):'<tr><td colspan="7" class="empty">Bu filtrlərə uyğun hesabat məlumatı yoxdur.</td></tr>';
}
function downloadExcel(){
  const rows=[];
  records.forEach(r=>ensureInstallments(r).forEach(i=>{
    const d=dayDiff(i.dueDate);
    rows.push({
      type:r.type==='receivable'?'Alacaq':'Verəcək',
      person:r.person,
      phone:r.phone||'',
      mode:isOneTime(r)?'1 dəfəlik':'Hər ay üzrə',
      month:installmentLabel(i,r),
      amount:Number(i.amount||0),
      currency:r.currency,
      category:r.category,
      startDate:fmtDate(r.startDate),
      dueDate:fmtDate(i.dueDate),
      status:i.status==='paid'?(r.type==='receivable'?'Alınıb':'Ödənilib'):(d<0?'Gecikib':d===0?'Bu gün':`${d} gün qalıb`),
      paidAt:fmtDateTime(i.paidAt),
      note:r.note||''
    });
  }));
  const recOpen=records.filter(r=>r.type==='receivable').reduce((a,r)=>a+outstandingAmount(r),0);
  const payOpen=records.filter(r=>r.type==='payable').reduce((a,r)=>a+outstandingAmount(r),0);
  const headers=['Növ','Ödəniş növü','Şəxs / şirkət','Telefon','Ay','Məbləğ','Valyuta','Kateqoriya','Başlama tarixi','Son tarix','Vəziyyət','Alındığı / ödənildiyi tarix','Qeyd'];
  const cell=(v,type='String',style='')=>`<Cell${style?` ss:StyleID="${style}"`:''}><Data ss:Type="${type}">${xmlEsc(v)}</Data></Cell>`;
  const detailRows=rows.map(x=>`<Row>${cell(x.type)}${cell(x.mode)}${cell(x.person)}${cell(x.phone)}${cell(x.month)}${cell(x.amount,'Number','money')}${cell(x.currency)}${cell(x.category)}${cell(x.startDate)}${cell(x.dueDate)}${cell(x.status)}${cell(x.paidAt)}${cell(x.note)}</Row>`).join('');
  const xml=`<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Styles><Style ss:ID="Default"><Alignment ss:Vertical="Center"/><Font ss:FontName="Calibri" ss:Size="11"/></Style><Style ss:ID="header"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#0c1f44" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style><Style ss:ID="title"><Font ss:Bold="1" ss:Size="16"/></Style><Style ss:ID="money"><NumberFormat ss:Format="#,##0.00;[Red](#,##0.00);-"/></Style><Style ss:ID="kpi"><Font ss:Bold="1" ss:Size="12"/><Interior ss:Color="#eaf3ff" ss:Pattern="Solid"/></Style></Styles>
<Worksheet ss:Name="Xülasə"><Table><Column ss:Width="180"/><Column ss:Width="120"/><Row><Cell ss:MergeAcross="1" ss:StyleID="title"><Data ss:Type="String">Borc Xatırladıcı — Excel hesabatı</Data></Cell></Row><Row/><Row><Cell ss:StyleID="kpi"><Data ss:Type="String">Açıq alacaq</Data></Cell>${cell(recOpen,'Number','money')}</Row><Row><Cell ss:StyleID="kpi"><Data ss:Type="String">Açıq verəcək</Data></Cell>${cell(payOpen,'Number','money')}</Row><Row><Cell ss:StyleID="kpi"><Data ss:Type="String">Xalis vəziyyət</Data></Cell>${cell(recOpen-payOpen,'Number','money')}</Row><Row><Cell ss:StyleID="kpi"><Data ss:Type="String">İxrac tarixi</Data></Cell>${cell(fmtDateTime(new Date().toISOString()))}</Row></Table></Worksheet>
<Worksheet ss:Name="Aylar üzrə"><Table><Column ss:Width="90"/><Column ss:Width="95"/><Column ss:Width="180"/><Column ss:Width="100"/><Column ss:Width="100"/><Column ss:Width="90"/><Column ss:Width="65"/><Column ss:Width="95"/><Column ss:Width="95"/><Column ss:Width="95"/><Column ss:Width="110"/><Column ss:Width="145"/><Column ss:Width="220"/><Row>${headers.map(h=>cell(h,'String','header')).join('')}</Row>${detailRows}</Table><AutoFilter x:Range="R1C1:R${rows.length+1}C13" xmlns="urn:schemas-microsoft-com:office:excel"/></Worksheet></Workbook>`;
  downloadBlob('\uFEFF'+xml,'application/vnd.ms-excel;charset=utf-8',`borc-hesabati-${ymd()}.xls`);
  toast('Excel hesabatı yükləndi');
}
function downloadCsv(){
  const arr=reportFiltered();const rows=[['Növ','Ödəniş növü','Şəxs / şirkət','Telefon','Məbləğ (1 dəfəlik / aylıq)','Qalıq','Valyuta','Kateqoriya','Son tarix','Vəziyyət','Gün məlumatı','Qeyd'],...arr.map(r=>[r.type==='receivable'?'Alacaq':'Verəcək',isOneTime(r)?'1 dəfəlik':'Hər ay üzrə',r.person,r.phone||'',recordFace(r),outstandingAmount(r),r.currency,r.category,fmtDate(nextDueDate(r)),timing(r).label,timing(r).detail,r.note||''])];
  const csv='\uFEFF'+rows.map(row=>row.map(csvEsc).join(';')).join('\r\n');downloadBlob(csv,'text/csv;charset=utf-8',`borc-hesabati-${ymd()}.csv`);toast('CSV hesabatı yükləndi');
}
function downloadHtmlReport(){
  const arr=reportFiltered();const rec=arr.filter(r=>r.type==='receivable').reduce((a,r)=>a+outstandingAmount(r),0);const pay=arr.filter(r=>r.type==='payable').reduce((a,r)=>a+outstandingAmount(r),0);
  const rows=arr.map(r=>`<tr><td>${r.type==='receivable'?'Alacaq':'Verəcək'}<br><small>${isOneTime(r)?'1 dəfəlik':'Hər ay üzrə · '+fmt(monthlyEach(r),r.currency)+'/ay'}</small></td><td>${esc(r.person)}</td><td>${fmt(outstandingAmount(r),r.currency)}</td><td>${esc(r.category)}</td><td>${fmtDate(nextDueDate(r))}</td><td>${esc(timing(r).label)} — ${esc(timing(r).detail)}</td><td>${esc(r.note||'')}</td></tr>`).join('');
  const html=`<!doctype html><html lang="az"><head><meta charset="utf-8"><title>Borc hesabatı</title><style>body{font-family:Arial,sans-serif;padding:32px;color:#0b1c3f}h1{margin:0 0 6px}.muted{color:#667085}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:24px 0}.summary div{border:1px solid #ddd;border-radius:10px;padding:14px}.summary span,.summary strong{display:block}.summary strong{font-size:20px;margin-top:8px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:9px;text-align:left;font-size:12px}th{background:#f4f6f8}@media print{button{display:none}}</style></head><body><h1>Borc Xatırladıcı — Hesabat</h1><p class="muted">Hazırlanma tarixi: ${fmtDateTime(new Date().toISOString())}</p><div class="summary"><div><span>Qeyd sayı</span><strong>${arr.length}</strong></div><div><span>Alacaq</span><strong>${fmt(rec)}</strong></div><div><span>Verəcək</span><strong>${fmt(pay)}</strong></div><div><span>Xalis</span><strong>${fmt(rec-pay)}</strong></div></div><table><thead><tr><th>Növ</th><th>Şəxs / şirkət</th><th>Qalıq</th><th>Kateqoriya</th><th>Son tarix</th><th>Vəziyyət</th><th>Qeyd</th></tr></thead><tbody>${rows||'<tr><td colspan="7">Məlumat yoxdur</td></tr>'}</tbody></table></body></html>`;
  downloadBlob(html,'text/html;charset=utf-8',`borc-hesabati-${ymd()}.html`);toast('Hesabat yükləndi');
}
function downloadBlob(content,type,name){const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}

function exportData(){const blob=new Blob([JSON.stringify({records,settings,exportedAt:new Date().toISOString()},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`borc-xatirlatici-${ymd()}.json`;a.click();URL.revokeObjectURL(url);}
async function importData(e){const file=e.target.files[0];if(!file)return;try{const data=JSON.parse(await file.text());if(!Array.isArray(data.records))throw new Error();records=data.records.map(normalizeRecord);records.forEach(r=>expandAutomaticMonthlyRecord(r));settings={...settings,...(data.settings||{})};await chrome.storage.local.set({records,borcSettings:settings});$('reminderDays').value=settings.reminderDays;renderAll();toast('Məlumatlar uğurla bərpa edildi');}catch{alert('Fayl düzgün JSON ehtiyat nüsxəsi deyil.');}e.target.value='';}
async function clearData(){if(!confirm('Bütün qeydlər birdəfəlik silinəcək. Davam edilsin?'))return;records=[];await chrome.storage.local.set({records,notified:{}});renderAll();toast('Bütün məlumatlar silindi');}
function toast(text){const t=$('toast');t.textContent=text;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2500);}
init();
