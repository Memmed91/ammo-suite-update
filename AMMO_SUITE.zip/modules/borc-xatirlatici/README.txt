BORC XATIRLADICI - AVTOMATIK AYLIQ VERSIYA

Qeyd edilən başlanğıc aydan cari aya qədər bütün aylar avtomatik yaradılır.
Hər ayın qarşısında alacaq üçün Aldım, verəcək üçün Ödədim düyməsi var.
Bir ay bağlandıqda yalnız həmin ay tamamlanır, digər aylar açıq qalır.

Quraşdırma:
1. chrome://extensions/ açın.
2. Developer mode aktiv edin.
3. Load unpacked seçin.
4. Bu qovluğu göstərin.


YENİLİK (Variant 1): Başlama tarixi hansı aydadırsa, ilk aylıq borc məhz həmin aydan yaranır. Məsələn, 01.02.2026 → Fevral 2026; Yanvar yaradılmır. Yuxarı sağ hissədə Excel ixrac düyməsi əlavə edilib.
