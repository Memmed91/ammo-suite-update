
const sectionKeys = Object.keys(DECLARATION_SECTIONS);
let currentSection = 0;
const values = {};
const meta = {};

function format(n){ return Number(n || 0).toFixed(2).replace(".", ","); }
function parseNumber(v){
  if(!v) return 0;
  return Number(String(v).replace(/\s/g,"").replace(",",".").replace(/[^\d.-]/g,"")) || 0;
}
function isTotal(code){
  return ["218","220","234","236","237","239","241","243","245","1","2"].includes(code);
}
function setValue(code, val){ values[code] = format(parseNumber(val)); }
function getValue(code){ return parseNumber(values[code]); }

function buildNav(){
  const nav = document.getElementById("nav");
  nav.innerHTML = sectionKeys.map((key,i)=>`<button class="nav ${i===0?'active':''}" data-index="${i}">${i+1} ${DECLARATION_SECTIONS[key].title}</button>`).join("");
  nav.querySelectorAll(".nav").forEach(btn=>{
    btn.onclick = () => showSection(Number(btn.dataset.index));
  });
}

function buildSections(){
  const wrap = document.getElementById("sections");
  let html = "";
  sectionKeys.forEach((key,i)=>{
    const sec = DECLARATION_SECTIONS[key];
    html += `<section id="${key}" class="section ${i===0?'active':''}"><h3>${sec.subtitle}</h3>`;
    if(sec.type === "form"){
      html += `<div class="formGrid">`;
      sec.fields.forEach(([id,label,def])=>{
        html += `<label>${label}</label><input id="${id}" data-meta="${id}" value="${def || ''}">`;
      });
      html += `</div>`;
    } else {
      html += `<div class="table">
        <div class="row header"><div class="code">Göstərici</div><div class="label">Açıqlama</div><div class="amount">Məbləğ</div></div>`;
      sec.rows.forEach(([code,label])=>{
        html += `<div class="row ${isTotal(code)?'totalRow':''}">
          <div class="code">${code}</div>
          <div class="label">${label}</div>
          <div class="amount"><input data-code="${code}" value="${values[code] || '0,00'}"></div>
        </div>`;
      });
      html += `</div>`;
    }
    html += `</section>`;
  });
  wrap.innerHTML = html;
}

function showSection(index){
  currentSection = index;
  document.querySelectorAll(".section").forEach(s=>s.classList.remove("active"));
  document.querySelectorAll(".nav").forEach(s=>s.classList.remove("active"));
  document.getElementById(sectionKeys[index]).classList.add("active");
  document.querySelectorAll(".nav")[index].classList.add("active");
  document.getElementById("sectionTitle").textContent = DECLARATION_SECTIONS[sectionKeys[index]].title;
}

function collectInputs(){
  document.querySelectorAll("input[data-code]").forEach(i => values[i.dataset.code] = i.value);
  document.querySelectorAll("[data-meta]").forEach(i => meta[i.dataset.meta] = i.value);
  meta.periodYear = document.getElementById("periodYear").value;
  meta.declType = document.getElementById("declType").value;
  meta.sendType = document.getElementById("sendType").value;
}

function applyInputs(){
  document.querySelectorAll("input[data-code]").forEach(i => i.value = values[i.dataset.code] || "0,00");
  document.querySelectorAll("[data-meta]").forEach(i => { if(meta[i.dataset.meta] !== undefined) i.value = meta[i.dataset.meta]; });
  if(meta.periodYear) document.getElementById("periodYear").value = meta.periodYear;
  if(meta.declType) document.getElementById("declType").value = meta.declType;
  if(meta.sendType) document.getElementById("sendType").value = meta.sendType;
}

function calculate(){
  collectInputs();

  const totalIncome = getValue("200.1.1") + getValue("200.1.2") + getValue("200.2") + getValue("201") + getValue("202") + getValue("203") + getValue("204") + getValue("205") + getValue("206") + getValue("207") + getValue("208");
  if(totalIncome > 0){
    setValue("200.1", getValue("200.1.1") + getValue("200.1.2"));
    setValue("200", getValue("200.1") + getValue("200.2"));
    setValue("218", totalIncome);
    setValue("220", totalIncome - getValue("219"));
  }

  const totalExpenses =
    getValue("221.1") + getValue("221.2") + getValue("221.3") + getValue("221.4") +
    getValue("221.5") + getValue("221.6") + getValue("221.7") + getValue("221.8") +
    getValue("221.9") + getValue("221.10") + getValue("221.11") + getValue("221.12") +
    getValue("221.13") + getValue("221.14") + getValue("221.15") + getValue("222") +
    getValue("223") + getValue("224") + getValue("225") + getValue("226");
  if(totalExpenses > 0){
    setValue("234", totalExpenses);
    setValue("236", totalExpenses);
  }

  const profit = getValue("220") - getValue("236");
  setValue("237", profit > 0 ? profit : 0);
  setValue("239", profit < 0 ? Math.abs(profit) : 0);
  const taxable = Math.max(0, getValue("237") - getValue("238") - getValue("240"));
  setValue("241", taxable);
  if(!getValue("242")) setValue("242", 20);
  setValue("243", taxable * getValue("242") / 100);
  setValue("245", Math.max(0, getValue("243") - getValue("244")));

  const assets = ["1.1","1.2","1.3","1.4","1.5","1.6","1.7","1.8","1.9","1.10"].reduce((s,c)=>s+getValue(c),0);
  const liabilities = ["2.1","2.2"].reduce((s,c)=>s+getValue(c),0);
  if(assets > 0) setValue("1", assets);
  if(liabilities > 0) setValue("2", liabilities);

  buildSections();
  applyInputs();
  showSection(currentSection);
}

document.addEventListener("input", e=>{
  if(e.target.matches("input[data-code]")) calculate();
});

document.getElementById("nextBtn").onclick = ()=>{ if(currentSection < sectionKeys.length-1) showSection(currentSection+1); };
document.getElementById("prevBtn").onclick = ()=>{ if(currentSection > 0) showSection(currentSection-1); };

document.getElementById("clearBtn").onclick = ()=>{
  if(confirm("Bütün məbləğlər təmizlənsin?")){
    Object.keys(values).forEach(k=>delete values[k]);
    buildSections(); showSection(currentSection);
  }
};

document.getElementById("saveBtn").onclick = ()=>{
  collectInputs();
  chrome.storage.local.set({menfeetVisual:{values,meta}}, ()=>alert("Qaralamada saxlanıldı."));
};

document.getElementById("exportBtn").onclick = ()=>{
  collectInputs();
  const data = {meta, values, exportedAt: new Date().toISOString()};
  const blob = new Blob([JSON.stringify(data,null,2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({url, filename:"menfeet_beyannamesi_visual.json", saveAs:true});
};

document.getElementById("printBtn").onclick = ()=>window.print();

document.getElementById("fillBtn").onclick = ()=>{
  const file = document.getElementById("jsonFile").files[0];
  if(!file){ alert("JSON faylı seçilməyib. Əvvəl ixrac edilmiş JSON faylı seçə bilərsən."); return; }
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const data = JSON.parse(reader.result);
      Object.assign(values, data.values || {});
      Object.assign(meta, data.meta || {});
      buildSections(); applyInputs(); calculate();
      alert("Məlumatlar dolduruldu.");
    }catch(e){ alert("JSON oxunmadı: " + e.message); }
  };
  reader.readAsText(file);
};

document.getElementById("backBtn").onclick = ()=>history.back();

buildNav();
buildSections();

chrome.storage.local.get(["menfeetVisual"], res=>{
  if(res.menfeetVisual){
    Object.assign(values, res.menfeetVisual.values || {});
    Object.assign(meta, res.menfeetVisual.meta || {});
    buildSections(); applyInputs(); calculate();
  }
});
