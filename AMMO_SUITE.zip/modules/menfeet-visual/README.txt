MƏNFƏƏT BƏYANNAMƏSİ VİZUAL FORM

Bu paket Chrome Extension kimi hazırlanıb.
Açılışda e-taxes görünüşünə yaxın vizual forma açılır.

Daxildir:
- Ümumi məlumat
- Gəlirlər
- Xərclər
- Verginin hesablanması
- Aktivlər və öhdəliklər
- İcmal
- Avtomatik cəmləmə
- Qaralama saxla
- JSON ixrac/import
- Çap / PDF

Quraşdırma:
1. ZIP faylını Extract et.
2. Chrome aç: chrome://extensions/
3. Developer mode aktiv et.
4. Load unpacked seç.
5. MENFEET_BEYANNAME_VISUAL_FORM qovluğunu seç.

Qeyd:
Sənin göndərdiyin ZIP-dən 11 HTML faylı tapıldı.
