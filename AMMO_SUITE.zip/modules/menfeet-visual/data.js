const DECLARATION_SECTIONS = {
  "general": {
    "title": "Ümumi məlumat",
    "subtitle": "Ümumi məlumat",
    "type": "form",
    "fields": [
      [
        "taxOffice",
        "Vergi orqanının adı",
        "İqtisadiyyat Nazirliyi yanında Dövlət Vergi Xidmətinin Bakı şəhəri Lokal Gəlirlər Baş İdarəsi"
      ],
      [
        "voen",
        "VÖEN",
        ""
      ],
      [
        "companyName",
        "Vergi ödəyicisinin tam adı",
        ""
      ],
      [
        "activity",
        "Əsas fəaliyyət növü",
        ""
      ]
    ]
  },
  "income": {
    "title": "Gəlirlər",
    "subtitle": "Hesabat dövrünün GƏLİRLƏRİ",
    "rows": [
      [
        "200",
        "Malların təqdim edilməsindən (işlərin görülməsindən, xidmətlərin göstərilməsindən) gəlir"
      ],
      [
        "200.1",
        "Malların təqdim edilməsindən gəlir"
      ],
      [
        "200.1.1",
        "Pərakəndə satışdan gəlir"
      ],
      [
        "200.1.2",
        "Topdan satışdan gəlir"
      ],
      [
        "200.2",
        "İşlərin görülməsindən və xidmətlərin göstərilməsindən gəlir"
      ],
      [
        "201",
        "Royalti gəlirləri"
      ],
      [
        "202",
        "Faiz gəlirləri"
      ],
      [
        "203",
        "Əmlakın icarəyə verilməsindən gəlir"
      ],
      [
        "204",
        "Aktivlərin təqdim edilməsindən gəlir"
      ],
      [
        "205",
        "Məzənnə fərqindən gəlir"
      ],
      [
        "206",
        "Əvəzsiz alınmış aktivlər üzrə gəlir"
      ],
      [
        "207",
        "Silinmiş kreditor borcları üzrə gəlir"
      ],
      [
        "208",
        "Sair gəlirlər"
      ],
      [
        "218",
        "ÜMUMİ GƏLİRLƏR"
      ],
      [
        "219",
        "Gəlirdən çıxılan məbləğlər"
      ],
      [
        "220",
        "Çıxılmalardan sonra ÜMUMİ GƏLİR"
      ]
    ]
  },
  "expenses": {
    "title": "Xərclər",
    "subtitle": "Hesabat dövründə gəlirlərin əldə edilməsi ilə bağlı XƏRCLƏR",
    "rows": [
      [
        "221",
        "Malların təqdim edilməsi, iş görülməsi və xidmət göstərilməsi üzrə xərclər"
      ],
      [
        "221.1",
        "Əmək haqqı və ona bərabər tutulan ödəmələr"
      ],
      [
        "221.1.1",
        "Əcnəbi işçilər üzrə"
      ],
      [
        "221.1.2",
        "Yerli işçilər üzrə"
      ],
      [
        "221.2",
        "Sosial sığorta haqları"
      ],
      [
        "221.3",
        "Xammal və materiallar"
      ],
      [
        "221.4",
        "Malın dəyəri"
      ],
      [
        "221.5",
        "İcarə haqqı"
      ],
      [
        "221.5.1",
        "Rezident şəxslər üzrə icarə haqqı"
      ],
      [
        "221.5.1.1",
        "Hüquqi şəxslər üzrə"
      ],
      [
        "221.5.1.2",
        "Fiziki şəxslər üzrə"
      ],
      [
        "221.6",
        "Amortizasiya ayırmaları"
      ],
      [
        "221.7",
        "Təmir xərcləri"
      ],
      [
        "221.8",
        "Ezamiyyə xərcləri"
      ],
      [
        "221.9",
        "Sığorta xərcləri"
      ],
      [
        "221.10",
        "Kommunal xərclər"
      ],
      [
        "221.11",
        "Rabitə və internet xərcləri"
      ],
      [
        "221.12",
        "Nəqliyyat xərcləri"
      ],
      [
        "221.13",
        "Bank xidməti üzrə xərclər"
      ],
      [
        "221.14",
        "Reklam və marketinq xərcləri"
      ],
      [
        "221.15",
        "Bilavasitə malların təqdim edilməsi ilə bağlı sair xərclər"
      ],
      [
        "222",
        "Faiz xərcləri"
      ],
      [
        "223",
        "Royalti xərcləri"
      ],
      [
        "224",
        "Şübhəli borclar üzrə xərclər"
      ],
      [
        "225",
        "Məzənnə fərqindən zərər"
      ],
      [
        "226",
        "Sair xərclər"
      ],
      [
        "234",
        "CƏMİ XƏRCLƏR"
      ],
      [
        "236",
        "Ümumi gəlirlərdən çıxılan xərclər"
      ]
    ]
  },
  "tax": {
    "title": "Verginin hesablanması",
    "subtitle": "Hesabat dövrü üçün verginin hesablanması",
    "rows": [
      [
        "237",
        "Vergitutma məqsədləri üçün mənfəət"
      ],
      [
        "238",
        "Mənfəət üzrə azadolmalar və güzəştlər"
      ],
      [
        "239",
        "Zərər"
      ],
      [
        "240",
        "Keçmiş illərin zərəri"
      ],
      [
        "241",
        "Vergiyə cəlb olunan mənfəət"
      ],
      [
        "242",
        "Mənfəət vergisinin dərəcəsi"
      ],
      [
        "243",
        "Mənfəət vergisi"
      ],
      [
        "244",
        "Azaldılmalı verginin məbləği"
      ],
      [
        "245",
        "Ödənilməli mənfəət vergisinin məbləği"
      ]
    ]
  },
  "assets": {
    "title": "Aktivlər və öhdəliklər",
    "subtitle": "Vergi uçotunun məqsədləri üçün aktivlər, öhdəliklər və kapital",
    "rows": [
      [
        "1",
        "Cəmi aktivlər"
      ],
      [
        "1.1",
        "Torpaq, tikili və avadanlıqlar"
      ],
      [
        "1.2",
        "Qeyri-maddi aktivlər"
      ],
      [
        "1.3",
        "Ehtiyatlar"
      ],
      [
        "1.3.1",
        "Xammal və materiallar"
      ],
      [
        "1.3.2",
        "Mallar"
      ],
      [
        "1.3.3",
        "Hazır məhsul"
      ],
      [
        "1.4",
        "Debitor borcları"
      ],
      [
        "1.5",
        "Pul vəsaitləri"
      ],
      [
        "1.6",
        "Verilmiş avanslar"
      ],
      [
        "1.7",
        "Vergilər üzrə artıq ödəmələr"
      ],
      [
        "1.8",
        "Qısamüddətli maliyyə qoyuluşları"
      ],
      [
        "1.9",
        "Uzunmüddətli maliyyə qoyuluşları"
      ],
      [
        "1.10",
        "Digər aktivlər"
      ],
      [
        "2",
        "Cəmi kapital və öhdəliklər"
      ],
      [
        "2.1",
        "Cəmi kapital"
      ],
      [
        "2.1.1",
        "Nizamnamə kapitalı"
      ],
      [
        "2.1.2",
        "Bölüşdürülməmiş mənfəət / zərər"
      ],
      [
        "2.2",
        "Cəmi öhdəliklər"
      ],
      [
        "2.2.1",
        "Kreditor borcları"
      ],
      [
        "2.2.1.1",
        "Malsatan və podratçılar üzrə kreditor borcları"
      ],
      [
        "2.2.1.2",
        "Əmək haqqı üzrə kreditor borcları"
      ],
      [
        "2.2.1.3",
        "Dövlət büdcəsinə vergi öhdəlikləri"
      ],
      [
        "2.2.1.4",
        "Sosial sığorta və digər öhdəliklər"
      ],
      [
        "2.2.2",
        "Alınmış avanslar"
      ],
      [
        "2.2.3",
        "Kreditlər və borclar"
      ],
      [
        "2.2.4",
        "Digər öhdəliklər"
      ]
    ]
  },
  "summary": {
    "title": "İcmal",
    "subtitle": "Mənfəət vergisi bəyannaməsi üzrə icmal",
    "rows": [
      [
        "200",
        "Malların təqdim edilməsindən və xidmətlərdən gəlir"
      ],
      [
        "218",
        "ÜMUMİ GƏLİRLƏR"
      ],
      [
        "220",
        "Çıxılmalardan sonra ÜMUMİ GƏLİR"
      ],
      [
        "234",
        "CƏMİ XƏRCLƏR"
      ],
      [
        "236",
        "Ümumi gəlirlərdən çıxılan xərclər"
      ],
      [
        "237",
        "Vergitutma məqsədləri üçün mənfəət"
      ],
      [
        "239",
        "Zərər"
      ],
      [
        "241",
        "Vergiyə cəlb olunan mənfəət"
      ],
      [
        "242",
        "Mənfəət vergisinin dərəcəsi"
      ],
      [
        "243",
        "Mənfəət vergisi"
      ],
      [
        "244",
        "Azaldılmalı verginin məbləği"
      ],
      [
        "245",
        "Ödənilməli mənfəət vergisinin məbləği"
      ],
      [
        "1",
        "Cəmi aktivlər"
      ],
      [
        "2",
        "Cəmi kapital və öhdəliklər"
      ]
    ]
  }
};

/*
BBEC 2.20 DÜZƏLİŞ MƏNTİQİ

VAHİD BƏYANNAMƏ:
902 Gəlirlər, cəmi -> "Rüb üzrə orta say"
1+2+3+4 rüb cəmi -> 221.1.2

OMV:
1607.1.1 Hüquqi şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.1

1607.1.2 Fiziki şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.2
*/
