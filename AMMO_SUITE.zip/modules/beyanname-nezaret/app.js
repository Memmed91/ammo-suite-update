const firebaseConfig = {
  apiKey: "AIzaSyCwcYEbn6WAIhgYgYwCPsEde1uPjPL7n_8",
  authDomain: "gomruk-nezaret.firebaseapp.com",
  projectId: "gomruk-nezaret",
  storageBucket: "gomruk-nezaret.firebasestorage.app",
  messagingSenderId: "1055442363796",
  appId: "1:1055442363796:web:b3de53d144db4f854d9b81"
};

const COLLECTION = "beyannameNezaret";
const LOCAL_KEY = "ammo_beyanname_nezaret_fixed_local";
const AUTH_KEY = "ammo_beyanname_nezaret_fixed_auth";
const BASE = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/(default)/documents/${COLLECTION}`;
const SIGNUP_URL = `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${firebaseConfig.apiKey}`;
const REFRESH_URL = `https://securetoken.googleapis.com/v1/token?key=${firebaseConfig.apiKey}`;

const years = ["2024","2025","2026","2027","2028","2029","2030"];
const months = [
  ["01","YANVAR"],["02","FEVRAL"],["03","MART"],["04","APREL"],["05","MAY"],["06","İYUN"],
  ["07","İYUL"],["08","AVQUST"],["09","SENTYABR"],["10","OKTYABR"],["11","NOYABR"],["12","DEKABR"]
];
const rubs = ["1 RÜB","2 RÜB","3 RÜB","4 RÜB"];
const statuses = [
  "TƏSDİQLƏNDİ",
  "UYĞUNSUZLUQ YOXLAMASINDA",
  "KAMERAL",
  "KAMERAL TƏSDİQLƏNDİ",
  "ANOLOJİ",
  "ANOLOJİ TƏSDİQLƏNDİ",
  "TƏQDİM OLUNAN"
];

let page = "cari";
let data = [];
let editId = null;
let authState = null;
let firebaseOk = false;
let pollTimer = null;

function $(id){ return document.getElementById(id); }
function todayText(){ return new Date().toLocaleString("az-AZ"); }
function clean(v){ return String(v || "").trim(); }
function safe(v){ return String(v ?? "").replace(/[&<>"']/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m])); }
function newId(){ return "id_" + Date.now() + "_" + Math.random().toString(16).slice(2); }
function chromeGet(key){ return new Promise(res => chrome.storage.local.get([key], r => res(r[key]))); }
function chromeSet(obj){ return new Promise(res => chrome.storage.local.set(obj, res)); }

function normalizeStatus(value){
  return value === "TƏSDİQLƏNMƏDİ" ? "UYĞUNSUZLUQ YOXLAMASINDA" : value;
}
function normalizeRecordStatuses(record){
  const out = {...record};
  ["edvStatus","omvStatus","vvbStatus","svStatus","emlakStatus","menfeetStatus","torpaqStatus"].forEach(key => {
    out[key] = normalizeStatus(out[key]);
  });
  return out;
}

function firebaseErrorText(err){
  const msg = String(err?.message || err || "");
  if(msg.includes("ADMIN_ONLY_OPERATION") || msg.includes("OPERATION_NOT_ALLOWED")){
    return "Firebase: Anonymous provider aktiv deyil";
  }
  if(msg.includes("PERMISSION_DENIED")){
    return "Firebase: Rules icazə vermir";
  }
  if(msg.includes("API key")){
    return "Firebase: API key xətası";
  }
  return "Firebase: xəta";
}

function setFirebaseState(ok, text){
  firebaseOk = ok;
  $("firebaseBtn").textContent = text;
  $("firebaseState").textContent = text;
  $("firebaseBtn").title = text;
  $("firebaseBtn").className = ok ? "firebaseOk" : "firebaseBad";
}

function toFsValue(v){
  if(typeof v === "number") return {doubleValue:v};
  if(typeof v === "boolean") return {booleanValue:v};
  return {stringValue:String(v ?? "")};
}
function toFsFields(obj){
  const out = {};
  Object.keys(obj).forEach(k => out[k] = toFsValue(obj[k]));
  return out;
}
function fromFsFields(fields){
  const obj = {};
  Object.keys(fields || {}).forEach(k => {
    const v = fields[k];
    if("stringValue" in v) obj[k] = v.stringValue;
    else if("integerValue" in v) obj[k] = Number(v.integerValue);
    else if("doubleValue" in v) obj[k] = Number(v.doubleValue);
    else if("booleanValue" in v) obj[k] = !!v.booleanValue;
    else obj[k] = "";
  });
  return obj;
}
function docIdFromName(name){ return String(name || "").split("/").pop(); }

async function anonymousLogin(){
  let saved = await chromeGet(AUTH_KEY);
  if(saved && saved.refreshToken){
    authState = saved;
    if(!authState.idToken || Date.now() > (authState.expiresAt || 0) - 60000){
      try{ await refreshToken(); return; }
      catch(e){
        // V29.2: token həqiqətən etibarsızdırsa yeni sessiya aç; internet xətasıdırsa saxlanmış tokenlə davam et
        if(!/INVALID_REFRESH_TOKEN|TOKEN_EXPIRED|USER_DISABLED|USER_NOT_FOUND|MISSING_REFRESH_TOKEN/.test(String(e?.message||''))) throw e;
        authState = null; await chromeSet({[AUTH_KEY]:null});
      }
    } else return;
  }
  const res = await fetch(SIGNUP_URL, {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({returnSecureToken:true})
  });
  const json = await res.json();
  if(!res.ok) throw new Error(json?.error?.message || "Anonymous Firebase giriş alınmadı");
  authState = {
    idToken: json.idToken,
    refreshToken: json.refreshToken,
    expiresAt: Date.now() + Number(json.expiresIn || 3600) * 1000
  };
  await chromeSet({[AUTH_KEY]:authState});
}
async function refreshToken(){
  if(!authState?.refreshToken) throw new Error("Firebase token yoxdur");
  const body = new URLSearchParams();
  body.set("grant_type", "refresh_token");
  body.set("refresh_token", authState.refreshToken);
  const res = await fetch(REFRESH_URL, {method:"POST", body});
  const json = await res.json();
  if(!res.ok) throw new Error(json?.error?.message || "Firebase token yenilənmədi");
  authState.idToken = json.id_token;
  authState.refreshToken = json.refresh_token || authState.refreshToken;
  authState.expiresAt = Date.now() + Number(json.expires_in || 3600) * 1000;
  await chromeSet({[AUTH_KEY]:authState});
}
async function apiFetch(url, opt={}){
  if(!authState?.idToken) await anonymousLogin();
  const res = await fetch(url, {
    ...opt,
    headers:{
      "Content-Type":"application/json",
      "Authorization":"Bearer " + authState.idToken,
      ...(opt.headers || {})
    }
  });
  if(res.status === 401){
    await refreshToken();
    return apiFetch(url, opt);
  }
  const text = await res.text();
  let json = {};
  try{ json = text ? JSON.parse(text) : {}; }catch(e){}
  if(!res.ok) throw new Error(json?.error?.message || ("Firebase xəta: " + res.status));
  return json;
}

async function initFirebase(){
  try{
    await anonymousLogin();
    await fetchFirebaseRecords();
    setFirebaseState(true, "Firebase: aktiv");
    if(pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(fetchFirebaseRecordsSilent, 5000);
  }catch(e){
    console.error(e);
    setFirebaseState(false, firebaseErrorText(e));
    loadLocal();
    setTimeout(initFirebase, 15000); // V29.2: qoşulma alınmadısa avtomatik yenidən cəhd
  }
}
async function fetchFirebaseRecords(){
  const json = await apiFetch(`${BASE}?pageSize=1000`);
  data = (json.documents || [])
    .map(doc => normalizeRecordStatuses({id:docIdFromName(doc.name), ...fromFsFields(doc.fields)}))
    .filter(r => !r.deleted);
  saveLocal();
  renderAll();
}
async function fetchFirebaseRecordsSilent(){
  try{
    await fetchFirebaseRecords();
    setFirebaseState(true, "Firebase: aktiv");
  }catch(e){
    console.error(e);
    setFirebaseState(false, firebaseErrorText(e));
  }
}
function loadLocal(){
  data = JSON.parse(localStorage.getItem(LOCAL_KEY) || "[]").map(normalizeRecordStatuses);
  renderAll();
}
function saveLocal(){
  localStorage.setItem(LOCAL_KEY, JSON.stringify(data));
}
async function saveRecord(record){
  const row = {...record, id: editId || record.id || newId(), updatedAt:String(Date.now()), deleted:false};
  const localIndex = data.findIndex(x => x.id === row.id);
  if(localIndex >= 0) data[localIndex] = row; else data.unshift(row);
  saveLocal();
  renderAll();

  if(firebaseOk || authState){
    try{
      await apiFetch(`${BASE}/${encodeURIComponent(row.id)}`, {
        method:"PATCH",
        body:JSON.stringify({fields:toFsFields(row)})
      });
      await fetchFirebaseRecords();
      setFirebaseState(true, "Firebase: aktiv");
    }catch(e){
      console.error(e);
      setFirebaseState(false, firebaseErrorText(e));
    }
  }
}
async function deleteRecord(id){
  data = data.filter(x => x.id !== id);
  saveLocal();
  renderAll();
  if(firebaseOk || authState){
    try{
      await apiFetch(`${BASE}/${encodeURIComponent(id)}`, {method:"DELETE"});
      setFirebaseState(true, "Firebase: aktiv");
    }catch(e){
      console.error(e);
      setFirebaseState(false, firebaseErrorText(e));
    }
  }
}

function fillSelect(id, arr, placeholder){
  const el = $(id);
  if(!el) return;
  el.innerHTML = `<option value="">${placeholder}</option>` + arr.map(x => {
    if(Array.isArray(x)) return `<option value="${safe(x[0])}">${safe(x[1])}</option>`;
    return `<option value="${safe(x)}">${safe(x)}</option>`;
  }).join("");
}
function initSelects(){
  ["f_edvYear","f_omvYear","f_vvbYear","f_svYear","f_emlakYear","f_menfeetYear","f_torpaqYear","umumiYear","sirketYear"].forEach(id => fillSelect(id, years, "İl seçin"));
  fillSelect("f_edvMonth", months, "Ay seçin");
  ["f_omvRub","f_vvbRub","f_svRub"].forEach(id => fillSelect(id, rubs, "Rüb seçin"));
  ["f_edvStatus","f_omvStatus","f_vvbStatus","f_svStatus","f_emlakStatus","f_menfeetStatus","f_torpaqStatus"].forEach(id => fillSelect(id, statuses, "Status seçin"));
  $("umumiYear").value = "2025";
  $("sirketYear").value = "2025";
}
function getForm(){
  return {
    teskilat: clean($("f_teskilat").value),
    voen: clean($("f_voen").value),
    edvDate: $("f_edvDate").value,
    edvYear: $("f_edvYear").value,
    edvMonth: $("f_edvMonth").value,
    edvStatus: $("f_edvStatus").value,
    omvDate: $("f_omvDate").value,
    omvYear: $("f_omvYear").value,
    omvRub: $("f_omvRub").value,
    omvStatus: $("f_omvStatus").value,
    vvbDate: $("f_vvbDate").value,
    vvbYear: $("f_vvbYear").value,
    vvbRub: $("f_vvbRub").value,
    vvbStatus: $("f_vvbStatus").value,
    svDate: $("f_svDate").value,
    svYear: $("f_svYear").value,
    svRub: $("f_svRub").value,
    svStatus: $("f_svStatus").value,
    emlakDate: $("f_emlakDate").value,
    emlakYear: $("f_emlakYear").value,
    emlakStatus: $("f_emlakStatus").value,
    menfeetDate: $("f_menfeetDate").value,
    menfeetYear: $("f_menfeetYear").value,
    menfeetStatus: $("f_menfeetStatus").value,
    torpaqDate: $("f_torpaqDate").value,
    torpaqYear: $("f_torpaqYear").value,
    torpaqStatus: $("f_torpaqStatus").value
  };
}
function setForm(r){
  Object.keys(r).forEach(k => {
    const el = $("f_" + k);
    if(el) el.value = r[k] || "";
  });
}
function clearForm(){
  document.querySelectorAll("#cariPanel input,#cariPanel select").forEach(x => x.value = "");
  editId = null;
  $("addBtn").textContent = "+ Əlavə et";
}

function statusClass(s){
  s = normalizeStatus(s);
  if(s === "TƏSDİQLƏNDİ") return "ok";
  if(s === "ANOLOJİ TƏSDİQLƏNDİ") return "anoloji-ok";
  if(s === "KAMERAL TƏSDİQLƏNDİ") return "kameral-ok";
  if(s === "KAMERAL") return "kameral";
  if(s === "UYĞUNSUZLUQ YOXLAMASINDA") return "mismatch";
  if(s === "ANOLOJİ") return "anoloji";
  if(s === "TƏQDİM OLUNAN") return "submitted";
  return "";
}
function statusBadge(s){
  if(!s) return "";
  s = normalizeStatus(s);
  return `<span class="status ${statusClass(s)}">${safe(s)}</span>`;
}
function monthName(num){
  const m = months.find(x => x[0] === num);
  return m ? m[1] : "";
}
function recordYearMatch(r, year){
  return [r.edvYear,r.omvYear,r.vvbYear,r.svYear,r.emlakYear,r.menfeetYear,r.torpaqYear].includes(year);
}
function companyKey(r){ return `${r.teskilat || ""}|${r.voen || ""}`; }
function companyRowsForYear(year, name){
  return data.filter(r => (!name || r.teskilat === name) && recordYearMatch(r, year));
}
function groupedCompanies(rows){
  const map = new Map();
  rows.forEach(r => {
    const k = companyKey(r);
    if(!map.has(k)) map.set(k, {teskilat:r.teskilat, voen:r.voen, rows:[]});
    map.get(k).rows.push(r);
  });
  return [...map.values()].sort((a,b)=>String(a.teskilat).localeCompare(String(b.teskilat), "az"));
}
function findMonthStatus(group, year, type, month){
  const row = group.rows.find(r => r[`${type}Year`] === year && r[`${type}Month`] === month && r[`${type}Status`]);
  return row ? row[`${type}Status`] : "";
}
function findRubStatus(group, year, type, rub){
  const row = group.rows.find(r => r[`${type}Year`] === year && r[`${type}Rub`] === rub && r[`${type}Status`]);
  return row ? row[`${type}Status`] : "";
}
function findYearStatus(group, year, type){
  const row = group.rows.find(r => r[`${type}Year`] === year && r[`${type}Status`]);
  return row ? row[`${type}Status`] : "";
}

function cariHeader(){
  return `
    <tr>
      <th rowspan="2">TƏŞKİLAT</th><th rowspan="2">VÖEN</th>
      <th colspan="4">ƏDV</th><th colspan="3">ÖMV</th><th colspan="3">VVB</th><th colspan="3">SV</th>
      <th colspan="3">ƏMLAK</th><th colspan="3">MƏNFƏƏT</th><th colspan="3">TORPAQ</th><th rowspan="2">ƏMƏLİYYATLAR</th>
    </tr>
    <tr>
      <th>Tarix</th><th>İl</th><th>Ay</th><th>Status</th>
      <th>Tarix</th><th>Rüb</th><th>Status</th>
      <th>Tarix</th><th>Rüb</th><th>Status</th>
      <th>Tarix</th><th>Rüb</th><th>Status</th>
      <th>Tarix</th><th>İl</th><th>Status</th>
      <th>Tarix</th><th>İl</th><th>Status</th>
      <th>Tarix</th><th>İl</th><th>Status</th>
    </tr>`;
}
function renderCari(){
  $("cariHead").innerHTML = cariHeader();
  $("cariBody").innerHTML = data.map(r => `
    <tr>
      <td>${safe(r.teskilat)}</td><td>${safe(r.voen)}</td>
      <td>${safe(r.edvDate)}</td><td>${safe(r.edvYear)}</td><td>${safe(monthName(r.edvMonth))}</td><td>${statusBadge(r.edvStatus)}</td>
      <td>${safe(r.omvDate)}</td><td>${safe(r.omvRub)}</td><td>${statusBadge(r.omvStatus)}</td>
      <td>${safe(r.vvbDate)}</td><td>${safe(r.vvbRub)}</td><td>${statusBadge(r.vvbStatus)}</td>
      <td>${safe(r.svDate)}</td><td>${safe(r.svRub)}</td><td>${statusBadge(r.svStatus)}</td>
      <td>${safe(r.emlakDate)}</td><td>${safe(r.emlakYear)}</td><td>${statusBadge(r.emlakStatus)}</td>
      <td>${safe(r.menfeetDate)}</td><td>${safe(r.menfeetYear)}</td><td>${statusBadge(r.menfeetStatus)}</td>
      <td>${safe(r.torpaqDate)}</td><td>${safe(r.torpaqYear)}</td><td>${statusBadge(r.torpaqStatus)}</td>
      <td><button class="iconBtn edit" data-edit="${safe(r.id)}">✎</button> <button class="iconBtn del" data-del="${safe(r.id)}">🗑</button></td>
    </tr>`).join("");
}

function buildMonthBlock(title, groups, year, type){
  const trs = groups.map(g => {
    const cells = months.map(m => `<td>${statusBadge(findMonthStatus(g, year, type, m[0]))}</td>`).join("");
    return `<tr><td>${safe(g.teskilat)}</td><td>${safe(g.voen)}</td>${cells}</tr>`;
  }).join("");
  return `<div class="block monthTable"><div class="blockTitle">▣ ${title}</div><table><thead><tr><th>TƏŞKİLAT</th><th>VÖEN</th>${months.map(m=>`<th>${m[1]}</th>`).join("")}</tr></thead><tbody>${trs}</tbody></table></div>`;
}
function buildRubBlock(title, groups, year, type){
  const trs = groups.map(g => {
    const cells = rubs.map(q => `<td>${statusBadge(findRubStatus(g, year, type, q))}</td>`).join("");
    return `<tr><td>${safe(g.teskilat)}</td><td>${safe(g.voen)}</td>${cells}</tr>`;
  }).join("");
  return `<div class="block"><div class="blockTitle">▣ ${title}</div><table><thead><tr><th>TƏŞKİLAT</th><th>VÖEN</th>${rubs.map(q=>`<th>${q}</th>`).join("")}</tr></thead><tbody>${trs}</tbody></table></div>`;
}
function buildYearBlock(title, groups, selectedYear, type){
  const viewYears = years;
  const trs = groups.map(g => {
    const cells = viewYears.map(y => `<td>${statusBadge(findYearStatus(g, y, type))}</td>`).join("");
    return `<tr><td>${safe(g.teskilat)}</td><td>${safe(g.voen)}</td>${cells}</tr>`;
  }).join("");
  return `<div class="block"><div class="blockTitle">▣ ${title}</div><table><thead><tr><th>TƏŞKİLAT</th><th>VÖEN</th>${viewYears.map(y=>`<th>${y}</th>`).join("")}</tr></thead><tbody>${trs}</tbody></table></div>`;
}
function reportHtml(groups, year){
  if(!groups.length) return `<div class="empty">Seçilən il üzrə məlumat yoxdur</div>`;
  return `
    ${buildMonthBlock("ƏDV", groups, year, "edv")}
    ${buildRubBlock("ÖMV", groups, year, "omv")}
    ${buildRubBlock("VVB", groups, year, "vvb")}
    ${buildRubBlock("SV", groups, year, "sv")}
    ${buildYearBlock("MƏNFƏƏT", groups, year, "menfeet")}
    ${buildYearBlock("ƏMLAK", groups, year, "emlak")}
    ${buildYearBlock("TORPAQ", groups, year, "torpaq")}`;
}
function renderUmumi(){
  const y = $("umumiYear").value || "2025";
  const rows = companyRowsForYear(y, "");
  const groups = groupedCompanies(rows);
  $("umumiContent").innerHTML = groups.length ? `
    <div class="companyInfo"><div class="infoCard"><span>TƏŞKİLAT</span><b>${groups.length}</b></div><div class="infoCard"><span>İL</span><b>${safe(y)}</b></div></div>
    ${reportHtml(groups, y)}` : `<div class="empty">Bu il üzrə məlumat yoxdur</div>`;
}
function updateCompanySelect(){
  const current = $("sirketName").value;
  const names = [...new Set(data.map(x => x.teskilat).filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b), "az"));
  $("sirketName").innerHTML = `<option value="">Şirkət seçin</option>` + names.map(n => `<option value="${safe(n)}">${safe(n)}</option>`).join("");
  if(names.includes(current)) $("sirketName").value = current;
}
function renderSirket(){
  const selectedNameBefore = $("sirketName").value;
  updateCompanySelect();
  if(selectedNameBefore) $("sirketName").value = selectedNameBefore;

  const y = $("sirketYear").value || "2025";
  const name = $("sirketName").value;
  const rows = companyRowsForYear(y, name);
  const groups = groupedCompanies(rows);
  const first = rows[0];

  $("sirketInfo").innerHTML = first ? `
    <div class="infoCard"><span>TƏŞKİLAT</span><b>${safe(first.teskilat)}</b></div>
    <div class="infoCard"><span>VÖEN</span><b>${safe(first.voen)}</b></div>
    <div class="infoCard"><span>İL</span><b>${safe(y)}</b></div>` : "";

  if(!name) $("sirketContent").innerHTML = `<div class="empty">Şirkət və il seçin</div>`;
  else $("sirketContent").innerHTML = reportHtml(groups, y);
}
function setPage(p){
  page = p;
  document.querySelectorAll(".nav").forEach(b => b.classList.toggle("active", b.dataset.page === p));
  $("cariPanel").classList.toggle("hidden", p !== "cari");
  $("umumiPanel").classList.toggle("hidden", p !== "umumi");
  $("sirketPanel").classList.toggle("hidden", p !== "sirket");
  if(p === "cari") { $("pageTitle").textContent = "Cari Hesabat"; $("pageSub").textContent = "Şirkət və bəyannamə məlumatlarını daxil edin"; }
  if(p === "umumi") { $("pageTitle").textContent = "Ümumi Hesabat"; $("pageSub").textContent = "Cari bölmədən seçilmiş il üzrə məlumatlar"; }
  if(p === "sirket") { $("pageTitle").textContent = "Şirkət Hesabatı"; $("pageSub").textContent = "Cari bölmədən seçilmiş şirkət və il üzrə məlumatlar"; }
  renderAll();
}
function renderAll(){
  $("totalCount").textContent = data.length;
  $("lastUpdate").textContent = todayText();
  renderCari();
  renderUmumi();
  renderSirket();
}

$("addBtn").onclick = async () => {
  const r = getForm();
  if(!r.teskilat || !r.voen){ alert("Təşkilat və VÖEN mütləq yazılmalıdır."); return; }
  await saveRecord(r);
  clearForm();
};
$("clearBtn").onclick = clearForm;

document.addEventListener("click", async e => {
  if(e.target.dataset.del){ if(confirm("Silinsin?")) await deleteRecord(e.target.dataset.del); }
  if(e.target.dataset.edit){
    const r = data.find(x => x.id === e.target.dataset.edit);
    if(r){ editId = r.id; setForm(r); $("addBtn").textContent = "✓ Düzəlişi yadda saxla"; setPage("cari"); window.scrollTo({top:0,behavior:"smooth"}); }
  }
});
document.querySelectorAll(".nav").forEach(b => b.onclick = () => setPage(b.dataset.page));
$("umumiYear").onchange = renderUmumi;
$("sirketYear").onchange = renderSirket;
$("sirketName").onchange = renderSirket;
$("refreshBtn").onclick = fetchFirebaseRecordsSilent;
$("pdfBtn").onclick = () => window.print();
$("excelBtn").onclick = () => {
  const rows = page === "sirket" ? companyRowsForYear($("sirketYear").value, $("sirketName").value) : page === "umumi" ? companyRowsForYear($("umumiYear").value, "") : data;
  const csv = [
    "Təşkilat;VÖEN;ƏDV tarix;ƏDV il;ƏDV ay;ƏDV status;ÖMV tarix;ÖMV il;ÖMV rüb;ÖMV status;VVB tarix;VVB il;VVB rüb;VVB status;SV tarix;SV il;SV rüb;SV status;Əmlak tarix;Əmlak il;Əmlak status;Mənfəət tarix;Mənfəət il;Mənfəət status;Torpaq tarix;Torpaq il;Torpaq status",
    ...rows.map(r => [r.teskilat,r.voen,r.edvDate,r.edvYear,monthName(r.edvMonth),r.edvStatus,r.omvDate,r.omvYear,r.omvRub,r.omvStatus,r.vvbDate,r.vvbYear,r.vvbRub,r.vvbStatus,r.svDate,r.svYear,r.svRub,r.svStatus,r.emlakDate,r.emlakYear,r.emlakStatus,r.menfeetDate,r.menfeetYear,r.menfeetStatus,r.torpaqDate,r.torpaqYear,r.torpaqStatus].map(x => `"${String(x || "").replace(/"/g,'""')}"`).join(";"))
  ].join("\n");
  const blob = new Blob(["\ufeff" + csv], {type:"text/csv;charset=utf-8"});
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "ammo_beyanname_nezaret.csv"; a.click();
};

initSelects();
loadLocal();
initFirebase();
renderAll();
