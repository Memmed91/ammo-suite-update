/* AMMO SUITE — Sənəd hazırla (V29.1)
   Hesab-faktura, təhvil-təslim aktı, razılaşma protokolu və əmək müqaviləsinə əlavələr.
   Məlumatlar localStorage-da saxlanılır (AMMO bulud sinxronu ilə bütün kompüterlərə gedir). */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const LS_PROFILE = 'senedProfiles_v1', LS_HISTORY = 'senedHistory_v1', LS_COUNTERS = 'senedCounters_v1', LS_DRAFT = 'senedDraft_v1';
  const load = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? d; } catch { return d; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  const MONTHS = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avqust', 'sentyabr', 'oktyabr', 'noyabr', 'dekabr'];
  const fmtDate = (iso) => { if (!iso) return '«___» __________ 20__'; const [y, m, d] = iso.split('-').map(Number); return `«${String(d).padStart(2, '0')}» ${MONTHS[m - 1]} ${y}`; };
  const fmtShort = (iso) => { if (!iso) return '__.__.____'; const [y, m, d] = iso.split('-'); return `${d}.${m}.${y}`; };
  const money = (n) => new Intl.NumberFormat('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(n) || 0);
  const num = (v) => { const x = parseFloat(String(v ?? '').replace(/\s/g, '').replace(',', '.')); return Number.isFinite(x) ? x : 0; };
  const round2 = (x) => Math.round((x + Number.EPSILON) * 100) / 100;

  /* ---------- Rəqəmi sözlə (Azərbaycan dili) ---------- */
  const ONES = ['', 'bir', 'iki', 'üç', 'dörd', 'beş', 'altı', 'yeddi', 'səkkiz', 'doqquz'];
  const TENS = ['', 'on', 'iyirmi', 'otuz', 'qırx', 'əlli', 'altmış', 'yetmiş', 'səksən', 'doxsan'];
  function triple(n) {
    const h = Math.floor(n / 100), t = Math.floor((n % 100) / 10), o = n % 10, out = [];
    if (h) out.push(h === 1 ? 'yüz' : ONES[h] + ' yüz');
    if (t) out.push(TENS[t]);
    if (o) out.push(ONES[o]);
    return out.join(' ');
  }
  function intWords(n) {
    if (n === 0) return 'sıfır';
    const scales = ['', 'min', 'milyon', 'milyard', 'trilyon'];
    const parts = []; let i = 0;
    while (n > 0) {
      const chunk = n % 1000;
      if (chunk) {
        let w = triple(chunk);
        if (i === 1 && chunk === 1) w = ''; // "bir min" yox, "min"
        parts.unshift([w, scales[i]].filter(Boolean).join(' '));
      }
      n = Math.floor(n / 1000); i++;
    }
    return parts.join(' ');
  }
  function amountWords(x) {
    const v = round2(Math.abs(Number(x) || 0));
    const man = Math.floor(v), q = Math.round((v - man) * 100);
    const s = `${intWords(man)} manat ${String(q).padStart(2, '0')} qəpik`;
    return s.charAt(0).toLocaleUpperCase('az') + s.slice(1);
  }

  /* ---------- Rekvizit profilləri (bizim şirkət) ---------- */
  const EMPTY_PARTY = { name: '', voen: '', address: '', phone: '', director: '', directorTitle: 'Direktor', bank: '', bankCode: '', bankVoen: '', corr: '', swift: '', account: '' };
  let profiles = load(LS_PROFILE, []);
  if (!Array.isArray(profiles)) profiles = [];

  /* ---------- Sənəd növləri ---------- */
  const TYPES = {
    invoice: { title: 'Hesab-faktura', hint: 'Satıcı — sizin şirkət, alıcı — müştəri. ƏDV rejimini seçin.', parties: ['Satıcı', 'Alıcı'], items: 'priced', prefix: 'HF' },
    act: { title: 'Təhvil-təslim aktı', hint: 'Təhvil verən və qəbul edən tərəflər, mal/xidmətlər və qiymətlər.', parties: ['Təhvil verən', 'Təhvil alan'], items: 'priced', prefix: 'TT' },
    actPlain: { title: 'Təhvil-təslim aktı (qiymətsiz)', hint: 'Yalnız ad, ölçü vahidi və miqdar — qiymət göstərilmir.', parties: ['Təhvil verən', 'Təhvil alan'], items: 'plain', prefix: 'TT' },
    protocol: { title: 'Razılaşma protokolu', hint: 'Tərəflərin razılaşdırdığı qiymətlər. Müqavilə nömrəsini yazın.', parties: ['İcraçı / Satıcı', 'Sifarişçi / Alıcı'], items: 'priced', prefix: 'RP' },
    nda: { title: 'Konfidensiallıq öhdəliyi', hint: 'Əmək müqaviləsinə əlavə. İşçinin məlumatlarını yazın.', employee: true, prefix: 'Əlavə' },
    liability: { title: 'Tam maddi məsuliyyət haqqında müqavilə', hint: 'Maddi sərvətlərə cavabdeh işçi ilə bağlanır.', employee: true, prefix: 'MM' },
    duties: { title: 'İşçinin öhdəlikləri', hint: 'Əmək müqaviləsinə əlavə — işçinin əsas öhdəlikləri.', employee: true, prefix: 'Əlavə' }
  };

  const blankState = () => ({
    type: 'invoice',
    number: '', date: todayISO(), city: 'Bakı', contractNo: '', contractDate: '', dueDate: '', basis: '',
    vatMode: 'plus', vatRate: 18, currency: 'AZN',
    profileIdx: 0, a: { ...EMPTY_PARTY }, b: { ...EMPTY_PARTY },
    items: [{ name: '', unit: 'ədəd', qty: 1, price: 0 }],
    emp: { name: '', position: '', idCard: '', fin: '', address: '', startDate: '', department: '', valuables: '' },
    note: ''
  });
  let state = Object.assign(blankState(), load(LS_DRAFT, {}));
  if (!state.a) state.a = { ...EMPTY_PARTY };
  if (!state.b) state.b = { ...EMPTY_PARTY };
  if (!Array.isArray(state.items) || !state.items.length) state.items = blankState().items;
  if (!state.emp) state.emp = blankState().emp;

  function nextNumber(type) {
    const c = load(LS_COUNTERS, {}); const y = new Date().getFullYear(); const key = `${type}_${y}`;
    return `${TYPES[type].prefix}-${y}/${String((c[key] || 0) + 1).padStart(3, '0')}`;
  }
  function bumpCounter(type, number) {
    const c = load(LS_COUNTERS, {}); const y = new Date().getFullYear(); const key = `${type}_${y}`;
    const m = String(number).match(/(\d+)\s*$/); const n = m ? Number(m[1]) : (c[key] || 0) + 1;
    if (n > (c[key] || 0)) { c[key] = n; save(LS_COUNTERS, c); }
  }

  /* ---------- Hesablama ---------- */
  function totals() {
    const rows = state.items.map((it) => ({ ...it, sum: round2(num(it.qty) * num(it.price)) }));
    const raw = round2(rows.reduce((s, r) => s + r.sum, 0));
    const rate = num(state.vatRate) / 100;
    let net = raw, vat = 0, gross = raw;
    if (state.vatMode === 'plus') { vat = round2(raw * rate); gross = round2(raw + vat); }
    else if (state.vatMode === 'incl') { gross = raw; net = round2(raw / (1 + rate)); vat = round2(gross - net); }
    return { rows, net, vat, gross };
  }

  /* ---------- Forma ---------- */
  const companyOptions = () => $$('#ammoCompaniesList option').map((o) => ({ name: o.value, voen: (o.textContent || '').trim() }));

  function partyFields(key, label, allowProfile) {
    const p = state[key];
    const prof = allowProfile && profiles.length
      ? `<label class="full">Rekvizit profili<select data-profile="${key}">${profiles.map((x, i) => `<option value="${i}" ${i === state.profileIdx ? 'selected' : ''}>${esc(x.name || 'Profil ' + (i + 1))}</option>`).join('')}<option value="-1">— əl ilə doldur —</option></select></label>` : '';
    const f = (k, l, cls = '', extra = '') => `<label class="${cls}">${l}<input data-p="${key}.${k}" value="${esc(p[k])}" ${extra}></label>`;
    return `<fieldset><legend>${esc(label)}</legend>${prof}
      ${f('name', 'Şirkət adı', 'full', 'list="ammoCompaniesList" placeholder="Ad yazın və ya siyahıdan seçin"')}
      ${f('voen', 'VÖEN', '', 'inputmode="numeric" maxlength="10"')}${f('phone', 'Telefon')}
      ${f('address', 'Ünvan', 'full')}
      ${f('director', 'Rəhbər (ad, soyad)')}${f('directorTitle', 'Vəzifə')}
      <details class="full"><summary>Bank rekvizitləri</summary><div class="grid">
        ${f('bank', 'Bank', 'full')}${f('bankCode', 'Bank kodu')}${f('bankVoen', 'Bankın VÖEN-i')}
        ${f('corr', 'Müxbir hesab', 'full')}${f('swift', 'SWIFT')}${f('account', 'Hesab (IBAN)', '')}
      </div></details></fieldset>`;
  }

  function itemsTable(kind) {
    const priced = kind === 'priced';
    const t = totals();
    return `<fieldset><legend>Mal / xidmətlər</legend>
      <table class="items"><thead><tr><th>#</th><th>Adı</th><th>Ölçü</th><th>Miqdar</th>${priced ? '<th>Qiymət</th><th>Məbləğ</th>' : ''}<th></th></tr></thead><tbody>
      ${state.items.map((it, i) => `<tr>
        <td class="n">${i + 1}</td>
        <td><input data-i="${i}.name" value="${esc(it.name)}" placeholder="Mal və ya xidmətin adı"></td>
        <td><input data-i="${i}.unit" value="${esc(it.unit)}" list="units" class="w-unit"></td>
        <td><input data-i="${i}.qty" value="${esc(it.qty)}" inputmode="decimal" class="w-num"></td>
        ${priced ? `<td><input data-i="${i}.price" value="${esc(it.price)}" inputmode="decimal" class="w-num"></td><td class="sum">${money(t.rows[i].sum)}</td>` : ''}
        <td><button type="button" class="x" data-del="${i}" title="Sətri sil">✕</button></td></tr>`).join('')}
      </tbody></table>
      <div class="row-tools"><button type="button" id="addRow" class="ghost">+ Sətir əlavə et</button>
      <label class="file ghost">⬆ Excel-dən<input type="file" id="itemsXlsx" accept=".xlsx,.xls,.csv" hidden></label></div>
      ${priced ? `<div class="vat"><label>ƏDV<select data-k="vatMode">
          <option value="plus" ${state.vatMode === 'plus' ? 'selected' : ''}>Qiymətin üstünə gəlir</option>
          <option value="incl" ${state.vatMode === 'incl' ? 'selected' : ''}>Qiymətə daxildir</option>
          <option value="none" ${state.vatMode === 'none' ? 'selected' : ''}>ƏDV-siz</option></select></label>
          <label>Dərəcə %<input data-k="vatRate" value="${esc(state.vatRate)}" class="w-num" inputmode="decimal"></label>
          <div class="tot"><span>ƏDV-siz: <b>${money(t.net)}</b></span><span>ƏDV: <b>${money(t.vat)}</b></span><span>Cəmi: <b class="big">${money(t.gross)} ${esc(state.currency)}</b></span></div></div>` : ''}
    </fieldset>`;
  }

  function renderForm() {
    const T = TYPES[state.type];
    $('#docTitle').textContent = T.title; $('#docHint').textContent = T.hint;
    $$('#types [data-type]').forEach((b) => b.classList.toggle('active', b.dataset.type === state.type));
    const k = (key, label, cls = '', extra = '') => `<label class="${cls}">${label}<input data-k="${key}" value="${esc(state[key])}" ${extra}></label>`;
    let html = `<fieldset><legend>Əsas</legend>
      ${k('number', 'Nömrə', '', `placeholder="${esc(nextNumber(state.type))}"`)}${k('date', 'Tarix', '', 'type="date"')}
      ${k('city', 'Şəhər')}${!T.employee ? k('contractNo', 'Müqavilə №') : k('contractNo', 'Əmək müqaviləsi №')}
      ${k('contractDate', 'Müqavilə tarixi', '', 'type="date"')}
      ${state.type === 'invoice' ? k('dueDate', 'Ödəniş müddəti', '', 'type="date"') : ''}
      ${state.type === 'protocol' ? k('basis', 'Qüvvədə olma tarixi', '', 'type="date"') : ''}
    </fieldset>`;
    if (T.employee) {
      const e = state.emp; const f = (key, l, cls = '', extra = '') => `<label class="${cls}">${l}<input data-e="${key}" value="${esc(e[key])}" ${extra}></label>`;
      html += partyFields('a', 'İşəgötürən', true);
      html += `<fieldset><legend>İşçi</legend>${f('name', 'Ad, soyad, ata adı', 'full')}${f('position', 'Vəzifə')}${f('department', 'Struktur bölmə')}
        ${f('idCard', 'Şəxsiyyət vəsiqəsi №')}${f('fin', 'FİN', '', 'maxlength="7"')}${f('address', 'Yaşayış ünvanı', 'full')}${f('startDate', 'İşə başlama tarixi', '', 'type="date"')}
        ${state.type === 'liability' ? `<label class="full">Cavabdeh olduğu maddi sərvətlər<textarea data-e="valuables" rows="3" placeholder="məs. anbardakı mallar, kassa, avadanlıq">${esc(e.valuables)}</textarea></label>` : ''}</fieldset>`;
    } else {
      html += partyFields('a', T.parties[0], true) + partyFields('b', T.parties[1], false) + itemsTable(T.items);
    }
    html += `<fieldset><legend>Əlavə qeyd</legend><label class="full"><textarea data-k="note" rows="2" placeholder="Sənədin sonunda göstəriləcək qeyd (istəyə bağlı)">${esc(state.note)}</textarea></label></fieldset>`;
    $('#form').innerHTML = html;
    bindForm();
    renderDoc();
  }

  function setPath(obj, path, val) { const ks = path.split('.'); let o = obj; while (ks.length > 1) o = o[ks.shift()]; o[ks[0]] = val; }

  function fillFromCompany(key, input) {
    const c = companyOptions().find((x) => x.name.toLocaleLowerCase('az') === input.value.trim().toLocaleLowerCase('az'));
    if (c && c.voen && !state[key].voen) { state[key].voen = c.voen; const v = $(`[data-p="${key}.voen"]`); if (v) v.value = c.voen; }
  }

  let renderTimer = null;
  const scheduleRender = () => { clearTimeout(renderTimer); renderTimer = setTimeout(() => { renderDoc(); save(LS_DRAFT, state); }, 120); };

  function updateTotals() {
    const t = totals();
    $$('#form .items tbody tr').forEach((tr, i) => { const c = tr.querySelector('.sum'); if (c && t.rows[i]) c.textContent = money(t.rows[i].sum); });
    const tot = $('#form .tot'); if (tot) tot.innerHTML = `<span>ƏDV-siz: <b>${money(t.net)}</b></span><span>ƏDV: <b>${money(t.vat)}</b></span><span>Cəmi: <b class="big">${money(t.gross)} ${esc(state.currency)}</b></span>`;
  }

  function bindForm() {
    $$('#form [data-k]').forEach((el) => el.addEventListener('input', () => {
      state[el.dataset.k] = el.value;
      if (el.dataset.k === 'vatMode') { renderForm(); save(LS_DRAFT, state); return; }
      if (el.dataset.k === 'vatRate') updateTotals();
      scheduleRender();
    }));
    $$('#form [data-p]').forEach((el) => el.addEventListener('input', () => {
      setPath(state, el.dataset.p, el.value);
      if (el.dataset.p.endsWith('.name')) fillFromCompany(el.dataset.p.split('.')[0], el);
      scheduleRender();
    }));
    $$('#form [data-e]').forEach((el) => el.addEventListener('input', () => { state.emp[el.dataset.e] = el.value; scheduleRender(); }));
    $$('#form [data-i]').forEach((el) => el.addEventListener('input', () => {
      const [i, f] = el.dataset.i.split('.'); state.items[i][f] = el.value;
      updateTotals();
      scheduleRender();
    }));
    $$('#form [data-del]').forEach((b) => b.addEventListener('click', () => {
      state.items.splice(Number(b.dataset.del), 1); if (!state.items.length) state.items.push({ name: '', unit: 'ədəd', qty: 1, price: 0 }); renderForm(); save(LS_DRAFT, state);
    }));
    $('#addRow')?.addEventListener('click', () => { state.items.push({ name: '', unit: 'ədəd', qty: 1, price: 0 }); renderForm(); const ins = $$('#form [data-i$=".name"]'); ins[ins.length - 1]?.focus(); });
    $('#itemsXlsx')?.addEventListener('change', (e) => importItems(e.target.files[0]).finally(() => { e.target.value = ''; }));
    $$('#form [data-profile]').forEach((s) => s.addEventListener('change', () => {
      const i = Number(s.value); state.profileIdx = i;
      if (i >= 0 && profiles[i]) state.a = { ...EMPTY_PARTY, ...profiles[i] };
      renderForm(); save(LS_DRAFT, state);
    }));
  }

  async function importItems(file) {
    if (!file || !window.XLSX) return;
    try {
      const wb = XLSX.read(await file.arrayBuffer(), { type: 'array' });
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '', raw: false });
      const key = (s) => String(s).toLocaleLowerCase('az');
      let h = rows.findIndex((r) => r.some((c) => /ad|məhsul|mal|xidmət|name/i.test(key(c))));
      if (h < 0) h = -1;
      const head = h >= 0 ? rows[h].map(key) : [];
      const col = (re, d) => { const i = head.findIndex((x) => re.test(x)); return i >= 0 ? i : d; };
      const cN = col(/ad|məhsul|mal|xidmət|name/, 0), cU = col(/ölçü|vahid|unit/, 1), cQ = col(/miqdar|say|qty|kəmiyyət/, 2), cP = col(/qiymət|price/, 3);
      const items = rows.slice(h + 1).filter((r) => String(r[cN] || '').trim()).map((r) => ({ name: String(r[cN]).trim(), unit: String(r[cU] || 'ədəd').trim() || 'ədəd', qty: num(r[cQ]) || 1, price: num(r[cP]) }));
      if (!items.length) throw new Error('Faylda mal/xidmət sətri tapılmadı');
      state.items = items; renderForm(); save(LS_DRAFT, state);
    } catch (e) { alert('Excel oxunmadı: ' + e.message); }
  }

  /* ---------- Sənəd (A4) ---------- */
  const partyBlock = (p, role) => `<div class="party"><div class="role">${esc(role)}</div>
    <div class="pname">${esc(p.name) || '______________________'}</div>
    <div>VÖEN: ${esc(p.voen) || '__________'}</div>
    ${p.address ? `<div>Ünvan: ${esc(p.address)}</div>` : ''}${p.phone ? `<div>Tel: ${esc(p.phone)}</div>` : ''}
    ${p.bank ? `<div>Bank: ${esc(p.bank)}</div>` : ''}${p.bankCode ? `<div>Kod: ${esc(p.bankCode)}${p.bankVoen ? ' · Bank VÖEN: ' + esc(p.bankVoen) : ''}</div>` : ''}
    ${p.corr ? `<div>M/h: ${esc(p.corr)}</div>` : ''}${p.swift ? `<div>SWIFT: ${esc(p.swift)}</div>` : ''}${p.account ? `<div>H/h: ${esc(p.account)}</div>` : ''}</div>`;
  const signs = (left, right, lp, rp) => `<div class="signs">
    <div><div class="role">${esc(left)}</div><div class="pname">${esc(lp?.name || '')}</div><div class="line"></div><div class="who">${esc(lp?.directorTitle || '')} ${esc(lp?.director || '')}</div><div class="mp">M.Y.</div></div>
    <div><div class="role">${esc(right)}</div><div class="pname">${esc(rp?.name || '')}</div><div class="line"></div><div class="who">${esc(rp?.directorTitle || '')} ${esc(rp?.director || '')}</div><div class="mp">M.Y.</div></div></div>`;
  const head = (title, sub) => `<div class="dh"><div class="dtitle">${esc(title)}</div>${sub ? `<div class="dsub">${sub}</div>` : ''}</div>
    <div class="meta"><span>${esc(state.city || 'Bakı')} şəhəri</span><span>${fmtDate(state.date)}</span></div>`;

  function itemsDoc(priced) {
    const t = totals();
    const rows = t.rows.filter((r) => String(r.name).trim() || num(r.price));
    const list = rows.length ? rows : [{ name: '', unit: '', qty: '', price: '', sum: 0 }];
    return `<table class="dt"><thead><tr><th>№</th><th>Mal / xidmətin adı</th><th>Ölçü vahidi</th><th>Miqdar</th>${priced ? '<th>Qiymət</th><th>Məbləğ</th>' : ''}</tr></thead><tbody>
      ${list.map((r, i) => `<tr><td class="c">${i + 1}</td><td>${esc(r.name)}</td><td class="c">${esc(r.unit)}</td><td class="r">${esc(r.qty)}</td>${priced ? `<td class="r">${r.price === '' ? '' : money(r.price)}</td><td class="r">${money(r.sum)}</td>` : ''}</tr>`).join('')}
      </tbody>${priced ? `<tfoot>
        ${state.vatMode !== 'none' ? `<tr><td colspan="5" class="r">ƏDV-siz məbləğ</td><td class="r">${money(t.net)}</td></tr><tr><td colspan="5" class="r">ƏDV (${esc(state.vatRate)}%)</td><td class="r">${money(t.vat)}</td></tr>` : ''}
        <tr class="grand"><td colspan="5" class="r">Cəmi ödəniləcək${state.vatMode === 'none' ? ' (ƏDV-siz)' : ''}</td><td class="r">${money(t.gross)}</td></tr></tfoot>` : ''}</table>
      ${priced ? `<p class="words"><b>Yekun məbləğ sözlə:</b> ${amountWords(t.gross)}${state.vatMode === 'plus' || state.vatMode === 'incl' ? `, o cümlədən ƏDV ${amountWords(t.vat).toLocaleLowerCase('az')}` : ''}.</p>` : ''}`;
  }

  function docHTML() {
    const n = state.number || nextNumber(state.type);
    const contract = state.contractNo ? `${fmtShort(state.contractDate) !== '__.__.____' ? fmtShort(state.contractDate) + ' tarixli ' : ''}${esc(state.contractNo)} nömrəli müqavilə` : '';
    const note = state.note ? `<p class="note">${esc(state.note).replace(/\n/g, '<br>')}</p>` : '';
    const a = state.a, b = state.b, e = state.emp;
    switch (state.type) {
      case 'invoice':
        return `${head(`HESAB-FAKTURA № ${n}`, contract ? `${contract} əsasında` : '')}
          <div class="parties">${partyBlock(a, 'Satıcı')}${partyBlock(b, 'Alıcı')}</div>
          ${itemsDoc(true)}
          ${state.dueDate ? `<p>Ödəniş müddəti: <b>${fmtShort(state.dueDate)}</b> tarixinədək.</p>` : ''}
          <p>Ödəniş zamanı təyinatda hesab-fakturanın nömrəsini göstərməyiniz xahiş olunur.</p>${note}
          <div class="signs one"><div><div class="role">Satıcı</div><div class="pname">${esc(a.name)}</div><div class="line"></div><div class="who">${esc(a.directorTitle)} ${esc(a.director)}</div><div class="mp">M.Y.</div></div></div>`;
      case 'act':
      case 'actPlain': {
        const priced = state.type === 'act';
        return `${head(`TƏHVİL-TƏSLİM AKTI № ${n}`, contract ? `${contract} üzrə` : '')}
          <p>Biz, aşağıda imza edənlər, bir tərəfdən <b>${esc(a.name) || '________'}</b> (bundan sonra "Təhvil verən") adından ${esc(a.directorTitle).toLocaleLowerCase('az') || 'rəhbər'} <b>${esc(a.director) || '________'}</b> və digər tərəfdən <b>${esc(b.name) || '________'}</b> (bundan sonra "Təhvil alan") adından ${esc(b.directorTitle).toLocaleLowerCase('az') || 'rəhbər'} <b>${esc(b.director) || '________'}</b> bu aktı tərtib edirik ki, Təhvil verən aşağıdakı mal/xidmətləri təhvil vermiş, Təhvil alan isə onları qəbul etmişdir:</p>
          ${itemsDoc(priced)}
          <p>Mal/xidmətlər tam həcmdə, vaxtında və lazımi keyfiyyətdə təhvil verilmişdir. Tərəflərin bir-birinə qarşı kəmiyyət, keyfiyyət və müddətlə bağlı iddiası yoxdur.</p>
          <p>Akt eyni hüquqi qüvvəyə malik iki nüsxədə tərtib edilmişdir — hər tərəf üçün bir nüsxə.</p>${note}
          <div class="parties small">${partyBlock(a, 'Təhvil verən')}${partyBlock(b, 'Təhvil alan')}</div>
          ${signs('Təhvil verən', 'Təhvil alan', a, b)}`;
      }
      case 'protocol':
        return `${head(`QİYMƏT RAZILAŞMA PROTOKOLU № ${n}`, contract ? `${contract}ya əlavə` : '')}
          <p><b>${esc(a.name) || '________'}</b> (bundan sonra "İcraçı") və <b>${esc(b.name) || '________'}</b> (bundan sonra "Sifarişçi") aşağıdakı mal/xidmətlərin qiymətləri barədə razılığa gəldilər:</p>
          ${itemsDoc(true)}
          <p>1. Razılaşdırılmış qiymətlər ${state.basis ? `<b>${fmtShort(state.basis)}</b>` : 'protokolun imzalandığı'} tarixdən qüvvəyə minir və tərəflərin yeni razılaşmasınadək dəyişməz qalır.</p>
          <p>2. Protokol ${contract ? 'müqavilənin ayrılmaz hissəsidir' : 'tərəflər arasında bağlanmış müqavilənin ayrılmaz hissəsidir'} və eyni hüquqi qüvvəyə malik iki nüsxədə tərtib edilmişdir.</p>${note}
          <div class="parties small">${partyBlock(a, 'İcraçı')}${partyBlock(b, 'Sifarişçi')}</div>
          ${signs('İcraçı', 'Sifarişçi', a, b)}`;
      case 'nda':
        return `${head('KONFİDENSİALLIQ ÖHDƏLİYİ', `${state.contractNo ? `${esc(state.contractNo)} nömrəli ` : ''}əmək müqaviləsinə əlavə № ${esc(n)}`)}
          <p>Mən, <b>${esc(e.name) || '__________________'}</b>${e.idCard ? `, şəxsiyyət vəsiqəsi № ${esc(e.idCard)}` : ''}${e.fin ? ` (FİN: ${esc(e.fin)})` : ''}, <b>${esc(a.name) || '________'}</b> (bundan sonra "İşəgötürən") ${e.department ? esc(e.department) + ' bölməsində ' : ''}<b>${esc(e.position) || '________'}</b> vəzifəsində işləyərkən aşağıdakı öhdəlikləri qəbul edirəm:</p>
          <ol class="clauses">
            <li>İşəgötürənin kommersiya sirri və konfidensial məlumatlarını — müştərilər, tərəfdaşlar, qiymətlər, müqavilələr, maliyyə və mühasibat göstəriciləri, vergi və bank məlumatları, proqram təminatı və daxili sənədlər barədə məlumatları — üçüncü şəxslərə açıqlamamaq.</li>
            <li>Bu məlumatlardan yalnız əmək funksiyalarımı yerinə yetirmək üçün istifadə etmək, şəxsi məqsədlə və ya başqa şəxslərin xeyrinə istifadə etməmək.</li>
            <li>Konfidensial məlumatı olan sənədləri, elektron faylları, giriş məlumatlarını (parol, ASAN İmza, bank girişləri) icazəsiz surətini çıxarmamaq, aparmamaq və başqasına ötürməmək.</li>
            <li>Məlumatın açıqlanması və ya itirilməsi təhlükəsi yarandıqda bu barədə dərhal rəhbərliyə məlumat vermək.</li>
            <li>Əmək münasibətlərinə xitam verildikdə İşəgötürənə məxsus bütün sənəd, fayl və daşıyıcıları geri qaytarmaq.</li>
            <li>Bu öhdəlik əmək müqaviləsinin qüvvədə olduğu müddətdə və ona xitam verildikdən sonra <b>3 (üç) il</b> ərzində qüvvədədir.</li>
            <li>Öhdəliklərin pozulması nəticəsində İşəgötürənə vurulmuş ziyana görə Azərbaycan Respublikasının qanunvericiliyinə uyğun olaraq məsuliyyət daşıdığım mənə izah edilmişdir.</li>
          </ol>${note}
          ${empSigns(a, e)}`;
      case 'liability':
        return `${head(`TAM FƏRDİ MADDİ MƏSULİYYƏT HAQQINDA MÜQAVİLƏ № ${n}`, state.contractNo ? `${esc(state.contractNo)} nömrəli əmək müqaviləsinə əlavə` : '')}
          <p><b>${esc(a.name) || '________'}</b> (bundan sonra "İşəgötürən") adından ${esc(a.directorTitle).toLocaleLowerCase('az') || 'rəhbər'} <b>${esc(a.director) || '________'}</b> bir tərəfdən və <b>${esc(e.position) || '________'}</b> vəzifəsində çalışan <b>${esc(e.name) || '__________________'}</b>${e.idCard ? ` (şəxsiyyət vəsiqəsi № ${esc(e.idCard)})` : ''} (bundan sonra "İşçi") digər tərəfdən Azərbaycan Respublikasının Əmək Məcəlləsinə uyğun olaraq bu müqaviləni bağladılar:</p>
          <ol class="clauses">
            <li>İşçi ona etibar edilmiş maddi sərvətlərin${e.valuables ? ` (<i>${esc(e.valuables)}</i>)` : ''} qorunub saxlanmasına görə tam fərdi maddi məsuliyyət daşıyır.</li>
            <li>İşçi öhdəsinə götürür: etibar edilmiş sərvətlərə qayğı ilə yanaşmaq və ziyanın qarşısını almaq üçün tədbir görmək; sərvətlərin qəbulu, saxlanması, buraxılması və uçotu qaydalarına əməl etmək; inventarizasiyada iştirak etmək; sərvətlərin salamatlığına təhlükə yaradan hallar barədə rəhbərliyə dərhal məlumat vermək.</li>
            <li>İşəgötürən öhdəsinə götürür: İşçi üçün sərvətlərin qorunması üçün zəruri şərait yaratmaq; maddi məsuliyyət barədə qanunvericiliklə İşçini tanış etmək; inventarizasiyanı müəyyən olunmuş qaydada keçirmək.</li>
            <li>Ziyanın məbləği faktiki itki əsasında, qanunvericilikdə nəzərdə tutulmuş qaydada müəyyən edilir. İşçinin təqsiri olmadan vurulmuş ziyana görə o, məsuliyyətdən azad edilir.</li>
            <li>Müqavilə İşçinin ona etibar edilmiş maddi sərvətlərlə işlədiyi bütün müddət ərzində qüvvədədir və iki nüsxədə tərtib edilmişdir.</li>
          </ol>${note}
          ${empSigns(a, e)}`;
      case 'duties':
        return `${head('İŞÇİNİN ÖHDƏLİKLƏRİ', `${state.contractNo ? `${esc(state.contractNo)} nömrəli ` : ''}əmək müqaviləsinə əlavə № ${esc(n)}`)}
          <p>Mən, <b>${esc(e.name) || '__________________'}</b>, <b>${esc(a.name) || '________'}</b>-də <b>${esc(e.position) || '________'}</b> vəzifəsində${e.startDate ? ` ${fmtShort(e.startDate)} tarixdən` : ''} işləyərək aşağıdakıları öhdəmə götürürəm:</p>
          <ol class="clauses">
            <li>Əmək funksiyalarımı vicdanla, vaxtında və keyfiyyətlə yerinə yetirmək, rəhbərliyin qanuni tapşırıqlarına əməl etmək.</li>
            <li>Daxili intizam qaydalarına, iş vaxtı rejiminə, əməyin mühafizəsi və yanğın təhlükəsizliyi qaydalarına riayət etmək.</li>
            <li>İşəgötürənin əmlakına, avadanlığına və sənədlərinə qayğı ilə yanaşmaq; onlardan yalnız iş məqsədilə istifadə etmək.</li>
            <li>Tapşırılan sənədlərin, hesabatların və bəyannamələrin vaxtında hazırlanmasına və təqdim edilməsinə cavabdeh olmaq; müddətlərin pozulma riski barədə rəhbərliyə əvvəlcədən xəbər vermək.</li>
            <li>Elektron xidmətlərə giriş məlumatlarını (ASAN İmza, e-taxes, bank girişləri) yalnız iş məqsədilə istifadə etmək və heç kimə ötürməmək.</li>
            <li>Peşə səviyyəmi artırmaq, qanunvericilikdəki dəyişikliklərlə tanış olmaq.</li>
            <li>Bu öhdəliklərin pozulmasına görə qanunvericiliklə nəzərdə tutulmuş intizam və maddi məsuliyyət daşıdığım mənə izah edilmişdir.</li>
          </ol>${note}
          ${empSigns(a, e)}`;
    }
    return '';
  }
  const empSigns = (a, e) => `<div class="signs">
    <div><div class="role">İşəgötürən</div><div class="pname">${esc(a.name)}</div><div>VÖEN: ${esc(a.voen)}</div><div class="line"></div><div class="who">${esc(a.directorTitle)} ${esc(a.director)}</div><div class="mp">M.Y.</div></div>
    <div><div class="role">İşçi</div><div class="pname">${esc(e.name)}</div>${e.address ? `<div>${esc(e.address)}</div>` : ''}<div class="line"></div><div class="who">(imza)</div><div class="mp">Tarix: ${fmtShort(state.date)}</div></div></div>`;

  function renderDoc() {
    $('#doc').innerHTML = docHTML();
    $('#pvInfo').textContent = `${TYPES[state.type].title} · ${state.number || nextNumber(state.type)}`;
  }

  /* ---------- Çap / Word / Saxla ---------- */
  function docFileName() { return `${TYPES[state.type].title} ${state.number || nextNumber(state.type)}`.replace(/[\\/:*?"<>|]/g, '-'); }
  function commitNumber() {
    if (!state.number) { state.number = nextNumber(state.type); }
    bumpCounter(state.type, state.number); save(LS_DRAFT, state);
  }
  function addHistory() {
    const h = load(LS_HISTORY, []); const t = totals();
    const entry = { id: Date.now(), at: new Date().toISOString(), type: state.type, number: state.number, party: state.type in { nda: 1, liability: 1, duties: 1 } ? state.emp.name : state.b.name, total: TYPES[state.type].items === 'priced' ? t.gross : null, state: JSON.parse(JSON.stringify(state)) };
    const i = h.findIndex((x) => x.type === entry.type && x.number === entry.number);
    if (i >= 0) h[i] = entry; else h.unshift(entry);
    save(LS_HISTORY, h.slice(0, 200));
  }
  $('#printBtn').addEventListener('click', () => { commitNumber(); renderForm(); addHistory(); const old = document.title; document.title = docFileName(); window.print(); setTimeout(() => { document.title = old; }, 500); });
  $('#saveBtn').addEventListener('click', () => { commitNumber(); renderForm(); addHistory(); flash('Yadda saxlanıldı ✓'); });
  $('#wordBtn').addEventListener('click', async () => {
    commitNumber(); renderForm(); addHistory();
    let css = ''; try { css = await (await fetch('style.css')).text(); } catch {}
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><style>${css}</style></head><body class="word"><article class="a4">${docHTML()}</article></body></html>`;
    const blob = new Blob(['﻿', html], { type: 'application/msword' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = docFileName() + '.doc'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  });
  function flash(msg) { const b = $('#saveBtn'); const t = b.textContent; b.textContent = msg; setTimeout(() => { b.textContent = t; }, 1600); }

  /* ---------- Növ seçimi ---------- */
  $$('#types [data-type]').forEach((b) => b.addEventListener('click', () => {
    if (state.type === b.dataset.type) return;
    state.type = b.dataset.type; state.number = ''; save(LS_DRAFT, state); renderForm();
  }));

  /* ---------- Modal: profillər və tarixçə ---------- */
  const modal = $('#modal');
  const openModal = (title, html) => { $('#modalTitle').textContent = title; $('#modalBody').innerHTML = html; modal.classList.remove('hidden'); };
  const closeModal = () => modal.classList.add('hidden');
  $('#modalClose').addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  function profileModal() {
    const fields = [['name', 'Şirkət adı'], ['voen', 'VÖEN'], ['address', 'Ünvan'], ['phone', 'Telefon'], ['director', 'Rəhbər'], ['directorTitle', 'Vəzifə'], ['bank', 'Bank'], ['bankCode', 'Bank kodu'], ['bankVoen', 'Bankın VÖEN-i'], ['corr', 'Müxbir hesab'], ['swift', 'SWIFT'], ['account', 'Hesab (IBAN)']];
    const list = profiles.map((p, i) => `<div class="pf"><div><b>${esc(p.name || 'Adsız')}</b><small>VÖEN ${esc(p.voen || '—')}</small></div><div><button data-edit="${i}" class="ghost">Düzəlt</button><button data-rm="${i}" class="danger">Sil</button></div></div>`).join('') || '<p class="muted">Hələ profil yoxdur. Öz şirkətinizin (və ya xidmət etdiyiniz şirkətlərin) rekvizitlərini bir dəfə yazın — sənədlərdə avtomatik dolacaq.</p>';
    openModal('Rekvizitlərim', `<div class="pf-list">${list}</div>
      <form id="pfForm" class="pf-form"><input type="hidden" name="idx" value="-1">${fields.map(([k, l]) => `<label>${l}<input name="${k}" ${k === 'name' ? 'list="ammoCompaniesList" required' : ''}></label>`).join('')}
      <div class="pf-actions"><button type="button" id="pfFromCurrent" class="ghost">Formadakı 1-ci tərəfi götür</button><button class="primary">Yadda saxla</button></div></form>`);
    const form = $('#pfForm');
    $$('[data-edit]').forEach((b) => b.onclick = () => { const p = profiles[b.dataset.edit]; form.idx.value = b.dataset.edit; fields.forEach(([k]) => { form[k].value = p[k] || ''; }); });
    $$('[data-rm]').forEach((b) => b.onclick = () => { if (!confirm('Profil silinsin?')) return; profiles.splice(Number(b.dataset.rm), 1); save(LS_PROFILE, profiles); profileModal(); renderForm(); });
    $('#pfFromCurrent').onclick = () => fields.forEach(([k]) => { form[k].value = state.a[k] || ''; });
    form.onsubmit = (e) => {
      e.preventDefault(); const p = {}; fields.forEach(([k]) => { p[k] = form[k].value.trim(); });
      const i = Number(form.idx.value); if (i >= 0) profiles[i] = p; else profiles.push(p);
      save(LS_PROFILE, profiles); state.profileIdx = i >= 0 ? i : profiles.length - 1; state.a = { ...EMPTY_PARTY, ...p };
      save(LS_DRAFT, state); profileModal(); renderForm();
    };
  }
  $('#profileBtn').addEventListener('click', profileModal);

  function historyModal() {
    const h = load(LS_HISTORY, []);
    openModal('Son sənədlər', h.length ? `<input id="hq" class="hq" placeholder="Axtar: nömrə, şirkət, işçi...">
      <table class="hist"><thead><tr><th>Tarix</th><th>Növ</th><th>№</th><th>Tərəf</th><th class="r">Məbləğ</th><th></th></tr></thead><tbody>
      ${h.map((x, i) => `<tr data-q="${esc((x.number + ' ' + x.party + ' ' + TYPES[x.type]?.title).toLocaleLowerCase('az'))}"><td>${fmtShort(x.at.slice(0, 10))}</td><td>${esc(TYPES[x.type]?.title || x.type)}</td><td>${esc(x.number)}</td><td>${esc(x.party || '—')}</td><td class="r">${x.total == null ? '' : money(x.total)}</td>
      <td><button data-open="${i}" class="ghost">Aç</button><button data-copy="${i}" class="ghost" title="Eyni məlumatla yeni nömrə">Surət</button></td></tr>`).join('')}</tbody></table>` : '<p class="muted">Hələ yadda saxlanmış sənəd yoxdur.</p>');
    $('#hq')?.addEventListener('input', (e) => { const q = e.target.value.toLocaleLowerCase('az'); $$('.hist tbody tr').forEach((tr) => { tr.style.display = tr.dataset.q.includes(q) ? '' : 'none'; }); });
    $$('[data-open]').forEach((b) => b.onclick = () => { state = Object.assign(blankState(), h[b.dataset.open].state); save(LS_DRAFT, state); closeModal(); renderForm(); });
    $$('[data-copy]').forEach((b) => b.onclick = () => { state = Object.assign(blankState(), h[b.dataset.copy].state, { number: '', date: todayISO() }); save(LS_DRAFT, state); closeModal(); renderForm(); });
  }
  $('#historyBtn').addEventListener('click', historyModal);

  /* AMMO "Sahibkarlar" (Excel-dən şirkət siyahısı) düyməsini sol panelə köçür */
  function adoptOwnersBtn() {
    const btn = document.getElementById('ammoOwnersBtn'); if (!btn || btn.dataset.adopted) return !!btn;
    const host = document.getElementById('ammoGlobalActions');
    btn.dataset.adopted = '1'; btn.removeAttribute('style'); btn.className = 'ghost'; btn.textContent = '▣ Sahibkarlar (Excel)';
    $('.types-foot').prepend(btn); if (host && !host.children.length) host.remove();
    return true;
  }
  if (!adoptOwnersBtn()) { const mo = new MutationObserver(() => { if (adoptOwnersBtn()) mo.disconnect(); }); mo.observe(document.body, { childList: true, subtree: true }); }

  /* ---------- Başlanğıc ---------- */
  if (profiles.length && !state.a.name && profiles[state.profileIdx]) state.a = { ...EMPTY_PARTY, ...profiles[state.profileIdx] };
  renderForm();
  window.addEventListener('ammo-cloud-updated', () => { profiles = load(LS_PROFILE, profiles); });
  window.AMMO_amountWords = amountWords; // test üçün
})();
