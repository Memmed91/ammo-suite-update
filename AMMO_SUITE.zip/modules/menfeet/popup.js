const sections = ["general", "income", "expenses", "tax", "assets", "summary"];
let currentSection = 0;

const rows = {
  income: [
    ["200", "Malların təqdim edilməsindən (işlərin görülməsindən, xidmətlərin göstərilməsindən) gəlir"],
    ["200.1", "Malların təqdim edilməsindən gəlir"],
    ["200.1.1", "Pərakəndə satışdan gəlir"],
    ["200.1.2", "Topdan satışdan gəlir"],
    ["200.2", "İşlərin görülməsindən və xidmətlərin göstərilməsindən gəlir"],
    ["218", "ÜMUMİ GƏLİRLƏR"],
    ["220", "Çıxılmalardan sonra ÜMUMİ GƏLİR"]
  ],

  expenses: [
    ["221", "Malların təqdim edilməsi, iş görülməsi və xidmət göstərilməsi üzrə xərclər"],
    ["221.1", "Əmək haqqı və ona bərabər tutulan ödəmələr"],
    ["221.1.1", "Əcnəbi işçilər üzrə"],
    ["221.1.2", "Yerli işçilər üzrə"],
    ["221.2", "Sosial sığorta haqları"],
    ["221.3", "Xammal və materiallar"],
    ["221.4", "Malın dəyəri"],
    ["221.5", "İcarə haqqı"],
    ["221.5.1", "Rezident şəxslər üzrə icarə haqqı"],
    ["221.5.1.1", "Hüquqi şəxslər üzrə"],
    ["221.5.1.2", "Fiziki şəxslər üzrə"],
    ["221.13", "Bank xidməti üzrə xərclər"],
    ["221.15", "Bilavasitə malların təqdim edilməsi ilə bağlı sair xərclər"],
    ["234", "CƏMİ XƏRCLƏR"],
    ["236", "Ümumi gəlirlərdən çıxılan xərclər"]
  ],

  tax: [
    ["237", "Vergitutma məqsədləri üçün mənfəət"],
    ["238", "Mənfəət üzrə azadolmalar və güzəştlər"],
    ["239", "Zərər"],
    ["240", "Keçmiş illərin zərəri"],
    ["241", "Vergiyə cəlb olunan mənfəət"],
    ["242", "Mənfəət vergisinin dərəcəsi"],
    ["243", "Mənfəət vergisi"],
    ["244", "Azaldılmalı verginin məbləği"],
    ["245", "Ödənilməli mənfəət vergisinin məbləği"]
  ],

  assets: [
    ["1", "Cəmi aktivlər"],
    ["1.3", "Ehtiyatlar"],
    ["1.3.2", "Mallar"],
    ["1.4", "Debitor borcları"],
    ["1.5", "Pul vəsaitləri"],
    ["1.10", "Digər aktivlər"],
    ["2", "Cəmi kapital və öhdəliklər"],
    ["2.2", "Cəmi öhdəliklər"],
    ["2.2.1", "Kreditor borcları"],
    ["2.2.1.3", "Dövlət büdcəsinə vergi öhdəlikləri"]
  ],

  summary: [
    ["237", "Vergitutma məqsədləri üçün mənfəət"],
    ["241", "Vergiyə cəlb olunan mənfəət"],
    ["242", "Mənfəət vergisinin dərəcəsi"],
    ["243", "Mənfəət vergisi"],
    ["245", "Ödənilməli mənfəət vergisinin məbləği"]
  ]
};

const values = {};

function renderRows(sectionName, containerId) {
  const container = document.getElementById(containerId);

  let html = `
    <div class="row header">
      <div class="code">Göstərici</div>
      <div class="label">Açıqlama</div>
      <div class="amount">Məbləğ</div>
    </div>
  `;

  rows[sectionName].forEach(([code, label]) => {
    html += `
      <div class="row ${isTotal(code) ? "totalRow" : ""}">
        <div class="code">${code}</div>
        <div class="label">${label}</div>
        <div class="amount">
          <input data-code="${code}" value="${values[code] || "0,00"}">
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

function isTotal(code) {
  return ["218", "220", "234", "236", "237", "241", "243", "245", "1", "2"].includes(code);
}

function renderAll() {
  renderRows("income", "incomeRows");
  renderRows("expenses", "expenseRows");
  renderRows("tax", "taxRows");
  renderRows("assets", "assetRows");
  renderRows("summary", "summaryRows");
}

renderAll();

document.querySelectorAll(".nav").forEach((btn, index) => {
  btn.onclick = () => {
    currentSection = index;
    showSection(index);
  };
});

document.getElementById("nextBtn").onclick = () => {
  if (currentSection < sections.length - 1) {
    currentSection++;
    showSection(currentSection);
  }
};

document.getElementById("prevBtn").onclick = () => {
  if (currentSection > 0) {
    currentSection--;
    showSection(currentSection);
  }
};

function showSection(index) {
  document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
  document.querySelectorAll(".nav").forEach(s => s.classList.remove("active"));

  document.getElementById(sections[index]).classList.add("active");
  document.querySelectorAll(".nav")[index].classList.add("active");

  const titles = {
    general: "Ümumi məlumat",
    income: "Gəlirlər",
    expenses: "Xərclər",
    tax: "Verginin hesablanması",
    assets: "Aktivlər, öhdəliklər və kapital",
    summary: "İcmal"
  };

  document.getElementById("sectionTitle").textContent = titles[sections[index]];
}

document.getElementById("fillBtn").onclick = () => {
  /*
    GƏLƏCƏKDƏ BURAYA PDF QAYDALARI ƏLAVƏ EDƏCƏYİK.

    Nümunə:
    ÖMV bəyannaməsi sətr 1607, gəlir məbləği → 221.5
  */

  setValue("221.5", 1050);
  setValue("221.5.1", 1050);
  setValue("221.5.1.2", 1050);

  calculate();
  renderAll();

  alert("Nümunə doldurma icra edildi: 221.5 = 1050.00");
};

document.getElementById("clearBtn").onclick = () => {
  Object.keys(values).forEach(k => delete values[k]);
  renderAll();
};

document.getElementById("saveBtn").onclick = () => {
  collectInputs();
  chrome.storage.local.set({ profitDeclarationValues: values }, () => {
    alert("Qaralamada saxlanıldı.");
  });
};

document.getElementById("exportBtn").onclick = () => {
  collectInputs();

  const blob = new Blob([JSON.stringify(values, null, 2)], {
    type: "application/json"
  });

  const url = URL.createObjectURL(blob);

  chrome.downloads.download({
    url,
    filename: "menfeet_beyannamesi_melumatlari.json",
    saveAs: true
  });
};

function collectInputs() {
  document.querySelectorAll("input[data-code]").forEach(input => {
    values[input.dataset.code] = input.value;
  });
}

function setValue(code, amount) {
  values[code] = format(amount);
}

function getValue(code) {
  return parseNumber(values[code]);
}

function calculate() {
  const income = getValue("200") || getValue("218") || 0;

  const expenseCodes = [
    "221.1",
    "221.2",
    "221.3",
    "221.4",
    "221.5",
    "221.13",
    "221.15"
  ];

  const totalExpenses = expenseCodes.reduce((sum, code) => sum + getValue(code), 0);

  setValue("234", totalExpenses);
  setValue("236", totalExpenses);

  const profit = income - totalExpenses;

  setValue("237", profit > 0 ? profit : 0);
  setValue("239", profit < 0 ? Math.abs(profit) : 0);
  setValue("241", profit > 0 ? profit : 0);
  setValue("242", 20);
  setValue("243", profit > 0 ? profit * 0.20 : 0);
  setValue("245", profit > 0 ? profit * 0.20 : 0);
}

function parseNumber(v) {
  if (!v) return 0;

  return Number(
    String(v)
      .replace(/\s/g, "")
      .replace(",", ".")
      .replace(/[^\d.-]/g, "")
  ) || 0;
}

function format(n) {
  return Number(n || 0).toFixed(2).replace(".", ",");
}

/*
BBEC 2.20 DÜZƏLİŞ MƏNTİQİ

VAHİD BƏYANNAMƏ:
902 Gəlirlər, cəmi -> "Rüb üzrə orta say"
1+2+3+4 rüb cəmi -> 221.1.2

OMV:
1607.1.1 Hüquqi şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.1

1607.1.2 Fiziki şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.2
*/
