(()=>{
const ALARM='hesabat-check';
const DATA_VERSION=8;
const BASE_PERIOD_START='2026-04-01';
const MONTHS=['Yanvar','Fevral','Mart','Aprel','May','İyun','İyul','Avqust','Sentyabr','Oktyabr','Noyabr','Dekabr'];

chrome.runtime.onInstalled.addListener(async()=>{
  await chrome.alarms.create(ALARM,{periodInMinutes:60});
  const stored=await chrome.storage.local.get(['initialized','dataVersion','reports','emails','phones','settings']);
  const seed=await fetch(chrome.runtime.getURL('modules/hesabat-vaxti/seed.json')).then(r=>r.json());
  if(!stored.initialized){
    await chrome.storage.local.set({reports:seed.rows.map(createSeedReport),emails:stored.emails||[],phones:stored.phones||[],settings:{notifyDays:10,chromeEnabled:true,emailEnabled:false,phoneEnabled:false,emailMode:'multi',...(stored.settings||{})},initialized:true,dataVersion:DATA_VERSION,basePeriodStart:BASE_PERIOD_START});
  }else if((stored.dataVersion||1)<DATA_VERSION){
    const old=stored.reports||[];
    const manual=old.filter(r=>!r.form);
    const oldByKey=new Map(old.filter(r=>r.form).map(r=>[`${r.company}|${r.voen}|${r.taxType}`,r]));
    const imported=seed.rows.map(row=>{
      const prev=oldByKey.get(`${row.company}|${row.voen}|${row.taxType}`);
      const fresh=createSeedReport(row);
      // Köhnə versiyada bir ay seçiləndə digər ayların da səhvən göndərilmiş
      // işarələnməsi mümkün idi. Yenilənmə zamanı yalnız son tarixi keçmiş,
      // həqiqətən saxlanmış dövrləri qoruyuruq; cari/yaxınlaşan dövrlər yenidən görünür.
      const oldSent=new Set(prev?.sentPeriods||[]);
      const today=new Date();today.setHours(0,0,0,0);
      const safeSent=occurrenceList(fresh).filter(o=>oldSent.has(o.key)&&new Date(o.dueDate+'T23:59:59')<today).map(o=>o.key);
      return {...fresh,sentPeriods:safeSent,periodStatuses:Object.fromEntries(safeSent.map(k=>[k,'Göndərildi'])),sentAt:safeSent.length?prev?.sentAt||null:null,status:'Gözləyir'};
    });
    await chrome.storage.local.set({reports:[...imported,...manual],dataVersion:DATA_VERSION,basePeriodStart:BASE_PERIOD_START});
  }
});

chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)checkAndNotify();});
chrome.runtime.onMessage.addListener((m,s,send)=>{if(m.type==='run-check'){checkAndNotify(true).then(send);return true;}if(m.type==='send-report'){sendReport(m.report,true).then(send);return true;}if(m.type==='test-channel'){testChannel(m.channel).then(send);return true;}if(m.type==='gmail-connect'){gmailConnect().then(send);return true;}if(m.type==='gmail-status'){gmailStatus().then(send);return true;}if(m.type==='gmail-disconnect'){gmailDisconnect().then(send);return true;}if(m.type==='oauth-diagnostic'){oauthDiagnostic().then(send);return true;}});

function createSeedReport(r){return {...r,id:crypto.randomUUID(),period:inferPeriod(r.periodText),dueDate:firstDue(r.periodText),status:'Gözləyir',sentPeriods:[],sentAt:null,enabled:true,reportingBase:'1 aprel 2026-dan'};}
function inferPeriod(t=''){if(t.includes('Hər ay'))return 'Aylıq';if(t.includes('Hər rüb'))return 'Rüblük';if(t.includes('Hər il'))return 'İllik';return 'Digər';}
function parseRule(t=''){const day=+(t.match(/ayın\s+(\d+)/i)||[])[1]||20;if(t.includes('Hər ay'))return {kind:'monthly',day};if(t.includes('Hər rüb'))return {kind:'quarterly',day};if(t.includes('Hər il')){let month=2;if(t.includes('yanvar'))month=0;else if(t.includes('fevral'))month=1;else if(t.includes('mart'))month=2;return {kind:'yearly',day,month};}return {kind:'single'};}
function iso(y,m,d){return `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;}
function firstDue(t=''){const r=parseRule(t);if(r.kind==='monthly')return iso(2026,4,r.day);if(r.kind==='quarterly')return iso(2026,6,r.day);if(r.kind==='yearly')return iso(2027,r.month,r.day);return '2026-06-30';}
function occurrenceList(r){
  if(!r.form||!r.periodText)return [{key:r.dueDate,label:r.period||'Hesabat dövrü',dueDate:r.dueDate}];
  const rule=parseRule(r.periodText),n=new Date(),now=new Date(n.getFullYear(),n.getMonth(),n.getDate()),out=[];
  if(rule.kind==='monthly'){
    const last=new Date(now.getFullYear(),now.getMonth()-1,1);
    for(let d=new Date(2026,3,1);d<=last;d=new Date(d.getFullYear(),d.getMonth()+1,1)){
      const due=new Date(d.getFullYear(),d.getMonth()+1,rule.day);
      out.push({key:`M-${d.getFullYear()}-${d.getMonth()+1}`,label:`${MONTHS[d.getMonth()]} ${d.getFullYear()}`,dueDate:iso(due.getFullYear(),due.getMonth(),due.getDate())});
    }
  }else if(rule.kind==='quarterly'){
    const completedQuarter=Math.floor(now.getMonth()/3);
    for(let quarter=2;quarter<=completedQuarter;quarter++){
      const due=new Date(now.getFullYear(),quarter*3,rule.day);
      out.push({key:`Q-${now.getFullYear()}-${quarter}`,label:`${now.getFullYear()}-cı il, ${quarter}-ci rüb`,dueDate:iso(due.getFullYear(),due.getMonth(),due.getDate())});
    }
  }else if(rule.kind==='yearly'){
    const y=Math.max(2026,now.getFullYear()),due=new Date(y+1,rule.month,rule.day);
    out.push({key:`Y-${y}`,label:`${y}-cı il`,dueDate:iso(due.getFullYear(),due.getMonth(),due.getDate())});
  }else out.push({key:r.dueDate,label:r.period||'Dövr göstərilməyib',dueDate:r.dueDate});
  return out;
}
function diffDays(d){const [y,m,day]=String(d).split('-').map(Number),n=new Date(),today=new Date(n.getFullYear(),n.getMonth(),n.getDate()),due=new Date(y,m-1,day);return Math.round((due-today)/86400000);}
function pending(r){const sent=new Set(r.sentPeriods||[]);if(r.status==='Göndərildi'&&!r.sentPeriods)return [];return occurrenceList(r).filter(o=>!sent.has(o.key));}

async function checkAndNotify(force=false){
  const data=await chrome.storage.local.get(['reports','settings','notificationLog']);
  const reports=data.reports||[],settings=data.settings||{},notifyDays=settings.notifyDays??10;
  const log=data.notificationLog||{},todayKey=new Date().toISOString().slice(0,10);let count=0;
  for(const r of reports){
    if(!r.enabled)continue;
    const dues=pending(r).filter(o=>force||diffDays(o.dueDate)<=notifyDays);
    for(const due of dues){
      const logKey=`${todayKey}|${r.id}|${due.key}`;
      if(!force&&log[logKey])continue;
      const diff=diffDays(due.dueDate),item={...r,dueDate:due.dueDate,periodLabel:due.label};
      const result=await sendReport(item,false,true);
      if(result.ok){log[logKey]=Date.now();count++;}
    }
  }
  const cutoff=Date.now()-35*86400000;
  for(const [k,v] of Object.entries(log))if(v<cutoff)delete log[k];
  await chrome.storage.local.set({notificationLog:log});
  return {ok:true,count,message:count?`${count} bildiriş göndərildi`:'Bu gün üçün yeni bildiriş yoxdur'};
}

async function createChromeNotification(report,diff=diffDays(report.dueDate)){
  await chrome.notifications.create('r-'+report.id+'-'+(report.periodLabel||report.dueDate)+'-'+Date.now(),{type:'basic',iconUrl:'modules/hesabat-vaxti/icons/icon128.png',title:`${report.taxType} — ${report.company}`,message:diff>=0?`${report.periodLabel||report.period||''} hesabatının son tarixinə ${diff} gün qalıb. VÖEN: ${report.voen}`:`${report.periodLabel||report.period||''} hesabatı ${Math.abs(diff)} gündür gecikib!`,priority:2});
}


const GMAIL_SCOPE='https://www.googleapis.com/auth/gmail.send';

function normalizeIdentityError(error){
  const raw=String(error?.message||error||'Naməlum OAuth xətası');
  const low=raw.toLowerCase();
  if(low.includes('not granted')||low.includes('revoked'))return 'Google icazəsi verilməyib və ya əvvəlki icazə ləğv olunub';
  if(low.includes('bad client id'))return 'OAuth Client ID Google Cloud-da bu Chrome əlavəsinin ID-si ilə uyğun deyil';
  if(low.includes('user did not approve'))return 'Google icazə pəncərəsində icazə təsdiqlənmədi';
  if(low.includes('the user is not signed in')||low.includes('not signed in'))return 'Chrome profilində Google hesabına giriş edilməyib';
  return raw;
}

async function getChromeProfile(){
  try{return await chrome.identity.getProfileUserInfo({accountStatus:'ANY'});}catch(_){return {email:'',id:''};}
}

async function getGmailToken(interactive=false,{reset=false}={}){
  if(reset&&chrome.identity.clearAllCachedAuthTokens)await chrome.identity.clearAllCachedAuthTokens();
  try{
    const result=await chrome.identity.getAuthToken({interactive,enableGranularPermissions:true,scopes:[GMAIL_SCOPE]});
    const token=typeof result==='string'?result:result?.token;
    if(!token)throw new Error('Google access token qaytarmadı');
    return token;
  }catch(error){
    const profile=await getChromeProfile();
    const reason=normalizeIdentityError(error);
    const details=[reason,`Extension ID: ${chrome.runtime.id}`];
    if(profile?.email)details.push(`Chrome hesabı: ${profile.email}`);
    else details.push('Chrome-un sağ yuxarı profil menyusundan Google hesabına daxil olun və Sync-i aktiv edin');
    throw new Error(details.join(' | '));
  }
}

async function oauthDiagnostic(){
  const profile=await getChromeProfile();
  const manifest=chrome.runtime.getManifest();
  try{
    await getGmailToken(false);
    return {ok:true,connected:true,message:`OAuth hazırdır | Extension ID: ${chrome.runtime.id} | Chrome hesabı: ${profile.email||'tapılmadı'}`,extensionId:chrome.runtime.id,profileEmail:profile.email||'',clientId:manifest.oauth2?.client_id||''};
  }catch(error){
    return {ok:false,connected:false,message:error.message,extensionId:chrome.runtime.id,profileEmail:profile.email||'',clientId:manifest.oauth2?.client_id||''};
  }
}

async function gmailStatus(){
  try{await getGmailToken(false);return {ok:true,connected:true,message:'Gmail hesabı qoşulub'};}
  catch(e){return {ok:true,connected:false,message:e.message};}
}

async function gmailConnect(){
  try{
    const profile=await getChromeProfile();
    if(!profile?.email)throw new Error(`Chrome profilində Google hesabı tapılmadı | Extension ID: ${chrome.runtime.id} | Chrome-un sağ yuxarı profil menyusundan hesabınıza daxil olun və Sync-i aktiv edin`);
    await getGmailToken(true,{reset:true});
    return {ok:true,connected:true,message:`Gmail uğurla qoşuldu: ${profile.email}`};
  }catch(e){return {ok:false,connected:false,message:e.message};}
}

async function gmailDisconnect(){
  try{
    const token=await getGmailToken(false);
    await fetch(`https://accounts.google.com/o/oauth2/revoke?token=${encodeURIComponent(token)}`);
  }catch(_){ }
  try{if(chrome.identity.clearAllCachedAuthTokens)await chrome.identity.clearAllCachedAuthTokens();}catch(_){ }
  return {ok:true,connected:false,message:'Gmail hesabı ayrıldı və OAuth keşi təmizləndi'};
}

function base64UrlUtf8(text){
  const bytes=new TextEncoder().encode(text);let bin='';
  for(const b of bytes)bin+=String.fromCharCode(b);
  return btoa(bin).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
async function sendGmail(to,subject,body){
  let token=await getGmailToken(false);
  const raw=[`To: ${to}`,'Content-Type: text/plain; charset=UTF-8','MIME-Version: 1.0',`Subject: =?UTF-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,'',body].join('\r\n');
  let res=await fetch('https://www.googleapis.com/gmail/v1/users/me/messages/send',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({raw:base64UrlUtf8(raw)})});
  if(res.status===401){
    await new Promise(r=>chrome.identity.removeCachedAuthToken({token},r));
    token=await getGmailToken(true);
    res=await fetch('https://www.googleapis.com/gmail/v1/users/me/messages/send',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({raw:base64UrlUtf8(raw)})});
  }
  if(!res.ok)throw new Error('Gmail göndərmə xətası: '+await res.text());
}

async function testChannel(channel){
  const sample={id:'test',company:'Test şirkəti',voen:'0000000000',taxType:'Test hesabatı',periodLabel:'Test dövrü',period:'Test dövrü',dueDate:new Date().toISOString().slice(0,10)};
  const d=await chrome.storage.local.get(['settings']);const settings=d.settings||{};
  const original={chromeEnabled:settings.chromeEnabled,emailEnabled:settings.emailEnabled,phoneEnabled:settings.phoneEnabled};
  const patched={...settings,chromeEnabled:channel==='chrome',emailEnabled:channel==='email',phoneEnabled:channel==='phone',emailMode:'multi'};
  await chrome.storage.local.set({settings:patched});
  try{return await sendReport(sample,true,true);}finally{await chrome.storage.local.set({settings:{...patched,...original}});}
}

async function sendReport(report,manual,includeChrome=true){
  const d=await chrome.storage.local.get(['emails','phones','settings']);
  const emails=(d.emails||[]).filter(x=>x.active).map(x=>x.email),phones=(d.phones||[]).filter(x=>x.active).map(x=>x.phone),s=d.settings||{};
  const legacy=s.emailMode||'none';
  const chromeEnabled=s.chromeEnabled!==false;
  const emailEnabled=Boolean(s.emailEnabled||legacy==='emailjs'||legacy==='gmail');
  const phoneEnabled=Boolean(s.phoneEnabled||legacy==='webhook');
  const text=`${report.company} (${report.voen}) üçün ${report.taxType} — ${report.periodLabel||report.period||''} hesabatının son tarixi ${report.dueDate}-dir.`;
  const results=[];
  try{
    if(includeChrome&&chromeEnabled){await createChromeNotification(report);results.push('Chrome');}
    if(emailEnabled){
      if(!emails.length)throw new Error('E-poçt kanalı aktivdir, amma aktiv e-poçt əlavə edilməyib');
      const subject=`Hesabat bildirişi: ${report.taxType} — ${report.company}`;
      for(const to_email of emails)await sendGmail(to_email,subject,text);
      results.push('Gmail');
    }
    if(phoneEnabled){
      if(!phones.length)throw new Error('Telefon kanalı aktivdir, amma aktiv nömrə əlavə edilməyib');
      if(!s.webhookUrl)throw new Error('Telefon bildirişi üçün Webhook URL daxil edilməyib');
      const res=await fetch(s.webhookUrl,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({channel:'phone',phones,report,message:text,manual})});
      if(!res.ok)throw new Error('Telefon webhook xətası');
      results.push('telefon');
    }
    if(!results.length)return {ok:false,message:'Heç bir bildiriş kanalı aktiv deyil'};
    return {ok:true,message:`Bildiriş göndərildi: ${results.join(', ')}`};
  }catch(e){return {ok:false,message:e.message};}
}


})();
