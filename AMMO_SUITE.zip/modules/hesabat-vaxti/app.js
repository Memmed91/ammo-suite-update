let state={reports:[],emails:[],phones:[],periodStatusMap:{},settings:{notifyDays:10,emailMode:'none'},gmailConnected:false},view='dashboard',activeFilter=null;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
async function load(){const saved=await chrome.storage.local.get(['reports','emails','phones','settings','periodStatusMap']);state={...state,...saved,settings:{...state.settings,...(saved.settings||{})},reports:saved.reports||[],emails:saved.emails||[],phones:saved.phones||[],periodStatusMap:saved.periodStatusMap||{}};if(!Number.isFinite(+state.settings.notifyDays))state.settings.notifyDays=10;migratePeriodStatuses();let gs=null;try{gs=await chrome.runtime.sendMessage({type:'gmail-status'});}catch(e){console.warn('gmail-status',e);}state.gmailConnected=Boolean(gs?.connected);render();}
async function save(){await chrome.storage.local.set(state)}
const BASE_START=new Date(2026,3,1);
const MONTHS=['Yanvar','Fevral','Mart','Aprel','May','İyun','İyul','Avqust','Sentyabr','Oktyabr','Noyabr','Dekabr'];
function dateOnly(){const n=new Date();return new Date(n.getFullYear(),n.getMonth(),n.getDate())}
function iso(y,m,d){return `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`}
function parseRule(t=''){
  const day=+(t.match(/ayın\s+(\d+)/i)||[])[1]||20;
  if(t.includes('Hər ay'))return {kind:'monthly',day};
  if(t.includes('Hər rüb'))return {kind:'quarterly',day};
  if(t.includes('Hər il')){
    let month=2;if(t.includes('yanvar'))month=0;else if(t.includes('fevral'))month=1;else if(t.includes('mart'))month=2;
    return {kind:'yearly',day,month};
  }
  return {kind:'single'};
}
function occurrenceList(r){
  if(!r.form||!r.periodText)return [{key:r.dueDate,label:r.period||'Hesabat dövrü',dueDate:r.dueDate}];
  const rule=parseRule(r.periodText),now=dateOnly(),out=[];
  if(rule.kind==='monthly'){
    // Yalnız başa çatmış aylar: aprel 2026-dan keçən aya qədər.
    const last=new Date(now.getFullYear(),now.getMonth()-1,1);
    for(let d=new Date(BASE_START);d<=last;d=new Date(d.getFullYear(),d.getMonth()+1,1)){
      const due=new Date(d.getFullYear(),d.getMonth()+1,rule.day);
      out.push({key:`M-${d.getFullYear()}-${d.getMonth()+1}`,label:`${MONTHS[d.getMonth()]} ${d.getFullYear()}`,dueDate:iso(due.getFullYear(),due.getMonth(),due.getDate())});
    }
  }else if(rule.kind==='quarterly'){
    const completedQuarter=Math.floor(now.getMonth()/3); // Julyda 2: II rüb tamamlanıb
    for(let quarter=2;quarter<=completedQuarter;quarter++){
      const due=new Date(now.getFullYear(),quarter*3,rule.day);
      out.push({key:`Q-${now.getFullYear()}-${quarter}`,label:`${now.getFullYear()}-cı il, ${quarter}-ci rüb`,dueDate:iso(due.getFullYear(),due.getMonth(),due.getDate())});
    }
  }else if(rule.kind==='yearly'){
    const y=Math.max(2026,now.getFullYear());
    const due=new Date(y+1,rule.month,rule.day);
    out.push({key:`Y-${y}`,label:`${y}-cı il`,dueDate:iso(due.getFullYear(),due.getMonth(),due.getDate())});
  }else out.push({key:r.dueDate,label:r.period||'Dövr göstərilməyib',dueDate:r.dueDate});
  return out;
}
function periodStatusId(r,key){return `${r.id}::${key}`}
function migratePeriodStatuses(){
  state.periodStatusMap=state.periodStatusMap||{};
  state.reports.forEach(r=>{
    Object.entries(r.periodStatuses||{}).forEach(([key,value])=>{
      const id=periodStatusId(r,key);if(!(id in state.periodStatusMap))state.periodStatusMap[id]=value;
    });
    (r.sentPeriods||[]).forEach(key=>{const id=periodStatusId(r,key);if(!(id in state.periodStatusMap))state.periodStatusMap[id]='Göndərildi'});
  });
}
function isOccurrenceSent(r,key){return state.periodStatusMap?.[periodStatusId(r,key)]==='Göndərildi'}
function setOccurrenceStatus(r,key,status){
  state.periodStatusMap=state.periodStatusMap||{};
  const id=periodStatusId(r,key);
  if(status==='Göndərildi')state.periodStatusMap[id]='Göndərildi';else delete state.periodStatusMap[id];
  // Köhnə sahələri yalnız uyğun seçilmiş dövr üzrə sinxronlaşdırırıq.
  r.periodStatuses={...(r.periodStatuses||{})};
  if(status==='Göndərildi')r.periodStatuses[key]='Göndərildi';else delete r.periodStatuses[key];
  const sent=new Set(r.sentPeriods||[]);
  if(status==='Göndərildi')sent.add(key);else sent.delete(key);
  r.sentPeriods=[...sent];
  const all=occurrenceList(r),sentCount=all.filter(o=>isOccurrenceSent(r,o.key)).length;
  r.status=sentCount===all.length&&all.length?'Göndərildi':sentCount?'Qismən göndərildi':'Gözləyir';
  if(status==='Göndərildi')r.sentAt=new Date().toISOString();
}
function pendingOccurrences(r){
  return occurrenceList(r).filter(o=>!isOccurrenceSent(r,o.key));
}
function occDays(o){const [y,m,d]=String(o.dueDate).split('-').map(Number),today=dateOnly(),due=new Date(y,m-1,d);return Math.round((due-today)/86400000)}
function primaryOccurrence(r){if(r._occurrence)return r._occurrence;const p=pendingOccurrences(r);return p.sort((a,b)=>occDays(a)-occDays(b))[0]||occurrenceList(r).slice(-1)[0]}
function days(r){const o=primaryOccurrence(r);return o?occDays(o):999999}
function displayDue(r){const o=primaryOccurrence(r);return o?.dueDate||r.dueDate||'—'}
function statusOf(r){return pendingOccurrences(r).length===0?'Göndərildi':days(r)<0?'Gecikib':'Gözləyir'}
function periodDetails(r){return pendingOccurrences(r).map(o=>({...o,days:occDays(o)})).filter(o=>o.days<0).sort((a,b)=>a.days-b.days)}
function isStatistics(r){return r.sourceSheet==='STATİSTİKA'||['12-tikinti','12-investisiya','4-əmək','1-İnvest','4-enerji-','1-Tikinti','1-İnnovasiya','1-İKT','1-İstehsal','1-Əmək','1-Əmək şəraiti','1-Müəssisə'].includes(r.taxType)}
function fineFor(r,o){if(!o||occDays(o)>=0)return '—';return isStatistics(r)?'300–500 AZN risk':'40 AZN'}
function expanded(rows,predicate){return rows.flatMap(r=>pendingOccurrences(r).filter(predicate).map(o=>({...r,_occurrence:o,_rowKey:r.id+'|'+o.key})))}
function soonRows(rows=activeReports()){return expanded(rows,o=>{const d=occDays(o);return d>=0&&d<=state.settings.notifyDays})}
function lateRows(rows=activeReports()){return expanded(rows,o=>occDays(o)<0)}
function todayRows(rows=activeReports()){return expanded(rows,o=>occDays(o)===0)}
function showPeriodPopup(event,id){
  event.stopPropagation();const r=state.reports.find(x=>x.id===id);if(!r)return;
  document.querySelector('.period-popup')?.remove();
  const items=periodDetails(r);const pop=document.createElement('div');pop.className='period-popup period-popup-list';
  pop.innerHTML=`<button class="period-popup-close" aria-label="Bağla">×</button><small>Göndərilməmiş hesabat dövrləri</small><b>${esc(r.taxType)} — ${esc(r.company)}</b><div class="period-items">${items.map(o=>`<div><strong>${esc(o.label)}</strong><span>${Math.abs(o.days)} gün gecikib · ${fineFor(r,o)}</span></div>`).join('')||'<div><strong>Gecikmiş dövr yoxdur</strong></div>'}</div>`;
  document.body.appendChild(pop);const rect=event.currentTarget.getBoundingClientRect();
  const left=Math.min(window.innerWidth-pop.offsetWidth-12,Math.max(12,rect.left+rect.width/2-pop.offsetWidth/2));
  const top=Math.min(window.innerHeight-pop.offsetHeight-12,rect.bottom+8);pop.style.left=left+'px';pop.style.top=top+'px';
  pop.querySelector('.period-popup-close').onclick=()=>pop.remove();
  setTimeout(()=>document.addEventListener('click',function close(e){if(!pop.contains(e.target)){pop.remove();document.removeEventListener('click',close)}}),0);
}
function activeReports(){return state.reports.filter(r=>r.enabled!==false)}
function stats(){const a=activeReports(),sent=a.filter(r=>statusOf(r)==='Göndərildi').length,late=lateRows(a).length,soon=soonRows(a).length,today=todayRows(a).length;return{all:a.length,sent,late,soon,today}}
function sorted(rows){return [...rows].sort((a,b)=>{const as=statusOf(a)==='Göndərildi',bs=statusOf(b)==='Göndərildi';if(as!==bs)return as?1:-1;return days(a)-days(b)})}
function render(){const titles={dashboard:['İcmal','2026-cı ilin II rübü — 1 aprel 2026-dan başlayan hesabatlara nəzarət'],reports:['Hesabatların hərəkəti','2026 II rüb üzrə gecikmiş və ən az vaxt qalan hesabatlar birinci göstərilir'],analytics:['Hesabat bölməsi','Hesabat növləri üzrə say və qalan günlər'],settings:['İdarəetmə paneli','Vergi növləri, tarixlər, e-poçtlar, telefonlar və inteqrasiyalar']};$('#pageTitle').textContent=titles[view][0];$('#pageSub').textContent=titles[view][1];$$('nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===view));$('#content').innerHTML=view==='dashboard'?dashboard():view==='reports'?reports():view==='analytics'?analytics():settings();bind();}
function kpis(){const s=stats();return `<div class="kpis"><button class="kpi clickable" data-kpi="all"><span>Bütün hesabatlar</span><b>${s.all}</b><small>Hamısını göstər</small></button><button class="kpi clickable" data-kpi="soon"><span>${state.settings.notifyDays} gün içində</span><b>${s.soon}</b><small>Yaxınlaşanları göstər</small></button><button class="kpi clickable" data-kpi="late"><span>Gecikmiş</span><b>${s.late}</b><small>Gecikənləri göstər</small></button><button class="kpi clickable" data-kpi="sent"><span>Göndərilmiş</span><b>${s.sent}</b><small>Göndərilənləri göstər</small></button></div>`}
function dashboard(){const priority=sorted(soonRows()).slice(0,12),today=sorted(todayRows());return kpis()+`<div class="today-card clickable" data-kpi="today"><div><span>Bu gün son tarix olan hesabatlar</span><b>${stats().today}</b></div><strong>${stats().today?'Siyahını aç →':'Bu gün üçün gözləyən hesabat yoxdur'}</strong></div><div class="grid2"><div class="panel"><div class="panel-head"><div><h3>Son ${state.settings.notifyDays} gün içində olan hesabatlar</h3><p class="muted">Yalnız son tarixinə 0–${state.settings.notifyDays} gün qalan dövrlər göstərilir.</p></div><button class="link-btn" data-kpi="priority">Hamısını göstər</button></div>${priority.length?table(priority):empty('Son 10 gün içində hesabat yoxdur')}</div><div class="panel"><div class="panel-head"><h3>Bu gün üçün qalan hesabatlar</h3><button class="link-btn" data-kpi="today">Filtrlə</button></div>${today.length?compactTable(today):empty('Bu gün üçün göndərilməmiş hesabat yoxdur')}</div></div>`}
function reports(){const rows=applyFilter(sorted(activeReports()),activeFilter);return kpis()+`<div class="panel"><div class="panel-head"><div><h3>Hesabat siyahısı</h3>${activeFilter?`<div class="filter-note">Aktiv filtr: <b>${filterLabel(activeFilter)}</b> <button id="clearFilter">Təmizlə</button></div>`:''}</div><div class="filters"><input id="search" placeholder="Şirkət, VÖEN və ya hesabat..."><select id="statusFilter"><option value="all">Bütün statuslar</option><option>Gözləyir</option><option>Göndərildi</option><option>Gecikib</option></select></div></div><div id="reportTable">${table(rows)}</div></div>`}
function applyFilter(rows,f){if(!f)return rows;if(f.kind==='all')return rows;if(f.kind==='soon'||f.kind==='priority')return sorted(soonRows(rows));if(f.kind==='late')return sorted(lateRows(rows));if(f.kind==='sent')return rows.filter(r=>statusOf(r)==='Göndərildi');if(f.kind==='today')return sorted(todayRows(rows));if(f.kind==='type')return rows.filter(r=>r.taxType===f.value);return rows}
function filterLabel(f){return f.kind==='all'?'Bütün hesabatlar':f.kind==='soon'?`${state.settings.notifyDays} gün içində`:f.kind==='late'?'Gecikmiş':f.kind==='sent'?'Göndərilmiş':f.kind==='today'?'Bu gün son tarix':f.kind==='priority'?'Təcili hesabatlar':`Hesabat növü: ${f.value}`}
function table(rows){return `<div class="table-wrap"><table><thead><tr><th>Şirkət / VÖEN</th><th>Hesabat</th><th>Hesabat dövrü</th><th>Son tarix</th><th>Vaxt</th><th>Təxmini cərimə</th><th>Status</th><th></th></tr></thead><tbody>${rows.map(r=>{const d=days(r),sent=statusOf(r)==='Göndərildi',hot=!sent&&d>=0&&d<=state.settings.notifyDays,o=primaryOccurrence(r);return `<tr data-id="${r.id}"><td><div class="company">${esc(r.company)}</div><div class="muted">${esc(r.voen)}</div></td><td class="${hot?'fire':''}">${hot?'🔥 ':''}${esc(r.taxType)}</td><td>${esc(o?.label||r.period)}</td><td>${displayDue(r)}</td><td>${sent?'—':d===0?'<b class="today-text">Bu gün</b>':d>0?`${d} gün qalıb`:`<button class="late-time-btn" data-period-popup="${r.id}" title="Bütün gecikmiş dövrləri göstər">${Math.abs(d)} gün gecikib</button>`}</td><td><span class="fine-badge ${d<0?'fine-risk':''}">${fineFor(r,o)}</span></td><td><span class="badge ${sent?'sent':d<0?'late':'waiting'}">${sent?'Göndərildi':d<0?'Gecikib':'Gözləyir'}</span></td><td><div class="row-actions">${!sent?`<button class="small sent-btn" data-send="${r.id}" data-period-key="${o?.key||''}">Göndərildi</button>`:''}<button class="small" data-mail="${r.id}">Mesaj</button><button class="small danger" data-del="${r.id}">Sil</button></div></td></tr>`}).join('')||`<tr><td colspan="8">${empty('Bu filtrə uyğun hesabat tapılmadı')}</td></tr>`}</tbody></table></div>`}
function compactTable(rows){return `<div class="compact-list">${rows.slice(0,8).map(r=>`<button data-open-report="${r.id}"><span><b>${esc(r.company)}</b><small>${esc(r.taxType)} · ${esc(r.voen)}</small></span><strong>${days(r)===0?'Bu gün':days(r)+' gün'}</strong></button>`).join('')}</div>`}
function analytics(){const groups={};activeReports().forEach(r=>(groups[r.taxType]??=[]).push(r));const items=Object.entries(groups).map(([type,rs])=>{const pending=rs.filter(r=>statusOf(r)!=='Göndərildi'),nearest=pending.length?Math.min(...pending.map(days)):null;return{type,count:rs.length,nearest}}).sort((a,b)=>(a.nearest??999999)-(b.nearest??999999)||b.count-a.count);return kpis()+`<div class="panel"><div class="panel-head"><div><h3>Hesabat növləri</h3><p class="muted">Sayın və ya hesabat adının üzərinə vuraraq aid şirkətləri filtrləyin.</p></div></div><div class="analytics-table"><div class="analytics-head"><span>Hesabat növü</span><span>Say</span><span>Ən yaxın qalan gün</span></div>${items.map(x=>`<button class="analytics-row" data-type-filter="${escAttr(x.type)}"><span>${esc(x.type)}</span><b>${x.count}</b><strong class="${x.nearest!==null&&x.nearest<=state.settings.notifyDays?'urgent-text':''}">${x.nearest===null?'Hamısı göndərilib':x.nearest<0?`${Math.abs(x.nearest)} gün gecikib`:x.nearest===0?'Bu gün':`${x.nearest} gün qalıb`}</strong></button>`).join('')}</div></div>`}
function settings(){
  const activeEmails=state.emails.filter(x=>x.active).length,activePhones=state.phones.filter(x=>x.active).length;
  const emailReady=activeEmails>0&&state.gmailConnected;
  const phoneReady=activePhones>0&&state.settings.webhookUrl;
  return `<div class="panel"><h3>Avtomatik bildiriş sistemi</h3><p class="muted">Hər saat yoxlanılır, eyni hesabat üçün gündə yalnız bir dəfə bildiriş göndərilir.</p><div class="channel-status-grid"><div class="channel-status ready"><b>Google Chrome</b><span>Hazırdır</span><button data-test-channel="chrome">Test et</button></div><div class="channel-status ${emailReady?'ready':'missing'}"><b>Gmail</b><span>${state.gmailConnected?(activeEmails?'Hazırdır':'Alıcı e-poçtu əlavə edin'):'Google hesabını qoşun'}</span><button data-test-channel="email">Test et</button></div><div class="channel-status ${phoneReady?'ready':'missing'}"><b>Telefon</b><span>${phoneReady?'Hazırdır':'Webhook URL tələb olunur'}</span><button data-test-channel="phone">Test et</button></div></div></div><div class="grid2"><div class="panel"><h3>Bildiriş qaydası</h3><div class="settings-grid" style="margin-top:16px"><label>Neçə gün əvvəl xəbərdarlıq<input id="notifyDays" type="number" min="1" max="60" value="${state.settings.notifyDays||10}"></label><div class="notify-channels"><span>Bildiriş kanalları</span><label class="check-label"><input id="chromeEnabled" type="checkbox" ${state.settings.chromeEnabled!==false?'checked':''}> Google Chrome bildirişi</label><label class="check-label"><input id="emailEnabled" type="checkbox" ${state.settings.emailEnabled||state.settings.emailMode==='gmail'?'checked':''}> Gmail ilə e-poçt göndər</label><label class="check-label"><input id="phoneEnabled" type="checkbox" ${state.settings.phoneEnabled||state.settings.emailMode==='webhook'?'checked':''}> Telefon nömrəsinə SMS/WhatsApp</label></div><div class="gmail-connect-box"><b>Google hesabı</b><span>${state.gmailConnected?'Gmail hesabı qoşulub':'Gmail hesabı qoşulmayıb'}</span><button id="gmailConnect" class="${state.gmailConnected?'danger':'primary'}">${state.gmailConnected?'Hesabı ayır':'Google hesabını qoş'}</button><button id="oauthDiagnostic">OAuth yoxla</button></div><label>SMS/WhatsApp Webhook URL<input id="webhookUrl" placeholder="SMS xidməti webhook ünvanı" value="${esc(state.settings.webhookUrl||'')}"></label></div><button id="saveSettings" class="primary" style="margin-top:16px">Ayarları saxla</button><button id="runCheck" style="margin:16px 0 0 8px">İndi yoxla</button><p class="help">Gmail üçün yalnız bir dəfə “Google hesabını qoş” düyməsinə basıb icazə vermək lazımdır. Telefon üçün pulsuz push bildirişi növbəti mərhələdə ntfy ilə əlavə ediləcək.</p></div><div class="panel"><h3>Mesaj göndəriləcək e-poçtlar</h3><div class="email-row"><input id="newEmail" type="email" placeholder="muhasib@example.com"><button id="addEmail">Əlavə et</button></div><div>${state.emails.map((e,i)=>`<div class="email-row"><input type="checkbox" data-email-toggle="${i}" ${e.active?'checked':''}><input type="email" value="${esc(e.email)}" data-email-edit="${i}"><button class="danger" data-email-del="${i}">Sil</button></div>`).join('')||'<p class="muted">Hələ e-poçt əlavə edilməyib.</p>'}</div><hr><h3>Bildiriş göndəriləcək telefonlar</h3><div class="email-row"><input id="newPhone" type="tel" placeholder="+994501234567"><button id="addPhone">Əlavə et</button></div><div>${state.phones.map((p,i)=>`<div class="email-row"><input type="checkbox" data-phone-toggle="${i}" ${p.active?'checked':''}><input type="tel" value="${esc(p.phone)}" data-phone-edit="${i}"><button class="danger" data-phone-del="${i}">Sil</button></div>`).join('')||'<p class="muted">Hələ telefon nömrəsi əlavə edilməyib.</p>'}</div></div></div><div class="panel"><div class="panel-head"><h3>Vergi və hesabat növləri</h3><button id="addTax">+ Növ yarat</button></div><p class="muted">Hesabat növünə toxunduqda həmin növə aid şirkətlər açılır.</p>${[...new Set(state.reports.map(r=>r.taxType))].sort().map(x=>`<button class="badge waiting tax-chip" data-type-filter="${escAttr(x)}">${esc(x)}</button>`).join('')}</div>`
}
function empty(t){return `<div class="empty">${esc(t)}</div>`}
function goFilter(kind,value){activeFilter={kind,value};view='reports';render()}
function bind(){$$('[data-period-popup]').forEach(b=>b.onclick=e=>showPeriodPopup(e,b.dataset.periodPopup));$$('[data-kpi]').forEach(b=>b.onclick=()=>goFilter(b.dataset.kpi));$$('[data-type-filter]').forEach(b=>b.onclick=()=>goFilter('type',b.dataset.typeFilter));$$('[data-open-report]').forEach(b=>b.onclick=()=>{const r=state.reports.find(x=>x.id===b.dataset.openReport);goFilter('type',r.taxType)});$('#clearFilter')?.addEventListener('click',()=>{activeFilter=null;render()});$$('[data-send]').forEach(b=>b.onclick=async()=>{const r=state.reports.find(x=>x.id===b.dataset.send);const key=b.dataset.periodKey;if(key)setOccurrenceStatus(r,key,'Göndərildi');else occurrenceList(r).forEach(o=>setOccurrenceStatus(r,o.key,'Göndərildi'));await save();toast('Seçilən hesabat dövrü göndərildi kimi işarələndi');render()});$$('[data-del]').forEach(b=>b.onclick=async()=>{if(confirm('Bu hesabat silinsin?')){state.reports=state.reports.filter(x=>x.id!==b.dataset.del);await save();render()}});$$('[data-mail]').forEach(b=>b.onclick=async()=>{const r=state.reports.find(x=>x.id===b.dataset.mail);const res=await chrome.runtime.sendMessage({type:'send-report',report:r});toast(res.message)});$('#search')?.addEventListener('input',filterRows);$('#statusFilter')?.addEventListener('change',filterRows);$('#saveSettings')?.addEventListener('click',async()=>{state.settings={...state.settings,notifyDays:+$('#notifyDays').value,chromeEnabled:$('#chromeEnabled').checked,emailEnabled:$('#emailEnabled').checked,phoneEnabled:$('#phoneEnabled').checked,emailMode:'gmail',webhookUrl:$('#webhookUrl').value};await save();toast('Ayarlar saxlanıldı');render()});$('#addEmail')?.addEventListener('click',async()=>{const v=$('#newEmail').value.trim();if(v){state.emails.push({email:v,active:true});await save();render()}});$$('[data-email-toggle]').forEach(x=>x.onchange=async()=>{state.emails[+x.dataset.emailToggle].active=x.checked;await save()});$$('[data-email-edit]').forEach(x=>x.onchange=async()=>{state.emails[+x.dataset.emailEdit].email=x.value;await save()});$$('[data-email-del]').forEach(x=>x.onclick=async()=>{state.emails.splice(+x.dataset.emailDel,1);await save();render()});$('#addPhone')?.addEventListener('click',async()=>{const v=$('#newPhone').value.trim();if(v){state.phones.push({phone:v,active:true});await save();render()}});$$('[data-phone-toggle]').forEach(x=>x.onchange=async()=>{state.phones[+x.dataset.phoneToggle].active=x.checked;await save()});$$('[data-phone-edit]').forEach(x=>x.onchange=async()=>{state.phones[+x.dataset.phoneEdit].phone=x.value;await save()});$$('[data-phone-del]').forEach(x=>x.onclick=async()=>{state.phones.splice(+x.dataset.phoneDel,1);await save();render()});$('#addTax')?.addEventListener('click',()=>{$('#modal').classList.remove('hidden');$('#reportForm [name=taxType]').focus()})}
function filterRows(){const q=($('#search').value||'').toLowerCase(),f=$('#statusFilter').value;let rows=applyFilter(sorted(activeReports()),activeFilter);rows=rows.filter(r=>`${r.company} ${r.voen} ${r.taxType}`.toLowerCase().includes(q)&&(f==='all'||(f==='Gecikib'?days(r)<0:f==='Gözləyir'?days(r)>=0:statusOf(r)===f)));$('#reportTable').innerHTML=table(rows);bind()}
function esc(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function escAttr(s=''){return esc(s).replace(/`/g,'&#96;')}
function toast(t){const x=$('#toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),2500)}
$$('nav button').forEach(b=>b.onclick=()=>{view=b.dataset.view;activeFilter=null;render()});$('#addReport').onclick=()=>$('#modal').classList.remove('hidden');$('.close').onclick=()=>$('#modal').classList.add('hidden');$('#reportForm').onsubmit=async e=>{e.preventDefault();const o=Object.fromEntries(new FormData(e.target));state.reports.unshift({...o,id:crypto.randomUUID(),status:'Gözləyir',sentAt:null,enabled:true});await save();e.target.reset();$('#modal').classList.add('hidden');view='reports';activeFilter=null;render()};$('#checkNow').onclick=async()=>{const r=await chrome.runtime.sendMessage({type:'run-check'});toast(`${r.count} hesabat yoxlanıldı`)};setInterval(()=>$('#clock').textContent=new Date().toLocaleString('az-AZ'),1000);load();

// v1.6: şirkətlər hesabat/dövr üzrə qruplaşdırılır; şirkət siyahısı say düyməsində açılır.
let groupCache={},groupSeq=0;
function resetGroupCache(){groupCache={};groupSeq=0}
function groupRows(rows){
  const map=new Map();
  rows.forEach(r=>{
    // Filtrlənmiş sətirdəki konkret dövrü qoruyuruq. Bu, ƏDV-nin həm gecikmiş
    // aylarını, həm də 10 gün içində olan cari ayını ayrıca göstərməyə imkan verir.
    const o=r._occurrence||primaryOccurrence(r);
    if(!o)return;
    const key=[r.taxType,o.key||'',o.label||r.period||'',o.dueDate||r.dueDate||''].join('|');
    if(!map.has(key))map.set(key,{taxType:r.taxType,occurrence:o,period:o.label||r.period||'—',dueDate:o.dueDate||r.dueDate||'—',members:[]});
    map.get(key).members.push(r);
  });
  return [...map.values()].map(g=>{
    const id='grp-'+(++groupSeq);groupCache[id]=g;g.groupId=id;
    // Qrupun vaxtı və statusu hesabatın başqa aylarına görə deyil,
    // məhz bu sətirdə göstərilən ay/rüb/il üzrə hesablanır.
    g.day=occDays(g.occurrence);
    g.sent=g.members.every(r=>isOccurrenceSent(r,g.occurrence.key));
    g.late=!g.sent&&g.day<0;
    return g;
  }).sort((a,b)=>{if(a.sent!==b.sent)return a.sent?1:-1;return a.day-b.day||a.taxType.localeCompare(b.taxType,'az')});
}
function groupFine(g){
  if(!g.late)return '—';
  const stat=g.members.some(isStatistics),n=g.members.length;
  return stat?`${n} şirkət × 300–500 AZN`:`${n} şirkət × 40 AZN = ${n*40} AZN`;
}
function showCompaniesPopup(event,groupId){
  event.stopPropagation();document.querySelector('.company-popup')?.remove();const g=groupCache[groupId];if(!g)return;
  const pop=document.createElement('div');pop.className='period-popup company-popup';
  pop.innerHTML=`<button class="period-popup-close" aria-label="Bağla">×</button><small>${esc(g.taxType)} · ${esc(g.period)}</small><b>${g.members.length} şirkət</b><div class="company-popup-list">${g.members.sort((a,b)=>a.company.localeCompare(b.company,'az')).map(r=>`<div><strong>${esc(r.company)}</strong><span>${esc(r.voen)}</span></div>`).join('')}</div>`;
  document.body.appendChild(pop);const rect=event.currentTarget.getBoundingClientRect();
  pop.style.left=Math.min(window.innerWidth-pop.offsetWidth-12,Math.max(12,rect.left+rect.width/2-pop.offsetWidth/2))+'px';
  pop.style.top=Math.min(window.innerHeight-pop.offsetHeight-12,rect.bottom+8)+'px';
  pop.querySelector('.period-popup-close').onclick=()=>pop.remove();
  setTimeout(()=>document.addEventListener('click',function close(e){if(!pop.contains(e.target)){pop.remove();document.removeEventListener('click',close)}}),0);
}
function render(){
  resetGroupCache();
  const titles={dashboard:['İcmal','2026-cı ilin II rübü — 1 aprel 2026-dan başlayan hesabatlara nəzarət'],reports:['Hesabatların hərəkəti','Hesabatlar növ və dövr üzrə qruplaşdırılır; şirkətləri sayın üzərinə vuraraq görün'],analytics:['Hesabat bölməsi','Hesabat növləri üzrə say və qalan günlər'],settings:['İdarəetmə paneli','Vergi növləri, tarixlər, e-poçtlar, telefonlar və inteqrasiyalar']};
  $('#pageTitle').textContent=titles[view][0];$('#pageSub').textContent=titles[view][1];$$('nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  $('#content').innerHTML=view==='dashboard'?dashboard():view==='reports'?reports():view==='analytics'?analytics():settings();bind();
}
function dashboard(){
  const priority=sorted(soonRows()),today=sorted(todayRows());
  return kpis()+`<div class="today-card clickable" data-kpi="today"><div><span>Bu gün son tarix olan hesabatlar</span><b>${stats().today}</b></div><strong>${stats().today?'Siyahını aç →':'Bu gün üçün gözləyən hesabat yoxdur'}</strong></div><div class="grid2"><div class="panel"><div class="panel-head"><div><h3>Son ${state.settings.notifyDays} gün içində olan hesabatlar</h3><p class="muted">Şirkətlər gizlədilib, eyni hesabat və dövr bir sətirdə göstərilir.</p></div><button class="link-btn" data-kpi="priority">Hamısını göstər</button></div>${priority.length?table(priority,true):empty('Son 10 gün içində hesabat yoxdur')}</div><div class="panel"><div class="panel-head"><h3>Bu gün üçün qalan hesabatlar</h3><button class="link-btn" data-kpi="today">Filtrlə</button></div>${today.length?table(today,true):empty('Bu gün üçün göndərilməmiş hesabat yoxdur')}</div></div>`;
}
function reports(){
  const rows=applyFilter(sorted(activeReports()),activeFilter);
  return kpis()+`<div class="panel"><div class="panel-head"><div><h3>Hesabat siyahısı</h3>${activeFilter?`<div class="filter-note">Aktiv filtr: <b>${filterLabel(activeFilter)}</b> <button id="clearFilter">Təmizlə</button></div>`:''}</div><div class="filters"><input id="search" placeholder="Şirkət, VÖEN və ya hesabat..."><select id="statusFilter"><option value="all">Bütün statuslar</option><option>Gözləyir</option><option>Göndərildi</option><option>Gecikib</option></select></div></div><div id="reportTable">${table(rows)}</div></div>`;
}
function table(rows,compact=false){
  const groups=groupRows(rows);
  return `<div class="table-wrap grouped-table"><table><thead><tr><th>Hesabat</th><th>Şirkət sayı</th><th>Hesabat dövrü</th><th>Son tarix</th><th>Vaxt</th><th>Təxmini cərimə</th><th>Status</th><th>Əməliyyatlar</th></tr></thead><tbody>${groups.map(g=>{
    const hot=!g.sent&&g.day>=0&&g.day<=state.settings.notifyDays;
    return `<tr><td class="${hot?'fire':''}">${hot?'🔥 ':''}${esc(g.taxType)}</td><td><button class="company-count-btn" data-company-group="${g.groupId}" title="Şirkətləri göstər">${g.members.length}</button></td><td>${esc(g.period)}</td><td>${g.dueDate}</td><td>${g.sent?'—':g.day===0?'<b class="today-text">Bu gün</b>':g.day>0?`${g.day} gün qalıb`:`${Math.abs(g.day)} gün gecikib`}</td><td><span class="fine-badge ${g.late?'fine-risk':''}">${groupFine(g)}</span></td><td><span class="badge ${g.sent?'sent':g.late?'late':'waiting'}">${g.sent?'Göndərildi':g.late?'Gecikib':'Gözləyir'}</span></td><td><div class="row-actions">${!g.sent?`<button class="small sent-btn" data-group-send="${g.groupId}">Göndərildi</button>`:''}<button class="small" data-group-mail="${g.groupId}">Mesaj</button><button class="small danger" data-group-del="${g.groupId}">Sil</button></div></td></tr>`
  }).join('')||`<tr><td colspan="8">${empty('Bu filtrə uyğun hesabat tapılmadı')}</td></tr>`}</tbody></table></div>`;
}
function bind(){
  $$('[data-company-group]').forEach(b=>b.onclick=e=>showCompaniesPopup(e,b.dataset.companyGroup));
  $$('[data-period-popup]').forEach(b=>b.onclick=e=>showPeriodPopup(e,b.dataset.periodPopup));
  $$('[data-kpi]').forEach(b=>b.onclick=()=>goFilter(b.dataset.kpi));
  $$('[data-type-filter]').forEach(b=>b.onclick=()=>goFilter('type',b.dataset.typeFilter));
  $$('[data-open-report]').forEach(b=>b.onclick=()=>{const r=state.reports.find(x=>x.id===b.dataset.openReport);goFilter('type',r.taxType)});
  $('#clearFilter')?.addEventListener('click',()=>{activeFilter=null;render()});
  $$('[data-group-send]').forEach(b=>b.onclick=async()=>{const g=groupCache[b.dataset.groupSend];if(!g)return;if(!confirm(`${g.taxType} üzrə ${g.members.length} şirkətin ${g.period} hesabatı göndərildi kimi işarələnsin?`))return;g.members.forEach(r=>{const key=g.occurrence?.key;if(key)setOccurrenceStatus(r,key,'Göndərildi')});await save();toast(`${g.members.length} şirkət üzrə status yeniləndi`);render()});
  $$('[data-group-del]').forEach(b=>b.onclick=async()=>{const g=groupCache[b.dataset.groupDel];if(!g)return;if(confirm(`${g.taxType} üzrə bu dövrə aid ${g.members.length} hesabat sətri silinsin?`)){const ids=new Set(g.members.map(r=>r.id));state.reports=state.reports.filter(r=>!ids.has(r.id));await save();render()}});
  $$('[data-group-mail]').forEach(b=>b.onclick=async()=>{const g=groupCache[b.dataset.groupMail];if(!g)return;let ok=0;for(const r of g.members){const res=await chrome.runtime.sendMessage({type:'send-report',report:{...r,period:g.period,dueDate:g.dueDate}});if(res?.message)ok++}toast(`${ok} şirkət üçün mesaj əmri göndərildi`)});
  $$('[data-send]').forEach(b=>b.onclick=async()=>{const r=state.reports.find(x=>x.id===b.dataset.send);const key=b.dataset.periodKey;if(key)setOccurrenceStatus(r,key,'Göndərildi');else occurrenceList(r).forEach(o=>setOccurrenceStatus(r,o.key,'Göndərildi'));await save();toast('Seçilən hesabat dövrü göndərildi kimi işarələndi');render()});
  $$('[data-del]').forEach(b=>b.onclick=async()=>{if(confirm('Bu hesabat silinsin?')){state.reports=state.reports.filter(x=>x.id!==b.dataset.del);await save();render()}});
  $$('[data-mail]').forEach(b=>b.onclick=async()=>{const r=state.reports.find(x=>x.id===b.dataset.mail);const res=await chrome.runtime.sendMessage({type:'send-report',report:r});toast(res.message)});
  $('#search')?.addEventListener('input',filterRows);$('#statusFilter')?.addEventListener('change',filterRows);
  $('#saveSettings')?.addEventListener('click',async()=>{state.settings={...state.settings,notifyDays:+$('#notifyDays').value,chromeEnabled:$('#chromeEnabled').checked,emailEnabled:$('#emailEnabled').checked,phoneEnabled:$('#phoneEnabled').checked,emailMode:'gmail',webhookUrl:$('#webhookUrl').value};await save();toast('Ayarlar saxlanıldı');render()});
  $$('[data-test-channel]').forEach(b=>b.onclick=async()=>{b.disabled=true;const res=await chrome.runtime.sendMessage({type:'test-channel',channel:b.dataset.testChannel});toast(res?.message||'Test tamamlanmadı');b.disabled=false});
  $('#runCheck')?.addEventListener('click',async()=>{const res=await chrome.runtime.sendMessage({type:'run-check'});toast(res?.message||`${res?.count||0} bildiriş göndərildi`)});$('#gmailConnect')?.addEventListener('click',async()=>{const type=state.gmailConnected?'gmail-disconnect':'gmail-connect';const res=await chrome.runtime.sendMessage({type});toast(res?.message||'Google əməliyyatı tamamlanmadı');state.gmailConnected=Boolean(res?.connected);render()});$('#oauthDiagnostic')?.addEventListener('click',async()=>{const res=await chrome.runtime.sendMessage({type:'oauth-diagnostic'});alert(`${res?.ok?'OAuth hazırdır':'OAuth problemi'}

${res?.message||'Nəticə alınmadı'}

Client ID: ${res?.clientId||'—'}`)});
  $('#addEmail')?.addEventListener('click',async()=>{const v=$('#newEmail').value.trim();if(v){state.emails.push({email:v,active:true});await save();render()}});$$('[data-email-toggle]').forEach(x=>x.onchange=async()=>{state.emails[+x.dataset.emailToggle].active=x.checked;await save()});$$('[data-email-edit]').forEach(x=>x.onchange=async()=>{state.emails[+x.dataset.emailEdit].email=x.value;await save()});$$('[data-email-del]').forEach(x=>x.onclick=async()=>{state.emails.splice(+x.dataset.emailDel,1);await save();render()});
  $('#addPhone')?.addEventListener('click',async()=>{const v=$('#newPhone').value.trim();if(v){state.phones.push({phone:v,active:true});await save();render()}});$$('[data-phone-toggle]').forEach(x=>x.onchange=async()=>{state.phones[+x.dataset.phoneToggle].active=x.checked;await save()});$$('[data-phone-edit]').forEach(x=>x.onchange=async()=>{state.phones[+x.dataset.phoneEdit].phone=x.value;await save()});$$('[data-phone-del]').forEach(x=>x.onclick=async()=>{state.phones.splice(+x.dataset.phoneDel,1);await save();render()});$('#addTax')?.addEventListener('click',()=>{$('#modal').classList.remove('hidden');$('#reportForm [name=taxType]').focus()});
}
function filterRows(){
  const q=($('#search').value||'').toLowerCase(),f=$('#statusFilter').value;let rows=applyFilter(sorted(activeReports()),activeFilter);
  rows=rows.filter(r=>`${r.company} ${r.voen} ${r.taxType} ${primaryOccurrence(r)?.label||''}`.toLowerCase().includes(q)&&(f==='all'||(f==='Gecikib'?days(r)<0:f==='Gözləyir'?days(r)>=0:statusOf(r)===f)));
  resetGroupCache();$('#reportTable').innerHTML=table(rows);bind();
}

/* v1.7: grouped period drill-down and per-company period status */
function periodStatusText(r,o){
  if(isOccurrenceSent(r,o.key)) return 'Göndərildi';
  const d=occDays(o); return d<0?'Gecikib':d===0?'Bu gün':'Gözləyir';
}
function periodTimeText(o){const d=occDays(o);return d<0?`${Math.abs(d)} gün gecikib`:d===0?'Bu gün son gündür':`${d} gün qalıb`}
function allGroupPeriods(g){
  const map=new Map();
  g.members.forEach(r=>occurrenceList(r).forEach(o=>{
    if(!map.has(o.key))map.set(o.key,{...o,reports:[],sentCount:0});
    const x=map.get(o.key);x.reports.push(r);if(isOccurrenceSent(r,o.key))x.sentCount++;
  }));
  return [...map.values()].sort((a,b)=>new Date(a.dueDate)-new Date(b.dueDate));
}
function positionPopup(pop,target){
  const rect=target.getBoundingClientRect();
  pop.style.left=Math.min(window.innerWidth-pop.offsetWidth-12,Math.max(12,rect.left+rect.width/2-pop.offsetWidth/2))+'px';
  pop.style.top=Math.min(window.innerHeight-pop.offsetHeight-12,rect.bottom+8)+'px';
}
function closeOnOutside(pop){
  setTimeout(()=>document.addEventListener('click',function close(e){if(!pop.contains(e.target)){pop.remove();document.removeEventListener('click',close)}}),0);
}
function showGroupPeriodsPopup(event,groupId){
  event.stopPropagation();document.querySelector('.period-popup')?.remove();const g=groupCache[groupId];if(!g)return;
  const sample=g.members[0],rule=parseRule(sample?.periodText||'');
  const unitTitle=rule.kind==='monthly'?'Aylar':rule.kind==='quarterly'?'Rüblər':rule.kind==='yearly'?'İllər':'Hesabat dövrləri';
  // Yalnız bütün şirkətlər üzrə göndərilməmiş qalan dövrləri göstəririk.
  const periods=allGroupPeriods(g).filter(p=>p.sentCount<p.reports.length);
  const pop=document.createElement('div');pop.className='period-popup group-period-popup simple-period-popup';
  pop.innerHTML=`<button class="period-popup-close">×</button><small>${unitTitle} və vaxt statusu</small><b>${esc(g.taxType)}</b><div class="period-items">${periods.map(p=>{const d=occDays(p);return `<div class="period-detail-row simple-period-row"><strong>${esc(p.label)}</strong><span class="${d<0?'period-late':'period-wait'}">${periodTimeText(p)}</span></div>`}).join('')||'<div class="period-detail-row"><strong>Göndərilməmiş dövr yoxdur</strong></div>'}</div>`;
  document.body.appendChild(pop);positionPopup(pop,event.currentTarget);pop.querySelector('.period-popup-close').onclick=()=>pop.remove();closeOnOutside(pop);
}
function showCompaniesPopup(event,groupId){
  event.stopPropagation();document.querySelector('.period-popup')?.remove();const g=groupCache[groupId];if(!g)return;
  const pop=document.createElement('div');pop.className='period-popup company-popup';
  pop.innerHTML=`<button class="period-popup-close">×</button><small>${esc(g.taxType)} · ${esc(g.period)}</small><b>${g.members.length} şirkət — şirkətin üzərinə vurun</b><div class="company-popup-list">${g.members.sort((a,b)=>a.company.localeCompare(b.company,'az')).map(r=>`<button class="company-drill-btn" data-company-detail="${r.id}" data-company-group-id="${groupId}"><span><strong>${esc(r.company)}</strong><small>${esc(r.voen)}</small></span><em>Detallar →</em></button>`).join('')}</div>`;
  document.body.appendChild(pop);positionPopup(pop,event.currentTarget);pop.querySelector('.period-popup-close').onclick=()=>pop.remove();
  pop.querySelectorAll('[data-company-detail]').forEach(btn=>btn.onclick=e=>showCompanyDetailsPopup(e,btn.dataset.companyDetail,btn.dataset.companyGroupId));closeOnOutside(pop);
}
function showCompanyDetailsPopup(event,reportId,groupId){
  event.stopPropagation();document.querySelector('.period-popup')?.remove();const r=state.reports.find(x=>x.id===reportId);const g=groupCache[groupId];if(!r)return;
  const periods=occurrenceList(r).sort((a,b)=>new Date(a.dueDate)-new Date(b.dueDate));const pop=document.createElement('div');pop.className='period-popup company-detail-popup';
  pop.innerHTML=`<button class="period-popup-close">×</button><small>${esc(r.taxType)} üzrə təyinatlar</small><b>${esc(r.company)}</b><div class="company-meta">VÖEN: ${esc(r.voen)}</div><div class="company-period-list">${periods.map(o=>{const st=periodStatusText(r,o);return `<div class="company-period-row"><div><strong>${esc(o.label)}</strong><small>Son tarix: ${o.dueDate}</small><span class="status-line ${st==='Göndərildi'?'ok':st==='Gecikib'?'bad':'wait'}">${st==='Göndərildi'?'Göndərilib':periodTimeText(o)}</span></div><select data-period-status-report="${r.id}" data-period-status-key="${o.key}"><option value="auto" ${st!=='Göndərildi'?'selected':''}>Göndərilməyib — ${st}</option><option value="sent" ${st==='Göndərildi'?'selected':''}>Göndərildi</option></select></div>`}).join('')}</div>`;
  document.body.appendChild(pop);positionPopup(pop,event.currentTarget);pop.querySelector('.period-popup-close').onclick=()=>pop.remove();
  pop.querySelectorAll('[data-period-status-report]').forEach(sel=>sel.onchange=async()=>{
    const rr=state.reports.find(x=>x.id===sel.dataset.periodStatusReport);const key=sel.dataset.periodStatusKey;if(!rr||!key)return;
    setOccurrenceStatus(rr,key,sel.value==='sent'?'Göndərildi':'Gözləyir');
    await save();toast(`${sel.closest('.company-period-row').querySelector('strong').textContent}: status yeniləndi`);
    // Pəncərəni bağlamadan yalnız seçilmiş sətri vizual olaraq yenilə.
    const row=sel.closest('.company-period-row'),occ=occurrenceList(rr).find(o=>o.key===key),st=periodStatusText(rr,occ);
    const line=row.querySelector('.status-line');line.className=`status-line ${st==='Göndərildi'?'ok':st==='Gecikib'?'bad':'wait'}`;line.textContent=st==='Göndərildi'?'Göndərilib':periodTimeText(occ);
    sel.querySelector('option[value=auto]').textContent=`Göndərilməyib — ${st==='Göndərildi'?'Gözləyir':st}`;
  });closeOnOutside(pop);
}
function table(rows,compact=false){
  const groups=groupRows(rows);
  return `<div class="table-wrap grouped-table"><table><thead><tr><th>Hesabat</th><th>Şirkət sayı</th><th>Hesabat dövrü</th><th>Son tarix</th><th>Vaxt</th><th>Təxmini cərimə</th><th>Status</th><th>Əməliyyatlar</th></tr></thead><tbody>${groups.map(g=>{const hot=!g.sent&&g.day>=0&&g.day<=state.settings.notifyDays;return `<tr><td class="${hot?'fire':''}">${hot?'🔥 ':''}${esc(g.taxType)}</td><td><button class="company-count-btn" data-company-group="${g.groupId}">${g.members.length}</button></td><td>${esc(g.period)}</td><td>${g.dueDate}</td><td>${g.sent?'—':`<button class="late-time-btn" data-group-periods="${g.groupId}">${g.day===0?'Bu gün':g.day>0?`${g.day} gün qalıb`:`${Math.abs(g.day)} gün gecikib`}</button>`}</td><td><span class="fine-badge ${g.late?'fine-risk':''}">${groupFine(g)}</span></td><td><span class="badge ${g.sent?'sent':g.late?'late':'waiting'}">${g.sent?'Göndərildi':g.late?'Gecikib':'Gözləyir'}</span></td><td><div class="row-actions">${!g.sent?`<button class="small sent-btn" data-group-send="${g.groupId}">Göndərildi</button>`:''}<button class="small" data-group-mail="${g.groupId}">Mesaj</button><button class="small danger" data-group-del="${g.groupId}">Sil</button></div></td></tr>`}).join('')||`<tr><td colspan="8">${empty('Bu filtrə uyğun hesabat tapılmadı')}</td></tr>`}</tbody></table></div>`;
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-group-periods]');if(b)showGroupPeriodsPopup(e,b.dataset.groupPeriods)});
