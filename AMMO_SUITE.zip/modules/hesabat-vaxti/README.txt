HESABAT VAXTI v2.8 — Gmail OAuth diaqnostika versiyası

1. Köhnə əlavəni silməyin; v2.7 qovluğundakı faylları bu paketlə əvəz edin və chrome://extensions səhifəsində Reload basın.
2. Faktiki Extension ID sabit qalmalıdır: lenencedhiadnagjlcahihflkejpfcdm
3. Google Cloud Chrome Extension OAuth Client-də Item ID həmin ID ilə tam eyni olmalıdır.
4. Chrome-un sağ yuxarı profil menyusunda Google hesabına daxil olun və Sync-i aktiv edin. Sadəcə gmail.com saytına daxil olmaq kifayət etmir.
5. İdarəetmə panelində “OAuth yoxla” düyməsinə basın. Bu düymə faktiki Extension ID-ni, Chrome profil hesabını və OAuth vəziyyətini göstərəcək.
6. Sonra “Google hesabını qoş” düyməsinə basıb Gmail göndərmə icazəsini təsdiqləyin.
7. Alıcı e-poçtu əlavə edin, Gmail kanalını aktiv edin və “Test et” basın.

Qeyd: Bu paket OAuth xətasını gizlətmir; dəqiq səbəbi ekranda göstərir. Gmail API və Google Cloud hesabı internet üzərindən olduğu üçün paket daxilində real giriş testini avtomatik aparmaq mümkün deyil.
