
// ===== BBEC MENFEET AVTO-DOLDURMA QAYDALARI =====
// OMV: 1607.1.2 Fiziki şəxslər üzrə -> 221.5.1.2
// OMV: 1607.1.1 Hüquqi şəxslər üzrə -> 221.5.1.1
// Vahid: 902 Gəlirlər, cəmi / Rüb üzrə orta say -> 221.1.2
// ƏDV: 301 Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan) -> 200.1
// Gələn qaimə: Q sütunu Cəmi qiyməti; mal cəmi -> 221.4; xidmət cəmi -> 221.15

function normText(s){
  return String(s || "")
    .replace(/\u00a0/g, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\r/g, "\n")
    .trim();
}
function parseAzNumber(raw){
  if(raw === undefined || raw === null) return 0;
  let s = String(raw).trim();
  if(!s) return 0;
  s = s.replace(/\u00a0/g, " ").replace(/\s/g, "");
  // keep only last decimal separator
  if(s.includes(",") && s.includes(".")){
    if(s.lastIndexOf(",") > s.lastIndexOf(".")) s = s.replace(/\./g, "").replace(",", ".");
    else s = s.replace(/,/g, "");
  } else if(s.includes(",")) {
    s = s.replace(",", ".");
  }
  s = s.replace(/[^\d.-]/g, "");
  return Number(s) || 0;
}
function fmtAz(n){ return Number(n || 0).toFixed(2).replace(".", ","); }
function addToCode(code, amount){
  values[code] = fmtAz(parseAzNumber(values[code]) + parseAzNumber(amount));
}
function setCode(code, amount){ values[code] = fmtAz(amount); }

async function fileToText(file){
  const lower = file.name.toLowerCase();
  if(lower.endsWith(".xlsx") || lower.endsWith(".xls") || lower.endsWith(".pdf")){
    // Best-effort: binary faylda görünən mətnləri çıxarır. Daha dəqiq nəticə üçün CSV/XML/HTML göndərmək məsləhətdir.
    const buf = await file.arrayBuffer();
    const bytes = new Uint8Array(buf);
    let out = "";
    for(let i=0;i<bytes.length;i++){
      const b = bytes[i];
      out += (b>=32 && b<=126) ? String.fromCharCode(b) : " ";
    }
    try { out += "\n" + new TextDecoder("utf-8", {fatal:false}).decode(buf); } catch(e){}
    return normText(out);
  }
  return normText(await file.text());
}

function findAfter(text, code, keywords=[]){
  const lines = text.split(/\n|(?=\b\d{3,4}(?:\.\d+)*\b)/).map(x=>x.trim()).filter(Boolean);
  const codeRe = new RegExp("(^|\\s)" + code.replaceAll(".", "\\.") + "(\\s|$)");
  let best = [];
  for(const ln of lines){
    const low = ln.toLowerCase();
    if(codeRe.test(ln) || keywords.some(k=>low.includes(k.toLowerCase()))){
      const nums = ln.match(/-?\d[\d\s.,]*\d|-?\d/g) || [];
      const parsed = nums.map(parseAzNumber).filter(n=>Math.abs(n)>0 && String(n).length <= 14);
      if(parsed.length) best.push(parsed[parsed.length-1]);
    }
  }
  return best.reduce((a,b)=>a+b,0);
}

function detectOmv(text){
  const huq = findAfter(text, "1607.1.1", ["1607.1.1", "hüquqi şəxslər", "huquqi sexsler"]);
  const fiz = findAfter(text, "1607.1.2", ["1607.1.2", "fiziki şəxslər", "fiziki sexsler"]);
  return {huq, fiz};
}
function detectVahid(text){
  // 902 Gəlirlər, cəmi / Rüb üzrə orta say
  return findAfter(text, "902", ["902", "gəlirlər, cəmi", "gelirler, cemi", "rüb üzrə orta say", "rub uzre orta say"]);
}
function detectEdv(text){
  return findAfter(text, "301", ["301", "təqdim edilmiş mal", "teqdim edilmis mal", "ədv nəzərə alınmadan", "edv nezere alinmadan"]);
}

function splitCsvLine(line){
  const sep = line.includes(";") ? ";" : (line.includes("\t") ? "\t" : ",");
  const out=[]; let cur=""; let q=false;
  for(let i=0;i<line.length;i++){
    const ch=line[i];
    if(ch === '"'){ q = !q; continue; }
    if(ch === sep && !q){ out.push(cur); cur=""; continue; }
    cur += ch;
  }
  out.push(cur);
  return out.map(x=>x.trim());
}
function detectQaime(text){
  const lines = text.split(/\n/).map(x=>x.trim()).filter(Boolean);
  let mal=0, xidmet=0;
  for(const line of lines){
    const low = line.toLowerCase();
    if(!low) continue;
    let cells = splitCsvLine(line);
    // Q column = index 16. If not enough columns, use last numeric value in row.
    let amount = 0;
    if(cells.length > 16) amount = parseAzNumber(cells[16]);
    if(!amount){
      const nums = line.match(/-?\d[\d\s.,]*\d|-?\d/g) || [];
      amount = parseAzNumber(nums[nums.length-1]);
    }
    if(!amount) continue;
    const isService = low.includes("xidmət") || low.includes("xidmet") || low.includes("service") || low.includes("iş") || low.includes("is ");
    const isGoods = low.includes("mal") || low.includes("məhsul") || low.includes("mehsul") || low.includes("goods") || low.includes("material");
    if(isService && !isGoods) xidmet += amount;
    else mal += amount;
  }
  return {mal, xidmet};
}

async function readFiles(inputId){
  const inp = document.getElementById(inputId);
  const files = Array.from(inp?.files || []);
  const texts = [];
  for(const f of files){
    texts.push({name:f.name, text: await fileToText(f)});
  }
  return texts;
}

async function autoFillFromFiles(){
  let log = [];
  let omvHuq=0, omvFiz=0, vahid=0, edv=0, mal=0, xidmet=0;

  for(const file of Array.from(document.getElementById("omvFiles")?.files || [])){
    const data = await fileToSmartData(file);
    const r = detectOmvSmart(data);
    omvHuq += r.huq; omvFiz += r.fiz;
    log.push(`OMV: ${file.name} → 1607.1.1=${fmtAz(r.huq)}, 1607.1.2=${fmtAz(r.fiz)}`);
  }
  for(const file of Array.from(document.getElementById("vahidFiles")?.files || [])){
    const data = await fileToSmartData(file);
    const r = detectVahidSmart(data);
    vahid += r;
    log.push(`VAHİD: ${file.name} → 902=${fmtAz(r)}`);
  }
  for(const file of Array.from(document.getElementById("edvFiles")?.files || [])){
    const data = await fileToSmartData(file);
    const r = detectEdvSmart(data);
    edv += r;
    log.push(`ƏDV: ${file.name} → 301 sütununun CƏMİ=${fmtAz(r)}`);
  }
  for(const file of Array.from(document.getElementById("qaimeFiles")?.files || [])){
    const data = await fileToSmartData(file);
    const r = detectQaimeSmart(data);
    mal += r.mal; xidmet += r.xidmet;
    log.push(`QAİMƏ: ${file.name} → mal=${fmtAz(r.mal)}, xidmət=${fmtAz(r.xidmet)}`);
  }

  if(omvHuq) setCode("221.5.1.1", omvHuq);
  if(omvFiz) setCode("221.5.1.2", omvFiz);
  if(vahid) setCode("221.1.2", vahid);
  if(edv) setCode("200.1", edv);
  if(mal) setCode("221.4", mal);
  if(xidmet) setCode("221.15", xidmet);

  log.push("");
  log.push("YAZILAN XANALAR:");
  log.push(`221.5.1.1 Hüquqi şəxslər üzrə = ${values["221.5.1.1"] || "0,00"}`);
  log.push(`221.5.1.2 Fiziki şəxslər üzrə = ${values["221.5.1.2"] || "0,00"}`);
  log.push(`221.1.2 Yerli işçilər üzrə = ${values["221.1.2"] || "0,00"}`);
  log.push(`200.1 Malların təqdim edilməsindən gəlir = ${values["200.1"] || "0,00"}`);
  log.push(`221.4 Malın dəyəri = ${values["221.4"] || "0,00"}`);
  log.push(`221.15 Bilavasitə malların təqdim edilməsi ilə bağlı sair xərclər = ${values["221.15"] || "0,00"}`);

  build(); apply(); show(current);
  const box = document.getElementById("autoResult");
  if(box){ box.style.display="block"; box.textContent = log.join("\\n"); }
}

function showAutoMap(){
  const txt = `QAYDA:
OMV 1–4 rüb:
  1607.1.1 Hüquqi şəxslər üzrə → Mənfəət 221.5.1.1
  1607.1.2 Fiziki şəxslər üzrə → Mənfəət 221.5.1.2

VAHİD 1–4 rüb:
  902 Gəlirlər, cəmi / Rüb üzrə orta say → Mənfəət 221.1.2

ƏDV 12 ay:
  301 Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan) → Mənfəət 200.1

GƏLƏN QAİMƏ:
  Q sütunu Cəmi qiyməti:
    Mal olan sətirlərin cəmi → Mənfəət 221.4
    Xidmət olan sətirlərin cəmi → Mənfəət 221.15`;
  const box = document.getElementById("autoResult");
  if(box){ box.style.display="block"; box.textContent = txt; }
}


let current=0;const values={},meta={},grid={};
const totalCodes=["218","220","234","236","237","239","241","243","245","A5.4","1","2"];
function parseN(v){return Number(String(v||"").replace(/\s/g,"").replace(",",".").replace(/[^\d.-]/g,""))||0}
function fmt(v){return parseN(v).toFixed(2).replace(".",",")}
function isTotal(c){return totalCodes.includes(c)}
function buildNav(){nav.innerHTML=SECTIONS.map((s,i)=>`<button class="nav ${i===0?'active':''}" data-i="${i}"><span class="num">${s.no}</span><span>${s.title}</span></button>`).join("");document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>show(+b.dataset.i))}
function build(){let h="";SECTIONS.forEach((s,i)=>{h+=`<section class="section ${i===0?'active':''}" id="${s.key}"><h3>${s.title}</h3>`;if(s.kind==="form"){h+=`<div class="formGrid">`;s.fields.forEach(([id,l,d])=>h+=`<label>${l}</label><input data-meta="${id}" value="${meta[id]??d??''}">`);h+=`</div>`}if(s.kind==="table"){h+=`<div class="table"><div class="row header"><div class="code">Göstərici</div><div class="label">Açıqlama</div><div class="amount">Məbləğ, manatla</div></div>`;s.rows.forEach(([c,l])=>h+=`<div class="row ${isTotal(c)?'total':''}"><div class="code">${c}</div><div class="label">${l}</div><div class="amount"><input data-code="${c}" value="${values[c]||'0,00'}"></div></div>`);h+=`</div>`}if(s.kind==="multi"){h+=`<div class="multiWrap"><table class="multi"><thead><tr><th>Kod</th><th>Göstəricilər</th>`;s.columns.forEach(c=>h+=`<th>${c}</th>`);h+=`</tr></thead><tbody>`;s.rows.forEach(([c,l])=>{
if(s.key==="appendix1" && c==="2"){
  h+=`<tr class="repeatHead"><th>Göstəricilər</th><th></th>`;
  s.columns.forEach(col=>h+=`<th>${col}</th>`);
  h+=`</tr>`;
}
h+=`<tr class="${(s.key==="appendix1" && (c==="1" || c==="2")) ? "groupRow" : ""}"><td class="code">${c}</td><td>${l}</td>`;
s.columns.forEach((_,ci)=>{let k=`${s.key}_${c}_${ci}`;h+=`<td><input data-gridcell="${k}" value="${grid[k]||'0,00'}"></td>`});
h+=`</tr>`});h+=`</tbody></table></div>`}if(s.kind==="grid"){let rows=grid[s.key]?.length?grid[s.key]:Array.from({length:s.rows_count},()=>({}));h+=`<button class="addRow" data-add="${s.key}">+ Sətir əlavə et</button><div class="multiWrap"><table class="multi"><thead><tr><th>№</th>`;s.columns.forEach(c=>h+=`<th>${c}</th>`);h+=`</tr></thead><tbody>`;rows.forEach((r,ri)=>{h+=`<tr><td>${ri+1}</td>`;s.columns.forEach((_,ci)=>h+=`<td class="text"><input data-grid="${s.key}" data-r="${ri}" data-c="${ci}" value="${r[ci]||''}"></td>`);h+=`</tr>`});h+=`</tbody></table></div>`}h+=`</section>`});sections.innerHTML=h;document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>{collect();(grid[b.dataset.add]??=[]).push({});build();apply();show(current)})}
function show(i){current=i;document.querySelectorAll(".section").forEach(s=>s.classList.remove("active"));document.querySelectorAll(".nav").forEach(s=>s.classList.remove("active"));document.getElementById(SECTIONS[i].key).classList.add("active");document.querySelectorAll(".nav")[i].classList.add("active");title.textContent=SECTIONS[i].title}
function collect(){document.querySelectorAll("[data-code]").forEach(x=>values[x.dataset.code]=x.value);document.querySelectorAll("[data-meta]").forEach(x=>meta[x.dataset.meta]=x.value);document.querySelectorAll("[data-gridcell]").forEach(x=>grid[x.dataset.gridcell]=x.value);document.querySelectorAll("[data-grid]").forEach(x=>{let k=x.dataset.grid,r=+x.dataset.r,c=+x.dataset.c;(grid[k]??=[]);(grid[k][r]??={});grid[k][r][c]=x.value})}
function apply(){document.querySelectorAll("[data-code]").forEach(x=>x.value=values[x.dataset.code]||'0,00');document.querySelectorAll("[data-meta]").forEach(x=>{if(meta[x.dataset.meta]!==undefined)x.value=meta[x.dataset.meta]});document.querySelectorAll("[data-gridcell]").forEach(x=>x.value=grid[x.dataset.gridcell]||'0,00')}
function calc(){collect();let inc=["200.1.1","200.1.2","200.2","201","202","203","204","205","206","207","208","209","210","211","212","213","214","215","216","217"].reduce((s,c)=>s+parseN(values[c]),0);if(inc){values["218"]=fmt(inc);values["220"]=fmt(inc-parseN(values["219"]))}let exp=["221","222","223","224","225","226","227","228","229","230","231","232","233"].reduce((s,c)=>s+parseN(values[c]),0);if(exp){values["234"]=fmt(exp);values["236"]=fmt(exp-parseN(values["235"]))}let profit=parseN(values["220"])-parseN(values["236"]);values["237"]=fmt(Math.max(0,profit));values["239"]=fmt(Math.max(0,-profit));values["241"]=fmt(Math.max(0,parseN(values["237"])-parseN(values["238"])-parseN(values["240"])));if(!parseN(values["242"]))values["242"]="20,00";values["243"]=fmt(parseN(values["241"])*parseN(values["242"])/100);values["245"]=fmt(Math.max(0,parseN(values["243"])-parseN(values["244"])));build();apply();show(current)}
document.addEventListener("input",e=>{if(e.target.matches("[data-code],[data-gridcell]"))setTimeout(calc,0)});prevBtn.onclick=()=>{if(current>0)show(current-1)};nextBtn.onclick=()=>{if(current<SECTIONS.length-1)show(current+1)};backBtn.onclick=()=>history.back();clearBtn.onclick=()=>{if(confirm("Təmizlənsin?")){Object.keys(values).forEach(k=>delete values[k]);Object.keys(grid).forEach(k=>delete grid[k]);build();show(current)}};saveBtn.onclick=()=>{collect();chrome.storage.local.set({menfeetHtmlFull:{values,meta,grid,current}},()=>alert("Qaralamada saxlanıldı."))};exportBtn.onclick=()=>{collect();let blob=new Blob([JSON.stringify({values,meta,grid,exportedAt:new Date().toISOString()},null,2)],{type:"application/json"});chrome.downloads.download({url:URL.createObjectURL(blob),filename:"menfeet_beyanname_full.json",saveAs:true})};printBtn.onclick=()=>window.print();fillBtn.onclick=()=>{let f=jsonFile.files[0];if(!f){alert("JSON seçilməyib");return}let r=new FileReader();r.onload=()=>{let d=JSON.parse(r.result);Object.assign(values,d.values||{});Object.assign(meta,d.meta||{});Object.assign(grid,d.grid||{});build();apply();show(current)};r.readAsText(f)};buildNav();build();chrome.storage.local.get(["menfeetHtmlFull"],res=>{if(res.menfeetHtmlFull){Object.assign(values,res.menfeetHtmlFull.values||{});Object.assign(meta,res.menfeetHtmlFull.meta||{});Object.assign(grid,res.menfeetHtmlFull.grid||{});current=res.menfeetHtmlFull.current||0;build();apply();show(current)}})

setTimeout(()=>{
  const autoBtn = document.getElementById("autoFillBtn");
  const mapBtn = document.getElementById("showMapBtn");
  if(autoBtn) autoBtn.onclick = async()=>{try{await autoFillFromFiles()}catch(e){const box=document.getElementById('autoResult'); if(box){box.style.display='block'; box.textContent='XƏTA: '+e.message+'\n\nƏgər fayl XLSX-dirsə, Chrome-un yenilənmiş versiyasından istifadə et.'}}};
  if(mapBtn) mapBtn.onclick = showAutoMap;
}, 300);


/*
BBEC 2.20 DÜZƏLİŞ MƏNTİQİ

VAHİD BƏYANNAMƏ:
902 Gəlirlər, cəmi -> "Rüb üzrə orta say"
1+2+3+4 rüb cəmi -> 221.1.2

OMV:
1607.1.1 Hüquqi şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.1

1607.1.2 Fiziki şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.2
*/
