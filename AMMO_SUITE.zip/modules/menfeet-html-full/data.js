const SECTIONS = [
  {
    "key": "general",
    "no": "1",
    "title": "Bölmə 1. Vergi ödəyicisi haqqında ümumi məlumat",
    "kind": "form",
    "fields": [
      [
        "taxOffice",
        "Bəyannamənin təqdim edildiyi vergi orqanının adı",
        ""
      ],
      [
        "period",
        "Vergi dövrü",
        "2025"
      ],
      [
        "voen",
        "VÖEN",
        ""
      ],
      [
        "taxpayerName",
        "Vergi ödəyicisinin tam adı",
        ""
      ],
      [
        "phone",
        "Telefonu",
        ""
      ],
      [
        "activityCode",
        "Əsas fəaliyyət növünün kodu",
        ""
      ],
      [
        "activityName",
        "Əsas fəaliyyət növünün adı",
        ""
      ],
      [
        "presentationType",
        "Təqdim olunmuş əlavələrin sayı",
        ""
      ],
      [
        "declarationType",
        "Bəyannamənin növü",
        "Dəqiqləşdirilmiş"
      ],
      [
        "taxpayerCategory",
        "Vergi ödəyicisinin qrupu",
        ""
      ],
      [
        "taxpayerCriterion",
        "Sahibkarlıq subyektinin meyarı",
        ""
      ],
      [
        "accountingMethod",
        "Uçot metodu",
        ""
      ]
    ]
  },
  {
    "key": "income",
    "no": "2",
    "title": "Bölmə 2. Verginin hesablanması — Hesabat dövrünün GƏLİRLƏRİ",
    "kind": "table",
    "rows": [
      [
        "200",
        "Malların təqdim edilməsindən (işlərin görülməsindən, xidmətlərin göstərilməsindən) gəlir"
      ],
      [
        "200.1",
        "Malların təqdim edilməsindən gəlir"
      ],
      [
        "200.1.1",
        "Pərakəndə satışdan gəlir"
      ],
      [
        "200.1.1.1",
        "O cümlədən elektron ticarətdən"
      ],
      [
        "200.1.2",
        "Topdan satışdan gəlir"
      ],
      [
        "200.1.2.1",
        "O cümlədən elektron ticarətdən"
      ],
      [
        "200.2",
        "İşlərin görülməsindən və xidmətlərin göstərilməsindən gəlir"
      ],
      [
        "200.2.1",
        "Sığorta fəaliyyətindən gəlirlər"
      ],
      [
        "200.2.1.1",
        "Sığorta ehtiyatlarının qaytarılması üzrə"
      ],
      [
        "200.2.2",
        "İctimai iaşə fəaliyyətindən gəlirlər"
      ],
      [
        "200.2.3",
        "Elektron xidmətdən"
      ],
      [
        "201",
        "Amortizasiya olunan əsas vəsaitlərin təqdim edilməsindən gəlir"
      ],
      [
        "202",
        "Amortizasiya olunmayan aktivlərin təqdim edilməsindən gəlir"
      ],
      [
        "203",
        "Əmlakın icarəyə verilməsindən gəlir"
      ],
      [
        "203.1",
        "Daşınan əmlakın icarəyə verilməsindən gəlir"
      ],
      [
        "203.2",
        "Daşınmaz əmlakın icarəyə verilməsindən gəlir"
      ],
      [
        "204",
        "Digər müəssisələrin fəaliyyətindən payçı kimi iştirakdan əldə edilmiş gəlir (dividend istisna olmaqla)"
      ],
      [
        "204.1",
        "50%-dən çox səs hüququ verən səhmi olan müəssisələrdə iştirakdan gəlir"
      ],
      [
        "204.2",
        "50 faizədək səs hüququ verən səhmi olan müəssisələrdə iştirakdan gəlir"
      ],
      [
        "205",
        "İştirak faizinə görə birgə fəaliyyətdən əldə edilmiş gəlir"
      ],
      [
        "205.1",
        "Birgə fəaliyyət üzrə ümumi gəlir"
      ],
      [
        "205.2",
        "İştirak faizi"
      ],
      [
        "206",
        "Əvəzsiz əsasla təqdim edilmiş aktivlərin dəyəri"
      ],
      [
        "207",
        "Səhmlər, iştirak payları və digər qiymətli kağızların, borc öhdəliklərinin və tələblərin satışından əldə edilmiş gəlirlər"
      ],
      [
        "207.1",
        "Səhmlərin və iştirak paylarının satışından əldə edilmiş gəlir"
      ],
      [
        "207.1.1",
        "Nizamnamə kapitalındakı səhmlər və iştirak payları alış aktivlərinin nominal/faktiki satış qiyməti"
      ],
      [
        "207.1.1.1",
        "Təqdim edilən səhmlərin və iştirak paylarının nominal və ya faktiki satılma qiyməti"
      ],
      [
        "207.1.1.2",
        "Təqdim edilən səhmlər və iştirak payları üzrə alış aktivlərinə faktiki təqdim olunma dəyəri"
      ],
      [
        "207.1.1.3",
        "Təqdim edilən səhmlərin və iştirak paylarının faktiki təqdim olunma dəyəri"
      ],
      [
        "207.1.2",
        "Nizamnamə kapitalındakı səhmlər və iştirak payları alış aktivlərinin güzəştli qiymətlə təqdim edilməsindən gəlir"
      ],
      [
        "207.1.2.1",
        "Təqdim edilən səhmlərin və iştirak paylarının nominal və ya faktiki satılma qiyməti"
      ],
      [
        "207.1.2.2",
        "Təqdim edilən səhmlər və iştirak payları üzrə alış aktivlərinə faktiki təqdim olunma dəyəri"
      ],
      [
        "207.1.2.3",
        "Təqdim edilən səhmlərin və iştirak paylarının faktiki təqdim olunma dəyəri"
      ],
      [
        "207.2",
        "İstiqrazların satışından əldə edilmiş gəlir"
      ],
      [
        "207.3",
        "Digər qiymətli kağızların satışından əldə edilmiş gəlir"
      ],
      [
        "207.4",
        "Borc öhdəliklərinin satışından əldə edilmiş gəlir"
      ],
      [
        "207.5",
        "Borc tələblərinin satışından əldə edilmiş gəlir"
      ],
      [
        "208",
        "İddia müddəti ötmüş və kreditorlar tərəfindən silinmiş kreditor borclar üzrə gəlir"
      ],
      [
        "209",
        "Uduşlar"
      ],
      [
        "210",
        "Royalti"
      ],
      [
        "210.1",
        "Azərbaycan Respublikasının hüdudlarından kənarda əldə edilmiş royaltidən gəlir"
      ],
      [
        "211",
        "Dividendlər"
      ],
      [
        "211.1",
        "Azərbaycan Respublikasında alınmış dividendlər"
      ],
      [
        "211.2",
        "Azərbaycan Respublikasının hüdudlarından kənarda alınmış dividendlər"
      ],
      [
        "212",
        "Faizlər"
      ],
      [
        "212.1",
        "Bank fəaliyyətindən faizlər"
      ],
      [
        "212.2",
        "Digər faiz gəlirləri"
      ],
      [
        "213",
        "Əvvəllər gəlirdən çıxılmış ehtiyatın azaldılmasından gəlir"
      ],
      [
        "214",
        "Xarici valyutaların manat nisbətən məzənnə fərqindən müsbət məzənnə fərqi"
      ],
      [
        "215",
        "Əvvəllər gəlirdən çıxılmış ərzində zərərin və ya ümidsiz borcun ödənilməsindən gəlir"
      ],
      [
        "216",
        "Vergilərin uçotu metodunun dəyişilməsi nəticəsində yaranan keçmiş illərin gəliri"
      ],
      [
        "217",
        "Yuxarıdakı bəndlərdə nəzərdə tutulmayan digər gəlirlər"
      ],
      [
        "217.1",
        "İxrac məqsədli neft-qaz fəaliyyəti üzrə alınmış gəlirlər"
      ],
      [
        "217.2",
        "Azərbaycan Respublikasının hüdudlarından kənarda əldə edilmiş gəlirlər"
      ],
      [
        "217.3",
        "Transfer qiymətləri tətbiq edilməsindən əldə edilmiş gəlirlər"
      ],
      [
        "217.4",
        "Azərbaycan Respublikası rezidenti hesab edilən şəxsin nəzarət olunan xarici müəssisədən əldə etdiyi gəlir"
      ],
      [
        "217.5",
        "Tibb müəssisələri tərəfindən dövlət büdcəsinə ƏDV hesablanarkən azaldılmış ƏDV məbləğinin azaldılmasından əldə edilən gəlirlər"
      ],
      [
        "218",
        "CƏMİ GƏLİRLƏR"
      ],
      [
        "219",
        "Ümumi gəlirdən çıxılmalar"
      ],
      [
        "219.1",
        "Rezident tərəfindən ödəmə mənbəyində vergiyə cəlb olunan dividend gəlirləri"
      ],
      [
        "219.2",
        "Təqdim olunmuş aktivlərin çıxılmış dəyəri"
      ],
      [
        "219.3",
        "Xarici valyutaların manat nisbətən məzənnəsinin dəyişməsindən yaranan mənfi fərq"
      ],
      [
        "219.4",
        "Gəlirlər üzrə azadolmalar və güzəştlər"
      ],
      [
        "219.5",
        "Bina tikintisi fəaliyyəti üzrə güzəşt tətbiq edilən gəlir"
      ],
      [
        "219.6",
        "Dəqiqləşdirilmiş əməliyyatlar hesabına azaldılan gəlir"
      ],
      [
        "219.7",
        "Vəkil qurumların tərkibində fəaliyyət göstərən vəkillərlə bağlı gəlirdən çıxılan məbləğlər"
      ],
      [
        "220",
        "Çıxılmalardan sonra CƏMİ GƏLİR"
      ]
    ]
  },
  {
    "key": "expenses",
    "no": "3",
    "title": "Hesabat dövründə gəlirlərin əldə edilməsi ilə bağlı XƏRCLƏR",
    "kind": "table",
    "rows": [
      [
        "221",
        "Malların təqdim edilməsi, iş görülməsi və xidmət göstərilməsi üzrə xərclər"
      ],
      [
        "221.1",
        "Əmək haqqı və ona bərabər tutulan ödəmələr"
      ],
      [
        "221.1.1",
        "Əcnəbi işçilər üzrə"
      ],
      [
        "221.1.2",
        "Yerli işçilər üzrə"
      ],
      [
        "221.2",
        "Sosial sığorta haqları"
      ],
      [
        "221.3",
        "Xammal və materiallar"
      ],
      [
        "221.4",
        "Malın dəyəri"
      ],
      [
        "221.5",
        "İcarə haqqı"
      ],
      [
        "221.5.1",
        "Rezident şəxslər üzrə icarə haqqı"
      ],
      [
        "221.5.1.1",
        "Hüquqi şəxslər üzrə"
      ],
      [
        "221.5.1.2",
        "Fiziki şəxslər üzrə"
      ],
      [
        "221.5.2",
        "Qeyri-rezidentlər üzrə icarə haqqı"
      ],
      [
        "221.6",
        "Nazirlər Kabinetinin qərarı ilə müəyyən edilmiş ezamiyyə xərclərinin məbləğləri"
      ],
      [
        "221.7",
        "Enerji xərcləri"
      ],
      [
        "221.8",
        "Qaz xərcləri"
      ],
      [
        "221.9",
        "Yanacaq xərcləri"
      ],
      [
        "221.10",
        "Su və kanalizasiya xərcləri"
      ],
      [
        "221.11",
        "Rabitə xərcləri"
      ],
      [
        "221.12",
        "Mühafizə xərcləri"
      ],
      [
        "221.13",
        "Bank xidməti üzrə xərclər"
      ],
      [
        "221.14",
        "Reklam xərcləri"
      ],
      [
        "221.15",
        "Bilavasitə malların təqdim edilməsi ilə bağlı sair xərclər"
      ],
      [
        "221.16",
        "Qanunvericiliklə müəyyən edilmiş təbii itki normaları daxilində xammal, material və itkilər"
      ],
      [
        "221.17",
        "VM-nin 119.2-ci maddəsinə əsasən qanunvericiliklə müəyyən edilmiş normalar daxilində çəkilən xərclər"
      ],
      [
        "222",
        "Borclara görə faizlər və onlarla bağlı olan xərclər"
      ],
      [
        "222.1",
        "Rezident üzrə faizlər"
      ],
      [
        "222.2",
        "Faizlərlə bağlı digər xərclər"
      ],
      [
        "222.3",
        "Qeyri-rezident üzrə faizlər"
      ],
      [
        "223",
        "Royalti"
      ],
      [
        "223.1",
        "Rezident üzrə royalti"
      ],
      [
        "223.2",
        "Qeyri-rezident üzrə royalti"
      ],
      [
        "224",
        "Xarici hüquqi şəxsin baş ofisi tərəfindən çəkilmiş və Azərbaycan Respublikası ilə bağlı olan xərclər"
      ],
      [
        "225",
        "Ümidsiz borclar"
      ],
      [
        "226",
        "Elmi tədqiqat, layihə axtarış və təcrübə-konstruktor işlərinə çəkilən xərclər"
      ],
      [
        "227",
        "Amortizasiya ayırmaları"
      ],
      [
        "227.1",
        "Torpaqların yaxşılaşdırılması üzrə kapitallaşdırılmış xərclər, binalar, tikililər və qurğular üzrə amortizasiya"
      ],
      [
        "227.2",
        "Maşınlar və avadanlıqlar üzrə amortizasiya"
      ],
      [
        "227.3",
        "Nəqliyyat vasitələri üzrə amortizasiya"
      ],
      [
        "227.4",
        "İş heyvanları üzrə amortizasiya"
      ],
      [
        "227.5",
        "Geoloji kəşfiyyat işləri və təbii ehtiyatların hasilatına hazırlıq xərcləri üzrə amortizasiya"
      ],
      [
        "227.6",
        "İstifadə müddəti məlum olmayan qeyri-maddi aktivlər üzrə amortizasiya"
      ],
      [
        "227.7",
        "Digər əsas vəsaitlər üzrə amortizasiya"
      ],
      [
        "227.8",
        "VM-nin 114.6-cı maddəsinə əsasən hesablanan amortizasiya"
      ],
      [
        "227.9",
        "Təqdim edilmiş əsas vəsaitlərin qalıq dəyəri"
      ],
      [
        "227.10",
        "Yüksək texnologiyalar məhsulu olan hesablama texnikası üzrə amortizasiya"
      ],
      [
        "228",
        "Təmir xərcləri"
      ],
      [
        "228.1",
        "Binalar, tikililər və qurğular üzrə təmir xərcləri"
      ],
      [
        "228.2",
        "Maşınlar və avadanlıqlar üzrə təmir xərcləri"
      ],
      [
        "228.3",
        "Digər əsas vəsaitlər üzrə təmir xərcləri"
      ],
      [
        "228.4",
        "İcarəyə götürülmüş əsas vəsaitlərin təmir xərcləri"
      ],
      [
        "228.5",
        "Yüksək texnologiyalar məhsulu olan hesablama texnikası üzrə təmir xərcləri"
      ],
      [
        "228.6",
        "Yük avtomobillərinin təmir xərcləri"
      ],
      [
        "229",
        "Nəqliyyat xərcləri"
      ],
      [
        "229.1",
        "Rezident üzrə nəqliyyat xərcləri"
      ],
      [
        "229.2",
        "Qeyri-rezident üzrə nəqliyyat xərcləri"
      ],
      [
        "230",
        "Sığorta üzrə xərclər"
      ],
      [
        "230.1",
        "Sığorta fəaliyyəti üzrə xərclər"
      ],
      [
        "230.1.1",
        "Sığorta ehtiyatlarına ayırmalar"
      ],
      [
        "230.1.2",
        "Təkrarsığortaya verilmiş sığorta haqları"
      ],
      [
        "230.1.3",
        "Sığorta fəaliyyəti üzrə sair xərclər"
      ],
      [
        "230.2",
        "Ödənilmiş sığorta haqları"
      ],
      [
        "231",
        "İstiqrazların, digər qiymətli kağızların, borc öhdəliklərinin və tələblərinin, iştirak payı və səhmlərin alınması ilə bağlı xərclər"
      ],
      [
        "231.1",
        "İstiqrazların alınması ilə bağlı xərclər"
      ],
      [
        "231.2",
        "Digər qiymətli kağızların alınması ilə bağlı xərclər"
      ],
      [
        "231.3",
        "Borc öhdəliklərinin alınması ilə bağlı xərclər"
      ],
      [
        "231.4",
        "Borc tələblərinin alınması ilə bağlı xərclər"
      ],
      [
        "231.5",
        "İştirak payı və səhmlərin alınması ilə bağlı digər xərclər"
      ],
      [
        "232",
        "Digər xərclər"
      ],
      [
        "232.1",
        "Azərbaycan Respublikasının hüdudlarından kənarda gəlirlərin əldə edilməsi ilə bağlı xərclər"
      ],
      [
        "232.2",
        "Özəl metodun dəyişilməsi nəticəsində yaranan keçmiş illərin xərci"
      ],
      [
        "232.3",
        "İştirak faizinə görə birgə fəaliyyətdən xərc"
      ],
      [
        "232.4",
        "Birgə fəaliyyət üzrə ümumi xərc"
      ],
      [
        "232.5",
        "İştirak faizi"
      ],
      [
        "232.6",
        "VM-nin 109.8-ci maddəsinə əsasən xərclər"
      ],
      [
        "233",
        "Gəlirdən çıxılan vergilər və rüsumlar"
      ],
      [
        "233.1",
        "Torpaq vergisi"
      ],
      [
        "233.2",
        "Əmlak vergisi"
      ],
      [
        "233.3",
        "Mədən vergisi"
      ],
      [
        "233.4",
        "İxrac məhsullarının kontrakt qiyməti ilə satış qiyməti arasındakı fərqdən hesablanan yığım"
      ],
      [
        "233.5",
        "Vergi Məcəlləsinin 220.12-ci maddəsi üzrə yığımlar"
      ],
      [
        "234",
        "CƏMİ XƏRCLƏR"
      ],
      [
        "235",
        "Ümumi gəlirdən çıxılmayan xərclər"
      ],
      [
        "235.1",
        "Vergidən azad olunan və ya vergiyə cəlb edilməyən fəaliyyətlə bağlı bölüşdürülməsi mümkün olmayan xərclərin cəmi"
      ],
      [
        "235.1.1",
        "Vergiyə cəlb edilməyən fəaliyyətlə bağlı xərclərin cəmi"
      ],
      [
        "235.1.2",
        "Transfer qiymətlərinin tətbiqi nəticəsində azaldılan xərclər"
      ],
      [
        "235.2",
        "Dağıdılmış əməliyyatlar hesabına azaldılan xərc"
      ],
      [
        "236",
        "Ümumi gəlirlərdən çıxılan xərclər"
      ]
    ]
  },
  {
    "key": "tax",
    "no": "4",
    "title": "Hesabat dövrü üçün verginin hesablanması",
    "kind": "table",
    "rows": [
      [
        "237",
        "Vergitutma məqsədləri üçün mənfəət (sət.220 - sət.236)"
      ],
      [
        "238",
        "Mənfəət üzrə azadolmalar və güzəştlər"
      ],
      [
        "239",
        "Zərər (sət.236 - sət.220)"
      ],
      [
        "240",
        "Mənfəət hesabına kompensasiya edilən keçmiş illərin zərəri"
      ],
      [
        "241",
        "Mənfəət üzrə azadolma, güzəşt və keçmiş zərər çıxılmaqla vergiyə cəlb olunan mənfəət"
      ],
      [
        "242",
        "Mənfəət vergisinin dərəcəsi"
      ],
      [
        "243",
        "Mənfəət vergisi (sət.241 x sət.242 / 100)"
      ],
      [
        "244",
        "Azaldılmalı verginin məbləği"
      ],
      [
        "244.1",
        "VM-nin 106.2-ci maddəsinə əsasən azaldılmalı verginin məbləği"
      ],
      [
        "244.2",
        "Xarici ölkələrdə ödənilmiş və nəzərə alınan mənfəət vergisinin məbləği"
      ],
      [
        "244.2.1",
        "O cümlədən nəzarət olunan xarici müəssisədə əldə edilən mənfəət üzrə həmin ölkələrdə və ya ərazilərdə ödənilmiş və nəzərə alınan mənfəət vergisinin məbləği"
      ],
      [
        "244.3",
        "VM-nin 227.1-ci maddəsinə əsasən azaldılmalı verginin məbləği"
      ],
      [
        "244.4",
        "VM-nin 106.1.20-ci maddəsinə əsasən əvvəlki 3 təqvim ilinin yekunlarına görə hesablanmış və ödənilmiş mənfəət vergisinin 75 faizi həcmində azaldılmalı verginin məbləği"
      ],
      [
        "245",
        "Ödənilməli mənfəət vergisinin məbləği (sət.243 - sət.244)"
      ],
      [
        "246",
        "Elan edilmiş dividendlər"
      ],
      [
        "247",
        "VM-nin 114.4-cü maddəsi ilə hesablanmış, lakin növbəti illərdə nəzərə alınacaq amortizasiya məbləği"
      ],
      [
        "248",
        "VM-nin 115.1-ci maddəsi ilə hesablanmış, lakin növbəti illərdə nəzərə alınacaq təmir xərclərinin məbləği"
      ],
      [
        "249",
        "VM-nə əsasən gəlirdən çıxılmayan xərclər"
      ],
      [
        "249.1",
        "VM-nin 109.2-ci maddəsinə əsasən gəlirdən çıxılmayan xərclər"
      ],
      [
        "249.2",
        "VM-nin 109.3-cü maddəsinə əsasən gəlirdən çıxılmayan xərclər"
      ],
      [
        "249.3",
        "Gəlirdən çıxılmayan digər xərclər"
      ]
    ]
  },
  {
    "key": "appendix1",
    "no": "5",
    "title": "Əlavə 1. Vergi uçotunun məqsədləri üçün aktivlər, öhdəliklər və kapitallar barədə məlumat",
    "kind": "multi",
    "columns": [
      "Hesabat dövrünün əvvəlinə",
      "Dövr ərzində daxil olmuşdur",
      "Təqdim edilmişdir",
      "Silinmişdir",
      "Ləğv edilmişdir",
      "Hesabat dövrünün sonuna"
    ],
    "rows": [
      [
        "1",
        "Cəmi aktivlər"
      ],
      [
        "1.1",
        "Əsas vəsaitlərin dəyəri"
      ],
      [
        "1.1.1",
        "Torpaqların yaxşılaşdırılması üzrə kapitallaşdırılmış xərclər, binalar, tikililər və qurğular"
      ],
      [
        "1.1.1.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri"
      ],
      [
        "1.1.2",
        "Maşınlar və avadanlıq"
      ],
      [
        "1.1.2.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri"
      ],
      [
        "1.1.3",
        "Nəqliyyat vasitələri (yük avtomobilləri istisna olmaqla)"
      ],
      [
        "1.1.3.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri"
      ],
      [
        "1.1.4",
        "İş heyvanları"
      ],
      [
        "1.1.4.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan aktivlərin dəyəri"
      ],
      [
        "1.1.5",
        "Digər əsas vəsaitlər"
      ],
      [
        "1.1.5.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri"
      ],
      [
        "1.1.6",
        "Yüksək texnologiyalar məhsulu olan hesablama texnikası"
      ],
      [
        "1.1.6.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri"
      ],
      [
        "1.1.7",
        "Yük avtomobilləri"
      ],
      [
        "1.1.7.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri"
      ],
      [
        "1.1.8",
        "İcarəyə götürülmüş əsas vəsaitlərin təmirinə çəkilən kapitallaşdırılmış xərclər"
      ],
      [
        "1.2",
        "Qeyri-maddi aktivlərin dəyəri"
      ],
      [
        "1.2.1",
        "İstifadə müddəti məlum olmayan qeyri-maddi aktivlərin dəyəri"
      ],
      [
        "1.2.1.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri"
      ],
      [
        "1.2.2",
        "İstifadə müddəti məlum olan qeyri-maddi aktivlərin dəyəri"
      ],
      [
        "1.2.2.1",
        "Dövlət müəssisələrində dövlət büdcəsinin investisiya xərcləri hesabına ayrılmış vəsaitlər hesabına alınan və ya quraşdırılan aktivlərin dəyəri"
      ],
      [
        "1.3",
        "Ehtiyatlar"
      ],
      [
        "1.3.1",
        "Hazır məhsul"
      ],
      [
        "1.3.2",
        "Mallar"
      ],
      [
        "1.3.3",
        "Bitməmiş istehsal"
      ],
      [
        "1.3.4",
        "Sair ehtiyatlar"
      ],
      [
        "1.4",
        "Debitor borcları"
      ],
      [
        "1.4.1",
        "Dövlət büdcəsinə (vergilər üzrə)"
      ],
      [
        "1.4.2",
        "Sair debitor borcları"
      ],
      [
        "1.4.2.1",
        "O cümlədən xarici borclar"
      ],
      [
        "1.5",
        "Pul vəsaitləri"
      ],
      [
        "1.6",
        "Səhmlər və iştirak payları üzrə maliyyə qoyuluşları"
      ],
      [
        "1.7",
        "Dövlət qiymətli kağızları"
      ],
      [
        "1.8",
        "Kapitallaşdırma üçün aktivlər"
      ],
      [
        "1.9",
        "Gələcək dövrün xərcləri"
      ],
      [
        "1.10",
        "Digər aktivlər"
      ],
      [
        "2",
        "Cəmi kapital və öhdəliklər"
      ],
      [
        "2.1",
        "Cəmi kapital"
      ],
      [
        "2.1.1",
        "Nizamnamə kapitalı"
      ],
      [
        "2.1.2",
        "Hesabat dövrünün xalis mənfəəti"
      ],
      [
        "2.1.3",
        "Əvvəlki illər üzrə bölüşdürülməmiş mənfəət"
      ],
      [
        "2.1.4",
        "Emissiya gəliri"
      ],
      [
        "2.1.5",
        "Kapital ehtiyatları"
      ],
      [
        "2.2",
        "Cəmi öhdəliklər"
      ],
      [
        "2.2.1",
        "Kreditor borcları"
      ],
      [
        "2.2.1.1",
        "Bank kreditləri"
      ],
      [
        "2.2.1.1.1",
        "O cümlədən xarici borclar"
      ],
      [
        "2.2.1.2",
        "Alınmış avanslar"
      ],
      [
        "2.2.1.3",
        "Dövlət büdcəsinə vergi öhdəlikləri"
      ],
      [
        "2.2.1.4",
        "Törəmə (asılı) müəssisələrə kreditor borcları"
      ],
      [
        "2.2.1.5",
        "Sair kreditor borcları"
      ],
      [
        "2.2.1.5.1",
        "O cümlədən xarici borclar"
      ],
      [
        "2.2.2",
        "Gələcək dövrün gəlirləri"
      ],
      [
        "2.2.3",
        "Digər öhdəliklər"
      ]
    ]
  },
  {
    "key": "appendix2",
    "no": "6",
    "title": "Əlavə 2. Xaricdə olan bank hesabları barədə məlumat",
    "kind": "grid",
    "columns": [
      "Ölkə",
      "Bankın adı",
      "Hesab nömrəsi / IBAN",
      "Valyuta",
      "Açılma tarixi",
      "Bağlanma tarixi",
      "Qeyd"
    ],
    "rows_count": 10
  },
  {
    "key": "appendix3",
    "no": "7",
    "title": "Əlavə 3. Ümidsiz borclar barədə məlumat",
    "kind": "grid",
    "columns": [
      "Borclunun adı",
      "VÖEN / Ş/V",
      "Borcu təsdiq edən sənəd",
      "Yaranma tarixi",
      "Məbləğ",
      "Silinən məbləğ",
      "Qeyd"
    ],
    "rows_count": 10
  },
  {
    "key": "appendix4",
    "no": "8",
    "title": "Əlavə 4. Obyektlər barədə məlumat",
    "kind": "grid",
    "columns": [
      "Obyektin adı",
      "Obyekt kodu",
      "Ünvan",
      "Fəaliyyət növü",
      "Başlama tarixi",
      "Bitmə tarixi",
      "Qeyd"
    ],
    "rows_count": 10
  },
  {
    "key": "appendix5",
    "no": "9",
    "title": "Əlavə 5. Azadolmalar və güzəştlər barədə məlumat",
    "kind": "table",
    "rows": [
      [
        "1",
        "Vergi Məcəlləsinin 106.1.1-ci maddəsinə əsasən dövlət hakimiyyəti orqanlarının, büdcə təşkilatlarının və yerli özünüidarə orqanlarının gəlirləri"
      ],
      [
        "2",
        "Vergi Məcəlləsinin 106.1.2-ci maddəsinə əsasən xeyriyyə təşkilatlarının gəliri – sahibkarlıq fəaliyyətindən əldə etdikləri gəlirdən başqa"
      ],
      [
        "3",
        "Vergi Məcəlləsinin 106.1.2-ci maddəsinə əsasən qeyri-kommersiya təşkilatlarının aldıqları əvəzsiz köçürmələr, üzvlük haqları və ianələr"
      ],
      [
        "4",
        "Vergi Məcəlləsinin 106.1.3-cü maddəsinə əsasən beynəlxalq, dövlətlərarası və hökumətlərarası təşkilatların gəlirləri – sahibkarlıq fəaliyyətindən əldə etdikləri gəlirdən başqa"
      ],
      [
        "5",
        "Vergi Məcəlləsinin 106.1.4-cü maddəsinə əsasən dövlət hakimiyyəti orqanlarının, büdcə təşkilatlarının, yerli özünüidarə orqanlarının və dövlətin adından yaradılan publik hüquqi şəxslərin gəlirləri"
      ],
      [
        "6",
        "Vergi Məcəlləsinin 106.1.5-ci maddəsinə əsasən Azərbaycan Respublikasının Mərkəzi Bankının və onun qurumlarının, ipoteka kreditləşməsi və sahibkarların dəstəklənməsi üzrə müvafiq qurumların gəlirləri"
      ],
      [
        "7",
        "Vergi Məcəlləsinin 106.1.6-cı maddəsinə əsasən alınmış sığorta ödənişləri, habelə müvafiq icra hakimiyyəti orqanının müəyyən etdiyi orqanların güzəştli kreditlər üzrə faiz gəlirləri"
      ],
      [
        "8",
        "Vergi Məcəlləsinin 106.1.6-cı maddəsinə əsasən alınmış sığorta ödənişləri və zərərə aid edilən məbləğlərdən başqa"
      ],
      [
        "9",
        "Vergi Məcəlləsinin 106.1.8-ci maddəsinə əsasən Azərbaycan Respublikasının qanunvericiliyinə uyğun olaraq dövlət büdcəsinə olan vergi borclarının silinməsindən əldə olunan gəlir"
      ],
      [
        "10",
        "Vergi Məcəlləsinin 106.1.9-cu maddəsinə əsasən Azərbaycan Respublikasının Prezidenti tərəfindən müəyyən edilmiş hallarda hüquqi şəxsin özünün və onun tam mülkiyyətində olan rezident törəmə müəssisələrinin aktivlərinin dəyəri"
      ],
      [
        "11",
        "Vergi Məcəlləsinin 106.1.10-cu maddəsinə əsasən balansında olan əsas vəsaitlərin digər şəxsin balansına verilməsi üzrə gəlirlər"
      ],
      [
        "12",
        "Vergi Məcəlləsinin 106.1.11-ci maddəsinə əsasən neft-qaz ehtiyatlarının kəşfiyyatı, işlənməsi və hasilatı üzrə gəlirlər"
      ],
      [
        "13",
        "Vergi Məcəlləsinin 106.1.13-cü maddəsinə əsasən sənaye və texnologiyalar parkında fəaliyyətdən əldə edilən gəlir"
      ],
      [
        "14",
        "Vergi Məcəlləsinin 106.1.15-ci maddəsinə əsasən məktəbəqədər təhsil müəssisələrinin və uşaq evlərinin gəlirləri"
      ],
      [
        "15",
        "Vergi Məcəlləsinin 106.1.16-cı maddəsinə əsasən “Torpaqların dövlət ehtiyacları üçün alınması haqqında” Qanuna əsasən ödənilən kompensasiya"
      ],
      [
        "16",
        "Vergi Məcəlləsinin 106.1.19-cu maddəsinə əsasən vergi ödəyicisinin azı 3 il ərzində mülkiyyətində olan iştirak payının və ya səhmin təqdim edilməsindən əldə olunan gəlirin 50 faizi"
      ],
      [
        "17",
        "Vergi Məcəlləsinin 106.10-cu maddəsinə əsasən qanunla müəyyən olunmuş qaydada gəlirlərin və xərclərin uçotunu aparan və ƏDV məqsədləri üçün qeydiyyata alınmayan rezident müəssisənin təsisçisi olan hüquqi şəxslərin dividend gəlirləri"
      ],
      [
        "18",
        "Vergi Məcəlləsinin 106.1.24-cü maddəsinə əsasən “Məşğulluq haqqında” Qanuna uyğun olaraq haqqı ödənilən ictimai işlərin təşkili ilə bağlı fəaliyyətdən əldə etdiyi gəlir"
      ],
      [
        "19",
        "Vergi Məcəlləsinin 106.1.28-ci maddəsinə əsasən Formula 1 və Formula 2 yarışları ilə bağlı qeyri-maddi aktivlər üzrə hüquqlardan istifadə edilməsindən əldə edilən royalti gəlirləri"
      ],
      [
        "20",
        "Vergi Məcəlləsinin 106.1.29-cu maddəsinə əsasən lotereya biletlərinin satışı ilə bağlı xidmətlərdən əldə olunan gəlirlər"
      ],
      [
        "21",
        "Vergi Məcəlləsinin 106.1.14-1-ci maddəsinə əsasən kənd təsərrüfatı məhsullarının istehsalı ilə məşğul olan hüquqi şəxslərin gəlirləri"
      ],
      [
        "22",
        "Vergi Məcəlləsinin 106.1.30-cu maddəsinə əsasən vəkillər və vəkil qurumları tərəfindən order markasının əldə edilməsi ilə bağlı ödənişlər"
      ],
      [
        "23",
        "Vergi Məcəlləsinin 227.3-cü maddəsinə əsasən dividend gəlirləri"
      ],
      [
        "24",
        "Vergi Məcəlləsinin 106.1.32-ci maddəsinə əsasən media subyektlərinin fəaliyyətindən əldə etdikləri gəlirlər"
      ],
      [
        "25",
        "Vergi Məcəlləsinin 106.1.34-cü maddəsinə əsasən tibb müəssisələri tərəfindən ƏDV məbləğinin azaldılmasından əldə edilən gəlirlər"
      ],
      [
        "26",
        "Vergi Məcəlləsinin 106.1.13-1-ci maddəsinə əsasən texnologiyalar parkının rezidenti kimi texnologiyalar parkından kənar sistem inteqrasiyası, proqram təminatının hazırlanması və inkişaf etdirilməsi fəaliyyəti üzrə gəlirlər"
      ],
      [
        "27",
        "Vergi Məcəlləsinin 106.1.36-cı maddəsinə əsasən “Sosial sığorta haqqında” Qanuna uyğun dövlətin investisiya yönümlü fəaliyyətindən əldə olunan gəlirlər"
      ],
      [
        "28",
        "Qanunla təsdiq olunmuş hasilatın pay bölgüsü və digər sazişlər çərçivəsində göstərilən fəaliyyətdən əldə olunan gəlir"
      ],
      [
        "29",
        "Gəlirlər üzrə azadolmalar barədə CƏMİ məlumat"
      ],
      [
        "30",
        "Vergi Məcəlləsinin 106.1.14-cü maddəsinə əsasən kənd təsərrüfatı məhsullarının istehsalı ilə məşğul olan hüquqi şəxslərin bu fəaliyyətdən əldə etdikləri mənfəəti"
      ],
      [
        "31",
        "Vergi Məcəlləsinin 106.1.7-ci maddəsinə əsasən təhsil müəssisələrinin və sağlamlıq imkanları məhdud şəxslərin təhsili üçün yaradılmış xüsusi təhsil müəssisələrinin mənfəəti"
      ],
      [
        "32",
        "Vergi Məcəlləsinin 106.1.12-ci maddəsinə əsasən sənaye və texnologiyalar parklarının idarəedici təşkilatının və operatorunun mənfəəti"
      ],
      [
        "33",
        "Vergi Məcəlləsinin 106.1.17-ci maddəsinə əsasən investisiya təşviqi sənədi almış hüquqi şəxsin mənfəətinin 50 faizi"
      ],
      [
        "34",
        "Vergi Məcəlləsinin 106.1.18-ci maddəsinə əsasən ödəmə qabiliyyətini itirmiş bankın rezolyusiyası çərçivəsində aktivlərin təqdim edilməsindən əldə olunan mənfəət"
      ],
      [
        "35",
        "Vergi Məcəlləsinin 106.1.20-ci maddəsinə əsasən mikro sahibkarlıq subyekti olan hüquqi şəxslərin sahibkarlıq fəaliyyətindən əldə etdikləri mənfəətin 75 faizi"
      ],
      [
        "36",
        "Vergi Məcəlləsinin 106.1.21-ci maddəsinə əsasən KOB klaster şirkətinin mənfəəti"
      ],
      [
        "37",
        "Vergi Məcəlləsinin 106.1.22-ci maddəsinə əsasən KOB klaster iştirakçısı olan hüquqi şəxsin mənfəətinin kapital xarakterli xərclərin çəkilməsinə yönəldilən hissəsi"
      ],
      [
        "38",
        "Vergi Məcəlləsinin 106.1.23-cü maddəsinə əsasən mikro və ya kiçik sahibkarlıq subyekti olan və “Startap” şəhadətnaməsi aldığı tarixdən innovasiya fəaliyyətindən əldə etdiyi mənfəəti"
      ],
      [
        "39",
        "Vergi Məcəlləsinin 106.1.31-ci maddəsinə əsasən işğaldan azad edilmiş ərazilərin rezidenti olan hüquqi şəxslərin mənfəətinin 75 faizi"
      ],
      [
        "40",
        "Vergi Məcəlləsinin 106.1.33-cü maddəsinə əsasən qanunla müəyyən olunmuş qaydada qeydə alınmış mikro sahibkarlıq subyekti olan kinematoqrafiya müəssisəsinin sahibkarlıq fəaliyyətindən əldə etdiyi mənfəətin 90 faizi"
      ],
      [
        "41",
        "Vergi Məcəlləsinin 106.1.35-ci maddəsinə əsasən elektrik enerjisi istehsalı layihələri üzrə əldə edilən mənfəət"
      ],
      [
        "42",
        "Mənfəət üzrə güzəştlər barədə CƏMİ məlumat"
      ]
    ]
  },
  {
    "key": "appendix7",
    "no": "10",
    "title": "Əlavə 7. Xarici ölkələrdə əldə edilmiş gəlirlər və ödənilmiş vergi barədə məlumat",
    "kind": "grid",
    "columns": [
      "Ölkə",
      "Gəlirin növü",
      "Gəlirin məbləği",
      "Xaricdə ödənilmiş vergi",
      "Nəzərə alınan vergi",
      "Sənəd nömrəsi",
      "Qeyd"
    ],
    "rows_count": 10
  },
  {
    "key": "summary",
    "no": "11",
    "title": "İcmal",
    "kind": "table",
    "rows": [
      [
        "200",
        "Malların təqdim edilməsindən və xidmətlərdən gəlir"
      ],
      [
        "218",
        "CƏMİ GƏLİRLƏR"
      ],
      [
        "220",
        "Çıxılmalardan sonra CƏMİ GƏLİR"
      ],
      [
        "234",
        "CƏMİ XƏRCLƏR"
      ],
      [
        "236",
        "Ümumi gəlirlərdən çıxılan xərclər"
      ],
      [
        "237",
        "Vergitutma məqsədləri üçün mənfəət"
      ],
      [
        "239",
        "Zərər"
      ],
      [
        "241",
        "Vergiyə cəlb olunan mənfəət"
      ],
      [
        "242",
        "Mənfəət vergisinin dərəcəsi"
      ],
      [
        "243",
        "Mənfəət vergisi"
      ],
      [
        "244",
        "Azaldılmalı verginin məbləği"
      ],
      [
        "245",
        "Ödənilməli mənfəət vergisinin məbləği"
      ]
    ]
  }
];

/*
BBEC 2.20 DÜZƏLİŞ MƏNTİQİ

VAHİD BƏYANNAMƏ:
902 Gəlirlər, cəmi -> "Rüb üzrə orta say"
1+2+3+4 rüb cəmi -> 221.1.2

OMV:
1607.1.1 Hüquqi şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.1

1607.1.2 Fiziki şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.2
*/
