
/*
BBEC SMART XLSX ANALYZER
XLSX faylını brauzerdə açır:
- ZIP End Of Central Directory tapır
- Central Directory oxuyur
- Deflate data üçün DecompressionStream istifadə edir
- xl/sharedStrings.xml və xl/worksheets/sheet*.xml fayllarını oxuyur
*/
async function unzipXlsxEntries(arrayBuffer){
  const bytes = new Uint8Array(arrayBuffer);
  function u16(o){ return bytes[o] | (bytes[o+1]<<8); }
  function u32(o){ return (bytes[o] | (bytes[o+1]<<8) | (bytes[o+2]<<16) | (bytes[o+3]<<24)) >>> 0; }
  let eocd = -1;
  for(let i=bytes.length-22;i>=0 && i>bytes.length-70000;i--){
    if(u32(i) === 0x06054b50){ eocd = i; break; }
  }
  if(eocd < 0) throw new Error("XLSX ZIP strukturu tapılmadı.");
  const cdCount = u16(eocd + 10);
  const cdOffset = u32(eocd + 16);
  let p = cdOffset;
  const files = {};
  for(let i=0;i<cdCount;i++){
    if(u32(p) !== 0x02014b50) break;
    const method = u16(p+10);
    const compSize = u32(p+20);
    const uncompSize = u32(p+24);
    const nameLen = u16(p+28);
    const extraLen = u16(p+30);
    const commentLen = u16(p+32);
    const localOffset = u32(p+42);
    const nameBytes = bytes.slice(p+46, p+46+nameLen);
    const name = new TextDecoder().decode(nameBytes);
    files[name] = {method, compSize, uncompSize, localOffset};
    p += 46 + nameLen + extraLen + commentLen;
  }
  const result = {};
  for(const [name, f] of Object.entries(files)){
    let lp = f.localOffset;
    if(u32(lp) !== 0x04034b50) continue;
    const nameLen = u16(lp+26);
    const extraLen = u16(lp+28);
    const start = lp + 30 + nameLen + extraLen;
    const comp = bytes.slice(start, start + f.compSize);
    let out;
    if(f.method === 0){
      out = comp;
    } else if(f.method === 8){
      if(typeof DecompressionStream === "undefined"){
        throw new Error("Bu Chrome versiyasında DecompressionStream yoxdur. Chrome-u yenilə.");
      }
      const ds = new DecompressionStream("deflate-raw");
      const stream = new Blob([comp]).stream().pipeThrough(ds);
      out = new Uint8Array(await new Response(stream).arrayBuffer());
    } else {
      continue;
    }
    result[name] = new TextDecoder("utf-8").decode(out);
  }
  return result;
}

function xmlUnescape(s){
  return String(s||"").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&").replace(/&quot;/g,'"').replace(/&apos;/g,"'");
}
function parseSharedStrings(xml){
  const out = [];
  if(!xml) return out;
  const items = xml.match(/<si[\s\S]*?<\/si>/g) || [];
  for(const si of items){
    const texts = [...si.matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map(m=>xmlUnescape(m[1]));
    out.push(texts.join(""));
  }
  return out;
}
function colToIndex(ref){
  const letters = String(ref||"").replace(/[0-9]/g,"").toUpperCase();
  let n=0;
  for(const ch of letters) n = n*26 + (ch.charCodeAt(0)-64);
  return n-1;
}
function rowIndex(ref){
  const m = String(ref||"").match(/\d+/);
  return m ? Number(m[0])-1 : 0;
}
function parseSheet(xml, shared){
  const rows = [];
  const cellRegex = /<c\b([^>]*)>([\s\S]*?)<\/c>/g;
  let m;
  while((m = cellRegex.exec(xml))){
    const attrs = m[1], body = m[2];
    const r = (attrs.match(/\br="([^"]+)"/)||[])[1] || "";
    const t = (attrs.match(/\bt="([^"]+)"/)||[])[1] || "";
    const ci = colToIndex(r), ri = rowIndex(r);
    let val = "";
    const v = (body.match(/<v[^>]*>([\s\S]*?)<\/v>/)||[])[1];
    const is = (body.match(/<is[^>]*>([\s\S]*?)<\/is>/)||[])[1];
    if(t === "s") val = shared[Number(v)] || "";
    else if(t === "inlineStr") {
      const texts = [...String(is||"").matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map(x=>xmlUnescape(x[1]));
      val = texts.join("");
    } else val = xmlUnescape(v || "");
    if(!rows[ri]) rows[ri] = [];
    rows[ri][ci] = val;
  }
  return rows.map(r => r || []);
}
async function readXlsxWorkbook(file){
  const entries = await unzipXlsxEntries(await file.arrayBuffer());
  const shared = parseSharedStrings(entries["xl/sharedStrings.xml"]);
  const sheets = [];
  const names = Object.keys(entries).filter(k => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort((a,b)=>{
    return Number((a.match(/sheet(\d+)/)||[])[1]) - Number((b.match(/sheet(\d+)/)||[])[1]);
  });
  for(const n of names){
    sheets.push({name:n, rows:parseSheet(entries[n], shared)});
  }
  return sheets;
}
function rowsToText(sheets){
  return sheets.map(s => s.rows.map(r => r.join(" | ")).join("\n")).join("\n\n");
}
function findHeaderIndex(rows, names){
  for(let r=0;r<Math.min(rows.length,60);r++){
    for(let c=0;c<(rows[r]||[]).length;c++){
      const v = String(rows[r][c]||"").toLowerCase();
      if(names.some(n => v.includes(n.toLowerCase()))) return {r,c};
    }
  }
  return null;
}
function findRowByCode(rows, code, extraKeywords=[]){
  const cr = new RegExp("^\\s*" + code.replaceAll(".","\\.") + "\\s*$");
  for(let r=0;r<rows.length;r++){
    const row = rows[r] || [];
    const rowText = row.join(" ").toLowerCase();
    for(let c=0;c<row.length;c++){
      const cell = String(row[c]||"").trim();
      if(cr.test(cell) || (cell.includes(code) && extraKeywords.some(k=>rowText.includes(k.toLowerCase())))){
        return {r,c,row};
      }
    }
  }
  return null;
}
function lastNumericInRow(row){
  const nums = [];
  for(const cell of row || []){
    const n = parseAzNumber(cell);
    if(n) nums.push(n);
  }
  return nums.length ? nums[nums.length-1] : 0;
}
function numericInColumnsAfter(row, start){
  for(let i=row.length-1;i>start;i--){
    const n = parseAzNumber(row[i]);
    if(n) return n;
  }
  return 0;
}
async function fileToSmartData(file){
  const lower = file.name.toLowerCase();
  if(lower.endsWith(".xlsx")){
    const sheets = await readXlsxWorkbook(file);
    return {type:"xlsx", sheets, text:rowsToText(sheets)};
  }
  return {type:"text", sheets:null, text:normText(await file.text())};
}
function detectOmvSmart(data){
  let huq=0, fiz=0;
  if(data.sheets){
    for(const sh of data.sheets){
      let a = findRowByCode(sh.rows, "1607.1.1", ["hüquqi","huquqi"]);
      let b = findRowByCode(sh.rows, "1607.1.2", ["fiziki"]);
      if(a) huq += numericInColumnsAfter(a.row, a.c);
      if(b) fiz += numericInColumnsAfter(b.row, b.c);
    }
  }
  if(!huq && !fiz){
    const r = detectOmv(data.text);
    huq += r.huq; fiz += r.fiz;
  }
  return {huq,fiz};
}
function detectVahidSmart(data){
  let total=0;
  if(data.sheets){
    for(const sh of data.sheets){
      const row = findRowByCode(sh.rows, "902", ["gəlirlər", "gelirler", "cəmi", "cemi"]);
      if(row) total += numericInColumnsAfter(row.row, row.c);
    }
  }
  if(!total) total += detectVahid(data.text);
  return total;
}
function detectEdvSmart(data){
  let total = 0;
  if(data.sheets){
    for(const sh of data.sheets){
      const col = findEdv301Column(sh.rows);
      if(col !== null && col !== undefined){
        let val = getColumnLastTotal(sh.rows, col);
        if(!val) val = getColumnSumIfNoTotal(sh.rows, col);
        total += val;
      } else {
        // Ehtiyat variant: 301 sətrinin özündən yox, mümkün olduqda yenə əvvəlki qaydanı saxlayırıq.
        const row = findRowByCode(sh.rows, "301", ["təqdim", "teqdim", "ədv", "edv"]);
        if(row) total += numericInColumnsAfter(row.row, row.c);
      }
    }
  }
  if(!total) total += detectEdv(data.text);
  return total;
}
function detectQaimeSmart(data){
  let mal=0, xidmet=0;
  if(data.sheets){
    for(const sh of data.sheets){
      const rows = sh.rows;
      let qIndex = 16; // Q sütunu
      const header = findHeaderIndex(rows, ["cəmi qiyməti", "cemi qiymeti"]);
      if(header) qIndex = header.c;
      for(const row of rows){
        if(!row || !row.length) continue;
        const text = row.join(" ").toLowerCase();
        const amount = parseAzNumber(row[qIndex]);
        if(!amount) continue;
        const isService = text.includes("xidmət") || text.includes("xidmet") || text.includes("service") || text.includes("iş ") || text.includes(" is ");
        const isGoods = text.includes("mal") || text.includes("məhsul") || text.includes("mehsul") || text.includes("material") || text.includes("goods");
        if(isService && !isGoods) xidmet += amount;
        else mal += amount;
      }
    }
  } else {
    const r = detectQaime(data.text);
    mal += r.mal; xidmet += r.xidmet;
  }
  return {mal,xidmet};
}


function cellText(row, c){
  return String((row && row[c]) || "").replace(/\s+/g, " ").trim();
}
function findEdv301Column(rows){
  // ƏDV cədvəlində 301 başlığı altında:
  // "Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)"
  const targetParts = ["təqdim", "edilmiş", "mal", "iş", "xidmət", "dəyəri"];
  const altParts = ["teqdim", "edilmis", "mal", "is", "xidmet", "deyeri"];
  let candidates = [];

  for(let r=0; r<Math.min(rows.length, 80); r++){
    const row = rows[r] || [];
    for(let c=0; c<row.length; c++){
      const v = cellText(row,c).toLowerCase();
      const ok1 = targetParts.every(p => v.includes(p));
      const ok2 = altParts.every(p => v.includes(p));
      if(ok1 || ok2){
        candidates.push({r,c,score:100});
      }
    }
  }

  // Bəzən başlıq bir neçə sətirdə parçalanır. Hər sütunu yuxarı 80 sətir üzrə birləşdirib yoxlayırıq.
  let maxCols = 0;
  rows.slice(0,80).forEach(r => maxCols = Math.max(maxCols, (r||[]).length));
  for(let c=0; c<maxCols; c++){
    let joined = "";
    for(let r=0; r<Math.min(rows.length,80); r++){
      joined += " " + cellText(rows[r], c);
    }
    const low = joined.toLowerCase();
    const ok1 = targetParts.every(p => low.includes(p));
    const ok2 = altParts.every(p => low.includes(p));
    if(ok1 || ok2){
      // 301 başlığına yaxın sütunlara üstünlük ver
      let score = 80;
      for(let rr=0; rr<Math.min(rows.length,25); rr++){
        const around = [c-2,c-1,c,c+1,c+2].map(x=>cellText(rows[rr],x)).join(" ");
        if(/\b301\b/.test(around)) score += 30;
      }
      candidates.push({r:0,c,score});
    }
  }

  if(!candidates.length) return null;
  candidates.sort((a,b)=>b.score-a.score);
  return candidates[0].c;
}
function getColumnLastTotal(rows, col){
  // Sütundakı ən aşağıdakı real rəqəmi götürürük. ƏDV bəyannaməsində bu, CƏMİ sətridir.
  let last = 0;
  for(let r=0; r<rows.length; r++){
    const n = parseAzNumber(rows[r] && rows[r][col]);
    if(n || String(rows[r] && rows[r][col] || "").trim()==="0"){
      if(n) last = n;
    }
  }
  return last;
}
function getColumnSumIfNoTotal(rows, col){
  // Əgər cəmi sətri tapılmasa ehtiyat variant: sütundakı müsbət rəqəmləri toplayırıq.
  let sum = 0;
  for(let r=0; r<rows.length; r++){
    const n = parseAzNumber(rows[r] && rows[r][col]);
    if(n > 0) sum += n;
  }
  return sum;
}


/*
BBEC 2.20 DÜZƏLİŞ MƏNTİQİ

VAHİD BƏYANNAMƏ:
902 Gəlirlər, cəmi -> "Rüb üzrə orta say"
1+2+3+4 rüb cəmi -> 221.1.2

OMV:
1607.1.1 Hüquqi şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.1

1607.1.2 Fiziki şəxslər üzrə
1+2+3+4 rüb cəmi -> 221.5.1.2
*/
