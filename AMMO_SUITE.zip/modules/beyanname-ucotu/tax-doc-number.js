import * as pdfjsLib from '../surucu-gelir/vendor/pdf.min.mjs';
pdfjsLib.GlobalWorkerOptions.workerSrc='../surucu-gelir/vendor/pdf.worker.min.mjs';
const td=new TextDecoder();
const u16=(d,o)=>d[o]|d[o+1]<<8, u32=(d,o)=>(u16(d,o)|(u16(d,o+2)<<16))>>>0;
async function inflate(data){return new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer())}
async function unzip(buf){const d=new Uint8Array(buf),files={};let e=d.length-22;while(e>=0&&u32(d,e)!==0x06054b50)e--;if(e<0)throw Error('DOCX ZIP formatı oxunmadı');let n=u16(d,e+10),p=u32(d,e+16);for(let i=0;i<n;i++){if(u32(d,p)!==0x02014b50)break;const method=u16(d,p+10),cs=u32(d,p+20),nl=u16(d,p+28),el=u16(d,p+30),cl=u16(d,p+32),lo=u32(d,p+42),name=td.decode(d.slice(p+46,p+46+nl));const lnl=u16(d,lo+26),lel=u16(d,lo+28),raw=d.slice(lo+30+lnl+lel,lo+30+lnl+lel+cs);files[name]=method===0?raw:await inflate(raw);p+=46+nl+el+cl}return files}
function xmlText(xml){const doc=new DOMParser().parseFromString(xml,'application/xml');return [...doc.querySelectorAll('w\\:t,t')].map(x=>x.textContent).join(' ')}
async function docxText(file){const f=await unzip(await file.arrayBuffer()),parts=[];for(const [name,data] of Object.entries(f)){if(/^word\/(document|header\d+|footer\d+)\.xml$/i.test(name))parts.push(xmlText(td.decode(data)))}return parts.join('\n')}
async function pdfText(file){const pdf=await pdfjsLib.getDocument({data:new Uint8Array(await file.arrayBuffer())}).promise;let out=[];for(let i=1;i<=pdf.numPages;i++){const p=await pdf.getPage(i),c=await p.getTextContent();out.push(c.items.map(x=>x.str).join(' '))}return out.join('\n')}
function clean(s){return String(s||'').replace(/\s+/g,' ').trim()}
function findNumber(text,fileName){const candidates=[];const pats=[
 /\b\d{1,3}-\d{1,3}-\d{1,3}-\d{1,3}\s*\/\s*\d{1,3}\s*-\s*(?:[A-ZƏÖÜĞÇŞİ]\s*-\s*)?\d{3,10}(?:\s*-\s*\d{1,4})?\s*\/\s*\d{4}\b/giu,
 /(?:Məktub|Sənəd|Qərar|Bildiriş)\s*(?:№|N[oö]mrə(?:si)?\s*[:\-]?)\s*([A-ZƏÖÜĞÇŞİ0-9][A-ZƏÖÜĞÇŞİ0-9\/\-]{5,})/giu,
 /№\s*([A-ZƏÖÜĞÇŞİ0-9][A-ZƏÖÜĞÇŞİ0-9\/\-]{5,})/giu
 ];for(const p of pats){for(const m of text.matchAll(p))candidates.push(clean(m[1]||m[0]).replace(/\s*([\/-])\s*/g,'$1').replace(/^№\s*/,'').trim())}
 const filenameMatches=String(fileName||'').match(/\d{1,3}-\d{1,3}-\d{1,3}-\d{1,3}\/\d{1,3}-(?:[A-ZƏÖÜĞÇŞİ]-)?\d{3,10}(?:-\d{1,4})?\/\d{4}/giu)||[];candidates.push(...filenameMatches);
 return candidates.find(x=>!/^\d{10}$/.test(x))||''}
function findVoen(text,fileName){const m=text.match(/VÖEN\s*[:№]?\s*(\d{10})/iu)||String(fileName||'').match(/(?:^|[_\s-])(\d{10})(?:[_\s-]|$)/);return m?.[1]||''}
function findCompany(text){const m=text.match(/Vergi ödəyicisinin adı\s*:\s*["“]?([^\n”"]{3,100})/iu)||text.match(/["“]\s*([^"”\n]{2,80})\s*["”]\s*(?:Məhdud|MMC|ASC|QSC)/iu);return clean(m?.[1]||'').replace(/["“”]/g,'')}
function setValue(sel,val){if(!val)return;const el=document.querySelector(sel);if(el){el.value=val;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}))}}
const b=document.getElementById('taxDocBtn'),f=document.getElementById('taxDocInput');
b.addEventListener('click',()=>f.click());f.addEventListener('change',async()=>{const file=f.files[0];if(!file)return;b.disabled=true;b.textContent='Oxunur...';try{const ext=file.name.toLowerCase().split('.').pop();let text='';if(ext==='pdf')text=await pdfText(file);else if(ext==='docx')text=await docxText(file);else throw Error('Köhnə .doc formatı dəstəklənmir. Faylı Word-də .docx kimi saxlayın.');const no=findNumber(text,file.name),voen=findVoen(text,file.name),company=findCompany(text);setValue('#voen',voen);setValue('#teskilat',company);if(no){setValue('#nomre',no);alert(`Məktub nömrəsi tapıldı: ${no}${voen?'\nVÖEN: '+voen:''}`)}else alert(`Sənəd oxundu, lakin daxilində məktub nömrəsi yoxdur.${voen?'\nVÖEN avtomatik yazıldı: '+voen:''}`)}catch(e){alert('Sənəd oxunmadı: '+e.message)}finally{b.disabled=false;b.textContent='📄 Vergi sənədi əlavə et';f.value=''}});
