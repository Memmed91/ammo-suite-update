const firebaseConfig = {
  apiKey: "AIzaSyCwcYEbn6WAIhgYgYwCPsEde1uPjPL7n_8",
  authDomain: "gomruk-nezaret.firebaseapp.com",
  projectId: "gomruk-nezaret",
  storageBucket: "gomruk-nezaret.firebasestorage.app",
  messagingSenderId: "1055442363796",
  appId: "1:1055442363796:web:b3de53d144db4f854d9b81"
};

const COLLECTION = "beyannameUcotu";
const LOCAL_KEY = "beyannameUcotuLocalCache";
const AUTH_KEY = "beyannameFirebaseAuth";
const BASE = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/(default)/documents/${COLLECTION}`;
const AUTH_URL = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${firebaseConfig.apiKey}`;
const REFRESH_URL = `https://securetoken.googleapis.com/v1/token?key=${firebaseConfig.apiKey}`;

let records = [];
let editId = null;
let authState = null;
let pollTimer = null;
let syncBusy = false;

const $ = id => document.getElementById(id);
const fields = ["teskilat","voen","nomre","nov","tarixGelen","tarixCavab","teyinat","qeyd"];

function setBadge(on, text){
  const b = $("serverBadge");
  if(!b) return;
  b.className = "server-badge " + (on ? "on" : "off");
  b.textContent = text;
}

function setSyncInfo(text){
  const el = $("syncInfo");
  if(el) el.textContent = text;
}

function nowText(){
  return new Date().toLocaleString("az-AZ");
}

function normalizeText(v){
  return String(v || "").toLowerCase().trim();
}

function escapeHtml(v){
  return String(v ?? "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#039;");
}

function formatDate(v){
  if(!v) return "";
  if(v === "yoxdur") return "yoxdur";
  const d = new Date(v);
  if(isNaN(d)) return v;
  return String(d.getDate()).padStart(2,"0") + "." +
         String(d.getMonth()+1).padStart(2,"0") + "." +
         d.getFullYear();
}

function daysBetween(a,b){
  if(!a || !b || a === "yoxdur" || b === "yoxdur") return "";
  const d1 = new Date(a);
  const d2 = new Date(b);
  if(isNaN(d1) || isNaN(d2)) return "";
  return Math.max(0, Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24)));
}

function newId(){
  return "id_" + Date.now() + "_" + Math.random().toString(16).slice(2);
}

function getForm(){
  return {
    id: editId || newId(),
    teskilat: $("teskilat").value.trim(),
    voen: $("voen").value.trim(),
    nomre: $("nomre").value.trim(),
    nov: $("nov").value.trim(),
    tarixGelen: $("tarixGelen").value,
    tarixCavab: $("tarixCavab").value,
    teyinat: $("teyinat").value || "CAVABLANDIRILMADI",
    qeyd: $("qeyd").value.trim(),
    updatedAt: Date.now(),
    updatedBy: authState?.email || "",
    deleted: false
  };
}

function clearForm(){
  fields.forEach(f => { if($(f)) $(f).value = ""; });
  if($("gecikme")) $("gecikme").value = "";
  editId = null;
  $("addBtn")?.classList.remove("hidden");
  $("saveEditBtn")?.classList.add("hidden");
}

async function saveLocal(){
  await chrome.storage.local.set({ [LOCAL_KEY]: records });
}

async function loadLocal(){
  const res = await chrome.storage.local.get([LOCAL_KEY]);
  records = Array.isArray(res[LOCAL_KEY]) ? res[LOCAL_KEY] : [];
  render();
}

function toFsValue(v){
  if(typeof v === "number") return { doubleValue: v };
  if(typeof v === "boolean") return { booleanValue: v };
  return { stringValue: String(v ?? "") };
}

function toFsFields(obj){
  const out = {};
  Object.keys(obj).forEach(k => out[k] = toFsValue(obj[k]));
  return out;
}

function fromFsFields(fields){
  const obj = {};
  Object.keys(fields || {}).forEach(k => {
    const v = fields[k];
    if("stringValue" in v) obj[k] = v.stringValue;
    else if("integerValue" in v) obj[k] = Number(v.integerValue);
    else if("doubleValue" in v) obj[k] = Number(v.doubleValue);
    else if("booleanValue" in v) obj[k] = Boolean(v.booleanValue);
    else obj[k] = "";
  });
  return obj;
}

function docIdFromName(name){
  return String(name || "").split("/").pop();
}

async function login(email, password){
  const res = await fetch(AUTH_URL, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({ email, password, returnSecureToken: true })
  });
  const data = await res.json();
  if(!res.ok) throw new Error(data?.error?.message || "Firebase girişi alınmadı");
  authState = {
    email: data.email,
    idToken: data.idToken,
    refreshToken: data.refreshToken,
    expiresAt: Date.now() + Number(data.expiresIn || 3600) * 1000
  };
  await chrome.storage.local.set({ [AUTH_KEY]: authState });
}

async function refreshToken(){
  if(!authState?.refreshToken) throw new Error("Refresh token yoxdur");
  const body = new URLSearchParams();
  body.set("grant_type", "refresh_token");
  body.set("refresh_token", authState.refreshToken);
  const res = await fetch(REFRESH_URL, { method:"POST", body });
  const data = await res.json();
  if(!res.ok) throw new Error(data?.error?.message || "Token yenilənmədi");
  authState.idToken = data.id_token;
  authState.refreshToken = data.refresh_token || authState.refreshToken;
  authState.expiresAt = Date.now() + Number(data.expires_in || 3600) * 1000;
  await chrome.storage.local.set({ [AUTH_KEY]: authState });
}

async function loadAuth(){
  const res = await chrome.storage.local.get([AUTH_KEY]);
  authState = res[AUTH_KEY] || null;
  if(authState?.refreshToken && (!authState.idToken || Date.now() > (authState.expiresAt || 0) - 60000)){
    try{ await refreshToken(); }catch(e){ authState = null; }
  }
}

async function apiFetch(url, options = {}){
  if(!authState?.idToken) throw new Error("Firebase girişi yoxdur");
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type":"application/json",
      "Authorization":"Bearer " + authState.idToken,
      ...(options.headers || {})
    }
  });
  if(res.status === 401 && authState.refreshToken){
    await refreshToken();
    return apiFetch(url, options);
  }
  if(!res.ok){
    let msg = "Firebase xətası: " + res.status;
    try{
      const j = await res.json();
      msg = j?.error?.message || msg;
    }catch(e){
      try{ msg = await res.text(); }catch(_){}
    }
    throw new Error(msg);
  }
  return res.json().catch(() => ({}));
}

async function fetchFirebaseRecords(){
  const data = await apiFetch(`${BASE}?pageSize=1000&orderBy=updatedAt desc`);
  const arr = (data.documents || [])
    .map(doc => ({ id: docIdFromName(doc.name), ...fromFsFields(doc.fields) }))
    .filter(r => !r.deleted);
  records = arr;
  await saveLocal();
  render();
  setSyncInfo("Son yenilənmə: " + nowText());
  setBadge(true, "Firebase: aktiv");
}

async function pushFirebase(row){
  if(!authState?.idToken) return;
  await apiFetch(`${BASE}/${encodeURIComponent(row.id)}`, {
    method:"PATCH",
    body: JSON.stringify({ fields: toFsFields(row) })
  });
}

async function deleteFirebase(id){
  if(!authState?.idToken) return;
  await apiFetch(`${BASE}/${encodeURIComponent(id)}`, { method:"DELETE" });
}

function filters(){
  const f = {};
  document.querySelectorAll("[data-filter]").forEach(i => f[i.dataset.filter] = normalizeText(i.value));
  return f;
}

function match(r,f){
  return Object.keys(f).every(k => {
    if(!f[k]) return true;
    let v = "";
    if(k === "tarixGelen" || k === "tarixCavab") v = formatDate(r[k]);
    else if(k === "gecikme") v = daysBetween(r.tarixGelen, r.tarixCavab);
    else v = r[k];
    return normalizeText(v).includes(f[k]);
  });
}

function statusHtml(v){
  if(v === "CAVABLANDIRILIB") return `<span class="status green">CAVABLANDIRILIB</span>`;
  if(v === "BAXIŞ") return `<span class="status blue">BAXIŞ</span>`;
  return `<span class="status red">CAVABLANDIRILMADI</span>`;
}

function render(){
  const f = filters();
  const arr = records.filter(r => !r.deleted && match(r,f));
  if($("count")) $("count").textContent = "Cəmi " + arr.length + " qeyd";
  if(!$("tbody")) return;
  $("tbody").innerHTML = arr.map(r => `
    <tr>
      <td>${escapeHtml(r.teskilat)}</td>
      <td>${escapeHtml(r.voen)}</td>
      <td>${escapeHtml(r.nomre)}</td>
      <td>${escapeHtml(r.nov)}</td>
      <td>${escapeHtml(formatDate(r.tarixGelen))}</td>
      <td>${escapeHtml(formatDate(r.tarixCavab))}</td>
      <td>${statusHtml(r.teyinat)}</td>
      <td>${escapeHtml(r.qeyd)}</td>
      <td>${escapeHtml(daysBetween(r.tarixGelen, r.tarixCavab))}</td>
      <td>
        <button class="action edit" data-edit="${escapeHtml(r.id)}">✎</button>
        <button class="action del" data-del="${escapeHtml(r.id)}">🗑</button>
      </td>
    </tr>
  `).join("");
  document.querySelectorAll("[data-edit]").forEach(b => b.onclick = () => editRecord(b.dataset.edit));
  document.querySelectorAll("[data-del]").forEach(b => b.onclick = () => deleteRecord(b.dataset.del));
}

function editRecord(id){
  const r = records.find(x => x.id === id);
  if(!r) return;
  editId = id;
  fields.forEach(f => { if($(f)) $(f).value = r[f] || ""; });
  if($("gecikme")) $("gecikme").value = daysBetween(r.tarixGelen, r.tarixCavab);
  $("addBtn")?.classList.add("hidden");
  $("saveEditBtn")?.classList.remove("hidden");
}

async function deleteRecord(id){
  if(!confirm("Bu məlumat silinsin?")) return;
  const idx = records.findIndex(x => x.id === id);
  if(idx >= 0) records.splice(idx, 1);
  await saveLocal();
  render();
  try{
    await deleteFirebase(id);
    await fetchFirebaseRecords();
  }catch(e){
    console.error(e);
    setSyncInfo("Firebase silmə xətası: " + e.message);
  }
}

async function addOrUpdate(){
  const row = getForm();
  if(!row.teskilat && !row.voen && !row.nomre){
    alert("Ən azı bir əsas məlumat yaz.");
    return;
  }
  const idx = records.findIndex(x => x.id === row.id);
  if(idx >= 0) records[idx] = row;
  else records.unshift(row);

  await saveLocal();
  render();
  clearForm();
  setSyncInfo("Məlumat əlavə edildi. Firebase-ə yazılır...");

  try{
    await pushFirebase(row);
    await fetchFirebaseRecords();
  }catch(e){
    console.error(e);
    setBadge(false, "Firebase: xəta");
    setSyncInfo("Məlumat lokal əlavə edildi, Firebase xətası: " + e.message);
    alert("Məlumat cədvələ əlavə edildi, amma Firebase-ə yazılmadı:\n" + e.message);
  }
}

async function startApp(){
  $("loginPanel")?.classList.add("hidden");
  $("mainPanel")?.classList.remove("hidden");
  $("logoutBtn")?.classList.remove("hidden");
  setBadge(true, "Firebase: aktiv");
  await loadLocal();
  try{ await fetchFirebaseRecords(); }catch(e){
    console.error(e);
    setBadge(false, "Firebase: xəta");
    setSyncInfo("Lokal məlumat göstərilir. Firebase oxuma xətası: " + e.message);
  }
  if(pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(() => {
    if(syncBusy) return;
    syncBusy = true;
    fetchFirebaseRecords().catch(console.error).finally(()=>syncBusy=false);
  }, 4000);
}

function showLogin(){
  $("loginPanel")?.classList.remove("hidden");
  $("mainPanel")?.classList.add("hidden");
  $("logoutBtn")?.classList.add("hidden");
  setBadge(false, "Firebase: qoşulmayıb");
}

function exportCsv(){
  const header = ["Təşkilat","VÖEN","Nömrə","Məktubun növü","Tarix gələn","Tarix cavablandırılan","Təyinat","Qeyd","Gecikmə günü"];
  const rows = records.filter(r=>!r.deleted).map(r => [
    r.teskilat||"", r.voen||"", r.nomre||"", r.nov||"", formatDate(r.tarixGelen),
    formatDate(r.tarixCavab), r.teyinat||"", r.qeyd||"", daysBetween(r.tarixGelen,r.tarixCavab)
  ]);
  const csv = [header, ...rows].map(row => row.map(v => `"${String(v).replace(/"/g,'""')}"`).join(";")).join("\n");
  const blob = new Blob(["\ufeff" + csv], {type:"text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "beyanname-ucotu.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function bindEvents(){
  $("loginBtn")?.addEventListener("click", async () => {
    const email = $("loginEmail").value.trim();
    const pass = $("loginPassword").value.trim();
    const err = $("loginError");
    if(err) err.textContent = "";
    if(!email || !pass){ if(err) err.textContent = "Email və şifrə yazın."; return; }
    try{
      $("loginBtn").disabled = true;
      $("loginBtn").textContent = "YOXLANILIR...";
      await login(email, pass);
      await startApp();
    }catch(e){
      if(err) err.textContent = "Firebase giriş xətası: " + e.message;
    }finally{
      $("loginBtn").disabled = false;
      $("loginBtn").textContent = "DAXİL OL";
    }
  });

  $("logoutBtn")?.addEventListener("click", async () => {
    await chrome.storage.local.remove([AUTH_KEY]);
    authState = null;
    records = [];
    if(pollTimer) clearInterval(pollTimer);
    showLogin();
  });

  $("addBtn")?.addEventListener("click", addOrUpdate);
  $("saveEditBtn")?.addEventListener("click", addOrUpdate);
  $("refreshBtn")?.addEventListener("click", () => fetchFirebaseRecords().catch(e => alert(e.message)));
  $("printPdf")?.addEventListener("click", () => window.print());
  $("exportExcel")?.addEventListener("click", exportCsv);

  ["tarixGelen","tarixCavab"].forEach(id => {
    $(id)?.addEventListener("input", () => {
      if($("gecikme")) $("gecikme").value = daysBetween($("tarixGelen").value, $("tarixCavab").value);
    });
  });

  document.querySelectorAll("[data-filter]").forEach(i => i.addEventListener("input", render));
}

(async function init(){
  bindEvents();
  await loadAuth();
  if(authState?.idToken) await startApp();
  else {
    await loadLocal();
    showLogin();
  }
})();
