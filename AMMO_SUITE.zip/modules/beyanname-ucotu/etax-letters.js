/* Vergi məktubları — V30.2: açıq e-taxes kabinetindən yenilənmə.
   "↻ Yenilə" → hansı şirkətin kabineti açıqdırsa onun məktubları oxunur → yeni olanlar varsa
   yuxarıda "🔔 Yenilənmə" çıxır → üzərinə basanda cədvələ düşür və Firebase-ə yazılır.
   popup.js-dən sonra yüklənir (records, saveLocal, render, pushFirebase, fetchFirebaseRecords qlobaldır). */
(() => {
  'use strict';
  const E = window.AmmoEtax; if (!E) return;
  const main = document.getElementById('mainPanel'); if (!main) return;
  const bar = E.bar(main, main.firstElementChild);
  const tools = document.querySelector('header.top .right-tools');
  const chip = tools ? E.topChip(tools, tools.firstChild) : null;
  let pending = [], who = null, busy = false;

  const norm = (s) => String(s || '').toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();
  function companyName(tp) {
    const fromRecords = records.find((r) => r.voen === tp.voen && r.teskilat)?.teskilat;
    if (fromRecords) return fromRecords;
    const opt = [...document.querySelectorAll('#ammoCompaniesList option')].find((o) => o.textContent.trim() === tp.voen);
    return opt?.value || tp.name || ('VÖEN ' + tp.voen);
  }
  function exists(x, voen) {
    return records.some((r) => !r.deleted && (r.voen || '') === voen && (
      (r.etaxId && r.etaxId === x.etaxId) ||
      (x.nomre && norm(r.nomre) === norm(x.nomre))
    ));
  }
  function setChip(n) { if (!chip) return; chip.textContent = `🔔 Yenilənmə (${n})`; chip.classList.toggle('hidden', !n); }

  async function check(manual) {
    if (busy) return; busy = true;
    try {
      const r = await E.snapshot({ letters: true });
      if (!r.ok) { pending = []; setChip(0); if (manual) bar.show('warn', E.errorText(r)); else bar.hide(); return; }
      const tp = r.taxpayer || {};
      if (!tp.voen) { if (manual) bar.show('warn', 'e-taxes kabineti açıqdır, amma şirkətin VÖEN-i müəyyən edilmədi.', 'Kabinetin ana səhifəsini bir dəfə açıb yenidən “Yenilə” basın.'); return; }
      who = { voen: tp.voen, name: companyName(tp) };
      if (r.lettersInfo === 'expired') { bar.show('warn', `${who.name}: e-taxes sessiyasının vaxtı bitib.`, 'Kabinetə yenidən daxil olun.'); return; }
      const all = E.normalizeLetters(r.letters || []);
      pending = all.filter((x) => !exists(x, who.voen));
      setChip(pending.length);
      if (pending.length) {
        bar.show('new', `Yenilənmə — ${who.name} (${who.voen}): ${pending.length} yeni məktub`, pending.slice(0, 3).map((x) => [x.nomre, x.subject].filter(Boolean).join(' · ')).join('  |  ') + (pending.length > 3 ? '  …' : ''), apply, 'Yenilənmə ⤵');
      } else if (!all.length && r.lettersInfo === 'no_endpoint') {
        bar.show('info', `Açıq kabinet: ${who.name} (${who.voen})`, 'Məktubları oxumaq üçün kabinetdə bir dəfə “Məktublar / Bildirişlər” bölməsini açın — AMMO ünvanı öyrənəcək. Sonra “Yenilə” basın.');
      } else if (manual) {
        bar.show('ok', `${who.name} (${who.voen}): yeni məktub yoxdur`, `Kabinetdə ${all.length} məktub yoxlanıldı · ${new Date().toLocaleTimeString('az-AZ')}`);
      }
    } finally { busy = false; }
  }

  async function apply() {
    if (!pending.length || !who) return;
    const list = pending.slice(); pending = []; setChip(0);
    bar.show('info', `${list.length} məktub cədvələ yazılır...`);
    const rows = list.map((x) => ({
      id: 'id_' + Date.now() + '_' + Math.random().toString(16).slice(2),
      teskilat: who.name, voen: who.voen, nomre: x.nomre, nov: x.nov,
      tarixGelen: x.tarixGelen, tarixCavab: '', teyinat: 'CAVABLANDIRILMADI',
      qeyd: [x.subject, x.sender].filter(Boolean).join(' — ').slice(0, 300),
      etaxId: x.etaxId, source: 'e-taxes', updatedAt: Date.now(), updatedBy: (authState && authState.email) || '', deleted: false
    }));
    rows.forEach((r) => records.unshift(r));
    await saveLocal(); render();
    let ok = 0;
    for (const r of rows) { try { await pushFirebase(r); ok++; } catch (e) { console.warn('AMMO məktub Firebase', e); } }
    try { await fetchFirebaseRecords(); } catch (e) { /* lokal qalır */ }
    bar.show(ok === rows.length ? 'ok' : 'warn', `${who.name}: ${rows.length} yeni məktub cədvələ əlavə olundu`, ok === rows.length ? 'Firebase serverə yazıldı — bütün kompüterlərdə görünəcək.' : `${rows.length - ok} məktub hələ Firebase-ə yazılmadı (internet?).`);
  }

  if (chip) chip.onclick = apply;
  document.getElementById('refreshBtn')?.addEventListener('click', () => check(true));
  // Panel açıq olduqca hər dəqiqə səssiz yoxla — yeni məktub varsa zolaq özü çıxır
  setTimeout(() => check(false), 2500);
  setInterval(() => { if (document.visibilityState === 'visible') check(false); }, 60000);
})();
