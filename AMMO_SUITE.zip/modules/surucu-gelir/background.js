const APP_URL = chrome.runtime.getURL('app.html');

async function openAppFullscreen() {
  const windows = await chrome.windows.getAll({ populate: true });
  const existing = windows.find(win =>
    (win.tabs || []).some(tab => tab.url === APP_URL)
  );

  if (existing) {
    await chrome.windows.update(existing.id, { focused: true, state: 'maximized' });
    const appTab = (existing.tabs || []).find(tab => tab.url === APP_URL);
    if (appTab) await chrome.tabs.update(appTab.id, { active: true });
    return;
  }

  await chrome.windows.create({
    url: APP_URL,
    type: 'popup',
    state: 'maximized',
    focused: true
  });
}

chrome.action.onClicked.addListener(openAppFullscreen);
chrome.runtime.onInstalled.addListener(openAppFullscreen);
