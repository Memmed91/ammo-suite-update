QURAŞDIRILMA
1. ZIP faylını çıxarın.
2. Chrome-da chrome://extensions açın.
3. Developer mode / Tərtibatçı rejimini aktiv edin.
4. Load unpacked / Paketlənməmiş uzantını yüklə seçin.
5. driver_income_extension_v2 qovluğunu seçin.
6. Uzantı ikonuna basdıqda proqram maksimum ölçüdə ayrıca pəncərədə açılır.

HESABLAMA DÜSTURLARI
- 1% nağdlaşdırma = Gəlirlər x 1%
- 5% gəlir vergisi = Gəlirlər x 5%
- Cəmi tutulan = DSMF + DSMF borc + 1% + verilmiş borc + mühasibat xidməti + mühasibat borc + vergi planlaması + borc + 5%
- Əlinə çatan = Gəlirlər - Cəmi tutulan


V9 YENİLİKLƏRİ
- Hesablama bölməsi daha yaradıcı və gözoxşayan dizayna keçirildi.
- Köhnə Excel arxivini birbaşa Hesabat və arxiv bölməsinə əlavə etmək mümkündür.
- Arxivdə Təmizlə düyməsi: tarix aralığı seçilibsə yalnız həmin aralığı, seçilməyibsə ən son tarixli siyahını silir.
- Cari ayda DSMF və ya Mühasibat xidməti tutulmayan sürücülər yeni siyahıda qırmızı yanıb-sönən xəbərdarlıqla göstərilir.
