/* Sürücü Gəlir Hesabatı — V10
   - Sürücü bazası Excel arxivindən yenidən quruldu (köhnə siyahı silindi, ehtiyat nüsxəsi saxlanır)
   - Nağdlaşdırma 2%, gəlir vergisi 10% (Ayarlardan dəyişilir)
   - Aylıq 50 ₼ xidmət haqqı nəzarəti: ödəməyən sürücü yanıb-sönür, qərar yazılmadan arxivə yazılmır
   - Yeni maşın aşkarlanması və bazaya daxil etmə sehrbazı
   - Direktor hesabatı (10% vergi → komissiya → ardıcıl tutulmalar → paylar → qalıq)
*/
import * as pdfjsLib from './vendor/pdf.min.mjs';
pdfjsLib.GlobalWorkerOptions.workerSrc = './vendor/pdf.worker.min.mjs';

/* ---------------- Sabitlər və vəziyyət ---------------- */
const K = { drivers:'sgDrivers', payments:'sgPayments', settings:'sgSettings', director:'sgDirector', meta:'sgMeta', draft:'sgDraft', arch:'sgArchive_' };
const SEED_VERSION = (window.SG_SEED && window.SG_SEED.version) || 'v10';
/* Direktor bölgüsü (V10.1):
   10% gəlir vergisi − Nağdlaşdırma (sürücü gəlirinin 2%-i) − Turnisə xanım (10%-in 5%-i) = Hesablanacaq məbləğ
   Məmməd = Hesablanacaq × 20% + xidmət haqqı · Aydın = Hesablanacaq × 10% · Qalan → Xəyalə xanım */
const DEFAULT_DIRECTOR = () => ({
  recipient: 'Xəyalə xanım',
  deductions: [
    { id: 'd1', name: 'Nağdlaşdırma', basis: 'income', pct: 2, on: true },
    { id: 'd2', name: 'Turnisə xanım', basis: 'base', pct: 5, on: true }
  ],
  shares: [
    { id: 's1', name: 'Məmməd', pct: 20, addFees: true, payeeId: '', payeeAuto: true, on: true },
    { id: 's2', name: 'Aydın', pct: 10, addFees: false, payeeId: '', on: true }
  ]
});
const DEFAULT_SETTINGS = {
  cashRate: 2, taxRate: 10, fee: 50, feeMode: 'ask',
  company: 'FOOD HALL MMC', voen: '3104242691', preparedBy: '', approvedBy: '',
  paymentForms: ['DEBET KART', 'ƏLBƏHƏL'],
  director: DEFAULT_DIRECTOR(), dirVersion: 2, lastCommission: 0
};
const BASIS = { income: 'Sürücü gəlirindən', base: '10% gəlir vergisindən' };
const MONTHS = ['Yanvar','Fevral','Mart','Aprel','May','İyun','İyul','Avqust','Sentyabr','Oktyabr','Noyabr','Dekabr'];
const PAY_METHODS = { deduct:'Maaşdan tutuldu', cash:'Nağd ödəyib', transfer:'Köçürmə ilə ödəyib', waive:'Bu ay azad', defer:'Növbəti hesabata saxlanıldı' };

const state = {
  drivers: [], archive: [], payments: [], director: [], meta: {}, settings: structuredClone(DEFAULT_SETTINGS),
  current: [], currentTrips: [], currentFile: '', pdfCheck: null, curCommission: 0,
  filtered: [], archSnap: {}, dirCalc: null
};

/* ---------------- Köməkçilər ---------------- */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = (s = '') => String(s ?? '').replace(/[&<>'"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[c]));
const num = v => {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  let s = String(v ?? '').replace(/[\s\u00a0₼]/g, '').replace(/AZN/i, ''); if (!s) return 0;
  if (/^-?\d{1,3}(\.\d{3})*,\d+$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^-?\d+,\d+$/.test(s)) s = s.replace(',', '.');
  else s = s.replace(/,/g, '');
  const n = Number(s); return Number.isFinite(n) ? n : 0;
};
const r2 = n => Math.round((num(n) + Number.EPSILON) * 100) / 100;
const fmtNum = v => num(v).toLocaleString('az-AZ', { minimumFractionDigits:2, maximumFractionDigits:2 });
const money = v => `${fmtNum(v)} ₼`;
const pctTxt = v => `${String(r2(v)).replace('.', ',')}%`;
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
const isoToday = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const fmtDate = v => { if (!v) return ''; const [y,m,d] = String(v).split('-'); return `${d}.${m}.${y}`; };
const toIso = v => { const m = String(v).match(/(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})/); return m ? `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}` : ''; };
const monthOf = d => String(d || '').slice(0, 7);
const monthLabel = m => { if (!m) return ''; const [y, mm] = m.split('-'); return `${MONTHS[Number(mm) - 1]} ${y}`; };
const monthShort = m => { const [y, mm] = m.split('-'); return `${MONTHS[Number(mm) - 1].slice(0,3)} ${y.slice(2)}`; };
const postingDate = () => $('#postingDate').value || isoToday();
const fixCyr = s => String(s ?? '').replace(/[Әә]/g, m => m === 'Ә' ? 'Ə' : 'ə');
const upperAz = s => fixCyr(s).toLocaleUpperCase('az').replace(/\s+/g, ' ').trim();
const loose = s => upperAz(s).replace(/[İI]/g,'I').replace(/Ə/g,'E').replace(/Ş/g,'S').replace(/Ç/g,'C').replace(/Ğ/g,'G').replace(/Ö/g,'O').replace(/Ü/g,'U').replace(/[^A-Z0-9]/g,'');
const translit = (s = '') => fixCyr(s).replace(/[Əə]/g, c => c === 'Ə' ? 'E' : 'e').replace(/Ş/g,'S').replace(/ş/g,'s').replace(/Ç/g,'C').replace(/ç/g,'c').replace(/Ğ/g,'G').replace(/ğ/g,'g').replace(/İ/g,'I').replace(/ı/g,'i').replace(/Ö/g,'O').replace(/ö/g,'o').replace(/Ü/g,'U').replace(/ü/g,'u').replace(/₼/g,'AZN');
function normalizePlate(v = '') {
  const s = upperAz(v).replace(/[^0-9A-ZƏÖÜĞÇŞİ]/g, ' ').replace(/\s+/g, ' ').trim();
  const m = s.replace(/\s/g, '').match(/^(\d{2})([A-ZƏÖÜĞÇŞİ]{1,2})(\d{3})$/);
  return m ? `${m[1]} ${m[2]} ${m[3]}` : s;
}
const splitPlates = v => String(v || '').split(/[,;\n\/]+/).map(normalizePlate).filter(Boolean);
function parseCard(raw) {
  const t = String(raw ?? '').trim(), digits = t.replace(/\D/g, '');
  if (digits.length >= 12) return { card: digits.replace(/(\d{4})(?=\d)/g, '$1 ').trim(), payment: 'DEBET KART' };
  if (/ƏLBƏHƏL|ELBEHEL|NAĞD|NAGD/i.test(loose(t)) || /əlbəhəl|nağd/i.test(t)) return { card: '', payment: 'ƏLBƏHƏL' };
  return { card: '', payment: '' };
}
const cardText = r => r.payment === 'ƏLBƏHƏL' && !r.card ? 'ƏLBƏHƏL VERİLƏCƏK' : (r.card || '');
const initials = n => upperAz(n).split(/[\s(]+/).filter(Boolean).slice(0, 2).map(x => x[0]).join('');

function toast(t, kind = '') { const e = $('#toast'); e.textContent = t; e.className = `toast show ${kind}`; clearTimeout(e._t); e._t = setTimeout(() => e.className = 'toast', 3200); }

/* ---------------- Hesablama ---------------- */
function calc(r) {
  r.income = r2(r.income); r.service = r2(r.service); r.other = r2(r.other);
  if (r.manual) {
    r.cash = 0; r.incomeTax = 0; r.totalDeduction = r2(r.service + r.other); r.net = r2(num(r.manualNet));
  } else {
    r.cash = r2(r.income * num(r.cashRate) / 100);
    r.incomeTax = r2(r.income * num(r.taxRate) / 100);
    r.totalDeduction = r2(r.cash + r.incomeTax + r.service + r.other);
    r.net = r2(r.income - r.totalDeduction);
  }
  return r;
}
function makeRow(o = {}) {
  return calc({
    id: o.id || uid(), postingDate: o.postingDate || postingDate(), sourceFile: o.sourceFile || '',
    driverId: o.driverId || '', driverName: o.driverName || 'NAMƏLUM', card: o.card || '', payment: o.payment || '',
    plates: (o.plates || []).filter(Boolean), trips: num(o.trips), income: num(o.income),
    cashRate: o.cashRate ?? state.settings.cashRate, taxRate: o.taxRate ?? state.settings.taxRate,
    service: num(o.service), other: num(o.other), otherNote: o.otherNote || '',
    manual: !!o.manual, manualNet: num(o.manualNet), sourceDates: o.sourceDates || [], pdfNames: o.pdfNames || [],
    feeDecision: o.feeDecision || '', feeState: o.feeState || ''
  });
}
const STORED_ROW_KEYS = ['id','postingDate','sourceFile','driverId','driverName','card','payment','plates','trips','income','cashRate','taxRate','service','other','otherNote','manual','manualNet','sourceDates','feeDecision'];
const compactRow = r => { const o = {}; for (const k of STORED_ROW_KEYS) { const v = r[k]; if (v === '' || v === false || v == null || (Array.isArray(v) && !v.length) || (v === 0 && !['income','cashRate','taxRate'].includes(k))) continue; o[k] = v; } return o; };

/* ---------------- Yaddaş ---------------- */
async function persistDrivers() { await chrome.storage.local.set({ [K.drivers]: state.drivers }); }
async function persistPayments() { await chrome.storage.local.set({ [K.payments]: state.payments }); }
async function persistSettings() { await chrome.storage.local.set({ [K.settings]: state.settings }); }
async function persistDirector() { await chrome.storage.local.set({ [K.director]: state.director }); }
async function persistMeta() { await chrome.storage.local.set({ [K.meta]: state.meta }); }
async function persistArchive() {
  const groups = {};
  for (const r of state.archive) { const k = K.arch + monthOf(r.postingDate).replace('-', '_'); (groups[k] ||= []).push(compactRow(r)); }
  const set = {}, removed = [];
  for (const [k, rows] of Object.entries(groups)) { rows.sort((a, b) => (a.postingDate || '').localeCompare(b.postingDate || '')); const j = JSON.stringify(rows); if (state.archSnap[k] !== j) { set[k] = rows; state.archSnap[k] = j; } }
  for (const k of Object.keys(state.archSnap)) if (!groups[k]) { removed.push(k); delete state.archSnap[k]; }
  if (Object.keys(set).length) await chrome.storage.local.set(set);
  if (removed.length) await chrome.storage.local.remove(removed);
}
let draftTimer = null;
function persistDraft() {
  clearTimeout(draftTimer);
  draftTimer = setTimeout(() => chrome.storage.local.set({ [K.draft]: { current: state.current.map(compactRow), trips: state.currentTrips, file: state.currentFile, pdfCheck: state.pdfCheck, postingDate: postingDate(), commission: state.curCommission } }), 250);
}
async function readStore() {
  const all = await chrome.storage.local.get(null);
  state.drivers = (all[K.drivers] || []).map(d => ({ aliases: [], plates: [], ...d }));
  state.payments = all[K.payments] || [];
  state.director = all[K.director] || [];
  state.meta = all[K.meta] || {};
  state.settings = { ...structuredClone(DEFAULT_SETTINGS), ...(all[K.settings] || {}) };
  if (state.settings.dirVersion !== 2 || !state.settings.director) {
    state.settings.director = DEFAULT_DIRECTOR(); state.settings.dirVersion = 2;
    delete state.settings.deductions; delete state.settings.shares; delete state.settings.recipient; state.settingsDirty = true;
  }
  if (!Array.isArray(state.settings.paymentForms) || !state.settings.paymentForms.length) state.settings.paymentForms = ['DEBET KART', 'ƏLBƏHƏL'];
  state.archive = []; state.archSnap = {};
  for (const [k, v] of Object.entries(all)) if (k.startsWith(K.arch) && Array.isArray(v)) { state.archSnap[k] = JSON.stringify(v); state.archive.push(...v.map(makeRow)); }
  state.archive.sort((a, b) => a.postingDate.localeCompare(b.postingDate));
  return all;
}

/* ---------------- Sürücü bazası ---------------- */
const driverById = id => state.drivers.find(d => d.id === id);
const driverByPlate = p => state.drivers.find(d => d.plates.includes(p));
const driverByName = n => { const l = loose(n); return l ? state.drivers.find(d => loose(d.name) === l || (d.aliases || []).some(a => loose(a) === l)) : null; };
function addAlias(d, name) { const n = upperAz(name); if (n && loose(n) !== loose(d.name) && !(d.aliases ||= []).some(a => loose(a) === loose(n))) d.aliases.push(n); }
function newDriver(o) {
  const d = { id: uid(), name: upperAz(o.name) || 'NAMƏLUM', plates: [...new Set(o.plates || [])], card: o.card || '', payment: o.payment || (o.card ? 'DEBET KART' : ''), phone: o.phone || '', note: o.note || '', active: true, manual: !!o.manual, feeExempt: !!o.feeExempt, createdAt: o.createdAt || isoToday(), cardDate: o.cardDate || '', source: o.source || '', aliases: [] };
  for (const p of d.plates) for (const x of state.drivers) x.plates = x.plates.filter(y => y !== p);
  state.drivers.push(d); return d;
}
/* Excel hesabatından sürücünü öyrən: maşın nömrəsi əsas açardır, sonra ad */
function learnDriver({ name, cardRaw, plates, date, manual, source }) {
  const pc = parseCard(cardRaw);
  let d = plates.map(driverByPlate).find(Boolean) || driverByName(name);
  let created = false, cardChanged = false;
  if (!d) {
    d = newDriver({ name, plates, card: pc.card, payment: pc.payment, manual, feeExempt: manual, createdAt: date, cardDate: date, source });
    created = true;
  } else {
    for (const p of plates) if (!d.plates.includes(p)) { for (const x of state.drivers) x.plates = x.plates.filter(y => y !== p); d.plates.push(p); }
    addAlias(d, name);
    if ((pc.card || pc.payment) && date >= (d.cardDate || '')) {
      if (pc.card && pc.card !== d.card && d.card) cardChanged = true;
      if (pc.card) d.card = pc.card;
      if (pc.payment) d.payment = pc.payment;
      d.cardDate = date;
    }
    if (d.createdAt > date) d.createdAt = date;
  }
  return { d, created, cardChanged };
}

/* ---------------- Ödənişlər (xidmət haqqı) ---------------- */
function feeRecord(driverId, month, { excludeCurrent = false } = {}) {
  const row = state.archive.find(r => r.driverId === driverId && monthOf(r.postingDate) === month && r.service > 0);
  if (row) return { kind: 'deduct', amount: row.service, date: row.postingDate, rowId: row.id };
  const p = state.payments.find(x => x.driverId === driverId && x.month === month);
  if (p) return { kind: p.method, amount: p.amount, date: p.date, paymentId: p.id, note: p.note };
  if (!excludeCurrent) {
    const c = state.current.find(r => r.driverId === driverId && monthOf(r.postingDate) === month && r.service > 0);
    if (c) return { kind: 'deduct', amount: c.service, date: c.postingDate, current: true };
  }
  return null;
}
const workedIn = (driverId, month) => state.archive.some(r => r.driverId === driverId && monthOf(r.postingDate) === month) || state.current.some(r => r.driverId === driverId && monthOf(r.postingDate) === month);

/* Cari cədvəldə hər sətrin xidmət haqqı vəziyyəti */
function refreshFeeStates() {
  const month = monthOf(postingDate());
  for (const r of state.current) {
    r.postingDate = postingDate();
    const d = driverById(r.driverId);
    if (!d) { r.feeState = 'new'; r.service = 0; continue; }
    if (r.manual || d.feeExempt) { r.feeState = 'exempt'; if (r.feeDecision === 'deduct') { r.feeDecision = ''; r.service = 0; } continue; }
    const others = state.current.filter(x => x !== r);
    const prev = feeRecord(d.id, month, { excludeCurrent: true }) || (others.find(x => x.driverId === d.id && x.service > 0) ? { kind: 'deduct' } : null);
    if (prev) { r.feeState = 'paid'; r.paidInfo = prev; if (r.feeDecision) { r.feeDecision = ''; r.service = 0; } continue; }
    if (!r.feeDecision && state.settings.feeMode === 'deduct') r.feeDecision = 'deduct';
    if (r.feeDecision) { r.feeState = 'decided'; r.service = r.feeDecision === 'deduct' ? (r.feeAmount || num(state.settings.fee)) : 0; }
    else { r.feeState = 'pending'; r.service = 0; }
  }
  state.current.forEach(calc);
  applyLinkedPayouts();
}
/* Payı kart sahibinə bağlanan şəxslər (məs. Məmməd → ALLAHVERDİYEV M.): məbləğ avtomatik yazılır */
function ensurePayees() {
  let changed = false;
  for (const sh of state.settings.director.shares) {
    if (sh.payeeAuto && !sh.payeeId && loose(sh.name) === loose('Məmməd')) {
      const d = state.drivers.find(x => loose(x.name).startsWith('ALLAHVERDIYEVM'));
      if (d) { sh.payeeId = d.id; changed = true; }
    }
  }
  return changed;
}
function applyLinkedPayouts() {
  for (const r of state.current) r.linkedShare = '';
  if (!state.current.length) return;
  const c = directorCalc(state.current, num(state.curCommission));
  for (const sh of c.shares) {
    if (!sh.payeeId) continue;
    const r = state.current.find(x => x.driverId === sh.payeeId && x.manual);
    if (!r) continue;
    r.manualNet = r2(sh.total); r.linkedShare = sh.name; r.linkedInfo = sh; calc(r);
  }
}

/* ---------------- PDF reyestr ---------------- */
function reconstructLines(items) {
  const groups = [];
  for (const it of items) {
    if (!it.str || !it.str.trim()) continue;
    const y = Math.round(it.transform[5] * 2) / 2;
    let g = groups.find(x => Math.abs(x.y - y) < 2);
    if (!g) { g = { y, items: [] }; groups.push(g); }
    g.items.push({ x: it.transform[4], s: it.str });
  }
  return groups.sort((a, b) => b.y - a.y).map(g => g.items.sort((a, b) => a.x - b.x).map(x => x.s).join(' ').replace(/\s+/g, ' ').trim()).filter(Boolean);
}
const AMOUNT_RE = /(?:^|\s)(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})(?=\s|$)/g;
const PLATE_RE = /(?:^|\s)(\d{2})\s?-?([A-Z]{2})\s?-?(\d{3})(?=\s|$)/;
async function parsePdf(file) {
  const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
  const lines = [];
  for (let p = 1; p <= pdf.numPages; p++) { const tc = await (await pdf.getPage(p)).getTextContent(); lines.push(...reconstructLines(tc.items).map(fixCyr)); }
  const rowStart = /^\s*(\d{1,3})\s+(\d{10})\s+(.+?)\s+(\d{2}\.\d{2}\.\d{4})\s+(.*)$/;
  const rows = []; let lastRowLine = -1;
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(rowStart); if (!m) continue;
    lastRowLine = i;
    let chunk = m[5], j = i + 1;
    while (j < lines.length && j < i + 6 && !rowStart.test(lines[j]) && !/^\s*\d{1,3}\s+\d{10}\s/.test(lines[j])) { chunk += ' ' + lines[j]; j++; }
    const up = upperAz(m[5]), upChunk = upperAz(chunk);
    const pm = up.match(PLATE_RE) || upChunk.match(PLATE_RE); if (!pm) continue;
    let am = [...m[5].matchAll(AMOUNT_RE)]; if (!am.length) am = [...chunk.matchAll(AMOUNT_RE)]; if (!am.length) continue;
    const plate = `${pm[1]} ${pm[2]} ${pm[3]}`;
    const nameIdx = up.indexOf(pm[0].trim());
    rows.push({ ss: Number(m[1]), date: toIso(m[4]), plate, name: nameIdx > 0 ? up.slice(0, nameIdx).trim() : '', amount: num(am.at(-1)[1]) });
  }
  const unique = [], seen = new Set();
  for (const r of rows) { const k = `${r.ss}|${r.date}|${r.plate}|${r.amount}`; if (!seen.has(k)) { seen.add(k); unique.push(r); } }
  if (!unique.length) throw new Error('PDF-də reyestr sətirləri tapılmadı.');
  // Sənəddə göstərilən yekun məbləğ — ayrıca sətirdə yazılan ən böyük məbləğ
  let stated = null;
  for (const line of lines) {
    const m = line.match(/^(\d{1,3}(?:,\d{3})+\.\d{2}|\d{3,}\.\d{2})(?:\s+[A-ZƏÖÜĞÇŞİa-zəöüğçşı].*)?$/);
    if (m && !rowStart.test(line)) stated = Math.max(stated ?? 0, num(m[1]));
  }
  return { trips: unique, stated };
}

/* ---------------- Excel: tip müəyyənləşdirmə ---------------- */
const hk = s => loose(s);
function findHeader(aoa, test) { for (let i = 0; i < Math.min(aoa.length, 25); i++) { const keys = (aoa[i] || []).map(hk); if (test(keys)) return { index: i, keys }; } return null; }
function classifyAoa(aoa) {
  const rep = findHeader(aoa, k => k.includes('ASA') && k.some(x => x.includes('ELINECATAN') || x.includes('GELIRLER')));
  if (rep) return { type: 'report', header: rep };
  const rey = findHeader(aoa, k => k.some(x => x.includes('MASIN')) && k.some(x => x.includes('HAQQ') || x.includes('MEBLEG') || x.includes('MƏBLƏĞ')));
  if (rey) return { type: 'reyestr', header: rey };
  return { type: aoa.some(r => (r || []).some(c => PLATE_RE.test(' ' + upperAz(c) + ' '))) ? 'reyestr' : 'unknown', header: null };
}
function excelDate(v) {
  if (v instanceof Date && !isNaN(v)) return `${v.getFullYear()}-${String(v.getMonth()+1).padStart(2,'0')}-${String(v.getDate()).padStart(2,'0')}`;
  if (typeof v === 'number' && v > 20000 && window.XLSX) { const d = XLSX.SSF.parse_date_code(v); if (d) return `${d.y}-${String(d.m).padStart(2,'0')}-${String(d.d).padStart(2,'0')}`; }
  const s = String(v ?? '').trim(); if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10); return toIso(s);
}
function parseReyestrAoa(aoa, header) {
  const trips = [];
  let plateCol = -1, amountCol = -1, dateCol = -1, nameCol = -1, start = 0;
  if (header) {
    const k = header.keys; start = header.index + 1;
    plateCol = k.findIndex(x => x.includes('MASIN')); amountCol = k.findIndex(x => x.includes('HAQQ') || x.includes('MEBLEG'));
    dateCol = k.findIndex(x => x === 'TARIX' || x.includes('TARIX')); nameCol = k.findIndex(x => x.includes('SURUCU') || x.includes('ADI'));
  }
  aoa.slice(start).forEach((row, i) => {
    if (!row) return;
    let plate = '', amount = 0;
    if (plateCol >= 0) { const m = (' ' + upperAz(row[plateCol]) + ' ').match(PLATE_RE); if (m) plate = `${m[1]} ${m[2]} ${m[3]}`; }
    if (!plate) for (const c of row) { const m = (' ' + upperAz(c) + ' ').match(PLATE_RE); if (m) { plate = `${m[1]} ${m[2]} ${m[3]}`; break; } }
    if (!plate) return;
    amount = amountCol >= 0 ? num(row[amountCol]) : num([...row].reverse().find(c => num(c) > 0));
    if (!(amount > 0)) return;
    trips.push({ ss: i + 1, date: dateCol >= 0 ? excelDate(row[dateCol]) : '', plate, name: nameCol >= 0 ? upperAz(row[nameCol]) : '', amount: r2(amount) });
  });
  if (!trips.length) throw new Error('Excel reyestrində maşın nömrəsi və məbləğ tapılmadı.');
  return { trips, stated: null };
}

/* ---------------- Excel hesabatını arxivə yaz ---------------- */
function importReportAoa(aoa, header, fileName) {
  const k = header.keys, col = test => k.findIndex(test);
  const c = {
    name: col(x => x === 'ASA'), card: col(x => x.includes('KART')), pay: col(x => x.includes('ODENISFORMASI')), cnt: col(x => x.includes('MASINSAYI')),
    date: col(x => x === 'TARIX'), plate: col(x => x.includes('MASINNOMRESI')), income: col(x => x === 'GELIRLER'),
    cash: col(x => x.includes('NAGDLASDIRMA')), tax: col(x => x.includes('GELIRVERGISI')), net: col(x => x.includes('ELINECATAN')),
    service: [col(x => x.includes('MUHASIBATXIDMETI')), col(x => x.includes('XIDMETHAQQI'))],
    other: ['DSMF','DSMFBORC','VERILMISBORC','MUHASIBATBORC','VERGIPLANLAMASI','BORC','DIGERTUTULMA'].map(n => col(x => x === n))
  };
  const hdrRate = i => { if (i < 0) return null; const m = String(aoa[header.index][i]).match(/(\d+(?:[.,]\d+)?)\s*%/); return m ? num(m[1].replace(',', '.')) : null; };
  const cashRateH = hdrRate(c.cash), taxRateH = hdrRate(c.tax);
  const fileDateM = fileName.match(/(\d{4})-(\d{2})-(\d{2})/);
  const body = aoa.slice(header.index + 1).filter(r => r && String(r[c.name] ?? '').trim() && !loose(r[c.name]).includes('UMUMICEM'));
  const dates = body.map(r => c.date >= 0 ? excelDate(r[c.date]) : '').filter(Boolean);
  const common = dates.sort((a, b) => dates.filter(x => x === b).length - dates.filter(x => x === a).length)[0] || (fileDateM ? fileDateM.slice(1).join('-') : postingDate());
  const rows = [], created = [], cardChanges = [];
  for (const x of body) {
    const name = upperAz(x[c.name]); const date = (c.date >= 0 && excelDate(x[c.date])) || common;
    const plates = c.plate >= 0 ? splitPlates(x[c.plate]) : [];
    const income = c.income >= 0 ? num(x[c.income]) : 0, net = c.net >= 0 ? num(x[c.net]) : 0;
    const manual = !(income > 0);
    if (manual && !(net > 0)) continue;
    const { d, created: cr, cardChanged } = learnDriver({ name, cardRaw: c.card >= 0 ? x[c.card] : '', plates, date, manual: manual && !plates.length, source: fileName });
    if (cr) created.push(d.name); if (cardChanged) cardChanges.push(d.name);
    const cashV = c.cash >= 0 ? num(x[c.cash]) : 0, taxV = c.tax >= 0 ? num(x[c.tax]) : 0;
    const cashRate = income > 0 && cashV > 0 ? r2(cashV / income * 100) : (cashRateH ?? state.settings.cashRate);
    const taxRate = income > 0 && taxV > 0 ? r2(taxV / income * 100) : (taxRateH ?? state.settings.taxRate);
    const pc = parseCard(c.card >= 0 ? x[c.card] : '');
    rows.push(makeRow({
      postingDate: date, sourceFile: fileName, driverId: d.id, driverName: name || d.name, card: pc.card, payment: pc.payment || (c.pay >= 0 ? upperAz(x[c.pay]) : '') || d.payment,
      plates: plates.length ? plates : (manual ? [] : d.plates), trips: c.cnt >= 0 ? num(x[c.cnt]) : plates.length, income: manual ? 0 : income,
      cashRate, taxRate, service: c.service.reduce((a, i) => a + (i >= 0 ? num(x[i]) : 0), 0), other: c.other.reduce((a, i) => a + (i >= 0 ? num(x[i]) : 0), 0),
      manual, manualNet: manual ? net : 0
    }));
  }
  return { rows, created, cardChanges, dates: [...new Set(rows.map(r => r.postingDate))] };
}

/* ---------------- Fayl qəbulu ---------------- */
async function handleFiles(files) {
  files = [...files || []].filter(Boolean); if (!files.length) return;
  const btn = $('#addFileBtn'); btn.disabled = true; btn.textContent = 'Oxunur...';
  const reports = [];
  try {
    for (const file of files) {
      const lower = file.name.toLowerCase();
      try {
        if (lower.endsWith('.pdf')) { await loadReyestr(await parsePdf(file), file.name); continue; }
        if (!/\.xlsx?$/.test(lower)) { toast(`${file.name}: yalnız PDF və Excel qəbul edilir`, 'bad'); continue; }
        const wb = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: true });
        const aoa = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '', raw: true });
        const cls = classifyAoa(aoa);
        if (cls.type === 'report') reports.push({ aoa, header: cls.header, name: file.name });
        else if (cls.type === 'reyestr') await loadReyestr(parseReyestrAoa(aoa, cls.header), file.name);
        else toast(`${file.name}: fayl tanınmadı`, 'bad');
      } catch (e) { console.error(e); toast(`${file.name}: ${e.message}`, 'bad'); }
    }
    if (reports.length) await importReports(reports);
  } finally { btn.disabled = false; btn.textContent = '＋ Fayl əlavə et'; $('#fileInput').value = ''; }
}
async function importReports(list, { silent = false } = {}) {
  let added = 0; const created = [], cardChanges = [], dates = [];
  for (const f of list) {
    const before = state.drivers.length;
    const snapshot = JSON.stringify(state.drivers);
    const res = importReportAoa(f.aoa, f.header, f.name);
    if (!res.rows.length) { if (!silent) toast(`${f.name}: sətir tapılmadı`, 'bad'); continue; }
    const clash = state.archive.filter(r => res.dates.includes(r.postingDate));
    if (clash.length && !silent) {
      const ok = confirm(`${res.dates.map(fmtDate).join(', ')} tarixində arxivdə artıq ${clash.length} qeyd var.\n\nOK — köhnə qeydlər bu fayl ilə ƏVƏZ olunsun\nLəğv et — bu fayl ötürülsün`);
      if (!ok) { state.drivers = JSON.parse(snapshot); continue; }
    }
    state.archive = state.archive.filter(r => !res.dates.includes(r.postingDate)).concat(res.rows).sort((a, b) => a.postingDate.localeCompare(b.postingDate));
    added += res.rows.length; created.push(...res.created); cardChanges.push(...res.cardChanges); dates.push(...res.dates);
    void before;
  }
  await persistDrivers(); await persistArchive();
  renderAll();
  if (!silent && added) {
    openModal({
      title: '✓ Excel hesabatı arxivə yazıldı',
      body: `<div class="import-summary">
        <div><b>${added}</b><span>qeyd arxivə yazıldı</span></div>
        <div><b>${[...new Set(dates)].length}</b><span>hesabat tarixi: ${[...new Set(dates)].map(fmtDate).join(', ')}</span></div>
        <div class="${created.length ? 'hl' : ''}"><b>${created.length}</b><span>yeni sürücü bazaya əlavə edildi</span></div>
        <div><b>${cardChanges.length}</b><span>kart nömrəsi yeniləndi</span></div></div>
        ${created.length ? `<p class="muted">Yeni sürücülər: ${created.map(esc).join(', ')}</p>` : ''}
        ${cardChanges.length ? `<p class="muted">Kartı yenilənənlər: ${cardChanges.map(esc).join(', ')}</p>` : ''}`,
      actions: [{ label: 'Arxivə bax', cls: 'primary', onClick: () => { closeModal(); const ds = [...new Set(dates)].sort(); $('#fromDate').value = ds[0]; $('#toDate').value = ds.at(-1); showView('archive'); } }]
    });
  }
  return added;
}
async function loadReyestr({ trips, stated }, fileName) {
  if (state.current.length && !confirm('Cari hesablama cədvəli yeni reyestrlə əvəz edilsin?')) return;
  state.currentTrips = trips; state.currentFile = fileName; state.current = [];
  const sum = r2(trips.reduce((a, t) => a + t.amount, 0));
  state.pdfCheck = { file: fileName, trips: trips.length, sum, stated, from: trips.map(t => t.date).filter(Boolean).sort()[0] || '', to: trips.map(t => t.date).filter(Boolean).sort().at(-1) || '' };
  aggregate();
  showView('calc'); renderAll(); persistDraft();
  const unknown = state.current.filter(r => !r.driverId).length;
  toast(`${trips.length} reys oxundu · ${state.current.length} sürücü üzrə toplandı`, 'ok');
  if (unknown) setTimeout(openNewCarWizard, 350);
}
function aggregate() {
  const keep = new Map(state.current.map(r => [r.driverId || 'u:' + r.plates[0], r]));
  const map = new Map();
  for (const t of state.currentTrips) {
    const d = driverByPlate(t.plate); const key = d ? d.id : `u:${t.plate}`;
    if (!map.has(key)) {
      const prev = keep.get(key);
      map.set(key, makeRow({ sourceFile: state.currentFile, driverId: d?.id || '', driverName: d?.name || t.name || 'YENİ MAŞIN', card: d?.card || '', payment: d?.payment || '', plates: [], trips: 0, income: 0,
        other: prev?.other || 0, otherNote: prev?.otherNote || '', feeDecision: prev?.feeDecision || '' }));
    }
    const x = map.get(key);
    if (!x.plates.includes(t.plate)) x.plates.push(t.plate);
    x.trips++; x.income = r2(x.income + t.amount);
    if (t.date && !x.sourceDates.includes(t.date)) x.sourceDates.push(t.date);
    if (t.name && !x.pdfNames.includes(t.name)) x.pdfNames.push(t.name);
  }
  // Maşınsız (sabit ödənişli) aktiv şəxslər
  for (const d of state.drivers.filter(d => d.manual && d.active !== false)) {
    const prev = keep.get(d.id);
    map.set(d.id, makeRow({ sourceFile: state.currentFile, driverId: d.id, driverName: d.name, card: d.card, payment: d.payment, manual: true, manualNet: prev?.manualNet || 0, other: prev?.other || 0, otherNote: prev?.otherNote || '' }));
  }
  state.current = [...map.values()];
  refreshFeeStates();
}

/* ---------------- Modal ---------------- */
function openModal({ title, body, actions = [], wide = false, onMount }) {
  $('#modalTitle').innerHTML = title; $('#modalBody').innerHTML = body;
  $('.modal-card').classList.toggle('wide', !!wide);
  const a = $('#modalActions'); a.innerHTML = '';
  const cancel = document.createElement('button'); cancel.textContent = 'Bağla'; cancel.onclick = closeModal; a.appendChild(cancel);
  for (const x of actions) { const b = document.createElement('button'); b.textContent = x.label; b.className = x.cls || ''; b.onclick = x.onClick; a.appendChild(b); }
  $('#modal').classList.remove('hidden');
  onMount && onMount($('#modalBody'));
}
function closeModal() { $('#modal').classList.add('hidden'); }
const payOpts = sel => { const list = [...new Set([...(state.settings.paymentForms || []), sel].filter(Boolean))]; return list.map(p => `<option ${p === sel ? 'selected' : ''}>${esc(p)}</option>`).join(''); };
const fv = (root, name) => root.querySelector(`[name="${name}"]`)?.value ?? '';
const driverOptions = (sel = '') => state.drivers.slice().sort((a, b) => a.name.localeCompare(b.name, 'az')).map(d => `<option value="${d.id}" ${d.id === sel ? 'selected' : ''}>${esc(d.name)}${d.plates.length ? ' · ' + esc(d.plates.join(', ')) : ''}</option>`).join('');

/* ---------------- Yeni maşın sehrbazı ---------------- */
function openNewCarWizard() {
  const unknown = state.current.filter(r => !r.driverId);
  if (!unknown.length) return toast('Yeni maşın yoxdur', 'ok');
  openModal({
    wide: true,
    title: `🚚 ${unknown.length} yeni maşın aşkar edildi`,
    body: `<p class="muted">Bu maşın nömrələri bazada yoxdur. Hər biri üçün yeni sürücü yaradın və ya mövcud sürücüyə bağlayın. Daxil edilmədən hesabat arxivə yazılmır.</p>
      <div class="wizard">${unknown.map(r => `
        <div class="wz-row" data-row="${r.id}">
          <div class="wz-plate"><span class="plate">${esc(r.plates.join(', '))}</span><small>${r.trips} reys · ${money(r.income)}</small><small>Reyestrdə: ${esc(r.pdfNames.join(' / ') || '—')}</small></div>
          <label>Bağla<select name="link"><option value="">➕ Yeni sürücü</option>${driverOptions()}</select></label>
          <label class="wz-new">Ad, soyad<input name="name" value="${esc(r.pdfNames[0] || '')}"></label>
          <label class="wz-new">Kart nömrəsi<input name="card" placeholder="4169 7388 ...."></label>
          <label class="wz-new">Ödəniş forması<select name="payment">${payOpts('DEBET KART')}</select></label>
        </div>`).join('')}</div>`,
    onMount: root => root.querySelectorAll('.wz-row').forEach(row => { const s = row.querySelector('[name=link]'); const t = () => row.classList.toggle('linked', !!s.value); s.onchange = t; t(); }),
    actions: [{ label: '✓ Bazaya daxil et', cls: 'success', onClick: async () => {
      const root = $('#modalBody'); let n = 0;
      for (const row of root.querySelectorAll('.wz-row')) {
        const r = state.current.find(x => x.id === row.dataset.row); if (!r) continue;
        const link = fv(row, 'link');
        if (link) { const d = driverById(link); for (const p of r.plates) if (!d.plates.includes(p)) d.plates.push(p); r.pdfNames.forEach(nm => addAlias(d, nm)); n++; }
        else {
          const name = fv(row, 'name').trim(); if (!name) { row.classList.add('shake'); continue; }
          const pc = parseCard(fv(row, 'card')); const payment = fv(row, 'payment');
          const d = newDriver({ name, plates: r.plates, card: pc.card, payment, createdAt: postingDate(), source: state.currentFile });
          r.pdfNames.forEach(nm => addAlias(d, nm)); n++;
        }
      }
      await persistDrivers(); aggregate(); renderAll(); persistDraft();
      const left = state.current.filter(r => !r.driverId).length;
      if (left) toast(`${left} maşın hələ daxil edilməyib — adı boş qalıb`, 'bad'); else { closeModal(); toast(`${n} maşın bazaya daxil edildi`, 'ok'); if (state.current.some(r => r.feeState === 'pending')) setTimeout(openFeeWizard, 300); }
    } }]
  });
}

/* ---------------- Xidmət haqqı sehrbazı ---------------- */
function openFeeWizard(onlyId) {
  const list = state.current.filter(r => onlyId ? r.id === onlyId : r.feeState === 'pending');
  if (!list.length) return toast('Ödənilməmiş xidmət haqqı yoxdur', 'ok');
  const month = monthOf(postingDate()), fee = num(state.settings.fee);
  openModal({
    wide: list.length > 1,
    title: `💳 ${monthLabel(month)} — xidmət haqqı ${onlyId ? '' : `(${list.length} sürücü ödəməyib)`}`,
    body: `<p class="muted">Hər sürücü ayda <b>${money(fee)}</b> xidmət haqqı ödəyir. Bu ay ödəniş qeydə alınmayıb — necə ödənildiyini yazın.</p>
      ${list.length > 1 ? `<div class="bulk-bar">Hamısına tətbiq et: <button data-all="deduct">Maaşdan tut</button><button data-all="cash">Nağd ödəyib</button><button data-all="defer">Sonraya saxla</button></div>` : ''}
      <div class="fee-list">${list.map(r => `
        <div class="fee-item" data-row="${r.id}">
          <div><b>${esc(r.driverName)}</b><small>${esc(r.plates.join(', '))} · gəlir ${money(r.income)}</small></div>
          <select name="decision">${Object.entries(PAY_METHODS).map(([k, v]) => `<option value="${k}" ${(r.feeDecision || 'deduct') === k ? 'selected' : ''}>${v.replace('Maaşdan tutuldu', 'Maaşdan tut')}</option>`).join('')}</select>
          <input name="amount" type="number" step="0.01" value="${r.feeAmount || fee}">
        </div>`).join('')}</div>`,
    onMount: root => root.querySelectorAll('[data-all]').forEach(b => b.onclick = () => root.querySelectorAll('[name=decision]').forEach(s => s.value = b.dataset.all)),
    actions: [{ label: '✓ Yaz və davam et', cls: 'success', onClick: () => {
      for (const it of $('#modalBody').querySelectorAll('.fee-item')) {
        const r = state.current.find(x => x.id === it.dataset.row); if (!r) continue;
        r.feeDecision = fv(it, 'decision'); r.feeAmount = num(fv(it, 'amount')) || fee;
      }
      refreshFeeStates(); renderAll(); persistDraft(); closeModal(); toast('Xidmət haqqı qərarları yazıldı', 'ok');
    } }]
  });
}

/* ---------------- Cari sətir düzəlişi ---------------- */
function editCurrent(id) {
  const r = state.current.find(x => x.id === id); if (!r) return;
  if (!r.driverId) return openNewCarWizard();
  const d = driverById(r.driverId);
  openModal({
    title: `✎ ${esc(r.driverName)}`,
    body: `<div class="form-grid">
      <label>Sürücü adı<input name="name" value="${esc(d.name)}"></label>
      <label>Kart nömrəsi<input name="card" value="${esc(d.card)}"></label>
      <label>Ödəniş forması<select name="payment">${payOpts(d.payment || 'DEBET KART')}</select></label>
      ${r.manual ? (r.linkedShare ? `<label>Əlinə çatan (avtomatik)<input value="${fmtNum(r.manualNet)} ₼ — ${esc(r.linkedShare)} payı + xidmət haqqı" disabled></label>` : `<label>Əlinə çatan (sabit)<input name="manualNet" type="number" step="0.01" value="${r.manualNet}"></label>`) : `<label>Gəlirlər<input name="income" type="number" step="0.01" value="${r.income}"></label>`}
      <label>Digər tutulma (borc və s.)<input name="other" type="number" step="0.01" value="${r.other}"></label>
      <label>Tutulma qeydi<input name="otherNote" value="${esc(r.otherNote)}" placeholder="məs. avans"></label>
    </div><p class="muted">Ad, kart və ödəniş forması dəyişiklikləri sürücü bazasına da yazılır.</p>`,
    actions: [
      ...(r.feeState === 'exempt' || r.manual ? [] : [{ label: '💳 Xidmət haqqı', onClick: () => openFeeWizard(r.id) }]),
      { label: '✓ Yadda saxla', cls: 'primary', onClick: async () => {
        const root = $('#modalBody'); const pc = parseCard(fv(root, 'card'));
        d.name = upperAz(fv(root, 'name')) || d.name; d.card = pc.card; d.payment = fv(root, 'payment');
        Object.assign(r, { driverName: d.name, card: d.card, payment: d.payment, other: num(fv(root, 'other')), otherNote: fv(root, 'otherNote') });
        if (r.manual) { if (!r.linkedShare) r.manualNet = num(fv(root, 'manualNet')); } else r.income = num(fv(root, 'income'));
        calc(r); refreshFeeStates(); await persistDrivers(); renderAll(); persistDraft(); closeModal();
      } }]
  });
}
function addManualRow() {
  openModal({
    title: '＋ Əl ilə sətir (maşınsız / sabit ödəniş)',
    body: `<div class="form-grid"><label>Şəxs<select name="driver"><option value="">➕ Yeni şəxs</option>${driverOptions()}</select></label>
      <label>Yeni şəxsin adı<input name="name"></label><label>Kart nömrəsi<input name="card"></label>
      <label>Əlinə çatan (₼)<input name="net" type="number" step="0.01"></label></div>`,
    actions: [{ label: '✓ Əlavə et', cls: 'primary', onClick: async () => {
      const root = $('#modalBody'); let d = driverById(fv(root, 'driver'));
      if (!d) { const name = fv(root, 'name').trim(); if (!name) return toast('Ad yazın', 'bad'); const pc = parseCard(fv(root, 'card')); d = newDriver({ name, card: pc.card, payment: pc.payment || 'DEBET KART', manual: true, feeExempt: true }); await persistDrivers(); }
      state.current = state.current.filter(x => x.driverId !== d.id);
      state.current.push(makeRow({ driverId: d.id, driverName: d.name, card: d.card, payment: d.payment, plates: d.manual ? [] : d.plates, manual: true, manualNet: num(fv(root, 'net')), sourceFile: state.currentFile }));
      refreshFeeStates(); renderAll(); persistDraft(); closeModal();
    } }]
  });
}

/* ---------------- Arxivə yazma ---------------- */
async function saveCurrentToArchive() {
  if (!state.current.length) return toast('Əvvəl reyestr əlavə edin', 'bad');
  if (state.current.some(r => !r.driverId)) { toast('Yeni maşınlar bazaya daxil edilməyib', 'bad'); return openNewCarWizard(); }
  refreshFeeStates();
  if (state.current.some(r => r.feeState === 'pending')) { renderAll(); toast('Xidmət haqqı ödəməyən sürücülər var — əvvəl yazın', 'bad'); return openFeeWizard(); }
  const date = postingDate();
  const rows = state.current.filter(r => !(r.manual && !(r.manualNet > 0)));
  const skipped = state.current.length - rows.length;
  const clash = state.archive.filter(r => r.postingDate === date);
  if (clash.length && !confirm(`${fmtDate(date)} tarixində arxivdə artıq ${clash.length} qeyd var. Yeni qeydlər onlara ƏLAVƏ edilsin?`)) return;
  const month = monthOf(date);
  for (const r of rows) {
    if (['cash', 'transfer', 'waive'].includes(r.feeDecision)) {
      state.payments = state.payments.filter(p => !(p.driverId === r.driverId && p.month === month));
      state.payments.push({ id: uid(), driverId: r.driverId, month, amount: r.feeDecision === 'waive' ? 0 : (r.feeAmount || num(state.settings.fee)), method: r.feeDecision, date, note: 'Hesabatdan' });
    }
    if (r.feeDecision !== 'deduct') r.service = 0;
  }
  state.archive.push(...rows.map(r => makeRow({ ...r, id: uid(), postingDate: date, feeDecision: r.feeDecision === 'deduct' ? 'deduct' : '' })));
  state.archive.sort((a, b) => a.postingDate.localeCompare(b.postingDate));
  state.current = []; state.currentTrips = []; state.pdfCheck = null; state.currentFile = '';
  await persistArchive(); await persistPayments(); persistDraft();
  renderAll();
  openModal({
    title: '✓ Hesabat arxivə yazıldı',
    body: `<div class="import-summary"><div><b>${rows.length}</b><span>sürücü · ${fmtDate(date)}</span></div><div><b>${money(rows.reduce((a, r) => a + r.income, 0))}</b><span>ümumi gəlir</span></div><div><b>${money(rows.reduce((a, r) => a + r.net, 0))}</b><span>əlinə çatan</span></div><div><b>${rows.filter(r => r.service > 0).length}</b><span>xidmət haqqı tutuldu</span></div></div>${skipped ? `<p class="muted">${skipped} boş sabit ödəniş sətri ötürüldü.</p>` : ''}`,
    actions: [
      { label: '▣ Arxivdə aç', onClick: () => { closeModal(); $('#fromDate').value = date; $('#toDate').value = date; showView('archive'); } },
      { label: '👔 Direktor hesabatı', cls: 'primary', onClick: () => { closeModal(); showView('director'); $('#dirDate').value = date; renderDirector(); } }
    ]
  });
}

/* ---------------- Render: Hesablama ---------------- */
function feeCell(r) {
  const fee = money(r.service);
  switch (r.feeState) {
    case 'new': return '<span class="tag gray">—</span>';
    case 'exempt': return '<span class="tag gray">azad</span>';
    case 'paid': return `<span class="tag green" title="${esc(PAY_METHODS[r.paidInfo?.kind] || 'ödənib')} ${fmtDate(r.paidInfo?.date)}">✓ bu ay ödənib</span>`;
    case 'pending': return `<button class="fee-pill blink" data-fee="${r.id}">${money(state.settings.fee)} ÖDƏNİLMƏYİB</button>`;
    default: return r.feeDecision === 'deduct' ? `<button class="fee-link" data-fee="${r.id}">${fee}<small>maaşdan</small></button>` : `<button class="fee-link" data-fee="${r.id}">${fmtNum(0)}<small>${esc((PAY_METHODS[r.feeDecision] || '').toLowerCase())}</small></button>`;
  }
}
function renderCurrent() {
  const b = $('#currentBody'), f = $('#currentFoot');
  if (!state.current.length) { $('#feeAll').checked = false; $('#feeAll').disabled = true; $('#feeAllCount').textContent = ''; b.innerHTML = `<tr><td colspan="16" class="empty">Hələ reyestr əlavə edilməyib. PDF və ya Excel faylını yuxarıdakı sahəyə atın.</td></tr>`; f.innerHTML = ''; return; }
  const sorted = [...state.current].sort((a, b) => (!a.driverId) - (!b.driverId) || (b.feeState === 'pending') - (a.feeState === 'pending') || a.driverName.localeCompare(b.driverName, 'az'));
  b.innerHTML = sorted.map((r, i) => {
    const d = driverById(r.driverId), isNew = !r.driverId, newThisMonth = d && monthOf(d.createdAt) === monthOf(postingDate()) && !d.manual;
    const cls = isNew ? 'row-new' : r.feeState === 'pending' ? 'row-alert' : '';
    const pdfHint = r.pdfNames.length && d && !r.pdfNames.some(n => loose(n) === loose(d.name)) ? `<small class="pdf-name">reyestrdə: ${esc(r.pdfNames.join(' / '))}</small>` : '';
    return `<tr class="${cls}">
      <td>${i + 1}</td>
      <td class="name-cell">${isNew ? '<span class="tag amber blink">YENİ MAŞIN</span> ' : ''}${newThisMonth ? '<span class="tag sky">yeni</span> ' : ''}${esc(r.driverName)}${pdfHint}</td>
      <td>${esc(cardText(r)) || (isNew ? '—' : '<span class="tag red">kart yoxdur</span>')}</td><td>${esc(r.payment)}</td><td>${r.manual ? '—' : r.plates.length}</td>
      <td>${fmtDate(r.postingDate)}</td><td>${r.manual ? '<span class="tag gray">sabit ödəniş</span>' : esc(r.plates.join(', '))}</td><td>${r.trips || ''}</td>
      <td class="money">${r.manual ? '—' : fmtNum(r.income)}</td><td>${fmtNum(r.cash)}</td><td>${fmtNum(r.incomeTax)}</td>
      <td>${feeCell(r)}</td><td>${r.other ? `<span title="${esc(r.otherNote)}">${fmtNum(r.other)}</span>` : fmtNum(0)}</td>
      <td class="money">${fmtNum(r.totalDeduction)}</td><td class="money net">${r.linkedShare ? `${fmtNum(r.net)}<small class="auto">avto · ${esc(r.linkedShare)}</small>` : r.manual && !r.manualNet ? `<button class="fee-pill" data-edit="${r.id}">məbləğ yazın</button>` : fmtNum(r.net)}</td>
      <td><div class="row-actions">${isNew ? `<button class="warn" data-wizard="1">Daxil et</button>` : `<button data-edit="${r.id}">Düzəliş</button>`}<button class="danger" data-del="${r.id}">Sil</button></div></td></tr>`;
  }).join('');
  const elig = state.current.filter(r => r.feeState === 'pending' || r.feeState === 'decided');
  const ded = elig.filter(r => r.feeDecision === 'deduct').length, box = $('#feeAll');
  box.disabled = !elig.length; box.checked = !!elig.length && ded === elig.length; box.indeterminate = ded > 0 && ded < elig.length;
  $('#feeAllCount').textContent = elig.length ? `${ded}/${elig.length}` : '';
  const t = k => state.current.reduce((a, r) => a + num(r[k]), 0);
  f.innerHTML = `<tr><td colspan="7">ÜMUMİ CƏM</td><td>${t('trips')}</td><td class="money">${fmtNum(t('income'))}</td><td>${fmtNum(t('cash'))}</td><td>${fmtNum(t('incomeTax'))}</td><td>${fmtNum(t('service'))}</td><td>${fmtNum(t('other'))}</td><td class="money">${fmtNum(t('totalDeduction'))}</td><td class="money">${fmtNum(t('net'))}</td><td></td></tr>`;
}
function renderChecklist() {
  const c = state.pdfCheck, unknown = state.current.filter(r => !r.driverId).length, pending = state.current.filter(r => r.feeState === 'pending').length;
  const steps = [
    { done: !!c, title: 'Reyestr oxundu', text: c ? `${esc(c.file)} · ${c.trips} reys${c.from ? ` · ${fmtDate(c.from)} – ${fmtDate(c.to)}` : ''}` : 'PDF və ya Excel reyestri əlavə edin' },
    { done: c && !unknown, warn: unknown > 0, title: unknown ? `${unknown} yeni maşın` : 'Maşınlar bazada var', text: unknown ? 'Bazaya daxil edilməlidir' : (c ? 'Bütün maşın nömrələri tanındı' : '—'), btn: unknown ? '<button class="warn" data-wizard="1">Daxil et</button>' : '' },
    { done: c && !pending && !unknown, alert: pending > 0, title: pending ? `${pending} sürücü xidmət haqqı ödəməyib` : 'Xidmət haqqı yoxlandı', text: pending ? `${monthLabel(monthOf(postingDate()))} üçün ${money(state.settings.fee)}` : (c ? 'Hamısı ödəyib və ya qərar yazılıb' : '—'), btn: pending ? '<button class="danger-solid" data-feewiz="1">Yaz</button>' : '' },
    { done: false, ready: c && !pending && !unknown, title: 'Arxivə yaz', text: c && !pending && !unknown ? 'Hazırdır — "Arxivə yaz" düyməsini basın' : 'Yuxarıdakı addımlar tamamlanmalıdır' }
  ];
  $('#checklist').innerHTML = `<div class="cl-head"><small>YOXLAMA MƏRKƏZİ</small><b>${steps.filter(s => s.done).length}/3 addım</b></div>` + steps.map((s, i) => `
    <div class="cl-step ${s.done ? 'done' : ''} ${s.warn ? 'warn' : ''} ${s.alert ? 'alert' : ''} ${s.ready ? 'ready' : ''}">
      <i>${s.done ? '✓' : s.alert ? '!' : i + 1}</i><div><b>${s.title}</b><span>${s.text}</span></div>${s.btn || ''}</div>`).join('');
  $('#saveArchive').classList.toggle('pulse-ready', !!(c && !pending && !unknown));
  const pc = $('#pdfCheck');
  if (c && c.stated != null) {
    const diff = r2(c.sum - c.stated);
    pc.className = `pdf-check ${diff ? 'bad' : 'ok'}`;
    pc.innerHTML = diff ? `⚠ Reyestrdə yekun <b>${money(c.stated)}</b>, oxunan reyslərin cəmi isə <b>${money(c.sum)}</b>. Fərq: <b>${money(diff)}</b> — sətirləri yoxlayın.` : `✓ Yoxlama: reyestrin yekunu <b>${money(c.stated)}</b> oxunan ${c.trips} reysin cəmi ilə tam üst-üstə düşür.`;
  } else pc.className = 'pdf-check hidden';
  const nb = $('#navCalcBadge'); nb.textContent = unknown + pending; nb.classList.toggle('hidden', !(unknown + pending));
}
function updateStats() {
  const t = k => state.current.reduce((a, r) => a + num(r[k]), 0);
  $('#statTotal').textContent = money(t('income')); $('#statRows').textContent = `${t('trips')} reys`;
  $('#statDrivers').textContent = state.current.length; $('#statPlates').textContent = `${new Set(state.current.flatMap(r => r.plates)).size} maşın`;
  $('#statDeductions').textContent = money(t('totalDeduction')); $('#statNet').textContent = money(t('net'));
}

/* ---------------- Render: Arxiv ---------------- */
function filteredArchive() {
  const f = $('#fromDate').value, t = $('#toDate').value, n = loose($('#filterName').value), p = normalizePlate($('#filterPlate').value).replace(/\s/g, '');
  return state.archive.filter(r => (!f || r.postingDate >= f) && (!t || r.postingDate <= t) && (!n || loose(r.driverName).includes(n)) && (!p || r.plates.some(x => x.replace(/\s/g, '').includes(p))));
}
function renderArchive() {
  state.filtered = filteredArchive();
  const groups = {}; for (const r of state.archive) (groups[r.postingDate] ||= []).push(r);
  const f = $('#fromDate').value, t = $('#toDate').value;
  $('#reportStrip').innerHTML = Object.entries(groups).sort((a, b) => b[0].localeCompare(a[0])).map(([d, rows]) => `
    <button class="rep-chip ${f === d && t === d ? 'on' : ''}" data-date="${d}"><b>${fmtDate(d)}</b><span>${rows.length} sürücü</span><em>${money(rows.reduce((a, r) => a + r.income, 0))}</em></button>`).join('') || '<p class="muted">Arxiv boşdur.</p>';
  const b = $('#archiveBody');
  b.innerHTML = state.filtered.map((r, i) => `<tr>
    <td>${i + 1}</td><td class="name-cell">${esc(r.driverName)}</td><td>${esc(cardText(r))}</td><td>${esc(r.payment)}</td><td>${r.manual ? '' : r.plates.length}</td><td>${fmtDate(r.postingDate)}</td><td>${esc(r.plates.join(', '))}</td>
    <td class="money">${r.manual ? '' : fmtNum(r.income)}</td><td>${fmtNum(r.cash)} <small class="rate">${r.manual ? '' : pctTxt(r.cashRate)}</small></td><td>${fmtNum(r.incomeTax)} <small class="rate">${r.manual ? '' : pctTxt(r.taxRate)}</small></td>
    <td>${r.service ? `<span class="tag green">${fmtNum(r.service)}</span>` : fmtNum(0)}</td><td>${fmtNum(r.other)}</td><td class="money">${fmtNum(r.totalDeduction)}</td><td class="money net">${fmtNum(r.net)}</td>
    <td><div class="row-actions"><button data-aedit="${r.id}">Düzəliş</button><button class="danger" data-adel="${r.id}">Sil</button></div></td></tr>`).join('') || '<tr><td colspan="15" class="empty">Filtrə uyğun qeyd yoxdur.</td></tr>';
  const s = k => state.filtered.reduce((a, r) => a + num(r[k]), 0);
  $('#archiveFoot').innerHTML = state.filtered.length ? `<tr><td colspan="7">ÜMUMİ CƏM</td><td class="money">${fmtNum(s('income'))}</td><td>${fmtNum(s('cash'))}</td><td>${fmtNum(s('incomeTax'))}</td><td>${fmtNum(s('service'))}</td><td>${fmtNum(s('other'))}</td><td class="money">${fmtNum(s('totalDeduction'))}</td><td class="money">${fmtNum(s('net'))}</td><td></td></tr>` : '';
  $('#archiveSummary').textContent = `${state.filtered.length} qeyd · Gəlir: ${money(s('income'))} · Əlinə çatan: ${money(s('net'))}`;
}
function editArchive(id) {
  const r = state.archive.find(x => x.id === id); if (!r) return;
  openModal({
    title: `✎ Arxiv qeydi — ${esc(r.driverName)}`,
    body: `<div class="form-grid">
      <label>Tarix<input name="date" type="date" value="${r.postingDate}"></label>
      <label>Sürücü<select name="driver">${driverOptions(r.driverId)}</select></label>
      <label>Kart nömrəsi<input name="card" value="${esc(cardText(r))}"></label>
      <label>Maşın nömrələri<input name="plates" value="${esc(r.plates.join(', '))}"></label>
      ${r.manual ? `<label>Əlinə çatan (sabit)<input name="manualNet" type="number" step="0.01" value="${r.manualNet}"></label>` : `<label>Gəlirlər<input name="income" type="number" step="0.01" value="${r.income}"></label>
      <label>Nağdlaşdırma %<input name="cashRate" type="number" step="0.01" value="${r.cashRate}"></label><label>Gəlir vergisi %<input name="taxRate" type="number" step="0.01" value="${r.taxRate}"></label>`}
      <label>Xidmət haqqı<input name="service" type="number" step="0.01" value="${r.service}"></label>
      <label>Digər tutulma<input name="other" type="number" step="0.01" value="${r.other}"></label>
    </div>`,
    actions: [{ label: '✓ Yadda saxla', cls: 'primary', onClick: async () => {
      const root = $('#modalBody'), d = driverById(fv(root, 'driver')), pc = parseCard(fv(root, 'card'));
      Object.assign(r, { postingDate: fv(root, 'date') || r.postingDate, driverId: d?.id || r.driverId, driverName: d?.name || r.driverName, card: pc.card, payment: pc.payment || r.payment, plates: splitPlates(fv(root, 'plates')), service: num(fv(root, 'service')), other: num(fv(root, 'other')) });
      if (r.manual) r.manualNet = num(fv(root, 'manualNet')); else Object.assign(r, { income: num(fv(root, 'income')), cashRate: num(fv(root, 'cashRate')), taxRate: num(fv(root, 'taxRate')) });
      calc(r); await persistArchive(); renderAll(); closeModal(); toast('Arxiv qeydi yeniləndi', 'ok');
    } }]
  });
}
async function clearArchiveSelection() {
  if (!state.archive.length) return toast('Arxiv boşdur');
  const from = $('#fromDate').value, to = $('#toDate').value;
  let pred, label;
  if (from || to) { pred = r => (!from || r.postingDate >= from) && (!to || r.postingDate <= to); label = `${from ? fmtDate(from) : 'ilk tarix'} – ${to ? fmtDate(to) : 'son tarix'} aralığı`; }
  else { const last = state.archive.reduce((m, r) => r.postingDate > m ? r.postingDate : m, ''); pred = r => r.postingDate === last; label = `${fmtDate(last)} tarixli son hesabat`; }
  const n = state.archive.filter(pred).length; if (!n) return toast('Silinəcək qeyd yoxdur');
  if (!confirm(`${label} üzrə ${n} qeyd silinsin?`)) return;
  state.archive = state.archive.filter(r => !pred(r)); await persistArchive(); renderAll(); toast(`${n} qeyd silindi`, 'ok');
}

/* ---------------- Export (formatlı Excel + Azərbaycan şriftli PDF) ---------------- */
function rateLabel(rows, key, fallback) { const s = new Set(rows.filter(r => !r.manual).map(r => r[key])); return s.size === 1 ? pctTxt([...s][0]) : fallback; }
function reportAoa(rows) {
  const head = ['S/N', 'A.S.A.', 'KART NÖMRƏSİ', 'ÖDƏNİŞ FORMASI', 'MAŞIN SAYI', 'TARİX', 'MAŞIN NÖMRƏSİ', 'GƏLİRLƏR', `${rateLabel(rows, 'cashRate', '')} NAĞDLAŞDIRMA`.trim(), 'XİDMƏT HAQQI', `${rateLabel(rows, 'taxRate', '')} GƏLİR VERGİSİ`.trim(), 'DİGƏR TUTULMA', 'CƏMİ TUTULAN', 'ƏLİNƏ ÇATAN'];
  const body = rows.map((r, i) => [i + 1, r.driverName, cardText(r), r.payment, r.manual ? '' : r.plates.length, fmtDate(r.postingDate), r.plates.join(', '), r.manual ? '' : r.income, r.manual ? '' : r.cash, r.service, r.manual ? '' : r.incomeTax, r.other, r.totalDeduction, r.net]);
  const s = k => r2(rows.reduce((a, r) => a + num(r[k]), 0));
  return [head, ...body, ['', 'ÜMUMİ CƏM', '', '', '', '', '', s('income'), s('cash'), s('service'), s('incomeTax'), s('other'), s('totalDeduction'), s('net')]];
}
function fileStamp(rows = state.filtered) { const ds = [...new Set(rows.map(r => r.postingDate))].sort(); return ds.length === 1 ? ds[0] : `${ds[0]}_${ds.at(-1)}`; }
const datesText = rows => { const ds = [...new Set(rows.map(r => r.postingDate))].sort(); return ds.length === 1 ? fmtDate(ds[0]) : `${fmtDate(ds[0])} – ${fmtDate(ds.at(-1))}`; };

/* Formatlı cədvəl vərəqi: başlıq + alt başlıq + cədvəl + cəm sətri */
function gridSheet({ name, title, sub, head, body, foot, cols, numCols = [], centerCols = [], boldCols = [], landscape = true }) {
  const n = head.length, last = XLSXStyled.col(n - 1);
  const rows = [
    { h: 26, cells: [{ v: title, s: 'title' }] },
    { h: 18, cells: [{ v: sub, s: 'sub' }] },
    { h: 8, cells: [] },
    { h: 32, cells: head.map(v => ({ v, s: 'head' })) },
    ...body.map((r, i) => ({ h: 19, cells: r.map((v, c) => { const z = i % 2 ? 'zebra' : ''; const k = numCols.includes(c) ? (boldCols.includes(c) ? 'NumB' : 'Num') : centerCols.includes(c) ? 'C' : boldCols.includes(c) ? 'B' : ''; return { v, s: z ? (z + (k || '')) : ({ Num: 'num', NumB: 'numB', C: 'cellC', B: 'cellB' }[k] || 'cell') }; }) }))
  ];
  if (foot) rows.push({ h: 22, cells: foot.map((v, c) => ({ v, s: numCols.includes(c) && typeof v === 'number' ? 'totalNum' : 'total' })) });
  return { name, cols, rows, merges: [`A1:${last}1`, `A2:${last}2`], freeze: 4, landscape };
}
function exportExcel() {
  if (!state.filtered.length) return toast('Yükləmək üçün qeyd yoxdur', 'bad');
  const aoa = reportAoa(state.filtered), S = state.settings;
  XLSXStyled.download(`SURUCULER_ETRAFLI_HESABAT_${fileStamp()}.xlsx`, [gridSheet({
    name: 'Ətraflı hesabat', title: 'SÜRÜCÜLƏRİN ƏTRAFLI HESABATI', sub: `${S.company} · VÖEN ${S.voen} · Hesabat tarixi: ${datesText(state.filtered)} · ${state.filtered.length} qeyd`,
    head: aoa[0], body: aoa.slice(1, -1), foot: aoa.at(-1), cols: [6, 30, 22, 14, 9, 12, 20, 13, 14, 12, 14, 12, 13, 14],
    numCols: [7, 8, 9, 10, 11, 12, 13], centerCols: [0, 3, 4, 5, 6], boldCols: [1, 13]
  })]);
}
function exportCardExcel() {
  if (!state.filtered.length) return toast('Yükləmək üçün qeyd yoxdur', 'bad');
  const S = state.settings, total = r2(state.filtered.reduce((a, r) => a + r.net, 0));
  XLSXStyled.download(`KARTA_KOCURME_${fileStamp()}.xlsx`, [gridSheet({
    name: 'Karta köçürmə', title: 'KARTA KÖÇÜRMƏ SİYAHISI', sub: `${S.company} · ${datesText(state.filtered)} · ${state.filtered.length} nəfər`, landscape: false,
    head: ['S/N', 'A.S.A.', 'KART NÖMRƏSİ', 'ÖDƏNİŞ FORMASI', 'ƏLİNƏ ÇATAN'], body: state.filtered.map((r, i) => [i + 1, r.driverName, cardText(r), r.payment, r.net]),
    foot: ['', 'ÜMUMİ CƏM', '', '', total], cols: [6, 32, 26, 16, 16], numCols: [4], centerCols: [0, 2, 3], boldCols: [1, 4]
  })]);
}

/* PDF köməkçiləri */
function newPdf(orientation = 'portrait') {
  const { jsPDF } = window.jspdf, doc = new jsPDF({ orientation, unit: 'mm', format: 'a4' });
  doc._az = false;
  if (window.SG_FONTS) {
    try { doc.addFileToVFS('DV.ttf', SG_FONTS.regular); doc.addFont('DV.ttf', 'DV', 'normal'); doc.addFileToVFS('DVB.ttf', SG_FONTS.bold); doc.addFont('DVB.ttf', 'DV', 'bold'); doc.setFont('DV', 'normal'); doc._az = true; } catch (e) { console.warn('PDF şrifti', e); }
  }
  return doc;
}
const pT = (doc, s) => { s = String(s ?? '').replace(/₼/g, 'AZN'); return doc._az ? fixCyr(s) : translit(s); };
const pF = (doc, bold) => doc._az ? doc.setFont('DV', bold ? 'bold' : 'normal') : doc.setFont('helvetica', bold ? 'bold' : 'normal');
const C = { navy: [11, 59, 125], ink: [11, 28, 63], muted: [107, 122, 148], line: [201, 214, 232], soft: [238, 243, 250], soft2: [220, 231, 246], zebra: [247, 249, 253] };
function pdfHeader(doc, { title, left, right }) {
  const W = doc.internal.pageSize.getWidth();
  doc.setFillColor(...C.navy); doc.rect(0, 0, W, 24, 'F');
  doc.setTextColor(255); pF(doc, false); doc.setFontSize(8); doc.text(pT(doc, left), 12, 9);
  pF(doc, true); doc.setFontSize(15); doc.text(pT(doc, title), 12, 17.5);
  pF(doc, false); doc.setFontSize(9); doc.text(pT(doc, right), W - 12, 17.5, { align: 'right' });
  doc.setTextColor(...C.ink); return 32;
}
function pdfFooter(doc) {
  const n = doc.getNumberOfPages(), W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
  for (let i = 1; i <= n; i++) { doc.setPage(i); pF(doc, false); doc.setFontSize(7); doc.setTextColor(...C.muted); doc.text(pT(doc, `${state.settings.company} · AMMO SUITE · ${new Date().toLocaleString('az-AZ')}`), 12, H - 6); doc.text(`${i} / ${n}`, W - 12, H - 6, { align: 'right' }); }
}
/* Ümumi cədvəl: align 'l' | 'r' | 'c'; rowStyle(i) => 'sum' | 'final' | '' */
function pdfGrid(doc, { y, head, rows, widths, align = [], foot, fontSize = 7, rowH = 6.4, rowStyle, headH = 9 }) {
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), total = widths.reduce((a, b) => a + b, 0), x0 = (W - total) / 2;
  const lh = fontSize * 0.42;
  const fmtCell = (txt, a) => pT(doc, typeof txt === 'number' ? (a === 'c' && Number.isInteger(txt) ? String(txt) : fmtNum(txt)) : txt);
  const linesOf = (txt, w, a) => doc.splitTextToSize(fmtCell(txt, a), w - 3);
  const cellText = (txt, x, w, yy, a, h) => { const ls = linesOf(txt, w, a); const ty = yy + h / 2 - (ls.length - 1) * lh / 2 + fontSize * 0.13; if (a === 'r') doc.text(ls, x + w - 1.6, ty, { align: 'right' }); else if (a === 'c') doc.text(ls, x + w / 2, ty, { align: 'center' }); else doc.text(ls, x + 1.6, ty); };
  const drawHead = () => {
    doc.setFillColor(...C.navy); doc.rect(x0, y, total, headH, 'F'); doc.setTextColor(255); pF(doc, true); doc.setFontSize(fontSize - 0.6);
    let x = x0; head.forEach((h, i) => { const lines = doc.splitTextToSize(pT(doc, h), widths[i] - 2); doc.text(lines, x + widths[i] / 2, y + headH / 2 - (lines.length - 1) * 1.3 + 1, { align: 'center' }); x += widths[i]; });
    y += headH; doc.setTextColor(...C.ink); pF(doc, false); doc.setFontSize(fontSize);
  };
  drawHead();
  const baseH = rowH;
  rows.forEach((row, ri) => {
    const st = rowStyle ? rowStyle(ri) : '';
    pF(doc, !!st); const maxL = Math.max(1, ...row.map((v, i) => linesOf(v, widths[i], align[i] || (typeof v === 'number' ? 'r' : 'l')).length)); pF(doc, false);
    rowH = Math.max(baseH, maxL * lh + 3.2);
    if (y + rowH > H - 14) { doc.addPage(); y = 14; drawHead(); }
    if (st === 'final') { doc.setFillColor(...C.navy); doc.rect(x0, y, total, rowH, 'F'); doc.setTextColor(255); pF(doc, true); }
    else if (st === 'sum') { doc.setFillColor(...C.soft2); doc.rect(x0, y, total, rowH, 'F'); pF(doc, true); }
    else if (ri % 2) { doc.setFillColor(...C.zebra); doc.rect(x0, y, total, rowH, 'F'); }
    doc.setDrawColor(...C.line); doc.setLineWidth(0.15); doc.line(x0, y + rowH, x0 + total, y + rowH);
    let x = x0; row.forEach((v, i) => { cellText(v, x, widths[i], y, align[i] || (typeof v === 'number' ? 'r' : 'l'), rowH); x += widths[i]; });
    if (st) { doc.setTextColor(...C.ink); pF(doc, false); }
    y += rowH;
  });
  rowH = baseH;
  if (foot) { doc.setFillColor(...C.soft2); doc.rect(x0, y, total, rowH + 1, 'F'); doc.setDrawColor(...C.navy); doc.setLineWidth(0.4); doc.line(x0, y, x0 + total, y); pF(doc, true); let x = x0; foot.forEach((v, i) => { cellText(v, x, widths[i], y, align[i] || (typeof v === 'number' ? 'r' : 'l'), rowH + 1); x += widths[i]; }); pF(doc, false); y += rowH + 1; }
  return y;
}
function exportPdf() {
  if (!state.filtered.length) return toast('Yükləmək üçün qeyd yoxdur', 'bad');
  const doc = newPdf('landscape'), aoa = reportAoa(state.filtered), S = state.settings;
  const y = pdfHeader(doc, { title: 'SÜRÜCÜLƏRİN ƏTRAFLI HESABATI', left: `${S.company} · VÖEN ${S.voen}`, right: `Hesabat tarixi: ${datesText(state.filtered)} · ${state.filtered.length} qeyd` });
  pdfGrid(doc, { y, head: aoa[0], rows: aoa.slice(1, -1), foot: aoa.at(-1), fontSize: 6.8, widths: [9, 40, 32, 20, 11, 17, 22, 18, 18, 15, 18, 15, 18, 20], align: ['c', 'l', 'c', 'c', 'c', 'c', 'c'] });
  pdfFooter(doc); doc.save(`SURUCULER_HESABAT_${fileStamp()}.pdf`);
}

/* ---------------- Render: Sürücü paneli ---------------- */
function driverStatsFor(d) {
  const rows = state.archive.filter(r => r.driverId === d.id);
  return { rows, income: rows.reduce((a, r) => a + r.income, 0), net: rows.reduce((a, r) => a + r.net, 0), last: rows.reduce((m, r) => r.postingDate > m ? r.postingDate : m, ''), reports: new Set(rows.map(r => r.postingDate)).size };
}
function feeStatusThisMonth(d, month) {
  if (d.feeExempt || d.manual) return { cls: 'gray', text: 'Xidmət haqqından azad' };
  const rec = feeRecord(d.id, month);
  if (rec) return { cls: rec.kind === 'waive' ? 'gray' : 'green', text: rec.kind === 'waive' ? `${monthLabel(month)}: azad` : `${monthLabel(month)}: ödənib · ${PAY_METHODS[rec.kind] || ''}` };
  if (workedIn(d.id, month)) return { cls: 'red blink', text: `${monthLabel(month)}: ${money(state.settings.fee)} ÖDƏNİLMƏYİB`, unpaid: true };
  return { cls: 'gray', text: `${monthLabel(month)}: hələ işləməyib` };
}
function renderDrivers() {
  const month = monthOf(postingDate()), q = loose($('#driverSearch').value), flt = $('#driverFilter').value;
  const all = state.drivers.map(d => ({ d, st: driverStatsFor(d), fee: feeStatusThisMonth(d, month) }));
  const active = all.filter(x => x.d.active !== false);
  $('#driverStats').innerHTML = [
    ['Aktiv sürücü', active.length], ['Maşın', new Set(active.flatMap(x => x.d.plates)).size],
    ['Bu ay yeni', active.filter(x => monthOf(x.d.createdAt) === month && !x.d.manual).length], ['Bu ay ödəməyən', active.filter(x => x.fee.unpaid).length, 'red']
  ].map(([l, v, c]) => `<div class="ms ${c || ''}"><b>${v}</b><span>${l}</span></div>`).join('');
  $('#navDriversBadge').textContent = active.length;
  let list = all.filter(({ d }) => !q || loose([d.name, d.card, ...d.plates, ...(d.aliases || [])].join(' ')).includes(q));
  list = list.filter(({ d, fee }) => flt === 'all' ? true : flt === 'active' ? d.active !== false : flt === 'passive' ? d.active === false : flt === 'unpaid' ? fee.unpaid : flt === 'new' ? monthOf(d.createdAt) === month : flt === 'nocard' ? !d.card && d.payment !== 'ƏLBƏHƏL' : true);
  list.sort((a, b) => (b.fee.unpaid ? 1 : 0) - (a.fee.unpaid ? 1 : 0) || (a.d.active === false) - (b.d.active === false) || a.d.name.localeCompare(b.d.name, 'az'));
  $('#driverGrid').innerHTML = list.map(({ d, st, fee }) => `
    <article class="dcard ${d.active === false ? 'passive' : ''} ${fee.unpaid ? 'unpaid' : ''}">
      ${monthOf(d.createdAt) === month && !d.manual ? '<span class="ribbon">YENİ</span>' : ''}
      <header><div class="avatar">${esc(initials(d.name))}</div><div><b>${esc(d.name)}</b><small>${d.manual ? 'Maşınsız · sabit ödəniş' : `${d.plates.length} maşın`}${d.active === false ? ' · passiv' : ''}</small></div></header>
      <div class="plates">${d.plates.map(p => `<span class="plate">${esc(p)}</span>`).join('') || '<span class="muted">maşın yoxdur</span>'}</div>
      <div class="dinfo"><span>💳 ${esc(cardText(d)) || '<em class="tag red">kart yoxdur</em>'}</span>${d.phone ? `<span>📞 ${esc(d.phone)}</span>` : ''}</div>
      <div class="dnums"><div><small>Ümumi gəlir</small><b>${money(st.income)}</b></div><div><small>Hesabat</small><b>${st.reports}</b></div><div><small>Son</small><b>${st.last ? fmtDate(st.last) : '—'}</b></div></div>
      <div class="fee-status tag ${fee.cls}">${fee.text}</div>
      <footer><button data-dedit="${d.id}">✎ Düzəliş</button><button data-dhist="${d.id}">☰ Tarixçə</button>${!d.manual && !d.feeExempt ? `<button data-dpay="${d.id}">💳 Ödəniş</button>` : ''}</footer>
    </article>`).join('') || '<p class="muted pad">Heç nə tapılmadı.</p>';
}
function editDriver(id) {
  const d = id ? driverById(id) : null, isNew = !d;
  const x = d || { name: '', plates: [], card: '', payment: 'DEBET KART', phone: '', note: '', active: true, manual: false, feeExempt: false };
  openModal({
    title: isNew ? '＋ Yeni sürücü' : `✎ ${esc(x.name)}`,
    body: `<div class="form-grid">
      <label>Ad, soyad<input name="name" value="${esc(x.name)}"></label>
      <label>Maşın nömrələri (vergüllə)<input name="plates" value="${esc(x.plates.join(', '))}" placeholder="99 XX 999, 10 AB 123"></label>
      <label>Kart nömrəsi<input name="card" value="${esc(x.card)}"></label>
      <label>Ödəniş forması<select name="payment">${payOpts(x.payment || 'DEBET KART')}</select></label>
      <label>Telefon<input name="phone" value="${esc(x.phone || '')}"></label>
      <label>Qeyd<input name="note" value="${esc(x.note || '')}"></label>
      <label class="chk"><input type="checkbox" name="active" ${x.active !== false ? 'checked' : ''}> Aktiv</label>
      <label class="chk"><input type="checkbox" name="manual" ${x.manual ? 'checked' : ''}> Maşınsız (sabit ödəniş, hər hesabata avtomatik əlavə olunur)</label>
      <label class="chk"><input type="checkbox" name="feeExempt" ${x.feeExempt ? 'checked' : ''}> Xidmət haqqından azad</label>
      ${isNew ? '' : `<label>Başqa sürücü ilə birləşdir<select name="merge"><option value="">—</option>${driverOptions().replace(`value="${d.id}"`, `value="${d.id}" disabled`)}</select></label>`}
    </div>${!isNew && d.aliases?.length ? `<p class="muted">Reyestrdə görünən adlar: ${d.aliases.map(esc).join(', ')}</p>` : ''}`,
    actions: [
      ...(isNew ? [] : [{ label: '🗑 Sil', cls: 'danger', onClick: async () => {
        const used = state.archive.filter(r => r.driverId === d.id).length;
        if (!confirm(used ? `${d.name} arxivdə ${used} qeyddə var. Silmək əvəzinə "Passiv" etmək tövsiyə olunur. Yenə də silinsin?` : `${d.name} silinsin?`)) return;
        state.drivers = state.drivers.filter(y => y.id !== d.id); await persistDrivers(); aggregateIfAny(); renderAll(); closeModal();
      } }]),
      { label: '✓ Yadda saxla', cls: 'primary', onClick: async () => {
        const root = $('#modalBody'), name = upperAz(fv(root, 'name')); if (!name) return toast('Ad yazın', 'bad');
        const plates = splitPlates(fv(root, 'plates')), pc = parseCard(fv(root, 'card'));
        const conflict = plates.map(p => [p, driverByPlate(p)]).filter(([, o]) => o && o.id !== d?.id);
        if (conflict.length && !confirm(`${conflict.map(([p, o]) => `${p} → ${o.name}`).join('\n')}\n\nBu maşın(lar) başqa sürücüdədir. Bu sürücüyə köçürülsün?`)) return;
        const chk = n => root.querySelector(`[name=${n}]`).checked;
        const data = { name, plates, card: pc.card, payment: fv(root, 'payment'), phone: fv(root, 'phone'), note: fv(root, 'note'), active: chk('active'), manual: chk('manual'), feeExempt: chk('feeExempt') };
        let target = d;
        if (isNew) target = newDriver(data);
        else { for (const [p] of conflict) for (const o of state.drivers) if (o.id !== d.id) o.plates = o.plates.filter(y => y !== p); Object.assign(d, data); }
        const mergeId = !isNew && fv(root, 'merge');
        if (mergeId) {
          const other = driverById(mergeId);
          if (other && confirm(`${other.name} → ${d.name} ilə birləşdirilsin? Onun maşınları və arxiv qeydləri bu sürücüyə keçəcək.`)) {
            d.plates = [...new Set([...d.plates, ...other.plates])]; addAlias(d, other.name); (other.aliases || []).forEach(a => addAlias(d, a));
            state.archive.forEach(r => { if (r.driverId === other.id) r.driverId = d.id; });
            state.payments.forEach(p => { if (p.driverId === other.id) p.driverId = d.id; });
            state.drivers = state.drivers.filter(y => y.id !== other.id); await persistArchive(); await persistPayments();
          }
        }
        // cari cədvəli yenilə
        for (const r of state.current) if (r.driverId === target.id) Object.assign(r, { driverName: target.name, card: target.card, payment: target.payment });
        await persistDrivers(); aggregateIfAny(); renderAll(); closeModal(); toast(isNew ? 'Yeni sürücü əlavə edildi' : 'Sürücü yeniləndi', 'ok');
      } }]
  });
}
function aggregateIfAny() { if (state.currentTrips.length) { aggregate(); persistDraft(); } }
function driverHistory(id) {
  const d = driverById(id), { rows, income, net } = driverStatsFor(d);
  const months = [...new Set([...rows.map(r => monthOf(r.postingDate)), ...state.payments.filter(p => p.driverId === id).map(p => p.month)])].sort().reverse();
  openModal({
    wide: true, title: `☰ ${esc(d.name)} — tarixçə`,
    body: `<div class="import-summary"><div><b>${money(income)}</b><span>ümumi gəlir</span></div><div><b>${money(net)}</b><span>əlinə çatan</span></div><div><b>${rows.length}</b><span>qeyd</span></div></div>
      <h4 class="sub-h">Xidmət haqqı</h4><div class="month-pills">${months.map(m => { const rec = feeRecord(id, m); return `<span class="tag ${rec ? (rec.kind === 'waive' ? 'gray' : 'green') : 'red'}">${monthLabel(m)}: ${rec ? (rec.kind === 'waive' ? 'azad' : money(rec.amount)) : 'ödənməyib'}</span>`; }).join('') || '—'}</div>
      <h4 class="sub-h">Hesabatlar</h4><div class="table-wrap short"><table class="plain"><thead><tr><th>Tarix</th><th>Maşın</th><th>Gəlir</th><th>Tutulan</th><th>Xidmət</th><th>Əlinə çatan</th></tr></thead><tbody>
      ${rows.slice().reverse().map(r => `<tr><td>${fmtDate(r.postingDate)}</td><td>${esc(r.plates.join(', '))}</td><td class="money">${fmtNum(r.income)}</td><td>${fmtNum(r.totalDeduction)}</td><td>${fmtNum(r.service)}</td><td class="money">${fmtNum(r.net)}</td></tr>`).join('')}</tbody></table></div>`
  });
}

/* ---------------- Xidmət haqqı paneli (sadə siyahı) ---------------- */
function recordPayment(driverId, month) {
  const d = driverById(driverId), rec = feeRecord(driverId, month);
  openModal({
    title: `💳 ${esc(d.name)} — ${monthLabel(month)}`,
    body: rec ? `<p>Bu ay üçün qeyd var: <b>${PAY_METHODS[rec.kind] || rec.kind}</b> · ${money(rec.amount)} · ${fmtDate(rec.date)}${rec.rowId ? '<br><small class="muted">Hesabatda maaşdan tutulub — dəyişmək üçün arxiv qeydini düzəldin.</small>' : ''}${rec.current ? '<br><small class="muted">Cari hesablamada maaşdan tutulur.</small>' : ''}</p>` :
      `<div class="form-grid"><label>Necə ödəyib<select name="method"><option value="cash">Nağd ödəyib</option><option value="transfer">Köçürmə ilə ödəyib</option><option value="waive">Bu ay azad</option></select></label>
       <label>Məbləğ<input name="amount" type="number" step="0.01" value="${state.settings.fee}"></label><label>Tarix<input name="date" type="date" value="${isoToday()}"></label><label>Qeyd<input name="note"></label></div>`,
    actions: rec ? (rec.paymentId ? [{ label: 'Ödənişi ləğv et', cls: 'danger', onClick: async () => { state.payments = state.payments.filter(p => p.id !== rec.paymentId); await persistPayments(); refreshFeeStates(); renderAll(); closeModal(); } }] : []) :
      [{ label: '✓ Ödənişi yaz', cls: 'primary', onClick: async () => {
        const root = $('#modalBody'), method = fv(root, 'method');
        state.payments.push({ id: uid(), driverId, month, method, amount: method === 'waive' ? 0 : num(fv(root, 'amount')), date: fv(root, 'date') || isoToday(), note: fv(root, 'note') });
        await persistPayments(); refreshFeeStates(); renderAll(); closeModal(); toast('Ödəniş yazıldı', 'ok');
      } }]
  });
}
const feeMonthVal = () => $('#feeMonth').value || monthOf(postingDate());
function shiftFeeMonth(step) { const [y, m] = feeMonthVal().split('-').map(Number); const d = new Date(y, m - 1 + step, 1); $('#feeMonth').value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; renderFees(); }
function feeList(month) {
  return state.drivers.filter(d => !d.manual && !d.feeExempt && workedIn(d.id, month)).map(d => ({ d, rec: feeRecord(d.id, month) }))
    .sort((a, b) => (!!a.rec - !!b.rec) || a.d.name.localeCompare(b.d.name, 'az'));
}
function renderFees() {
  if (!$('#feeMonth').value) $('#feeMonth').value = monthOf(postingDate());
  const month = feeMonthVal(), fee = num(state.settings.fee), list = feeList(month);
  const paid = list.filter(x => x.rec && x.rec.kind !== 'waive'), waived = list.filter(x => x.rec?.kind === 'waive'), unpaid = list.filter(x => !x.rec);
  const collected = paid.reduce((a, x) => a + num(x.rec.amount), 0), expected = fee * (paid.length + unpaid.length);
  $('#feeMonthLabel').textContent = monthLabel(month);
  $('#feeSum').innerHTML = `
    <div><small>İşləyən sürücü</small><b>${list.length}</b></div>
    <div><small>Ödəyib</small><b>${paid.length}</b></div>
    <div class="${unpaid.length ? 'is-due' : ''}"><small>Ödəməyib</small><b>${unpaid.length}</b></div>
    <div class="wide"><small>Yığılıb</small><b>${money(collected)} <em>/ ${money(expected)}</em></b><span class="meter"><i style="width:${expected ? Math.min(100, collected / expected * 100) : 0}%"></i></span></div>`;
  const tab = $('#feeTabs .on')?.dataset.tab || 'unpaid';
  $$('#feeTabs [data-tab]').forEach(b => { const n = { unpaid: unpaid.length, paid: paid.length + waived.length, all: list.length }[b.dataset.tab]; b.querySelector('em').textContent = n; });
  const shown = tab === 'unpaid' ? unpaid : tab === 'paid' ? [...paid, ...waived] : list;
  $('#feeBulk').innerHTML = tab === 'unpaid' && unpaid.length ? `<button id="feeBulkBtn" class="primary">Hamısını ödənmiş qeyd et</button>` : '';
  $('#feeBody').innerHTML = shown.map(({ d, rec }, i) => `<tr>
      <td class="c">${i + 1}</td><td class="name-cell">${esc(d.name)}</td><td>${d.plates.map(p => `<span class="plate">${esc(p)}</span>`).join(' ')}</td>
      <td>${rec ? `<span class="state ok">${rec.kind === 'waive' ? 'Azad edilib' : PAY_METHODS[rec.kind] || 'Ödənib'}</span>` : `<span class="state due">Ödənilməyib</span>`}</td>
      <td>${rec?.date ? fmtDate(rec.date) : '—'}</td><td class="money">${rec ? fmtNum(rec.amount) : fmtNum(fee)}</td>
      <td class="r">${rec ? (rec.paymentId ? `<button class="link" data-fpay="${d.id}">Bax</button>` : '') : `<button data-fpay="${d.id}">Ödəniş yaz</button>`}</td></tr>`).join('')
    || `<tr><td colspan="7" class="empty">${tab === 'unpaid' ? `✓ ${monthLabel(month)} üçün ödəməyən sürücü yoxdur.` : 'Qeyd yoxdur.'}</td></tr>`;
  const idle = state.drivers.filter(d => !d.manual && !d.feeExempt && d.active !== false && !workedIn(d.id, month)).length;
  $('#feeFoot').textContent = `Siyahıya yalnız ${monthLabel(month)} ayında işləyən sürücülər düşür. Bu ay işləməyən: ${idle} sürücü. Xidmət haqqı: ${money(fee)} / ay.`;
  const cur = monthOf(postingDate()), allUnpaid = feeList(cur).filter(x => !x.rec).length;
  const nb = $('#navFeesBadge'); nb.textContent = allUnpaid; nb.classList.toggle('hidden', !allUnpaid);
}
function bulkFees() {
  const month = feeMonthVal(), unpaid = feeList(month).filter(x => !x.rec);
  openModal({
    title: `${monthLabel(month)} — ${unpaid.length} sürücü`,
    body: `<p class="muted">${unpaid.map(x => esc(x.d.name)).join(', ')}</p><div class="form-grid"><label>Necə ödəyiblər<select name="method"><option value="cash">Nağd ödəyib</option><option value="transfer">Köçürmə ilə ödəyib</option><option value="waive">Bu ay azad</option></select></label><label>Tarix<input name="date" type="date" value="${isoToday()}"></label></div>`,
    actions: [{ label: '✓ Hamısına yaz', cls: 'primary', onClick: async () => {
      const root = $('#modalBody'), method = fv(root, 'method'), date = fv(root, 'date') || isoToday();
      for (const { d } of unpaid) state.payments.push({ id: uid(), driverId: d.id, month, method, amount: method === 'waive' ? 0 : num(state.settings.fee), date, note: 'Toplu qeyd' });
      await persistPayments(); refreshFeeStates(); renderAll(); closeModal(); toast(`${unpaid.length} ödəniş yazıldı`, 'ok');
    } }]
  });
}
function exportFees() {
  const month = feeMonthVal(), list = feeList(month), S = state.settings;
  const body = list.map(({ d, rec }, i) => [i + 1, d.name, d.plates.join(', '), rec ? (rec.kind === 'waive' ? 'Azad' : PAY_METHODS[rec.kind] || 'Ödənib') : 'ÖDƏNİLMƏYİB', rec?.date ? fmtDate(rec.date) : '', rec ? num(rec.amount) : 0]);
  XLSXStyled.download(`XIDMET_HAQQI_${month}.xlsx`, [gridSheet({ name: 'Xidmət haqqı', title: `XİDMƏT HAQQI — ${monthLabel(month).toUpperCase()}`, sub: `${S.company} · ${list.length} sürücü · ödəməyən: ${list.filter(x => !x.rec).length}`, landscape: false,
    head: ['S/N', 'SÜRÜCÜ', 'MAŞIN', 'VƏZİYYƏT', 'TARİX', 'MƏBLƏĞ'], body, foot: ['', 'CƏMİ', '', '', '', r2(body.reduce((a, r) => a + r[5], 0))], cols: [6, 32, 18, 26, 13, 13], numCols: [5], centerCols: [0, 2, 4], boldCols: [1] })]);
}

/* ---------------- Direktor hesabatı ---------------- */
function directorCalc(rows, commission = 0) {
  const D = state.settings.director, live = rows.filter(r => !r.manual);
  const income = live.reduce((a, r) => a + num(r.income), 0);
  const base = live.reduce((a, r) => a + num(r.income) * num(r.taxRate) / 100, 0);
  const fees = live.reduce((a, r) => a + num(r.service), 0), feeCount = live.filter(r => num(r.service) > 0).length;
  const deductions = D.deductions.filter(x => x.on && num(x.pct)).map(x => { const from = x.basis === 'income' ? income : base; return { ...x, from, amount: from * num(x.pct) / 100 }; });
  commission = num(commission);
  const dedTotal = deductions.reduce((a, x) => a + x.amount, 0) + commission;
  const remaining = base - dedTotal;
  const shares = D.shares.filter(x => x.on && num(x.pct)).map(x => { const amount = remaining * num(x.pct) / 100, f = x.addFees ? fees : 0; return { ...x, amount, fees: f, total: amount + f }; });
  const sharesTotal = shares.reduce((a, x) => a + x.amount, 0), final = remaining - sharesTotal;
  const taxRate = rateLabel(live, 'taxRate', '10%');
  return { income, base, taxRate, fees, feeCount, commission, deductions, dedTotal, remaining, shares, sharesTotal, final, recipient: D.recipient, drivers: live.length };
}
/* Hesabatın sətirləri — ekran, PDF və Excel eyni mənbədən */
function directorLines(c) {
  const L = [];
  L.push({ k: 'plain', name: 'Sürücülərin gəlirləri', calc: `${c.drivers} sürücü`, amount: c.income });
  L.push({ k: 'sum', name: `${c.taxRate} gəlir vergisi`, calc: `${fmtNum(c.income)} × ${c.taxRate}`, amount: c.base });
  for (const d of c.deductions) L.push({ k: 'minus', name: d.name, calc: `${fmtNum(d.from)} × ${pctTxt(d.pct)}`, amount: -d.amount });
  if (c.commission) L.push({ k: 'minus', name: 'Əlavə komissiya', calc: 'sabit məbləğ', amount: -c.commission });
  L.push({ k: 'sum', name: 'Hesablanacaq məbləğ', calc: [fmtNum(c.base), ...c.deductions.map(d => fmtNum(d.amount)), ...(c.commission ? [fmtNum(c.commission)] : [])].join(' − '), amount: c.remaining });
  for (const s of c.shares) {
    const payee = s.payeeId ? driverById(s.payeeId)?.name : '';
    L.push({ k: 'share', name: s.name, sub: payee ? `→ ${payee} kartına` : '', calc: `${fmtNum(c.remaining)} × ${pctTxt(s.pct)} = ${fmtNum(s.amount)}${s.addFees ? ` + xidmət haqqı ${fmtNum(s.fees)}${c.feeCount ? ` (${c.feeCount} sürücü)` : ''}` : ''}`, amount: s.total });
  }
  L.push({ k: 'final', name: c.recipient, calc: [fmtNum(c.remaining), ...c.shares.map(s => fmtNum(s.amount))].join(' − '), amount: c.final });
  return L;
}
function directorRows() { const v = $('#dirDate').value; return v === '__current' ? state.current : state.archive.filter(r => r.postingDate === v); }
function renderDirector() {
  const dates = [...new Set(state.archive.map(r => r.postingDate))].sort().reverse();
  const sel = $('#dirDate'), cur = sel.value;
  sel.innerHTML = (state.current.length ? `<option value="__current">Cari hesablama · ${fmtDate(postingDate())}</option>` : '') + dates.map(d => `<option value="${d}">${fmtDate(d)}</option>`).join('');
  if ([...sel.options].some(o => o.value === cur)) sel.value = cur;
  if (!sel.value) { $('#dirStatement').innerHTML = '<p class="muted pad">Arxivdə hesabat yoxdur.</p>'; $('#dirPayouts').innerHTML = ''; state.dirCalc = null; return; }
  const saved = state.director.find(x => x.date === sel.value);
  if (sel.dataset.last !== sel.value) { $('#dirCommission').value = sel.value === '__current' ? (state.curCommission || 0) : (saved?.commission ?? 0); $('#dirNote').value = saved?.note || ''; sel.dataset.last = sel.value; }
  const c = directorCalc(directorRows(), num($('#dirCommission').value)), date = sel.value === '__current' ? postingDate() : sel.value;
  state.dirCalc = { ...c, date, lines: directorLines(c) };
  $('#dirStatement').innerHTML = `
    <div class="stmt-head"><div><small>DİREKTOR HESABATI · ${esc(state.settings.company)}</small><h3>${fmtDate(date)}</h3></div><div class="stmt-total"><small>${esc(c.recipient)}</small><b>${money(c.final)}</b></div></div>
    ${state.dirCalc.lines.map((l, i) => `<div class="st-line ${l.k}"><span class="st-n">${i + 1}</span><span class="st-name">${l.k === 'minus' ? '− ' : ''}${esc(l.name)}${l.sub ? `<i>${esc(l.sub)}</i>` : ''}</span><em>${esc(l.calc)}</em><b>${fmtNum(Math.abs(l.amount))}</b></div>`).join('')}`;
  const people = [...c.deductions.map(d => ({ name: d.name, amount: d.amount, note: `${pctTxt(d.pct)} · ${BASIS[d.basis].toLowerCase()}` })), ...c.shares.map(s => ({ name: s.name, amount: s.total, note: `${pctTxt(s.pct)}${s.addFees ? ' + xidmət haqqı' : ''}${s.payeeId ? ' · ' + (driverById(s.payeeId)?.name || '') : ''}` })), { name: c.recipient, amount: c.final, note: 'yerdə qalan', main: true }];
  const max = Math.max(...people.map(p => p.amount), 1);
  $('#dirPayouts').innerHTML = `<h3>Kimə nə qədər</h3>${people.map(p => `<div class="po ${p.main ? 'main' : ''}"><div><b>${esc(p.name)}</b><small>${esc(p.note)}</small></div><strong>${money(p.amount)}</strong><span class="meter"><i style="width:${Math.max(2, p.amount / max * 100)}%"></i></span></div>`).join('')}
    <div class="po-foot"><span>10% vergi cəmi</span><b>${money(c.base)}</b></div>${c.fees ? `<div class="po-foot"><span>Xidmət haqqı (${c.feeCount} sürücü)</span><b>${money(c.fees)}</b></div>` : ''}`;
  $('#dirHistory').innerHTML = state.director.slice().sort((a, b) => b.date.localeCompare(a.date)).map(h => `<tr><td>${fmtDate(h.date)}</td><td class="r">${fmtNum(h.income)}</td><td class="r">${fmtNum(h.base)}</td><td class="r">${fmtNum(h.dedTotal ?? h.deductionsTotal ?? 0)}</td><td class="r">${fmtNum(h.remaining ?? 0)}</td><td class="r">${fmtNum(h.sharesTotal + (h.fees || 0))}</td><td class="r"><b>${fmtNum(h.final)}</b></td><td>${esc(h.note || '')}</td><td class="r"><button class="link" data-hload="${h.date}">Aç</button> <button class="link danger" data-hdel="${h.id}">Sil</button></td></tr>`).join('') || '<tr><td colspan="9" class="empty">Hələ yadda saxlanmış hesabat yoxdur.</td></tr>';
}
async function saveDirector() {
  const c = state.dirCalc; if (!c) return toast('Hesabat seçin', 'bad');
  if ($('#dirDate').value === '__current') return toast('Əvvəl cari hesablamanı arxivə yazın', 'bad');
  state.director = state.director.filter(x => x.date !== c.date);
  state.director.push({ id: uid(), v: 2, date: c.date, income: r2(c.income), base: r2(c.base), dedTotal: r2(c.dedTotal), commission: c.commission, remaining: r2(c.remaining), sharesTotal: r2(c.sharesTotal), fees: r2(c.fees), final: r2(c.final), lines: c.lines, recipient: c.recipient, note: $('#dirNote').value, savedAt: new Date().toISOString() });
  await persistDirector(); renderDirector(); toast('Direktor hesabatı yadda saxlanıldı', 'ok');
}
function directorPdf() {
  const c = state.dirCalc; if (!c) return;
  const S = state.settings, doc = newPdf('portrait'), W = doc.internal.pageSize.getWidth();
  let y = pdfHeader(doc, { title: 'DİREKTOR HESABATI', left: `${S.company} · VÖEN ${S.voen}`, right: `Hesabat tarixi: ${fmtDate(c.date)}` });
  // Xülasə qutuları
  const boxes = [['Sürücülərin gəlirləri', c.income], [`${c.taxRate} gəlir vergisi`, c.base], [c.recipient, c.final]], bw = (W - 24 - 8) / 3;
  boxes.forEach(([t, v], i) => { const x = 12 + i * (bw + 4); doc.setFillColor(...(i === 2 ? C.navy : C.soft)); doc.roundedRect(x, y, bw, 18, 2, 2, 'F'); doc.setTextColor(...(i === 2 ? [220, 231, 246] : C.muted)); pF(doc, false); doc.setFontSize(8); doc.text(pT(doc, t), x + 4, y + 6.5); doc.setTextColor(...(i === 2 ? [255, 255, 255] : C.ink)); pF(doc, true); doc.setFontSize(13); doc.text(pT(doc, `${fmtNum(v)} AZN`), x + 4, y + 14); });
  y += 26; doc.setTextColor(...C.ink);
  pF(doc, true); doc.setFontSize(10); doc.text(pT(doc, 'Hesablama'), 12, y); y += 3;
  const lines = c.lines;
  y = pdfGrid(doc, { y, fontSize: 8.4, rowH: 8, headH: 8, head: ['№', 'Göstərici', 'Hesablama', 'Məbləğ (AZN)'], widths: [10, 52, 94, 30], align: ['c', 'l', 'l', 'r'],
    rows: lines.map((l, i) => [i + 1, `${l.k === 'minus' ? '− ' : ''}${l.name}${l.sub ? ' ' + l.sub : ''}`, l.calc, Math.abs(l.amount)]), rowStyle: i => lines[i].k === 'final' ? 'final' : lines[i].k === 'sum' ? 'sum' : '' });
  y += 9; pF(doc, true); doc.setFontSize(10); doc.text(pT(doc, 'Ödəniş bölgüsü'), 12, y); y += 3;
  const pay = [...c.deductions.map(d => [d.name, `${pctTxt(d.pct)} · ${BASIS[d.basis].toLowerCase()}`, d.amount, 0, d.amount]), ...c.shares.map(s => [s.name + (s.payeeId ? ` (${driverById(s.payeeId)?.name || ''})` : ''), `${pctTxt(s.pct)} · hesablanacaq məbləğdən`, s.amount, s.fees, s.total]), [c.recipient, 'yerdə qalan', c.final, 0, c.final]];
  y = pdfGrid(doc, { y, fontSize: 8.4, rowH: 8, headH: 8, head: ['Kimə', 'Əsas', 'Pay', 'Xidmət haqqı', 'Cəmi (AZN)'], widths: [56, 56, 25, 25, 24], align: ['l', 'l', 'r', 'r', 'r'],
    rows: pay, foot: ['CƏMİ', '', r2(pay.reduce((a, r) => a + r[2], 0)), r2(pay.reduce((a, r) => a + r[3], 0)), r2(pay.reduce((a, r) => a + r[4], 0))] });
  const note = $('#dirNote').value; if (note) { y += 7; pF(doc, false); doc.setFontSize(9); doc.text(pT(doc, `Qeyd: ${note}`), 12, y); }
  y += 20; pF(doc, false); doc.setFontSize(9); doc.setDrawColor(...C.muted);
  [['Hazırladı', S.preparedBy], ['Təsdiq etdi', S.approvedBy]].forEach(([t, n], i) => { const x = 12 + i * 98; doc.text(pT(doc, `${t}:`), x, y); doc.line(x + 24, y + 1, x + 85, y + 1); if (n) doc.text(pT(doc, n), x + 26, y - 1); });
  pdfFooter(doc); doc.save(`DIREKTOR_HESABATI_${c.date}.pdf`);
}
function directorExcel() {
  const c = state.dirCalc; if (!c) return;
  const S = state.settings, lines = c.lines;
  const rows = [
    { h: 26, cells: [{ v: 'DİREKTOR HESABATI', s: 'title' }] },
    { h: 18, cells: [{ v: `${S.company} · VÖEN ${S.voen} · Hesabat tarixi: ${fmtDate(c.date)}`, s: 'sub' }] },
    { h: 8, cells: [] },
    { h: 24, cells: ['№', 'GÖSTƏRİCİ', 'HESABLAMA', 'MƏBLƏĞ (AZN)'].map(v => ({ v, s: 'head' })) },
    ...lines.map((l, i) => { const k = l.k === 'final' ? 'final' : l.k === 'sum' ? 'sum' : ''; return { h: l.k === 'share' ? 30 : 22, cells: [{ v: String(i + 1), s: k || 'cellC' }, { v: `${l.k === 'minus' ? '− ' : ''}${l.name}${l.sub ? ' ' + l.sub : ''}`, s: k || 'label' }, { v: l.calc, s: k ? k + 'Note' : 'note' }, { v: r2(Math.abs(l.amount)), s: k ? k + 'Num' : 'num' }] }; }),
    { h: 12, cells: [] },
    { h: 24, cells: ['KİMƏ', 'ƏSAS', 'PAY', 'XİDMƏT HAQQI', 'CƏMİ (AZN)'].map(v => ({ v, s: 'head' })) }
  ];
  const pay = [...c.deductions.map(d => [d.name, `${pctTxt(d.pct)} · ${BASIS[d.basis].toLowerCase()}`, d.amount, 0, d.amount]), ...c.shares.map(s => [s.name + (s.payeeId ? ` (${driverById(s.payeeId)?.name || ''})` : ''), `${pctTxt(s.pct)} · hesablanacaq məbləğdən`, s.amount, s.fees, s.total]), [c.recipient, 'yerdə qalan', c.final, 0, c.final]];
  pay.forEach(p => rows.push({ h: 20, cells: [{ v: p[0], s: 'label' }, { v: p[1], s: 'note' }, { v: r2(p[2]), s: 'num' }, { v: r2(p[3]), s: 'num' }, { v: r2(p[4]), s: 'numB' }] }));
  rows.push({ h: 22, cells: [{ v: 'CƏMİ', s: 'total' }, { v: '', s: 'total' }, ...[2, 3, 4].map(i => ({ v: r2(pay.reduce((a, r) => a + r[i], 0)), s: 'totalNum' }))] });
  rows.push({ h: 14, cells: [] }, { h: 20, cells: [{ v: `Hazırladı: ${S.preparedBy || '____________________'}`, s: 'sign' }, null, { v: `Təsdiq etdi: ${S.approvedBy || '____________________'}`, s: 'sign' }] });
  if ($('#dirNote').value) rows.push({ h: 20, cells: [{ v: `Qeyd: ${$('#dirNote').value}`, s: 'sub' }] });
  XLSXStyled.download(`DIREKTOR_HESABATI_${c.date}.xlsx`, [{ name: 'Direktor hesabatı', cols: [34, 44, 56, 16, 16], rows, merges: ['A1:E1', 'A2:E2'], landscape: false }]);
}

/* ---------------- Ayarlar ---------------- */
function driverPick(sel) { return `<option value="">— yoxdur —</option>` + state.drivers.slice().sort((a, b) => (b.manual - a.manual) || a.name.localeCompare(b.name, 'az')).map(d => `<option value="${d.id}" ${d.id === sel ? 'selected' : ''}>${esc(d.name)}${d.manual ? ' (maşınsız)' : ''}</option>`).join(''); }
function renderDedEditor() {
  $('#setDeductions').innerHTML = `<div class="ed-head"><span></span><span>Ad</span><span>Nədən hesablanır</span><span>Faiz</span><span></span></div>` + state.settings.director.deductions.map((x, i) => `
    <div class="ed-row ded" data-i="${i}"><input type="checkbox" name="on" ${x.on ? 'checked' : ''} title="Aktiv"><input name="name" value="${esc(x.name)}">
    <select name="basis">${Object.entries(BASIS).map(([k, v]) => `<option value="${k}" ${x.basis === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
    <span class="pct"><input name="pct" type="number" step="0.01" value="${x.pct}">%</span><button class="link danger" data-rmded="${i}" title="Sil">✕</button></div>`).join('');
}
function renderShareEditor() {
  $('#setShares').innerHTML = `<div class="ed-head sh"><span></span><span>Ad</span><span>Faiz</span><span>+ Xidmət haqqı</span><span>Ödəniş kimin kartına</span><span></span></div>` + state.settings.director.shares.map((x, i) => `
    <div class="ed-row sh" data-i="${i}"><input type="checkbox" name="on" ${x.on ? 'checked' : ''} title="Aktiv"><input name="name" value="${esc(x.name)}">
    <span class="pct"><input name="pct" type="number" step="0.01" value="${x.pct}">%</span>
    <label class="chk"><input type="checkbox" name="addFees" ${x.addFees ? 'checked' : ''}> əlavə et</label>
    <select name="payeeId">${driverPick(x.payeeId)}</select><button class="link danger" data-rmshare="${i}" title="Sil">✕</button></div>`).join('');
}
function renderPayForms() { $('#setPayForms').innerHTML = state.settings.paymentForms.map((p, i) => `<span class="chip">${esc(p)}<button data-rmpay="${i}" title="Sil">✕</button></span>`).join(''); }
function renderSettings() {
  const S = state.settings;
  for (const [id, k] of [['setCompany', 'company'], ['setVoen', 'voen'], ['setPrepared', 'preparedBy'], ['setApproved', 'approvedBy'], ['setCash', 'cashRate'], ['setTax', 'taxRate'], ['setFee', 'fee'], ['setFeeMode', 'feeMode']]) $('#' + id).value = S[k] ?? '';
  $('#setRecipient').value = S.director.recipient;
  renderDedEditor(); renderShareEditor(); renderPayForms();
  $('#metaInfo').textContent = `Baza: ${state.drivers.length} sürücü · Arxiv: ${state.archive.length} qeyd · Ödəniş qeydləri: ${state.payments.length} · Direktor hesabatları: ${state.director.length}`;
}
const readDed = () => [...document.querySelectorAll('#setDeductions .ed-row')].map(r => ({ id: uid(), on: r.querySelector('[name=on]').checked, name: r.querySelector('[name=name]').value.trim() || 'Tutulma', basis: r.querySelector('[name=basis]').value, pct: num(r.querySelector('[name=pct]').value) }));
const readShares = () => [...document.querySelectorAll('#setShares .ed-row')].map(r => ({ id: uid(), on: r.querySelector('[name=on]').checked, name: r.querySelector('[name=name]').value.trim() || 'Pay', pct: num(r.querySelector('[name=pct]').value), addFees: r.querySelector('[name=addFees]').checked, payeeId: r.querySelector('[name=payeeId]').value }));
async function saveSettings() {
  const S = state.settings;
  Object.assign(S, { company: $('#setCompany').value.trim() || 'FOOD HALL MMC', voen: $('#setVoen').value.trim(), preparedBy: $('#setPrepared').value.trim(), approvedBy: $('#setApproved').value.trim(), cashRate: num($('#setCash').value), taxRate: num($('#setTax').value), fee: num($('#setFee').value), feeMode: $('#setFeeMode').value });
  S.director = { recipient: $('#setRecipient').value.trim() || 'Xəyalə xanım', deductions: readDed(), shares: readShares() };
  // seçilmiş kart sahibi maşınsız deyilsə, maşınsız et ki hər hesabata düşsün
  for (const sh of S.director.shares) { const d = driverById(sh.payeeId); if (d && !d.manual) { d.manual = true; d.feeExempt = true; } }
  for (const r of state.current) { if (!r.manual) { r.cashRate = S.cashRate; r.taxRate = S.taxRate; } }
  aggregateIfAny(); refreshFeeStates(); await persistSettings(); await persistDrivers(); persistDraft(); renderAll(); toast('Ayarlar yadda saxlanıldı', 'ok');
}
function download(name, text, type = 'application/json') { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); }
async function backupImport(file) {
  try {
    const j = JSON.parse(await file.text()); if (!Array.isArray(j.drivers) || !Array.isArray(j.archive)) throw new Error('fayl formatı uyğun deyil');
    if (!confirm(`Ehtiyat nüsxə: ${j.drivers.length} sürücü, ${j.archive.length} qeyd. Hazırkı məlumatlar ƏVƏZ olunsun?`)) return;
    state.drivers = j.drivers; state.archive = j.archive.map(makeRow); state.payments = j.payments || []; state.director = j.director || [];
    state.settings = { ...structuredClone(DEFAULT_SETTINGS), ...(j.settings || {}) }; if (state.settings.dirVersion !== 2) { state.settings.director = DEFAULT_DIRECTOR(); state.settings.dirVersion = 2; }
    await persistDrivers(); await persistArchive(); await persistPayments(); await persistDirector(); await persistSettings(); renderAll(); toast('Bərpa edildi', 'ok');
  } catch (e) { toast('Bərpa alınmadı: ' + e.message, 'bad'); }
}

/* ---------------- Ümumi render və naviqasiya ---------------- */
const VIEW_TEXT = {
  calc: ['Sürücü gəlirlərinin hesablanması', 'PDF reyestri və ya Excel faylı əlavə edin — hesablama, yoxlama və arxiv avtomatikdir.'],
  archive: ['Hesabat arxivi', 'Bütün hesabatlar tarix üzrə. Filtrləyin, düzəldin, Excel/PDF yükləyin.'],
  drivers: ['Sürücü paneli', 'Sürücü, maşın və kart məlumatlarını buradan idarə edin — əlavə, düzəliş, birləşdirmə.'],
  fees: ['Xidmət haqqı', 'Seçilmiş ayda işləyən sürücülər — kim ödəyib, kim ödəməyib.'],
  director: ['Direktor hesabatı', '10% gəlir vergisindən nağdlaşdırma və tutulmalar çıxılır, paylar bölünür — qalan məbləğ avtomatik hesablanır.'],
  settings: ['Ayarlar', 'Şirkət, faizlər, xidmət haqqı, ödəniş formaları, direktor bölgüsü və ehtiyat nüsxə.']
};
function showView(v) {
  $$('.nav').forEach(b => b.classList.toggle('active', b.dataset.view === v)); $$('.view').forEach(s => s.classList.toggle('active', s.id === v));
  $('#pageTitle').textContent = VIEW_TEXT[v][0]; $('#pageSub').textContent = VIEW_TEXT[v][1];
  renderAll();
}
function renderHeader() {
  const S = state.settings;
  $('#heroChips').innerHTML = `<span>Nağdlaşdırma ${pctTxt(S.cashRate)}</span><span>Gəlir vergisi ${pctTxt(S.taxRate)}</span><span>Xidmət haqqı ${money(S.fee)} / ay</span><span>${state.drivers.filter(d => d.active !== false).length} sürücü</span><span>${new Set(state.archive.map(r => r.postingDate)).size} hesabat</span>`;
  const ob = $('#ammoOwnersBtn'); if (ob && !ob.dataset.sgStyled) { ob.dataset.sgStyled = '1'; ob.style.setProperty('background', 'rgba(255,255,255,.12)', 'important'); ob.style.setProperty('box-shadow', 'none', 'important'); ob.style.setProperty('border', '1px solid rgba(255,255,255,.25)', 'important'); }
  $('.eyebrow').textContent = `${S.company} • AĞILLI HESABAT SİSTEMİ`; $('.brand small').textContent = `${S.company} · V10`;
  $$('.rateCash').forEach(e => e.textContent = pctTxt(S.cashRate)); $$('.rateTax').forEach(e => e.textContent = pctTxt(S.taxRate));
  $('.thCash').textContent = `${pctTxt(S.cashRate)} nağdlaşdırma`; $('.thTax').textContent = `${pctTxt(S.taxRate)} gəlir vergisi`;
  $('#sideRates').innerHTML = `<div><span>Nağdlaşdırma</span><b>${pctTxt(S.cashRate)}</b></div><div><span>Gəlir vergisi</span><b>${pctTxt(S.taxRate)}</b></div><div><span>Xidmət haqqı</span><b>${fmtNum(S.fee)} ₼</b></div>`;
}
function renderAll() {
  renderHeader(); renderCurrent(); renderChecklist(); updateStats(); renderFees(); renderDrivers();
  const v = $('.view.active')?.id;
  if (v === 'archive') renderArchive(); if (v === 'director') renderDirector(); if (v === 'settings') renderSettings();
}

/* ---------------- İlkin yükləmə və miqrasiya ---------------- */
function legacyRow(r) {
  const income = num(r.income ?? r.amount);
  return makeRow({ postingDate: r.postingDate, sourceFile: r.sourceFile || 'V9 arxivi', driverName: upperAz(r.driverName || r.name || 'NAMƏLUM'), card: parseCard(r.card).card, payment: parseCard(r.card).payment || r.payment || '', plates: (r.plates || [r.plate]).map(normalizePlate).filter(Boolean), trips: num(r.trips), income,
    cashRate: income && num(r.cash) ? r2(num(r.cash) / income * 100) : 1, taxRate: income && num(r.incomeTax) ? r2(num(r.incomeTax) / income * 100) : 5,
    service: num(r.accounting), other: ['dsmf', 'dsmfDebt', 'givenDebt', 'accountingDebt', 'taxPlanning', 'debt'].reduce((a, k) => a + num(r[k]), 0) });
}
async function migrate(all) {
  // 1) Köhnə sürücü bazası silinir, Excel arxivindən yenidən qurulur
  state.drivers = []; state.archive = [];
  const files = (window.SG_SEED?.files || []).map(f => ({ name: f.name, aoa: f.rows, header: classifyAoa(f.rows).header })).filter(f => f.header);
  for (const f of files) { const res = importReportAoa(f.aoa, f.header, f.name); state.archive = state.archive.filter(r => !res.dates.includes(r.postingDate)).concat(res.rows); }
  // 2) Köhnə (V9) arxivdəki digər tarixlər saxlanılır və maşın nömrəsi üzrə yeni bazaya bağlanır
  const seedDates = new Set(state.archive.map(r => r.postingDate));
  for (const r of (all.archive2 || all.archive || []).map(legacyRow).filter(r => r.postingDate && !seedDates.has(r.postingDate))) {
    const d = r.plates.map(driverByPlate).find(Boolean) || driverByName(r.driverName);
    if (d) r.driverId = d.id; state.archive.push(r);
  }
  state.archive.sort((a, b) => a.postingDate.localeCompare(b.postingDate));
  state.meta = { ...state.meta, seed: SEED_VERSION, seededAt: new Date().toISOString(), legacyKept: !!(all.drivers2 || all.archive2) };
  await persistDrivers(); await persistArchive(); await persistMeta(); await persistSettings();
}
async function load() {
  const all = await readStore();
  if (state.meta.seed !== SEED_VERSION && !state.drivers.length) await migrate(all);
  if (ensurePayees() || state.settingsDirty) { state.settingsDirty = false; await persistSettings(); }
  const draft = all[K.draft];
  $('#postingDate').value = draft?.postingDate || isoToday();
  if (draft?.current?.length) { state.current = draft.current.map(makeRow); state.currentTrips = draft.trips || []; state.currentFile = draft.file || ''; state.pdfCheck = draft.pdfCheck || null; state.curCommission = num(draft.commission); refreshFeeStates(); }
  renderAll();
}

/* ---------------- Hadisələr ---------------- */
$('.sidebar nav').addEventListener('click', e => { const b = e.target.closest('.nav'); if (b) showView(b.dataset.view); });
$('#addFileBtn').onclick = () => $('#fileInput').click();
$('#fileInput').onchange = e => handleFiles(e.target.files);
const dz = $('#dropZone');
['dragenter', 'dragover'].forEach(x => dz.addEventListener(x, e => { e.preventDefault(); dz.classList.add('drag'); }));
['dragleave', 'drop'].forEach(x => dz.addEventListener(x, e => { e.preventDefault(); dz.classList.remove('drag'); }));
dz.addEventListener('drop', e => handleFiles(e.dataTransfer.files));
dz.onclick = () => $('#fileInput').click();
document.addEventListener('dragover', e => e.preventDefault());
document.addEventListener('drop', e => { if (!dz.contains(e.target)) { e.preventDefault(); handleFiles(e.dataTransfer.files); } });
$('#postingDate').onchange = () => { refreshFeeStates(); renderAll(); persistDraft(); };
$('#saveArchive').onclick = saveCurrentToArchive;
$('#clearCurrent').onclick = () => { if (state.current.length && !confirm('Cari hesablama silinsin?')) return; state.current = []; state.currentTrips = []; state.pdfCheck = null; state.currentFile = ''; persistDraft(); renderAll(); };
$('#addManualRow').onclick = addManualRow;
$('#checklist').onclick = e => { if (e.target.dataset.wizard) openNewCarWizard(); if (e.target.dataset.feewiz) openFeeWizard(); };
$('#currentBody').onclick = e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.wizard) openNewCarWizard();
  if (t.dataset.fee) openFeeWizard(t.dataset.fee);
  if (t.dataset.edit) editCurrent(t.dataset.edit);
  if (t.dataset.del) { state.current = state.current.filter(x => x.id !== t.dataset.del); state.currentTrips = state.currentTrips; refreshFeeStates(); renderAll(); persistDraft(); }
};
$('#archiveBody').onclick = async e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.aedit) editArchive(t.dataset.aedit);
  if (t.dataset.adel && confirm('Bu qeyd silinsin?')) { state.archive = state.archive.filter(x => x.id !== t.dataset.adel); await persistArchive(); renderAll(); }
};
$('#reportStrip').onclick = e => { const b = e.target.closest('[data-date]'); if (!b) return; const on = $('#fromDate').value === b.dataset.date && $('#toDate').value === b.dataset.date; $('#fromDate').value = on ? '' : b.dataset.date; $('#toDate').value = on ? '' : b.dataset.date; renderArchive(); };
$('#applyFilter').onclick = renderArchive;
$('#resetFilter').onclick = () => { ['fromDate', 'toDate', 'filterName', 'filterPlate'].forEach(x => $('#' + x).value = ''); renderArchive(); };
['filterName', 'filterPlate'].forEach(id => $('#' + id).addEventListener('input', renderArchive));
$('#exportExcel').onclick = exportExcel; $('#exportPdf').onclick = exportPdf; $('#exportCardExcel').onclick = exportCardExcel; $('#clearArchive').onclick = clearArchiveSelection;
$('#importArchiveBtn').onclick = () => $('#archiveFileInput').click();
$('#archiveFileInput').onchange = e => { handleFiles(e.target.files); e.target.value = ''; };
$('#driverSearch').oninput = renderDrivers; $('#driverFilter').onchange = renderDrivers;
$('#addDriver').onclick = () => editDriver(null);
$('#driverGrid').onclick = e => { const t = e.target.closest('button'); if (!t) return; if (t.dataset.dedit) editDriver(t.dataset.dedit); if (t.dataset.dhist) driverHistory(t.dataset.dhist); if (t.dataset.dpay) recordPayment(t.dataset.dpay, monthOf(postingDate())); };
$('#feeExport').onclick = exportFees; $('#feePrev').onclick = () => shiftFeeMonth(-1); $('#feeNext').onclick = () => shiftFeeMonth(1);
$('#feeTabs').onclick = e => { const b = e.target.closest('[data-tab]'); if (!b) return; $$('#feeTabs [data-tab]').forEach(x => x.classList.toggle('on', x === b)); renderFees(); };
$('#feeBulk').onclick = e => { if (e.target.id === 'feeBulkBtn') bulkFees(); };
$('#feeBody').onclick = e => { const t = e.target.closest('[data-fpay]'); if (t) recordPayment(t.dataset.fpay, feeMonthVal()); };
$('#feeAll').onchange = e => {
  const on = e.target.checked;
  for (const r of state.current) {
    if (r.feeState !== 'pending' && r.feeState !== 'decided') continue;
    if (on) { r.feeDecision = 'deduct'; r.feeAmount = num(state.settings.fee); } else if (r.feeDecision === 'deduct') r.feeDecision = '';
  }
  refreshFeeStates(); renderAll(); persistDraft();
  toast(on ? 'Bütün sürücülərdən xidmət haqqı tutuldu' : 'Xidmət haqqı tutulmaları ləğv edildi', on ? 'ok' : '');
};
$('#dirDate').onchange = renderDirector;
$('#dirCommission').oninput = () => { if ($('#dirDate').value === '__current') { state.curCommission = num($('#dirCommission').value); refreshFeeStates(); persistDraft(); } renderDirector(); };
$('#dirSave').onclick = saveDirector; $('#dirPdf').onclick = directorPdf; $('#dirExcel').onclick = directorExcel;
$('#dirHistory').onclick = async e => { const t = e.target.closest('button'); if (!t) return; if (t.dataset.hload) { $('#dirDate').value = t.dataset.hload; $('#dirDate').dataset.last = ''; renderDirector(); } if (t.dataset.hdel && confirm('Silinsin?')) { state.director = state.director.filter(x => x.id !== t.dataset.hdel); await persistDirector(); renderDirector(); } };
$('#addDeduction').onclick = () => { state.settings.director.deductions = readDed(); state.settings.director.deductions.push({ id: uid(), name: 'Yeni tutulma', basis: 'base', pct: 0, on: true }); renderDedEditor(); };
$('#addShare').onclick = () => { state.settings.director.shares = readShares(); state.settings.director.shares.push({ id: uid(), name: 'Yeni pay', pct: 0, addFees: false, payeeId: '', on: true }); renderShareEditor(); };
$('#setDeductions').onclick = e => { const i = e.target.dataset.rmded; if (i == null) return; state.settings.director.deductions = readDed(); state.settings.director.deductions.splice(Number(i), 1); renderDedEditor(); };
$('#setShares').onclick = e => { const i = e.target.dataset.rmshare; if (i == null) return; state.settings.director.shares = readShares(); state.settings.director.shares.splice(Number(i), 1); renderShareEditor(); };
$('#setPayForms').onclick = e => { const i = e.target.dataset.rmpay; if (i == null) return; state.settings.paymentForms.splice(Number(i), 1); renderPayForms(); };
$('#addPayForm').onclick = () => { const v = upperAz($('#newPayForm').value); if (!v) return; if (!state.settings.paymentForms.includes(v)) state.settings.paymentForms.push(v); $('#newPayForm').value = ''; renderPayForms(); };
$('#resetDirector').onclick = () => { if (!confirm('Direktor bölgüsü standart vəziyyətə qaytarılsın?')) return; state.settings.director = DEFAULT_DIRECTOR(); ensurePayees(); renderSettings(); toast('Standart bölgü yükləndi — "Yadda saxla" basın'); };
$('#saveSettings').onclick = saveSettings;
$('#backupExport').onclick = () => download(`SURUCU_EHTIYAT_${isoToday()}.json`, JSON.stringify({ version: 'v10', exportedAt: new Date().toISOString(), drivers: state.drivers, archive: state.archive.map(compactRow), payments: state.payments, director: state.director, settings: state.settings }, null, 1));
$('#backupImport').onclick = () => $('#backupFile').click();
$('#backupFile').onchange = e => { if (e.target.files[0]) backupImport(e.target.files[0]); e.target.value = ''; };
$('#legacyExport').onclick = async () => { const d = await chrome.storage.local.get(['drivers2', 'archive2', 'drivers', 'archive']); download(`SURUCU_KOHNE_V9_${isoToday()}.json`, JSON.stringify(d, null, 1)); };
$('#modalX').onclick = closeModal;
$('#modal').addEventListener('mousedown', e => { if (e.target.id === 'modal') closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

window.addEventListener('ammo-cloud-updated', async () => {
  if (!$('#modal').classList.contains('hidden') || (document.activeElement && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName))) return;
  await readStore(); ensurePayees(); refreshFeeStates(); renderAll();
});

window.SG = { state, calc, directorCalc, importReportAoa, classifyAoa }; // diaqnostika üçün
load();
