AMMO SUITE V31 — YENİLİKLƏR
===========================

1) YENİ İNTERFEYS
   • Sol menyu qruplara bölündü: Vergi · Maliyyə və kadr · Komanda. Emoji əvəzinə vahid xətti ikonlar.
   • Yuxarıda nazik zolaq: hansı bölmədəsiniz, server vəziyyəti və "yenilə" düyməsi.
   • Admin düymələri (Panellər, Modullar, Cihazlar), "Yeniləməni yoxla" və "Çıxış" — sol aşağıda
     adınıza basanda açılan menyudadır.
   • Yeni giriş ekranı.
   • Bütün panellər vahid rəngdədir: bir əsas mavi, neytral boz, ağ kartlar. Panellərin öz daxili menyusu
     açıq rəngli alt-menyu oldu (iki tünd menyu yan-yana durmur). Rənglər bir fayldadır: theme/ammo-ui.css.

2) GÖMRÜK NƏZARƏT PANELİ LƏĞV EDİLDİ
   • Panel paketdən çıxarıldı; admin ilk girişdə onu Firebase modul reyestrindən də silir.
   • İstifadə olunmayan köhnə fayllar (popup, Mənfəət-visual və s.) da silindi.

3) HAMISI BİR FIREBASE LAYİHƏSİNDƏ (Konsalting)
   • Bəyannamə nəzarət və Vergi məktubları artıq GOMRUK-NEZARET-də deyil, Konsalting-dədir
     (kolleksiyalar: beyannameNezaret, beyannameUcotu). Giriş AMMO SUITE hesabı ilə — ayrıca parol yoxdur.
   • Köçürmə avtomatikdir: panel açılanda köhnə layihədəki qeydlər Konsalting-ə yazılır. Eyni qeyd iki dəfə
     yazılmır; köhnə layihədəki daha yenidirsə yenilənir; Konsalting-də silinən qeyd geri qayıtmır.
   • Silmə artıq "yumşaq"dır (deleted: true) — bütün kompüterlərdə silinir.
   • GOMRUK-NEZARET layihəsini, bütün işçilər V31-ə keçəndən və panellərdə məlumatı yoxlayandan SONRA
     silmək olar. Silindikdən sonra köçürmə özü dayanır.

V31.0.1
   • Admin bağladığı paneli öz menyusunda görməyə davam edir ("gizli" işarəsi ilə); işçilərdə görünmür.
   • Panelləri idarə et: sol aşağıda adınıza basın → "Panelləri idarə et" (yalnız memmed@ammo.az).
