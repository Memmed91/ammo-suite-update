const modules = {
  gomruk: { url: "modules/gomruk/main.html" },
  menfeet: { url: "modules/menfeet-html-full/popup.html" },
  beyannameUcotu: { url: "modules/beyanname-ucotu/popup.html" },
  beyannameNezaret: { url: "modules/beyanname-nezaret/app.html" },
  taskpanel: { url: "modules/taskpanel/index.html" },
  emekhaqqi: { url: "modules/emekhaqqi/app.html" },
  surucu: { url: "modules/surucu-gelir/app.html" },
  links: { url: "modules/links/links.html" },
  "akt-sened": { title: "📄 AKT SƏNƏD HAZIRLA" },
  "akt-protokol": { title: "📋 AKT VƏ PROTOKOL" },
  muqavile: { title: "🤝 XİDMƏT MÜQAVİLƏSİ" },
  asanimza: { title: "🔑 ASAN İMZA AXTARIŞ" }
};
const panel = document.getElementById("panel");
document.querySelectorAll(".module").forEach(btn => btn.addEventListener("click", () => {
  const key = btn.dataset.module;
  const mod = modules[key];
  if (mod.url) {
    const u = new URL(chrome.runtime.getURL("suite.html"));
    u.searchParams.set("module", key);
    chrome.tabs.create({ url: u.href });
    window.close();
    return;
  }
  document.getElementById("panelTitle").textContent = mod.title;
  document.getElementById("panelBody").innerHTML = '<div class="notice">Bu modulun faylları hələ əlavə edilməyib.</div>';
  panel.classList.remove("hidden");
}));
document.getElementById("closePanel").addEventListener("click", () => panel.classList.add("hidden"));
