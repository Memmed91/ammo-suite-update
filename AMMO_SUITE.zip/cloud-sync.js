/* AMMO SUITE V14 — açar-səviyyəli səssiz sinxronizasiya.
   Məqsəd:
   - Ekranı və iframe-i yeniləmir.
   - İki istifadəçinin ayrı sahələrdə etdiyi dəyişiklikləri bir-birinin üstünə yazmır.
   - Hər localStorage/chrome.storage açarı ayrıca Firestore sənədidir.
   - V13 suiteSharedV2 məlumatını ilk açılışda oxuyub V14-ə köçürür.
*/
(() => {
  'use strict';
  const PROJECT = 'konsalting-79c40';
  const API_KEY = 'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg';
  const moduleKey = (document.documentElement.dataset.ammoModule || window.AMMO_MODULE || location.pathname.split('/').slice(-2,-1)[0] || 'suite').replace(/[^a-zA-Z0-9_-]/g,'_');
  const BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT}/databases/(default)/documents`;
  const LEGACY_DOC = `${BASE}/suiteSharedV2/${moduleKey}`;
  const KEY_COLLECTION = `${BASE}/suiteSharedV3/${moduleKey}/keys`;
  const EXCLUDE = new Set(['sgDraft','suiteAuth','ammoLastEmail','notified','notificationLog','beyannameFirebaseAuth','ammo_beyanname_nezaret_fixed_auth','ammoOldGomrukAuth']);
  // V28: hər açar yalnız öz modulunda sinxronlaşır. Əvvəl hər modul BÜTÜN açarları öz bulud
  // kolleksiyasına yükləyib geri yazırdı və başqa modulun köhnə surəti (məs. Borc "records")
  // yeni məlumatın üstünə yazılırdı. İndi açarın sahibi müəyyəndir.
  const OWNERS = {
    records:'borc-xatirlatici', borcSettings:'borc-xatirlatici',
    archive:'surucu-gelir', archive2:'surucu-gelir', drivers:'surucu-gelir', drivers2:'surucu-gelir',
    sgDrivers:'surucu-gelir', sgPayments:'surucu-gelir', sgSettings:'surucu-gelir', sgDirector:'surucu-gelir', sgMeta:'surucu-gelir',
    eh_state_v2:'emekhaqqi', eh_monthly_archives_v2:'emekhaqqi', ammo_calendar_fix_v257:'emekhaqqi',
    ammo_beyanname_nezaret_fixed_local:'beyanname-nezaret',
    beyannameUcotuLocalCache:'vergi-mektublari',
    menfeetHtmlFull:'menfeet',
    reports:'hesabat-vaxti', emails:'hesabat-vaxti', phones:'hesabat-vaxti', settings:'hesabat-vaxti',
    periodStatusMap:'hesabat-vaxti', dataVersion:'hesabat-vaxti', initialized:'hesabat-vaxti', basePeriodStart:'hesabat-vaxti',
    senedProfiles_v1:'sened-hazirla', senedHistory_v1:'sened-hazirla', senedCounters_v1:'sened-hazirla', senedDraft_v1:'sened-hazirla',
    edvColumnPrefs_v1:'edv-analiz',
    // V30.2
    ammo_sexsi_hesab_v1:'sexsi-hesab', ammo_sexsi_requisites_v1:'sexsi-hesab',
    ammo_bn_etax_map_v1:'beyanname-nezaret', ammo_bn_etax_seen_v1:'beyanname-nezaret'
  };
  // V30: Sürücü modulu arxivi aylara bölünür (sgArchive_YYYY_MM)
  const ownerOf = (key) => OWNERS[key] || (String(key).startsWith('sgArchive_') ? 'surucu-gelir' : '');
  const owns = (key) => { const o = ownerOf(key); return o ? o === moduleKey : true; };
  const ownsStrict = (key) => ownerOf(key) === moduleKey;
  const dirtyChrome = new Set(), dirtyLocal = new Set(), removedChrome = new Set(), removedLocal = new Set();
  const knownUpdate = new Map();
  let applying = false, saveTimer = null, saving = false, hydrated = false;
  // V29.2: açılışda modulun yazdığı başlanğıc (çox vaxt boş) dəyərlər buluddakı məlumatın üstünə yazılmasın
  const pageLoadAt = Date.now(), INIT_WINDOW = 4000;
  const pending = new Map();      // hidratasiyadan əvvəlki yazılar: 'scope:key' -> {scope,key,at,removed}
  const cloudKeys = new Set();    // buludda dəyəri olan 'scope:key'
  function markDirty(scope, key, removed){
    const id = `${scope}:${key}`, now = Date.now();
    if(!hydrated){ pending.set(id,{scope,key,at:now,removed}); return false; }
    if(now - pageLoadAt < INIT_WINDOW && cloudKeys.has(id)) return false; // başlanğıc yazısı — buludu qoru
    const D = scope==='chrome' ? [dirtyChrome, removedChrome] : [dirtyLocal, removedLocal];
    if(removed){ D[1].add(key); D[0].delete(key); } else { D[0].add(key); D[1].delete(key); }
    return true;
  }

  const enc = v => {
    if (v === null) return {nullValue:null};
    if (Array.isArray(v)) return {arrayValue:{values:v.map(enc)}};
    if (typeof v === 'boolean') return {booleanValue:v};
    if (typeof v === 'number') return Number.isInteger(v) ? {integerValue:String(v)} : {doubleValue:v};
    if (typeof v === 'object') return {mapValue:{fields:Object.fromEntries(Object.entries(v).map(([k,x])=>[k,enc(x)]))}};
    return {stringValue:String(v)};
  };
  const dec = v => {
    if (!v) return null;
    if ('stringValue' in v) return v.stringValue;
    if ('integerValue' in v) return Number(v.integerValue);
    if ('doubleValue' in v) return v.doubleValue;
    if ('booleanValue' in v) return v.booleanValue;
    if ('timestampValue' in v) return v.timestampValue;
    if ('nullValue' in v) return null;
    if ('arrayValue' in v) return (v.arrayValue.values||[]).map(dec);
    if ('mapValue' in v) return Object.fromEntries(Object.entries(v.mapValue.fields||{}).map(([k,x])=>[k,dec(x)]));
    return null;
  };
  const same = (a,b) => { try { return JSON.stringify(a) === JSON.stringify(b); } catch { return a === b; } };
  const docId = (scope,key) => `${scope}_${btoa(unescape(encodeURIComponent(key))).replace(/=+$/,'').replace(/\+/g,'-').replace(/\//g,'_')}`;

  async function getAuth(){
    let {suiteAuth:a} = await chrome.storage.local.get('suiteAuth');
    if (!a?.idToken) return null;
    const expiresAt = Number(a.expiresAt || 0);
    if (a.refreshToken && (!expiresAt || Date.now() > expiresAt - 120000)) {
      try {
        const r = await fetch(`https://securetoken.googleapis.com/v1/token?key=${API_KEY}`, {
          method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
          body:new URLSearchParams({grant_type:'refresh_token',refresh_token:a.refreshToken})
        });
        const d = await r.json();
        if (r.ok) {
          a = {...a,idToken:d.id_token,refreshToken:d.refresh_token||a.refreshToken,uid:d.user_id||a.uid,expiresAt:Date.now()+Number(d.expires_in||3600)*1000};
          await originalSet({suiteAuth:a});
        }
      } catch(e) { console.warn('AMMO token refresh',e); }
    }
    return a;
  }
  async function request(url,options={}){
    const a=await getAuth();
    if(!a?.idToken) return null;
    const r=await fetch(url,{...options,headers:{Authorization:`Bearer ${a.idToken}`,...(options.headers||{})},cache:'no-store'});
    if(!r.ok && r.status!==404) throw new Error(`Firebase ${r.status}`);
    return r;
  }
  async function listCloud(){
    const out=[]; let token='';
    do {
      const u=`${KEY_COLLECTION}?pageSize=300${token?`&pageToken=${encodeURIComponent(token)}`:''}`;
      const r=await request(u); if(!r || r.status===404) return out;
      const d=await r.json(); out.push(...(d.documents||[])); token=d.nextPageToken||'';
    } while(token);
    return out;
  }
  async function writeOne(scope,key,value,deleted){
    if(EXCLUDE.has(key) || !owns(key) || String(key).startsWith('taskFiles_') || String(key).startsWith('ammo_cloud_') || String(key).startsWith('ammoMigV31_')) return;
    const a=await getAuth(); if(!a?.idToken) return;
    const now=new Date().toISOString();
    const body={fields:{module:{stringValue:moduleKey},scope:{stringValue:scope},key:{stringValue:key},deleted:{booleanValue:Boolean(deleted)},updatedAt:{timestampValue:now},updatedBy:{stringValue:a.email||a.uid||''},value:enc(value)}};
    const r=await request(`${KEY_COLLECTION}/${docId(scope,key)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    if(r){ knownUpdate.set(`${scope}:${key}`,now); if(deleted) cloudKeys.delete(`${scope}:${key}`); else cloudKeys.add(`${scope}:${key}`); }
  }
  async function flush(){
    if(applying||saving||(!dirtyChrome.size&&!dirtyLocal.size&&!removedChrome.size&&!removedLocal.size)) return;
    saving=true;
    const cSet=[...dirtyChrome],lSet=[...dirtyLocal],cDel=[...removedChrome],lDel=[...removedLocal];
    try{
      const cVals=cSet.length?await chrome.storage.local.get(cSet):{};
      for(const k of cSet) await writeOne('chrome',k,cVals[k],false);
      for(const k of lSet) await writeOne('local',k,localStorage.getItem(k),false);
      for(const k of cDel) await writeOne('chrome',k,null,true);
      for(const k of lDel) await writeOne('local',k,null,true);
      if(cSet.length||lSet.length||cDel.length||lDel.length) window.AMMO_REV?.bump('mod_'+moduleKey);
      cSet.forEach(k=>dirtyChrome.delete(k)); lSet.forEach(k=>dirtyLocal.delete(k)); cDel.forEach(k=>removedChrome.delete(k)); lDel.forEach(k=>removedLocal.delete(k));
    } catch(e){ console.warn('AMMO cloud save',e); }
    finally{saving=false;}
  }
  function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(flush,700);}

  async function applyDocs(docs,{initial=false}={}){
    let changed=false; applying=true;
    try{
      for(const d of docs){
        const f=d.fields||{}, scope=dec(f.scope), key=dec(f.key), deleted=dec(f.deleted)===true, updated=dec(f.updatedAt)||d.updateTime||'';
        if(!scope||!key||EXCLUDE.has(key)||!owns(key)||String(key).startsWith('taskFiles_')) continue;
        const marker=`${scope}:${key}`;
        if(!initial && updated && knownUpdate.get(marker)===updated) continue;
        if(scope==='chrome'){
          if(dirtyChrome.has(key)||removedChrome.has(key)) continue;
          if(deleted){ const cur=await chrome.storage.local.get(key); if(Object.prototype.hasOwnProperty.call(cur,key)){await originalRemove(key);changed=true;} }
          else { const val=dec(f.value),cur=(await chrome.storage.local.get(key))[key]; if(!same(cur,val)){await originalSet({[key]:val});changed=true;} }
        } else if(scope==='local'){
          if(dirtyLocal.has(key)||removedLocal.has(key)) continue;
          if(deleted){if(localStorage.getItem(key)!==null){lsRemove(key);changed=true;}}
          else {const val=dec(f.value),text=val===null?'':String(val);if(localStorage.getItem(key)!==text){lsSet(key,text);changed=true;}}
        }
        if(updated) knownUpdate.set(marker,updated);
        if(deleted) cloudKeys.delete(marker); else cloudKeys.add(marker);
      }
    } finally{applying=false;}
    return changed;
  }
  async function uploadCurrentLocalState(){
    const chromeValues=await chrome.storage.local.get(null);
    const jobs=[];
    for(const [k,v] of Object.entries(chromeValues||{})){
      if(EXCLUDE.has(k)||!ownsStrict(k)) continue;
      jobs.push(writeOne('chrome',k,v,false));
    }
    for(let i=0;i<localStorage.length;i++){
      const k=localStorage.key(i);
      if(!k||!ownsStrict(k)) continue;
      jobs.push(writeOne('local',k,localStorage.getItem(k),false));
    }
    for(let i=0;i<jobs.length;i+=20) await Promise.all(jobs.slice(i,i+20));
  }
  async function migrateLegacyIfNeeded(){
    const existing=await listCloud(); if(existing.length) return existing;
    const r=await request(LEGACY_DOC);
    if(r&&r.status!==404){
      const d=await r.json(), payload=dec(d.fields?.payload)||{};
      const tasks=[];
      for(const [k,v] of Object.entries(payload.chrome||{})) tasks.push(writeOne('chrome',k,v,false));
      for(const [k,v] of Object.entries(payload.local||{})) tasks.push(writeOne('local',k,v,false));
      for(let i=0;i<tasks.length;i+=20) await Promise.all(tasks.slice(i,i+20));
      return listCloud();
    }
    await uploadCurrentLocalState();
    return listCloud();
  }
  async function hydrate(){
    try{
      if(!(await getAuth())?.idToken) throw new Error('giriş yoxdur');
      const docs=await migrateLegacyIfNeeded();
      for(const d of docs){ const f=d.fields||{}; if(dec(f.deleted)!==true && dec(f.scope) && dec(f.key)) cloudKeys.add(`${dec(f.scope)}:${dec(f.key)}`); }
      const changed=await applyDocs(docs,{initial:true});
      hydrated=true;
      // Hidratasiyadan əvvəlki yazılar: buludda olmayan açarlar yüklənir; istifadəçinin sonradan etdiyi dəyişiklik qalır
      for(const [id,p] of pending){
        if(!cloudKeys.has(id) || p.at - pageLoadAt >= INIT_WINDOW){
          const D = p.scope==='chrome' ? [dirtyChrome, removedChrome] : [dirtyLocal, removedLocal];
          if(p.removed){ if(cloudKeys.has(id)) D[1].add(p.key); } else D[0].add(p.key);
        }
      }
      pending.clear(); scheduleSave();
      if(changed){
        // Modul köhnə (boş) yaddaşla açılıb — buluddan gələn məlumatla bir dəfə yenidən aç
        const guard='ammo_cloud_reload_'+moduleKey, last=Number(sessionStorage.getItem(guard)||0);
        if(Date.now()-last>20000){ sessionStorage.setItem(guard,String(Date.now())); location.reload(); return; }
        const detail={module:moduleKey,at:new Date().toISOString()};
        window.dispatchEvent(new CustomEvent('ammo-cloud-updated',{detail})); document.dispatchEvent(new CustomEvent('ammo-cloud-updated',{detail}));
      }
      showBadge('☁ Məlumatlar buludla eynidir');
    }catch(e){
      console.warn('AMMO cloud hydrate',e);
      showBadge('⚠ Bulud bağlantısı gözlənilir...');
      setTimeout(hydrate, 8000);
    }
  }
  async function poll(){
    if(!hydrated) return;
    try{
      const docs=await listCloud();
      const changed=await applyDocs(docs);
      if(changed){
        const detail={module:moduleKey,at:new Date().toISOString()};
        window.dispatchEvent(new CustomEvent('ammo-cloud-updated',{detail}));
        document.dispatchEvent(new CustomEvent('ammo-cloud-updated',{detail}));
        showBadge('☁ Yeni məlumat gəldi');
      }
    } catch(e){console.warn('AMMO cloud poll',e);}
  }
  function showBadge(text){
    if(!document.body){document.addEventListener('DOMContentLoaded',()=>showBadge(text),{once:true});return;}
    const badge=document.getElementById('ammoCloudBadge')||(()=>{const el=document.createElement('div');el.id='ammoCloudBadge';Object.assign(el.style,{position:'fixed',right:'14px',bottom:'14px',zIndex:999999,padding:'7px 10px',borderRadius:'10px',background:'rgba(11,27,61,.88)',color:'#fff',font:'600 12px system-ui',pointerEvents:'none',opacity:'0',transition:'opacity .2s'});document.body.appendChild(el);return el;})();
    badge.textContent=text;badge.style.opacity='1';clearTimeout(badge._t);badge._t=setTimeout(()=>badge.style.opacity='0',1100);
  }

  const originalSet=chrome.storage.local.set.bind(chrome.storage.local), originalRemove=chrome.storage.local.remove.bind(chrome.storage.local);
  chrome.storage.local.set=(items,cb)=>new Promise(resolve=>originalSet(items,()=>{if(!applying){for(const k of Object.keys(items||{}))if(!EXCLUDE.has(k)&&!String(k).startsWith('taskFiles_'))markDirty('chrome',k,false);scheduleSave();}cb&&cb();resolve();}));
  chrome.storage.local.remove=(keys,cb)=>new Promise(resolve=>originalRemove(keys,()=>{const arr=Array.isArray(keys)?keys:[keys];if(!applying){for(const k of arr)if(!EXCLUDE.has(k)&&!String(k).startsWith('taskFiles_'))markDirty('chrome',k,true);scheduleSave();}cb&&cb();resolve();}));
  const lsSet=localStorage.setItem.bind(localStorage),lsRemove=localStorage.removeItem.bind(localStorage),lsClear=localStorage.clear.bind(localStorage);
  localStorage.setItem=(k,v)=>{lsSet(k,v);if(!applying&&!String(k).startsWith('ammo_cloud_')){markDirty('local',String(k),false);scheduleSave();}};
  localStorage.removeItem=k=>{lsRemove(k);if(!applying&&!String(k).startsWith('ammo_cloud_')){markDirty('local',String(k),true);scheduleSave();}};
  localStorage.clear=()=>{const keys=[];for(let i=0;i<localStorage.length;i++)keys.push(localStorage.key(i));lsClear();if(!applying){for(const k of keys)if(k&&!String(k).startsWith('ammo_cloud_'))markDirty('local',String(k),true);scheduleSave();}};

  // V30.2: yenilənmədən/yenidən yükləmədən əvvəl son dəyişikliklər mütləq buluda yazılsın
  window.AmmoCloudFlush=async()=>{clearTimeout(saveTimer);for(let i=0;i<20&&saving;i++)await new Promise(r=>setTimeout(r,150));await flush();};
  try{chrome.runtime.onMessage.addListener((m,s,send)=>{if(m?.type!=='AMMO_FLUSH_NOW')return;window.AmmoCloudFlush().then(()=>send({ok:true,module:moduleKey})).catch(()=>send({ok:false}));return true;});}catch(e){}
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')flush();});
  window.AmmoCloudReady=hydrate();
  // V31.0.2: hər 3 saniyədə bütün açarları oxumaq əvəzinə dəyişiklik nişanı (Firebase gündəlik limitinə qənaət)
  if(window.AMMO_REV) window.AMMO_REV.watch('mod_'+moduleKey,{every:30000},poll);
  else setInterval(()=>{ if(document.visibilityState==='visible') poll(); },60000);
  window.addEventListener('online',()=>{poll();flush();});
  window.addEventListener('beforeunload',()=>{if(saveTimer){clearTimeout(saveTimer);flush();}});
})();
