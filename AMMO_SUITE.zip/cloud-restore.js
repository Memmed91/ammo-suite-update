/* AMMO SUITE V30.2 — serverdən tam bərpa.
   AMMO SUITE açılanda (giriş varsa) bütün panellərin Firebase-dəki məlumatı bu kompüterə gətirilir:
   yeni kompüter, yenidən quraşdırma və ya yeni versiya — panelləri tək-tək açmağa ehtiyac yoxdur,
   arxa fon xidmətləri (Borc xatırladıcı, Hesabat vaxtı, WhatsApp) də dərhal məlumatla işləyir.
   Qayda: yalnız bu kompüterdə OLMAYAN açarlar yazılır; mövcud olanları panel özü açılanda buludla tutuşdurur. */
(() => {
  'use strict';
  const PROJECT = 'konsalting-79c40', API_KEY = 'AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg';
  const BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT}/databases/(default)/documents/suiteSharedV3`;
  const MODULES = ['taskpanel', 'emekhaqqi', 'kurs', 'sexsi-hesab', 'surucu-gelir', 'vergi-mektublari', 'beyanname-nezaret', 'menfeet', 'links', 'hesabat-vaxti', 'borc-xatirlatici', 'mal-hereketi-pro'];
  const EXCLUDE = /^(ammoOldGomrukAuth|ammoMigV31_|suiteAuth|ammoLastEmail|beyannameFirebaseAuth|ammo_beyanname_nezaret_fixed_auth|sgDraft|ammo_cloud_|taskFiles_|updateAvailable|justUpdated|ammoLatestInfo|lastRunVersion|ammoDeviceId)/;

  const dec = (v) => {
    if (!v) return null;
    if ('stringValue' in v) return v.stringValue; if ('integerValue' in v) return Number(v.integerValue); if ('doubleValue' in v) return v.doubleValue;
    if ('booleanValue' in v) return v.booleanValue; if ('timestampValue' in v) return v.timestampValue; if ('nullValue' in v) return null;
    if ('arrayValue' in v) return (v.arrayValue.values || []).map(dec);
    if ('mapValue' in v) return Object.fromEntries(Object.entries(v.mapValue.fields || {}).map(([k, x]) => [k, dec(x)]));
    return null;
  };
  async function auth() {
    let { suiteAuth: a } = await chrome.storage.local.get('suiteAuth');
    if (!a?.refreshToken) return a;
    if (a.expiresAt && Date.now() < Number(a.expiresAt) - 120000) return a;
    try {
      const r = await fetch(`https://securetoken.googleapis.com/v1/token?key=${API_KEY}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: a.refreshToken }) });
      const d = await r.json();
      if (r.ok) { a = { ...a, idToken: d.id_token, refreshToken: d.refresh_token || a.refreshToken, expiresAt: Date.now() + Number(d.expires_in || 3600) * 1000 }; await chrome.storage.local.set({ suiteAuth: a }); }
    } catch (e) { /* oflayn */ }
    return a;
  }
  async function listModule(mod, token) {
    const out = []; let page = '';
    do {
      const r = await fetch(`${BASE}/${mod}/keys?pageSize=300${page ? '&pageToken=' + encodeURIComponent(page) : ''}`, { headers: { Authorization: `Bearer ${token}` }, cache: 'no-store' });
      if (!r.ok) return out;
      const d = await r.json(); out.push(...(d.documents || [])); page = d.nextPageToken || '';
    } while (page);
    return out;
  }
  let running = false;
  async function restoreAll(reason) {
    if (running) return null; running = true;
    const status = document.getElementById('syncStatus');
    try {
      const a = await auth(); if (!a?.idToken) return null;
      if (status) status.textContent = '☁ Serverdən yüklənir...';
      const local = await chrome.storage.local.get(null);
      const lists = await Promise.all(MODULES.map((m) => listModule(m, a.idToken).catch(() => [])));
      const setChrome = {}; let lsCount = 0;
      lists.flat().forEach((d) => {
        const f = d.fields || {}; const scope = dec(f.scope), key = dec(f.key);
        if (!scope || !key || dec(f.deleted) === true || EXCLUDE.test(key)) return;
        if (scope === 'chrome' && !(key in local) && !(key in setChrome)) setChrome[key] = dec(f.value);
        if (scope === 'local' && localStorage.getItem(key) === null) { const v = dec(f.value); localStorage.setItem(key, v === null ? '' : String(v)); lsCount++; }
      });
      const n = Object.keys(setChrome).length;
      if (n) await chrome.storage.local.set(setChrome);
      await chrome.storage.local.set({ ammoLastCloudRestore: { at: Date.now(), reason, chrome: n, local: lsCount } });
      if (status) status.textContent = (n + lsCount) ? `☁ Serverdən bərpa: ${n + lsCount} məlumat` : '☁ Məlumatlar serverlə eynidir';
      return { chrome: n, local: lsCount };
    } catch (e) {
      if (status) status.textContent = '⚠ Server bağlantısı gözlənilir';
      return null;
    } finally { running = false; }
  }
  window.AmmoCloudRestore = restoreAll;
  // Giriş edilən kimi və hər açılışda bir dəfə
  (async () => { const { suiteAuth } = await chrome.storage.local.get('suiteAuth'); if (suiteAuth?.idToken) restoreAll('open'); })();
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.suiteAuth && ch.suiteAuth.newValue && !ch.suiteAuth.oldValue) restoreAll('login'); });
})();
