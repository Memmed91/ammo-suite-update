AMMO SUITE V25.2 — STATUS RƏNGLƏRİ

Bəyannamə Nəzarət panelində açılan status siyahısındakı bütün seçimlər qara rəngdə göstərilir.
Status Əlavə et / Yadda saxla düyməsi ilə cədvələ düşdükdən sonra:
- TƏSDİQLƏNDİ — yaşıl
- UYĞUNSUZLUQ YOXLAMASINDA — qırmızı
- KAMERAL — sarı fon, qırmızı yazı və yanıb-sönmə
- KAMERAL TƏSDİQLƏNDİ — yaşıl və yanıb-sönmə
- ANOLOJİ — bənövşəyi
- ANOLOJİ TƏSDİQLƏNDİ — yaşıl
- TƏQDİM OLUNAN — açıq göy
