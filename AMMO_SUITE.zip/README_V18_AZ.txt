AMMO SUITE V18

Düzəlişlər:
- TaskPanel: Sahibkarlar düyməsi Yenilə və Yeni tapşırıq arasında.
- Sürücü gəliri: Sahibkarlar düyməsi Hesabat tarixi sahəsinin solunda.
- Vergi məktubları: Vergi sənədi və Sahibkarlar düymələri Firebase statusu ilə Çıxış arasında.
- Bəyannamə nəzarət: Sahibkarlar düyməsi Firebase və Excel arasında.
- Düymələr artıq başlıqların və digər elementlərin üzərinə çıxmır.
