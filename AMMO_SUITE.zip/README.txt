AMMO 2.15

Düzəliş:
ƏDV bəyannaməsində 301 başlığı altında olan
"Təqdim edilmiş mal, iş və xidmətlərin dəyəri (ƏDV nəzərə alınmadan)"
sütununun ən aşağı CƏMİ məbləği götürülür və Mənfəət bəyannaməsində 200.1 xanasına yazılır.

Digər qaydalar saxlanılıb:
- OMV 1607.1.1 -> 221.5.1.1
- OMV 1607.1.2 -> 221.5.1.2
- Vahid 902 -> 221.1.2
- Gələn qaimə mal -> 221.4
- Gələn qaimə xidmət -> 221.15


2.16: BƏYANNAMƏ UÇOTU modulu AMMO əsas menyusuna əlavə edildi.
