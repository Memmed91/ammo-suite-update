AMMO SUITE V28 — DÜZƏLİŞLƏR
===========================

1) BORC XATIRLADICI — 250 AZN yazılır, 600/500 görünürdü
   Səbəb 1: Qeydlər avtomatik "Hər ay üzrə" yazılırdı. Başlama ayından cari aya qədər hər ay
            250 AZN əlavə olunur və ümumi baxışda bütün ödənilməmiş ayların CƏMİ görünürdü
            (məs: 250 × 2 ay = 500).
   Səbəb 2: Tarix xətası — toISOString() Bakı saatında (UTC+4) tarixi 1 gün geri sürüşdürürdü,
            ay adları və son tarixlər səhv çıxırdı (Avqust əvəzinə İyul və s.). DÜZƏLDİLDİ.
   Səbəb 3: Borc modulu "settings" açarını Hesabat Vaxtı modulu ilə paylaşırdı — biri digərinin
            ayarlarını silirdi ("undefined gün içində" xətası da buradan idi). İndi "borcSettings".
   Səbəb 4: Bulud sinxronizasiyası hər modulda BÜTÜN açarları yükləyib geri yazırdı; başqa
            modulun köhnə surəti Borc qeydlərinin üstünə yaza bilirdi. İndi hər açarın sahibi var.

2) İKİ BÖLMƏ: "1 dəfəlik" və "Hər ay üzrə"
   - Ümumi baxışda iki ayrı kart: Hər ay üzrə (aylıq məbləğ + ödənilməmiş aylar) və 1 dəfəlik.
   - Alacaqlarım / Verəcəklərim: iki ayrı cədvəl + "Hamısı / Hər ay üzrə / 1 dəfəlik" tabları.
   - Aylıq qeydlərdə əsas rəqəm AYLIQ məbləğdir (250 AZN / ay), qalıq ayrıca göstərilir.
   - Yeni qeyddə ödəniş növünü seçmək MƏCBURİDİR (avtomatik "hər ay" seçilmir).
   - ⇄ düyməsi: mövcud qeydi bir kliklə 1 dəfəliyə və ya hər ay üzrəyə çevirir.
   - 1 dəfəlik qeyddə ✓ düyməsi ilə "Aldım / Ödədim".
   - Hesabat, CSV və Excel-də "Ödəniş növü" sütunu.

3) VAHİD DİZAYN — bütün bölmələr AMMO loqosunun mavi rənginə uyğunlaşdırıldı
   (TaskPanel, Əməkhaqqı, Sürücü gəliri, Vergi məktubları, Bəyannamə nəzarət, Mənfəət,
   Linklər, Hesabat Vaxtı, Borc Xatırladıcı, Mal Hərəkəti PRO, Gömrük).

4) Digər xətalar
   - Hesabat Vaxtı: "undefined gün içində" düzəldildi.
   - İnternet olmayanda Sahibkarlar siyahısı səhifədə xəta atırdı — düzəldildi.
   - Borc statistikası və hesabatlarında gecikmə yalnız 1-ci aya görə hesablanırdı — düzəldildi.
   - Yeni ay başlayanda yaradılan aylar yadda saxlanmırdı — düzəldildi.
   - Admin modul siyahısında HTML təhlükəsizliyi (escape) əlavə edildi.

QURAŞDIRMA: chrome://extensions → köhnə AMMO SUITE-i "Yenilə" etmək əvəzinə qovluğu bu
yeni qovluqla əvəz edin və ya "Load unpacked" ilə bu qovluğu seçin. Məlumatlar qorunur.
Mövcud Salaməli / Turan Göktel qeydləri 1 dəfəlikdirsə, siyahıda ⇄ düyməsini basın.

V28.1 — PANELLƏRİ İDARƏ ET
==========================
- Sol altda "☰ Panelləri idarə et" düyməsi (bütün istifadəçilər üçün).
- Hər panelin yanında açar (aç / bağla), ▲▼ ilə sıranı dəyişmək, "Aç" ilə dərhal keçid.
- "Hamısını aç" və "Sıranı sıfırla" düymələri. Ən azı 1 panel həmişə açıq qalır.
- Seçim bu kompüterdə yadda qalır. Admin (memmed@ammo.az) üçün əlavə olaraq
  "⚙ Bütün kompüterlər üçün (admin)" — köhnə modul idarəetməsi (Firebase) saxlanılıb.
- Düzəliş: internet kəsiləndə və ya 1 saatdan sonra (token vaxtı bitəndə) sistem
  istifadəçini çıxarırdı və pəncərənin içində ikinci AMMO SUITE açılırdı. İndi token
  avtomatik yenilənir, internet yoxdursa "Yenidən cəhd et" ekranı göstərilir.

V28.2 — AYLIQ BORC AY BİTƏNDƏ YAZILIR (alacaq və verəcək)
=========================================================
- Əvvəl: başlama ayından CARİ AY daxil olmaqla bütün aylar dərhal borc yazılırdı
  (məs: EV 570 AZN, başlama 05.09.2026 → 05.10.2026-da 1.140 AZN görünürdü).
- İndi: ay bitəndə (son tarix gələndə) həmin ay üzrə borc yazılır.
  Başlama 01.09.2026 → 01.10.2026-da "Sentyabr 2026" borcu, 01.11.2026-da "Oktyabr 2026".
  EV nümunəsində 05.10.2026-da qalıq 570 AZN olur.
- Ayları açanda növbəti ay "Hələ hesablanmayıb — dd.mm.yyyy-də yazılacaq" kimi görünür.
- Növbəti aya 5 gün qalanda "5 gün qalan ödənişlər" siyahısında və Chrome bildirişində çıxır.
- Əvvəlcədən ödənilmiş aylar silinmir. Yeni əlavə edilən aylıq qeyd siyahıda dərhal görünür.
- Panelləri idarə et modulu (☰) bu versiyaya daxildir.
