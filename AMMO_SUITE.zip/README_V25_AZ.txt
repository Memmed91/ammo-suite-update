AMMO SUITE V25 — TAM SİNXRONİZASİYA DÜZƏLİŞİ

DÜZƏLDİLƏN PROBLEMLƏR
1. Firestore qaydalarına suiteSharedV2, suiteSharedV3/keys və suiteModules kolleksiyaları əlavə edildi.
2. Bulud boş olduqda ilk açılan kompüterdəki mövcud lokal məlumatlar avtomatik Firestore-a başlanğıc məlumat kimi yüklənir.
3. Sonrakı dəyişikliklər açar-səviyyəli şəkildə təxminən 3 saniyə ərzində digər kompüterlərə ötürülür.
4. TaskPanel-də işçi yalnız öz gələn və göndərilən tapşırıqlarını təhlükəsiz Firestore sorğuları ilə alır.
5. Sənəd, şəkil və səs faylları taskFileChunks + taskFileManifests sistemi ilə göndərən və alan tərəfdə açılır/yüklənir.

MÜTLƏQ QURAŞDIRMA
1. Firebase Console > Firestore Database > Rules bölməsini açın.
2. FIRESTORE_RULES_AMMO_SUITE.txt faylının BÜTÜN məzmununu köhnə qaydaların yerinə yerləşdirin və Publish edin.
3. Bütün kompüterlərdə köhnə AMMO SUITE uzantısını söndürün və ya silin.
4. chrome://extensions > Developer mode > Load unpacked ilə bu V25 qovluğunu seçin.
5. Hər istifadəçi öz Firebase Authentication email və şifrəsi ilə daxil olmalıdır.
6. users/{UID} profilində active=true olmalıdır; işçidə role=employee, admində role=admin.

İLK SİNXRONİZASİYA
Əvvəlcə əsas məlumatların olduğu admin kompüterində V25-i açın və hər modula bir dəfə daxil olun. Bulud boşdursa həmin kompüterdəki məlumatlar başlanğıc baza kimi yüklənəcək. Sonra işçi kompüterlərində V25-i açın.
