(()=>{'use strict';
const P='konsalting-79c40',K='AIzaSyDyFppIEdpJomUAmeQ8b9V96rpBM9cG2Jg',BASE=`https://firestore.googleapis.com/v1/projects/${P}/databases/(default)/documents`;
const dec=v=>!v?null:'stringValue'in v?v.stringValue:'integerValue'in v?Number(v.integerValue):'booleanValue'in v?v.booleanValue:null;
async function auth(){let a=(await chrome.storage.local.get('suiteAuth')).suiteAuth;if(!a)return null;if(a.refreshToken&&(!a.expiresAt||Date.now()>a.expiresAt-120000)){try{const r=await fetch(`https://securetoken.googleapis.com/v1/token?key=${K}`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',refresh_token:a.refreshToken})});const d=await r.json();if(r.ok){a={...a,idToken:d.id_token,refreshToken:d.refresh_token||a.refreshToken,expiresAt:Date.now()+Number(d.expires_in||3600)*1000};await chrome.storage.local.set({suiteAuth:a})}}catch(e){console.warn('AMMO token',e)}}return a}
async function list(){const a=await auth();if(!a)return[];const r=await fetch(`${BASE}/companies?pageSize=1000`,{headers:{Authorization:`Bearer ${a.idToken}`}});if(!r.ok)return[];const d=await r.json();return(d.documents||[]).map(x=>({id:x.name.split('/').pop(),name:dec(x.fields?.name)||'',voen:String(dec(x.fields?.voen)||'')})).filter(x=>x.name&&/^\d{10}$/.test(x.voen)).sort((a,b)=>a.name.localeCompare(b.name,'az'))}
async function add(name,voen){const a=await auth();if(!a)throw Error('Sistemə giriş edilməyib');const id=String(voen).replace(/\D/g,'');const body={fields:{name:{stringValue:String(name).trim()},voen:{stringValue:id},updatedAt:{stringValue:new Date().toISOString()}}};const r=await fetch(`${BASE}/companies/${id}`,{method:'PATCH',headers:{Authorization:`Bearer ${a.idToken}`,'Content-Type':'application/json'},body:JSON.stringify(body)});if(!r.ok){const e=await r.json().catch(()=>({}));throw Error(e?.error?.message||'Firebase yazma xətası')}}
function norm(s){return String(s??'').replace(/\u00a0/g,' ').trim()} function voenOf(v){const x=norm(v).replace(/\.0$/,'').replace(/\D/g,'');return /^\d{10}$/.test(x)?x:''}
function headerKey(s){return norm(s).toLocaleUpperCase('az').replace(/[^A-ZƏÖÜĞÇŞİ0-9]/g,'')}
async function importFile(file){
 const buf=await file.arrayBuffer(),wb=XLSX.read(buf,{type:'array',cellText:true,cellDates:false});let records=[];
 for(const sheetName of wb.SheetNames){const rows=XLSX.utils.sheet_to_json(wb.Sheets[sheetName],{header:1,defval:'',raw:false});if(!rows.length)continue;
  let header=-1,nameCol=-1,voenCol=-1;
  for(let r=0;r<Math.min(rows.length,20);r++){const keys=rows[r].map(headerKey);const v=keys.findIndex(x=>x==='VÖEN'||x==='VOEN'||x.includes('EYNİLƏŞDİRMƏNÖMRƏSİ'));const n=keys.findIndex(x=>x==='SAHİBKARLAR'||x==='SAHİBKAR'||x.includes('ŞİRKƏT')||x.includes('TƏŞKİLAT')||x.includes('VERGİÖDƏYİCİSİNİNADI'));if(v>=0&&n>=0){header=r;nameCol=n;voenCol=v;break}}
  if(header>=0){for(let r=header+1;r<rows.length;r++){const name=norm(rows[r][nameCol]),voen=voenOf(rows[r][voenCol]);if(name&&voen)records.push({name,voen})}}
  else {for(const row of rows){let name='',voen='';for(const cell of row){const v=norm(cell),tax=voenOf(v);if(!voen&&tax)voen=tax;else if(!name&&v&&v.length>2&&!/^(SAHİBKARLAR|VÖEN|VOEN)$/iu.test(v))name=v}if(name&&voen)records.push({name,voen})}}
 }
 const unique=[...new Map(records.map(x=>[x.voen,x])).values()];if(!unique.length)throw Error('Excel-də “SAHİBKARLAR” və “VÖEN” sütunları üzrə uyğun məlumat tapılmadı.');
 let ok=0;for(let i=0;i<unique.length;i+=20){const batch=unique.slice(i,i+20);await Promise.all(batch.map(x=>add(x.name,x.voen)));ok+=batch.length}
 alert(`${ok} sahibkar bazaya əlavə edildi və ya yeniləndi.`);await apply()
}
let companies=[];async function apply(){try{companies=await list();}catch(e){console.warn('AMMO sahibkarlar siyahısı alınmadı (internet?)',e);}let dl=document.getElementById('ammoCompaniesList');if(!dl){dl=document.createElement('datalist');dl.id='ammoCompaniesList';document.body.appendChild(dl)}dl.innerHTML=companies.map(c=>`<option value="${String(c.name).replace(/"/g,'&quot;')}">${c.voen}</option>`).join('');
 const inputs=[...document.querySelectorAll('input')];inputs.forEach(i=>{if(i.dataset.ammoCompanyBound)return;const t=((i.placeholder||'')+' '+(i.id||'')+' '+(i.closest('label')?.textContent||'')).toLocaleLowerCase('az');if(t.includes('təşkilat')||t.includes('şirkət adı')||t.includes('sirket')){i.dataset.ammoCompanyBound='1';i.setAttribute('list','ammoCompaniesList');const select=()=>{const val=norm(i.value).toLocaleLowerCase('az'),c=companies.find(x=>x.name.toLocaleLowerCase('az')===val||x.voen===voenOf(i.value));if(!c)return; i.value=c.name;const scope=i.closest('form,section,.panel,main')||document;const v=[...scope.querySelectorAll('input')].find(x=>(((x.placeholder||'')+' '+(x.id||'')+' '+(x.closest('label')?.textContent||'')).toLocaleLowerCase('az').includes('vöen')));if(v){v.value=c.voen;v.dispatchEvent(new Event('input',{bubbles:true}));v.dispatchEvent(new Event('change',{bubbles:true}))}};i.addEventListener('change',select);i.addEventListener('input',()=>{const c=companies.find(x=>x.name===i.value);if(c)select()})}})}
function ui(){if(document.getElementById('ammoOwnersBtn'))return;
 const module=(document.documentElement.dataset.ammoModule||'').trim();
 const common='position:static!important;inset:auto!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:6px!important;height:40px!important;min-height:40px!important;white-space:nowrap!important;padding:0 14px!important;border:0!important;border-radius:10px!important;color:#fff!important;font:700 13px/1 system-ui!important;box-shadow:0 6px 18px #0002!important;margin:0!important;transform:none!important;flex:0 0 auto!important;';
 const b=document.createElement('button');b.id='ammoOwnersBtn';b.type='button';b.textContent='▣ Sahibkarlar';b.title='SAHİBKARLAR və VÖEN sütunları olan Excel faylını əlavə et';b.style.cssText=common+'background:#177cff!important;';
 const f=document.createElement('input');f.type='file';f.accept='.xlsx,.xls';f.hidden=true;f.onchange=async()=>{if(!f.files[0])return;b.disabled=true;b.textContent='Yüklənir...';try{await importFile(f.files[0])}catch(e){alert('Sahibkarlar faylı oxunmadı: '+e.message)}finally{b.disabled=false;b.textContent='▣ Sahibkarlar';f.value=''}};b.onclick=()=>f.click();document.body.appendChild(f);
 const tax=document.getElementById('taxDocBtn');if(tax)tax.style.cssText=common+'background:#0a3d91!important;';
 let host=null, before=null;
 if(module==='taskpanel'){
   host=document.querySelector('.topbar .top-actions');
   before=host?.querySelector('[data-go="newTask"]')||null;
 }else if(module==='surucu-gelir'||module==='surucu'){
   host=document.querySelector('.hero .header-actions');
   before=host?.querySelector('.datebox')||null;
 }else if(module==='vergi-mektublari'){
   host=document.querySelector('header.top .right-tools');
   before=host?.querySelector('#logoutBtn')||null;
   if(host&&tax)host.insertBefore(tax,before);
 }else if(module==='beyanname-nezaret'){
   host=document.querySelector('header.top .topActions');
   before=host?.querySelector('#excelBtn')||null;
 }
 if(!host){host=document.createElement('div');host.id='ammoGlobalActions';host.style.cssText='position:fixed;right:24px;top:92px;z-index:999999;display:flex;align-items:center;gap:10px;';document.body.appendChild(host)}
 host.style.flexWrap='nowrap';host.style.alignItems='center';host.style.gap='10px';
 host.insertBefore(b,before);
 const compact=()=>{const small=innerWidth<900;b.style.padding=small?'0 10px':'0 14px';b.style.fontSize=small?'12px':'13px';if(tax){tax.style.padding=small?'0 10px':'0 14px';tax.style.fontSize=small?'12px':'13px'}};compact();addEventListener('resize',compact)
}
document.addEventListener('DOMContentLoaded',async()=>{ui();await apply()});window.addEventListener('ammo-cloud-updated',apply);
})();
