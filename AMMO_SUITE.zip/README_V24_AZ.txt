AMMO SUITE V24 — TaskPanel köklü fayl düzəlişi

1. İşçi tapşırıq göndərdikdə task sənədini fayllarla yeniləməsinə icazə verildi.
2. Fayl siyahısı ayrıca taskFileManifests kolleksiyasında da saxlanılır.
3. Tapşırıq pəncərəsi faylları əvvəl lokal nüsxədən, sonra task sənədindən, sonra manifestdən oxuyur.
4. PDF, Word, Excel, JPG, PNG və səs faylları həm göndərən, həm alan tərəfindən açılır/yüklənir.

MÜTLƏQ:
modules/taskpanel/firestore.rules faylının BÜTÜN məzmununu Firebase Console > Firestore Database > Rules bölməsinə yapışdırın və Publish edin.
Köhnə qaydanın sonuna əlavə etməyin; bütün köhnə mətni silib bu faylı tam yapışdırın.
