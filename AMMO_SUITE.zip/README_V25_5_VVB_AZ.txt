AMMO SUITE V25.5 — VVB İXRACI

Əməkhaqqı moduluna əlavə edildi:
1. Ümumi bölmənin yükləmə hissəsində “VVB nümunə” kartı.
   - İstifadəçi öz .xlsx VVB nümunəsini yükləyə bilər.
   - Fayl yüklənməzsə paketdəki standart nümunə istifadə olunur.
2. Hesablama cədvəli bölməsində, “Yenilə” və “Yadda saxla” arasında “VVB yüklə” düyməsi.
3. Cari rübün 3 ayı avtomatik toplanır:
   - 1-ci ay: rübün ilk ayı
   - 2-ci ay: rübün ikinci ayı
   - 3-cü ay: rübün üçüncü ayı
4. Sütun uyğunluğu:
   - Soyadı, adı, atasının adı -> İşçinin soyadı, adı, atasının adı
   - FİN -> FİN
   - Əsas/Əlavə -> Əsas iş yeri olması barədə qeyd
   - Faktiki iş günləri -> Faktiki iş günlərinin sayı
   - Yekun ə/h -> Hesablanmış əmək haqqı və digər gəlirlər
5. Əvvəlki aylar “Yadda saxla” ilə aylıq arxivə əlavə edilməlidir.
6. VVB faylı nümunənin formatını, stillərini və birləşdirilmiş xanalarını qoruyaraq hazırlanır.
