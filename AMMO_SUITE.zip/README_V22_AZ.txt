AMMO SUITE V22

TaskPanel düzəlişi:
- Tapşırığı göndər düyməsi basıldıqda “Göndərilir...” vəziyyəti göstərilir.
- Uğurlu göndərişdən sonra yuxarı sağ küncdə yaşıl bildiriş 7 saniyə görünür.
- E-poçt xətası olsa belə tapşırığın yaradıldığı ayrıca göstərilir.
- Xəta bildirişləri qırmızı, e-poçt xəbərdarlıqları narıncı göstərilir.
