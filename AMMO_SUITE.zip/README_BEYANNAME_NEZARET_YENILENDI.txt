AMMO SUITE 2.20

Bu paketdə köhnə Bəyannamə Nəzarət modulu silindi və yeni AMMO_BEYANNAME_NEZARET_FIXED modulu əlavə edildi.

Açılış yolu:
AMMO SUITE -> BƏYANNAMƏ NƏZARƏT

Qeyd:
- Cari Hesabatda yazılan məlumatlar saxlanır.
- Ümumi Hesabat seçilən il üzrə Cari Hesabatdan məlumatları çəkir.
- Şirkət Hesabatı seçilən il və təşkilata uyğun Cari Hesabat məlumatlarını göstərir.
- Firebase REST bağlantısı app.js daxilində hazır config ilə aktivdir.
