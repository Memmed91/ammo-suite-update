/* AMMO SUITE V29 — yenilənmə zolağı, versiya göstəricisi və admin "Cihazlar" paneli.
   suite.js-dən sonra yüklənir (FB, currentAuth, isAdmin, $ qlobaldır). */
(() => {
  'use strict';
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const RUNNING = chrome.runtime.getManifest().version;
  const banner = document.getElementById('updateBanner');
  const verEl = document.getElementById('appVersion');
  if (verEl) verEl.textContent = `Versiya ${RUNNING}`;

  const ERRORS = {
    native: 'AMMO Updater bu kompüterdə quraşdırılmayıb. AMMO qovluğundakı AMMO-Updater.exe faylını bir dəfə açın, sonra yenidən cəhd edin.',
    not_updateable: 'Bu hesab üçün yeniləmə icazəsi bağlıdır. Admin ilə əlaqə saxlayın.',
    permission_check_failed: 'İcazə yoxlanılmadı — internet bağlantısını yoxlayın.',
    timeout: 'Yeniləmə çox uzun çəkdi. Bir az sonra yenidən cəhd edin.',
    update_url_not_configured: 'Yeniləmə serveri hələ təyin edilməyib (update-config.json).'
  };
  function explain(err) {
    const e = String(err || '');
    if (/native messaging host not found|not found|forbidden|native_host/i.test(e)) return ERRORS.native;
    return ERRORS[e] || ('Xəta: ' + e);
  }

  function notesHtml(notes) {
    if (!notes || !notes.length) return '';
    return `<ul>${notes.slice(0, 8).map((n) => `<li>${esc(n)}</li>`).join('')}</ul>`;
  }

  async function renderBanner() {
    if (!banner) return;
    const { updateAvailable, justUpdated, ammoLatestInfo } = await chrome.storage.local.get(['updateAvailable', 'justUpdated', 'ammoLatestInfo']);
    if (updateAvailable && updateAvailable.version && updateAvailable.version !== RUNNING) { // yeni versiya həmişə önəmlidir
      banner.className = 'update-banner';
      banner.innerHTML = `<div><b>🔔 Yeni versiya: ${esc(updateAvailable.version)}</b> <small>(sizdəki: ${esc(RUNNING)})</small>${notesHtml(updateAvailable.notes)}<div id="updMsg" class="upd-msg"></div></div><button id="updNow">İndi yenilə</button>`;
      document.getElementById('updNow').onclick = runUpdate;
      return;
    }
    if (justUpdated && justUpdated.to === RUNNING) {
      const notes = ammoLatestInfo && ammoLatestInfo.version === RUNNING ? ammoLatestInfo.notes : [];
      banner.className = 'update-banner done';
      banner.innerHTML = `<div><b>✅ AMMO SUITE ${esc(RUNNING)} versiyasına yeniləndi</b>${notesHtml(notes)}</div><button id="updDismiss">Bağla</button>`;
      document.getElementById('updDismiss').onclick = async () => { await chrome.storage.local.remove('justUpdated'); renderBanner(); };
      return;
    }
    banner.className = 'update-banner hidden';
    banner.innerHTML = '';
  }

  async function runUpdate() {
    const btn = document.getElementById('updNow');
    const msg = document.getElementById('updMsg');
    if (btn) { btn.disabled = true; btn.textContent = 'Yenilənir...'; }
    if (msg) msg.textContent = 'Yeni versiya yüklənir, bir neçə saniyə gözləyin. Səhifə avtomatik yenidən açılacaq.';
    const email = (typeof currentAuth !== 'undefined' && currentAuth?.email) || (await chrome.storage.local.get('ammoLastEmail')).ammoLastEmail || '';
    const res = await chrome.runtime.sendMessage({ type: 'AMMO_RUN_UPDATE', email }).catch((e) => ({ success: false, error: e.message }));
    if (res?.success && res.updated) { if (msg) msg.textContent = 'Yeniləndi! AMMO SUITE yenidən açılır...'; return; }
    if (btn) { btn.disabled = false; btn.textContent = 'İndi yenilə'; }
    if (res?.success && !res.updated) { if (msg) msg.textContent = 'Serverdə daha yeni versiya tapılmadı.'; return; }
    if (msg) msg.textContent = '⚠ ' + explain(res?.error);
  }

  const checkBtn = document.getElementById('checkUpdateBtn');
  if (checkBtn) checkBtn.onclick = async () => {
    checkBtn.disabled = true; checkBtn.textContent = 'Yoxlanılır...';
    const r = await chrome.runtime.sendMessage({ type: 'AMMO_CHECK_UPDATE' }).catch((e) => ({ ok: false, error: e.message }));
    checkBtn.disabled = false;
    if (!r?.ok) checkBtn.textContent = '⚠ ' + (r?.error === 'update_url_not_configured' ? 'Server təyin edilməyib' : 'Yoxlanılmadı');
    else checkBtn.textContent = r.updateAvailable ? `Yeni: ${r.latest}` : '✓ Ən son versiyadır';
    setTimeout(() => { checkBtn.textContent = '⟳ Yeniləməni yoxla'; }, 4000);
    renderBanner();
  };

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && (ch.updateAvailable || ch.justUpdated)) renderBanner();
  });
  renderBanner();

  /* ---------------- Admin: Cihazlar və yeniləmə icazəsi ---------------- */
  const devBtn = document.getElementById('devicesBtn');
  const adminBtn = document.getElementById('adminBtn');
  const overlay = document.getElementById('devicesOverlay');
  if (devBtn && adminBtn) {
    const sync = () => devBtn.classList.toggle('hidden', adminBtn.classList.contains('hidden'));
    new MutationObserver(sync).observe(adminBtn, { attributes: true, attributeFilter: ['class'] });
    sync();
  }
  const BASE = () => `https://firestore.googleapis.com/v1/projects/${FB.projectId}/databases/(default)/documents`;
  const H = () => ({ Authorization: `Bearer ${currentAuth.idToken}`, 'Content-Type': 'application/json' });
  const fv = (f) => (!f ? '' : f.stringValue ?? f.timestampValue ?? (f.booleanValue !== undefined ? f.booleanValue : '') ?? '');
  const fmt = (t) => { if (!t) return '—'; const d = new Date(t); return isNaN(d) ? '—' : d.toLocaleString('az-AZ', { timeZone: 'Asia/Baku', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); };

  async function listCol(name) {
    const out = []; let token = '';
    do {
      const r = await fetch(`${BASE()}/${name}?pageSize=300${token ? '&pageToken=' + encodeURIComponent(token) : ''}`, { headers: H() });
      if (!r.ok) throw new Error(`${name}: HTTP ${r.status} — Firestore qaydalarını (rules) yeniləyin`);
      const d = await r.json(); (d.documents || []).forEach((x) => out.push(x)); token = d.nextPageToken || '';
    } while (token);
    return out;
  }

  async function renderDevices() {
    const root = document.getElementById('devicesList');
    const msg = document.getElementById('devicesMsg');
    root.innerHTML = '<div class="dev-empty">Yüklənir...</div>'; msg.textContent = '';
    try {
      if (typeof ammoRefreshAuth === 'function') currentAuth = await ammoRefreshAuth(currentAuth, FB.apiKey);
      const [devs, access] = await Promise.all([listCol('devices'), listCol('updateAccess').catch(() => [])]);
      const acc = {}; access.forEach((d) => { acc[d.name.split('/').pop()] = d.fields?.updateable?.booleanValue !== false; });
      const rows = devs.map((d) => ({ uid: d.name.split('/').pop(), email: fv(d.fields?.email), deviceId: fv(d.fields?.deviceId), label: fv(d.fields?.deviceLabel), ver: fv(d.fields?.appVersion), seen: fv(d.fields?.lastSeenAt), bound: fv(d.fields?.boundAt) }))
        .sort((a, b) => String(a.email).localeCompare(String(b.email)));
      if (!rows.length) { root.innerHTML = '<div class="dev-empty">Hələ heç bir cihaz qeydə alınmayıb. İstifadəçilər V29-a ilk dəfə daxil olanda burada görünəcək.</div>'; return; }
      root.innerHTML = `<table class="dev-table"><thead><tr><th>İstifadəçi</th><th>Cihaz</th><th>Versiya</th><th>Son görülmə</th><th>Yeniləmə</th><th></th></tr></thead><tbody>${rows.map((r) => {
        const upd = acc[r.email] !== false; const old = r.ver && r.ver !== RUNNING;
        return `<tr><td><b>${esc(r.email || r.uid)}</b></td>
          <td>${r.deviceId ? `${esc(r.label || 'Cihaz')}<small>ID: ${esc(r.deviceId.slice(0, 8))}… · bağlanıb ${esc(fmt(r.bound))}</small>` : '<span class="dev-free">Boşdur — növbəti girişdə bağlanacaq</span>'}</td>
          <td><span class="${old ? 'dev-old' : 'dev-ok'}">${esc(r.ver || '—')}</span></td>
          <td>${esc(fmt(r.seen))}</td>
          <td><label class="switch" title="Yeniləmə icazəsi"><input type="checkbox" data-upd="${esc(r.email)}" ${upd ? 'checked' : ''}><span></span></label></td>
          <td>${r.deviceId ? `<button class="dev-reset" data-reset="${esc(r.uid)}" data-email="${esc(r.email)}">Cihazı sıfırla</button>` : ''}</td></tr>`;
      }).join('')}</tbody></table>`;
      root.querySelectorAll('[data-reset]').forEach((b) => b.onclick = async () => {
        if (!confirm(`${b.dataset.email} hesabının cihaz bağlantısı silinsin? Növbəti dəfə hansı kompüterdə daxil olsa, ona bağlanacaq.`)) return;
        const r = await fetch(`${BASE()}/devices/${encodeURIComponent(b.dataset.reset)}?updateMask.fieldPaths=deviceId`, { method: 'PATCH', headers: H(), body: JSON.stringify({ fields: { deviceId: { stringValue: '' } } }) });
        msg.textContent = r.ok ? `✓ ${b.dataset.email} — cihaz sıfırlandı.` : `Xəta: HTTP ${r.status}`;
        renderDevices();
      });
      root.querySelectorAll('[data-upd]').forEach((x) => x.onchange = async () => {
        const email = x.dataset.upd;
        const r = await fetch(`${BASE()}/updateAccess/${encodeURIComponent(email)}`, { method: 'PATCH', headers: H(), body: JSON.stringify({ fields: { updateable: { booleanValue: x.checked }, changedAt: { timestampValue: new Date().toISOString() } } }) });
        msg.textContent = r.ok ? `✓ ${email}: yeniləmə ${x.checked ? 'açıldı' : 'bağlandı'}.` : `Xəta: HTTP ${r.status}`;
        if (!r.ok) x.checked = !x.checked;
      });
    } catch (e) {
      root.innerHTML = `<div class="dev-empty">⚠ ${esc(e.message)}</div>`;
    }
  }

  if (devBtn && overlay) {
    devBtn.onclick = () => { overlay.classList.remove('hidden'); renderDevices(); };
    document.getElementById('devicesClose').onclick = () => overlay.classList.add('hidden');
    document.getElementById('devicesRefresh').onclick = renderDevices;
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.add('hidden'); });
  }
})();
