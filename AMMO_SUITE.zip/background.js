const SUITE_URL = chrome.runtime.getURL('suite.html');

chrome.runtime.onInstalled.addListener(() => console.log('AMMO SUITE V28 quraşdırıldı'));

chrome.action.onClicked.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: SUITE_URL + '*' });
  if (tabs.length && tabs[0].id) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    if (tabs[0].windowId) await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: SUITE_URL });
  }
});


// TaskPanel e-poçt göndərişi — əsas AMMO SUITE service worker daxilində işləyir.
const TASK_EMAIL_WEB_APP_URL='https://script.google.com/macros/s/AKfycbzNfq2z5uxaU1CLxjGG1gVS1K1FaiRA5dFKvmUkzDNGRz1f2qsHOVdFu3-sy4zygkZN/exec';
chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(message?.type!=='SEND_TASK_EMAIL')return;
  (async()=>{
    try{
      const response=await fetch(TASK_EMAIL_WEB_APP_URL,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(message.payload||{}),redirect:'follow'});
      const text=await response.text();let result;try{result=JSON.parse(text)}catch{result={success:response.ok,raw:text}}
      if(!response.ok||result.success===false)throw new Error(result.error||`E-poçt xidməti HTTP ${response.status}`);
      sendResponse({success:true,result});
    }catch(error){sendResponse({success:false,error:error?.message||String(error)})}
  })();
  return true;
});

// Hesabat Vaxtı modulunun alarm, Gmail və bildiriş xidmətləri.
importScripts('modules/hesabat-vaxti/background.js');


/* === Borc Xatırladıcı avtomatik aylıq reminder inteqrasiyası === */
const ALARM_NAME = 'debt-reminder-check';

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: 60 });
  await runReminderCheck();
});

chrome.runtime.onStartup.addListener(async () => {
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: 60 });
  await runReminderCheck();
});


chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) runReminderCheck();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'RUN_REMINDER_CHECK') {
    runReminderCheck().then(() => sendResponse({ ok: true }));
    return true;
  }
});

function dayStart(value = new Date()) {
  const d = new Date(value);
  d.setHours(0, 0, 0, 0);
  return d;
}

function daysBetween(from, to) {
  return Math.round((dayStart(to) - dayStart(from)) / 86400000);
}

async function runReminderCheck() {
  const { records = [], borcSettings, settings: legacySettings = {}, notified = {} } = await chrome.storage.local.get(['records', 'borcSettings', 'settings', 'notified']);
  const settings = borcSettings || (('reminderDays' in legacySettings) ? legacySettings : {});
  const today = dayStart();
  const reminderDays = Number.isFinite(Number(settings.reminderDays)) ? Number(settings.reminderDays) : 5;
  const newNotified = { ...notified };

  for (const item of records) {
    const installments = Array.isArray(item.installments) && (item.installments.length || item.paymentMode === 'monthly')
      ? item.installments
      : [{ id: `${item.id}-legacy`, dueDate: item.dueDate, amount: item.amount, status: item.status, paidAt: item.paidAt }];

    // V28.2: aylıq qeyddə növbəti (hələ yazılmamış) ay üçün əvvəlcədən xatırlatma
    const list = installments.slice();
    if (item.paymentMode !== 'one_time' && item.startDate) {
      const addM = (ds, k) => { const d = new Date(ds + 'T00:00:00'); const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + k); const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); d.setDate(Math.min(day, last)); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
      const have = new Set(installments.map(i => i.periodStart));
      let k = 0; while (k < 600 && have.has(addM(item.startDate, k))) k++;
      const ps = addM(item.startDate, k);
      list.push({ id: 'next-' + ps, periodStart: ps, dueDate: addM(item.startDate, k + 1), amount: item.monthlyAmount || item.baseAmount || 0, status: 'pending' });
    }
    for (const installment of list) {
      if (installment.status === 'paid' || !installment.dueDate) continue;
      const due = dayStart(installment.dueDate + 'T00:00:00');
      const daysLeft = daysBetween(today, due);
      const overdueDays = daysLeft < 0 ? Math.abs(daysLeft) : 0;
      const notifyKey = `${item.id}:${installment.id}:${installment.dueDate}:${daysLeft}`;
      if (daysLeft > reminderDays || newNotified[notifyKey]) continue;

      const typeText = item.type === 'receivable' ? 'Alacağınız' : 'Verəcəyiniz';
      const amountText = new Intl.NumberFormat('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(installment.amount || 0));
      const AZM=['Yanvar','Fevral','Mart','Aprel','May','İyun','İyul','Avqust','Sentyabr','Oktyabr','Noyabr','Dekabr'];
      const per = item.paymentMode === 'one_time' ? null : new Date((installment.periodStart || installment.dueDate) + 'T00:00:00');
      const monthText = per ? `${AZM[per.getMonth()]} ${per.getFullYear()}` : '1 dəfəlik ödəniş';
      let message;
      if (overdueDays > 0) message = `${item.person} — ${monthText}: ${amountText} ${item.currency || 'AZN'}. ${overdueDays} gündür gecikib.`;
      else if (daysLeft === 0) message = `${item.person} — ${monthText}: ${amountText} ${item.currency || 'AZN'}. Son tarix bu gündür.`;
      else message = `${item.person} — ${monthText}: ${amountText} ${item.currency || 'AZN'}. Son tarixə ${daysLeft} gün qalıb.`;

      await chrome.notifications.create(`debt-${item.id}-${installment.id}-${Date.now()}`, {
        type: 'basic', iconUrl: 'modules/borc-xatirlatici/icons/icon128.png', title: `${typeText} üzrə ${item.paymentMode === 'one_time' ? '1 dəfəlik' : 'aylıq'} xatırlatma`, message, priority: overdueDays > 0 ? 2 : 1
      });
      newNotified[notifyKey] = Date.now();
    }
  }

  const cutoff = Date.now() - 45 * 86400000;
  for (const [key, timestamp] of Object.entries(newNotified)) {
    if (timestamp < cutoff) delete newNotified[key];
  }
  await chrome.storage.local.set({ notified: newNotified });
}



/* =====================================================================
   V29 — AVTOMATİK YENİLƏNMƏ (TaxPro modeli)
   - update-config.json → serverdəki update.json ünvanı
   - Hər N dəqiqədən bir yeni versiyanı yoxlayır, bildiriş göstərir
   - "İndi yenilə" → AMMO-Updater.exe (Native Messaging) faylları əvəz edir
   - Diskdəki versiya işləyən versiyadan böyükdürsə uzantı özünü yenidən yükləyir
   ===================================================================== */
const AMMO_UPD_ALARM = 'ammo-update-check';
const AMMO_DISK_ALARM = 'ammo-disk-check';
let ammoUpdCfgCache = null;

async function ammoUpdConfig() {
  if (ammoUpdCfgCache) return ammoUpdCfgCache;
  try {
    const r = await fetch(chrome.runtime.getURL('update-config.json'), { cache: 'no-store' });
    ammoUpdCfgCache = await r.json();
  } catch (e) { ammoUpdCfgCache = {}; }
  ammoUpdCfgCache.nativeHost = ammoUpdCfgCache.nativeHost || 'az.ammo.updater';
  ammoUpdCfgCache.checkEveryMinutes = Number(ammoUpdCfgCache.checkEveryMinutes) || 180;
  return ammoUpdCfgCache;
}

function ammoVersionGreater(a, b) {
  const x = String(a || '0').split('.').map(Number), y = String(b || '0').split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] || 0) > (y[i] || 0)) return true;
    if ((x[i] || 0) < (y[i] || 0)) return false;
  }
  return false;
}

async function ammoCheckRemoteVersion() {
  const cfg = await ammoUpdConfig();
  const running = chrome.runtime.getManifest().version;
  if (!cfg.updateInfoUrl || /SIZIN-GITHUB-ADINIZ/.test(cfg.updateInfoUrl)) return { ok: false, error: 'update_url_not_configured', running };
  try {
    const r = await fetch(cfg.updateInfoUrl + (cfg.updateInfoUrl.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const info = await r.json();
    if (info.version) await chrome.storage.local.set({ ammoLatestInfo: { version: info.version, notes: Array.isArray(info.notes) ? info.notes : [], date: info.date || '' } });
    if (info.version && ammoVersionGreater(info.version, running)) {
      const updateAvailable = { version: info.version, notes: Array.isArray(info.notes) ? info.notes : [], date: info.date || '', checkedAt: Date.now() };
      const { ammoUpdateNotified } = await chrome.storage.local.get('ammoUpdateNotified');
      await chrome.storage.local.set({ updateAvailable });
      if (ammoUpdateNotified !== info.version) {
        chrome.notifications.create('ammo-update-' + info.version, {
          type: 'basic', iconUrl: 'assets/icon128.png', priority: 2,
          title: `AMMO SUITE — yeni versiya ${info.version}`,
          message: 'Yeni versiya hazırdır. AMMO SUITE-də "İndi yenilə" düyməsini basın.'
        });
        await chrome.storage.local.set({ ammoUpdateNotified: info.version });
      }
      return { ok: true, running, latest: info.version, updateAvailable };
    }
    await chrome.storage.local.set({ updateAvailable: null });
    return { ok: true, running, latest: info.version || running, updateAvailable: null };
  } catch (e) {
    return { ok: false, error: e.message, running };
  }
}

// Updater faylları Chrome açıq ikən əvəz edibsə — diskdəki versiya daha yenidir → özünü yenidən yüklə
async function ammoReloadIfDiskNewer(delayMs = 0) {
  try {
    const running = chrome.runtime.getManifest().version;
    const r = await fetch(chrome.runtime.getURL('manifest.json') + '?t=' + Date.now(), { cache: 'no-store' });
    const onDisk = (await r.json()).version;
    if (onDisk && ammoVersionGreater(onDisk, running)) {
      await chrome.storage.local.set({ justUpdated: { from: running, to: onDisk, at: Date.now() }, updateAvailable: null, ammoReopenSuite: true });
      if (delayMs) setTimeout(() => chrome.runtime.reload(), delayMs); else chrome.runtime.reload();
      return true;
    }
  } catch (e) { console.error('ammoReloadIfDiskNewer:', e); }
  return false;
}

function ammoRunNativeUpdate(email) {
  return new Promise(async (resolve) => {
    const cfg = await ammoUpdConfig();
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    const timer = setTimeout(() => finish({ success: false, error: 'timeout' }), 120000);
    try {
      chrome.runtime.sendNativeMessage(cfg.nativeHost, { action: 'check_and_update', email: email || '' }, (resp) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) finish({ success: false, error: chrome.runtime.lastError.message || 'native_host_unreachable' });
        else finish(resp || { success: false, error: 'empty_response' });
      });
    } catch (e) { clearTimeout(timer); finish({ success: false, error: e.message }); }
  });
}

async function ammoSetupUpdateAlarms() {
  const cfg = await ammoUpdConfig();
  await chrome.alarms.create(AMMO_UPD_ALARM, { periodInMinutes: cfg.checkEveryMinutes, delayInMinutes: 1 });
  await chrome.alarms.create(AMMO_DISK_ALARM, { periodInMinutes: 15 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === AMMO_UPD_ALARM) ammoCheckRemoteVersion();
  if (alarm.name === AMMO_DISK_ALARM) ammoReloadIfDiskNewer();
});

async function ammoAfterStart(details) {
  await ammoSetupUpdateAlarms();
  const running = chrome.runtime.getManifest().version;
  const { lastRunVersion, ammoReopenSuite } = await chrome.storage.local.get(['lastRunVersion', 'ammoReopenSuite']);
  if (lastRunVersion && ammoVersionGreater(running, lastRunVersion)) {
    const { justUpdated } = await chrome.storage.local.get('justUpdated');
    if (!justUpdated || justUpdated.to !== running) await chrome.storage.local.set({ justUpdated: { from: lastRunVersion, to: running, at: Date.now() } });
    await chrome.storage.local.set({ updateAvailable: null });
  }
  await chrome.storage.local.set({ lastRunVersion: running });
  if (ammoReopenSuite) {
    await chrome.storage.local.remove('ammoReopenSuite');
    const tabs = await chrome.tabs.query({ url: SUITE_URL + '*' });
    if (!tabs.length) chrome.tabs.create({ url: SUITE_URL });
  }
  if (!(await ammoReloadIfDiskNewer())) ammoCheckRemoteVersion();
}
chrome.runtime.onInstalled.addListener((d) => { ammoAfterStart(d); });
chrome.runtime.onStartup.addListener(() => { ammoAfterStart(); });

chrome.notifications.onClicked.addListener(async (id) => {
  if (!id.startsWith('ammo-update-')) return;
  const tabs = await chrome.tabs.query({ url: SUITE_URL + '*' });
  if (tabs.length && tabs[0].id) chrome.tabs.update(tabs[0].id, { active: true }); else chrome.tabs.create({ url: SUITE_URL });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'AMMO_CHECK_UPDATE') {
    ammoCheckRemoteVersion().then(sendResponse);
    return true;
  }
  if (message?.type === 'AMMO_RUN_UPDATE') {
    (async () => {
      const res = await ammoRunNativeUpdate(message.email);
      if (res.success && res.updated) {
        const running = chrome.runtime.getManifest().version;
        await chrome.storage.local.set({ justUpdated: { from: running, to: res.version, at: Date.now() }, updateAvailable: null, ammoReopenSuite: true });
        sendResponse(res);
        setTimeout(() => chrome.runtime.reload(), 400);
        return;
      }
      if (res.success && !res.updated) {
        // Updater faylları əvvəlcədən yeniləyibsə (məs. Windows açılışında) — sadəcə yenidən yüklə
        if (await ammoReloadIfDiskNewer(400)) { sendResponse({ ...res, updated: true }); return; }
      }
      sendResponse(res);
    })();
    return true;
  }
});
