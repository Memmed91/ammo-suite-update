AMMO SUITE V16

1. Sahibkarlar Excel idxalı “SAHİBKARLAR” və “VÖEN” başlıqlarını avtomatik tanıyır.
2. Eyni VÖEN təkrar yüklənəndə yeni dublikat yaratmır, mövcud adı yeniləyir.
3. Vergi sənədi əlavə et düyməsi PDF və DOCX fayllarını oxuyur.
4. PDF nümunəsindəki 3-21-2-3/2-Ə-144206-43/2026 kimi nömrələr tam şəkildə NÖMRƏ sahəsinə yazılır.
5. Sənəddən VÖEN və vergi ödəyicisinin adı da mümkün olduqda avtomatik doldurulur.
6. Word sənədinin özündə məktub nömrəsi yoxdursa proqram bunu düzgün bildirir; olmayan nömrəni VÖEN-dən uydurmur.
