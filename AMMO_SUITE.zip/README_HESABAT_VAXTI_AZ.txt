AMMO SUITE V25.4 + HESABAT VAXTI

Hesabat Vaxtı AMMO SUITE daxilində ayrıca modul kimi əlavə edilib.
AMMO SUITE-ni açdıqda sol menyuda “Hesabat Vaxtı” görünür.

Gmail OAuth üçün vacib:
Google Cloud-da Chrome Extension OAuth client-in Item ID sahəsi artıq AMMO SUITE-nin chrome://extensions səhifəsində görünən ID-si ilə eyni olmalıdır. Köhnə Hesabat Vaxtı ID-si artıq istifadə edilmir.
OAuth client ID manifestdə saxlanılıb.
