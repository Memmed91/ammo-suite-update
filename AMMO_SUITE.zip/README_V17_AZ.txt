AMMO SUITE V17
- Sahibkarlar və vergi sənədi düymələri səliqəli yan-yana yerləşdirildi.
- Düymələrin başlıq və digər sözlərin üzərinə düşməsi aradan qaldırıldı.
- Bəyannamə nəzarətdə tarix xanaları hər vergi sətrinin yanına keçirildi.
- Yuxarı hissədə yalnız Təşkilat və VÖEN saxlanıldı.
