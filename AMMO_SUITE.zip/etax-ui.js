/* AMMO SUITE V30.2 — panellər üçün e-taxes köməkçisi (Vergi məktubları, Bəyannamə nəzarət).
   window.AmmoEtax.snapshot({letters,declarations}) → açıq kabinetdən məlumat
   window.AmmoEtax.bar(...)                        → panelin yuxarısında "🔔 Yenilənmə" zolağı */
(() => {
  'use strict';
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function snapshot(opts) {
    return new Promise((resolve) => {
      try { chrome.runtime.sendMessage({ type: 'AMMO_ETAX_SNAPSHOT', opts }, (r) => resolve(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : (r || { ok: false, error: 'empty' }))); }
      catch (e) { resolve({ ok: false, error: String(e.message || e) }); }
    });
  }
  function errorText(r) {
    const e = r?.error || '';
    if (e === 'no_tab') return 'e-taxes şəxsi kabineti açıq deyil. new.e-taxes.gov.az-da şirkətin kabinetinə daxil olun, sonra “Yenilə” basın.';
    if (e === 'no_token') return 'e-taxes səhifəsi açıqdır, amma kabinetə giriş edilməyib (ASAN İmza ilə daxil olun).';
    if (e === 'script_failed') return 'e-taxes səhifəsi oxunmadı. Səhifəni bir dəfə yeniləyin (F5) və yenidən cəhd edin.';
    return 'e-taxes kabineti oxunmadı: ' + e;
  }

  // ---------- Zolaq ----------
  const CSS = `.ammo-etax-bar{display:flex;align-items:center;gap:12px;margin:0 0 14px;padding:11px 14px;border-radius:12px;font:600 13.5px/1.35 system-ui,"Segoe UI",Arial;border:1px solid #b2ddff;background:#eff8ff;color:#175cd3}
  .ammo-etax-bar.hidden{display:none}
  .ammo-etax-bar.new{background:linear-gradient(90deg,#fff7e6,#fffaeb);border-color:#fdb022;color:#93370d;cursor:pointer;animation:ammoPulse 1.6s ease-in-out 3}
  .ammo-etax-bar.new:hover{border-color:#f79009;box-shadow:0 4px 14px #f7900933}
  .ammo-etax-bar.ok{background:#ecfdf3;border-color:#abefc6;color:#067647}
  .ammo-etax-bar.warn{background:#fef3f2;border-color:#fecdca;color:#b42318}
  .ammo-etax-bar .ic{font-size:18px}.ammo-etax-bar .tx{flex:1}.ammo-etax-bar small{display:block;font-weight:500;opacity:.85;margin-top:2px}
  .ammo-etax-bar .go{border:0;border-radius:9px;padding:8px 14px;font-weight:800;background:#f79009;color:#fff;cursor:pointer;white-space:nowrap}
  .ammo-etax-bar .x{border:0;background:transparent;color:inherit;font-size:16px;cursor:pointer;opacity:.6}
  .ammo-etax-top{display:inline-flex;align-items:center;gap:6px;border:0;border-radius:999px;padding:6px 12px;background:#f79009;color:#fff;font:800 12.5px system-ui;cursor:pointer;animation:ammoPulse 1.6s ease-in-out infinite}
  .ammo-etax-top.hidden{display:none}
  @keyframes ammoPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.025)}}
  .ammo-etax-modal{position:fixed;inset:0;background:#0b1b3d73;display:grid;place-items:center;z-index:99999;padding:16px}
  .ammo-etax-modal .card{background:#fff;border-radius:16px;width:min(760px,100%);max-height:88vh;display:flex;flex-direction:column;box-shadow:0 24px 60px #0b1b3d55;font:14px system-ui,"Segoe UI",Arial;color:#0b1b3d}
  .ammo-etax-modal .hd{padding:16px 18px 8px;border-bottom:1px solid #e2e8f2}.ammo-etax-modal .hd h3{margin:0;font-size:17px}.ammo-etax-modal .hd p{margin:4px 0 0;color:#667085;font-size:12.5px}
  .ammo-etax-modal .bd{padding:10px 18px;overflow:auto}.ammo-etax-modal .ft{padding:12px 18px;border-top:1px solid #e2e8f2;display:flex;gap:8px;justify-content:flex-end}
  .ammo-etax-modal table{width:100%;border-collapse:collapse;font-size:13px}.ammo-etax-modal th,.ammo-etax-modal td{text-align:left;padding:7px 8px;border-bottom:1px solid #eef2f7}
  .ammo-etax-modal th{background:#f6f8fc;font-size:11.5px;text-transform:uppercase;color:#475467}
  .ammo-etax-modal select{font:inherit;font-size:12.5px;padding:5px 7px;border:1px solid #cfdcf0;border-radius:8px;max-width:260px}
  .ammo-etax-modal button{font:inherit;font-weight:700;border-radius:10px;padding:8px 14px;cursor:pointer;border:1px solid #d6e2f5;background:#f5f9ff;color:#0b3d91}
  .ammo-etax-modal button.pri{background:#0b6be8;color:#fff;border-color:#0b6be8}`;
  function ensureCss() { if (document.getElementById('ammoEtaxCss')) return; const s = document.createElement('style'); s.id = 'ammoEtaxCss'; s.textContent = CSS; document.head.appendChild(s); }

  function bar(container, before) {
    ensureCss();
    const el = document.createElement('div'); el.className = 'ammo-etax-bar hidden';
    container.insertBefore(el, before || container.firstChild);
    let clickFn = null;
    el.addEventListener('click', (e) => { if (e.target.closest('.x')) { el.classList.add('hidden'); return; } if (el.classList.contains('new') && clickFn) clickFn(); });
    return {
      el,
      show(kind, title, sub, onClick, btnText) {
        clickFn = onClick || null;
        el.className = 'ammo-etax-bar ' + kind;
        const ic = kind === 'new' ? '🔔' : kind === 'ok' ? '✓' : kind === 'warn' ? '⚠' : 'ℹ';
        el.innerHTML = `<span class="ic">${ic}</span><div class="tx">${esc(title)}${sub ? `<small>${esc(sub)}</small>` : ''}</div>${kind === 'new' ? `<button class="go">${esc(btnText || 'Yenilənmə')}</button>` : ''}<button class="x" title="Gizlət">✕</button>`;
      },
      hide() { el.className = 'ammo-etax-bar hidden'; clickFn = null; }
    };
  }
  function topChip(host, before) {
    ensureCss();
    const b = document.createElement('button'); b.type = 'button'; b.className = 'ammo-etax-top hidden'; b.textContent = '🔔 Yenilənmə';
    host.insertBefore(b, before || null);
    return b;
  }
  function modal(title, sub, bodyHtml, buttons) {
    ensureCss();
    const m = document.createElement('div'); m.className = 'ammo-etax-modal';
    m.innerHTML = `<div class="card"><div class="hd"><h3>${esc(title)}</h3>${sub ? `<p>${esc(sub)}</p>` : ''}</div><div class="bd">${bodyHtml}</div><div class="ft"></div></div>`;
    const ft = m.querySelector('.ft');
    (buttons || [{ text: 'Bağla' }]).forEach((b) => { const x = document.createElement('button'); x.textContent = b.text; if (b.primary) x.className = 'pri'; x.onclick = async () => { if (b.onClick && (await b.onClick(m)) === false) return; m.remove(); }; ft.appendChild(x); });
    m.addEventListener('click', (e) => { if (e.target === m) m.remove(); });
    document.body.appendChild(m);
    return m;
  }

  // ---------- Məktubların ümumi oxunuşu (API cavabının forması əvvəlcədən bilinmir) ----------
  function flat(o, pre = '', out = {}, depth = 0) {
    if (!o || typeof o !== 'object' || depth > 2) return out;
    for (const [k, v] of Object.entries(o)) {
      const key = pre ? pre + '.' + k : k;
      if (v && typeof v === 'object' && !Array.isArray(v)) flat(v, key, out, depth + 1); else if (v !== null && v !== undefined && typeof v !== 'object') out[key] = v;
    }
    return out;
  }
  function isoDate(v) {
    if (v === null || v === undefined || v === '') return '';
    if (typeof v === 'number') { const d = new Date(v > 1e12 ? v : v * 1000); return isNaN(d) ? '' : d.toISOString().slice(0, 10); }
    const s = String(v).trim();
    let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return `${m[1]}-${m[2]}-${m[3]}`;
    m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})/); if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
    return '';
  }
  // Açar adları prioritet sırası ilə yoxlanılır (API cavabında açarların sırası təsadüfi ola bilər);
  // üst səviyyəli açarlar iç-içə olanlardan (sender.name) üstündür.
  function pick(f, names, rx, test) {
    const entries = Object.entries(f).sort((a, b) => a[0].split('.').length - b[0].split('.').length);
    for (const n of names) for (const [k, v] of entries) if (k.split('.').pop().toLowerCase() === n.toLowerCase() && (!test || test(v))) return { k, v };
    if (rx) for (const [k, v] of entries) if (rx.test(k) && (!test || test(v))) return { k, v };
    return null;
  }
  const LETTER_TYPES = [[/xəbərdar|xeberdar|warning/i, 'XƏBƏRDARLIQ'], [/ədv|edv|vat/i, 'ƏDV'], [/mənfəət|menfeet|profit|\bMV\b/i, 'MV'], [/sadələşdirilmiş|sadelesdirilmis|\bSV\b|simplified/i, 'SV'], [/ödəmə mənbəyi|\bÖMV\b|withholding/i, 'ÖMV'], [/əmlak|emlak|property/i, 'ƏMLAK V.'], [/torpaq|land/i, 'TORPAQ V.'], [/mədən|meden|mining/i, 'MƏDƏN V.'], [/aksiz|excise/i, 'AKSİZ V.'], [/gəlir|gelir|income/i, 'GƏLİR V.'], [/bildiriş|bildiris|notif/i, 'BİLDİRİŞ']];
  function normalizeLetters(rows) {
    const out = [];
    for (const r of rows || []) {
      const f = flat(r);
      const id = pick(f, ['id', 'uuid', 'letterId', 'messageId', 'documentId', 'notificationId'])?.v ?? '';
      const num = pick(f, ['documentNumber', 'letterNumber', 'number', 'docNumber', 'regNumber', 'registrationNumber', 'outgoingNumber', 'serialNumber', 'no', 'nomre', 'nömrə'], /number|nömrə|nomre/i, (v) => String(v).trim().length > 0)?.v ?? '';
      const date = pick(f, ['sentDate', 'sendDate', 'receivedDate', 'date', 'documentDate', 'registrationDate', 'regDate', 'createdDate', 'createdAt', 'tarix'], /date|tarix|created|sent/i, (v) => !!isoDate(v));
      const isText = (v) => typeof v === 'string' && v.trim().length > 1 && !/^\d+$/.test(v);
      const subj = pick(f, ['subject', 'title', 'theme', 'topic', 'mövzu', 'movzu', 'header', 'letterType', 'typeName', 'type', 'category', 'növ', 'name'], /^(?!sender|from)[^.]*(subject|title|theme|mövzu|type|növ)/i, isText)?.v ?? '';
      const sender = pick(f, ['senderName', 'sender', 'from', 'organization', 'department', 'qurum', 'göndərən'], /sender|göndərən|from/i, (v) => typeof v === 'string')?.v ?? '';
      if (!num && !subj && !date) continue;
      const text = `${subj} ${sender}`;
      const nov = (LETTER_TYPES.find(([rx]) => rx.test(text)) || [null, 'BİLDİRİŞ'])[1];
      out.push({ etaxId: String(id || num || (date ? isoDate(date.v) : '') + '|' + subj).slice(0, 180), nomre: String(num || ''), tarixGelen: date ? isoDate(date.v) : '', subject: String(subj || ''), sender: String(sender || ''), nov });
    }
    return out;
  }

  window.AmmoEtax = { snapshot, errorText, bar, topChip, modal, normalizeLetters, esc, isoDate };
})();
