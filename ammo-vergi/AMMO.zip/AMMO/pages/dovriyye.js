/* AMMO — Sənəd dövriyyəsi (v1.16: öz sənəd növləri, çox şirkətli sənəddə şirkət seçimi, yükləmələrin tutulması)
 * Elektron arxiv və kargüzarlıq: sənədi yükləyin → AMMO oxuyur (PDF, Word, Excel, şəkil/skan — OCR),
 * növünü, sahibini (hüquqi / fiziki şəxs), kontragenti, nömrəni, tarixi, məbləği təyin edir, sizdən
 * "Sənəd dövriyyəsinə göndərilsin?" deyə soruşur və təsdiqdən sonra uyğun qovluğa yerləşdirir.
 * Bütün məlumat yalnız bu brauzerdə (IndexedDB) saxlanılır — heç bir serverə göndərilmir. */
const A = globalThis.DD_ANALYZE, X = globalThis.AMMO_XLSX, XR = globalThis.AMMO_XLSX_READ, W = globalThis.AMMO_DOCX;
const IMG = globalThis.SENED_IMG, MSDOC = globalThis.SENED_MSDOC, INBOX = globalThis.DD_INBOX, HELPER = globalThis.DD_HELPER;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
function toast(t, ms = 3600) { const x = $('#toast'); x.textContent = t; x.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => x.classList.remove('show'), ms); }
const pad = (n) => String(n).padStart(2, '0');
const ymdOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const today = () => ymdOf(new Date());
const fmtDate = (s) => (s ? String(s).slice(0, 10).split('-').reverse().join('.') : '');
const fmtDT = (iso) => { if (!iso) return ''; const d = new Date(iso); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
function fmtMoney(n) { if (n == null || n === '' || !isFinite(n)) return ''; const [i, f] = Number(n).toFixed(2).split('.'); return i.replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ',' + f; }
const fmtSize = (b) => (b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
const MONTHS_AZ = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
const periodTxt = (p) => (p && /^\d{4}-\d{2}$/.test(p) ? `${MONTHS_AZ[+p.slice(5) - 1]} ${p.slice(0, 4)}` : '');
const DIR = { in: { name: 'Daxil olan', pfx: 'D', icon: '📥' }, out: { name: 'Çıxan', pfx: 'Ç', icon: '📤' }, internal: { name: 'Daxili', pfx: 'X', icon: '🏠' } };
const STATUSES = ['Qeydə alınıb', 'İcrada', 'İmzalanıb', 'Göndərilib', 'Arxivdə'];
const TYPE = A.TYPE, CAT = A.CAT;
const typeName = (id) => (TYPE[id] || TYPE.diger).name;
const typeIcon = (id) => (TYPE[id] || TYPE.diger).icon;
const catOf = (id) => CAT[id] || CAT.diger;
const COLORS = ['#1f4fd1', '#0f8a5f', '#c2410c', '#6d5bd0', '#b98a2f', '#0e7490', '#be185d', '#4d7c0f', '#7c2d12', '#1e40af'];

// ================================================================== IndexedDB
const DB = {
  db: null,
  open() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('ammo_dovriyye', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        for (const s of ['docs', 'files', 'texts', 'subjects', 'sends']) if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'id' });
        if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta');
      };
      r.onsuccess = () => { this.db = r.result; res(); };
      r.onerror = () => rej(r.error);
    });
  },
  req(store, mode, fn) {
    return new Promise((res, rej) => {
      const tx = this.db.transaction(store, mode); const q = fn(tx.objectStore(store));
      tx.oncomplete = () => res(q && q.result); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error || new Error('Yaddaş xətası'));
    });
  },
  get(s, k) { return this.req(s, 'readonly', (os) => os.get(k)); },
  all(s) { return this.req(s, 'readonly', (os) => os.getAll()); },
  put(s, v, k) { return this.req(s, 'readwrite', (os) => (k === undefined ? os.put(v) : os.put(v, k))); },
  del(s, k) { return this.req(s, 'readwrite', (os) => os.delete(k)); },
  clear(s) { return this.req(s, 'readwrite', (os) => os.clear()); },
};

// ================================================================== vəziyyət
const DEF_SET = { autoSend: false, autoThreshold: 0.85, ocr: true, pickSend: true, expiryDays: 30, monthly: ['tabel', 'hesablama', 'bank_cixaris', 'beyanname'], retention: {} };
const defFilter = () => ({ q: '', from: '', to: '', basis: 'date', subj: '', cat: '', type: '', dir: '', status: '', cp: '', person: '', amin: '', amax: '', tag: '', fav: false, expiry: false, period: '', preset: '' });
const st = {
  view: 'home', docs: [], subjects: [], sends: [], meta: { counters: {}, learn: [], settings: { ...DEF_SET }, custom: { cats: [], types: [] } },
  f: defFilter(), open: new Set(), sel: new Set(), mode: 'table', sort: { k: 'date', asc: false }, limit: 100, more: false,
  queue: [], qi: 0, textCache: null, drawer: null, dtab: 'info', editing: false, urls: [], mx: { subj: '', year: new Date().getFullYear() },
};
const S = () => st.meta.settings;
const live = () => st.docs.filter((d) => !d.deleted);
const subjById = (id) => st.subjects.find((s) => s.id === id);
const subjName = (id) => { const s = subjById(id); return s ? s.name : '— təyin olunmayıb —'; };
const subjIcon = (s) => (s && s.kind === 'physical' ? '👤' : '🏢');
const retentionOf = (type) => { const r = S().retention[type]; return r != null && r !== '' ? +r : (TYPE[type] || TYPE.diger).ret; };

async function saveMeta() { await DB.put('meta', st.meta, 'state'); }
async function saveDoc(d, hist) {
  d.updatedAt = new Date().toISOString();
  if (hist) (d.history = d.history || []).push({ at: d.updatedAt, a: hist[0], d: hist[1] || '' });
  const i = st.docs.findIndex((x) => x.id === d.id); if (i >= 0) st.docs[i] = d; else st.docs.unshift(d);
  await DB.put('docs', d); summary();
}
async function saveSubject(s) { const i = st.subjects.findIndex((x) => x.id === s.id); if (i >= 0) st.subjects[i] = s; else st.subjects.push(s); await DB.put('subjects', s); summary(); }
function nextReg(direction, ymd) {
  const y = (ymd || today()).slice(0, 4), p = DIR[direction] ? DIR[direction].pfx : 'D', k = `${p}-${y}`;
  st.meta.counters[k] = (st.meta.counters[k] || 0) + 1;
  return `${p}-${y}/${String(st.meta.counters[k]).padStart(4, '0')}`;
}
/** genişlənmənin panelinə (portal pəncərəsi) qısa xülasə */
let sumT = null;
function summary() {
  clearTimeout(sumT);
  sumT = setTimeout(() => {
    const L = live(), m = today().slice(0, 7);
    const exp = expiring().length;
    const recent = L.slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 5).map((d) => ({ id: d.id, title: d.title, subj: subjName(d.subj), icon: typeIcon(d.type), date: d.date }));
    try { chrome.storage.local.set({ ammo_dd_summary: { total: L.length, subjects: st.subjects.length, month: L.filter((d) => String(d.createdAt).slice(0, 7) === m).length, expiring: exp, recent, updatedAt: Date.now() } }); } catch (e) { /* */ }
    counts();
  }, 300);
}
function counts() {
  const L = live();
  $('#cDocs').textContent = L.length || ''; $('#cSubj').textContent = st.subjects.length || '';
  $('#cSends').textContent = st.sends.length || ''; $('#cTrash').textContent = st.docs.length - L.length || '';
}
function expiring() {
  const lim = new Date(); lim.setDate(lim.getDate() + (+S().expiryDays || 30)); const L = ymdOf(lim);
  return live().filter((d) => d.expiry && d.expiry <= L && d.status !== 'Arxivdə').sort((a, b) => a.expiry.localeCompare(b.expiry));
}

// ================================================================== faylın oxunması
const extOf = (n) => (String(n).toLowerCase().match(/\.([a-z0-9]+)$/) || [, ''])[1];
const IMG_EXT = ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif', 'tif', 'tiff'];
const MIME = { pdf: 'application/pdf', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', doc: 'application/msword', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', xls: 'application/vnd.ms-excel', txt: 'text/plain', csv: 'text/csv', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', odt: 'application/vnd.oasis.opendocument.text', rtf: 'application/rtf' };
const mimeOf = (n, t) => t || MIME[extOf(n)] || 'application/octet-stream';
const fileIcon = (n) => { const e = extOf(n); return e === 'pdf' ? '📕' : /docx?|odt|rtf/.test(e) ? '📘' : /xlsx?|csv/.test(e) ? '📗' : IMG_EXT.includes(e) ? '🖼️' : '📄'; };
let pdfjsP = null;
function pdfjs() {
  if (!pdfjsP) pdfjsP = import('../lib/pdfjs/pdf.min.mjs').then((m) => { m.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdfjs/pdf.worker.min.mjs'); return m; });
  return pdfjsP;
}
function xmlText(xml, paraEnd, cellEnd) {
  return xml.replace(new RegExp(paraEnd, 'g'), '\n').replace(new RegExp(cellEnd, 'g'), '\t').replace(/<w:tab\/>|<text:tab\/>/g, '\t').replace(/<w:br\/>|<text:line-break\/>/g, '\n')
    .replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, (m, n) => String.fromCodePoint(+n)).replace(/&amp;/g, '&')
    .replace(/[  ]+/g, ' ').replace(/\n\s*\n\s*\n+/g, '\n\n');
}
async function sha256(buf) { const h = await crypto.subtle.digest('SHA-256', buf); return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join(''); }
function canvasThumb(src, w = 360) {
  const k = Math.min(1, w / src.width); const c = document.createElement('canvas'); c.width = Math.round(src.width * k); c.height = Math.round(src.height * k);
  const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(src, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', 0.72);
}
function loadImg(url) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Şəkil oxunmadı')); i.src = url; }); }
const blobToDataUrl = (b) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(b); });

/** v1.23: mətnin keyfiyyəti — PDF-də şrift kodlaşdırması pozuqdursa (Məhkəmə/DVX sənədlərində tez-tez olur) mətn «zibil» çıxır */
const COMMON_WORDS = /\b(v[əe]|il[əe]|[üu]zr[əe]|haqq[ıi]nda|tarixli|n[öo]mr[əe]li|m[əe]hk[əe]m[əe]|vergi|m[üu]qavil[əe]|[şs]irk[əe]t|mmc|v[öo]en|az[əe]rbaycan|respublikas[ıi]|bak[ıi]|olunur|edilir|g[öo]r[əe]|[üu][çc][üu]n|il|ay|manat|azn|и|в|на|от|по|договор|суд|the|and|of|to)\b/gi;
function textQuality(t) {
  const s = String(t || '').replace(/\s+/g, '');
  if (s.length < 20) return { ok: false, why: 'az', len: s.length };
  const letters = (s.match(/[A-Za-zƏəÖöÜüĞğIıİiŞşÇçА-Яа-яЁё0-9]/g) || []).length;
  const bad = (s.match(/[�-]|Ã.|Ð.|Ñ./g) || []).length;
  const words = (String(t).match(COMMON_WORDS) || []).length;
  const ratio = letters / s.length;
  const ok = ratio > 0.62 && bad / s.length < 0.03 && (s.length < 400 || words >= 2);
  return { ok, ratio, bad, words, len: s.length };
}
const CONTAINER_EXT = ['adoc', 'edoc', 'asice', 'asics', 'sce', 'bdoc', 'ddoc', 'zip'];
function magicOf(buf) {
  const u = new Uint8Array(buf.slice(0, 8));
  if (u[0] === 0x25 && u[1] === 0x50 && u[2] === 0x44 && u[3] === 0x46) return 'pdf';
  if (u[0] === 0x50 && u[1] === 0x4b) return 'zip';
  if (u[0] === 0xd0 && u[1] === 0xcf && u[2] === 0x11) return 'ole';
  if (u[0] === 0xff && u[1] === 0xd8) return 'jpg';
  if (u[0] === 0x89 && u[1] === 0x50) return 'png';
  if (u[0] === 0x7b && u[1] === 0x5c && u[2] === 0x72) return 'rtf';
  return '';
}
async function renderPage(pdf, i, width = 2000) {
  const pg = await pdf.getPage(i); const vp = pg.getViewport({ scale: 1 });
  const scale = Math.max(1.5, Math.min(3, width / vp.width)); const v2 = pg.getViewport({ scale });
  const c = document.createElement('canvas'); c.width = Math.round(v2.width); c.height = Math.round(v2.height);
  const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
  await pg.render({ canvasContext: x, viewport: v2 }).promise;
  return c;
}
const OCR_LANG = 'aze+rus+eng';

/** → { text, thumb, ocr, pages, inner } — PDF, Word, Excel, şəkil, həmçinin ADOC/EDOC (ASAN İmza konteyneri) və ZIP */
async function extract(file, buf, onStatus, depth = 0) {
  let e = extOf(file.name);
  const mg = magicOf(buf);
  if (mg === 'pdf') e = 'pdf';
  else if (mg === 'ole' && !['doc', 'xls'].includes(e)) e = 'doc';
  else if (mg === 'rtf') e = 'rtf';
  else if ((mg === 'jpg' || mg === 'png') && !IMG_EXT.includes(e)) e = mg;
  if (mg === 'zip' && !['docx', 'xlsx', 'odt', 'ods', 'pptx'].includes(e)) {
    // ADOC (ASAN İmza), EDOC, ASiC-E və ya ZIP — içindəki əsas sənəd(lər)i oxu
    const z = await XR.unzip(buf);
    const names = Object.keys(z);
    if (names.includes('word/document.xml')) e = 'docx';
    else if (names.includes('xl/workbook.xml')) e = 'xlsx';
    else if (names.includes('content.xml') && !names.some((n) => /^META-INF\/signatures/i.test(n))) e = 'odt';
    else if (depth < 2) {
      const inner = names.filter((n) => !n.endsWith('/') && !/^META-INF\//i.test(n) && !/^mimetype$/i.test(n) && !/(signature|manifest|\.p7s$|\.sig$|\.cer$|\.crt$)/i.test(n) && z[n] && z[n].length)
        .sort((a, b) => (/\.pdf$/i.test(b) - /\.pdf$/i.test(a)) || (z[b].length - z[a].length)).slice(0, 6);
      const parts = []; let thumb = '', ocr = false, pages = 0;
      for (const n of inner) {
        onStatus && onStatus(`Konteyner açılır: ${n.split('/').pop()}…`, 10);
        const f = new File([z[n]], n.split('/').pop(), { type: mimeOf(n) });
        try {
          const r = await extract(f, z[n].buffer.slice(z[n].byteOffset, z[n].byteOffset + z[n].byteLength), onStatus, depth + 1);
          if (r.text && r.text.trim()) parts.push(r.text);
          if (!thumb && r.thumb) thumb = r.thumb; if (r.ocr) ocr = true; pages += r.pages || 0;
        } catch (er) { /* növbəti fayl */ }
      }
      return { text: parts.join('\n\n'), thumb, ocr, pages, inner: inner.map((n) => n.split('/').pop()) };
    }
  }
  if (e === 'pdf') {
    const P = await pdfjs();
    const pdf = await P.getDocument({ data: new Uint8Array(buf.slice(0)), isEvalSupported: false }).promise;
    const lines = [];
    for (let i = 1; i <= Math.min(pdf.numPages, 40); i++) {
      const page = await pdf.getPage(i); const tc = await page.getTextContent();
      let lastY = null, line = '', lastX = null;
      for (const it of tc.items) {
        const y = Math.round(it.transform[5]), x = it.transform[4];
        if (lastY != null && Math.abs(y - lastY) > 3) { lines.push(line); line = ''; lastX = null; }
        if (lastX != null && x - lastX > 40) line += '\t'; else if (line && !line.endsWith(' ') && !it.str.startsWith(' ')) line += ' ';
        line += it.str; lastY = y; lastX = x + (it.width || 0);
        if (it.hasEOL) { lines.push(line); line = ''; lastY = null; lastX = null; }
      }
      if (line) lines.push(line); lines.push('');
    }
    let text = lines.join('\n').replace(/[ ]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
    const first = await renderPage(pdf, 1, 1700);
    const thumb = canvasThumb(first);
    let ocr = false;
    const q = textQuality(text);
    const perPage = q.len / Math.max(1, Math.min(pdf.numPages, 40));
    if ((!q.ok || perPage < 60) && S().ocr !== false && IMG) {
      // skan edilmiş və ya şrifti pozuq PDF — səhifələri OCR ilə oxuyuruq (ilk 4 + sonuncu: imza, tarix adətən sondadır)
      const idx = [...new Set([1, 2, 3, 4, pdf.numPages].filter((i) => i >= 1 && i <= pdf.numPages))];
      const parts = [];
      try {
        for (const i of idx) {
          const c = i === 1 ? await renderPage(pdf, 1, 2200) : await renderPage(pdf, i, 2200);
          parts.push(await IMG.ocr(c.toDataURL('image/png'), (pr, status) => onStatus && onStatus(status === 'recognizing text' ? `OCR: səhifə ${i}/${pdf.numPages} — ${pr}%` : 'OCR mühərriki yüklənir (ilk dəfə bir az çəkir)…', pr), OCR_LANG));
        }
        const ot = parts.join('\n\n');
        const oq = textQuality(ot);
        if (oq.ok && (oq.words >= q.words || !q.ok)) { text = q.ok && q.len > 200 ? text + '\n\n' + ot : ot; ocr = true; }
      } catch (er) { if (!q.ok) text = ''; onStatus && onStatus('OCR alınmadı: ' + er.message, 0); }
    } else if (!q.ok) text = '';
    return { text, thumb, ocr, pages: pdf.numPages };
  }
  if (e === 'docx') {
    const f = await XR.unzip(buf, (n) => /^word\/(document|header\d*|footer\d*)\.xml$/.test(n));
    const order = Object.keys(f).sort((a, b) => (/document/.test(b) - /document/.test(a)));
    const t = order.map((n) => xmlText(new TextDecoder().decode(f[n]).replace(/^[\s\S]*?<w:body>/, ''), '</w:p>', '</w:tc>')).join('\n');
    return { text: t };
  }
  if (e === 'odt') {
    const f = await XR.unzip(buf, (n) => n === 'content.xml');
    return { text: f['content.xml'] ? xmlText(new TextDecoder().decode(f['content.xml']), '</text:p>|</text:h>', '</table:table-cell>') : '' };
  }
  if (e === 'doc') { const r = MSDOC.docText(buf); return { text: Array.isArray(r) ? r.map((p) => (typeof p === 'string' ? p : p.t)).join('\n') : String(r || '') }; }
  if (e === 'xlsx' || e === 'xls') { try { const rows = await XR.read(buf); return { text: rows.slice(0, 3000).map((r) => r.filter((c) => String(c).trim()).join('\t')).filter(Boolean).join('\n') }; } catch (er) { return { text: '' }; } }
  if (e === 'txt' || e === 'csv' || e === 'xml' || e === 'html' || e === 'htm') { let t = new TextDecoder('utf-8').decode(buf); if (/�/.test(t)) t = new TextDecoder('windows-1251').decode(buf); if (/^\s*</.test(t)) t = t.replace(/<style[\s\S]*?<\/style>|<script[\s\S]*?<\/script>/gi, '').replace(/<br\s*\/?>|<\/p>|<\/div>|<\/tr>/gi, '\n').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&'); return { text: t }; }
  if (e === 'rtf') { const t = new TextDecoder('windows-1252').decode(buf); return { text: t.replace(/\\par[d]?/g, '\n').replace(/\\'([0-9a-f]{2})/gi, (m, h) => String.fromCharCode(parseInt(h, 16))).replace(/\\u(-?\d+)\??/g, (m, n) => String.fromCharCode(+n < 0 ? +n + 65536 : +n)).replace(/\\[a-z]+-?\d* ?|[{}]/gi, '') }; }
  if (IMG_EXT.includes(e) || /^image\//.test(file.type)) {
    const url = await blobToDataUrl(file instanceof Blob ? file : new Blob([buf]));
    let thumb = '';
    try { const im = await loadImg(url); thumb = canvasThumb(im); } catch (er) { /* tif və s. göstərilməyə bilər */ }
    let text = '';
    if (S().ocr !== false && IMG && thumb) { try { text = await IMG.ocr(url, (pr, status) => onStatus && onStatus(status === 'recognizing text' ? `OCR: mətn tanınır — ${pr}%` : 'OCR mühərriki yüklənir (ilk dəfə bir az çəkir)…', pr), OCR_LANG); } catch (er) { onStatus && onStatus('OCR alınmadı: ' + er.message, 0); } }
    return { text, thumb, ocr: !!text };
  }
  return { text: '' };
}

// ================================================================== yükləmə növbəsi
async function expandZip(file) {
  const files = await XR.unzip(await file.arrayBuffer());
  return Object.entries(files).filter(([n, b]) => !n.endsWith('/') && !/__MACOSX|\.DS_Store|Thumbs\.db/i.test(n) && b.length)
    .map(([n, b]) => new File([b], n.split('/').pop(), { type: mimeOf(n) }));
}
async function handleFiles(list, opts = {}) {
  let files = [...(list || [])];
  if (!files.length) return;
  const out = [];
  for (const f of files) {
    if (extOf(f.name) === 'zip' && !(opts && opts.keepZip)) { try { out.push(...await expandZip(f)); } catch (e) { toast('ZIP açılmadı: ' + e.message); } } else out.push(f);
  }
  files = out;
  const add = files.map((file) => ({ id: uid(), file, name: file.name, size: file.size, status: 'wait', note: 'Növbədədir', progress: 0, form: null, res: null, text: '', auto: !!opts.auto, src: opts.src || '' }));
  const running = st.queue.some((q) => ['wait', 'read'].includes(q.status));
  st.queue.push(...add);
  if (!$('#modal .queue-modal')) st.qi = st.queue.indexOf(add[0]);
  renderQueue();
  if (!running) processQueue();
}
async function processQueue() {
  for (;;) {
    const q = st.queue.find((x) => x.status === 'wait'); if (!q) break;
    q.status = 'read'; q.note = 'Oxunur…'; renderQueue();
    try {
      const buf = await q.file.arrayBuffer();
      q.hash = await sha256(buf);
      const dup = st.docs.find((d) => !d.deleted && (d.hash === q.hash || (d.files || []).some((f) => f.hash === q.hash)));
      if (dup) q.dupOf = dup.id;
      let r = { text: '' };
      try { r = await extract(q.file, buf, (note, pr) => { q.note = note; q.progress = pr; updateQi(q); }); } catch (e) { q.warn = 'Mətn oxunmadı: ' + (e.message || e); }
      if (q.status === 'skipped') continue;
      q.text = r.text || ''; q.thumb = r.thumb || ''; q.ocr = r.ocr;
      q.res = analyzeQ(q);
      q.form = formFromAnalysis(q.res, q);
      q.status = 'ready'; q.note = '';
      refreshUntouched(q);
      if (!q.text.trim() && !q.warn) q.warn = S().ocr === false ? 'Faylda mətn qatı yoxdur (skan). Ayarlarda «OCR ilə oxu»nu açın — AMMO skanı da oxuyacaq.' : 'Faylda oxuna bilən mətn tapılmadı (OCR da nəticə vermədi — internet bağlantısını yoxlayın). Şirkəti aşağıdan seçin, növü yoxlayın.';
      else if (r.inner && r.inner.length && !q.warn) q.note = 'Konteyner: ' + r.inner.join(', ');
      const many = companyCands(q).length > 1; // bir neçə şirkət — istifadəçi seçməlidir
      if (q.auto && !many && !q.dupOf && q.form.subj && (q.form.subj !== '__new' || q.form.newSubj.name.trim())) { await commit(q, true); }
      else if (S().autoSend && !many && !q.dupOf && q.res.owner && q.res.confidence >= +S().autoThreshold) { await commit(q, true); }
    } catch (e) { q.status = 'error'; q.note = 'Xəta: ' + (e.message || e); }
    renderQueue();
  }
  finishIfDone();
}
/** Növbədəki bir neçə sənəddə təkrarlanan tərəf — çox güman ki, bizim müştəridir (subyekt). */
const partyKey = (p) => p.voen || A.nameKey(p.name);
function analyzeQ(q) {
  let res = A.analyze(q.text, q.name, st.subjects, st.meta.learn);
  if (!res.owner && res.parties.length > 1) {
    const f = {};
    for (const o of st.queue) if (o.res) { const seen = new Set(); for (const p of o.res.parties) { const k = partyKey(p); if (k && !seen.has(k)) { seen.add(k); f[k] = (f[k] || 0) + 1; } } }
    let best = null;
    for (const p of res.parties) { const n = f[partyKey(p)] || 0; if (n >= 2 && (!best || n > best.n)) best = { p, n }; }
    if (best) {
      const tmp = { id: '__new', kind: best.p.kind || 'legal', name: best.p.name || 'VÖEN ' + best.p.voen, voen: best.p.voen || '' };
      const r2 = A.analyze(q.text, q.name, [...st.subjects, tmp], st.meta.learn);
      if (r2.owner === '__new') { r2.owner = ''; r2.suggestSubject = { kind: tmp.kind, name: tmp.name, voen: tmp.voen }; res = r2; }
    }
  }
  return res;
}
/** istifadəçinin toxunmadığı sənədləri yenidən təhlil et (yeni subyekt yarandıqda və ya yeni sənəd oxunduqda) */
function refreshUntouched(except) {
  let cur = false;
  for (const o of st.queue) {
    if (o === except || o.status !== 'ready' || o.touched) continue;
    const before = JSON.stringify(o.form); o.res = analyzeQ(o); o.form = formFromAnalysis(o.res, o);
    if (JSON.stringify(o.form) !== before && st.queue[st.qi] === o) cur = true;
  }
  if (cur) renderQueue(true);
}
function formFromAnalysis(r, q) {
  const sug = r.suggestSubject;
  return {
    subj: r.owner || (sug ? '__new' : ''), newSubj: sug ? { kind: sug.kind, name: sug.name, voen: sug.voen || '', fin: sug.fin || '' } : { kind: 'legal', name: '', voen: '', fin: '' },
    cat: r.cat, type: r.type, typeLabel: r.typeLabel || '', title: r.title, titleAuto: true, number: r.number, date: r.date || '', period: r.period || '', direction: r.direction,
    cpName: r.counterparty ? r.counterparty.name : '', cpVoen: r.counterparty ? r.counterparty.voen : '', person: r.person || '',
    amount: r.amount != null ? String(r.amount) : '', currency: r.currency || 'AZN', expiry: r.expiry || '', tags: q && q.ocr ? 'skan' : '', note: r.note || '', status: 'Qeydə alınıb', heading: r.heading || '',
  };
}
function autoTitle(f) { if (f.heading) return [f.heading, f.number ? '№ ' + f.number : ''].filter(Boolean).join(' '); const who = f.person || f.cpName; return [f.typeLabel && f.type === 'muqavile' ? f.typeLabel : typeName(f.type), f.number ? '№ ' + f.number : '', who ? '— ' + who : ''].filter(Boolean).join(' '); }

async function commit(q, auto = false) {
  const f = q.form; let subj = f.subj;
  if (subj === '__new') {
    if (!f.newSubj.name.trim()) throw new Error('Yeni subyektin adını yazın');
    const s = { id: uid(), kind: f.newSubj.kind, name: f.newSubj.name.trim(), voen: (f.newSubj.voen || '').replace(/\D/g, '').slice(0, 10), fin: (f.newSubj.fin || '').toUpperCase(), aliases: [], color: COLORS[st.subjects.length % COLORS.length], createdAt: new Date().toISOString() };
    await saveSubject(s); subj = s.id; f.subj = s.id;
    // növbədəki digər sənədlər üçün də bu subyekti təklif edirik
    for (const o of st.queue) if (o !== q && o.form && o.form.subj === '__new' && A.nameKey(o.form.newSubj.name) === A.nameKey(s.name)) o.form.subj = s.id;
  }
  const now = new Date().toISOString();
  const fid = uid();
  await DB.put('files', { id: fid, blob: q.file, name: q.name, mime: mimeOf(q.name, q.file.type), size: q.size, hash: q.hash });
  const amt = f.amount === '' ? null : A.parseMoney(f.amount);
  const doc = {
    id: uid(), regNo: nextReg(f.direction, f.date), subj, cat: f.cat, type: f.type, title: (f.title || autoTitle(f)).trim(), number: f.number.trim(), date: f.date, period: f.period,
    direction: f.direction, cp: { name: f.cpName.trim(), voen: f.cpVoen.replace(/\D/g, '') }, person: f.person.trim(), amount: isFinite(amt) ? amt : null, currency: f.currency,
    expiry: f.expiry, tags: f.tags.split(',').map((t) => t.trim()).filter(Boolean), note: f.note, status: f.status || 'Qeydə alınıb', fav: false,
    files: [{ fid, name: q.name, size: q.size, mime: mimeOf(q.name, q.file.type), hash: q.hash, ver: 1, at: now }], hash: q.hash, thumb: q.thumb || '',
    conf: q.res.confidence, auto: { type: q.res.type, owner: q.res.owner, by: auto ? 'auto' : 'user' }, ocr: !!q.ocr, src: q.src || '',
    parties: (q.res.parties || []).filter((p) => p.name || p.voen).slice(0, 8),
    createdAt: now, updatedAt: now, history: [], sent: [], links: [], deleted: null,
  };
  doc.history.push({ at: now, a: 'Qeydə alındı', d: `${q.name} · AMMO təyin etdi: ${typeName(q.res.type)} (${Math.round(q.res.confidence * 100)}%)${auto ? ' · avtomatik göndərildi' : ''}${q.src ? ' · mənbə: ' + q.src : ''}` });
  await DB.put('texts', { id: doc.id, text: q.text.slice(0, 300000) });
  if (st.textCache) st.textCache.set(doc.id, A.fold(q.text));
  // öyrənmə: istifadəçi növü dəyişibsə — bu başlıqlı sənədləri gələcəkdə düz tanıyaq
  if (!auto && f.type !== q.res.type) learn(q.text, q.name, f.type);
  autoLink(doc, q.text);
  await saveDoc(doc); await saveMeta();
  q.status = 'sent'; q.docId = doc.id; q.note = doc.regNo;
  refreshUntouched();
  return doc;
}
function learn(text, fileName, type) {
  const first = A.fold(String(text || '').split('\n').map((l) => l.trim()).filter(Boolean)[0] || '').replace(/[0-9№#.,:;/\\()"«»-]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 50);
  if (first.replace(/[^a-zа-я]/g, '').length < 5) return;
  st.meta.learn = (st.meta.learn || []).filter((r) => r.key !== first);
  st.meta.learn.unshift({ key: first, type, at: new Date().toISOString(), from: fileName });
  st.meta.learn = st.meta.learn.slice(0, 400);
}
/** eyni subyektdə: eyni nömrəli sənədlər (HF/TTA/RP bir qaimə üzrə) və mətndə adı çəkilən müqavilə → əlaqələndirilir */
function autoLink(doc, text) {
  const ft = A.fold(text || '');
  for (const d of live()) {
    if (d.id === doc.id || d.subj !== doc.subj) continue;
    const sameNo = doc.number && d.number && doc.number.length >= 2 && d.number === doc.number && d.type !== doc.type;
    const mentions = d.cat === 'muqavile' && d.number && d.number.length >= 3 && new RegExp('(^|[^a-z0-9])' + A.fold(d.number).replace(/[.*+?^${}()|[\]\\/]/g, '\\$&') + '($|[^a-z0-9])').test(ft);
    if (sameNo || mentions) {
      if (!doc.links.includes(d.id)) doc.links.push(d.id);
      if (!(d.links || []).includes(doc.id)) { d.links = [...(d.links || []), doc.id]; DB.put('docs', d); }
    }
  }
}
function finishIfDone() {
  if (!st.queue.length || st.queue.some((q) => ['wait', 'read', 'ready'].includes(q.status))) return;
  const sent = st.queue.filter((q) => q.status === 'sent').length;
  st.queue = []; closeModal();
  if (sent) toast(`✅ ${sent} sənəd dövriyyəyə əlavə edildi`);
  render();
}

// ================================================================== modal köməkçiləri
function modal(html, cls = '') {
  $('#modal').innerHTML = `<div class="ov"><div class="box ${cls}">${html}</div></div>`;
  const ov = $('#modal .ov');
  ov.onmousedown = (e) => { if (e.target === ov && !cls.includes('queue-box')) closeModal(); };
  $$('#modal [data-close]').forEach((b) => (b.onclick = closeModal));
  return $('#modal .box');
}
function closeModal() { $('#modal').innerHTML = ''; }
function confirmBox(text, ok = 'Bəli', danger = false) {
  return new Promise((res) => {
    const b = modal(`<div class="mh"><h2>Təsdiq</h2><button class="x" data-no>✕</button></div><div class="mb">${text}</div>
      <div class="mf"><div class="sp"><button class="btn ghost" data-no>İmtina</button><button class="btn ${danger ? 'danger' : 'primary'}" data-yes>${esc(ok)}</button></div></div>`, 'sm');
    $$('[data-no]', b).forEach((x) => (x.onclick = () => { closeModal(); res(false); }));
    $('[data-yes]', b).onclick = () => { closeModal(); res(true); };
  });
}
function typeOptions(sel, withNew = false) {
  return A.CATS.map((c) => { const ts = A.TYPES.filter((t) => t.cat === c.id); return ts.length ? `<optgroup label="${esc(c.icon + ' ' + c.name)}">${ts.map((t) => `<option value="${t.id}" ${t.id === sel ? 'selected' : ''}>${esc(t.name)}${t.custom ? ' ★' : ''}</option>`).join('')}</optgroup>` : ''; }).join('')
    + (withNew ? '<option disabled>──────────</option><option value="__newtype">➕ Yeni növ yarat…</option>' : '');
}
function subjOptions(sel, extra = '') {
  const L = st.subjects.slice().sort((a, b) => a.name.localeCompare(b.name, 'az'));
  const grp = (k, lbl) => { const g = L.filter((s) => (k === 'physical') === (s.kind === 'physical')); return g.length ? `<optgroup label="${lbl}">${g.map((s) => `<option value="${s.id}" ${s.id === sel ? 'selected' : ''}>${esc(s.name)}${s.voen ? ' · ' + s.voen : ''}</option>`).join('')}</optgroup>` : ''; };
  return extra + grp('legal', '🏢 Hüquqi şəxslər') + grp('physical', '👤 Fiziki şəxslər (FS)');
}
const dirOptions = (sel) => Object.entries(DIR).map(([k, v]) => `<option value="${k}" ${k === sel ? 'selected' : ''}>${v.icon} ${v.name}</option>`).join('');
const statusOptions = (sel) => STATUSES.map((x) => `<option ${x === sel ? 'selected' : ''}>${x}</option>`).join('');
const curOptions = (sel) => ['AZN', 'USD', 'EUR', 'RUB', 'TRY', 'GBP'].map((x) => `<option ${x === sel ? 'selected' : ''}>${x}</option>`).join('');

// ================================================================== "Göndərilsin?" pəncərəsi
const qIcon = (q) => ({ wait: '⏳', read: '🔍', ready: '❓', sent: '✅', skipped: '⏭️', error: '⚠️' }[q.status]);
function qiHtml(q, i) {
  const sub = q.status === 'ready' ? `${!q.picked && companyCands(q).length > 1 ? '<em class="needpick">🏢 şirkəti seçin</em> · ' : ''}${typeName(q.form.type)} · ${q.form.subj === '__new' ? '➕ ' + esc(q.form.newSubj.name) : esc(subjName(q.form.subj))}` : esc(q.note || '');
  return `<div class="qi ${i === st.qi ? 'on' : ''} ${['sent', 'skipped'].includes(q.status) ? 'done' : ''}" data-qi="${i}"><span class="ic">${qIcon(q)}</span><div><b title="${esc(q.name)}">${esc(q.name)}</b><small>${sub}</small></div></div>`;
}
function updateQi(q) {
  const i = st.queue.indexOf(q); const el = $(`#modal [data-qi="${i}"]`); if (el) el.outerHTML = qiHtml(q, i);
  if (i === st.qi) { const n = $('#modal [data-note]'); if (n) n.textContent = q.note || ''; const p = $('#modal [data-prog]'); if (p) p.style.width = (q.progress || 5) + '%'; }
  bindQiClicks();
}
function bindQiClicks() { $$('#modal [data-qi]').forEach((el) => (el.onclick = () => { st.qi = +el.dataset.qi; renderQueue(true); })); }
let qRendered = '';
function renderQueue(force) {
  if (!st.queue.length) return;
  st.qi = Math.max(0, Math.min(st.qi, st.queue.length - 1));
  const single = st.queue.length === 1;
  let box = $('#modal .queue-box');
  if (!box || box.dataset.single !== String(single)) {
    box = modal(`<div class="mh queue-modal"><div class="ask"><span class="q">?</span>Sənəd dövriyyəsinə göndərilsin?</div><span class="muted small" data-cnt></span><button class="x" data-cancel title="Bağla">✕</button></div>
      <div class="mb"><div class="queue ${single ? 'single' : ''}">${single ? '' : '<div class="qlist"></div>'}<div class="qreview"></div></div></div>
      <div class="mf"><button class="btn ghost" data-skip>✕ Göndərmə</button><span class="muted small">AMMO məlumatları özü doldurdu — yoxlayın, lazım olsa düzəldin.</span>
        <div class="sp"><button class="btn soft" data-all>Hamısını göndər</button><button class="btn primary lg" data-send>📤 Göndər</button></div></div>`, 'queue-box');
    box.dataset.single = String(single); qRendered = '';
    $('[data-cancel]', box).onclick = async () => {
      const left = st.queue.filter((q) => ['wait', 'read', 'ready'].includes(q.status)).length;
      if (left && !(await confirmBox(`${left} sənəd hələ göndərilməyib. Pəncərə bağlansın və onlar göndərilməsin?`, 'Bəli, bağla'))) { renderQueue(true); return; }
      st.queue.forEach((q) => { if (['wait', 'read', 'ready'].includes(q.status)) q.status = 'skipped'; });
      finishIfDone(); closeModal(); render();
    };
    $('[data-skip]', box).onclick = () => { const q = st.queue[st.qi]; if (q && q.status !== 'sent') q.status = 'skipped'; nextQ(); };
    $('[data-send]', box).onclick = () => sendCurrent();
    $('[data-all]', box).onclick = async () => {
      const ready = st.queue.filter((q) => q.status === 'ready');
      for (const q of ready) { try { await commit(q); } catch (e) { toast(`${q.name}: ${e.message}`); st.qi = st.queue.indexOf(q); renderQueue(true); return; } }
      renderQueue(true); finishIfDone();
    };
  }
  const list = $('.qlist', box); if (list) { list.innerHTML = st.queue.map(qiHtml).join(''); bindQiClicks(); }
  const done = st.queue.filter((q) => q.status === 'sent').length, ready = st.queue.filter((q) => q.status === 'ready').length;
  $('[data-cnt]', box).textContent = `${st.queue.length} fayl · ${done} göndərildi${ready ? ' · ' + ready + ' təsdiq gözləyir' : ''}`;
  const all = $('[data-all]', box); all.textContent = `Hamısını göndər (${ready})`; all.classList.toggle('hidden', single || ready < 2);
  const q = st.queue[st.qi];
  $('[data-send]', box).disabled = !q || q.status !== 'ready'; $('[data-skip]', box).disabled = !q || !['ready', 'wait', 'read', 'error'].includes(q.status);
  const key = q ? `${q.id}:${q.status}` : '';
  if (!force && key === qRendered) return;
  qRendered = key;
  $('.qreview', box).innerHTML = q ? reviewHtml(q) : '';
  if (q && q.status === 'ready') bindReview(q);
  const op = $('[data-openreg]', box); if (op) op.onclick = () => { closeModal(); openDoc(q.docId); };
}
function nextQ() {
  const i = st.queue.findIndex((x, j) => j > st.qi && ['ready', 'wait', 'read'].includes(x.status));
  const j = st.queue.findIndex((x) => ['ready', 'wait', 'read'].includes(x.status));
  if (i >= 0) st.qi = i; else if (j >= 0) st.qi = j;
  renderQueue(true); finishIfDone();
}
async function sendCurrent() {
  const q = st.queue[st.qi]; if (!q || q.status !== 'ready') return;
  if (q.form.subj === '__new' && !q.form.newSubj.name.trim()) { toast('Yeni subyektin adını yazın və ya siyahıdan seçin'); return; }
  try { await commit(q); toast(`✅ ${q.form.title || typeName(q.form.type)} → ${subjName(q.form.subj)}`); } catch (e) { toast('Xəta: ' + e.message); return; }
  nextQ();
}
function confBar(c) { const p = Math.round(c * 100); const col = p >= 80 ? 'var(--ok)' : p >= 55 ? 'var(--gold)' : 'var(--bad)'; return `<div class="conf">İnam <div class="tr"><i style="width:${p}%;background:${col}"></i></div><b style="color:${col}">${p}%</b></div>`; }
function reviewHtml(q) {
  if (['wait', 'read'].includes(q.status)) return `<div class="card" style="text-align:center;padding:50px 20px"><div style="font-size:46px">${fileIcon(q.name)}</div><b>${esc(q.name)}</b><div class="muted" data-note>${esc(q.note)}</div><div class="prog" style="max-width:360px;margin:12px auto 0"><i data-prog style="width:${q.progress || 8}%"></i></div><div class="small muted" style="margin-top:14px">Mətn oxunur → növ, subyekt, nömrə, tarix və məbləğ təyin olunur…</div></div>`;
  if (q.status === 'error') return `<div class="card"><b>⚠️ ${esc(q.name)}</b><p class="muted">${esc(q.note)}</p></div>`;
  if (q.status === 'sent') return `<div class="card" style="text-align:center;padding:40px"><div style="font-size:44px">✅</div><b>Qeydə alındı: ${esc(q.note)}</b><div class="muted">${esc(q.form.title)} → ${esc(subjName(q.form.subj))}</div><button class="btn soft" style="margin-top:12px" data-openreg>Sənədi aç</button></div>`;
  if (q.status === 'skipped') return `<div class="card" style="text-align:center;padding:40px"><div style="font-size:40px">⏭️</div><b>${esc(q.name)}</b><div class="muted">Göndərilmədi</div></div>`;
  const f = q.form, r = q.res, det = (k) => (r && ((k === 'subj' && r.owner) || (k === 'number' && r.number) || (k === 'date' && r.date) || (k === 'amount' && r.amount != null) || (k === 'cp' && r.counterparty) || (k === 'person' && r.person) || (k === 'period' && r.period) || (k === 'expiry' && r.expiry)) ? 'det' : '');
  const dup = q.dupOf ? st.docs.find((d) => d.id === q.dupOf) : null;
  const sug = r.suggestSubject;
  const chips = [...r.voens.map((v) => `<span class="pill acc" title="VÖEN">VÖEN ${v}</span>`), ...r.fins.map((v) => `<span class="pill" title="FİN">FİN ${v}</span>`), ...r.parties.filter((p) => p.name).slice(0, 4).map((p) => `<span class="pill">${esc(p.name)}</span>`)].join('');
  return `<div class="review">
    <div>
      <div class="rthumb">${q.thumb ? `<img src="${q.thumb}">` : fileIcon(q.name)}</div>
      <div class="small muted" style="margin-top:6px;word-break:break-all">${esc(q.name)} · ${fmtSize(q.size)}${q.ocr ? ' · OCR' : ''}</div>
      ${confBar(r.confidence)}
      ${r.alternatives.length ? `<div class="small muted">Digər ehtimallar:</div><div class="chips">${r.alternatives.map((t) => `<span class="pill" data-alt="${t}">${typeIcon(t)} ${esc(typeName(t))}</span>`).join('')}</div>` : ''}
      ${chips ? `<div class="small muted" style="margin-top:10px">Tapılan rekvizitlər:</div><div class="chips">${chips}</div>` : ''}
      <details class="txt"><summary>Oxunmuş mətn (${q.text.length} simvol)</summary><pre>${esc(q.text.slice(0, 6000)) || '—'}</pre></details>
    </div>
    <div>
      ${dup ? `<div class="dup">⚠️ Bu fayl artıq arxivdədir: <a href="#" data-dup>${esc(dup.regNo)} · ${esc(dup.title)}</a>. Yenə də göndərə bilərsiniz.</div>` : ''}
      ${q.warn ? `<div class="dup">${esc(q.warn)}</div>` : ''}
      <div class="path" data-path></div>
      ${coChooserHtml(q)}
      <div class="row">
        <label class="f ${det('subj')}">Sahibi (subyekt)<select data-k="subj">${subjOptions(f.subj, `${sug || (f.subj === '__new' && f.newSubj.name) ? `<option value="__new" ${f.subj === '__new' ? 'selected' : ''}>➕ Yeni: ${esc(f.subj === '__new' && f.newSubj.name ? f.newSubj.name : sug.name)}</option>` : '<option value="__new">➕ Yeni subyekt…</option>'}<option value="" ${!f.subj ? 'selected' : ''}>— təyin etmə —</option>`)}</select></label>
        <label class="f">Sənədin növü<select data-k="type">${typeOptions(f.type, true)}</select></label>
      </div>
      <div class="row ${f.subj === '__new' ? '' : 'hidden'}" data-newsubj style="margin-top:8px;background:#fff;border:1px dashed #cbd7fb;border-radius:10px;padding:10px">
        <label class="f">Növ<select data-n="kind"><option value="legal" ${f.newSubj.kind !== 'physical' ? 'selected' : ''}>🏢 Hüquqi şəxs</option><option value="physical" ${f.newSubj.kind === 'physical' ? 'selected' : ''}>👤 Fiziki şəxs (FS)</option></select></label>
        <label class="f" style="grid-column:span 2">Adı<input data-n="name" value="${esc(f.newSubj.name)}" placeholder="«Alfa» MMC / Məmmədov Rəşad"></label>
        <label class="f">VÖEN<input data-n="voen" value="${esc(f.newSubj.voen)}" maxlength="10"></label>
      </div>
      <div class="row" style="margin-top:8px">
        <label class="f">İstiqamət<select data-k="direction">${dirOptions(f.direction)}</select></label>
        <label class="f ${det('number')}">Nömrə<input data-k="number" value="${esc(f.number)}"></label>
        <label class="f ${det('date')}">Tarix<input type="date" data-k="date" value="${esc(f.date)}"></label>
        <label class="f ${det('period')}">Dövr (ay)<input type="month" data-k="period" value="${esc(f.period)}"></label>
      </div>
      <label class="f" style="margin-top:8px">Başlıq<input data-k="title" value="${esc(f.title)}"></label>
      <div class="row" style="margin-top:8px">
        <label class="f ${det('cp')}" style="grid-column:span 2">Kontragent<input data-k="cpName" value="${esc(f.cpName)}"></label>
        <label class="f ${det('cp')}">Kontragentin VÖEN-i<input data-k="cpVoen" value="${esc(f.cpVoen)}" maxlength="10"></label>
      </div>
      <div class="row" style="margin-top:8px">
        <label class="f ${det('person')}">Əməkdaş / şəxs<input data-k="person" value="${esc(f.person)}"></label>
        <label class="f ${det('amount')}">Məbləğ<input data-k="amount" value="${esc(f.amount)}" inputmode="decimal"></label>
        <label class="f">Valyuta<select data-k="currency">${curOptions(f.currency)}</select></label>
        <label class="f ${det('expiry')}">Qüvvədədir (bitmə)<input type="date" data-k="expiry" value="${esc(f.expiry)}"></label>
      </div>
      <div class="row" style="margin-top:8px">
        <label class="f">Status<select data-k="status">${statusOptions(f.status)}</select></label>
        <label class="f" style="grid-column:span 2">Teqlər (vergüllə)<input data-k="tags" value="${esc(f.tags)}" placeholder="təcili, orijinal, imzalı"></label>
      </div>
      <label class="f" style="margin-top:8px">Qeyd<textarea data-k="note" rows="2">${esc(f.note)}</textarea></label>
    </div></div>`;
}
function pathHtml(f) {
  const t = TYPE[f.type] || TYPE.diger; const c = catOf(t.cat);
  const sn = f.subj === '__new' ? '➕ ' + (f.newSubj.name || 'Yeni subyekt') : f.subj ? subjName(f.subj) : 'Təyin olunmayıb';
  return `📁 <em>${esc(sn)}</em><span>›</span><em>${c.icon} ${esc(c.name)}</em><span>›</span><em>${t.icon} ${esc(t.name)}</em><span>›</span><em>${(f.date || today()).slice(0, 4)}</em>`;
}
function bindReview(q) {
  const box = $('#modal .qreview'), f = q.form;
  const upd = () => { $('[data-path]', box).innerHTML = pathHtml(f); updateQi(q); };
  upd();
  $$('[data-k]', box).forEach((el) => {
    const ev = el.tagName === 'SELECT' || el.type === 'date' || el.type === 'month' ? 'change' : 'input';
    el.addEventListener(ev, () => {
      const k = el.dataset.k;
      if (k === 'type' && el.value === '__newtype') {
        el.value = f.type;
        const nm = suggestTypeName(q.text);
        newTypeDialog(null, { name: nm, kw: nm ? A.lowerAz(nm) : '', cat: f.cat }).then((id) => {
          if (!id) return;
          q.touched = true; f.type = id; f.cat = TYPE[id].cat;
          if (f.titleAuto) f.title = autoTitle(f);
          renderQueue(true); refreshUntouched(q);
          toast(`✅ Yeni növ yaradıldı: ${typeName(id)}`);
        });
        return;
      }
      q.touched = true; f[k] = el.value;
      if (k === 'title') f.titleAuto = false;
      if (k === 'type') { f.cat = (TYPE[f.type] || TYPE.diger).cat; if (TYPE[f.type].monthly && !f.period && f.date) { f.period = f.date.slice(0, 7); $('[data-k=period]', box).value = f.period; } }
      if (['type', 'number', 'person', 'cpName'].includes(k) && f.titleAuto) { f.title = autoTitle(f); $('[data-k=title]', box).value = f.title; }
      if (k === 'subj') { q.picked = true; $('[data-newsubj]', box).classList.toggle('hidden', f.subj !== '__new'); }
      upd();
    });
  });
  $$('[data-n]', box).forEach((el) => el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => { q.touched = true; f.newSubj[el.dataset.n] = el.value; upd(); }));
  $$('[data-co]', box).forEach((el) => (el.onclick = () => pickCompany(q, companyCands(q)[+el.dataset.co])));
  const coOther = $('[data-coother]', box); if (coOther) coOther.onclick = () => { const s = $('[data-k=subj]', box); s.focus(); s.showPicker && s.showPicker(); };
  $$('[data-alt]', box).forEach((el) => (el.onclick = () => { const s = $('[data-k=type]', box); s.value = el.dataset.alt; s.dispatchEvent(new Event('change')); }));
  const d = $('[data-dup]', box); if (d) d.onclick = (e) => { e.preventDefault(); openDoc(q.dupOf); };
  box.onkeydown = (e) => { if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA' && !e.isComposing) { e.preventDefault(); sendCurrent(); } };
}

// ================================================================== ikinci qat pəncərə (növbə pəncərəsinin üstündə)
function modal2(html, cls = '') {
  $('#modal2').innerHTML = `<div class="ov"><div class="box ${cls}">${html}</div></div>`;
  return $('#modal2 .box');
}
function closeModal2() { $('#modal2').innerHTML = ''; }
function confirmBox2(text, ok = 'Bəli', danger = false) {
  return new Promise((res) => {
    const b = modal2(`<div class="mh"><h2>Təsdiq</h2><button class="x" data-no>✕</button></div><div class="mb">${text}</div>
      <div class="mf"><div class="sp"><button class="btn ghost" data-no>İmtina</button><button class="btn ${danger ? 'danger' : 'primary'}" data-yes>${esc(ok)}</button></div></div>`, 'sm');
    $$('[data-no]', b).forEach((x) => (x.onclick = () => { closeModal2(); res(false); }));
    $('[data-yes]', b).onclick = () => { closeModal2(); res(true); };
  });
}

// ================================================================== öz sənəd növləri
const TYPE_ICONS = ['📄', '📑', '📋', '📝', '🗳️', '📜', '🧾', '💼', '🏦', '🔖', '📌', '🗂️', '📁', '✉️', '⚖️', '🛡️', '🏷️', '🚚', '🏗️', '🧩', '🔑', '📦', '💳', '🩺'];
/** sənədin ilk mənalı sətrindən növ adı təklifi */
function suggestTypeName(text) {
  const line = String(text || '').split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).find((l) => (l.match(/\p{L}/gu) || []).length >= 4 && l.length <= 70) || '';
  let n = line.replace(/[№#]\s*\S+/g, '').replace(/\d{1,2}[./]\d{1,2}[./]\d{2,4}/g, '').replace(/[«»"“”:;,.\-–—_]+$/g, '').replace(/^[^\p{L}]+/u, '').trim().slice(0, 50);
  if (n && n === n.toUpperCase()) { n = A.lowerAz(n); n = n.charAt(0).toLocaleUpperCase('az') + n.slice(1); }
  return n;
}
/** t — redaktə üçün mövcud öz növ; pre — yeni növ üçün ilkin dəyərlər. → Promise<typeId|null> */
function newTypeDialog(t = null, pre = {}) {
  return new Promise((res) => {
    const edit = !!t;
    const v = t ? { ...t } : { name: pre.name || '', cat: pre.cat && CAT[pre.cat] ? pre.cat : 'karguzarliq', icon: '📄', ret: 5, kw: pre.kw || '', monthly: false };
    const b = modal2(`<div class="mh"><h2>${edit ? '✏️ Sənəd növünü redaktə et' : '➕ Yeni sənəd növü'}</h2><button class="x" data-no>✕</button></div>
      <div class="mb"><div style="display:grid;gap:12px">
        <label class="f">Növün adı<input data-t="name" value="${esc(v.name)}" placeholder="məs. Protokol / qərar, Kredit müqaviləsi, Gömrük bəyannaməsi"></label>
        <div class="row">
          <label class="f">Qovluq (kateqoriya)<select data-t="cat">${A.CATS.map((c) => `<option value="${c.id}" ${c.id === v.cat ? 'selected' : ''}>${c.icon} ${esc(c.name)}</option>`).join('')}<option value="__newcat">➕ Yeni qovluq…</option></select></label>
          <label class="f">Saxlama müddəti (il, 0 = daimi)<input type="number" min="0" max="100" data-t="ret" value="${esc(v.ret)}"></label>
        </div>
        <div class="row hidden" data-nc style="background:#fff;border:1px dashed #cbd7fb;border-radius:10px;padding:10px">
          <label class="f" style="grid-column:span 2">Yeni qovluğun adı<input data-c="name" placeholder="məs. Bank sənədləri"></label>
          <label class="f">İkon<input data-c="icon" value="📁" maxlength="4"></label>
        </div>
        <div class="f" style="font-size:12px;color:#5d6380;font-weight:600">İkon<div class="icons">${TYPE_ICONS.map((i) => `<button type="button" class="ico ${i === v.icon ? 'on' : ''}" data-ico="${i}">${i}</button>`).join('')}</div></div>
        <label class="f">Açar sözlər (vergüllə) — sənədin başlığında və ya mətnində bu sözlər olarsa, AMMO onu özü bu növə aid edəcək<textarea data-t="kw" rows="2" placeholder="protokol, iclas protokolu, протокол">${esc(v.kw)}</textarea></label>
        <label class="chk"><input type="checkbox" data-t="monthly" ${v.monthly ? 'checked' : ''}> Hər ay gözlənilən sənəddir (komplektlik nəzarətinə əlavə et)</label>
        <div class="small muted">Açar söz yazmasanız da olar: sənədi bu növə əl ilə keçirdikdə AMMO onun başlığını öyrənir və növbəti dəfə özü tanıyır.</div>
      </div></div>
      <div class="mf"><div class="sp"><button class="btn ghost" data-no>İmtina</button><button class="btn primary" data-yes>${edit ? '💾 Yadda saxla' : '➕ Yarat'}</button></div></div>`, 'md');
    const nameI = $('[data-t=name]', b), kwI = $('[data-t=kw]', b), catS = $('[data-t=cat]', b);
    let kwTouched = edit || !!v.kw && A.lowerAz(v.name) !== v.kw;
    kwI.oninput = () => (kwTouched = true);
    nameI.oninput = () => { if (!kwTouched) kwI.value = A.lowerAz(nameI.value).split('/').map((x) => x.trim()).filter(Boolean).join(', '); };
    catS.onchange = () => $('[data-nc]', b).classList.toggle('hidden', catS.value !== '__newcat');
    $$('[data-ico]', b).forEach((el) => (el.onclick = () => { v.icon = el.dataset.ico; $$('[data-ico]', b).forEach((x) => x.classList.toggle('on', x === el)); }));
    $$('[data-no]', b).forEach((x) => (x.onclick = () => { closeModal2(); res(null); }));
    setTimeout(() => nameI.focus(), 30);
    b.onkeydown = (e) => { if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); $('[data-yes]', b).click(); } if (e.key === 'Escape') { e.stopPropagation(); closeModal2(); res(null); } };
    $('[data-yes]', b).onclick = async () => {
      const name = nameI.value.replace(/\s+/g, ' ').trim();
      if (!name) { toast('Növün adını yazın'); nameI.focus(); return; }
      if (A.TYPES.some((x) => x.id !== (t && t.id) && A.fold(x.name) === A.fold(name))) { toast('Bu adda növ artıq var — siyahıdan seçin'); return; }
      const C = st.meta.custom;
      let cat = catS.value;
      if (cat === '__newcat') {
        const cn = $('[data-c=name]', b).value.trim(); if (!cn) { toast('Yeni qovluğun adını yazın'); return; }
        const ex = A.CATS.find((c) => A.fold(c.name) === A.fold(cn));
        if (ex) cat = ex.id; else { const c = { id: 'cc_' + uid(), name: cn, icon: $('[data-c=icon]', b).value.trim() || '📁', color: COLORS[(C.cats.length + 3) % COLORS.length] }; C.cats.push(c); cat = c.id; }
      }
      const rec = { id: t ? t.id : 'ct_' + uid(), name, cat, icon: v.icon || '📄', ret: $('[data-t=ret]', b).value === '' ? 5 : +$('[data-t=ret]', b).value, kw: kwI.value.trim(), monthly: $('[data-t=monthly]', b).checked };
      const i = C.types.findIndex((x) => x.id === rec.id); if (i >= 0) C.types[i] = rec; else C.types.push(rec);
      const mon = new Set(S().monthly || []); if (rec.monthly) mon.add(rec.id); else mon.delete(rec.id); S().monthly = [...mon];
      A.registerCustom(C);
      // qovluq dəyişibsə — bu növdəki sənədlər də yeni qovluğa keçir
      for (const d of st.docs) if (d.type === rec.id && d.cat !== rec.cat) { d.cat = rec.cat; await DB.put('docs', d); }
      await saveMeta(); closeModal2(); res(rec.id);
    };
  });
}
function customTypesHtml() {
  const ts = A.TYPES.filter((t) => t.custom), cs = A.CATS.filter((c) => c.custom);
  if (!ts.length && !cs.length) return '<div class="empty" style="padding:14px">Hələ öz növünüz yoxdur. «➕ Yeni növ» basın və ya sənəd yükləyəndə «Sənədin növü» siyahısının sonunda «➕ Yeni növ yarat…» seçin.</div>';
  return `<div style="max-height:260px;overflow:auto"><table class="simple">${ts.map((t) => { const n = live().filter((d) => d.type === t.id).length; return `<tr><td>${t.icon} <b>${esc(t.name)}</b><div class="small muted">${esc(catOf(t.cat).icon + ' ' + catOf(t.cat).name)}${t.kw ? ' · açar sözlər: ' + esc(t.kw) : ''}</div></td><td class="small muted" style="white-space:nowrap">${n} sənəd</td><td style="white-space:nowrap"><button class="btn ghost sm" data-ted="${t.id}" title="Redaktə">✏️</button> <button class="btn ghost sm" data-tdel="${t.id}" title="Sil">🗑</button></td></tr>`; }).join('')}</table></div>
    ${cs.length ? `<div class="small muted" style="margin-top:8px">Öz qovluqlarım: ${cs.map((c) => `<span class="pill">${c.icon} ${esc(c.name)} <a href="#" data-cdel="${c.id}" title="Qovluğu sil">✕</a></span>`).join(' ')}</div>` : ''}`;
}
function bindCustomTypes(app) {
  const C = st.meta.custom;
  const re = () => viewSettings(app);
  const nt = $('[data-nt]', app); if (nt) nt.onclick = () => newTypeDialog().then((id) => { if (id) { toast('✅ Yeni növ yaradıldı: ' + typeName(id)); re(); } });
  $$('[data-ted]', app).forEach((b) => (b.onclick = () => newTypeDialog(C.types.find((x) => x.id === b.dataset.ted)).then((id) => id && re())));
  $$('[data-tdel]', app).forEach((b) => (b.onclick = async () => {
    const id = b.dataset.tdel, docs = st.docs.filter((d) => d.type === id);
    if (!(await confirmBox(`«${esc(typeName(id))}» növü silinsin?${docs.length ? `<br><br>Bu növdə <b>${docs.length}</b> sənəd var — onlar silinməyəcək, «Digər sənəd» növünə keçəcək.` : ''}`, 'Sil', true))) { re(); return; }
    for (const d of docs) { d.type = 'diger'; d.cat = 'diger'; await saveDoc(d, ['Növ dəyişdi', 'öz növ silindi → Digər sənəd']); }
    C.types = C.types.filter((x) => x.id !== id); st.meta.learn = (st.meta.learn || []).filter((r) => r.type !== id);
    S().monthly = (S().monthly || []).filter((x) => x !== id); delete S().retention[id];
    A.registerCustom(C); await saveMeta(); re();
  }));
  $$('[data-cdel]', app).forEach((a) => (a.onclick = async (e) => {
    e.preventDefault(); const id = a.dataset.cdel;
    if (C.types.some((t) => t.cat === id)) { toast('Əvvəlcə bu qovluqdakı növləri silin və ya başqa qovluğa keçirin'); return; }
    for (const d of st.docs.filter((x) => x.cat === id)) { d.cat = (TYPE[d.type] || TYPE.diger).cat; await DB.put('docs', d); }
    C.cats = C.cats.filter((c) => c.id !== id); A.registerCustom(C); await saveMeta(); re();
  }));
}

// ================================================================== bir neçə şirkətli sənəd — şirkət seçimi
function findSubjectFor(p) {
  const k = p.name ? A.nameKey(p.name) : '';
  return st.subjects.find((s) => (p.voen && s.voen === p.voen) || (k && k.length >= 2 && [s.name, s.short, ...(s.aliases || [])].some((n) => n && A.nameKey(n) === k)));
}
/** sənəddə tapılan bütün şirkət / şəxslər (arxivdəki subyektlərlə birləşdirilmiş) */
function companyCands(q) {
  if (!q || !q.res) return [];
  const out = [];
  const add = (c) => {
    const o = out.find((x) => (c.subj && x.subj === c.subj) || (c.voen && x.voen === c.voen) || (c.key && x.key === c.key));
    if (o) { if (!o.voen && c.voen) o.voen = c.voen; if (!o.subj && c.subj) Object.assign(o, { subj: c.subj, name: c.name, kind: c.kind }); return; }
    out.push(c);
  };
  for (const m of q.res.matches || []) { const s = subjById(m.id); if (s) add({ subj: s.id, name: s.name, voen: s.voen || '', kind: s.kind, key: A.nameKey(s.name) }); }
  for (const p of q.res.parties || []) {
    if (!p.name && !p.voen) continue;
    const s = findSubjectFor(p);
    add(s ? { subj: s.id, name: s.name, voen: s.voen || p.voen || '', kind: s.kind, key: A.nameKey(s.name) }
      : { subj: '', name: p.name || 'VÖEN ' + p.voen, voen: p.voen || '', kind: p.kind || (p.voen && p.voen.endsWith('2') ? 'physical' : 'legal'), key: p.name ? A.nameKey(p.name) : '' });
  }
  return out.slice(0, 10);
}
const coSel = (c, f) => (c.subj ? f.subj === c.subj : f.subj === '__new' && ((c.key && A.nameKey(f.newSubj.name) === c.key) || (c.voen && f.newSubj.voen === c.voen)));
function coChooserHtml(q) {
  const cs = companyCands(q); if (!cs.length || (cs.length < 2 && q.res && (q.res.ownerScore >= 100 || (q.form.subj && coSel(cs[0], q.form))))) return '';
  const f = q.form;
  return `<div class="cochoose ${q.picked ? 'picked' : ''}">
    <div class="ch">🏢 Sənəddə <b>${cs.length}</b> şirkət / şəxs tapıldı — <b>bu sənəd hansı şirkətə aiddir?</b>${q.picked ? '' : ' <em class="needpick">seçin</em>'}</div>
    <div class="cogrid">${cs.map((c, i) => `<button type="button" class="co ${coSel(c, f) ? 'on' : ''}" data-co="${i}"><span class="ci">${c.kind === 'physical' ? '👤' : '🏢'}</span><span class="ct"><b>${esc(c.name)}</b><small>${c.voen ? 'VÖEN ' + c.voen + ' · ' : ''}${c.subj ? '✓ arxivdə var' : '➕ yeni subyekt olacaq'}</small></span></button>`).join('')}
      <button type="button" class="co other" data-coother><span class="ci">…</span><span class="ct"><b>Başqa şirkət</b><small>aşağıdakı siyahıdan seçin</small></span></button></div>
    <div class="small muted" style="margin-top:6px">Seçdiyiniz şirkət sənədin sahibi olur, qarşı tərəf avtomatik «Kontragent» yazılır, istiqamət (daxil olan / çıxan) yenidən hesablanır.</div></div>`;
}
function pickCompany(q, c) {
  if (!c) return; const f = q.form;
  q.touched = true; q.picked = true;
  let so;
  if (c.subj) { f.subj = c.subj; so = subjById(c.subj); }
  else { f.subj = '__new'; f.newSubj = { kind: c.kind || 'legal', name: c.name, voen: c.voen || '', fin: '' }; so = { id: '__pick', kind: c.kind, name: c.name, voen: c.voen || '', aliases: [] }; }
  const r2 = so ? A.analyze(q.text, q.name, [so], st.meta.learn) : null;
  if (r2 && r2.owner) f.direction = r2.direction;
  const others = companyCands(q).filter((x) => !(x.name === c.name && x.voen === c.voen));
  let cp = r2 && r2.owner && r2.counterparty && (r2.counterparty.name || r2.counterparty.voen) ? r2.counterparty : null;
  if (cp && ((cp.voen && cp.voen === c.voen) || (cp.name && A.nameKey(cp.name) === c.key))) cp = null;
  if (!cp && others[0]) cp = { name: others[0].name, voen: others[0].voen };
  if (cp) { f.cpName = cp.name || ''; f.cpVoen = cp.voen || ''; }
  if (f.titleAuto) f.title = autoTitle(f);
  renderQueue(true);
  // v1.23: şirkəti seçən kimi sənəd dərhal arxivə göndərilir (Ayarlar → «Şirkəti seçəndə dərhal göndər»)
  if (S().pickSend !== false && q.status === 'ready' && !q.dupOf) setTimeout(() => { if (st.queue[st.qi] === q) sendCurrent(); else commit(q).then(() => renderQueue(true)).catch((e) => toast('Xəta: ' + e.message)); }, 350);
}

// ================================================================== yükləmə pəncərəsindən gələn fayllar
let draining = false;
async function drainInbox() {
  if (draining || !INBOX) return; draining = true;
  try {
    const items = await INBOX.take();
    for (const it of items) handleFiles([new File([it.blob], it.name, { type: it.type || mimeOf(it.name) })], { auto: true, src: it.src || '' });
  } catch (e) { toast('Gələn fayl oxunmadı: ' + (e.message || e)); }
  draining = false;
}
function helperStatus() { return new Promise((res) => { try { chrome.runtime.sendMessage({ type: 'AMMO_HELPER_STATUS' }, (r) => res(!chrome.runtime.lastError && !!(r && r.alive))); } catch (e) { res(false); } }); }
const WATCH_DEF = { enabled: true, helper: false, exts: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'odt', 'ods', 'rtf', 'adoc', 'edoc', 'asice'] };
async function bindWatch(app) {
  const get = async () => ({ ...WATCH_DEF, ...((await chrome.storage.local.get('ammo_dd_watch')).ammo_dd_watch || {}) });
  const w = await get();
  const en = $('[data-w=enabled]', app), ex = $('[data-w=exts]', app);
  if (!en) return;
  en.checked = w.enabled; ex.value = w.exts.join(', ');
  const hst = $('[data-hst]', app);
  const chk = () => helperStatus().then((ok) => { if (!hst.isConnected) return; hst.className = 'pill ' + (ok ? 'ok' : 'warn'); hst.textContent = ok ? '🟢 köməkçi işləyir' : '🔴 quraşdırılmayıb / işləmir'; });
  chk(); $('[data-hchk]', app).onclick = chk;
  const save = async () => {
    const v = { enabled: en.checked, exts: ex.value.split(/[\s,;]+/).map((x) => x.replace(/^\./, '').toLowerCase()).filter(Boolean) };
    if (!v.exts.length) v.exts = WATCH_DEF.exts;
    await chrome.storage.local.set({ ammo_dd_watch: v }); toast('Yadda saxlanıldı');
  };
  en.onchange = save; ex.onchange = save;
  const fa = $('[data-fa]', app);
  chrome.extension.isAllowedFileSchemeAccess().then((ok) => {
    if (!fa) return;
    fa.innerHTML = ok ? '✅ Fayllara giriş icazəsi var — yüklənən fayl birbaşa diskdən götürülür.'
      : '⚠️ Bir dəfəlik ayar: genişlənmənin səhifəsində <b>«Fayl URL-lərinə girişə icazə verin»</b> (Allow access to file URLs) açarını yandırın — onda istənilən yüklənmiş fayl avtomatik götürülür. <button class="btn soft sm" data-openext>Ayarı aç</button>';
    const b = $('[data-openext]', fa); if (b) b.onclick = () => chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id });
  });
  $('[data-helper]', app).onclick = async () => {
    if (!HELPER) { toast('Köməkçi modulu tapılmadı'); return; }
    const w2 = await get();
    let icon = null; try { icon = new Uint8Array(await (await fetch(chrome.runtime.getURL('assets/icon48.png'))).arrayBuffer()); } catch (e) { /* */ }
    saveBlob(new Blob([X.zip(HELPER.build(w2.exts, icon))], { type: 'application/zip' }), 'AMMO_Windows_komekci.zip');
    toast('ZIP-i açın və «QURASDIR.cmd» faylına iki dəfə basın — 1 dəqiqəlik işdir.', 9000);
  };
}

// ================================================================== naviqasiya
function go(view, opts = {}) {
  st.view = view; st.sel.clear(); st.limit = 100;
  if (opts.filter) st.f = { ...defFilter(), ...opts.filter };
  $$('#topnav button').forEach((b) => b.classList.toggle('on', b.dataset.view === view));
  render(); window.scrollTo(0, 0);
}
function render() {
  const app = $('#app');
  ({ home: viewHome, arxiv: viewArxiv, subjects: viewSubjects, sends: viewSends, trash: viewTrash, settings: viewSettings }[st.view] || viewHome)(app);
  counts();
}

// ================================================================== İdarə paneli
function viewHome(app) {
  const L = live(), m = today().slice(0, 7);
  const exp = expiring();
  const month = L.filter((d) => String(d.createdAt).slice(0, 7) === m).length;
  const byCat = A.CATS.map((c) => ({ c, n: L.filter((d) => d.cat === c.id).length })).filter((x) => x.n);
  const max = Math.max(1, ...byCat.map((x) => x.n));
  const recent = L.slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 8);
  const low = L.filter((d) => (d.conf < 0.55 && d.auto && d.auto.by === 'auto') || !d.subj).slice(0, 6);
  if (!st.mx.subj || !subjById(st.mx.subj)) st.mx.subj = (st.subjects[0] || {}).id || '';
  app.innerHTML = `
  <div class="hero">
    <div class="drop" id="drop">
      <h1>Sənədi bura atın — qalanını AMMO edəcək</h1>
      <p>PDF, Word, Excel, şəkil və ya skan. Sənəd oxunur, <b>növü</b> (hesab-faktura, akt, müqavilə, əmr, tabel…), <b>sahibi</b> (hüquqi və ya fiziki şəxs — VÖEN/FİN/ad üzrə), kontragent, nömrə, tarix və məbləğ özü təyin olunur. Siz yalnız <b>«Göndər»</b> düyməsini basırsınız.</p>
      <button class="btn gold lg" id="dropBtn">📥 Fayl seçin</button>
      <div class="steps"><span>1 · Yüklə</span><span>2 · Avtomatik analiz</span><span>3 · «Göndərilsin?» → Göndər</span><span>4 · Qovluğa düşür</span><span>5 · Axtar · Göndər · Paylaş</span></div>
      <div class="fmt">Bir neçə faylı və ya ZIP arxivini birdən ata bilərsiniz. Ctrl+V ilə ekran görüntüsünü də yapışdırmaq olar.</div>
    </div>
    <div class="kpis">
      <div class="kpi" data-go="arxiv"><b>${L.length}</b><span>sənəd arxivdə</span></div>
      <div class="kpi" data-go="month"><b>${month}</b><span>bu ay əlavə edilib</span></div>
      <div class="kpi" data-go="subjects"><b>${st.subjects.length}</b><span>subyekt · ${st.subjects.filter((s) => s.kind !== 'physical').length} hüquqi, ${st.subjects.filter((s) => s.kind === 'physical').length} fiziki</span></div>
      <div class="kpi ${exp.length ? 'warn' : ''}" data-go="expiry"><b>${exp.length}</b><span>müddəti bitən / bitmək üzrə (${S().expiryDays} gün)</span></div>
    </div>
  </div>
  <div class="hbanner hidden" id="hbanner"><span style="font-size:22px">📥</span><div><b>İstənilən brauzerdən və proqramdan yüklənən sənədlər</b><br><span class="small">Opera, Firefox, Edge, WhatsApp, Telegram… — yükləyən kimi «Sənəd dövriyyəsinə göndərilsin? Bəli / Xeyr». Bunun üçün Windows köməkçisini bir dəfə quraşdırın.</span></div><button class="btn dark sm" id="hbGet">⬇️ Köməkçini yüklə</button><button class="btn ghost sm" id="hbX" title="Gizlət">✕</button></div>
  <div class="grid2">
    <div class="card"><h3>🗂️ Qovluqlar (kateqoriyalar)</h3>
      ${byCat.length ? `<div class="catbars">${byCat.map(({ c, n }) => `<div class="catbar" data-cat="${c.id}"><span>${c.icon} ${esc(c.name)}</span><div class="tr"><i style="width:${(n / max) * 100}%;background:${c.color}"></i></div><em>${n}</em></div>`).join('')}</div>` : '<div class="empty">Hələ sənəd yoxdur — ilk sənədi yuxarıdakı sahəyə atın.</div>'}
    </div>
    <div class="card"><h3>🕘 Son əlavə edilənlər <a class="sp small" href="#" data-go="arxiv">hamısı →</a></h3>
      <div class="mini">${recent.map((d) => miniItem(d)).join('') || '<div class="empty">—</div>'}</div>
    </div>
  </div>
  <div class="grid2" style="margin-top:16px">
    <div class="card"><h3>✅ Komplektlik nəzarəti <span class="sp" style="display:flex;gap:6px"><select id="mxSubj" style="width:220px">${st.subjects.length ? subjOptions(st.mx.subj) : '<option value="">Subyekt yoxdur</option>'}</select><select id="mxYear" style="width:90px">${[0, 1, 2, 3].map((k) => { const y = new Date().getFullYear() - k; return `<option ${y === +st.mx.year ? 'selected' : ''}>${y}</option>`; }).join('')}</select></span></h3>
      <div id="matrix"></div>
      <div class="small muted" style="margin-top:6px">Hər ay üçün gözlənilən sənədlər (Ayarlar-da dəyişə bilərsiniz). Qırmızı xana — sənəd hələ yüklənməyib; xanaya basın.</div>
    </div>
    <div class="card"><h3>🔔 Diqqət tələb edir</h3>
      ${exp.length ? `<div class="small muted" style="margin:0 0 4px">Müddəti bitən müqavilə, etibarnamə, lisenziya:</div><div class="mini">${exp.slice(0, 6).map((d) => miniItem(d, `<span class="pill ${d.expiry < today() ? 'bad' : 'warn'}">${d.expiry < today() ? 'bitib' : 'bitir'} ${fmtDate(d.expiry)}</span>`)).join('')}</div>` : ''}
      ${low.length ? `<div class="small muted" style="margin:10px 0 4px">Yoxlanmalı (aşağı inam və ya sahibi təyin olunmayıb):</div><div class="mini">${low.map((d) => miniItem(d, `<span class="pill warn">${Math.round((d.conf || 0) * 100)}%</span>`)).join('')}</div>` : ''}
      ${!exp.length && !low.length ? '<div class="empty">Hər şey qaydasındadır 👌</div>' : ''}
    </div>
  </div>`;
  (async () => {
    let hid = false; try { hid = localStorage.getItem('ammo_hb_hide') === '1'; } catch (e) { /* */ }
    if (hid || (await helperStatus())) return;
    const hb = $('#hbanner'); if (!hb) return; hb.classList.remove('hidden');
    $('#hbGet').onclick = async () => { const w = { ...WATCH_DEF, ...((await chrome.storage.local.get('ammo_dd_watch')).ammo_dd_watch || {}) }; let icon = null; try { icon = new Uint8Array(await (await fetch(chrome.runtime.getURL('assets/icon48.png'))).arrayBuffer()); } catch (e) { /* */ } saveBlob(new Blob([X.zip(HELPER.build(w.exts, icon))], { type: 'application/zip' }), 'AMMO_Windows_komekci.zip'); toast('ZIP-i açın və «QURASDIR.cmd» faylına iki dəfə basın.', 9000); };
    $('#hbX').onclick = () => { hb.remove(); try { localStorage.setItem('ammo_hb_hide', '1'); } catch (e) { /* */ } };
  })();
  const drop = $('#drop');
  drop.onclick = (e) => { if (e.target.closest('button') || e.target === drop || e.target.closest('h1,p,.steps,.fmt')) $('#fileInp').click(); };
  drop.ondragover = (e) => { e.preventDefault(); drop.classList.add('over'); };
  drop.ondragleave = () => drop.classList.remove('over');
  $$('[data-go]', app).forEach((el) => (el.onclick = (e) => {
    e.preventDefault(); const g = el.dataset.go;
    if (g === 'month') { const d = new Date(); go('arxiv', { filter: { from: ymdOf(new Date(d.getFullYear(), d.getMonth(), 1)), to: today(), basis: 'created', preset: 'month' } }); }
    else if (g === 'expiry') go('arxiv', { filter: { expiry: true } });
    else go(g);
  }));
  $$('[data-cat]', app).forEach((el) => (el.onclick = () => go('arxiv', { filter: { cat: el.dataset.cat } })));
  bindMini(app);
  const ms = $('#mxSubj'), my = $('#mxYear');
  ms.onchange = () => { st.mx.subj = ms.value; drawMatrix(); }; my.onchange = () => { st.mx.year = +my.value; drawMatrix(); };
  drawMatrix();
}
function miniItem(d, right) {
  return `<div class="it" data-doc="${d.id}"><span class="ic">${typeIcon(d.type)}</span><div style="min-width:0"><b>${esc(d.title)}</b><small>${esc(subjName(d.subj))} · ${fmtDate(d.date) || fmtDate(d.createdAt)} · ${esc(d.regNo)}</small></div>${right || `<span class="pill ${d.direction}">${DIR[d.direction] ? DIR[d.direction].name : ''}</span>`}</div>`;
}
function bindMini(el) { $$('[data-doc]', el).forEach((x) => (x.onclick = () => openDoc(x.dataset.doc))); }
function drawMatrix() {
  const box = $('#matrix'); if (!box) return;
  const subj = st.mx.subj, y = +st.mx.year;
  if (!subj) { box.innerHTML = '<div class="empty">Əvvəlcə subyekt əlavə edin (və ya sənəd yükləyin — subyekt avtomatik yaranır).</div>'; return; }
  const types = (S().monthly || []).filter((t) => TYPE[t]);
  if (!types.length) { box.innerHTML = '<div class="empty">Ayarlar-da aylıq sənəd növlərini seçin.</div>'; return; }
  const docs = live().filter((d) => d.subj === subj);
  const nowP = today().slice(0, 7);
  box.innerHTML = `<table class="matrix"><tr><th></th>${MONTHS_AZ.map((m) => `<th>${m.slice(0, 3)}</th>`).join('')}</tr>${types.map((t) => `<tr><td class="lbl">${typeIcon(t)} ${esc(typeName(t))}</td>${MONTHS_AZ.map((m, i) => {
    const p = `${y}-${pad(i + 1)}`; const n = docs.filter((d) => d.type === t && (d.period || (d.date || '').slice(0, 7)) === p).length;
    const fut = p > nowP; return `<td class="${n ? 'y' : fut ? 'f' : 'n'}" data-t="${t}" data-p="${p}" title="${esc(typeName(t))} · ${MONTHS_AZ[i]} ${y}: ${n ? n + ' sənəd' : 'yoxdur'}">${n ? (n > 1 ? n : '✓') : fut ? '·' : '✕'}</td>`;
  }).join('')}</tr>`).join('')}</table>`;
  $$('td[data-p]', box).forEach((td) => (td.onclick = () => {
    if (td.classList.contains('f')) return;
    if (td.classList.contains('y')) { go('arxiv', { filter: { subj, type: td.dataset.t, period: td.dataset.p, from: '', to: '' } }); return; }
    toast(`${typeName(td.dataset.t)} (${periodTxt(td.dataset.p)}) yoxdur — faylı seçin, AMMO özü yerləşdirəcək`); $('#fileInp').click();
  }));
}

// ================================================================== Arxiv: qovluqlar + axtarış
function presetRange(k) {
  const d = new Date(), y = d.getFullYear(), m = d.getMonth();
  switch (k) {
    case 'today': return [today(), today()];
    case 'week': { const s = new Date(d); s.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return [ymdOf(s), today()]; }
    case 'month': return [ymdOf(new Date(y, m, 1)), ymdOf(new Date(y, m + 1, 0))];
    case 'prev': return [ymdOf(new Date(y, m - 1, 1)), ymdOf(new Date(y, m, 0))];
    case 'quarter': { const q = Math.floor(m / 3) * 3; return [ymdOf(new Date(y, q, 1)), ymdOf(new Date(y, q + 3, 0))]; }
    case 'year': return [`${y}-01-01`, `${y}-12-31`];
    case 'lastyear': return [`${y - 1}-01-01`, `${y - 1}-12-31`];
    default: return ['', ''];
  }
}
const PRESETS = [['today', 'Bu gün'], ['week', 'Bu həftə'], ['month', 'Bu ay'], ['prev', 'Keçən ay'], ['quarter', 'Bu rüb'], ['year', 'Bu il'], ['lastyear', 'Keçən il'], ['', 'Bütün dövr']];
const foldKeep = (t) => A.fold(String(t || '').replace(/[ \t]/g, ' '));
async function ensureTexts() {
  if (st.textCache) return;
  const all = await DB.all('texts');
  st.textCache = new Map(all.map((t) => [t.id, foldKeep(t.text)]));
  st.rawText = new Map(all.map((t) => [t.id, t.text]));
}
function metaText(d) { const s = subjById(d.subj); return A.fold([d.title, d.number, d.regNo, d.cp && d.cp.name, d.cp && d.cp.voen, d.person, s && s.name, s && s.voen, s && s.fin, d.note, (d.tags || []).join(' '), typeName(d.type), (d.files || []).map((x) => x.name).join(' '), fmtDate(d.date), periodTxt(d.period), d.amount != null ? String(d.amount) : ''].join(' ')); }
function filtered() {
  const f = st.f, words = A.fold(f.q.trim()).split(/\s+/).filter(Boolean);
  const lim = new Date(); lim.setDate(lim.getDate() + (+S().expiryDays || 30)); const limY = ymdOf(lim);
  const cpq = A.fold(f.cp.trim()), pq = A.fold(f.person.trim()), tq = A.fold(f.tag.trim());
  const out = live().filter((d) => {
    if (f.subj && (f.subj === '__none' ? d.subj : d.subj !== f.subj)) return false;
    if (f.cat && d.cat !== f.cat) return false;
    if (f.type && d.type !== f.type) return false;
    if (f.dir && d.direction !== f.dir) return false;
    if (f.status && d.status !== f.status) return false;
    if (f.fav && !d.fav) return false;
    if (f.expiry && !(d.expiry && d.expiry <= limY && d.status !== 'Arxivdə')) return false;
    if (f.period && (d.period || (d.date || '').slice(0, 7)) !== f.period) return false;
    const v = f.basis === 'created' ? String(d.createdAt).slice(0, 10) : (d.date || String(d.createdAt).slice(0, 10));
    if (f.from && v < f.from) return false; if (f.to && v > f.to) return false;
    if (cpq && !A.fold(`${d.cp && d.cp.name} ${d.cp && d.cp.voen}`).includes(cpq)) return false;
    if (pq && !A.fold(d.person).includes(pq)) return false;
    if (f.amin !== '' && !(d.amount >= +f.amin)) return false;
    if (f.amax !== '' && !(d.amount <= +f.amax)) return false;
    if (tq && !(d.tags || []).some((t) => A.fold(t).includes(tq))) return false;
    d._hit = '';
    if (words.length) {
      const meta = metaText(d), txt = st.textCache ? st.textCache.get(d.id) || '' : '';
      for (const w of words) { if (meta.includes(w)) continue; if (txt.includes(w)) { if (!d._hit) d._hit = w; continue; } return false; }
    }
    return true;
  });
  const k = st.sort.k, dir = st.sort.asc ? 1 : -1;
  const val = (d) => k === 'amount' ? (d.amount || 0) : k === 'subj' ? subjName(d.subj) : k === 'type' ? typeName(d.type) : k === 'title' ? d.title : k === 'reg' ? d.regNo : k === 'created' ? d.createdAt : (d.date || String(d.createdAt).slice(0, 10));
  return out.sort((a, b) => { const x = val(a), y = val(b); return (typeof x === 'number' ? x - y : String(x).localeCompare(String(y), 'az')) * dir; });
}
function snippet(d) {
  if (!d._hit || !st.rawText) return '';
  const ft = st.textCache.get(d.id) || '', raw = st.rawText.get(d.id) || '', i = ft.indexOf(d._hit); if (i < 0) return '';
  const a = Math.max(0, i - 60), b = Math.min(raw.length, i + d._hit.length + 80);
  return `<div class="snip">…${esc(raw.slice(a, i)).replace(/\s+/g, ' ')}<mark>${esc(raw.slice(i, i + d._hit.length))}</mark>${esc(raw.slice(i + d._hit.length, b)).replace(/\s+/g, ' ')}…</div>`;
}
function treeHtml() {
  const L = live(), f = st.f;
  const node = (attrs, tw, icon, label, n, on) => `<div class="node ${on ? 'on' : ''}" ${attrs}><span class="tw">${tw}</span><span>${icon}</span><span class="nm" title="${esc(label)}">${esc(label)}</span><span class="c">${n}</span></div>`;
  const noFilter = !f.subj && !f.cat && !f.type && !f.dir && !f.fav && !f.expiry;
  let h = node('data-t="all"', '', '📚', 'Bütün sənədlər', L.length, noFilter);
  h += node('data-t="fav"', '', '⭐', 'Seçilmişlər', L.filter((d) => d.fav).length, f.fav);
  h += node('data-t="exp"', '', '⏰', 'Müddəti bitənlər', expiring().length, f.expiry);
  h += '<div class="tl">Jurnallar</div>';
  for (const [k, v] of Object.entries(DIR)) h += node(`data-t="dir" data-v="${k}"`, '', v.icon, v.name + ' sənədlər', L.filter((d) => d.direction === k).length, f.dir === k && !f.subj);
  h += `<div class="tl">Subyektlər · qovluqlar</div>`;
  const subs = st.subjects.slice().sort((a, b) => a.name.localeCompare(b.name, 'az'));
  for (const s of subs) {
    const D = L.filter((d) => d.subj === s.id); const open = st.open.has(s.id);
    h += node(`data-t="subj" data-v="${s.id}"`, D.length ? (open ? '▾' : '▸') : '', subjIcon(s), s.name, D.length, f.subj === s.id && !f.cat);
    if (open && D.length) {
      h += '<div class="kids">';
      for (const c of A.CATS) {
        const C = D.filter((d) => d.cat === c.id); if (!C.length) continue; const ok = st.open.has(s.id + '/' + c.id);
        h += node(`data-t="cat" data-s="${s.id}" data-v="${c.id}"`, ok ? '▾' : '▸', c.icon, c.name, C.length, f.subj === s.id && f.cat === c.id && !f.type);
        if (ok) {
          h += '<div class="kids">';
          for (const t of A.TYPES.filter((x) => x.cat === c.id)) { const n = C.filter((d) => d.type === t.id).length; if (n) h += node(`data-t="type" data-s="${s.id}" data-c="${c.id}" data-v="${t.id}"`, '', t.icon, t.name, n, f.subj === s.id && f.type === t.id); }
          h += '</div>';
        }
      }
      h += '</div>';
    }
  }
  const none = L.filter((d) => !d.subj).length;
  if (none) h += node('data-t="subj" data-v="__none"', '', '❔', 'Sahibi təyin olunmayıb', none, f.subj === '__none');
  if (!subs.length) h += '<div class="small muted" style="padding:6px 8px">Subyekt yoxdur. Sənəd yüklədikdə avtomatik yaranır və ya «Subyektlər» bölməsindən əlavə edin.</div>';
  return h;
}
function viewArxiv(app) {
  const f = st.f;
  app.innerHTML = `<div class="layout">
    <div class="card tree" id="tree">${treeHtml()}</div>
    <div>
      <div class="card">
        <div class="filters">
          <label class="f" style="grid-column:span 2">Axtarış (ad, VÖEN, nömrə, mətnin içi)<input data-f="q" value="${esc(f.q)}" placeholder="məs. Beta Trade, 1402345671, sentyabr tabel"></label>
          <label class="f">Tarixdən<input type="date" data-f="from" value="${f.from}"></label>
          <label class="f">Tarixədək<input type="date" data-f="to" value="${f.to}"></label>
          <label class="f">Tarix üzrə<select data-f="basis"><option value="date" ${f.basis === 'date' ? 'selected' : ''}>Sənədin tarixi</option><option value="created" ${f.basis === 'created' ? 'selected' : ''}>Qeydiyyat (yüklənmə) tarixi</option></select></label>
          <label class="f">Subyekt<select data-f="subj">${subjOptions(f.subj, `<option value="">Hamısı</option><option value="__none" ${f.subj === '__none' ? 'selected' : ''}>❔ Təyin olunmayıb</option>`)}</select></label>
          <label class="f">Kateqoriya<select data-f="cat"><option value="">Hamısı</option>${A.CATS.map((c) => `<option value="${c.id}" ${f.cat === c.id ? 'selected' : ''}>${c.icon} ${esc(c.name)}</option>`).join('')}</select></label>
          <label class="f">Növ<select data-f="type"><option value="">Hamısı</option>${typeOptions(f.type)}</select></label>
        </div>
        <details ${f.dir || f.status || f.cp || f.person || f.amin || f.amax || f.tag ? 'open' : ''} style="margin-top:8px"><summary class="small" style="cursor:pointer;color:var(--acc);font-weight:600">Ətraflı filtrlər</summary>
          <div class="filters" style="margin-top:8px">
            <label class="f">İstiqamət<select data-f="dir"><option value="">Hamısı</option>${dirOptions(f.dir)}</select></label>
            <label class="f">Status<select data-f="status"><option value="">Hamısı</option>${statusOptions(f.status)}</select></label>
            <label class="f">Kontragent / VÖEN<input data-f="cp" value="${esc(f.cp)}"></label>
            <label class="f">Əməkdaş<input data-f="person" value="${esc(f.person)}"></label>
            <label class="f">Məbləğ (min)<input data-f="amin" value="${esc(f.amin)}" inputmode="decimal"></label>
            <label class="f">Məbləğ (max)<input data-f="amax" value="${esc(f.amax)}" inputmode="decimal"></label>
            <label class="f">Teq<input data-f="tag" value="${esc(f.tag)}"></label>
          </div></details>
        <div class="presets">${PRESETS.map(([k, l]) => `<button data-pre="${k}" class="${f.preset === k && (k || f.from) ? 'on' : ''}">${l}</button>`).join('')}<button data-clear style="margin-left:auto">✕ Filtrləri təmizlə</button></div>
      </div>
      <div id="res"></div>
    </div></div>`;
  $$('#tree [data-t]').forEach((n) => (n.onclick = () => {
    const t = n.dataset.t, v = n.dataset.v; const keep = { q: f.q, from: f.from, to: f.to, basis: f.basis, preset: f.preset };
    if (t === 'all') st.f = { ...defFilter(), ...keep };
    else if (t === 'fav') st.f = { ...defFilter(), ...keep, fav: true };
    else if (t === 'exp') st.f = { ...defFilter(), ...keep, expiry: true };
    else if (t === 'dir') st.f = { ...defFilter(), ...keep, dir: v };
    else if (t === 'subj') { if (st.f.subj === v && !st.f.cat) { if (st.open.has(v)) st.open.delete(v); else st.open.add(v); } else st.open.add(v); st.f = { ...defFilter(), ...keep, subj: v }; }
    else if (t === 'cat') { const k = n.dataset.s + '/' + v; if (st.f.cat === v && st.f.subj === n.dataset.s && !st.f.type && st.open.has(k)) st.open.delete(k); else st.open.add(k); st.f = { ...defFilter(), ...keep, subj: n.dataset.s, cat: v }; }
    else if (t === 'type') st.f = { ...defFilter(), ...keep, subj: n.dataset.s, cat: n.dataset.c, type: v };
    st.sel.clear(); st.limit = 100; viewArxiv(app);
  }));
  let qt = null;
  $$('[data-f]', app).forEach((el) => {
    const ev = el.tagName === 'SELECT' || el.type === 'date' ? 'change' : 'input';
    el.addEventListener(ev, () => {
      const k = el.dataset.f; st.f[k] = el.value;
      if (k === 'from' || k === 'to') st.f.preset = 'custom';
      if (k === 'subj' && el.value) st.open.add(el.value);
      if (k === 'cat') st.f.type = '';
      if (k === 'type' && el.value) st.f.cat = TYPE[el.value].cat;
      if (['subj', 'cat', 'type', 'basis'].includes(k)) { viewArxiv(app); return; }
      clearTimeout(qt); qt = setTimeout(async () => { if (k === 'q' && st.f.q.trim()) await ensureTexts(); refreshRes(); }, k === 'q' ? 220 : 120);
    });
  });
  $$('[data-pre]', app).forEach((b) => (b.onclick = () => { const [a, z] = presetRange(b.dataset.pre); st.f.from = a; st.f.to = z; st.f.preset = b.dataset.pre; viewArxiv(app); }));
  $('[data-clear]', app).onclick = () => { st.f = defFilter(); viewArxiv(app); };
  if (st.f.q.trim() && !st.textCache) ensureTexts().then(refreshRes); else refreshRes();
}
function crumbs() {
  const f = st.f, parts = [];
  if (f.subj) parts.push(f.subj === '__none' ? '❔ Təyin olunmayıb' : `${subjIcon(subjById(f.subj))} ${subjName(f.subj)}`);
  if (f.cat) parts.push(`${catOf(f.cat).icon} ${catOf(f.cat).name}`);
  if (f.type) parts.push(`${typeIcon(f.type)} ${typeName(f.type)}`);
  if (f.dir) parts.push(`${DIR[f.dir].icon} ${DIR[f.dir].name}`);
  if (f.fav) parts.push('⭐ Seçilmişlər'); if (f.expiry) parts.push('⏰ Müddəti bitənlər');
  if (f.period) parts.push('🗓️ ' + periodTxt(f.period));
  if (f.from || f.to) parts.push(`📅 ${fmtDate(f.from) || '…'} – ${fmtDate(f.to) || '…'}`);
  return parts.length ? parts.map((p) => `<b>${esc(p)}</b>`).join('<span class="muted">›</span>') : '<b>📚 Bütün sənədlər</b>';
}
function refreshRes() {
  const box = $('#res'); if (!box) return;
  const L = filtered(); st.lastList = L;
  const sums = {}; L.forEach((d) => { if (d.amount) sums[d.currency || 'AZN'] = (sums[d.currency || 'AZN'] || 0) + d.amount; });
  const sumTxt = Object.entries(sums).map(([c, v]) => `${fmtMoney(v)} ${c}`).join(' · ');
  const shown = L.slice(0, st.limit);
  const th = (k, l) => `<th data-sort="${k}" class="${st.sort.k === k ? 's' + (st.sort.asc ? ' asc' : '') : ''}">${l}</th>`;
  box.innerHTML = `
    <div class="crumbs">📁 ${crumbs()}<span class="muted">· ${L.length} sənəd${sumTxt ? ' · cəmi ' + sumTxt : ''}</span>
      <span class="sp"><div class="seg"><button data-mode="table" class="${st.mode === 'table' ? 'on' : ''}" title="Cədvəl">☰</button><button data-mode="cards" class="${st.mode === 'cards' ? 'on' : ''}" title="Kartlar">▦</button></div>
      <button class="btn ghost sm" data-xls>📊 Reyestr (Excel)</button><button class="btn ghost sm" data-selall>☑ Hamısını seç</button></span></div>
    ${st.sel.size ? `<div class="bulk"><b>${st.sel.size} seçildi</b><button class="btn gold sm" data-b="send">📤 Göndər</button><button class="btn ghost sm" data-b="zip">📦 ZIP yüklə</button><button class="btn ghost sm" data-b="xls">📊 Excel</button>
      <select data-b="status" style="width:auto;padding:4px 8px;background:#27325a;color:#fff;border-color:#3a467a"><option value="">Status dəyiş…</option>${statusOptions('')}</select>
      <select data-b="move" style="width:180px;padding:4px 8px;background:#27325a;color:#fff;border-color:#3a467a">${subjOptions('', '<option value="">Subyektə köçür…</option>')}</select>
      <button class="btn ghost sm" data-b="del">🗑 Səbətə</button><button class="btn ghost sm" data-b="none" style="margin-left:auto">✕</button></div>` : ''}
    ${!L.length ? `<div class="card empty">Heç nə tapılmadı.${live().length ? ' Filtrləri dəyişin.' : ' İlk sənədi yükləyin — «＋ Sənəd yüklə».'}</div>`
      : st.mode === 'cards' ? `<div class="cards">${shown.map((d) => `<div class="dcard ${st.sel.has(d.id) ? 'sel' : ''}" data-id="${d.id}"><input type="checkbox" class="ck" ${st.sel.has(d.id) ? 'checked' : ''}><div class="th" style="${d.thumb ? `background-image:url(${d.thumb})` : ''}">${d.thumb ? '' : typeIcon(d.type)}</div><div class="bd"><b>${esc(d.title)}</b><small>${esc(subjName(d.subj))}<br>${fmtDate(d.date)} · ${esc(d.regNo)}</small></div></div>`).join('')}</div>`
      : `<div class="tblwrap"><table class="list"><thead><tr><th style="width:30px"></th>${th('title', 'Sənəd')}${th('subj', 'Subyekt')}${th('date', 'Tarix')}<th>Kontragent / şəxs</th>${th('amount', 'Məbləğ')}<th>Status</th></tr></thead><tbody>
        ${shown.map((d) => `<tr data-id="${d.id}" class="${st.sel.has(d.id) ? 'sel' : ''}"><td><input type="checkbox" class="ck" ${st.sel.has(d.id) ? 'checked' : ''}></td>
          <td><div class="ttl"><span class="ic">${typeIcon(d.type)}</span><div style="min-width:0"><b>${d.fav ? '⭐ ' : ''}${esc(d.title)}</b><small>${esc(d.regNo)} · ${esc(typeName(d.type))}${d.period ? ' · ' + periodTxt(d.period) : ''} · ${esc((d.files[0] || {}).name || '')}</small>${snippet(d)}</div></div></td>
          <td class="nw">${subjIcon(subjById(d.subj))} ${esc(subjName(d.subj))}</td><td class="nw">${fmtDate(d.date) || '<span class="muted">—</span>'}</td>
          <td>${esc((d.cp && d.cp.name) || d.person || '')}${d.cp && d.cp.voen ? `<div class="small muted">${d.cp.voen}</div>` : ''}</td>
          <td class="num">${d.amount != null ? fmtMoney(d.amount) + ' <span class="muted small">' + esc(d.currency) + '</span>' : ''}</td>
          <td class="nw"><span class="pill ${d.direction}">${DIR[d.direction] ? DIR[d.direction].icon : ''} ${esc(d.status)}</span>${d.expiry ? `<div class="small ${d.expiry < today() ? '' : 'muted'}" style="${d.expiry < today() ? 'color:var(--bad)' : ''}">⏰ ${fmtDate(d.expiry)}</div>` : ''}</td></tr>`).join('')}
      </tbody></table></div>`}
    ${L.length > st.limit ? `<div class="more"><button class="btn ghost" data-more>Daha ${Math.min(100, L.length - st.limit)} sənəd göstər (${L.length - st.limit} qalıb)</button></div>` : ''}`;
  $$('[data-id]', box).forEach((r) => (r.onclick = (e) => {
    const id = r.dataset.id;
    if (e.target.classList.contains('ck') || e.ctrlKey || e.metaKey || e.shiftKey) { if (st.sel.has(id)) st.sel.delete(id); else st.sel.add(id); refreshRes(); return; }
    openDoc(id);
  }));
  $$('[data-sort]', box).forEach((h) => (h.onclick = () => { const k = h.dataset.sort; st.sort = { k, asc: st.sort.k === k ? !st.sort.asc : k === 'title' || k === 'subj' }; refreshRes(); }));
  $$('[data-mode]', box).forEach((b) => (b.onclick = () => { st.mode = b.dataset.mode; refreshRes(); }));
  const more = $('[data-more]', box); if (more) more.onclick = () => { st.limit += 100; refreshRes(); };
  $('[data-xls]', box).onclick = () => exportXlsx(L, 'Reyestr');
  $('[data-selall]', box).onclick = () => { if (st.sel.size === L.length) st.sel.clear(); else L.forEach((d) => st.sel.add(d.id)); refreshRes(); };
  $$('[data-b]', box).forEach((b) => {
    const act = b.dataset.b, ids = [...st.sel];
    if (b.tagName === 'SELECT') { b.onchange = async () => { if (!b.value) return; for (const id of ids) { const d = st.docs.find((x) => x.id === id); if (!d) continue; if (act === 'status') { d.status = b.value; await saveDoc(d, ['Status dəyişdi', b.value]); } else { d.subj = b.value; await saveDoc(d, ['Subyekt dəyişdi', subjName(b.value)]); } } toast(`${ids.length} sənəd yeniləndi`); st.sel.clear(); viewArxiv($('#app')); }; return; }
    b.onclick = async () => {
      if (act === 'none') { st.sel.clear(); refreshRes(); }
      if (act === 'send') sendDialog(ids);
      if (act === 'zip') downloadZip(ids);
      if (act === 'xls') exportXlsx(ids.map((id) => st.docs.find((d) => d.id === id)).filter(Boolean), 'Secilmis');
      if (act === 'del') { if (!(await confirmBox(`${ids.length} sənəd səbətə atılsın? (Səbətdən bərpa etmək olar)`, 'Səbətə at', true))) return; for (const id of ids) { const d = st.docs.find((x) => x.id === id); d.deleted = new Date().toISOString(); await saveDoc(d, ['Səbətə atıldı']); } st.sel.clear(); viewArxiv($('#app')); }
    };
  });
}

// ================================================================== Sənəd kartı (sağ panel)
const safeName = (s) => String(s || '').replace(/[\\/:*?"<>|«»]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 90);
function niceName(d, f) { const e = extOf(f.name); return safeName([d.date || d.period, typeName(d.type), d.number ? '№' + d.number : '', (d.cp && d.cp.name) || d.person].filter(Boolean).join('_')) + (e ? '.' + e : ''); }
function saveBlob(blob, name) { const u = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { a.remove(); URL.revokeObjectURL(u); }, 3000); }
async function fileBlob(f) { const r = await DB.get('files', f.fid); return r ? r.blob : null; }
const lastFile = (d) => d.files[d.files.length - 1];
function openDoc(id) {
  const d = st.docs.find((x) => x.id === id); if (!d) { toast('Sənəd tapılmadı'); return; }
  st.drawer = id; st.editing = false;
  $('#drawer').classList.add('open'); $('#shade').classList.add('open');
  renderDrawer(); loadPreview(d);
}
function closeDrawer() { st.drawer = null; $('#drawer').classList.remove('open'); $('#shade').classList.remove('open'); st.urls.forEach((u) => URL.revokeObjectURL(u)); st.urls = []; }
function retentionTxt(d) {
  const y = retentionOf(d.type); if (!y) return 'Daimi';
  const base = d.expiry || d.date || String(d.createdAt).slice(0, 10); const until = (+base.slice(0, 4) + y) + '-12-31';
  return `${y} il · ${fmtDate(until)}-dək${until < today() ? ' (müddəti keçib — məhv aktı ilə silinə bilər)' : ''}`;
}
function renderDrawer() {
  const d = st.docs.find((x) => x.id === st.drawer); if (!d) return closeDrawer();
  const s = subjById(d.subj), dr = $('#drawer');
  const tabs = [['info', 'Məlumatlar'], ['text', 'Mətn'], ['files', `Fayllar (${d.files.length})`], ['links', `Əlaqəli (${(d.links || []).length})`], ['hist', `Tarixçə (${(d.history || []).length})`]];
  dr.innerHTML = `
    <div class="dh"><span class="ic">${typeIcon(d.type)}</span><div style="min-width:0"><h2>${d.fav ? '⭐ ' : ''}${esc(d.title)}</h2>
      <div class="sub"><span class="pill acc">${esc(d.regNo)}</span><span class="pill ${d.direction}">${DIR[d.direction].icon} ${DIR[d.direction].name}</span><span class="pill">${esc(d.status)}</span><span>${subjIcon(s)} <a href="#" data-subj>${esc(subjName(d.subj))}</a></span><span>· ${catOf(d.cat).icon} ${esc(catOf(d.cat).name)} › ${esc(typeName(d.type))}</span></div></div>
      <button class="x" data-x>✕</button></div>
    <div class="dacts">
      <button class="btn primary sm" data-a="dl">⬇️ Yüklə</button><button class="btn ghost sm" data-a="open">🖨️ Aç / çap et</button>
      <button class="btn gold sm" data-a="send">📤 Göndər</button><button class="btn ghost sm" data-a="copy">📋 Məlumatı kopyala</button>
      <button class="btn ghost sm" data-a="fav">${d.fav ? '★ Seçilmişdən çıxar' : '☆ Seçilmişlərə'}</button>
      <button class="btn ghost sm" data-a="ver">➕ Yeni versiya</button><input type="file" data-verinp hidden>
      <button class="btn danger sm" data-a="del" style="margin-left:auto">🗑 Səbətə</button>
    </div>
    <div class="dbody"><div class="pv" id="pv"><div class="none">Yüklənir…</div></div>
      <div class="dside"><div class="tabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${st.dtab === k ? 'on' : ''}">${l}</button>`).join('')}</div><div id="dtab"></div></div></div>`;
  $('[data-x]', dr).onclick = closeDrawer;
  $('[data-subj]', dr).onclick = (e) => { e.preventDefault(); closeDrawer(); if (d.subj) st.open.add(d.subj); go('arxiv', { filter: { subj: d.subj || '__none' } }); };
  $$('[data-tab]', dr).forEach((b) => (b.onclick = () => { st.dtab = b.dataset.tab; st.editing = false; $$('[data-tab]', dr).forEach((x) => x.classList.toggle('on', x === b)); renderTab(d); }));
  $$('[data-a]', dr).forEach((b) => (b.onclick = () => docAction(d, b.dataset.a)));
  $('[data-verinp]', dr).onchange = (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) addVersion(d, f); };
  renderTab(d);
}
async function docAction(d, a) {
  const f = lastFile(d);
  if (a === 'dl') { const b = await fileBlob(f); if (b) saveBlob(b, niceName(d, f)); }
  if (a === 'open') { const b = await fileBlob(f); if (b) { const u = URL.createObjectURL(new Blob([b], { type: f.mime })); window.open(u, '_blank'); setTimeout(() => URL.revokeObjectURL(u), 60000); } }
  if (a === 'send') sendDialog([d.id]);
  if (a === 'copy') { await navigator.clipboard.writeText(copyText(d)); toast('📋 Məlumat panoya kopyalandı'); }
  if (a === 'fav') { d.fav = !d.fav; await saveDoc(d); renderDrawer(); refreshRes(); }
  if (a === 'ver') $('#drawer [data-verinp]').click();
  if (a === 'del') { if (!(await confirmBox('Sənəd səbətə atılsın? Səbətdən bərpa etmək mümkündür.', 'Səbətə at', true))) return; d.deleted = new Date().toISOString(); await saveDoc(d, ['Səbətə atıldı']); closeDrawer(); render(); toast('Səbətə atıldı'); }
}
function copyText(d) {
  const s = subjById(d.subj);
  return [`${typeName(d.type)}${d.number ? ' № ' + d.number : ''}${d.date ? ' — ' + fmtDate(d.date) : ''}`,
    s ? `Subyekt: ${s.name}${s.voen ? ' (VÖEN ' + s.voen + ')' : ''}` : '', d.cp && d.cp.name ? `Kontragent: ${d.cp.name}${d.cp.voen ? ' (VÖEN ' + d.cp.voen + ')' : ''}` : '',
    d.person ? `Şəxs: ${d.person}` : '', d.period ? `Dövr: ${periodTxt(d.period)}` : '', d.amount != null ? `Məbləğ: ${fmtMoney(d.amount)} ${d.currency}` : '',
    d.expiry ? `Qüvvədədir: ${fmtDate(d.expiry)}-dək` : '', `Qeydiyyat: ${d.regNo}`].filter(Boolean).join('\n');
}
async function loadPreview(d) {
  const pv = $('#pv'); if (!pv) return;
  const f = lastFile(d); const blob = await fileBlob(f);
  if (!blob) { pv.innerHTML = '<div class="none">Fayl tapılmadı</div>'; return; }
  const e = extOf(f.name);
  const url = () => { const u = URL.createObjectURL(new Blob([blob], { type: f.mime })); st.urls.push(u); return u; };
  if (e === 'pdf') pv.innerHTML = `<iframe src="${url()}#view=FitH"></iframe>`;
  else if (IMG_EXT.includes(e) && e !== 'tif' && e !== 'tiff') pv.innerHTML = `<div class="img"><img src="${url()}"></div>`;
  else if (e === 'xlsx') {
    try { const rows = (await XR.read(await blob.arrayBuffer())).slice(0, 300); pv.innerHTML = `<div class="xl"><table>${rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</table></div>`; } catch (er) { pv.innerHTML = '<div class="none">Excel göstərilə bilmədi</div>'; }
  } else {
    const t = await DB.get('texts', d.id);
    pv.innerHTML = t && t.text.trim() ? `<pre>${esc(t.text)}</pre>` : `<div class="none"><div style="font-size:50px">${fileIcon(f.name)}</div>Önizləmə yoxdur.<br><button class="btn soft" style="margin-top:10px" id="pvdl">⬇️ Faylı yüklə</button></div>`;
    const b = $('#pvdl'); if (b) b.onclick = () => saveBlob(blob, niceName(d, f));
  }
}
function kv(k, v, copy) { return v ? `<div class="k">${k}</div><div>${v}</div><div>${copy ? `<button class="cp" data-cp="${esc(copy)}" title="Kopyala">⧉</button>` : ''}</div>` : ''; }
async function renderTab(d) {
  const box = $('#dtab'); if (!box) return;
  const s = subjById(d.subj);
  if (st.dtab === 'info' && !st.editing) {
    box.innerHTML = `<div class="kv">
      ${kv('Qeydiyyat №', esc(d.regNo), d.regNo)}${kv('Növ', `${typeIcon(d.type)} ${esc(typeName(d.type))}`)}${kv('Kateqoriya', `${catOf(d.cat).icon} ${esc(catOf(d.cat).name)}`)}
      ${kv('Subyekt', s ? `${subjIcon(s)} ${esc(s.name)}${s.voen ? ` <span class="muted">· VÖEN ${s.voen}</span>` : ''}` : '<span class="muted">təyin olunmayıb</span>', s ? s.name : '')}
      ${kv('İstiqamət', `${DIR[d.direction].icon} ${DIR[d.direction].name}`)}${kv('Nömrə', esc(d.number), d.number)}${kv('Tarix', fmtDate(d.date), fmtDate(d.date))}${kv('Dövr', periodTxt(d.period))}
      ${kv('Kontragent', esc(d.cp && d.cp.name), d.cp && d.cp.name)}${kv('Kontragent VÖEN', esc(d.cp && d.cp.voen), d.cp && d.cp.voen)}${kv('Əməkdaş / şəxs', esc(d.person), d.person)}
      ${kv('Məbləğ', d.amount != null ? `<b>${fmtMoney(d.amount)}</b> ${esc(d.currency)}` : '', d.amount != null ? String(d.amount) : '')}
      ${kv('Qüvvədədir', d.expiry ? `${fmtDate(d.expiry)}-dək ${d.expiry < today() ? '<span class="pill bad">bitib</span>' : ''}` : '')}
      ${kv('Status', esc(d.status))}${kv('Teqlər', (d.tags || []).map((t) => `<span class="pill">${esc(t)}</span>`).join(' '))}${kv('Qeyd', esc(d.note).replace(/\n/g, '<br>'))}
      ${kv('Qeydə alınıb', fmtDT(d.createdAt))}${kv('Saxlama müddəti', retentionTxt(d))}${kv('AMMO təyini', `${typeName(d.auto ? d.auto.type : d.type)} · ${Math.round((d.conf || 0) * 100)}%${d.ocr ? ' · OCR' : ''}`)}
    </div><div style="margin-top:12px;display:flex;gap:8px"><button class="btn soft" data-edit>✏️ Redaktə et</button>${(d.sent || []).length ? `<span class="small muted" style="align-self:center">📤 ${d.sent.length} dəfə göndərilib</span>` : ''}</div>`;
    $$('[data-cp]', box).forEach((b) => (b.onclick = async () => { await navigator.clipboard.writeText(b.dataset.cp); toast('Kopyalandı: ' + b.dataset.cp); }));
    $('[data-edit]', box).onclick = () => { st.editing = true; renderTab(d); };
  } else if (st.dtab === 'info') {
    const f = { subj: d.subj, type: d.type, direction: d.direction, number: d.number, date: d.date, period: d.period, title: d.title, cpName: (d.cp && d.cp.name) || '', cpVoen: (d.cp && d.cp.voen) || '', person: d.person, amount: d.amount != null ? String(d.amount) : '', currency: d.currency, expiry: d.expiry, status: d.status, tags: (d.tags || []).join(', '), note: d.note || '' };
    box.innerHTML = `<div style="display:grid;gap:8px">
      <label class="f">Subyekt<select data-e="subj">${subjOptions(f.subj, '<option value="">— təyin olunmayıb —</option>')}</select></label>
      ${(d.parties || []).filter((p) => p.name || p.voen).length > 1 ? `<div class="small muted">Sənəddə tapılan şirkətlər — basın, sənəd həmin şirkətə keçsin:</div><div class="chips" style="margin-top:0">${d.parties.filter((p) => p.name || p.voen).map((p, i) => `<span class="pill acc" data-dparty="${i}">🏢 ${esc(p.name || 'VÖEN ' + p.voen)}${p.voen && p.name ? ' · ' + p.voen : ''}</span>`).join('')}</div>` : ''}
      <label class="f">Növ<select data-e="type">${typeOptions(f.type, true)}</select></label>
      <label class="f">Başlıq<input data-e="title" value="${esc(f.title)}"></label>
      <div class="row"><label class="f">İstiqamət<select data-e="direction">${dirOptions(f.direction)}</select></label><label class="f">Status<select data-e="status">${statusOptions(f.status)}</select></label></div>
      <div class="row"><label class="f">Nömrə<input data-e="number" value="${esc(f.number)}"></label><label class="f">Tarix<input type="date" data-e="date" value="${esc(f.date)}"></label><label class="f">Dövr<input type="month" data-e="period" value="${esc(f.period)}"></label></div>
      <div class="row"><label class="f">Kontragent<input data-e="cpName" value="${esc(f.cpName)}"></label><label class="f">VÖEN<input data-e="cpVoen" value="${esc(f.cpVoen)}"></label></div>
      <div class="row"><label class="f">Əməkdaş / şəxs<input data-e="person" value="${esc(f.person)}"></label><label class="f">Məbləğ<input data-e="amount" value="${esc(f.amount)}"></label><label class="f">Valyuta<select data-e="currency">${curOptions(f.currency)}</select></label></div>
      <div class="row"><label class="f">Qüvvədədir (bitmə)<input type="date" data-e="expiry" value="${esc(f.expiry)}"></label><label class="f">Teqlər<input data-e="tags" value="${esc(f.tags)}"></label></div>
      <label class="f">Qeyd<textarea data-e="note" rows="3">${esc(f.note)}</textarea></label>
      <div style="display:flex;gap:8px"><button class="btn primary" data-save>💾 Yadda saxla</button><button class="btn ghost" data-cancel>İmtina</button></div></div>`;
    $('[data-cancel]', box).onclick = () => { st.editing = false; renderTab(d); };
    const tSel = $('[data-e=type]', box); let tPrev = tSel.value;
    tSel.onchange = async () => {
      if (tSel.value !== '__newtype') { tPrev = tSel.value; return; }
      tSel.value = tPrev; const t = await DB.get('texts', d.id); const nm = suggestTypeName(t ? t.text : '');
      const id = await newTypeDialog(null, { name: nm, kw: nm ? A.lowerAz(nm) : '', cat: d.cat });
      if (!id) return;
      tSel.innerHTML = typeOptions(id, true); tSel.value = id; tPrev = id;
    };
    const dParties = (d.parties || []).filter((p) => p.name || p.voen);
    $$('[data-dparty]', box).forEach((el) => (el.onclick = async () => {
      const p = dParties[+el.dataset.dparty]; const sSel = $('[data-e=subj]', box);
      let s = findSubjectFor(p);
      if (!s) {
        if (!(await confirmBox2(`«${esc(p.name || 'VÖEN ' + p.voen)}» hələ subyektlərdə yoxdur. Yeni subyekt kimi yaradılsın?`, 'Yarat'))) return;
        s = { id: uid(), kind: p.kind || (p.voen && p.voen.endsWith('2') ? 'physical' : 'legal'), name: p.name || 'VÖEN ' + p.voen, voen: p.voen || '', fin: '', aliases: [], color: COLORS[st.subjects.length % COLORS.length], createdAt: new Date().toISOString() };
        await saveSubject(s);
        sSel.innerHTML = subjOptions(s.id, '<option value="">— təyin olunmayıb —</option>');
      }
      sSel.value = s.id; toast(`Subyekt: ${s.name} — «Yadda saxla» basın`);
    }));
    $('[data-save]', box).onclick = async () => {
      const v = {}; $$('[data-e]', box).forEach((el) => (v[el.dataset.e] = el.value));
      const changes = [];
      const set = (k, val, label) => { if (JSON.stringify(d[k]) !== JSON.stringify(val)) { changes.push(label); d[k] = val; } };
      const oldType = d.type;
      if (v.type === '__newtype') v.type = d.type;
      set('subj', v.subj, 'subyekt'); set('type', v.type, 'növ'); d.cat = (TYPE[d.type] || TYPE.diger).cat; set('title', v.title.trim(), 'başlıq'); set('direction', v.direction, 'istiqamət'); set('status', v.status, 'status');
      set('number', v.number.trim(), 'nömrə'); set('date', v.date, 'tarix'); set('period', v.period, 'dövr'); set('cp', { name: v.cpName.trim(), voen: v.cpVoen.replace(/\D/g, '') }, 'kontragent');
      set('person', v.person.trim(), 'şəxs'); const am = v.amount.trim() === '' ? null : A.parseMoney(v.amount); set('amount', isFinite(am) ? am : null, 'məbləğ'); set('currency', v.currency, 'valyuta');
      set('expiry', v.expiry, 'müddət'); set('tags', v.tags.split(',').map((t) => t.trim()).filter(Boolean), 'teqlər'); set('note', v.note, 'qeyd');
      if (oldType !== d.type) { const t = await DB.get('texts', d.id); learn(t ? t.text : '', lastFile(d).name, d.type); await saveMeta(); }
      st.editing = false; await saveDoc(d, changes.length ? ['Redaktə edildi', changes.join(', ')] : null);
      renderDrawer(); if ($('#res')) refreshRes(); toast('Yadda saxlanıldı');
    };
  } else if (st.dtab === 'text') {
    const t = await DB.get('texts', d.id);
    box.innerHTML = `<div style="display:flex;gap:8px;margin-bottom:8px"><button class="btn ghost sm" data-ct>📋 Mətni kopyala</button><span class="small muted" style="align-self:center">${t ? t.text.length : 0} simvol${d.ocr ? ' · OCR ilə oxunub' : ''}</span></div><pre style="white-space:pre-wrap;background:#fff;border:1px solid var(--line);border-radius:10px;padding:12px;font-size:12.5px;max-height:70vh;overflow:auto">${esc(t ? t.text : '') || '—'}</pre>`;
    $('[data-ct]', box).onclick = async () => { await navigator.clipboard.writeText(t ? t.text : ''); toast('Mətn kopyalandı'); };
  } else if (st.dtab === 'files') {
    box.innerHTML = `<div class="files">${d.files.slice().reverse().map((f) => `<div class="fi"><span style="font-size:22px">${fileIcon(f.name)}</span><div><b>${esc(f.name)}</b><small>Versiya ${f.ver} · ${fmtSize(f.size)} · ${fmtDT(f.at)}${f === lastFile(d) ? ' · <b>cari</b>' : ''}</small></div><div class="sp"><button class="btn ghost sm" data-fdl="${f.fid}">⬇️</button></div></div>`).join('')}</div>
      <button class="btn soft sm" data-nv>➕ Yeni versiya yüklə</button><div class="small muted" style="margin-top:8px">Düzəliş edilmiş və ya imzalanmış nüsxəni yükləyin — köhnə versiyalar saxlanılır.</div>`;
    $$('[data-fdl]', box).forEach((b) => (b.onclick = async () => { const f = d.files.find((x) => x.fid === b.dataset.fdl); const bl = await fileBlob(f); if (bl) saveBlob(bl, f.name); }));
    $('[data-nv]', box).onclick = () => $('#drawer [data-verinp]').click();
  } else if (st.dtab === 'links') {
    const linked = (d.links || []).map((id) => st.docs.find((x) => x.id === id && !x.deleted)).filter(Boolean);
    const cands = live().filter((x) => x.id !== d.id && !(d.links || []).includes(x.id) && (!d.subj || x.subj === d.subj)).sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 300);
    box.innerHTML = `<div class="mini">${linked.map((x) => `<div class="it" data-doc="${x.id}"><span class="ic">${typeIcon(x.type)}</span><div style="min-width:0"><b>${esc(x.title)}</b><small>${fmtDate(x.date)} · ${esc(x.regNo)}</small></div><button class="btn ghost sm" data-unlink="${x.id}">✕</button></div>`).join('') || '<div class="empty">Əlaqəli sənəd yoxdur</div>'}</div>
      <div style="display:flex;gap:6px;margin-top:10px"><select data-lnk><option value="">Sənəd seçin (məs. müqavilə ↔ hesab-faktura ↔ akt)…</option>${cands.map((x) => `<option value="${x.id}">${esc(typeName(x.type))} · ${esc(x.number || '')} · ${fmtDate(x.date)} · ${esc(x.title).slice(0, 60)}</option>`).join('')}</select><button class="btn soft" data-addlnk>🔗 Bağla</button></div>
      <div class="small muted" style="margin-top:8px">Eyni nömrəli sənədlər (məs. bir qaimə üzrə HF, TTA, RP) və mətndə nömrəsi çəkilən müqavilə avtomatik bağlanır.</div>`;
    $$('[data-doc]', box).forEach((x) => (x.onclick = (e) => { if (e.target.dataset.unlink) return; openDoc(x.dataset.doc); }));
    $$('[data-unlink]', box).forEach((b) => (b.onclick = async () => { const o = st.docs.find((x) => x.id === b.dataset.unlink); d.links = d.links.filter((x) => x !== o.id); o.links = (o.links || []).filter((x) => x !== d.id); await saveDoc(o); await saveDoc(d, ['Əlaqə silindi', o.title]); renderDrawer(); }));
    $('[data-addlnk]', box).onclick = async () => { const id = $('[data-lnk]', box).value; if (!id) return; const o = st.docs.find((x) => x.id === id); d.links = [...(d.links || []), id]; o.links = [...(o.links || []), d.id]; await saveDoc(o); await saveDoc(d, ['Əlaqələndirildi', o.title]); renderDrawer(); };
  } else if (st.dtab === 'hist') {
    box.innerHTML = `<div class="hist">${(d.history || []).slice().reverse().map((h) => `<div><time>${fmtDT(h.at)}</time><span><b>${esc(h.a)}</b>${h.d ? ' — ' + esc(h.d) : ''}</span></div>`).join('')}</div>`;
  }
}
async function addVersion(d, file) {
  toast('Yeni versiya oxunur…');
  const buf = await file.arrayBuffer(); const hash = await sha256(buf);
  let r = { text: '' }; try { r = await extract(file, buf, (n) => toast(n)); } catch (e) { /* */ }
  const fid = uid(), now = new Date().toISOString();
  await DB.put('files', { id: fid, blob: file, name: file.name, mime: mimeOf(file.name, file.type), size: file.size, hash });
  d.files.push({ fid, name: file.name, size: file.size, mime: mimeOf(file.name, file.type), hash, ver: lastFile(d).ver + 1, at: now });
  if (r.thumb) d.thumb = r.thumb; d.hash = hash;
  if (r.text) { await DB.put('texts', { id: d.id, text: r.text.slice(0, 300000) }); if (st.textCache) { st.textCache.set(d.id, foldKeep(r.text)); st.rawText.set(d.id, r.text); } }
  await saveDoc(d, ['Yeni versiya', `${file.name} (v${lastFile(d).ver})`]);
  st.dtab = 'files'; renderDrawer(); loadPreview(d); toast('✅ Yeni versiya əlavə edildi');
}

// ================================================================== ixrac: Excel reyestr, ZIP
function regRows(list) {
  const head = ['№', 'Qeydiyyat №', 'İstiqamət', 'Subyekt', 'Subyektin VÖEN-i', 'Kateqoriya', 'Növ', 'Başlıq', 'Nömrə', 'Tarix', 'Dövr', 'Kontragent', 'Kontragentin VÖEN-i', 'Əməkdaş / şəxs', 'Məbləğ', 'Valyuta', 'Status', 'Qüvvədədir', 'Teqlər', 'Fayl', 'Qeydə alınıb'];
  return [head, ...list.map((d, i) => { const s = subjById(d.subj); return [i + 1, d.regNo, DIR[d.direction].name, s ? s.name : '', s ? s.voen || '' : '', catOf(d.cat).name, typeName(d.type), d.title, d.number, fmtDate(d.date), periodTxt(d.period), (d.cp && d.cp.name) || '', (d.cp && d.cp.voen) || '', d.person || '', d.amount != null ? { v: d.amount, s: 'n2' } : '', d.currency || '', d.status, fmtDate(d.expiry), (d.tags || []).join(', '), lastFile(d).name, fmtDT(d.createdAt)]; })];
}
function exportXlsx(list, name) { if (!list.length) { toast('Sənəd yoxdur'); return; } X.download([{ name: 'Reyestr', rows: regRows(list) }], `Sened_dovriyyesi_${name}_${today()}.xlsx`); }
async function zipEntries(docs, flat) {
  const files = [], used = new Set();
  for (const d of docs) {
    const f = lastFile(d); const b = await fileBlob(f); if (!b) continue;
    let base = flat ? `${String(files.length + 1).padStart(2, '0')}_${niceName(d, f)}` : `${safeName(subjName(d.subj))}/${safeName(catOf(d.cat).name)}/${safeName(typeName(d.type))}/${niceName(d, f)}`;
    let n = base, k = 2; while (used.has(n)) n = base.replace(/(\.[^.\/]+)?$/, ` (${k++})$1`); used.add(n);
    files.push({ name: n, data: new Uint8Array(await b.arrayBuffer()) });
  }
  return files;
}
async function downloadZip(ids) {
  const docs = ids.map((id) => st.docs.find((d) => d.id === id)).filter(Boolean); if (!docs.length) return;
  toast('ZIP hazırlanır…');
  const files = await zipEntries(docs, false);
  files.push({ name: 'Reyestr.xlsx', data: X.build([{ name: 'Reyestr', rows: regRows(docs) }]) });
  saveBlob(new Blob([X.zip(files)], { type: 'application/zip' }), `Senedler_${today()}.zip`);
}

// ================================================================== Göndərmə (vergi orqanına, banka, auditora…)
const RECIP = [
  ['tax', '🏛️ Vergi orqanı', 'Azərbaycan Respublikası İqtisadiyyat Nazirliyi yanında Dövlət Vergi Xidməti'],
  ['bank', '🏦 Bank', ''], ['audit', '🧮 Auditor / mühasib', ''], ['cp', '🤝 Kontragent', ''],
  ['dsmf', '🛡️ DSMF', 'Dövlət Sosial Müdafiə Fondu'], ['court', '⚖️ Məhkəmə / notariat', ''], ['other', '✉️ Digər', ''],
];
function sendDialog(ids) {
  const docs = ids.map((id) => st.docs.find((d) => d.id === id)).filter(Boolean); if (!docs.length) return;
  const cnt = {}; docs.forEach((d) => { if (d.subj) cnt[d.subj] = (cnt[d.subj] || 0) + 1; });
  const sender = Object.entries(cnt).sort((a, b) => b[1] - a[1]).map((x) => x[0])[0] || '';
  const cp = docs.find((d) => d.cp && d.cp.name);
  const st0 = { recip: 'tax', name: RECIP[0][2], email: '', subject: 'Sənədlərin təqdim edilməsi barədə', sender, signer: '', cover: true, reg: true, xls: true, recorded: null };
  const letter = () => `Bununla ${(subjById(st0.sender) || {}).name || '______'} tərəfindən aşağıda göstərilən ${docs.length} sənəd təqdim olunur. Sənədlərin surətləri əlavə edilir.`;
  const b = modal(`<div class="mh"><h2>📤 Sənədləri göndər</h2><span class="muted small">${docs.length} sənəd</span><button class="x" data-close>✕</button></div>
    <div class="mb"><div class="grid2">
      <div>
        <div class="row"><label class="f">Kimə<select data-s="recip">${RECIP.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label><label class="f">E-poçt<input data-s="email" placeholder="ünvan@mail.az" type="email"></label></div>
        <label class="f" style="margin-top:8px">Alıcının adı<input data-s="name" value="${esc(st0.name)}"></label>
        <label class="f" style="margin-top:8px">Mövzu<input data-s="subject" value="${esc(st0.subject)}"></label>
        <div class="row" style="margin-top:8px"><label class="f">Göndərən<select data-s="sender">${subjOptions(sender, '<option value="">—</option>')}</select></label><label class="f">İmzalayan (vəzifə, ad)<input data-s="signer" placeholder="Direktor Ə. Əliyev" value="${esc(signerOf(sender))}"></label></div>
        <label class="f" style="margin-top:8px">Müşayiət mətni<textarea data-s="text" rows="4">${esc(letter())}</textarea></label>
        <div style="margin-top:10px">
          <label class="chk"><input type="checkbox" data-c="cover" checked> Müşayiət məktubu (Word) əlavə et</label>
          <label class="chk"><input type="checkbox" data-c="xls" checked> Sənədlərin reyestri (Excel) əlavə et</label>
          <label class="chk"><input type="checkbox" data-c="reg" checked> Məktubu «Çıxan sənədlər» jurnalında qeydə al</label>
        </div>
      </div>
      <div><div class="small muted" style="margin-bottom:6px">Göndərilən sənədlər:</div><div class="mini" style="max-height:340px;overflow:auto;background:#fff;border:1px solid var(--line);border-radius:12px;padding:4px">${docs.map((d, i) => `<div class="it" style="cursor:default"><span class="ic">${i + 1}</span><div style="min-width:0"><b>${esc(d.title)}</b><small>${fmtDate(d.date)} · ${esc(subjName(d.subj))}</small></div><span class="muted small">${fmtSize(lastFile(d).size)}</span></div>`).join('')}</div>
        <div class="help" style="margin-top:10px">Brauzer e-poçta faylı özü əlavə edə bilmir: <b>«Paketi yüklə»</b> ZIP faylını hazırlayır, sonra e-poçt proqramında (və ya Gmail-də) həmin ZIP-i məktuba əlavə edin. E-taxes portalında «Vergi orqanına məktub» bölməsi üçün də eyni paketdən istifadə edin.</div></div>
    </div></div>
    <div class="mf"><span class="small muted" data-rec></span><div class="sp"><button class="btn ghost" data-close>Bağla</button><button class="btn soft" data-gm>Gmail-də aç</button><button class="btn soft" data-mail>✉️ E-poçt proqramı</button><button class="btn primary" data-zip>📦 Paketi yüklə (ZIP)</button></div></div>`, 'md');
  $$('[data-close]', b).forEach((x) => (x.onclick = closeModal));
  const val = (k) => $(`[data-s="${k}"]`, b).value;
  $('[data-s="recip"]', b).onchange = (e) => { const r = RECIP.find((x) => x[0] === e.target.value); $('[data-s="name"]', b).value = e.target.value === 'cp' && cp ? cp.cp.name : r[2]; };
  $('[data-s="sender"]', b).onchange = (e) => { st0.sender = e.target.value; $('[data-s="signer"]', b).value = signerOf(e.target.value); $('[data-s="text"]', b).value = letter(); };
  const gather = () => ({ recip: val('recip'), name: val('name').trim(), email: val('email').trim(), subject: val('subject').trim(), sender: val('sender'), signer: val('signer').trim(), text: val('text').trim(), cover: $('[data-c=cover]', b).checked, xls: $('[data-c=xls]', b).checked, reg: $('[data-c=reg]', b).checked });
  const record = async (channel) => {
    const g = gather();
    if (st0.recorded) { st0.recorded.channels = [...new Set([...st0.recorded.channels, channel])]; await DB.put('sends', st0.recorded); return st0.recorded; }
    const now = new Date().toISOString();
    let regNo = '', coverDoc = null, coverBytes = null;
    if (g.cover) {
      regNo = g.reg ? nextReg('out', today()) : '';
      coverBytes = coverLetter(g, docs, regNo);
      if (g.reg) {
        const fid = uid(), name = `Musayiet_mektubu_${regNo.replace(/\//g, '-')}.docx`;
        const blob = new Blob([coverBytes], { type: MIME.docx });
        await DB.put('files', { id: fid, blob, name, mime: MIME.docx, size: blob.size, hash: '' });
        coverDoc = { id: uid(), regNo, subj: g.sender, cat: 'karguzarliq', type: 'mektub', title: `Müşayiət məktubu — ${g.name || 'alıcı'}`, number: regNo, date: today(), period: '', direction: 'out', cp: { name: g.name, voen: '' }, person: '', amount: null, currency: 'AZN', expiry: '', tags: ['göndəriş'], note: g.subject, status: 'Göndərilib', fav: false, files: [{ fid, name, size: blob.size, mime: MIME.docx, hash: '', ver: 1, at: now }], hash: '', thumb: '', conf: 1, auto: { type: 'mektub', owner: g.sender, by: 'user' }, createdAt: now, updatedAt: now, history: [{ at: now, a: 'Yaradıldı', d: `${docs.length} sənədin göndərilməsi üçün müşayiət məktubu` }], sent: [], links: docs.map((d) => d.id), deleted: null };
        await DB.put('texts', { id: coverDoc.id, text: `${g.subject}\n${g.name}\n${g.text}\n` + docs.map((d, i) => `${i + 1}. ${d.title}`).join('\n') });
        await saveDoc(coverDoc);
      }
    }
    const rec = { id: uid(), at: now, recip: g.recip, to: g.name, email: g.email, subject: g.subject, sender: g.sender, docIds: docs.map((d) => d.id), coverId: coverDoc ? coverDoc.id : '', regNo, channels: [channel] };
    await DB.put('sends', rec); st.sends.unshift(rec);
    for (const d of docs) { d.sent = [...(d.sent || []), { at: now, to: g.name, sid: rec.id }]; if (coverDoc && !(d.links || []).includes(coverDoc.id)) d.links = [...(d.links || []), coverDoc.id]; if (['Qeydə alınıb', 'İcrada', 'İmzalanıb'].includes(d.status)) d.status = 'Göndərilib'; await saveDoc(d, ['Göndərildi', `${g.name || g.recip}${g.email ? ' · ' + g.email : ''}${regNo ? ' · məktub ' + regNo : ''}`]); }
    await saveMeta();
    st0.recorded = rec; st0.coverBytes = coverBytes;
    $('[data-rec]', b).textContent = `✅ Göndəriş qeydə alındı${regNo ? ' · çıxan № ' + regNo : ''}`;
    return rec;
  };
  const buildZip = async () => {
    const g = gather(); const files = await zipEntries(docs, true);
    if (g.cover && st0.coverBytes) files.unshift({ name: `00_Musayiet_mektubu${st0.recorded.regNo ? '_' + st0.recorded.regNo.replace(/\//g, '-') : ''}.docx`, data: st0.coverBytes });
    if (g.xls) files.push({ name: 'Senedlerin_reyestri.xlsx', data: X.build([{ name: 'Reyestr', rows: regRows(docs) }]) });
    saveBlob(new Blob([X.zip(files)], { type: 'application/zip' }), `${safeName((subjById(g.sender) || {}).name || 'Senedler')}_${safeName(g.name || 'gonderis').slice(0, 30)}_${today()}.zip`.replace(/\s+/g, '_'));
  };
  const body = () => { const g = gather(); return `${g.name ? 'Hörmətli ' + g.name + ',' : 'Salam,'}\n\n${g.text}\n\n${docs.map((d, i) => `${i + 1}. ${d.title}${d.date ? ' (' + fmtDate(d.date) + ')' : ''}`).join('\n')}\n\nSənədlər əlavə edilmiş ZIP faylındadır.\n\nHörmətlə,\n${g.signer || ''}\n${(subjById(g.sender) || {}).name || ''}`; };
  $('[data-zip]', b).onclick = async () => { await record('zip'); await buildZip(); toast('📦 Paket yükləndi'); };
  $('[data-mail]', b).onclick = async () => { await record('email'); await buildZip(); const g = gather(); location.href = `mailto:${encodeURIComponent(g.email)}?subject=${encodeURIComponent(g.subject)}&body=${encodeURIComponent(body())}`; };
  $('[data-gm]', b).onclick = async () => { await record('gmail'); await buildZip(); const g = gather(); window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(g.email)}&su=${encodeURIComponent(g.subject)}&body=${encodeURIComponent(body())}`, '_blank'); };
}
function signerOf(id) { const s = subjById(id); if (!s) return ''; return s.kind === 'physical' ? s.name : s.director ? `Direktor ${s.director}` : ''; }
function coverLetter(g, docs, regNo) {
  const s = subjById(g.sender) || { name: '', voen: '' };
  const rows = [[{ c: '№', b: true, shade: 'EDEDED', jc: 'center' }, { c: 'Sənəd', b: true, shade: 'EDEDED' }, { c: 'Nömrə', b: true, shade: 'EDEDED' }, { c: 'Tarix', b: true, shade: 'EDEDED' }, { c: 'Məbləğ', b: true, shade: 'EDEDED' }],
    ...docs.map((d, i) => [{ c: String(i + 1), jc: 'center' }, `${typeName(d.type)}${(d.cp && d.cp.name) || d.person ? ' — ' + ((d.cp && d.cp.name) || d.person) : ''}`, d.number || '', fmtDate(d.date), d.amount != null ? `${fmtMoney(d.amount)} ${d.currency}` : ''])];
  const body = [
    W.p(s.name || '', { b: true, sz: 12 }), s.voen ? W.p(`VÖEN: ${s.voen}`) : '', s.address ? W.p(s.address) : '', s.phone ? W.p(`Tel.: ${s.phone}`) : '',
    W.p(`${regNo ? 'Çıxış № ' + regNo + '     ' : ''}Tarix: ${fmtDate(today())}`, { before: 240, after: 240 }),
    W.p(g.name || '', { jc: 'right', b: true, after: 240 }),
    W.p(`Mövzu: ${g.subject}`, { b: true, after: 200 }),
    ...String(g.text || '').split(/\n+/).map((t) => W.p(t, { jc: 'both', firstLine: 567, after: 120, line: 276 })),
    W.p('', { after: 120 }),
    W.table({ widths: [567, 4300, 1500, 1300, 1700], rows, sz: 10.5 }),
    W.p(`Əlavə: ${docs.length} sənəd.`, { before: 200 }),
    W.p([g.signer || '', '                ____________________'], { before: 700 }),
  ].filter(Boolean);
  return W.build(body, { title: g.subject });
}

// ================================================================== Subyektlər (hüquqi və fiziki şəxslər)
const initials = (n) => A.nameKey(n).split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?';
function viewSubjects(app) {
  const L = live();
  const card = (s) => {
    const D = L.filter((d) => d.subj === s.id); const last = D.map((d) => d.createdAt).sort().pop();
    const cats = A.CATS.map((c) => [c, D.filter((d) => d.cat === c.id).length]).filter((x) => x[1]);
    return `<div class="subj" data-s="${s.id}"><button class="btn ghost sm ed" data-ed="${s.id}">✏️</button>
      <div class="av" style="background:${s.color || '#1f4fd1'}">${s.kind === 'physical' ? '👤' : initials(s.name)}</div>
      <b>${esc(s.name)}</b><div class="meta">${s.kind === 'physical' ? 'Fiziki şəxs (FS)' : 'Hüquqi şəxs'}${s.voen ? ' · VÖEN ' + s.voen : ''}${s.fin ? ' · FİN ' + esc(s.fin) : ''}</div>
      <div class="stats"><span class="pill acc">${D.length} sənəd</span>${cats.map(([c, n]) => `<span class="pill" title="${esc(c.name)}">${c.icon} ${n}</span>`).join('')}</div>
      ${last ? `<div class="small muted" style="margin-top:8px">Son sənəd: ${fmtDT(last)}</div>` : ''}</div>`;
  };
  const legal = st.subjects.filter((s) => s.kind !== 'physical').sort((a, b) => a.name.localeCompare(b.name, 'az'));
  const phys = st.subjects.filter((s) => s.kind === 'physical').sort((a, b) => a.name.localeCompare(b.name, 'az'));
  app.innerHTML = `<div class="sec-title"><h2>Subyektlər</h2><span class="muted">sənədlərin sahibləri — hüquqi və fiziki şəxslər</span>
    <div class="sp"><button class="btn ghost" data-imp>⬇️ İdxal: Asan İmza Pro və Tərəflər kitabı</button><button class="btn primary" data-new>＋ Yeni subyekt</button></div></div>
    <div class="help" style="margin-bottom:16px">AMMO sənədin mətnində subyektin <b>VÖEN</b>-ini, <b>FİN</b>-ini, <b>adını</b> və ya <b>alternativ adlarını</b> görəndə sənədi avtomatik ona aid edir. VÖEN-in son rəqəmi <b>1</b> — hüquqi şəxs, <b>2</b> — fiziki şəxs. Tanınmayan sahibkar ilk sənəddə özü yaradılır.</div>
    <h3 style="margin:6px 0 10px">🏢 Hüquqi şəxslər <span class="muted small">(${legal.length})</span></h3>
    <div class="subjects">${legal.map(card).join('') || '<div class="muted">Yoxdur</div>'}</div>
    <h3 style="margin:22px 0 10px">👤 Fiziki şəxslər — fərdi sahibkarlar <span class="muted small">(${phys.length})</span></h3>
    <div class="subjects">${phys.map(card).join('') || '<div class="muted">Yoxdur</div>'}</div>`;
  $$('[data-s]', app).forEach((c) => (c.onclick = (e) => { if (e.target.closest('[data-ed]')) return; st.open.add(c.dataset.s); go('arxiv', { filter: { subj: c.dataset.s } }); }));
  $$('[data-ed]', app).forEach((b) => (b.onclick = () => editSubject(subjById(b.dataset.ed))));
  $('[data-new]', app).onclick = () => editSubject(null);
  $('[data-imp]', app).onclick = importSubjects;
}
function editSubject(s) {
  const o = s ? { ...s } : { id: uid(), kind: 'legal', name: '', short: '', voen: '', fin: '', director: '', address: '', phone: '', email: '', aliases: [], color: COLORS[st.subjects.length % COLORS.length], createdAt: new Date().toISOString() };
  const n = s ? live().filter((d) => d.subj === s.id).length : 0;
  const b = modal(`<div class="mh"><h2>${s ? 'Subyekt' : 'Yeni subyekt'}</h2><button class="x" data-close>✕</button></div><div class="mb" style="display:grid;gap:9px">
    <div class="row"><label class="f">Növ<select data-v="kind"><option value="legal" ${o.kind !== 'physical' ? 'selected' : ''}>🏢 Hüquqi şəxs (MMC, ASC…)</option><option value="physical" ${o.kind === 'physical' ? 'selected' : ''}>👤 Fiziki şəxs (fərdi sahibkar)</option></select></label><label class="f">Rəng<input type="color" data-v="color" value="${o.color}" style="height:36px;padding:2px"></label></div>
    <label class="f">Adı<input data-v="name" value="${esc(o.name)}" placeholder="«Alfa Group» MMC / Məmmədov Rəşad Əli oğlu"></label>
    <div class="row"><label class="f">VÖEN<input data-v="voen" value="${esc(o.voen)}" maxlength="10"></label><label class="f">FİN (fiziki şəxs)<input data-v="fin" value="${esc(o.fin)}" maxlength="7"></label></div>
    <div class="row"><label class="f">Rəhbər / direktor<input data-v="director" value="${esc(o.director || '')}"></label><label class="f">Telefon<input data-v="phone" value="${esc(o.phone || '')}"></label></div>
    <div class="row"><label class="f">Ünvan<input data-v="address" value="${esc(o.address || '')}"></label><label class="f">E-poçt<input data-v="email" value="${esc(o.email || '')}"></label></div>
    <label class="f">Alternativ adlar (vergüllə) — sənəddə belə yazıla bilər<input data-v="aliases" value="${esc((o.aliases || []).join(', '))}" placeholder="Alfa, Alfa Qrup, ALFA GROUP LLC"></label>
  </div><div class="mf">${s ? `<button class="btn danger" data-del>Sil</button><span class="small muted">${n} sənəd</span>` : ''}<div class="sp"><button class="btn ghost" data-close>İmtina</button><button class="btn primary" data-save>💾 Yadda saxla</button></div></div>`, 'sm');
  $$('[data-close]', b).forEach((x) => (x.onclick = closeModal));
  $('[data-v=voen]', b).oninput = (e) => { const v = e.target.value.replace(/\D/g, ''); if (v.length === 10) $('[data-v=kind]', b).value = v.endsWith('2') ? 'physical' : 'legal'; };
  $('[data-save]', b).onclick = async () => {
    $$('[data-v]', b).forEach((el) => (o[el.dataset.v] = el.value));
    o.name = o.name.trim(); if (!o.name) { toast('Adı yazın'); return; }
    o.voen = o.voen.replace(/\D/g, '').slice(0, 10); o.fin = o.fin.toUpperCase().trim(); o.aliases = String(o.aliases).split(',').map((x) => x.trim()).filter(Boolean);
    const dup = st.subjects.find((x) => x.id !== o.id && ((o.voen && x.voen === o.voen) || A.nameKey(x.name) === A.nameKey(o.name)));
    if (dup && !(await confirmBox(`«${esc(dup.name)}» artıq var (eyni VÖEN və ya ad). Yenə də saxlanılsın?`))) return;
    await saveSubject(o); closeModal(); render(); toast('Yadda saxlanıldı');
  };
  const del = $('[data-del]', b); if (del) del.onclick = async () => {
    if (!(await confirmBox(`«${esc(o.name)}» silinsin?${n ? ` Onun ${n} sənədi «Sahibi təyin olunmayıb» qovluğuna keçəcək.` : ''}`, 'Sil', true))) return;
    for (const d of st.docs.filter((x) => x.subj === o.id)) { d.subj = ''; await saveDoc(d, ['Subyekt silindi', o.name]); }
    st.subjects = st.subjects.filter((x) => x.id !== o.id); await DB.del('subjects', o.id); summary(); render();
  };
}
async function importSubjects() {
  const r = await chrome.storage.local.get(['ammo_asan_profiles', 'sened_parties']);
  const cand = [];
  for (const p of r.ammo_asan_profiles || []) if (p.name || p.voen) cand.push({ kind: p.type === 'physical' || (p.voen && p.voen.endsWith('2')) ? 'physical' : 'legal', name: p.name || 'VÖEN ' + p.voen, voen: p.voen || '', phone: p.phone || '' });
  for (const p of r.sened_parties || []) {
    const d = p.data || {}; const per = d.person || {};
    const pn = [per.last, per.first].filter(Boolean).join(' ');
    const legal = d.type === 'legal';
    const name = legal ? (d.company ? `«${String(d.company).replace(/^[«"]|[»"]$/g, '')}» ${d.form || ''}`.trim() : p.label) : (d.company || pn || p.label);
    if (name) cand.push({ kind: legal ? 'legal' : 'physical', name, voen: d.voen || '', fin: per.fin || '', director: legal ? pn : '', address: d.address || '', phone: d.phone || '', email: d.email || '' });
  }
  let added = 0;
  for (const c of cand) {
    if (st.subjects.some((x) => (c.voen && x.voen === c.voen) || A.nameKey(x.name) === A.nameKey(c.name))) continue;
    await saveSubject({ id: uid(), aliases: [], color: COLORS[st.subjects.length % COLORS.length], createdAt: new Date().toISOString(), short: '', fin: '', director: '', address: '', phone: '', email: '', ...c }); added++;
  }
  toast(added ? `✅ ${added} subyekt idxal edildi` : (cand.length ? 'Hamısı artıq siyahıdadır' : 'Asan İmza Pro və Tərəflər kitabında məlumat tapılmadı'));
  render();
}

// ================================================================== Göndərişlər jurnalı
function viewSends(app) {
  const R = RECIP.reduce((o, [k, l]) => ((o[k] = l), o), {});
  app.innerHTML = `<div class="sec-title"><h2>Göndərişlər jurnalı</h2><span class="muted">kimə, nə vaxt, hansı sənədlər göndərilib</span><div class="sp"><button class="btn primary" data-go>📤 Yeni göndəriş — arxivdən seçin</button></div></div>
    ${st.sends.length ? `<table class="list"><thead><tr><th>Tarix</th><th>Kimə</th><th>Mövzu</th><th>Göndərən</th><th>Sənədlər</th><th>Məktub</th><th>Kanal</th></tr></thead><tbody>
      ${st.sends.slice().sort((a, b) => b.at.localeCompare(a.at)).map((s) => `<tr data-sid="${s.id}"><td class="nw">${fmtDT(s.at)}</td><td><b>${esc(s.to || '')}</b><div class="small muted">${R[s.recip] || ''}${s.email ? ' · ' + esc(s.email) : ''}</div></td><td>${esc(s.subject)}</td><td>${esc(subjName(s.sender))}</td><td class="num">${s.docIds.length}</td><td class="nw">${esc(s.regNo || '—')}</td><td>${s.channels.map((c) => `<span class="pill">${{ zip: '📦 ZIP', email: '✉️ E-poçt', gmail: 'Gmail' }[c] || c}</span>`).join(' ')}</td></tr>`).join('')}
    </tbody></table>` : '<div class="card empty">Hələ göndəriş yoxdur. Arxivdə sənədləri seçin → «📤 Göndər».</div>'}`;
  $('[data-go]', app).onclick = () => go('arxiv');
  $$('[data-sid]', app).forEach((r) => (r.onclick = () => {
    const s = st.sends.find((x) => x.id === r.dataset.sid);
    const b = modal(`<div class="mh"><h2>📤 ${esc(s.to || 'Göndəriş')}</h2><button class="x" data-close>✕</button></div><div class="mb"><div class="small muted">${fmtDT(s.at)} · ${esc(s.subject)}</div><div class="mini" style="margin-top:10px">${[s.coverId, ...s.docIds].filter(Boolean).map((id) => st.docs.find((d) => d.id === id)).filter(Boolean).map((d) => miniItem(d)).join('')}</div></div>
      <div class="mf"><div class="sp"><button class="btn soft" data-again>Yenidən göndər</button></div></div>`, 'sm');
    bindMini(b); $$('[data-doc]', b).forEach((x) => x.addEventListener('click', closeModal, { capture: true }));
    $('[data-again]', b).onclick = () => sendDialog(s.docIds.filter((id) => st.docs.some((d) => d.id === id && !d.deleted)));
  }));
}

// ================================================================== Səbət
function viewTrash(app) {
  const T = st.docs.filter((d) => d.deleted).sort((a, b) => b.deleted.localeCompare(a.deleted));
  app.innerHTML = `<div class="sec-title"><h2>Səbət</h2><span class="muted">silinmiş sənədlər — bərpa etmək olar</span><div class="sp">${T.length ? '<button class="btn danger" data-empty>Səbəti boşalt</button>' : ''}</div></div>
    ${T.length ? `<table class="list"><tbody>${T.map((d) => `<tr><td><div class="ttl"><span class="ic">${typeIcon(d.type)}</span><div><b>${esc(d.title)}</b><small>${esc(d.regNo)} · ${esc(subjName(d.subj))} · silinib ${fmtDT(d.deleted)}</small></div></div></td><td class="nw" style="text-align:right"><button class="btn soft sm" data-res="${d.id}">↩ Bərpa et</button> <button class="btn danger sm" data-kill="${d.id}">Həmişəlik sil</button></td></tr>`).join('')}</tbody></table>` : '<div class="card empty">Səbət boşdur</div>'}`;
  $$('[data-res]', app).forEach((b) => (b.onclick = async () => { const d = st.docs.find((x) => x.id === b.dataset.res); d.deleted = null; await saveDoc(d, ['Bərpa edildi']); render(); toast('Bərpa edildi'); }));
  $$('[data-kill]', app).forEach((b) => (b.onclick = async () => { if (await confirmBox('Sənəd və faylları həmişəlik silinsin? Bu geri qaytarılmır.', 'Həmişəlik sil', true)) { await purge(st.docs.find((x) => x.id === b.dataset.kill)); render(); } }));
  const e = $('[data-empty]', app); if (e) e.onclick = async () => { if (await confirmBox(`${T.length} sənəd həmişəlik silinsin?`, 'Boşalt', true)) { for (const d of T) await purge(d); render(); } };
}
async function purge(d) {
  for (const f of d.files) await DB.del('files', f.fid);
  await DB.del('texts', d.id); await DB.del('docs', d.id);
  st.docs = st.docs.filter((x) => x.id !== d.id); if (st.textCache) st.textCache.delete(d.id);
  for (const o of st.docs) if ((o.links || []).includes(d.id)) { o.links = o.links.filter((x) => x !== d.id); await DB.put('docs', o); }
  summary();
}

// ================================================================== Ayarlar + ehtiyat nüsxə
function viewSettings(app) {
  const s = S();
  const monthlyCands = ['tabel', 'hesablama', 'bank_cixaris', 'beyanname', 'dsmf', 'uzlesme', 'eqf', 'hesab_faktura', 'isler_akti', 'avans', 'kassa', 'statistika', ...A.TYPES.filter((t) => t.custom).map((t) => t.id)];
  app.innerHTML = `<div class="sec-title"><h2>Ayarlar</h2></div><div class="setgrid">
    <div class="card"><h3>🤖 Avtomatik qeydiyyat</h3>
      <label class="chk"><input type="checkbox" data-set="autoSend" ${s.autoSend ? 'checked' : ''}> Sahibi tapılıb və inam yüksəkdirsə — soruşmadan göndər</label>
      <label class="f" style="margin-top:8px">Minimal inam: <b data-thv>${Math.round(s.autoThreshold * 100)}%</b><input type="range" min="60" max="98" value="${Math.round(s.autoThreshold * 100)}" data-set="autoThreshold"></label>
      <div class="small muted" style="margin-top:6px">Söndürülübsə (tövsiyə), hər sənəd üçün «Sənəd dövriyyəsinə göndərilsin?» sualı verilir.</div>
      <label class="chk" style="margin-top:12px"><input type="checkbox" data-set="pickSend" ${s.pickSend !== false ? 'checked' : ''}> Sənəddə tapılan şirkətlərdən birini seçəndə — dərhal arxivə göndər</label>
      <label class="chk" style="margin-top:8px"><input type="checkbox" data-set="ocr" ${s.ocr !== false ? 'checked' : ''}> Skan edilmiş və şrifti pozuq PDF-ləri, şəkilləri OCR ilə oxu (azərbaycan + rus + ingilis)</label>
      <div class="small muted">OCR mühərriki ilk dəfə internetdən yüklənir; şəkil heç bir serverə göndərilmir — tanınma bu kompüterdə aparılır. ADOC/EDOC (ASAN İmza) faylları da açılıb oxunur.</div>
      <label class="f" style="margin-top:12px">Müddət xəbərdarlığı (gün əvvəl)<input type="number" min="1" max="365" value="${s.expiryDays}" data-set="expiryDays" style="width:120px"></label>
    </div>
    <div class="card"><h3>✅ Komplektlik — hər ay gözlənilən sənədlər</h3>
      ${monthlyCands.map((t) => `<label class="chk"><input type="checkbox" data-mon="${t}" ${(s.monthly || []).includes(t) ? 'checked' : ''}> ${typeIcon(t)} ${esc(typeName(t))}</label>`).join('')}
    </div>
    <div class="card"><h3>💾 Ehtiyat nüsxə</h3>
      <p class="small muted" style="margin-top:0">Bütün arxiv (sənədlər, fayllar, subyektlər, jurnallar) həm bu brauzerdə, həm də <b>Firebase (Konsalting) serverində</b> saxlanılır — kompüter dəyişsə də itmir. Əlavə olaraq ZIP nüsxə də götürə bilərsiniz.</p>
      <div class="small" data-cloudst style="margin:6px 0 10px"></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary" data-bk>⬇️ Ehtiyat nüsxəni yüklə</button><button class="btn ghost" data-rs>⬆️ Nüsxədən bərpa et</button><input type="file" accept=".zip" data-rsinp hidden></div>
      <div class="small muted" style="margin-top:10px" data-usage></div>
    </div>
    <div class="card"><h3>📂 Öz sənəd növlərim <button class="btn soft sm sp" data-nt>➕ Yeni növ</button></h3>
      <div class="small muted" style="margin-bottom:8px">Siyahıda olmayan sənəd növlərini özünüz yaradın. Açar söz yazsanız, AMMO belə sənədləri özü tanıyacaq.</div>
      ${customTypesHtml()}
    </div>
    <div class="card"><h3>📥 Yükləmələri izlə</h3>
      <label class="chk"><input type="checkbox" data-w="enabled"> Chrome-da sənəd faylı yükləyəndə «Sənəd dövriyyəsinə göndərilsin?» deyə soruş</label>
      <label class="f" style="margin-top:6px">Hansı fayllar (uzantı, vergüllə)<input data-w="exts" placeholder="pdf, docx, xlsx"></label>
      <div data-fa class="small" style="margin-top:8px"></div>
      <div class="help" style="margin-top:12px"><b>Bütün brauzerlər və proqramlar (Windows)</b> <span data-hst class="pill">yoxlanılır…</span><br>Google Chrome, Opera, Firefox, Edge, Yandex, WhatsApp, Telegram, Viber, Outlook — haradan yükləsəniz də sual çıxsın deyə kiçik Windows köməkçisini <b>bir dəfə</b> quraşdırın: ZIP-i açın → <b>QURASDIR.cmd</b>. Köməkçi işləyəndə Chrome-un öz sualı avtomatik söndürülür (iki dəfə soruşulmur).
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button class="btn dark sm" data-helper>⬇️ Windows köməkçisini yüklə</button><button class="btn ghost sm" data-hchk>↻ Yoxla</button></div>
      </div>
    </div>
    <div class="card"><h3>🧠 AMMO öyrənir <span class="sp small muted">${(st.meta.learn || []).length} qayda</span></h3>
      <div class="small muted" style="margin-bottom:8px">Sənədin növünü düzəltdikdə AMMO onun başlığını yadda saxlayır və növbəti dəfə özü düz tanıyır.</div>
      <div style="max-height:220px;overflow:auto"><table class="simple">${(st.meta.learn || []).slice(0, 100).map((r, i) => `<tr><td>«${esc(r.key)}»</td><td>→ ${typeIcon(r.type)} ${esc(typeName(r.type))}</td><td><button class="btn ghost sm" data-unl="${i}">✕</button></td></tr>`).join('') || '<tr><td class="muted">Hələ qayda yoxdur</td></tr>'}</table></div>
    </div>
    <div class="card" style="grid-column:1/-1"><h3>🗄️ Saxlama müddətləri (il, 0 = daimi)</h3>
      <div class="small muted" style="margin-bottom:8px">Tövsiyə xarakterli ilkin dəyərlərdir — öz qanunvericilik tələblərinizə uyğun dəyişin. Sənəd kartında «nə vaxta qədər saxlanmalı» göstərilir.</div>
      <div style="columns:3 300px">${A.TYPES.filter((t) => t.id !== 'diger').map((t) => `<div style="display:flex;gap:8px;align-items:center;padding:3px 0;break-inside:avoid"><input type="number" min="0" max="100" data-ret="${t.id}" value="${retentionOf(t.id)}" style="width:64px;padding:3px 6px"> <span>${t.icon} ${esc(t.name)}</span></div>`).join('')}</div>
    </div></div>`;
  $$('[data-set]', app).forEach((el) => el.addEventListener(el.type === 'range' ? 'input' : 'change', async () => {
    const k = el.dataset.set; s[k] = el.type === 'checkbox' ? el.checked : el.type === 'range' ? +el.value / 100 : +el.value;
    if (k === 'autoThreshold') $('[data-thv]', app).textContent = el.value + '%';
    await saveMeta();
  }));
  $$('[data-mon]', app).forEach((el) => (el.onchange = async () => { s.monthly = $$('[data-mon]', app).filter((x) => x.checked).map((x) => x.dataset.mon); await saveMeta(); }));
  $$('[data-ret]', app).forEach((el) => (el.onchange = async () => { s.retention[el.dataset.ret] = el.value === '' ? '' : +el.value; await saveMeta(); }));
  $$('[data-unl]', app).forEach((b) => (b.onclick = async () => { st.meta.learn.splice(+b.dataset.unl, 1); await saveMeta(); viewSettings(app); }));
  bindCustomTypes(app);
  bindWatch(app);
  $('[data-bk]', app).onclick = backup;
  $('[data-rs]', app).onclick = () => $('[data-rsinp]', app).click();
  $('[data-rsinp]', app).onchange = (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) restore(f); };
  if (navigator.storage && navigator.storage.estimate) navigator.storage.estimate().then((u) => { const el = $('[data-usage]', app); if (el) el.textContent = `İstifadə olunan yer: ${fmtSize(u.usage || 0)} · ${live().length} sənəd`; });
}
async function backup() {
  toast('Ehtiyat nüsxə hazırlanır…');
  const [files, texts] = await Promise.all([DB.all('files'), DB.all('texts')]);
  const entries = [{ name: 'manifest.json', data: JSON.stringify({ app: 'AMMO Sənəd dövriyyəsi', version: chrome.runtime.getManifest().version, at: new Date().toISOString(), docs: st.docs, subjects: st.subjects, sends: st.sends, meta: st.meta, files: files.map(({ blob, ...m }) => m) }) },
    { name: 'texts.json', data: JSON.stringify(texts) }];
  for (const f of files) entries.push({ name: `files/${f.id}`, data: new Uint8Array(await f.blob.arrayBuffer()) });
  saveBlob(new Blob([X.zip(entries)], { type: 'application/zip' }), `AMMO_sened_dovriyyesi_${today()}.zip`);
}
async function restore(file) {
  try {
    const z = await XR.unzip(await file.arrayBuffer()); const td = new TextDecoder();
    if (!z['manifest.json']) throw new Error('Bu AMMO ehtiyat nüsxəsi deyil');
    const m = JSON.parse(td.decode(z['manifest.json']));
    if (!(await confirmBox(`Nüsxədə ${m.docs.length} sənəd və ${m.subjects.length} subyekt var (${fmtDT(m.at)}). Mövcud arxivlə birləşdirilsin? (Eyni sənədlər yenilənəcək)`, 'Birləşdir'))) return;
    for (const f of m.files) if (z['files/' + f.id]) await DB.put('files', { ...f, blob: new Blob([z['files/' + f.id]], { type: f.mime }) });
    if (z['texts.json']) for (const t of JSON.parse(td.decode(z['texts.json']))) await DB.put('texts', t);
    for (const d of m.docs) await DB.put('docs', d);
    for (const s of m.subjects) await DB.put('subjects', s);
    for (const s of m.sends || []) await DB.put('sends', s);
    const c = st.meta.counters; for (const [k, v] of Object.entries((m.meta || {}).counters || {})) c[k] = Math.max(c[k] || 0, v);
    st.meta.learn = [...(st.meta.learn || []), ...(((m.meta || {}).learn) || [])].slice(0, 400);
    const mc = (m.meta || {}).custom || {};
    for (const k of ['cats', 'types']) for (const x of mc[k] || []) if (!st.meta.custom[k].some((y) => y.id === x.id)) st.meta.custom[k].push(x);
    A.registerCustom(st.meta.custom); await saveMeta();
    await loadAll(); st.textCache = null; render(); toast('✅ Bərpa edildi');
  } catch (e) { toast('Bərpa alınmadı: ' + e.message, 6000); }
}

// ================================================================== başlanğıc
async function loadAll() {
  const [docs, subjects, sends, meta] = await Promise.all([DB.all('docs'), DB.all('subjects'), DB.all('sends'), DB.get('meta', 'state')]);
  st.docs = docs.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))); st.subjects = subjects; st.sends = sends;
  if (meta) st.meta = { counters: {}, learn: [], ...meta, settings: { ...DEF_SET, ...(meta.settings || {}) } };
  st.meta.custom = { cats: [], types: [], ...(st.meta.custom || {}) };
  A.registerCustom(st.meta.custom);
  summary();
}
function cloudBadge(c) {
  const el = $('#cloudSt'); const box = $('[data-cloudst]');
  const txt = c.error && c.error !== 'giriş yoxdur' ? `☁ Bulud: ${c.pending} yazı gözləyir (${c.error})` : c.error === 'giriş yoxdur' ? '☁ Bulud: AMMO-ya daxil olun (e-taxes → AMMO)' : c.pending ? `☁ Buluda yazılır… (${c.pending})` : `☁ Bulud: hamısı yazılıb${c.last ? ' · ' + fmtDT(new Date(c.last).toISOString()) : ''}`;
  if (el) { el.textContent = txt; el.className = 'cloudst ' + (c.error ? 'bad' : c.pending ? 'busy' : 'ok'); }
  if (box) box.textContent = txt;
}
async function init() {
  try { await DB.open(); if (globalThis.DD_CLOUD) DD_CLOUD.attach(DB, { onStatus: cloudBadge }); await loadAll(); } catch (e) { $('#app').innerHTML = `<div class="card empty">Yaddaş açılmadı: ${esc(e.message)}</div>`; return; }
  // v1.23: buludla eyniləşdir — yeni kompüterdə arxiv buluddan gəlir; başqa işçinin əlavə etdiyi sənədlər də görünür
  const cloudPull = async (full) => { if (!globalThis.DD_CLOUD) return; try { const r = await DD_CLOUD.pull({ full }); if (r && r.changed) { await loadAll(); st.textCache = null; render(); toast(`☁ Buluddan ${r.changed} yenilik gəldi`); } } catch (e) { /* oflayn */ } };
  setTimeout(() => cloudPull(false), 800);
  setInterval(() => { if (document.visibilityState === 'visible') cloudPull(false); }, 60000);
  $$('#topnav button').forEach((b) => (b.onclick = () => go(b.dataset.view)));
  $('#btnUpload').onclick = () => $('#fileInp').click();
  $('#fileInp').onchange = (e) => { handleFiles(e.target.files); e.target.value = ''; };
  $('#shade').onclick = closeDrawer;
  const gq = $('#gq'); let gt = null;
  gq.oninput = () => { clearTimeout(gt); gt = setTimeout(async () => { await ensureTexts(); if (st.view !== 'arxiv') { st.f = { ...defFilter(), q: gq.value }; go('arxiv'); } else { st.f.q = gq.value; const i = $('[data-f=q]'); if (i) i.value = gq.value; refreshRes(); } }, 250); };
  gq.onkeydown = (e) => { if (e.key === 'Enter') { clearTimeout(gt); gq.oninput(); } };
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); gq.focus(); gq.select(); }
    if (e.key === 'Escape') { if ($('#modal2 .ov')) { closeModal2(); return; } if ($('#modal .ov') && !$('#modal .queue-box')) closeModal(); else if (st.drawer && !$('#modal .ov')) closeDrawer(); }
  });
  // bütün səhifəyə fayl atmaq
  let dragN = 0; const ov = $('#dropOverlay');
  const hasFiles = (e) => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
  window.addEventListener('dragenter', (e) => { if (!hasFiles(e)) return; dragN++; ov.classList.add('on'); });
  window.addEventListener('dragleave', () => { dragN = Math.max(0, dragN - 1); if (!dragN) ov.classList.remove('on'); });
  window.addEventListener('dragover', (e) => { if (hasFiles(e)) e.preventDefault(); });
  window.addEventListener('drop', (e) => { if (!hasFiles(e)) return; e.preventDefault(); dragN = 0; ov.classList.remove('on'); handleFiles(e.dataTransfer.files); });
  // Ctrl+V — ekran görüntüsü və ya kopyalanmış fayl
  document.addEventListener('paste', (e) => {
    if (/INPUT|TEXTAREA/.test(document.activeElement && document.activeElement.tagName)) return;
    const fs = [...(e.clipboardData ? e.clipboardData.files : [])];
    if (fs.length) { e.preventDefault(); handleFiles(fs.map((f, i) => (f.name && f.name !== 'image.png' ? f : new File([f], `Ekran_${today()}_${i + 1}.png`, { type: f.type })))); }
  });
  const key = new URLSearchParams(location.search).get('key') || '';
  // yükləmə pəncərəsindən («Bəli») gələn fayllar
  if (INBOX) { INBOX.listen(drainInbox); chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'AMMO_DD_INBOX') drainInbox(); }); setTimeout(drainInbox, 50); }
  if (key === 'inbox') history.replaceState(null, '', location.pathname);
  if (key.startsWith('doc:')) { go('arxiv'); openDoc(key.slice(4)); }
  else if (['arxiv', 'subjects', 'sends', 'settings'].includes(key)) go(key);
  else go('home');
}
init();
