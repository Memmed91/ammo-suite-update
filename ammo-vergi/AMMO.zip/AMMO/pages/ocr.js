/* AMMO — OCR sandbox səhifəsi.
 * Şəxsiyyət vəsiqəsindəki yazını oxumaq üçün açıq mənbəli Tesseract (tesseract.js) mühərrikindən istifadə edir.
 * Mühərrik ilk istifadədə internetdən (cdn.jsdelivr.net) yüklənir; şəkil heç bir serverə göndərilmir —
 * tanıma bu kompüterdə, brauzerin içində aparılır. */
(function () {
  'use strict';
  const VER = '5.1.1';
  const CDN = `https://cdn.jsdelivr.net/npm/tesseract.js@${VER}/dist/`;
  let libP = null, workerP = null, curLang = '';

  function loadLib() {
    if (libP) return libP;
    libP = new Promise((res, rej) => {
      const s = document.createElement('script'); s.src = CDN + 'tesseract.min.js';
      s.onload = () => (self.Tesseract ? res(self.Tesseract) : rej(new Error('Tesseract yüklənmədi')));
      s.onerror = () => { libP = null; rej(new Error('OCR mühərriki yüklənmədi — internet bağlantısını yoxlayın')); };
      document.head.appendChild(s);
    });
    return libP;
  }
  async function getWorker(lang, report) {
    if (workerP && curLang === lang) return workerP;
    curLang = lang;
    workerP = (async () => {
      const T = await loadLib();
      return T.createWorker(lang.split('+'), 1, {
        workerPath: CDN + 'worker.min.js',
        corePath: `https://cdn.jsdelivr.net/npm/tesseract.js-core@${VER}`,
        langPath: 'https://tessdata.projectnaptha.com/4.0.0_fast',
        cacheMethod: 'none',
        logger: (m) => report(m)
      });
    })().catch((e) => { workerP = null; throw e; });
    return workerP;
  }

  window.addEventListener('message', async (e) => {
    const m = e.data || {}; if (!m.id || !m.image) return;
    const reply = (o) => e.source.postMessage({ id: m.id, ...o }, '*');
    try {
      const w = await getWorker(m.lang || 'aze+eng', (p) => reply({ progress: Math.round((p.progress || 0) * 100), status: p.status }));
      const r = await w.recognize(m.image);
      reply({ ok: true, text: (r && r.data && r.data.text) || '' });
    } catch (err) { reply({ ok: false, error: String((err && err.message) || err) }); }
  });
})();
