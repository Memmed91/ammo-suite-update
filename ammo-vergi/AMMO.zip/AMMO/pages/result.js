(async function () {
  'use strict';
  const D = AMMO_DICT;
  const key = new URLSearchParams(location.search).get('key');
  const $ = (id) => document.getElementById(id);
  const data = key ? (await chrome.storage.local.get(key))[key] : null;
  if (!data) { $('title').textContent = 'Nəticə tapılmadı (vaxtı keçib və ya silinib).'; return; }

  document.title = 'AMMO — ' + data.title;
  $('title').textContent = data.title;
  let cur = 0, sortCol = -1, sortAsc = true;

  const val = (c) => (c !== null && typeof c === 'object' ? c.v : c);
  const isTotal = (r) => r.some((c) => /^(cəmi|cəmİ|CƏMİ)$/i.test(String(val(c) ?? '')) && r.indexOf(c) <= 2);

  function renderNav() {
    const nav = $('sheets');
    nav.innerHTML = '';
    if (data.sheets.length < 2) return;
    data.sheets.forEach((s, i) => {
      const b = document.createElement('button');
      b.textContent = s.name;
      b.className = i === cur ? 'active' : '';
      b.onclick = () => { cur = i; sortCol = -1; renderNav(); render(); };
      nav.appendChild(b);
    });
  }

  function render() {
    const sheet = data.sheets[cur];
    const hIdx = sheet.headerRow || 0;
    const header = sheet.rows[hIdx];
    const rest = sheet.rows.slice(hIdx + 1).map((r) => r.map(val));
    let body = rest.filter((r) => !isTotal(r));
    const totals = rest.filter(isTotal);
    const q = $('q').value.trim().toLowerCase();
    if (q) body = body.filter((r) => r.some((c) => String(c ?? '').toLowerCase().includes(q)));
    if (sortCol >= 0) {
      body = [...body].sort((a, b) => {
        const x = a[sortCol], y = b[sortCol];
        const c = typeof x === 'number' && typeof y === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? ''), 'az');
        return sortAsc ? c : -c;
      });
    }
    const tbl = $('tbl');
    tbl.innerHTML = '';
    const thead = tbl.createTHead();
    const hr = thead.insertRow();
    header.forEach((h, i) => {
      const th = document.createElement('th');
      th.textContent = h;
      if (i === sortCol) th.className = 'sorted' + (sortAsc ? ' asc' : '');
      th.onclick = () => { if (sortCol === i) sortAsc = !sortAsc; else { sortCol = i; sortAsc = true; } render(); };
      hr.appendChild(th);
    });
    const tb = tbl.createTBody();
    const addRow = (r, cls) => {
      const tr = tb.insertRow();
      if (cls) tr.className = cls;
      header.forEach((_, i) => {
        const td = tr.insertCell();
        const v = r[i];
        if (typeof v === 'number') { td.className = 'n'; td.textContent = Number.isInteger(v) && !/məbləğ|dəyər|ədv|aksiz|vergi|cəmi|qiymət|hesab/i.test(header[i]) ? v : v.toLocaleString('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 9 }); }
        else td.textContent = v ?? '';
      });
    };
    body.forEach((r) => addRow(r));
    if (!q) totals.forEach((r) => addRow(r, 'total'));
    $('info').textContent = `${body.length} sətir` + (q ? ` (filtr: “${q}”)` : '') + ` · Yaradılıb: ${D.fmtDateTime(data.created)}`;
  }

  $('q').addEventListener('input', render);
  $('xlsx').onclick = () => {
    const d = new Date(data.created), p = (n) => String(n).padStart(2, '0');
    AMMO_XLSX.download(data.sheets, `${data.fileBase}_${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}.xlsx`);
  };
  $('print').onclick = () => window.print();
  renderNav();
  render();
})();
