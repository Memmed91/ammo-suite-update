/* AMMO — İlkin audit (v1.23): nəticə səhifəsi */
(async function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const key = new URLSearchParams(location.search).get('key');
  const S = key ? (await chrome.storage.local.get(key))[key] : null;
  if (!S) { $('title').textContent = 'Nəticə tapılmadı — AMMO panelində «İlkin audit» → «Hazırla» basın.'; return; }
  if ((S.version || 1) < 3) { $('title').textContent = 'Bu nəticə AMMO-nun köhnə versiyası ilə hazırlanıb — İlkin audit-i yenidən hazırlayın.'; return; }
  const T = window.AMMO_TAXREP_FORMS, E = window.AMMO_EVEZ, ST = window.AMMO_STOCK;
  const TIN = S.tin || 'x';

  // ------------------------------------------------------------------ köməkçilər
  const n0 = (v) => { const x = Number(v); return isFinite(x) ? x : 0; };
  const r2 = (v) => Math.round(n0(v) * 100) / 100;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (v) => { const x = r2(v); const [i, f] = Math.abs(x).toFixed(2).split('.'); return (x < 0 ? '−' : '') + i.replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ',' + f; };
  const qty = (v) => { const x = Math.round(n0(v) * 1000) / 1000; return x.toLocaleString('az-AZ', { maximumFractionDigits: 3 }); };
  const dmy = (iso) => { const s = String(iso || ''); const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s); return m ? `${m[3]}.${m[2]}.${m[1]}` : s.slice(0, 10); };
  const fold = (s) => String(s || '').replace(/̇/g, '').toLocaleLowerCase('az');
  const MONTHS = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
  const qOf = (m) => { m = Number(m) || 1; return [1, 4, 7, 10].includes(m) ? (m + 2) / 3 : m <= 3 ? m : Math.ceil(m / 3); };
  const qName = (q) => `${q}-${q >= 3 ? 'cü' : 'ci'} rüb`;
  const periodLabel = (d) => (d.ptype === 'MONTH' ? `${MONTHS[(d.month || 1) - 1]} ${d.year}` : d.ptype === 'QUARTER' ? `${qName(qOf(d.month))} ${d.year}` : `${d.year}`);
  const periodSort = (d) => `${d.year}-${String(d.ptype === 'QUARTER' ? qOf(d.month) * 3 : d.month || 0).padStart(2, '0')}`;
  function toast(t, ms = 5000) { const el = $('toast'); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => { el.hidden = true; }, ms); }
  const P = S.period;
  const perText = P.mode === 'year' ? `${P.year}-ci il` : P.mode === 'all' ? `Bütün dövr (${dmy(P.fromISO)} – ${dmy(P.toISO)})` : `${dmy(P.fromISO)} – ${dmy(P.toISO)}`;
  const PORTAL = 'https://new.e-taxes.gov.az';
  const openUrl = (u) => chrome.tabs.create({ url: u });
  function modal(title, html) { $('mTitle').textContent = title; $('mBody').innerHTML = html; $('modal').hidden = false; }
  $('mClose').onclick = () => { $('modal').hidden = true; };
  $('modal').onclick = (e) => { if (e.target === $('modal')) $('modal').hidden = true; };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('modal').hidden = true; });
  async function portal(type, payload) {
    const tabs = await chrome.tabs.query({ url: PORTAL + '/eportal/*' });
    if (!tabs.length) throw new Error('e-taxes.gov.az açıq deyil — portala daxil olun.');
    let lastErr = null;
    for (const t of tabs) { try { const r = await chrome.tabs.sendMessage(t.id, { type, ...payload }); if (r && r.ok) return r.data; if (r && r.error) lastErr = new Error(r.error); } catch (e) { lastErr = e; } }
    throw lastErr || new Error('Portal cavab vermədi');
  }
  async function openPdf(id) {
    try {
      toast('Bəyannamənin PDF-i portaldan alınır…');
      const dataUrl = await portal('AMMO_AUDIT_API', { op: 'pdf', id });
      const b = await (await fetch(dataUrl)).blob();
      chrome.tabs.create({ url: URL.createObjectURL(b) });
    } catch (e) { toast('PDF açılmadı: ' + e.message); }
  }
  const table = (head, rows, opts = {}) => {
    if (!rows.length) return `<div class="empty">${opts.empty || 'Məlumat yoxdur.'}</div>`;
    const nums = opts.nums || [];
    return `<div class="wrap"><table class="t"><thead><tr>${head.map((h, i) => `<th class="${nums.includes(i) ? 'n' : ''}">${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr class="${r._cls || ''}"${r._attr || ''}>${r.map((c, i) => `<td class="${nums.includes(i) ? 'n' : ''}">${c && c.html != null ? c.html : nums.includes(i) && c !== '' && c != null ? money(c) : esc(c)}</td>`).join('')}</tr>`).join('')}${opts.total ? `<tr class="tot">${opts.total.map((c, i) => `<td class="${nums.includes(i) ? 'n' : ''}">${nums.includes(i) && c !== '' ? money(c) : esc(c)}</td>`).join('')}</tr>` : ''}</tbody></table></div>`;
  };
  const save = () => chrome.storage.local.set({ [key]: S }).catch(() => {});

  // ------------------------------------------------------------------ başlıq
  const PM = () => (S.profile && S.profile.main) || {};
  const compName = () => PM().companyName || PM().individualName || S.company || (S.audit && S.audit.self) || '';
  $('title').textContent = `İlkin audit${compName() ? ' — ' + compName() : ''}`;
  $('sub').textContent = `${perText} · VÖEN ${S.tin || '—'} · hazırlandı ${new Date(S.created).toLocaleString('az-AZ')}`;
  document.title = `AMMO — İlkin audit ${compName() || ''}`;

  // ------------------------------------------------------------------ mal qalığı (mal kodu üzrə, bütün tarixçə)
  const MV_BASE = (S.moves || []).filter((m) => m[1] !== 'cus').map(([d, dir, k, code, name, unit, q, cost, doc, party, svc]) => ({ d, dir: dir === 'retIn' ? 'in' : dir === 'retOut' ? 'out' : dir, key: k, code, name, unit, q, cost, doc, party, svc: !!svc }));
  const cusMoves = (rows) => (rows || []).filter((c) => n0(c.qty)).map((c) => ({ d: String(c.date || '').slice(0, 10), dir: 'cus', key: ST.keyOf(c.code, c.goods, c.unit), code: ST.normCode(c.code), name: String(c.goods || '').trim(), unit: c.unit || '', q: n0(c.qty), cost: n0(c.value), doc: c.gb || '', party: c.sender || c.name || '' }));
  let MV = [], INV = [], MVG = [];
  function recalcStock() {
    MV = MV_BASE.concat(cusMoves(S.customs)).sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : 0));
    INV = ST.balance(MV);
    MVG = MV.filter((m) => !m.svc); // maliyyə (maya dəyəri) üçün — yalnız mal kodları
  }
  recalcStock();

  // ------------------------------------------------------------------ gəlir · xərc · mənfəət (real məlumat)
  const A = S.audit;
  function finance() {
    if (!A) return null;
    const c = ST.cogs(MVG, P.fromISO, P.toISO);
    const goodsBought = (A.expenses.find((e) => e.code === '221.4') || {}).amount || 0;
    // satılan malların maya dəyəri = açılış qalığı + dövr ərzində alış − son qalıq (alış qaimələrində mal kimi gələnlər + akt + gömrük)
    const stockChange = c.close - c.open;
    const otherExp = A.expenseTotal - goodsBought;
    const cogs = c.cogs > 0 || c.open || c.close ? c.cogs : goodsBought;
    const income = A.income.total;
    const expense = r2(otherExp + cogs);
    const profit = r2(income - expense);
    return { income, expense, profit, tax: profit > 0 ? r2(profit * 0.2) : 0, cogs: r2(cogs), open: r2(c.open), close: r2(c.close), buy: r2(c.buy), goodsBought: r2(goodsBought), otherExp: r2(otherExp), stockChange: r2(stockChange) };
  }
  let FIN = finance();

  // ------------------------------------------------------------------ daxil olan pullar (804)
  function cashByYear() {
    const years = new Map();
    (S.cash || []).forEach((c) => {
      if (!years.has(c.year)) years.set(c.year, { year: c.year, q: [null, null, null, null], src: [null, null, null, null] });
      const y = years.get(c.year); const i = (c.q || 1) - 1;
      y.src[i] = c; if (c.v804 != null) y.q[i] = c.v804;
    });
    const sales = new Map();
    ((A && A.lines && A.lines.income) || []).forEach(([d, , , , , , cost, vat]) => { const y = +String(d).slice(0, 4), q = Math.ceil(+String(d).slice(5, 7) / 3); if (!y) return; const k = `${y}-${q}`; sales.set(k, n0(sales.get(k)) + n0(cost) + n0(vat)); });
    return [...years.keys()].sort().map((y) => ({ ...years.get(y), sales: [1, 2, 3, 4].map((q) => sales.get(`${y}-${q}`) || 0) }));
  }
  let CASH = cashByYear();
  const cashTotal = () => CASH.reduce((s, y) => s + y.q.reduce((a, b) => a + n0(b), 0), 0);

  // ------------------------------------------------------------------ bəyannamələr: yalnız Təsdiqlənmiş və Uyğunsuzluq
  const DECLS = (S.decls || []).filter((d) => d.year >= +P.fromISO.slice(0, 4) && d.year <= +P.toISO.slice(0, 4));
  const isConf = (d) => d.status === 'CONFIRMED' && !d.violation;
  const isViol = (d) => d.violation && d.status !== 'DRAFT';
  const missing = S.missing || [];
  const missLate = missing.filter((m) => m.state === 'missing' || m.state === 'draftLate');

  // ------------------------------------------------------------------ borc
  const debtTotal = () => (S.debts && S.debts.totals ? S.debts.totals.debt : null);

  // ------------------------------------------------------------------ bölmələr
  const SECTIONS = [
    ['ov', 'Ümumi baxış'], ['profile', 'Şirkət profili'], ['decls', 'Bəyannamələr', () => { const v = DECLS.filter(isViol).length; return v ? [v, 'bad'] : missLate.length ? [missLate.length, 'warn'] : [DECLS.filter(isConf).length]; }],
    ['fin', 'Gəlir · xərc · mənfəət'], ['stock', 'Mal qalığı', () => [INV.filter((i) => i.rest > 0.0005).length]], ['cash', 'Daxil olan pullar'],
    ['vat', 'ƏDV və depozit'], ['debts', 'Borclar', () => (debtTotal() ? [money(debtTotal()), 'bad'] : null)], ['mail', 'Məktublar', () => (S.mail && S.mail.unread ? [S.mail.unread, 'warn'] : null)], ['staff', 'İşçilər', () => (S.staff ? [S.staff.list.length] : null)],
  ];
  function renderNav() {
    $('nav').innerHTML = SECTIONS.map(([id, t, c]) => { const x = c ? c() : null; return `<a href="#${id}" data-id="${id}">${esc(t)}${x ? `<em class="${x[1] || ''}">${esc(x[0])}</em>` : ''}</a>`; }).join('');
  }
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) document.querySelectorAll('.side a').forEach((a) => a.classList.toggle('on', a.dataset.id === e.target.id)); }), { rootMargin: '-90px 0px -70% 0px' });
  const kpi = (cls, label, val, small, go) => `<button class="kpi ${cls}" data-go="${go}"><span>${esc(label)}</span><b>${val}</b><small>${small || ''}</small></button>`;
  const refreshBtn = (what) => `<button class="ghost" data-refresh="${what}" title="Açıq e-taxes kabinetindən yenidən oxu">↻ Portaldan yenilə</button>`;

  function secOverview() {
    const v = S.vat, d = S.debts && S.debts.totals;
    const restV = INV.reduce((s, i) => s + Math.max(0, i.restV), 0);
    const emp = A && A.payroll ? A.payroll.employees : 0;
    const viol = DECLS.filter(isViol).length;
    return `<section class="blk" id="ov"><h2>Ümumi baxış <small>${esc(perText)}</small></h2>
      <p class="lead">Bütün rəqəmlər portaldakı real məlumatdan hesablanıb. Karta basın — ətraflı bölmə açılacaq.</p>
      <div class="kpis">
        ${kpi('', 'Gəlir', FIN ? money(FIN.income) : '—', A ? `${A.counts.sales} satış qaiməsi` : '', 'fin')}
        ${kpi('', 'Xərc', FIN ? money(FIN.expense) : '—', FIN ? `o cümlədən satılan malın maya dəyəri ${money(FIN.cogs)}` : '', 'fin')}
        ${kpi(FIN && FIN.profit < 0 ? 'bad' : 'ok', FIN && FIN.profit < 0 ? 'Zərər' : 'Mənfəət', FIN ? money(Math.abs(FIN.profit)) : '—', FIN ? `təxmini vergi (20%): ${money(FIN.tax)}` : '', 'fin')}
        ${kpi('', 'Daxil olan pullar (804)', cashTotal() ? money(cashTotal()) : '—', `${(S.cash || []).filter((c) => c.v804 != null).length} rüb · bank + POS`, 'cash')}
        ${kpi('', 'Mal qalığı (dəyər)', money(restV), `${INV.filter((i) => i.rest > 0.0005).length} mal kodu`, 'stock')}
        ${kpi(viol ? 'bad' : 'ok', 'Uyğunsuzluq', String(viol), `${DECLS.filter(isConf).length} təsdiqlənmiş bəyannamə`, 'decls')}
        ${kpi(missLate.length ? 'bad' : 'ok', 'Təqdim edilməmiş', String(missLate.length), missLate.length ? 'müddəti keçmiş bəyannamə' : 'hamısı təqdim edilib', 'decls')}
        ${kpi(d && d.debt ? 'bad' : 'ok', 'Vergi borcu', d ? money(d.debt) : '—', d ? `artıq ödəmə: ${money(d.overpay)}` : (S.debts && S.debts.error) || '', 'debts')}
        ${kpi(S.mail && S.mail.unread ? 'warn' : 'ok', 'Oxunmamış məktub', S.mail ? String(S.mail.unread) : '—', S.mail ? `cəmi ${S.mail.total}` : '', 'mail')}
        ${kpi('', 'ƏDV — əvəzləşməyən qalıq', v ? money(v.totals.remaining) : '—', v ? `depozit qalığı: ${v.deposit && v.deposit.closing != null ? money(v.deposit.closing) : '—'}` : 'ƏDV analizi seçilməyib', 'vat')}
        ${kpi('', 'İşçi sayı', String(S.staff ? S.staff.list.length : (PM().employeeData && PM().employeeData.employeeCount) || emp || '—'), S.staff ? 'ƏMAS' : 'profil / vahid bəyannamə', 'staff')}
      </div>
      ${(S.notes || []).length ? `<div class="callout warn"><div><b>Qeydlər</b>${S.notes.map(esc).join('<br>')}</div></div>` : ''}
    </section>`;
  }

  // ------------------------------------------------------------------ profil
  const OBL_TAX = { '0100': 'Mənfəət vergisi', '0200': 'Mənfəət vergisi', '0300': 'ƏDV', '0400': 'Aksiz', '0500': 'Əmlak vergisi', '0600': 'Torpaq vergisi', '0700': 'Mədən vergisi', '0800': 'Sadələşdirilmiş vergi', '0802': 'Sadələşdirilmiş vergi (daşınmaz əmlak)', '0804': 'Sadələşdirilmiş vergi (pul vəsaiti)', '0901': 'Muzdlu iş (vahid bəyannamə)', '0101': 'Yol vergisi', '1200': 'Gəlir vergisi', '1400': 'Mənfəət vergisi (xüsusi rejim)', '1600': 'Ödəmə mənbəyində vergi', '1601': 'ÖMV (uduşlar)', '1700': 'Subpodrat', '1100': 'Dövlət rüsumu' };
  const PER_CODE = { '00': 'Aylıq', '01': 'Rüblük', '02': 'İllik', '03': 'Yarımillik' };
  const yms = (p) => (/^\d{6}$/.test(String(p || '')) ? `${MONTHS[+String(p).slice(4) - 1] || ''} ${String(p).slice(0, 4)}` : '');
  const tr = (s) => (typeof s === 'object' && s ? s.az || s.name || s.en || '' : s || '');
  const PTABS = [
    ['objects', 'Obyektlər', (pr) => table(['Kod', 'Ad', 'Ünvan', 'Fəaliyyət', 'Status'], (pr.objects || []).map((o) => [o.objectCode, o.objectName, o.address, o.mainActivity ? `${o.mainActivity.code || ''} ${tr(o.mainActivity.name)}` : '', o.status]), { empty: 'Qeydiyyatda obyekt yoxdur.' })],
    ['licenses', 'Lisenziyalar', (pr) => table(['Seriya №', 'Fəaliyyət', 'Başlama', 'Bitmə'], (pr.licenses || []).map((l) => [l.serialNumber, l.name || l.activityCode, dmy(l.startDate || l.registrationDate), l.expirationDate ? dmy(l.expirationDate) : 'müddətsiz']), { empty: 'Lisenziya yoxdur.' })],
    ['legal', 'Reyestr məlumatları', (pr) => table(['Ad', 'Hüquqi forma', 'Nizamnamə kapitalı', 'Pay', 'Qeydiyyat', 'Şəhadətnamə №', 'Qanuni nümayəndə'], (pr.legal || []).map((l) => [l.name, l.legalForm, l.nominalCapital != null ? money(l.nominalCapital) : '', l.share != null ? l.share + '%' : '', dmy(l.registrationDate), l.stateRegistrationDocumentNumber, l.legalRepresentative]), { empty: 'Reyestr məlumatı yoxdur.' })],
    ['branches', 'Filiallar', (pr) => table(['Kod', 'Ad', 'Ünvan', 'Status'], (pr.branches || []).map((b) => [b.code || b.branchCode, b.name || b.branchName, b.address || '', b.status || '']), { empty: 'Filial yoxdur.' })],
    ['cash', 'Kassa aparatları', (pr) => table(['Qeydiyyat №', 'Zavod №', 'Model', 'Obyekt', 'Status'], (pr.cash || []).map((c) => [c.registerNumber || c.registrationNumber || '', c.serialNumber || c.cashMachineSerialNumber || '', c.model || c.modelName || '', c.objectCode || '', c.state || c.status || '']), { empty: 'Qeydiyyatda kassa aparatı (NKA) yoxdur.' })],
    ['banks', 'Bank hesabları', (pr) => {
      const g = new Map();
      (pr.banks || []).forEach((b) => { const k = b.bankName || b.bankCode || '—'; if (!g.has(k)) g.set(k, { name: k, tin: b.bankTin, n: 0, act: 0, cur: new Set(), acc: [] }); const x = g.get(k); x.n++; if (!/closed|bağlı|inactive/i.test(b.status || '')) x.act++; if (b.currency) x.cur.add(b.currency); x.acc.push(b); });
      return g.size ? `<ol class="plist">${[...g.values()].map((x) => `<li><span class="pl-ic">🏦</span><b>${esc(x.name)}</b><em>${x.n} hesab${x.act !== x.n ? ` (${x.act} aktiv)` : ''}${x.cur.size ? ' · ' + [...x.cur].join(', ') : ''}${x.tin ? ' · VÖEN ' + esc(x.tin) : ''}</em></li>`).join('')}</ol>
        <details class="more"><summary>Bütün hesablar (${(pr.banks || []).length})</summary>${table(['Bank', 'Hesab', 'Valyuta', 'Növ', 'Açılma', 'Status'], (pr.banks || []).map((b) => [b.bankName, b.number || b.settlementAccount, b.currency, b.type, dmy(b.registrationDate), b.status]))}</details>` : '<div class="empty">Bank hesabı yoxdur.</div>';
    }],
    ['obligations', 'Mükəlləfiyyətlər', (pr) => table(['Vergi', 'Dövrilik', 'Yaranma dövrü', 'Bitmə', 'Status'], (pr.obligations || []).slice().sort((a, b) => (a.status === 'active' ? -1 : 1) - (b.status === 'active' ? -1 : 1)).map((o) => { const r = [`${OBL_TAX[o.taxCode] || 'Vergi'} (${o.taxCode})`, PER_CODE[o.taxPeriodCode] || o.taxPeriodCode || '', yms(o.startPeriod) || dmy(o.startDate), o.endDate ? dmy(o.endDate) : '—', { html: `<span class="pill ${o.status === 'active' ? 'ok' : ''}">${o.status === 'active' ? 'aktiv' : 'passiv'}</span>` }]; if (o.status !== 'active') r._cls = 'zero'; return r; }), { empty: 'Mükəlləfiyyət tapılmadı.' })],
    ['pos', 'POS-terminallar', (pr) => table(['Terminal', 'Bank', 'Obyekt', 'Status'], (pr.pos || []).map((p) => [p.terminalId || p.serialNumber || p.id || '', p.bankName || '', p.objectCode || p.address || '', p.status || '']), { empty: 'POS-terminal qeydiyyatda deyil.' })],
  ];
  let ptab = 0;
  function secProfile() {
    const pr = S.profile;
    if (!pr || !pr.main) return `<section class="blk" id="profile"><h2>Şirkət profili <span class="hdr-actions">${refreshBtn('profile')}</span></h2><div class="callout warn"><div><b>Profil oxunmadı</b>${esc((pr && pr.errors && pr.errors.main) || 'Portal cavab vermədi.')} «Portaldan yenilə» basın.</div></div></section>`;
    const m = pr.main;
    const chief = m.chief ? [m.chief.surname, m.chief.name, m.chief.middleName].filter(Boolean).join(' ') : m.companyDirectorName || '';
    const phone = (m.contacts || []).filter((c) => /phone|mobile|tel/i.test(c.type || '')).map((c) => `${c.prefix || ''}${c.contact}`).join(', ') || m.mobilePhoneNumber || '';
    const chips = [m.tin && `VÖEN ${m.tin}`, m.taxpayerRegistrationDate && `Uçota alınma: ${dmy(m.taxpayerRegistrationDate)}`, m.criteriaOfBusinessEntity, (m.taxSystems || []).join(', ') || m.taxSystemType, m.taxpayerStatus, m.isRisky ? '⚠ Riskli vergi ödəyicisi' : ''].filter(Boolean);
    const kv = [['Rəhbər', chief], ['Hüquqi ünvan', m.legalAddress], ['Faktiki ünvan', m.actualAddress], ['Əsas fəaliyyət', m.mainActivity], ['Əlavə fəaliyyətlər', (m.additionalActivityCodes || []).join(', ')], ['Telefon', phone], ['E-poçt', m.email],
      ['Dövlət qeydiyyatı', [m.stateRegistrationDocumentNumber, dmy(m.stateRegistrationDocumentIssuedDate)].filter(Boolean).join(' · ')], ['Vergi orqanı', m.taxAuthorityCode], ['Mülkiyyət növü', m.propertyType], ['İşçi sayı (profil)', m.employeeData && m.employeeData.employeeCount],
      ['ƏDV qeydiyyatı', m.vatInfo && (m.vatInfo.prVatOperationsRegDate ? dmy(m.vatInfo.prVatOperationsRegDate) : '')], ['Xüsusi vergi rejimi', m.specialTaxRegime ? 'bəli' : ''], ['Ləğv prosesi', m.isTaxPayerInCancellationProcess ? 'bəli — ləğv prosesindədir' : ''],
      ['Fəaliyyətin dayandırılması', m.suspensionStartDate ? `${dmy(m.suspensionStartDate)} – ${dmy(m.suspensionEndDate)}` : '']].filter(([, v]) => v !== '' && v != null);
    const errs = Object.entries(pr.errors || {}).filter(([k]) => k !== 'main');
    return `<section class="blk" id="profile"><h2>Şirkət profili <small>portaldan avtomatik oxunub: ${new Date(pr.at).toLocaleString('az-AZ')}</small><span class="hdr-actions">${refreshBtn('profile')}<button class="ghost" id="profPortal">Portalda aç</button></span></h2>
      <div class="company"><div class="logo">${esc((compName() || 'A').replace(/["«»]/g, '').trim().slice(0, 1))}</div>
        <div><h3>${esc(compName() || '—')}</h3><div>${chief ? 'Rəhbər: ' + esc(chief) : ''}</div><div class="chips">${chips.map((c) => `<span>${esc(c)}</span>`).join('')}</div></div></div>
      <dl class="kvgrid">${kv.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
      <div class="tabsrow" id="ptabs">${PTABS.map(([id, n], i) => `<button data-i="${i}" class="${i === ptab ? 'on' : ''}">${esc(n)}<em>${pr.errors && pr.errors[id] ? '!' : (pr[id] || []).length}</em></button>`).join('')}</div>
      <div id="ptab"></div>
      ${errs.length ? `<p class="lead" style="margin-top:8px">${errs.map(([k, v]) => `${esc((PTABS.find((x) => x[0] === k) || [, k])[1])}: ${esc(v)}`).join(' · ')}</p>` : ''}</section>`;
  }
  function renderProfileTab(i) { const pr = S.profile; if (!pr || !$('ptab')) return; ptab = i; const [id, name, fn] = PTABS[i]; $('ptab').innerHTML = `<div class="ptab-head">${esc(name)}</div>${pr.errors && pr.errors[id] ? `<div class="empty">${esc(pr.errors[id])}</div>` : fn(pr)}`; }

  // ------------------------------------------------------------------ bəyannamələr
  let declYear = 'all';
  function secDecls() {
    const years = [...new Set(DECLS.map((d) => d.year))].sort((a, b) => b - a);
    const list = declYear === 'all' ? DECLS : DECLS.filter((d) => d.year === +declYear);
    const conf = list.filter(isConf), viol = list.filter(isViol), wait = list.filter((d) => d.status === 'FILED' || d.status === 'SUBMITTED');
    const byTax = new Map();
    list.filter((d) => isConf(d) || isViol(d)).forEach((d) => { if (!byTax.has(d.tax)) byTax.set(d.tax, []); byTax.get(d.tax).push(d); });
    const howCnt = (L) => { const m = { Adi: 0, Kameral: 0, Analoji: 0, Audit: 0 }; L.forEach((d) => { m[d.how] = (m[d.how] || 0) + 1; }); return m; };
    const miss = declYear === 'all' ? missing : missing.filter((m) => m.key.startsWith(String(declYear)));
    const MS = { missing: ['Təqdim edilməyib — müddət keçib', 'bad'], draftLate: ['Qaralamada qalıb — müddət keçib', 'bad'], draft: ['Qaralamadadır', 'warn'], due: ['Təqdim vaxtıdır — son tarix gəlməyib', 'info'], unknown: ['Yoxlanılmadı — həmin ilin siyahısı alınmadı', 'info'] };
    const hc = howCnt(conf);
    return `<section class="blk" id="decls"><h2>Bəyannamələr <small>yalnız təsdiqlənmiş və uyğunsuzluqda olanlar</small></h2>
      <div class="years">${['all', ...years].map((y) => `<button data-y="${y}" class="${String(declYear) === String(y) ? 'on' : ''}">${y === 'all' ? 'Bütün illər' : y}</button>`).join('')}</div>
      <div class="dstat">
        <button class="dbig ok" data-grp="conf"><span>Təsdiqlənmiş</span><b>${conf.length}</b><small>Adi ${hc.Adi} · Kameral ${hc.Kameral} · Analoji ${hc.Analoji}${hc.Audit ? ' · Audit ' + hc.Audit : ''}</small></button>
        <button class="dbig ${viol.length ? 'bad' : 'ok'}" data-grp="viol"><span>Uyğunsuzluq</span><b>${viol.length}</b><small>${viol.length ? 'basın — hansı bəyannamədə və hansı vəziyyətdə' : 'uyğunsuzluq aşkar edilməyib'}</small></button>
        ${wait.length ? `<button class="dbig" data-grp="wait"><span>Təsdiq gözləyir</span><b>${wait.length}</b><small>portalda yoxlamadadır</small></button>` : ''}
      </div>
      <div class="board">${[...byTax].sort((a, b) => b[1].length - a[1].length).map(([tax, L]) => { const c = L.filter(isConf), v = L.filter(isViol), h = howCnt(c); return `
        <div class="taxcard"><h4>${esc(tax)} <small>${L.length}</small></h4>
          <div class="hows">
            <button data-tax="${esc(tax)}" data-grp="conf"><i class="dot ok"></i>Təsdiqlənmiş <b>${c.length}</b></button>
            ${v.length ? `<button data-tax="${esc(tax)}" data-grp="viol"><i class="dot bad"></i>Uyğunsuzluq <b>${v.length}</b></button>` : ''}
          </div>
          <div class="howline">${['Adi', 'Kameral', 'Analoji', 'Audit'].filter((k) => h[k]).map((k) => `<button data-tax="${esc(tax)}" data-grp="conf" data-how="${k}">${k} təsdiq <b>${h[k]}</b></button>`).join('')}</div>
        </div>`; }).join('') || '<div class="empty">Seçilmiş dövrdə təsdiqlənmiş bəyannamə yoxdur.</div>'}</div>
      <h3 class="sub3">Qalan / təqdim edilməmiş bəyannamələr <small>${miss.length}</small></h3>
      ${table(['Vergi', 'Dövr', 'Son tarix', 'Vəziyyət'], miss.map((m) => [m.tax, m.period, dmy(m.due), { html: `<span class="pill ${MS[m.state][1]}">${MS[m.state][0]}</span>` }]), { empty: 'Təqdim edilməmiş bəyannamə yoxdur.' })}
    </section>`;
  }
  function declList(filter, title, viol) {
    const list = DECLS.filter((d) => (declYear === 'all' || d.year === +declYear) && filter(d)).sort((a, b) => periodSort(b).localeCompare(periodSort(a)));
    const howPill = (d) => `<span class="pill ${d.how === 'Kameral' ? 'warn' : d.how === 'Analoji' ? 'info' : 'ok'}">${d.how} təsdiq</span>${d.how === 'Adi' && d.typeName ? `<small class="mut"> · ${esc(d.typeName)}</small>` : ''}`;
    modal(`${title} — ${list.length} bəyannamə`, viol
      ? table(['Vergi', 'Dövr', 'Növ', 'Uyğunsuzluq', 'Status', 'Tarix', 'Məbləğ', 'Sənəd №', ''], list.map((d) => [d.tax, periodLabel(d), d.typeName, { html: `<span class="pill bad">${esc(d.vvsName)}</span>${d.controlErrors && d.controlErrors.length ? `<div class="mut small">${d.controlErrors.map(esc).join('<br>')}</div>` : ''}` }, d.statusName, dmy(d.submitted), d.amount == null ? '' : d.amount, d.reg, { html: d.id ? `<button class="link" data-pdf="${esc(d.id)}">PDF aç</button>` : '' }]), { nums: [6] })
      : table(['Vergi', 'Dövr', 'Necə təsdiqlənib', 'Status', 'Tarix', 'Məbləğ', 'Sənəd №', ''], list.map((d) => [d.tax, periodLabel(d), { html: howPill(d) }, d.statusName, dmy(d.statusDate || d.submitted), d.amount == null ? '' : d.amount, d.reg, { html: d.id ? `<button class="link" data-pdf="${esc(d.id)}">PDF aç</button>` : '' }]), { nums: [5] }));
    document.querySelectorAll('[data-pdf]').forEach((b) => b.onclick = () => openPdf(b.dataset.pdf));
  }

  // ------------------------------------------------------------------ gəlir · xərc · mənfəət
  let showCmp = false;
  function secFin() {
    if (!A || !FIN) return `<section class="blk" id="fin"><h2>Gəlir · xərc · mənfəət</h2><div class="callout warn"><div><b>Qaimələr oxunmadı</b>Portala daxil olub İlkin audit-i yenidən hazırlayın.</div></div></section>`;
    const F = FIN;
    const fv = (sid, code, k = 0) => (S.filed ? n0(((S.filed.values[sid] || {})[code] || [])[k]) : 0);
    const decl = S.filed ? (S.filed.type === 'profit' ? { inc: fv('incomes', '218'), exp: fv('expenses', '234'), pro: fv('calc', '237') - fv('calc', '239') } : { inc: fv('incomes', '1223') + fv('incomes', '1223', 1), exp: fv('expenses', '1238') + fv('expenses', '1238', 1), pro: fv('calc', '1241') - fv('calc', '1243') }) : null;
    const incRows = [['Satış — mallar', A.income.goods], ['Satış — iş və xidmətlər', A.income.services], ['Satış — növü göstərilməyən', A.income.unknown], ['Alıcıların qaytardığı mallar', -A.income.returns]].filter(([, v]) => Math.abs(v) > 0.004);
    const expRows = A.expenses.filter((e) => e.amount && e.code !== '221.4').map((e) => [`${e.label}`, e.amount]);
    return `<section class="blk" id="fin"><h2>Gəlir · xərc · mənfəət <small>${esc(perText)} · real sistem məlumatı: qaimələr, aktlar, gömrük, maaş</small></h2>
      <div class="fin3"><div class="inc"><span>Gəlir (ƏDV-siz)</span><b>${money(F.income)}</b><small>${A.counts.sales} satış qaiməsi</small></div>
        <div class="exp"><span>Xərc</span><b>${money(F.expense)}</b><small>maya dəyəri ${money(F.cogs)} + digər ${money(F.otherExp)}</small></div>
        <div class="pro"><span>${F.profit >= 0 ? 'Mənfəət' : 'Zərər'}</span><b>${money(Math.abs(F.profit))}</b><small>rentabellik ${F.income ? Math.round((F.profit / F.income) * 1000) / 10 : 0}%</small></div>
        <div class="tax"><span>Mənfəət vergisi (20%, təxmini)</span><b>${money(F.tax)}</b><small>vergitutma rejiminizə görə fərqlənə bilər</small></div></div>
      <div class="split2">
        <div>${table(['Gəlir', 'Məbləğ'], incRows, { nums: [1], total: ['Cəmi gəlir', F.income] })}</div>
        <div>${table(['Xərc', 'Məbləğ'], [
          ['Satılan malların maya dəyəri', F.cogs], ...expRows,
        ], { nums: [1], total: ['Cəmi xərc', F.expense] })}
        <p class="lead small" style="margin-top:8px">Maya dəyəri = dövrün əvvəlinə mal qalığı ${money(F.open)} + dövrdə alınan mallar ${money(F.buy)} − dövrün sonuna qalıq ${money(F.close)} (mal kodu üzrə, orta çəkili qiymətlə).</p></div>
      </div>
      <h3 class="sub3">Aylar üzrə</h3>
      ${table(['Ay', 'Gəlir', 'Xərc (qaimələr + maaş)', 'Fərq'], A.months.map((m) => [`${MONTHS[+m.key.slice(5) - 1]} ${m.key.slice(0, 4)}`, m.income, m.expense, m.income - m.expense]), { nums: [1, 2, 3] })}
      <div class="split2" style="margin-top:14px"><div><h3 class="sub3">Əsas alıcılar</h3>${table(['Alıcı', 'VÖEN', 'Məbləğ'], (A.customers || []).map((c) => [c.name, c.tin, c.amount]), { nums: [2] })}</div>
        <div><h3 class="sub3">Əsas təchizatçılar</h3>${table(['Təchizatçı', 'VÖEN', 'Məbləğ'], (A.suppliers || []).map((c) => [c.name, c.tin, c.amount]), { nums: [2] })}</div></div>
      ${decl ? `<details class="more" ${showCmp ? 'open' : ''} id="cmpd"><summary>Təqdim edilmiş ${S.filed.type === 'profit' ? 'mənfəət' : 'gəlir'} bəyannaməsi ilə müqayisə (${S.filed.year})</summary>
        ${table(['', 'Real (sistem)', 'Bəyannamədə', 'Fərq'], [['Gəlir', F.income, decl.inc, F.income - decl.inc], ['Xərc', F.expense, decl.exp, F.expense - decl.exp], ['Mənfəət', F.profit, decl.pro, F.profit - decl.pro]], { nums: [1, 2, 3] })}
        <p class="lead small">Bəyannamə № ${esc(S.filed.reg)} · ${esc(S.filed.typeName)} · ${esc(S.filed.statusName)}. Fərq böyükdürsə — qaiməsiz gəlir/xərc və ya bəyannamədə səhv ola bilər.</p></details>` : ''}
    </section>`;
  }

  // ------------------------------------------------------------------ mal qalığı
  let stockQ = '', stockOnly = 'rest', stockKind = 'all';
  function secStock() {
    const q = fold(stockQ);
    const list = INV.filter((i) => (stockKind === 'all' || (stockKind === 'svc' ? i.svc : !i.svc)) && (stockOnly === 'all' || (stockOnly === 'rest' ? Math.abs(i.rest) > 0.0005 : i.rest < -0.0005)) && (!q || fold(i.name + ' ' + i.code + ' ' + i.altNames.join(' ')).includes(q)));
    const neg = INV.filter((i) => i.rest < -0.0005);
    const totV = INV.reduce((s, i) => s + Math.max(0, i.restV), 0);
    const cu = S.customs || [], cm = S.customsMeta;
    return `<section class="blk" id="stock"><h2>Mal qalığı <small>mal kodu üzrə · ${dmy(S.histFrom)} – ${dmy(S.today)} · bütün gələn qaimələr + alış aktları + gömrük idxalı − bütün göndərilən qaimələr</small>
      <span class="hdr-actions"><button class="ghost" id="cusRefresh">↻ Gömrükdən oxu</button></span></h2>
      <div class="kpis" style="margin-bottom:12px">${kpi('', 'Qalığın dəyəri', money(totV), `${INV.filter((i) => i.rest > 0.0005).length} mal kodu`, 'stock')}
        ${kpi('', 'Alınıb (dəyər)', money(INV.reduce((s, i) => s + i.inV + i.actV + i.cusV, 0)), `gələn qaimə ${money(INV.reduce((s, i) => s + i.inV, 0))} · akt ${money(INV.reduce((s, i) => s + i.actV, 0))} · gömrük ${money(INV.reduce((s, i) => s + i.cusV, 0))}`, 'stock')}
        ${kpi('', 'Göndərilib (dəyər)', money(INV.reduce((s, i) => s + i.outV, 0)), `göndərilən qaimələr · ${INV.filter((i) => i.outQ).length} kod`, 'stock')}
        ${kpi(neg.length ? 'bad' : 'ok', 'Mənfi qalıq', String(neg.length), neg.length ? 'göndərilən gələndən çoxdur — alış sənədi çatışmır' : 'yoxdur', 'stock')}
        ${kpi(cu.length ? 'ok' : 'warn', 'Gömrük (idxal)', cu.length ? `${cu.length} sətir` : '—', cu.length ? `${esc((cm && cm.src) || '')}${cm && cm.at ? ' · ' + new Date(cm.at).toLocaleDateString('az-AZ') : ''}` : 'e.customs.gov.az-ı açıb «Gömrükdən oxu» basın', 'stock')}</div>
      <div class="toolbar"><input type="search" id="stockQ" placeholder="Mal kodu və ya adı üzrə axtar…" value="${esc(stockQ)}">
        <div class="seg">${[['rest', 'Qalığı olanlar'], ['neg', 'Mənfi qalıq'], ['all', 'Hamısı']].map(([k, t]) => `<button data-so="${k}" class="${stockOnly === k ? 'on' : ''}">${t}</button>`).join('')}</div>
        <div class="seg" title="Qaimədə məhsul qrupu «mal» və ya «xidmət» (99… kodlar). Təchizatçılar bəzən malı xidmət kodu ilə yazır.">${[['all', 'Bütün kodlar'], ['good', 'Mal kodları'], ['svc', 'Xidmət kodları']].map(([k, t]) => `<button data-sk="${k}" class="${stockKind === k ? 'on' : ''}">${t}</button>`).join('')}</div></div>
      ${table(['Mal kodu', 'Mal', 'Ölçü', 'Gələn qaimə', 'Alış aktı', 'Gömrük', 'Göndərilən qaimə', 'Qalıq', 'Orta maya', 'Qalığın dəyəri', 'Son hərəkət'],
        list.slice(0, 2000).map((i) => { const r = [{ html: `<button class="link" data-mv="${esc(i.key)}">${esc(i.code || '—')}</button>` }, { html: `${esc(i.name)}${i.svc ? ' <span class="pill" title="Qaimədə xidmət kodu ilə yazılıb">xidmət kodu</span>' : ''}${i.altNames.length ? `<div class="mut small">${i.altNames.map(esc).join(' · ')}</div>` : ''}` }, { html: `${esc(i.unit)}${i.unitMix ? ' <span class="pill warn" title="Bu kodda fərqli ölçü vahidləri var">!</span>' : ''}` }, { html: qty(i.inQ) }, { html: qty(i.actQ) }, { html: qty(i.cusQ) }, { html: qty(i.outQ) }, { html: `<b class="${i.rest < -0.0005 ? 'neg' : ''}">${qty(i.rest)}</b>` }, i.avg, i.restV, dmy(i.last)]; return r; }),
        { nums: [3, 4, 5, 6, 7, 8, 9], total: ['Cəmi', `${list.length} kod`, '', '', '', '', '', '', '', list.reduce((s, i) => s + Math.max(0, i.restV), 0), ''], empty: stockOnly === 'neg' ? 'Mənfi qalıq yoxdur.' : 'Qaimə sətirlərində mal tapılmadı.' })}
      ${list.length > 2000 ? `<p class="lead">İlk 2000 kod göstərilir — axtarışdan istifadə edin və ya Excel-ə yükləyin.</p>` : ''}
    </section>`;
  }
  const DIRN = { in: 'Gələn qaimə', act: 'Alış aktı', cus: 'Gömrük idxalı', retIn: 'Gələn qaimə (qaytarma)', out: 'Göndərilən qaimə', retOut: 'Göndərilən qaimə (qaytarma)' };
  function moveHistory(k) {
    const it = INV.find((x) => x.key === k); if (!it) return;
    let run = 0;
    const rows = MV.filter((m) => m.key === k).map((m) => { const s = m.dir === 'out' || m.dir === 'retOut' ? -1 : 1; run += s * m.q; return [dmy(m.d), DIRN[m.dir] || m.dir, m.doc, m.party, m.name, { html: `<span class="${s < 0 ? 'neg' : 'pos'}">${s < 0 ? '−' : '+'}${qty(m.q)}</span>` }, m.cost, { html: `<b>${qty(run)}</b>` }]; });
    modal(`${it.code || '—'} · ${it.name} — ${rows.length} hərəkət`, table(['Tarix', 'Sənəd', '№', 'Tərəf', 'Ad (sənəddə)', 'Miqdar', 'Dəyər', 'Qalıq'], rows, { nums: [6] }));
  }

  // ------------------------------------------------------------------ daxil olan pullar
  function secCash() {
    const SRC = { filed: ['bəyannamədən', 'ok'], draft: ['qaralamadan', 'info'], auto: ['arxa planda oxundu', 'info'], error: ['oxunmadı', 'bad'], none: ['—', ''] };
    const cell = (y, i) => { const c = y.src[i]; if (!c) return { html: '<span class="mut">—</span>' }; const s = SRC[c.src] || ['', '']; return { html: `${c.v804 == null ? '<span class="mut">—</span>' : money(c.v804)} <span class="pill ${s[1]}" title="${esc(c.error || c.reg || '')}">${s[0]}</span>` }; };
    const last = CASH[CASH.length - 1];
    return `<section class="blk" id="cash"><h2>Daxil olan pullar (hasilat) <small>sadələşdirilmiş bəyannamənin 804-cü sətri — portal bank və POS daxilolmalarından özü doldurur</small><span class="hdr-actions">${refreshBtn('cash')}</span></h2>
      <p class="lead">Hər rüb üçün AMMO sadələşdirilmiş bəyannaməni (varsa — mövcudunu, yoxdursa — arxa planda qaralama yaradıb) oxuyur və 804-cü xananı götürür. Köməkçi qaralama dərhal silinir, heç nə təqdim edilmir.</p>
      ${last ? `<div class="qgrid">${[0, 1, 2, 3].map((i) => { const c = last.src[i]; return `<div><span>${qName(i + 1)} ${last.year}</span><b>${last.q[i] == null ? '—' : money(last.q[i])}</b><small>${c && c.parts && (c.parts.other || c.parts.zone) ? `220.1: ${money(c.parts.main)} · 220.1-1: ${money(c.parts.other)}${c.parts.zone ? ' · zona: ' + money(c.parts.zone) : ''}` : c ? (SRC[c.src] || [''])[0] : 'rüb başa çatmayıb'}</small></div>`; }).join('')}<div class="sum"><span>Daxil olmuş pullar cəmi ${last.year}</span><b>${money(last.q.reduce((a, b) => a + n0(b), 0))}</b><small>bütün dövr: ${money(cashTotal())}</small></div></div>` : ''}
      <div style="margin-top:14px">${table(['İl', '1-ci rüb', '2-ci rüb', '3-cü rüb', '4-cü rüb', 'Cəmi'], CASH.map((y) => [String(y.year), cell(y, 0), cell(y, 1), cell(y, 2), cell(y, 3), y.q.reduce((a, b) => a + n0(b), 0)]), { nums: [5], total: ['Cəmi', '', '', '', '', cashTotal()], empty: 'Hasilat məlumatı yoxdur.' })}</div>
      <h3 class="sub3">Müqayisə: satış qaimələri (ƏDV daxil)</h3>
      ${table(['İl', '1-ci rüb', '2-ci rüb', '3-cü rüb', '4-cü rüb', 'Cəmi'], CASH.map((y) => [String(y.year), ...y.sales, y.sales.reduce((a, b) => a + b, 0)]), { nums: [1, 2, 3, 4, 5] })}
    </section>`;
  }

  function secVat() {
    const v = S.vat;
    if (!v) return `<section class="blk" id="vat"><h2>ƏDV və depozit</h2><div class="callout"><div><b>ƏDV analizi bu hesabata daxil edilməyib</b>AMMO panelində «İlkin audit» → «ƏDV əvəzləşmə analizini daxil et» seçib yenidən hazırlayın.</div></div></section>`;
    const t = v.totals, d = v.deposit;
    return `<section class="blk" id="vat"><h2>ƏDV və depozit <span class="hdr-actions"><button class="ghost" id="vatAcc">ƏDV depozit hesabını aç</button></span></h2>
      <div class="kpis">${kpi('', 'Satış üzrə hesablanmış ƏDV', money(v.outVat), 'bəyannamələr üzrə', 'vat')}${kpi('', 'Alış ƏDV-si (qaimələr)', money(t.vat), 'əvəzləşdirilməli', 'vat')}
        ${kpi('ok', 'Əvəzləşib', money(t.offVat), `${t.pct}%`, 'vat')}${kpi('bad', 'Əvəzləşməyən qalıq', money(t.remaining), '', 'vat')}
        ${kpi('warn', 'Hüququ var, əvəzləşməyib', money(t.rightVat), `${t.rightCount} qaimə`, 'vat')}${kpi('bad', 'Hüququ yoxdur', money(t.noRightVat), `${t.noRightCount} qaimə`, 'vat')}
        ${kpi('', 'Büdcəyə ödənilməli', money(v.payable), v.refund ? `qaytarılmalı: ${money(v.refund)}` : '', 'vat')}
        ${kpi('', 'Depozit qalığı', d && d.closing != null ? money(d.closing) : '—', d ? `mədaxil ${money(d.inSum)} · məxaric ${money(d.outSum)}` : 'depozit oxunmayıb', 'vat')}
        ${kpi('', 'İdxal ƏDV-si (gömrük)', money(t.customsVat), `əvəzləşib ${money(t.customsOff)}`, 'vat')}</div>
      ${(v.notes || []).length ? `<div class="callout warn"><div>${v.notes.map(esc).join('<br>')}</div></div>` : ''}
      <div style="margin-top:14px">${table(['Ay', 'Satış ƏDV-si', 'Əvəzləşən (308)', 'Büdcəyə ödənilməli'], v.months.map((m) => [m.label, m.outVat ?? '', m.declOffVat, m.payable ?? '']), { nums: [1, 2, 3] })}</div></section>`;
  }

  function secDebts() {
    const D = S.debts;
    const head = `<h2>Borclar və artıq ödənişlər ${D && D.at ? `<small>portaldan avtomatik · ${new Date(D.at).toLocaleString('az-AZ')}${D.asOf ? ' · məlumat tarixi ' + dmy(D.asOf) : ''}</small>` : ''}<span class="hdr-actions">${refreshBtn('debts')}<button class="ghost" id="debtOpen">Portalda aç</button></span></h2>`;
    if (!D || !D.totals) return `<section class="blk" id="debts">${head}<div class="callout warn"><div><b>Borc məlumatı oxunmadı</b>${esc((D && D.error) || '')} «Portaldan yenilə» basın.</div></div></section>`;
    const t = D.totals;
    return `<section class="blk" id="debts">${head}
      ${table(['Göstəricilər', 'Cəmi', 'Əsas borc', 'Maliyyə sanksiyası', 'Faiz'], [
        [{ html: '<b>Borc</b>' }, { html: `<b class="${t.debt ? 'neg' : ''}">${money(t.debt)}</b>` }, t.principal, t.sanction, t.faiz],
        ['Artıq ödəmə', t.overpay, '', '', ''],
      ], { nums: [1, 2, 3, 4] })}
      <h3 class="sub3">Büdcə təsnifatı üzrə</h3>
      ${table(['Vergi / ödəniş', 'Kod', 'Əsas borc', 'Sanksiya', 'Faiz', 'Cəmi borc', 'Artıq ödəmə'], D.tax.map((x) => [x.name, x.code, x.principal, x.sanction, x.faiz, x.total, x.overpay]), { nums: [2, 3, 4, 5, 6], empty: 'Borc yoxdur.' })}
      ${D.social && D.social.length ? `<h3 class="sub3">Sosial ödənişlər</h3>${table(['Növ', 'Ödənilməli', 'Bölüşdürülməmiş'], D.social.map((x) => [x.name, x.toPay, x.unallocated]), { nums: [1, 2] })}` : ''}
    </section>`;
  }

  let mailOnlyUnread = false;
  function secMail() {
    const M = S.mail;
    const head = `<h2>Məktublar ${M && M.at ? `<small>portaldan avtomatik · ${new Date(M.at).toLocaleString('az-AZ')}</small>` : ''}<span class="hdr-actions">${refreshBtn('mail')}<button class="ghost" id="mailOpen">Məktubları portalda aç</button></span></h2>`;
    if (!M) return `<section class="blk" id="mail">${head}<div class="empty">Məktublar oxunmadı.</div></section>`;
    const L = (M.list || []).filter((m) => !mailOnlyUnread || !m.read);
    return `<section class="blk" id="mail">${head}
      <div class="kpis" style="margin-bottom:12px">${kpi(M.unread ? 'warn' : 'ok', 'Oxunmamış (vergi orqanından)', String(M.unread), `cəmi ${M.total} məktub (son 2 il)`, 'mail')}${kpi(M.unreadTp ? 'warn' : '', 'Oxunmamış (vergi ödəyicilərindən)', String(M.unreadTp || 0), '', 'mail')}
        ${kpi((M.list || []).some((m) => m.deadline && !m.read) ? 'bad' : '', 'Cavab müddəti olan', String((M.list || []).filter((m) => m.deadline).length), 'son tarixli məktublar', 'mail')}</div>
      <div class="toolbar"><label><input type="checkbox" id="mailUnread" ${mailOnlyUnread ? 'checked' : ''}> yalnız oxunmamışlar</label></div>
      ${table(['Tarix', 'Nömrə', 'Mövzu', 'Göndərən', 'Son tarix', ''], L.map((m) => { const r = [dmy(m.date), m.reg, { html: `${m.read ? '' : '<span class="pill warn">yeni</span> '}${esc(m.subject)}${m.attach ? ' 📎' : ''}` }, m.from, m.deadline ? dmy(m.deadline) : '', { html: `<button class="link" data-msg="${esc(m.id)}">Aç</button>` }]; if (!m.read) r._cls = 'lvl0'; return r; }), { empty: mailOnlyUnread ? 'Oxunmamış məktub yoxdur.' : 'Məktub yoxdur.' })}
    </section>`;
  }

  let staffQ = '';
  function secStaff() {
    const st = S.staff; const pr = A && A.payroll;
    const list = st ? st.list.filter((p) => !staffQ || fold(p.name + ' ' + p.position + ' ' + p.pin).includes(fold(staffQ))) : [];
    const byPos = new Map(); (st ? st.list : []).forEach((p) => byPos.set(p.position || '—', (byPos.get(p.position || '—') || 0) + 1));
    const mismatch = st && st.voen && S.tin && String(st.voen) !== String(S.tin);
    return `<section class="blk" id="staff"><h2>İşçilər</h2>
      ${!st || mismatch ? `<div class="callout"><div><b>İşçilərin vəzifələri ilə siyahısı (ƏMAS)</b>${mismatch ? `Son göndərilən siyahı başqa VÖEN-ə aiddir (${esc(st.voen)}). ` : ''}eroom.e-social.gov.az-da sağdakı «AMMO ƏMAS» panelində «👥 İşçiləri İlkin audit-ə göndər» basın — siyahı bura özü düşəcək.</div><button class="ghost go" id="emasOpen">ƏMAS-ı aç</button></div>` : ''}
      <div class="kpis">${kpi('', 'Qüvvədə olan müqavilə (ƏMAS)', st && !mismatch ? String(st.list.length) : '—', st && !mismatch ? esc(st.org || '') : '', 'staff')}
        ${kpi('', 'Muzdlu işçi (vahid bəyannamə)', pr ? String(pr.employees) : '—', pr ? `orta aylıq: ${pr.avgEmployees || 0}` : '', 'staff')}
        ${kpi('', 'Əmək haqqı fondu', pr ? money(pr.salary) : '—', pr ? `DSMF (işəgötürən): ${money(pr.social)}` : '', 'staff')}</div>
      ${st && !mismatch ? `<div class="st" style="margin:12px 0">${[...byPos].sort((a, b) => b[1] - a[1]).map(([p, c]) => `<button data-pos="${esc(p)}">${esc(p)} <b>${c}</b></button>`).join('')}</div>
        <div class="toolbar"><input type="search" id="staffQ" placeholder="Ad, vəzifə və ya FİN üzrə axtar…" value="${esc(staffQ)}"></div>
        <div class="staff">${list.map((p) => `<div class="person"><div class="av">${esc((p.name || '?').slice(0, 1))}</div><div><b>${esc(p.name)}</b><small>${esc(p.position || '—')}${p.salary ? ' · ' + money(p.salary) + ' ₼' : ''}<br>${esc(p.pin)}${p.begin ? ' · ' + esc(p.begin) + '-dən' : ''}</small></div></div>`).join('')}</div>` : ''}
    </section>`;
  }

  // ------------------------------------------------------------------ render
  function render() {
    recalcStock(); FIN = finance(); CASH = cashByYear();
    $('main').innerHTML = secOverview() + secProfile() + secDecls() + secFin() + secStock() + secCash() + secVat() + secDebts() + secMail() + secStaff();
    renderNav(); bind();
    document.querySelectorAll('section.blk').forEach((s) => io.observe(s));
  }
  function rerender(id, fn) { const el = document.getElementById(id); if (!el) return; const tmp = document.createElement('div'); tmp.innerHTML = fn(); el.replaceWith(tmp.firstElementChild); bind(); io.observe(document.getElementById(id)); renderNav(); }
  async function refresh(what, btn) {
    const old = btn ? btn.textContent : ''; if (btn) { btn.disabled = true; btn.textContent = 'Oxunur…'; }
    try {
      const data = await portal('AMMO_AUDIT_API', { op: what, tin: S.tin, years: CASH.map((y) => y.year) });
      if (what === 'profile') S.profile = data; else if (what === 'debts') S.debts = data; else if (what === 'mail') S.mail = data; else if (what === 'cash') S.cash = data;
      await save(); render(); toast('Yeniləndi — məlumat portaldan oxundu.');
    } catch (e) { toast('Yenilənmədi: ' + e.message); if (btn) { btn.disabled = false; btn.textContent = old; } }
  }
  function bind() {
    document.querySelectorAll('[data-go]').forEach((b) => b.onclick = () => document.getElementById(b.dataset.go).scrollIntoView({ behavior: 'smooth' }));
    document.querySelectorAll('[data-refresh]').forEach((b) => b.onclick = () => refresh(b.dataset.refresh, b));
    const pt = $('ptabs'); if (pt) { pt.querySelectorAll('button').forEach((b) => b.onclick = () => { pt.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); renderProfileTab(+b.dataset.i); }); renderProfileTab(ptab); }
    if ($('profPortal')) $('profPortal').onclick = () => openUrl(PORTAL + '/eportal/profile');
    document.querySelectorAll('#decls [data-y]').forEach((b) => b.onclick = () => { declYear = b.dataset.y; rerender('decls', secDecls); });
    document.querySelectorAll('#decls [data-grp]').forEach((b) => b.onclick = () => {
      const tax = b.dataset.tax, how = b.dataset.how, g = b.dataset.grp;
      const f = g === 'conf' ? isConf : g === 'viol' ? isViol : (d) => d.status === 'FILED' || d.status === 'SUBMITTED';
      declList((d) => f(d) && (!tax || d.tax === tax) && (!how || d.how === how), `${tax ? tax + ' · ' : ''}${g === 'conf' ? (how ? how + ' təsdiq' : 'Təsdiqlənmiş') : g === 'viol' ? 'Uyğunsuzluq' : 'Təsdiq gözləyir'}`, g === 'viol');
    });
    if ($('cmpd')) $('cmpd').ontoggle = (e) => { showCmp = e.target.open; };
    if ($('stockQ')) $('stockQ').oninput = (e) => { stockQ = e.target.value; clearTimeout(bind.t); bind.t = setTimeout(() => { rerender('stock', secStock); const q = $('stockQ'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }, 250); };
    document.querySelectorAll('#stock [data-so]').forEach((b) => b.onclick = () => { stockOnly = b.dataset.so; rerender('stock', secStock); });
    document.querySelectorAll('#stock [data-sk]').forEach((b) => b.onclick = () => { stockKind = b.dataset.sk; rerender('stock', secStock); });
    document.querySelectorAll('#stock [data-mv]').forEach((b) => b.onclick = () => moveHistory(b.dataset.mv));
    if ($('cusRefresh')) $('cusRefresh').onclick = () => customsRefresh($('cusRefresh'));
    if ($('staffQ')) $('staffQ').oninput = (e) => { staffQ = e.target.value; clearTimeout(bind.s); bind.s = setTimeout(() => { rerender('staff', secStaff); const q = $('staffQ'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }, 250); };
    document.querySelectorAll('#staff [data-pos]').forEach((b) => b.onclick = () => { staffQ = b.dataset.pos; rerender('staff', secStaff); });
    if ($('mailUnread')) $('mailUnread').onchange = (e) => { mailOnlyUnread = e.target.checked; rerender('mail', secMail); };
    document.querySelectorAll('[data-msg]').forEach((b) => b.onclick = () => openUrl(PORTAL + '/eportal/messages/view/' + encodeURIComponent(b.dataset.msg)));
    if ($('vatAcc')) $('vatAcc').onclick = () => openUrl(PORTAL + '/eportal/vat-account');
    if ($('debtOpen')) $('debtOpen').onclick = () => openUrl(PORTAL + '/eportal/budget/liabilities');
    if ($('mailOpen')) $('mailOpen').onclick = () => openUrl(PORTAL + '/eportal/messages');
    if ($('emasOpen')) $('emasOpen').onclick = () => openUrl('https://eroom.e-social.gov.az/#ammo-staff');
  }
  async function customsRefresh(btn) {
    btn.disabled = true; const old = btn.textContent; btn.textContent = 'Oxunur…';
    try {
      const r = await chrome.runtime.sendMessage({ type: 'AMMO_GMR_REPORT', from: S.histFrom || P.fromISO, to: S.today });
      if (!r || !r.ok) {
        if (r && r.error === 'no_tab') { toast('e.customs.gov.az açıq deyil — açılır. ASAN İmza ilə daxil olun və yenidən «Gömrükdən oxu» basın.', 9000); openUrl('https://e.customs.gov.az/'); }
        else toast(r && r.error === 'login' ? 'e.customs.gov.az-da sessiya bitib — yenidən daxil olun.' : 'Gömrük hesabatı alınmadı: ' + ((r && r.error) || ''));
        return;
      }
      const rows = r.parts.flatMap((p) => ST.customsFromXml(p.text, S.tin));
      S.customs = rows; S.customsMeta = { at: Date.now(), src: 'e.customs (avtomatik)', range: { from: S.histFrom, to: S.today } };
      await chrome.storage.local.set({ ['ammo_customs_' + TIN]: { at: Date.now(), tin: S.tin, rows, src: S.customsMeta.src }, [key]: S });
      render(); toast(`Gömrük: ${rows.length} idxal sətri əlavə edildi — mal qalığı yeniləndi.`);
    } catch (e) { toast('Gömrük oxunmadı: ' + e.message); }
    finally { btn.disabled = false; btn.textContent = old; }
  }
  // ƏMAS işçiləri və gömrük başqa pəncərədən gələndə səhifə özü yenilənsin
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    let changed = false;
    if (ch['ammo_emas_staff_last'] || ch['ammo_emas_staff_' + TIN]) { const v = (ch['ammo_emas_staff_' + TIN] || ch.ammo_emas_staff_last).newValue; if (v && v.list) { S.staff = v; changed = true; } }
    const cusCh = ch['ammo_customs_' + TIN] || ch.ammo_customs_last;
    if (cusCh && cusCh.newValue && Array.isArray(cusCh.newValue.rows) && (!cusCh.newValue.tin || String(cusCh.newValue.tin) === String(S.tin))) { const v = cusCh.newValue; if (JSON.stringify(v.rows) !== JSON.stringify(S.customs)) { S.customs = v.rows; S.customsMeta = { at: v.at || Date.now(), src: v.src || '', range: v.range || null }; changed = true; } }
    if (changed) { save(); render(); toast('Yeni məlumat gəldi — səhifə yeniləndi.'); }
  });

  // ------------------------------------------------------------------ Excel
  $('xlsx').onclick = () => {
    const H = (v) => ({ v, s: 'h' }), N = (v) => ({ v: r2(v), s: 'n2' });
    const sheets = [];
    const d = S.debts && S.debts.totals;
    sheets.push({ name: 'Xülasə', autoFilter: false, maxWidth: 60, rows: [[H('Göstərici'), H('Dəyər')], ['Şirkət', compName()], ['VÖEN', S.tin], ['Dövr', perText],
      ['Gəlir', FIN ? N(FIN.income) : ''], ['Xərc', FIN ? N(FIN.expense) : ''], ['Satılan malın maya dəyəri', FIN ? N(FIN.cogs) : ''], ['Mənfəət / zərər', FIN ? N(FIN.profit) : ''],
      ['Daxil olan pullar (804)', N(cashTotal())], ['Mal qalığının dəyəri', N(INV.reduce((s, i) => s + Math.max(0, i.restV), 0))],
      ['Təsdiqlənmiş bəyannamə', DECLS.filter(isConf).length], ['Uyğunsuzluq', DECLS.filter(isViol).length], ['Təqdim edilməmiş', missLate.length],
      ['Vergi borcu (cəmi)', d ? N(d.debt) : ''], ['  əsas borc', d ? N(d.principal) : ''], ['  maliyyə sanksiyası', d ? N(d.sanction) : ''], ['  faiz', d ? N(d.faiz) : ''], ['Artıq ödəmə', d ? N(d.overpay) : ''],
      ['Oxunmamış məktub', S.mail ? S.mail.unread : '']] });
    const m = PM();
    if (S.profile && S.profile.main) {
      sheets.push({ name: 'Profil', autoFilter: false, maxWidth: 80, rows: [[H('Göstərici'), H('Dəyər')], ['Ad', compName()], ['VÖEN', m.tin], ['Rəhbər', m.chief ? [m.chief.surname, m.chief.name, m.chief.middleName].join(' ') : ''], ['Hüquqi ünvan', m.legalAddress], ['Faktiki ünvan', m.actualAddress], ['Uçota alınma', m.taxpayerRegistrationDate], ['Vergitutma sistemi', (m.taxSystems || []).join(', ')], ['Əsas fəaliyyət', m.mainActivity]] });
      sheets.push({ name: 'Bank hesabları', rows: [['Bank', 'Hesab', 'Valyuta', 'Növ', 'Açılma', 'Status'].map(H), ...(S.profile.banks || []).map((b) => [b.bankName, b.number, b.currency, b.type, b.registrationDate, b.status])] });
      sheets.push({ name: 'Mükəlləfiyyətlər', rows: [['Vergi', 'Kod', 'Dövrilik', 'Başlama', 'Bitmə', 'Status'].map(H), ...(S.profile.obligations || []).map((o) => [OBL_TAX[o.taxCode] || '', o.taxCode, PER_CODE[o.taxPeriodCode] || o.taxPeriodCode, o.startDate, o.endDate || '', o.status])] });
    }
    sheets.push({ name: 'Bəyannamələr', rows: [['Vergi', 'Dövr', 'Necə təsdiqlənib', 'Növ', 'Status', 'Uyğunsuzluq', 'Tarix', 'Məbləğ', 'Sənəd №'].map(H), ...DECLS.filter((x) => isConf(x) || isViol(x)).sort((a, b) => periodSort(a).localeCompare(periodSort(b))).map((x) => [x.tax, periodLabel(x), x.how ? x.how + ' təsdiq' : '', x.typeName, x.statusName, x.violation ? x.vvsName : '', dmy(x.statusDate || x.submitted), x.amount == null ? '' : N(x.amount), x.reg])], maxWidth: 40 });
    sheets.push({ name: 'Qalan bəyannamələr', rows: [['Vergi', 'Dövr', 'Son tarix', 'Vəziyyət'].map(H), ...missing.map((x) => [x.tax, x.period, dmy(x.due), { missing: 'Təqdim edilməyib', draftLate: 'Qaralamada (gecikib)', draft: 'Qaralamada', due: 'Vaxtı var', unknown: 'Yoxlanılmadı' }[x.state]])] });
    if (A) sheets.push({ name: 'Gəlir-xərc', autoFilter: false, rows: [[H('Maddə'), H('Məbləğ')], ['Gəlir — mallar', N(A.income.goods)], ['Gəlir — xidmətlər', N(A.income.services)], ['Alıcı qaytarmaları', N(-A.income.returns)], ['Cəmi gəlir', N(FIN.income)], [''], ['Satılan malın maya dəyəri', N(FIN.cogs)], ...A.expenses.filter((e) => e.amount && e.code !== '221.4').map((e) => [e.label, N(e.amount)]), ['Cəmi xərc', N(FIN.expense)], ['Mənfəət', N(FIN.profit)]] });
    sheets.push({ name: 'Mal qalığı', maxWidth: 50, rows: [['Mal kodu', 'Mal', 'Kod növü', 'Ölçü', 'Gələn qaimə', 'Alış aktı', 'Gömrük', 'Göndərilən qaimə', 'Qalıq', 'Orta maya', 'Qalığın dəyəri', 'Göndərilən dəyər', 'Son hərəkət'].map(H), ...INV.map((i) => [i.code, i.name, i.svc ? 'xidmət' : 'mal', i.unit, i.inQ, i.actQ, i.cusQ, i.outQ, i.rest, N(i.avg), N(i.restV), N(i.outV), i.last])] });
    sheets.push({ name: 'Mal hərəkəti', maxWidth: 50, rows: [['Tarix', 'Sənəd', '№', 'Tərəf', 'Mal kodu', 'Mal', 'Ölçü', 'Miqdar', 'Dəyər'].map(H), ...MV.map((x) => [x.d, DIRN[x.dir] || x.dir, x.doc, x.party, x.code, x.name, x.unit, (x.dir === 'out' || x.dir === 'retOut' ? -1 : 1) * x.q, N(x.cost)])] });
    sheets.push({ name: 'Daxil olan pullar', autoFilter: false, rows: [['İl', '1-ci rüb', '2-ci rüb', '3-cü rüb', '4-cü rüb', 'Cəmi'].map(H), ...CASH.map((y) => [y.year, ...y.q.map((v) => (v == null ? '' : N(v))), N(y.q.reduce((a, b) => a + n0(b), 0))])] });
    if (S.debts && S.debts.tax) sheets.push({ name: 'Borclar', rows: [['Vergi', 'Kod', 'Əsas borc', 'Sanksiya', 'Faiz', 'Cəmi', 'Artıq ödəmə'].map(H), ...S.debts.tax.map((x) => [x.name, x.code, N(x.principal), N(x.sanction), N(x.faiz), N(x.total), N(x.overpay)])] });
    if (S.mail) sheets.push({ name: 'Məktublar', rows: [['Tarix', 'Nömrə', 'Mövzu', 'Göndərən', 'Son tarix', 'Oxunub'].map(H), ...S.mail.list.map((x) => [dmy(x.date), x.reg, x.subject, x.from, x.deadline ? dmy(x.deadline) : '', x.read ? 'bəli' : 'xeyr'])] });
    if (S.staff) sheets.push({ name: 'İşçilər', rows: [['Ad', 'FİN', 'Vəzifə', 'Maaş', 'Başlama'].map(H), ...S.staff.list.map((p) => [p.name, p.pin, p.position, N(p.salary), p.begin])] });
    AMMO_XLSX.download(sheets, `AMMO_Ilkin_audit_${S.tin || ''}_${P.fromISO}_${P.toISO}.xlsx`);
  };
  $('print').onclick = () => window.print();
  render();
})();
