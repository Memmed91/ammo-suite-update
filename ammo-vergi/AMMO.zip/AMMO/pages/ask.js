/* AMMO — «Sənəd dövriyyəsinə göndərilsin?» pəncərəsi (v1.16)
 * 1) Chrome-da sənəd yüklənəndə background.js bu kiçik pəncərəni açır (yükləmə ID-ləri storage.session-da).
 * 2) Windows köməkçisi «Bəli»dən sonra bu səhifəni ?go=1&path=… ilə açır (Edge, Firefox, WhatsApp və s.).
 * «Bəli» → fayl diskdən (və ya mənbə ünvanından) oxunur, gələnlər qutusuna yazılır və Sənəd dövriyyəsi paneli açılır. */
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const P = new URLSearchParams(location.search);
const GO = P.get('go') === '1';
const items = [];
let busy = false, left = 90, timer = null;

const baseName = (p) => String(p || '').split(/[\\/]/).pop();
const extOf = (n) => (String(n).toLowerCase().match(/\.([a-z0-9]+)$/) || [, ''])[1];
const fileIcon = (n) => { const e = extOf(n); return e === 'pdf' ? '📕' : /docx?|odt|rtf/.test(e) ? '📘' : /xlsx?|csv|ods/.test(e) ? '📗' : /jpe?g|png|webp|bmp|tiff?/.test(e) ? '🖼️' : '📄'; };
const fmtSize = (b) => (!b || b < 0 ? '' : b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
const hostOf = (u) => { try { const h = new URL(u).hostname; return h || ''; } catch (e) { return ''; } };
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

function render() {
  const multi = items.length > 1;
  $('#list').innerHTML = items.map((it, i) => `<div class="it ${it.done ? 'done' : ''} ${it.err ? 'err' : ''}">
      ${multi && !it.done ? `<input type="checkbox" data-i="${i}" ${it.on !== false ? 'checked' : ''}>` : ''}
      <span class="ic">${it.done ? '✅' : fileIcon(it.name)}</span>
      <div class="tx"><b title="${esc(it.path || it.name)}">${esc(it.name)}</b><small>${[fmtSize(it.size), it.src].filter(Boolean).map(esc).join(' · ')}${it.err ? ' · <span style="color:var(--bad)">oxunmadı</span>' : ''}</small></div></div>`).join('');
  document.querySelectorAll('[data-i]').forEach((el) => (el.onchange = () => { items[+el.dataset.i].on = el.checked; }));
  const srcs = [...new Set(items.map((x) => x.src).filter(Boolean))];
  $('#src').textContent = srcs.length ? 'Mənbə: ' + srcs.join(', ') : 'AMMO';
  $('#q').textContent = multi ? `Bu ${items.length} faylı Sənəd dövriyyəsi panelinə göndərmək istəyirsiniz?` : 'Bunu Sənəd dövriyyəsi panelinə göndərmək istəyirsiniz?';
}

// ---------------------------------------------------------------- Chrome yükləmələri (background-dan)
async function syncQueue() {
  let q = [];
  try { q = (await chrome.storage.session.get('ammo_ask_q')).ammo_ask_q || []; } catch (e) { /* */ }
  for (const id of q) {
    if (items.some((x) => x.dl === id)) continue;
    const [it] = await chrome.downloads.search({ id });
    if (!it || it.state !== 'complete' || it.exists === false) continue;
    items.push({ dl: it.id, name: baseName(it.filename), path: it.filename, size: it.fileSize || it.totalBytes, url: it.finalUrl || it.url, mime: it.mime, src: hostOf(it.referrer) || hostOf(it.finalUrl || it.url) || 'Chrome' });
  }
  if (!items.length && !GO) { closeMe(); return; }
  render(); left = 90;
}

// ---------------------------------------------------------------- faylın oxunması
function fileUrl(path) {
  const p = String(path).replace(/\\/g, '/');
  const enc = p.split('/').map((seg, i) => (i === 0 && /^[A-Za-z]:$/.test(seg) ? seg : encodeURIComponent(seg))).join('/');
  return 'file://' + (p.startsWith('/') ? '' : '/') + enc;
}
function readLocal(path) {
  return new Promise((res, rej) => {
    const x = new XMLHttpRequest();
    x.open('GET', fileUrl(path)); x.responseType = 'blob';
    x.onload = () => (x.response && x.response.size ? res(x.response) : rej(new Error('Fayl boşdur və ya oxunmadı')));
    x.onerror = () => rej(new Error('Fayl diskdən oxunmadı'));
    x.send();
  });
}
async function getBlob(it) {
  let err = null;
  if (it.file) return it.file;
  if (it.path) {
    if (await chrome.extension.isAllowedFileSchemeAccess()) { try { return await readLocal(it.path); } catch (e) { err = e; } }
    else err = Object.assign(new Error('Fayllara giriş icazəsi yoxdur'), { noaccess: true });
  }
  if (it.url && /^(https?|data):/i.test(it.url)) {
    for (const credentials of ['include', 'omit']) {
      try {
        const r = await fetch(it.url, { credentials });
        if (r.ok) { const b = await r.blob(); if (b.size && !(/text\/html/.test(b.type) && !/html?$/.test(extOf(it.name)))) return b; }
      } catch (e) { /* CORS və ya sessiya bitib */ }
    }
  }
  throw err || new Error('Fayl götürülə bilmədi');
}

// ---------------------------------------------------------------- panelə ötürmə
async function routeToPanel() {
  const base = chrome.runtime.getURL('pages/dovriyye.html');
  let tab = null;
  try { const c = (await chrome.runtime.getContexts({ contextTypes: ['TAB'] })).find((x) => x.documentUrl && x.documentUrl.startsWith(base)); if (c) tab = { id: c.tabId, windowId: c.windowId }; } catch (e) { /* köhnə Chrome */ }
  if (!tab) { try { const t = (await chrome.tabs.query({ url: base + '*' }))[0]; if (t) tab = { id: t.id, windowId: t.windowId }; } catch (e) { /* */ } }
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    try { await chrome.runtime.sendMessage({ type: 'AMMO_DD_INBOX' }); } catch (e) { /* BroadcastChannel kifayətdir */ }
    return;
  }
  const url = base + '?key=inbox';
  const wins = await chrome.windows.getAll({ windowTypes: ['normal'] });
  const w = wins.find((x) => x.focused) || wins[wins.length - 1];
  if (w) { await chrome.tabs.create({ windowId: w.id, url, active: true }); await chrome.windows.update(w.id, { focused: true, state: w.state === 'minimized' ? 'normal' : undefined }); }
  else await chrome.windows.create({ url, type: 'normal', focused: true });
}

async function send() {
  if (busy) return; busy = true; stopTimer();
  $('#yes').disabled = $('#no').disabled = true; $('#status').textContent = 'Göndərilir…';
  const todo = items.filter((x) => x.on !== false && !x.done);
  const fail = [];
  for (const it of todo) {
    try {
      const blob = await getBlob(it);
      await DD_INBOX.put({ id: uid(), name: it.name, type: blob.type || it.mime || '', blob, at: Date.now(), src: it.src || '' });
      it.done = true; it.err = '';
    } catch (e) { it.err = e.message || String(e); it.noaccess = !!e.noaccess; fail.push(it); }
  }
  render();
  if (items.some((x) => x.done)) { try { await routeToPanel(); } catch (e) { /* */ } }
  if (!fail.length) { await clearQueue(); closeMe(); return; }
  showFallback(fail);
  busy = false; $('#no').disabled = false; $('#no').textContent = 'Bağla';
  $('#yes').classList.add('hidden'); $('#status').textContent = '';
}

function showFallback(fail) {
  const noacc = fail.some((x) => x.noaccess);
  const fb = $('#fallback'); fb.classList.remove('hidden');
  fb.innerHTML = `${noacc ? '<b>Bir dəfəlik ayar lazımdır.</b> AMMO-nun faylı diskdən özü götürməsi üçün genişlənmənin səhifəsində <b>«Fayl URL-lərinə girişə icazə verin»</b> (Allow access to file URLs) açarını yandırın.<div class="row"><button class="btn soft" id="openExt">⚙️ Ayarı aç</button></div><div style="margin-top:8px">' : '<b>Fayl avtomatik götürülə bilmədi.</b> '}İndi isə faylı özünüz seçin — o, Yükləmələr qovluğundadır:</div>
    <div class="row">${fail.map((it, i) => `<button class="btn soft" data-pick="${i}">📂 ${esc(it.name)}</button>`).join('')}</div><input type="file" id="pick" hidden>`;
  const oe = $('#openExt'); if (oe) oe.onclick = () => chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id });
  let cur = null;
  fb.querySelectorAll('[data-pick]').forEach((b) => (b.onclick = () => { cur = fail[+b.dataset.pick]; try { navigator.clipboard.writeText(cur.path || cur.name); } catch (e) { /* */ } $('#status').textContent = 'Faylın yolu kopyalandı — seçim pəncərəsinə yapışdıra bilərsiniz (Ctrl+V).'; $('#pick').click(); }));
  $('#pick').onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ''; if (!f || !cur) return;
    await DD_INBOX.put({ id: uid(), name: f.name, type: f.type || cur.mime || '', blob: f, at: Date.now(), src: cur.src || '' });
    cur.done = true; cur.err = ''; render();
    try { await routeToPanel(); } catch (er) { /* */ }
    if (items.every((x) => x.done || x.on === false)) { await clearQueue(); closeMe(); }
  };
}

// ---------------------------------------------------------------- bağlama
async function clearQueue() { try { await chrome.storage.session.remove('ammo_ask_q'); } catch (e) { /* */ } }
function closeMe() {
  try { chrome.tabs.getCurrent((t) => { if (t && t.id != null) chrome.tabs.remove(t.id); else window.close(); }); } catch (e) { window.close(); }
  setTimeout(() => window.close(), 300);
}
async function no() {
  if ($('#never').checked) {
    const cur = (await chrome.storage.local.get('ammo_dd_watch')).ammo_dd_watch || {};
    await chrome.storage.local.set({ ammo_dd_watch: { enabled: true, helper: false, exts: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'odt', 'ods', 'rtf'], ...cur, enabled: false } });
  }
  await clearQueue(); closeMe();
}
function stopTimer() { clearInterval(timer); $('#cd').textContent = ''; }
function startTimer() {
  timer = setInterval(() => { left--; $('#cd').textContent = left <= 30 ? `${left} san.` : ''; if (left <= 0) no(); }, 1000);
}

// ---------------------------------------------------------------- başlanğıc
$('#yes').onclick = send;
$('#no').onclick = no;
document.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !busy && !$('#yes').classList.contains('hidden')) send(); if (e.key === 'Escape') no(); });
chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'AMMO_ASK_SYNC' && !busy) syncQueue(); });

(async function init() {
  if (GO && P.get('path')) {
    // Windows köməkçisi artıq soruşub — birbaşa göndəririk
    const path = P.get('path');
    items.push({ path, name: baseName(path), src: P.get('src') || 'Windows' });
    $('#never').parentElement.classList.add('hidden');
    render(); send();
    return;
  }
  await syncQueue();
  startTimer();
  $('#yes').focus();
})();
