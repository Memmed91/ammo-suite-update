/* AMMO — İdarəetmə paneli (v1.23, yalnız admin): panellər, istifadəçilər, cihazlar, yeniləmə, inteqrasiyalar */
(async function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const C = window.AMMO_CLOUD, CFG = window.AMMO_CONFIG;
  function toast(t, ms = 5000) { const el = $('toast'); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => { el.hidden = true; }, ms); }
  const main = $('main');
  const a = await C.auth().catch(() => null);
  if (!a || !C.isAdminEmail(a.email)) { main.innerHTML = '<section class="card"><h2>Giriş qadağandır</h2><p>Bu panel yalnız admin üçündür. e-taxes-də AMMO pəncərəsində admin hesabı ilə daxil olun.</p></section>'; $('save').hidden = true; return; }

  // AMMO panelləri (content/ui.js-dəki TABS ilə eyni id-lər)
  const PANELS = [
    ['invoices', 'Elektron Qaimələr'], ['returns', 'Elektron Qaimələrin Qaytarılması'], ['acts', 'Aktlar'], ['declarations', 'Bəyannamələr'], ['hftta', 'HF və TTA'],
    ['subaccount', 'Sub-uçot Köçürmələr'], ['quicksubmit', 'Sürətli təqdim etmə'], ['audit', 'İlkin audit'], ['bank', 'Bank Çıxarışı'], ['evez', 'ƏDV Əvəzləşməsi'],
    ['edv', 'ƏDV Analiz'], ['sened', 'Sənəd hazırla'], ['dovriyye', 'Sənəd dövriyyəsi'], ['social', 'Sosial şəbəkə analizi'], ['links', 'Linklər'],
    ['taxrep_profit', 'Mənfəət hesabatı'], ['taxrep_income', 'Gəlir hesabatı'],
  ];
  let conf = await C.getConfig(true).catch((e) => { toast('Ayarlar oxunmadı: ' + e.message); return { panels: {}, update: {}, social: {} }; });
  conf.panels = conf.panels || {}; conf.update = conf.update || {}; conf.social = conf.social || {};
  let users = [], devices = new Map();
  try { users = (await C.fs.list('users')).map((d) => ({ uid: d.id, ...d.data })); } catch (e) { toast('İstifadəçilər oxunmadı: ' + e.message); }
  try { devices = await C.kv.all('ammoVergiDevices'); } catch (e) { /* */ }
  const emails = [...new Set(users.map((u) => String(u.loginEmail || u.email || '').toLowerCase()).filter(Boolean).concat([...devices.values()].map((d) => String((d.value || {}).email || '').toLowerCase()).filter(Boolean)))].sort();
  let tab = 'panels';
  const ver = chrome.runtime.getManifest().version;

  function render() {
    main.innerHTML = `<nav class="atabs">${[['panels', '☰ Panellər'], ['users', '👥 İstifadəçilər və cihazlar'], ['update', '🔄 Yeniləmə və versiya'], ['social', '💬 Sosial analiz inteqrasiyaları'], ['cloud', '☁ Bulud (Firebase)']].map(([k, t]) => `<button data-t="${k}" class="${tab === k ? 'on' : ''}">${t}</button>`).join('')}</nav>
      <section class="card">${({ panels: secPanels, users: secUsers, update: secUpdate, social: secSocial, cloud: secCloud })[tab]()}</section>`;
    document.querySelectorAll('[data-t]').forEach((b) => b.onclick = () => { tab = b.dataset.t; render(); });
    bind();
  }
  function secPanels() {
    return `<h2>Panelləri idarə et</h2><p class="lead">Açarı bağlayanda panel bütün işçilərdə yox olur (admin hər şeyi görür). «👥 Seçilmiş işçilər» — paneli yalnız yazdığınız e-poçtlara göstərir.</p>
      <div class="plist2">${PANELS.map(([id, name]) => { const p = conf.panels[id] || {}; const list = (p.emails || []).join(', '); return `<div class="prow2 ${p.off ? 'off' : ''}">
        <label class="sw"><input type="checkbox" data-pon="${id}" ${p.off ? '' : 'checked'}><i></i></label>
        <div class="pn"><b>${esc(name)}</b><small>${p.off ? 'Bağlıdır — heç bir işçidə görünmür' : list ? 'Yalnız: ' + esc(list) : 'Hamı görür'}</small></div>
        <input class="em" data-pem="${id}" placeholder="Hamı görsün (və ya e-poçtlar, vergüllə)" value="${esc(list)}" list="emails" ${p.off ? 'disabled' : ''}></div>`; }).join('')}</div>
      <datalist id="emails">${emails.map((e) => `<option value="${esc(e)}">`).join('')}</datalist>`;
  }
  function secUsers() {
    const dev = (email) => [...devices.values()].map((d) => d.value).filter((v) => v && String(v.email).toLowerCase() === email);
    return `<h2>İstifadəçilər <small>AMMO SUITE ilə eyni hesablar (Firebase: users)</small></h2>
      <p class="lead">Yeni işçi: AMMO SUITE-də hesab yaradın (və ya işçi AMMO-ya ilk dəfə daxil olsun) — sonra burada «Aktiv» edin.</p>
      <div class="wrap"><table class="t"><thead><tr><th>E-poçt</th><th>Ad</th><th>Rol</th><th>Aktiv</th><th>AMMO versiyası</th><th>Kompüter</th><th>Son giriş</th></tr></thead><tbody>
      ${users.sort((x, y) => String(x.loginEmail || x.email).localeCompare(String(y.loginEmail || y.email))).map((u) => { const em = String(u.loginEmail || u.email || '').toLowerCase(); const ds = dev(em); const d = ds.sort((p, q) => String(q.lastSeen).localeCompare(String(p.lastSeen)))[0]; return `<tr>
        <td>${esc(em)}</td><td>${esc(u.name || u.displayName || '')}</td><td>${esc(u.role || '')}</td>
        <td><label class="sw"><input type="checkbox" data-uact="${esc(u.uid)}" ${u.active ? 'checked' : ''} ${C.isAdminEmail(em) ? 'disabled' : ''}><i></i></label></td>
        <td>${d ? `<span class="pill ${d.version === ver ? 'ok' : 'warn'}">${esc(d.version)}</span>` : '—'}</td><td>${d ? esc(d.device) : '—'}</td><td>${d ? new Date(d.lastSeen).toLocaleString('az-AZ') : '—'}</td></tr>`; }).join('')}
      </tbody></table></div>`;
  }
  function secUpdate() {
    const u = conf.update;
    return `<h2>Yeniləmə və versiya</h2>
      <p class="lead">Bu kompüterdə: <b>${ver}</b>. AMMO SUITE-dəki kimi: yeni versiyanı GitHub-a yükləyirsiniz — işçilərin kompüterində «AMMO-Yenile.exe» faylları özü əvəz edir və AMMO yenidən başlayır.</p>
      <div class="form">
        <label>update.json ünvanı<input data-u="url" value="${esc(u.url || CFG.UPDATE_URL)}"></label>
        <label>Yükləmə səhifəsi (ZIP)<input data-u="page" value="${esc(u.page || CFG.DOWNLOAD_PAGE)}"></label>
        <label>Neçə dəqiqədən bir yoxlansın<input type="number" min="1" max="720" data-u="everyMin" value="${esc(u.everyMin || CFG.CHECK_EVERY_MIN)}"></label>
        <label>Açıq iş varsa gözləmə (saniyə)<input type="number" min="0" max="3600" data-u="delaySec" value="${esc(u.delaySec != null ? u.delaySec : CFG.RESTART_DELAY_SEC)}"></label>
        <label class="chk"><input type="checkbox" data-u="autoApply" ${u.autoApply === false ? '' : 'checked'}> Avtomatik quraşdır (söndürülsə — yalnız «Yeni versiya» bildirişi çıxır)</label>
        <label>Yeniləmə almayacaq işçilər (e-poçtlar, vergüllə)<input data-u="blocked" value="${esc((u.blocked || []).join(', '))}" list="emails"></label>
      </div>
      <datalist id="emails">${emails.map((e) => `<option value="${esc(e)}">`).join('')}</datalist>
      <div class="row"><button id="chk">⟳ Yeniləməni indi yoxla</button><button id="ping">Köməkçini yoxla (AMMO-Yenile.exe)</button><span id="chkRes" class="mut"></span></div>
      <h3>Yeni versiya buraxmaq (hər dəfə, ~2 dəqiqə)</h3>
      <ol class="steps"><li>AMMO qovluğunda dəyişiklik edin, <code>manifest.json</code> → <code>"version"</code>-u artırın (məs. ${esc(ver)} → ${esc(ver.replace(/(\d+)$/, (m) => String(+m + 1)))}).</li>
        <li><b>AMMO-Yayim.exe</b> → qeydləri yazın → <code>yayim\\</code> qovluğunda <code>update.json</code> və <code>AMMO.zip</code> yaranır.</li>
        <li>Hər iki faylı GitHub-da <code>ammo-suite-update/ammo-vergi/</code> qovluğuna yükləyin (köhnənin üstünə).</li>
        <li>İşçilərdə heç nə etmək lazım deyil — ${esc(u.everyMin || CFG.CHECK_EVERY_MIN)} dəqiqə ərzində özləri yenilənəcək.</li></ol>`;
  }
  function secSocial() {
    const s = conf.social;
    const redirect = chrome.identity && chrome.identity.getRedirectURL ? chrome.identity.getRedirectURL('gmail') : '';
    return `<h2>Sosial şəbəkə analizi — inteqrasiyalar <small>istəyə görə</small></h2>
      <p class="lead">Heç biri doldurulmasa da analiz işləyir: Gmail, WhatsApp, Telegram açıq tablardan oxunur. Aşağıdakılar dəqiqliyi artırır.</p>
      <div class="form">
        <label>Gmail API — Google OAuth Client ID (Web application)<input data-s="gmailClientId" value="${esc(s.gmailClientId || '')}" placeholder="....apps.googleusercontent.com"></label>
        <div class="hint">Google Cloud Console → APIs &amp; Services → Gmail API-ni aktiv edin → Credentials → «OAuth client ID» → <b>Web application</b> → Authorized redirect URI: <code>${esc(redirect)}</code>. Bu ünvan bu kompüterdəki AMMO-ya aiddir; hər kompüterin AMMO ID-si fərqlidirsə, onların ünvanlarını da əlavə edin (işçi kompüterindəki İdarəetmə → Sosial bölməsində görünür).</div>
        <label>Süni intellekt (Claude API açarı) — mesajları daha dəqiq təsnif edir<input type="password" data-s="anthropicKey" value="${esc(s.anthropicKey || '')}" placeholder="sk-ant-..."></label>
        <label>Model<input data-s="model" value="${esc(s.model || 'claude-sonnet-4-5')}"></label>
        <label>Səsli mesajları mətnə çevirmək (OpenAI açarı, Whisper)<input type="password" data-s="openaiKey" value="${esc(s.openaiKey || '')}" placeholder="sk-..."></label>
        <label>Səsli mesajların dili<select data-s="voiceLang">${[['az', 'Azərbaycan'], ['ru', 'Rus'], ['tr', 'Türk'], ['en', 'İngilis']].map(([k, t]) => `<option value="${k}" ${(s.voiceLang || 'az') === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <div class="callout warn">Diqqət: açarlar Firebase-də saxlanılır və bütün aktiv işçilərin AMMO-su onlardan istifadə edir. Süni intellekt seçiləndə mesajların mətni xarici xidmətə (Anthropic/OpenAI) göndərilir — müştəri məxfiliyini nəzərə alın.</div>
      </div>`;
  }
  function secCloud() {
    return `<h2>Bulud (Firebase — Konsalting)</h2>
      <p class="lead">Layihə: <b>${esc(CFG.FB_PROJECT)}</b>. AMMO-nun bütün məlumatı (Sənəd dövriyyəsi — sənədlər, fayllar, mətnlər, subyektlər; sosial analiz hesabatları; cihazlar) <code>suiteSharedV3/ammo*</code> altında saxlanılır — indiki qaydalarla işləyir.</p>
      <p>Admin ayarlarının yeri: <b>${conf._where === 'main' ? 'ammoVergiConfig (yalnız admin yaza bilər) ✓' : 'suiteSharedV3/ammoVergiAdmin (ehtiyat yer)'}</b></p>
      ${conf._where === 'main' ? '' : `<div class="callout warn">Daha təhlükəsiz olsun deyə Firebase Console → Firestore → Rules bölməsinə bu sətirləri əlavə edin (match /databases/{database}/documents { ... } daxilinə), sonra «Publish»:</div>
      <pre class="code">    // AMMO (vergi masası) — admin ayarları
    match /ammoVergiConfig/{id} { allow read: if activeUser(); allow write: if admin(); }</pre>`}
      <div class="row"><button id="ddSync">☁ Sənəd dövriyyəsini indi buludla yoxla</button><span class="mut" id="ddRes"></span></div>`;
  }
  function bind() {
    document.querySelectorAll('[data-pon]').forEach((cb) => cb.onchange = () => { const id = cb.dataset.pon; conf.panels[id] = { ...(conf.panels[id] || {}), off: !cb.checked }; render(); });
    document.querySelectorAll('[data-pem]').forEach((inp) => inp.onchange = () => { const id = inp.dataset.pem; conf.panels[id] = { ...(conf.panels[id] || {}), emails: inp.value.split(/[,;\s]+/).map((x) => x.trim().toLowerCase()).filter((x) => /@/.test(x)) }; render(); });
    document.querySelectorAll('[data-uact]').forEach((cb) => cb.onchange = async () => {
      try { await C.fs.merge(`users/${cb.dataset.uact}`, { active: cb.checked }); const u = users.find((x) => x.uid === cb.dataset.uact); if (u) u.active = cb.checked; toast(cb.checked ? 'Aktivləşdirildi' : 'Deaktiv edildi'); }
      catch (e) { cb.checked = !cb.checked; toast('Dəyişmədi: ' + e.message); }
    });
    document.querySelectorAll('[data-u]').forEach((el) => el.onchange = () => { const k = el.dataset.u; conf.update[k] = el.type === 'checkbox' ? el.checked : k === 'blocked' ? el.value.split(/[,;\s]+/).map((x) => x.trim().toLowerCase()).filter((x) => /@/.test(x)) : (el.type === 'number' ? +el.value : el.value.trim()); });
    document.querySelectorAll('[data-s]').forEach((el) => el.onchange = () => { conf.social[el.dataset.s] = el.value.trim(); });
    if ($('chk')) $('chk').onclick = async () => { $('chkRes').textContent = 'yoxlanılır…'; const r = await chrome.runtime.sendMessage({ type: 'AMMO_CHECK_UPDATE' }); $('chkRes').textContent = r && r.available ? `Yeni versiya var: ${r.latest.version}` : r && r.error ? 'Xəta: ' + r.error : `Ən son versiyadır (serverdə ${r && r.latest ? r.latest.version : '—'})`; };
    if ($('ping')) $('ping').onclick = async () => { $('chkRes').textContent = 'yoxlanılır…'; const r = await chrome.runtime.sendMessage({ type: 'AMMO_NATIVE_PING' }); $('chkRes').textContent = r && r.ok ? `✓ Köməkçi işləyir (versiya ${r.version || '?'}, qovluq: ${r.dir || '?'})` : r && r.error === 'no_host' ? '✗ AMMO-Yenile.exe bu kompüterdə qeydiyyatda deyil — AMMO qovluğundakı AMMO-Yenile.exe-ni bir dəfə açın' : 'Xəta: ' + ((r && r.error) || ''); };
    if ($('ddSync')) $('ddSync').onclick = async () => { $('ddRes').textContent = 'Sənəd dövriyyəsi səhifəsini açın — yoxlama orada avtomatik aparılır (hər dəqiqə).'; chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/dovriyye.html', key: 'settings' }); };
  }
  $('save').onclick = async () => {
    try { conf = await C.saveConfig(conf); chrome.runtime.sendMessage({ type: 'AMMO_CLOUD_CHANGED' }).catch(() => {}); toast('✓ Yadda saxlanıldı — bütün kompüterlərə tətbiq olunur.'); render(); }
    catch (e) { toast('Saxlanmadı: ' + e.message, 8000); }
  };
  render();
})();
