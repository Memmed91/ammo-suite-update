/* AMMO — Sosial şəbəkə analizi səhifəsi (v1.24: Thunderbird poçtu + qruplaşdırma) */
(async function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const C = window.AMMO_CLOUD, SA = window.AMMO_SOCIAL;
  const fmt = (iso) => { if (!iso) return ''; const d = new Date(iso); return isNaN(d) ? String(iso) : d.toLocaleString('az-AZ', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); };
  function toast(t, ms = 5000) { const el = $('toast'); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => { el.hidden = true; }, ms); }
  const SRC = {
    mail: { name: 'E-poçt — Thunderbird (3 hesab)', icon: '📧', url: '' },
    gmail: { name: 'Gmail (bütün hesablar)', icon: '✉️', url: 'https://mail.google.com/' },
    yahoo: { name: 'Yahoo Mail', icon: '📮', url: 'https://mail.yahoo.com/' },
    wa: { name: 'WhatsApp', icon: '🟢', url: 'https://web.whatsapp.com/' },
    tg: { name: 'Telegram', icon: '✈️', url: 'https://web.telegram.org/k/' },
  };
  const TYPE = { task: ['Tapşırıq', 'bad'], question: ['Sual', 'warn'], voice: ['Səsli mesaj', 'info'], file: ['Fayl', ''], unanswered: ['Cavabsız', ''] };
  let conf = {}; try { conf = (await C.getConfig()) || {}; } catch (e) { conf = (await chrome.storage.local.get('ammoAdminConfig')).ammoAdminConfig || {}; }
  const soc = conf.social || {};
  const pref = (await chrome.storage.local.get('ammo_social_pref')).ammo_social_pref || { gmail: true, wa: true, tg: false };
  if (!pref.__v3) { pref.gmail = true; pref.yahoo = true; pref.__v3 = 1; chrome.storage.local.set({ ammo_social_pref: pref }); }
  if (pref.yahoo === undefined) pref.yahoo = true;
  // v1.24: poçt Thunderbird-dən oxunur (3 hesab birdən, brauzer tabı açılmır) — Gmail/Yahoo səhifə oxuması ehtiyat qalır
  if (!pref.__v4) { pref.mail = true; pref.gmail = false; pref.yahoo = false; pref.wa = true; pref.__v4 = 1; chrome.storage.local.set({ ammo_social_pref: pref }); }
  if (soc.anthropicKey) $('aiWrap').hidden = false;

  async function renderSources() {
    let tabs = {};
    try { tabs = (await chrome.runtime.sendMessage({ type: 'AMMO_SOCIAL', op: 'status' })).tabs || {}; } catch (e) { /* */ }
    $('srcs').innerHTML = Object.entries(SRC).map(([k, s]) => `<label class="src ${pref[k] ? 'on' : ''}"><input type="checkbox" data-src="${k}" ${pref[k] ? 'checked' : ''}>
      <span class="si">${s.icon}</span><span class="st"><b>${s.name}</b><small>${k === 'mail' ? 'kompüterdəki Thunderbird poçtu birbaşa oxunur — tab açılmır' : tabs[k] && tabs[k].open ? '✓ açıqdır' : 'bağlıdır — analizdə arxa planda açılacaq'}${k === 'gmail' && soc.gmailClientId ? ' · Gmail API qoşulub' : ''}</small></span>
      ${s.url ? `<button class="link" data-openSrc="${k}">aç</button>` : ''}</label>`).join('');
    document.querySelectorAll('[data-src]').forEach((cb) => cb.onchange = () => { pref[cb.dataset.src] = cb.checked; cb.closest('.src').classList.toggle('on', cb.checked); chrome.storage.local.set({ ammo_social_pref: pref }); });
    document.querySelectorAll('[data-opensrc]').forEach((b) => b.onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: SRC[b.dataset.opensrc].url }); });
  }
  renderSources();
  const log = (t) => { const el = $('log'); el.hidden = false; el.insertAdjacentHTML('beforeend', `<div>${esc(new Date().toLocaleTimeString('az-AZ'))} · ${esc(t)}</div>`); el.scrollTop = el.scrollHeight; };
  chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'AMMO_SOC_PROGRESS') log(m.text); });

  // ---- Gmail API (dəqiq rejim): admin panelində Google OAuth Client ID yazılıbsa
  async function gmailApi(days) {
    let t = await chrome.runtime.sendMessage({ type: 'AMMO_SOCIAL', op: 'gmail_token', clientId: soc.gmailClientId, prompt: 'none' }).catch(() => null);
    if (!t || !t.ok) t = await chrome.runtime.sendMessage({ type: 'AMMO_SOCIAL', op: 'gmail_token', clientId: soc.gmailClientId, prompt: 'select_account' });
    if (!t || !t.ok) throw new Error('Gmail icazəsi alınmadı: ' + ((t && t.error) || ''));
    const H = { Authorization: 'Bearer ' + t.token };
    const g = async (u) => { const r = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/' + u, { headers: H }); if (!r.ok) throw new Error('Gmail API ' + r.status); return r.json(); };
    const prof = await g('profile');
    const me = String(prof.emailAddress || '').toLowerCase();
    const list = await g(`threads?maxResults=150&q=${encodeURIComponent(`in:inbox newer_than:${days}d -category:promotions -category:social`)}`);
    const out = [];
    let n = 0;
    for (const th of list.threads || []) {
      n++; if (n % 10 === 0) log(`Gmail API: ${n}/${(list.threads || []).length} yazışma`);
      const d = await g(`threads/${th.id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date`);
      const msgs = (d.messages || []).map((m) => { const hd = Object.fromEntries((m.payload.headers || []).map((x) => [x.name.toLowerCase(), x.value])); const mine = (m.labelIds || []).includes('SENT') || (hd.from || '').toLowerCase().includes(me); return { dir: mine ? 'out' : 'in', from: (hd.from || '').replace(/<.*>/, '').trim(), text: (m.snippet || '').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&'), at: new Date(+m.internalDate).toISOString(), subject: hd.subject || '' }; });
      const first = msgs[0] || {}, last = msgs[msgs.length - 1] || {};
      out.push({ source: 'gmail', chat: (msgs.find((m) => m.dir === 'in') || first).from || '', subject: first.subject, lastDir: last.dir, at: last.at, unread: (d.messages || []).some((m) => (m.labelIds || []).includes('UNREAD')) ? 1 : 0, link: `https://mail.google.com/mail/u/0/#all/${th.id}`, ref: { tid: th.id }, messages: msgs.map((m) => ({ ...m, text: (m.subject && m === first ? m.subject + ' — ' : '') + m.text })) });
    }
    return { ok: true, source: 'gmail', account: me, threads: out, api: true };
  }

  // v1.23.2: tabla birbaşa əlaqə — uzun oxuma xidmət işçisindən keçmir (əvvəl 5 dəqiqədən sonra «message channel closed» xətası verirdi)
  async function toTab(tabId, payload) {
    for (let i = 0; i < 3; i++) {
      try { const r = await chrome.tabs.sendMessage(tabId, payload); if (r) return r; }
      catch (e) {
        if (i === 2) throw new Error('Səhifə AMMO-ya cavab vermədi (' + e.message + ')');
        await chrome.runtime.sendMessage({ type: 'AMMO_SOCIAL', op: 'tab', source: payload.__src }).catch(() => null);
      }
    }
    throw new Error('cavab yoxdur');
  }
  // v1.23.3: oxunan tab ÖNƏ çıxarılır — Chrome arxa plandakı tabları dondurur / taymerləri dəqiqədə 1 dəfəyə endirir
  // (əvvəl WhatsApp oxuması buna görə 17 dəqiqə uzanıb kəsilirdi). Sonda bu səhifəyə qayıdılır.
  let homeTab = null;
  try { homeTab = await chrome.tabs.getCurrent(); } catch (e) { /* */ }
  async function focusTab(tabId) { try { const t = await chrome.tabs.update(tabId, { active: true, autoDiscardable: false }); await chrome.windows.update(t.windowId, { focused: true }); } catch (e) { /* */ } }
  async function backHome() { if (homeTab) await focusTab(homeTab.id); }

  async function scanOne(k, opts, idx) {
    const t = await chrome.runtime.sendMessage({ type: 'AMMO_SOCIAL', op: 'tab', source: k, idx });
    if (!t || !t.ok) throw new Error((t && t.error) || 'tab açılmadı');
    await focusTab(t.tabId); await new Promise((r) => setTimeout(r, 400));
    if (k !== 'wa') { const r = await toTab(t.tabId, { type: 'AMMO_SOC_SCAN', opts, __src: k }); if (r) r.__tab = t; return r; }
    // WhatsApp: əvvəl siyahı (sürətli), sonra cavabsız söhbətlər 6-6 oxunur
    const res = await toTab(t.tabId, { type: 'AMMO_SOC_SCAN', opts: { ...opts, detail: false }, __src: k });
    if (!res || !res.ok) return res;
    log(`WhatsApp: ${res.threads.length} söhbət siyahıda, ${res.threads.filter((x) => x.lastDir === 'in').length} cavabsız`);
    if (!opts.detail) return res;
    const todo = res.threads.filter((x) => x.lastDir === 'in').slice(0, opts.maxDetail || 30);
    const byChat = new Map(res.threads.map((x) => [x.chat, x]));
    for (let i = 0; i < todo.length; i += 6) {
      const part = todo.slice(i, i + 6).map((x) => x.chat);
      try {
        await focusTab(t.tabId);
        const d = await toTab(t.tabId, { type: 'AMMO_SOC_DETAIL', chats: part, perChat: opts.perChat || 15, audio: !!opts.audio, __src: k });
        if (d && d.ok) for (const [c, msgs] of Object.entries(d.results || {})) { const th = byChat.get(c); if (th) th.messages = msgs || []; }
      } catch (e) { log('WhatsApp: ' + e.message); }
      log(`WhatsApp: ${Math.min(i + 6, todo.length)}/${todo.length} söhbət oxundu`);
    }
    return res;
  }
  async function scanSource(k, opts) {
    try {
      if (k !== 'gmail') return await scanOne(k, opts);
      // Gmail: brauzerdə daxil olunmuş BÜTÜN hesablar (u/0, u/1, u/2 …) — Outlook-dakı Gmail poçtları ilə eynidir
      const all = { ok: true, source: 'gmail', account: '', threads: [] }; const seen = new Set();
      for (let idx = 0; idx < 5; idx++) {
        let r;
        try { r = await scanOne('gmail', opts, idx); } catch (e) { if (idx === 0) throw e; break; }
        if (!r || !r.ok) { if (idx === 0) return r; break; }
        const acc = (r.account || '').toLowerCase();
        if (acc && seen.has(acc)) { if (r.__tab && r.__tab.fresh) chrome.tabs.remove(r.__tab.tabId).catch(() => {}); break; }
        if (acc) seen.add(acc);
        r.threads.forEach((t) => { t.chat = t.chat + (acc ? ` · ${acc}` : ''); t.account = acc; });
        all.threads.push(...r.threads);
        log(`Gmail ${acc || '#' + idx}: ${r.threads.length} yazışma`);
      }
      all.account = [...seen].join(', ');
      return all;
    } finally { await backHome(); }
  }

  // ================================================================ v1.24: analiz + qruplaşdırma
  let REPORT = null, groupBy = false;
  const filt = { src: '', type: '', q: '', urg: false, kind: '', onlyOpen: false };
  let VIEW = 'wait';
  const opened = new Set();
  $('run').onclick = async () => {
    const btn = $('run'); if (btn.disabled) return; btn.disabled = true; btn.textContent = 'Oxunur…';
    $('log').innerHTML = ''; const days = +$('days').value; const detail = $('detail').checked;
    const threads = [], errors = [], accounts = {};
    let MAIL = null;
    try {
      for (const k of Object.keys(SRC).filter((x) => pref[x])) {
        log(`${SRC[k].name}: oxunur…`);
        try {
          if (k === 'mail') {
            const r = await chrome.runtime.sendMessage({ type: 'AMMO_SOCIAL', op: 'mail', days, max: 1500 });
            if (!r || !r.ok) throw new Error((r && r.error) || 'cavab yoxdur');
            MAIL = AMMO_MAILGROUP.build(r.messages || [], r.accounts || []);
            accounts.mail = (r.accounts || []).map((a) => a.email).filter(Boolean).join(', ');
            threads.push(...MAIL.threads.filter((t) => !t.auto));
            log(`E-poçt: ${MAIL.stats.messages} məktub → ${MAIL.stats.threads} yazışma · ${MAIL.companies.length} şirkət/şəxs · ${MAIL.stats.auto} avtomatik bildiriş`);
            continue;
          }
          const r = k === 'gmail' && soc.gmailClientId ? await gmailApi(days).catch((e) => { log('Gmail API alınmadı, səhifədən oxunur: ' + e.message); return null; }) : null;
          const res = r || await scanSource(k, { days, detail, maxChats: 80, maxDetail: 30, perChat: 15, audio: !!soc.openaiKey });
          if (!res || !res.ok) throw new Error((res && res.error) || 'cavab yoxdur');
          accounts[k] = res.account || '';
          const lim = Date.now() - days * 864e5;
          res.threads.forEach((t) => { t.messages = (t.messages || []).filter((m) => !m.at || Date.parse(m.at) >= lim); if (!t.at && t.messages.length) t.at = t.messages[t.messages.length - 1].at; });
          if (soc.openaiKey) for (const t of res.threads) for (const m of t.messages) if (m.audio) { try { m.transcript = await SA.transcribe(m.audio.b64, m.audio.mime, soc); } catch (e) { /* */ } delete m.audio; }
          threads.push(...res.threads);
          log(`${SRC[k].name}: ${res.threads.length} yazışma oxundu`);
        } catch (e) { errors.push(`${SRC[k].name}: ${e.message}`); log(`${SRC[k].name}: XƏTA — ${e.message}`); }
      }
      const A = SA.analyzeThreads(threads, {});
      if ($('ai').checked && soc.anthropicKey && A.items.length) {
        log('Süni intellekt dəqiqləşdirir…');
        try {
          const arr = await SA.aiRefine(A.items, soc, C.net);
          if (arr) { arr.forEach((x) => { const it = A.items[x.i]; if (!it) return; it.ai = x.summary || ''; if (x.type === 'info') it.type = 'unanswered'; else if (x.type) it.type = x.type; if (x.urgent) it.urgent = true; if (x.deadline) it.deadlineText = x.deadline; }); A.items = A.items.filter((it) => !(it.type === 'unanswered' && it.ai && /məlumat|salam/i.test(it.ai))); log('Süni intellekt: hazırdır'); }
        } catch (e) { log('Süni intellekt alınmadı: ' + e.message); }
      }
      A.counts = { ...A.counts, task: A.items.filter((i) => i.type === 'task').length, question: A.items.filter((i) => i.type === 'question').length, voice: A.items.filter((i) => i.type === 'voice').length };
      // söhbət (WhatsApp / Telegram / brauzer poçtu) — tam mesajlarla
      const chats = threads.filter((t) => t.source !== 'mail').map((t) => {
        const sum = A.byChat.find((c) => c.source === t.source && c.chat === t.chat) || {};
        return { ...t, unanswered: !!sum.unanswered, pending: sum.pending || 0, items: A.items.filter((i) => i.source === t.source && i.chat === t.chat) };
      }).sort((a, b) => (b.unanswered - a.unanswered) || (b.items.length - a.items.length) || String(b.at || '').localeCompare(String(a.at || '')));
      // şirkət kartlarına tapşırıq/sual sayı
      if (MAIL) for (const c of MAIL.companies) { c.items = A.items.filter((i) => i.source === 'mail' && c.threads.some((t) => t.key === i.key)); c.tasks = c.items.filter((i) => i.type === 'task').length; c.questions = c.items.filter((i) => i.type === 'question').length; }
      REPORT = { at: Date.now(), days, accounts, errors, ...A, mail: MAIL, chats };
      const a = await C.auth().catch(() => null);
      await chrome.storage.local.set({ ammo_social_last: { at: REPORT.at, counts: REPORT.counts } });
      if (a) C.kv.put('ammoVergi_social', a.email, { at: REPORT.at, days, counts: REPORT.counts, items: REPORT.items.slice(0, 400) }).catch(() => {});
      VIEW = A.items.length ? 'wait' : MAIL ? 'co' : 'chat';
      render();
      $('xlsx').disabled = false;
    } finally { btn.disabled = false; btn.textContent = '🔎 Analiz et'; }
  };

  // ---------------------------------------------------------------- görünüş
  const KIND = { gov: ['🏛️', 'Dövlət'], company: ['🏢', 'Şirkət'], person: ['👤', 'Şəxs'] };
  const ago = (iso) => { const t = Date.parse(iso); if (!isFinite(t)) return ''; const d = (Date.now() - t) / 864e5; return d < 1 / 24 ? 'indicə' : d < 1 ? Math.floor(d * 24) + ' saat əvvəl' : Math.floor(d) + ' gün əvvəl'; };
  const waitAge = (iso) => { const t = Date.parse(iso); if (!isFinite(t)) return ''; const d = (Date.now() - t) / 864e5; return d < 1 ? 'bu gün gəlib' : `${Math.floor(d)} gündür gözləyir`; };
  const shortAcct = (a) => String(a || '').split('@')[0];
  const match = (txt) => !filt.q || SA.fold(txt).includes(SA.fold(filt.q));
  const openBtn = (o, label) => `<button class="open" data-open='${esc(JSON.stringify(o))}'>${label || 'Aç →'}</button>`;
  const mailOpen = (t) => t.link ? openBtn({ source: t.source, url: t.link }, 'Poçtda aç →') : `<button class="open ghost" data-copy="${esc(t.subject)}" title="Thunderbird-də axtarış üçün mövzunu kopyalayır">Mövzunu kopyala</button>`;

  function itemRow(i) {
    const isMail = i.source === 'mail';
    const sub = isMail ? `${i.company && i.company !== i.chat ? esc(i.company) + ' · ' : ''}${esc(i.subject || '')}` : esc(i.subject || '');
    return `<div class="it ${i.urgent ? 'urg' : ''} t-${i.type}">
      <div class="when"><b>${esc(fmt(i.at) || '—')}</b><small class="${(i.ageDays || 0) >= 3 ? 'late' : ''}">${esc(waitAge(i.at))}</small></div>
      <div class="who"><span class="si">${SRC[i.source].icon}</span><div><b>${esc(isMail ? i.from || i.chat : i.chat)}</b>${sub ? `<small>${sub}</small>` : ''}${isMail && i.acct ? `<small class="acct">→ ${esc(i.acct)}</small>` : ''}</div></div>
      <div class="what"><span class="pill ${TYPE[i.type][1]}">${TYPE[i.type][0]}</span>${i.urgent ? '<span class="pill bad">təcili</span>' : ''}${i.deadlineText ? `<span class="pill warn">son tarix: ${esc(i.deadlineText)}</span>` : i.deadline ? '<span class="pill warn">tarix qeyd olunub</span>' : ''}
        <p>${esc(String(i.text || '').slice(0, 600))}</p>${i.transcript ? `<p class="tr">🎤 ${esc(i.transcript)}</p>` : ''}${i.ai ? `<p class="ai">🤖 ${esc(i.ai)}</p>` : ''}</div>
      <div class="go2">${isMail ? mailOpen(i) : openBtn({ source: i.source, ref: i.ref, url: i.link }, 'Söhbəti aç →')}</div></div>`;
  }

  // 1) Cavab gözləyir — tapşırıq / sual / səsli / digər, ayrı-ayrı bloklarda
  function viewWait(R) {
    const L = R.items.filter((i) => (!filt.src || i.source === filt.src) && (!filt.urg || i.urgent) && match(`${i.chat} ${i.from} ${i.text} ${i.subject} ${i.company}`));
    const blocks = [
      ['task', '📌 Tapşırıqlar — sizə iş verilib, cavab yazılmayıb', 'bad'],
      ['question', '❓ Suallar — cavab gözlənilir', 'warn'],
      ['voice', '🎤 Səsli mesajlar', 'info'],
      ['file', '📎 Göndərilmiş fayllar', ''],
      ['unanswered', '✉️ Digər cavabsız məktub və mesajlar', ''],
    ];
    const html = blocks.map(([k, t, cls]) => {
      const B = L.filter((i) => i.type === k); if (!B.length) return '';
      const more = B.length > 40 && !opened.has('w:' + k);
      return `<div class="blk ${cls}"><h3>${t} <span class="cnt">${B.length}</span></h3>${(more ? B.slice(0, 40) : B).map(itemRow).join('')}${more ? `<button class="more" data-more="w:${k}">daha ${B.length - 40} göstər</button>` : ''}</div>`;
    }).join('');
    return html || '<div class="empty">Cavab gözləyən tapşırıq və ya sual yoxdur — əla! 🎉</div>';
  }

  // 2) E-poçt — şirkətlər üzrə
  function threadRow(t) {
    const last = t.messages[t.messages.length - 1] || {};
    const lastIn = [...t.messages].reverse().find((m) => m.dir === 'in') || {};
    return `<div class="th ${t.answered ? 'ok' : 'wait'}">
      <div class="thm"><span class="dot ${t.answered ? 'ok' : t.unread ? 'new' : 'wait'}"></span>
        <div class="tht"><b>${esc(t.subject)}</b>${t.unread ? '<span class="pill info">oxunmayıb</span>' : ''}${t.attach ? '<span class="pill">📎</span>' : ''}
          <small>${esc(t.person)}${t.email && t.email !== t.person ? ' &lt;' + esc(t.email) + '&gt;' : ''} · ${t.count} məktub · ${esc(fmt(t.at))} · <span class="acct">${esc(t.acct)}</span></small>
          <p>${esc(String(lastIn.text || last.text || t.preview || '').replace(/^.*? — /, '').slice(0, 260))}</p></div></div>
      <div class="thr"><span class="pill ${t.answered ? 'ok' : 'bad'}">${t.answered ? '✓ Cavab verilib' : '⏳ Cavabsız · ' + esc(ago(lastIn.at || t.at))}</span>${mailOpen(t)}</div></div>`;
  }
  function viewCompanies(R) {
    if (!R.mail) return '<div class="empty">E-poçt oxunmayıb — yuxarıda «E-poçt — Thunderbird» mənbəyini seçib yenidən analiz edin.</div>';
    let L = R.mail.companies.filter((c) => (!filt.kind || c.kind === filt.kind) && (!filt.onlyOpen || c.unanswered) && match(`${c.name} ${c.domain} ${c.threads.map((t) => t.subject + ' ' + t.person + ' ' + t.preview).join(' ')}`));
    const cnt = (k) => R.mail.companies.filter((c) => !k || c.kind === k).length;
    const chips = `<div class="chips">${[['', 'Hamısı'], ['gov', '🏛️ Dövlət'], ['company', '🏢 Şirkətlər'], ['person', '👤 Şəxslər']].map(([k, t]) => `<button data-kind="${k}" class="${filt.kind === k ? 'on' : ''}">${t} <small>${cnt(k)}</small></button>`).join('')}
      <label class="chk"><input type="checkbox" id="onlyOpen" ${filt.onlyOpen ? 'checked' : ''}> yalnız cavabsızı olanlar</label></div>`;
    const card = (c, i) => {
      const k = KIND[c.kind] || KIND.company; const id = 'c:' + c.key;
      const open = opened.has(id) || (!opened.has('!' + id) && i < 3 && c.unanswered > 0);
      const th = [...c.threads].sort((a, b) => (a.answered - b.answered) || String(b.at).localeCompare(String(a.at)));
      return `<details class="co k-${c.kind} ${c.unanswered ? 'has' : ''}" data-co="${esc(id)}" ${open ? 'open' : ''}>
        <summary><span class="av">${k[0]}</span><span class="cn"><b>${esc(c.name)}</b><small>${esc(k[1])}${c.domain && c.kind !== 'person' ? ' · ' + esc(c.domain) : c.kind === 'person' ? ' · ' + esc(c.domain) : ''} · son: ${esc(ago(c.at))}</small></span>
          <span class="badges">${c.unanswered ? `<span class="b bad">${c.unanswered} cavabsız</span>` : '<span class="b ok">✓ hamısı cavablı</span>'}${c.tasks ? `<span class="b bad">📌 ${c.tasks}</span>` : ''}${c.questions ? `<span class="b warn">❓ ${c.questions}</span>` : ''}${c.unread ? `<span class="b info">${c.unread} yeni</span>` : ''}<span class="b">${c.threads.length} yazışma</span></span></summary>
        <div class="ths">${th.map(threadRow).join('')}</div></details>`;
    };
    const s = R.mail.stats;
    return `<div class="mstat">📧 ${s.messages} məktub · ${s.threads} yazışma · <b>${R.mail.companies.length}</b> göndərən qrupu · <b class="bad">${s.unanswered}</b> cavabsız yazışma${R.accounts.mail ? ` · hesablar: ${esc(R.accounts.mail)}` : ''}</div>${chips}
      <div class="cos">${L.map(card).join('') || '<div class="empty">Uyğun yazışma yoxdur.</div>'}</div>`;
  }

  // 3) WhatsApp / Telegram — söhbət üzrə
  function viewChats(R) {
    const L = R.chats.filter((t) => (!filt.src || t.source === filt.src) && (!filt.onlyOpen || t.unanswered) && match(`${t.chat} ${t.preview || ''} ${(t.messages || []).map((m) => m.text).join(' ')}`));
    if (!R.chats.length) return '<div class="empty">WhatsApp / Telegram oxunmayıb — mənbəni seçib yenidən analiz edin.</div>';
    const card = (t) => {
      const id = 'ch:' + t.source + '|' + t.chat;
      const open = opened.has(id) || (!opened.has('!' + id) && t.items.length > 0 && t.items.some((i) => i.type === 'task' || i.type === 'question'));
      const msgs = (t.messages || []).slice(-8);
      const bubbles = msgs.length ? msgs.map((m) => `<div class="bb ${m.dir}"><small>${esc(m.dir === 'out' ? 'Siz' : m.from || t.chat)} · ${esc(fmt(m.at))}</small>${esc(m.text || (m.kind === 'voice' ? '🎤 Səsli mesaj' : m.kind === 'file' ? '📎 Fayl' : m.kind === 'image' ? '🖼️ Şəkil' : ''))}${m.transcript ? `<i>🎤 ${esc(m.transcript)}</i>` : ''}</div>`).join('') : `<div class="bb in">${esc(t.preview || '—')}</div>`;
      const tasks = t.items.filter((i) => i.type === 'task').length, qs = t.items.filter((i) => i.type === 'question').length;
      return `<details class="co chat ${t.unanswered ? 'has' : ''}" data-co="${esc(id)}" ${open ? 'open' : ''}>
        <summary><span class="av">${SRC[t.source].icon}</span><span class="cn"><b>${esc(t.chat)}</b><small>${esc(fmt(t.at))} · ${esc(ago(t.at))}</small></span>
          <span class="badges">${t.unanswered ? `<span class="b bad">⏳ cavabsız${t.pending ? ' · ' + t.pending : ''}</span>` : '<span class="b ok">✓ cavablı</span>'}${tasks ? `<span class="b bad">📌 ${tasks}</span>` : ''}${qs ? `<span class="b warn">❓ ${qs}</span>` : ''}${t.unread ? `<span class="b info">${t.unread} yeni</span>` : ''}</span></summary>
        <div class="conv">${bubbles}</div><div class="cact">${openBtn({ source: t.source, ref: t.ref, url: t.link }, 'Söhbəti aç →')}</div></details>`;
    };
    const un = L.filter((t) => t.unanswered), ok = L.filter((t) => !t.unanswered);
    return `<div class="chips"><label class="chk"><input type="checkbox" id="onlyOpen" ${filt.onlyOpen ? 'checked' : ''}> yalnız cavabsız söhbətlər</label></div>
      ${un.length ? `<div class="blk bad"><h3>⏳ Cavab gözləyən söhbətlər <span class="cnt">${un.length}</span></h3><div class="cos">${un.map(card).join('')}</div></div>` : ''}
      ${ok.length ? `<div class="blk"><h3>✓ Cavab verilmiş söhbətlər <span class="cnt">${ok.length}</span></h3><div class="cos">${ok.map(card).join('')}</div></div>` : ''}`;
  }

  // 4) Avtomatik bildirişlər (no-reply, bülleten, reklam)
  function viewAuto(R) {
    if (!R.mail || !R.mail.auto.length) return '<div class="empty">Avtomatik bildiriş yoxdur.</div>';
    const L = R.mail.auto.filter((a) => match(`${a.name} ${a.domain} ${a.threads.map((t) => t.subject).join(' ')}`));
    return `<p class="hint">Bunlar cavab tələb etməyən avtomatik məktublardır (no-reply, xəbər bülleteni, reklam) — tapşırıq siyahısına düşmür.</p><div class="cos">${L.map((a) => `<details class="co auto" data-co="a:${esc(a.key)}" ${opened.has('a:' + a.key) ? 'open' : ''}><summary><span class="av">📢</span><span class="cn"><b>${esc(a.name)}</b><small>${esc(a.domain)} · son: ${esc(ago(a.at))}</small></span><span class="badges"><span class="b">${a.threads.length} məktub</span></span></summary>
      <div class="ths">${a.threads.slice(0, 30).map((t) => `<div class="th mini"><span>${esc(fmt(t.at))}</span><b>${esc(t.subject)}</b><small class="acct">${esc(shortAcct(t.acct))}</small>${t.link ? openBtn({ source: 'mail', url: t.link }, '→') : ''}</div>`).join('')}</div></details>`).join('')}</div>`;
  }

  // 5) Bütün siyahı (köhnə görünüş)
  function viewAll(R) {
    const list = R.items.filter((i) => (!filt.src || i.source === filt.src) && (!filt.type || i.type === filt.type) && (!filt.urg || i.urgent) && match(`${i.chat} ${i.text} ${i.subject} ${i.company}`));
    if (!groupBy) return list.map(itemRow).join('') || '<div class="empty">Boşdur.</div>';
    const g = new Map(); list.forEach((i) => { const k = i.source + '|' + (i.source === 'mail' ? i.company || i.chat : i.chat); if (!g.has(k)) g.set(k, []); g.get(k).push(i); });
    return [...g.values()].map((L) => `<div class="grp"><h3>${SRC[L[0].source].icon} ${esc(L[0].source === 'mail' ? L[0].company || L[0].chat : L[0].chat)} <small>${L.length}</small></h3>${L.map(itemRow).join('')}</div>`).join('');
  }

  function render() {
    const R = REPORT; if (!R) return;
    const c = R.counts;
    const wait = R.items.length;
    const coUn = R.mail ? R.mail.companies.filter((x) => x.unanswered).length : 0;
    const chUn = R.chats.filter((t) => t.unanswered).length;
    const kpi = (t, v, cls, act) => `<button class="kpi ${cls || ''}" data-kpi="${act}"><span>${t}</span><b>${v}</b></button>`;
    const tabs = [
      ['wait', `🔴 Cavab gözləyir`, wait],
      ['co', `🏢 E-poçt — şirkətlər üzrə`, R.mail ? R.mail.companies.length : 0],
      ['chat', `💬 WhatsApp / Telegram`, R.chats.length],
      ['auto', `📢 Avtomatik bildirişlər`, R.mail ? R.mail.auto.length : 0],
      ['all', `📋 Bütün siyahı`, wait],
    ];
    const srcSeg = VIEW === 'wait' || VIEW === 'all' || VIEW === 'chat';
    const segList = (VIEW === 'chat' ? [['', 'Hamısı'], ['wa', '🟢 WhatsApp'], ['tg', '✈️ Telegram']] : [['', 'Hamısı'], ['mail', '📧 E-poçt'], ['wa', '🟢 WhatsApp'], ['tg', '✈️ Telegram'], ['gmail', '✉️ Gmail'], ['yahoo', '📮 Yahoo']]).filter(([k]) => !k || R.items.some((i) => i.source === k) || R.chats.some((t) => t.source === k));
    const body = VIEW === 'co' ? viewCompanies(R) : VIEW === 'chat' ? viewChats(R) : VIEW === 'auto' ? viewAuto(R) : VIEW === 'all' ? viewAll(R) : viewWait(R);
    $('result').innerHTML = `<section class="card">
      <div class="rhead"><h2>Hesabat <small>${fmt(new Date(R.at).toISOString())} · son ${R.days} gün${Object.entries(R.accounts).filter(([, v]) => v).map(([k, v]) => ` · ${SRC[k].icon} ${esc(v)}`).join('')}</small></h2></div>
      ${R.errors.length ? `<div class="callout warn">${R.errors.map(esc).join('<br>')}</div>` : ''}
      <div class="kpis k6">${kpi('Cavab gözləyir', wait, 'bad', 'wait')}${kpi('📌 Tapşırıq', c.task, 'bad', 'task')}${kpi('❓ Sual', c.question, 'warn', 'question')}${kpi('🏢 Cavabsızı olan şirkət', coUn, 'warn', 'co')}${kpi('💬 Cavabsız söhbət', chUn, 'info', 'chat')}${kpi('⚡ Təcili', c.urgent, 'bad', 'urgent')}</div>
      <nav class="vtabs">${tabs.map(([k, t, n]) => `<button data-view="${k}" class="${VIEW === k ? 'on' : ''}">${t}<span>${n}</span></button>`).join('')}</nav>
      <div class="toolbar"><input type="search" id="q" placeholder="Şirkət, ad, mövzu və ya mətn üzrə axtar…" value="${esc(filt.q)}">
        ${srcSeg && segList.length > 2 ? `<div class="seg">${segList.map(([k, t]) => `<button data-fs="${k}" class="${filt.src === k ? 'on' : ''}">${t}</button>`).join('')}</div>` : ''}
        ${VIEW === 'all' ? `<label class="chk"><input type="checkbox" id="grp" ${groupBy ? 'checked' : ''}> şirkət / söhbət üzrə qruplaşdır</label>` : ''}
        ${filt.urg ? '<button class="link" id="clrUrg">⚡ yalnız təcili — sıfırla</button>' : ''}</div>
      <div class="items">${body}</div></section>`;
    document.querySelectorAll('[data-view]').forEach((b) => b.onclick = () => { VIEW = b.dataset.view; if (VIEW === 'co' || VIEW === 'auto') filt.src = ''; if (VIEW === 'chat' && !['', 'wa', 'tg'].includes(filt.src)) filt.src = ''; render(); });
    document.querySelectorAll('[data-kpi]').forEach((b) => b.onclick = () => {
      const k = b.dataset.kpi;
      if (k === 'urgent') { filt.urg = !filt.urg; VIEW = 'wait'; }
      else if (k === 'task' || k === 'question') { VIEW = 'all'; filt.type = filt.type === k ? '' : k; }
      else if (k === 'co' || k === 'chat') { VIEW = k; filt.onlyOpen = true; }
      else VIEW = 'wait';
      render();
    });
    document.querySelectorAll('[data-fs]').forEach((b) => b.onclick = () => { filt.src = b.dataset.fs; render(); });
    document.querySelectorAll('[data-kind]').forEach((b) => b.onclick = () => { filt.kind = b.dataset.kind; render(); });
    document.querySelectorAll('[data-more]').forEach((b) => b.onclick = () => { opened.add(b.dataset.more); render(); });
    document.querySelectorAll('details[data-co]').forEach((d) => d.ontoggle = () => { const id = d.dataset.co; if (d.open) { opened.add(id); opened.delete('!' + id); } else { opened.delete(id); opened.add('!' + id); } });
    const oo = $('onlyOpen'); if (oo) oo.onchange = (e) => { filt.onlyOpen = e.target.checked; render(); };
    const cu = $('clrUrg'); if (cu) cu.onclick = () => { filt.urg = false; render(); };
    const q = $('q'); q.oninput = () => { clearTimeout(render.t); render.t = setTimeout(() => { filt.q = q.value; render(); const x = $('q'); x.focus(); x.setSelectionRange(x.value.length, x.value.length); }, 250); };
    const g = $('grp'); if (g) g.onchange = (e) => { groupBy = e.target.checked; render(); };
    document.querySelectorAll('[data-copy]').forEach((b) => b.onclick = async (e) => { e.preventDefault(); try { await navigator.clipboard.writeText(b.dataset.copy); toast('Mövzu kopyalandı — Thunderbird-də axtarış xanasına yapışdırın (Ctrl+K, Ctrl+V).'); } catch (er) { toast('Kopyalanmadı'); } });
    document.querySelectorAll('[data-open]').forEach((b) => b.onclick = async (e) => {
      e.preventDefault();
      const o = JSON.parse(b.dataset.open);
      if (['mail', 'gmail', 'yahoo'].includes(o.source) && o.url) { chrome.tabs.create({ url: o.url }); return; }
      const r = await chrome.runtime.sendMessage({ type: 'AMMO_SOCIAL', op: 'open', source: o.source, ref: { ...(o.ref || {}), url: o.url } }).catch(() => null);
      if (!r || !r.ok) toast('Tab açıldı — söhbəti siyahıdan seçin.');
    });
  }
  $('xlsx').onclick = () => {
    if (!REPORT) return;
    const H = (v) => ({ v, s: 'h' });
    const R = REPORT;
    const sheets = [{ name: 'Cavab gözləyir', maxWidth: 70, rows: [['Tarix', 'Gözləyir (gün)', 'Mənbə', 'Kimdən / söhbət', 'Şirkət', 'Hesab', 'Mövzu', 'Növ', 'Təcili', 'Mətn', 'Keçid'].map(H), ...R.items.map((i) => [fmt(i.at), i.ageDays != null ? Math.floor(i.ageDays) : '', SRC[i.source].name, i.source === 'mail' ? i.from || i.chat : i.chat, i.company || '', i.acct || '', i.subject || '', TYPE[i.type][0], i.urgent ? 'bəli' : '', i.transcript || i.ai || i.text, i.link || ''])] }];
    if (R.mail) {
      sheets.push({ name: 'Şirkətlər', rows: [['Qrup', 'Növ', 'Domen / ünvan', 'Yazışma', 'Cavabsız', 'Tapşırıq', 'Sual', 'Oxunmamış', 'Son məktub'].map(H), ...R.mail.companies.map((c) => [c.name, (KIND[c.kind] || KIND.company)[1], c.domain, c.threads.length, c.unanswered, c.tasks || 0, c.questions || 0, c.unread, fmt(c.at)])] });
      sheets.push({ name: 'E-poçt yazışmaları', maxWidth: 70, rows: [['Şirkət / şəxs', 'Kimdən', 'E-poçt', 'Hesab', 'Mövzu', 'Məktub sayı', 'Status', 'Son tarix', 'Son mətn'].map(H), ...R.mail.companies.flatMap((c) => c.threads.map((t) => [c.name, t.person, t.email, t.acct, t.subject, t.count, t.answered ? 'Cavab verilib' : 'Cavabsız', fmt(t.at), t.preview]))] });
      sheets.push({ name: 'Bildirişlər', rows: [['Göndərən', 'Domen', 'Məktub sayı', 'Son'].map(H), ...R.mail.auto.map((a) => [a.name, a.domain, a.threads.length, fmt(a.at)])] });
    }
    sheets.push({ name: 'Söhbətlər', rows: [['Mənbə', 'Söhbət', 'Oxunmamış', 'Cavabsız', 'Gözləyən mesaj', 'Tapşırıq', 'Sual', 'Son tarix'].map(H), ...R.chats.map((t) => [SRC[t.source].name, t.chat, t.unread || 0, t.unanswered ? 'bəli' : '', t.pending, t.items.filter((i) => i.type === 'task').length, t.items.filter((i) => i.type === 'question').length, fmt(t.at)])] });
    AMMO_XLSX.download(sheets, `AMMO_Sosial_analiz_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };
  $('print').onclick = () => { document.querySelectorAll('details.co').forEach((d) => { d.open = true; }); window.print(); };
})();
