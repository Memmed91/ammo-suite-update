/* AMMO — ƏDV Əvəzləşməsi: nəticə səhifəsi (v1.19.0) */
(async function () {
  'use strict';
  const E = AMMO_EVEZ;
  const $ = (id) => document.getElementById(id);
  const key = new URLSearchParams(location.search).get('key');
  const stored = key ? (await chrome.storage.local.get(key))[key] : null;
  if (!stored || !stored.inputs) { $('sub').textContent = 'Nəticə tapılmadı (vaxtı keçib və ya silinib). AMMO panelində yenidən «Hesabla» basın.'; return; }
  const inputs = stored.inputs;
  const TIN = inputs.ownTin || 'x';
  const DEP_KEY = 'ammo_evez_dep_' + TIN, CUS_KEY = 'ammo_evez_cus_' + TIN;

  // ------------------------------------------------------------------ köməkçilər
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (v) => (Number(v) || 0).toLocaleString('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const short = (v) => { const x = Number(v) || 0; if (Math.abs(x) >= 1e6) return (x / 1e6).toFixed(2).replace('.', ',') + ' mln'; if (Math.abs(x) >= 1e4) return Math.round(x / 1e3).toLocaleString('az-AZ') + ' min'; return money(x); };
  const fold = (s) => String(s || '').replace(/̇/g, '').toLocaleLowerCase('az');
  const dmy = E.dmy;
  const MSH = ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'İyn', 'İyl', 'Avq', 'Sen', 'Okt', 'Noy', 'Dek'];
  const TYPE = { CURRENT: 'Cari', CLARIFYING: 'Dəqiqləşdirilmiş', CAMERAL: 'Kameral' };
  const STATE = {
    full: ['Tam əvəzləşib', 'var(--ok)'], partial: ['Qismən', 'var(--brass)'], none: ['Əvəzləşməyib', 'var(--bad)'],
    over: ['Artıq əvəzləşib', 'var(--over)'], blocked: ['Əvəzləşdirilməyən (314)', 'var(--gray)'], novat: ['ƏDV-siz', '#b8c4c6'], passive: ['Passiv', '#b8c4c6'], declOnly: ['Yalnız bəyannamədə', 'var(--gray)'],
  };
  const FLAG = {
    paidNotOffset: ['Ödənilib, əvəzləşməyib', 'gold'], offsetNotPaid: ['Ödəniş tapılmadı', 'red'], offsetBeforePay: ['Ödənişdən əvvəl', 'red'],
    passiveOffset: ['Passiv qaimə', 'red'], multiPeriod: ['Bir neçə ayda', 'blue'], over: ['Artıq', 'red'], old: ['90+ gün', ''],
  };
  const INV_ST = { approved: 'Təsdiqləndi', approvedBySystem: 'Sistem tərəfindən təsdiqləndi', deactivated: 'Passiv', onApproval: 'Təsdiq gözləyir', updateRequested: 'Düzəlişə qaytarıldı', updateApproval: 'Düzəlişə göndərildi', cancelRequested: 'Ləğvə göndərildi', onApprovalEdited: 'Düzəliş edildi' };
  function toast(t) { const el = $('toast'); el.textContent = t; el.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('on'), 3200); }
  const copy = (t) => navigator.clipboard.writeText(t).then(() => toast('Kopyalandı: ' + t), () => toast(t));

  // ------------------------------------------------------------------ məlumat
  let dep = null, cus = null;
  let depExcel = null;
  try { const o = await chrome.storage.local.get([DEP_KEY, CUS_KEY]); depExcel = o[DEP_KEY] || null; cus = o[CUS_KEY] || null; } catch (e) { /* */ }
  const depPortal = inputs.deposit && inputs.deposit.payments ? { ...inputs.deposit, source: 'portal' } : null;
  dep = depExcel && (!depPortal || (depExcel.at || 0) > (stored.created || 0)) ? depExcel : (depPortal || depExcel);
  let R = null;
  const F = { state: null, flag: null, month: null, q: '', tin: null, pred: null, predLabel: '' };
  let tab = 0;
  function compute() { R = E.analyze({ ...inputs, deposit: dep, customs: cus ? cus.rows : null }); }

  // ------------------------------------------------------------------ portal körpüsü (qaimənin mal sətirləri)
  async function portal(op, payload) {
    const tabs = await chrome.tabs.query({ url: 'https://new.e-taxes.gov.az/eportal/*' });
    if (!tabs.length) throw new Error('e-taxes.gov.az tabı açıq deyil — portalı açın və daxil olun.');
    let last = 'Portal cavab vermədi';
    for (const t of tabs) {
      try {
        const r = await chrome.tabs.sendMessage(t.id, { type: 'AMMO_EVEZ_API', op, ...payload });
        if (r && r.ok) return r.data;
        if (r) last = r.error || last;
      } catch (e) { last = 'Portal səhifəsini yeniləyin (F5) — AMMO ora qoşulmayıb.'; }
    }
    throw new Error(last);
  }

  // ------------------------------------------------------------------ başlıq
  function renderHead() {
    const o = R.obligation || {};
    const parts = [];
    if (R.company) parts.push(R.company);
    if (R.ownTin) parts.push('VÖEN ' + R.ownTin);
    parts.push(`Dövr: ${dmy(R.range.from)} – ${dmy(R.range.to)}`);
    if (o.start) parts.push(`ƏDV mükəlləfiyyəti: ${E.ymLabel(o.start)}${o.end ? ' – ' + E.ymLabel(o.end) : ' – davam edir'} (${o.source || ''})`);
    $('sub').textContent = parts.join('  ·  ');
    document.title = `ƏDV Əvəzləşməsi — ${dmy(R.range.from)}–${dmy(R.range.to)}`;
  }

  // ------------------------------------------------------------------ hero
  function renderHero() {
    const T = R.totals;
    const pct = T.pct;
    const C = 2 * Math.PI * 70;
    const kpi = (cls, label, val, small, click) => `<div class="kpi ${cls}${click ? ' click' : ''}" ${click ? `data-go="${click}"` : ''}><span>${esc(label)}</span><b>${val}</b><small>${small || ''}</small></div>`;
    const missedTile = dep
      ? kpi('gold', 'Əvəzləşmə HÜQUQU VAR — əvəzləşməyib', money(T.rightVat), `${T.rightCount} qaimə · depozitdən ödənilib — <b>əvəzləşdirin</b>`, 'rightYes')
        + kpi('bad', 'Əvəzləşmə hüququ YOXDUR', money(T.noRightVat), `${T.noRightCount} qaimə · ƏDV depozitdən ödənilməyib`, 'rightNo')
      : kpi('info', 'Əvəzləşmə hüququ', '—', 'ƏDV depozit hesabı oxunmadı — «Mənbələr»', 'src');
    const custTile = R.gbs.length
      ? kpi(T.customsRemaining > 0.01 ? 'bad' : 'ok', 'İdxal (gömrük) ƏDV-si', money(T.customsVat || T.customsOff), `${R.gbs.length} YGB · əvəzləşib ${money(T.customsOff)}`, 'customs')
      : kpi('info', 'İdxal (gömrük) ƏDV-si', '—', 'YGB tapılmadı və ya gömrük məlumatı yoxdur', 'src');
    const states = ['full', 'partial', 'none', 'over', 'blocked', 'passive', 'novat'].map((s) => {
      const c = s === 'novat' ? T.novat : s === 'passive' ? T.passive : T[s];
      if (!c) return '';
      return `<button class="chip${F.state === s ? ' on' : ''}" data-state="${s}"><i style="background:${STATE[s][1]}"></i>${STATE[s][0]} <b>${c}</b></button>`;
    }).join('');
    $('hero').innerHTML = `
      <div class="ringcard">
        <div class="ring"><svg viewBox="0 0 170 170"><circle cx="85" cy="85" r="70" fill="none" stroke="rgba(255,255,255,.14)" stroke-width="16"/>
          <circle cx="85" cy="85" r="70" fill="none" stroke="#d9a93a" stroke-width="16" stroke-linecap="round" stroke-dasharray="${(C * Math.min(pct, 100)) / 100} ${C}"/></svg>
          <div class="c"><b>${pct.toLocaleString('az-AZ')}%</b><small>alış ƏDV-sinin<br>əvəzləşən hissəsi</small></div></div>
        <div class="cap">${T.invoices} qaimə · ${T.full} tam · ${T.partial} qismən · ${T.none} əvəzləşməyib</div>
      </div>
      <div class="kpis">
        ${kpi('', 'Alış qaimələrində ƏDV', money(T.vat), `${T.invoices} qaimə (ƏDV-li)`)}
        ${kpi('ok', 'Əvəzləşib', money(T.offVat), `Bəyannamələrdə: ${money(T.declOffVat)}`, 'full')}
        ${kpi('bad', 'Hələ əvəzləşməyib (qalıq)', money(T.remaining), `${T.none + T.partial} qaimə`, 'open')}
        ${missedTile}
        ${custTile}
        ${kpi('', 'Əlavə 1-də olub, tapılmayan', String(T.orphans), T.orphans ? money(T.orphanVat) + ' ƏDV' : 'hamısı uyğundur', T.orphans ? 'orphans' : '')}
        ${kpi('', 'Əvvəlki dövrlərin qaimələri', String(T.earlier), T.earlier ? money(T.earlierVat) + ' — seçilmiş dövrdə əvəzləşib' : '—', T.earlier ? 'orphans' : '')}
        ${kpi('', 'Bəyannamə ayları', String(R.decls.length), `${R.months.filter((m) => m.state === 'nodecl').length} ay bəyannaməsiz`, 'decls')}
        <div class="states">${states}</div>
      </div>`;
    $('hero').querySelectorAll('[data-go]').forEach((el) => el.onclick = () => go(el.dataset.go));
    $('hero').querySelectorAll('[data-state]').forEach((el) => el.onclick = () => { F.state = F.state === el.dataset.state ? null : el.dataset.state; F.flag = null; F.pred = null; tab = 0; renderAll(true); });
  }

  // ------------------------------------------------------------------ tapıntılar
  function renderAlerts() {
    const ic = { bad: '!', warn: '?', info: 'i' };
    const showAll = renderAlerts.all;
    const hidden = showAll ? 0 : R.alerts.filter((a) => a.level === 'info').length;
    $('alerts').innerHTML = R.alerts.map((a, i) => (!showAll && a.level === 'info') ? '' : `<div class="al ${a.level}"><div class="ic">${ic[a.level]}</div><div>
      <h4>${esc(a.title)}</h4><p>${esc(a.text)}</p>${a.amount != null ? `<div class="amt">${money(a.amount)} ₼</div>` : ''}
      ${a.filter ? `<button class="go" data-i="${i}">Siyahını göstər →</button>` : ''}</div></div>`).join('')
      + (hidden ? `<button class="chip" id="moreAl" style="justify-self:start;align-self:start">+ ${hidden} məlumat xarakterli qeyd</button>` : '')
      || '<div class="al info"><div class="ic">✓</div><div><h4>Problem tapılmadı</h4><p>Bütün yoxlamalar uğurludur.</p></div></div>';
    if ($('moreAl')) $('moreAl').onclick = () => { renderAlerts.all = true; renderAlerts(); };
    $('alerts').querySelectorAll('.go').forEach((b) => b.onclick = () => go(R.alerts[+b.dataset.i].filter));
  }

  function go(what) {
    F.state = null; F.flag = null; F.pred = null; F.month = null; F.tin = null;
    const flagFilters = { passiveOffset: 'passiveOffset', offsetNotPaid: 'offsetNotPaid', offsetBeforePay: 'offsetBeforePay', old: 'old' };
    if (what === 'src') { openSources(); return; }
    if (flagFilters[what]) { F.flag = flagFilters[what]; tab = 0; }
    else if (what === 'over' || what === 'full') { F.state = what; tab = 0; }
    else if (what === 'open') { F.pred = (i) => i.state === 'none' || i.state === 'partial'; F.predLabel = 'Əvəzləşməyən və qismən'; tab = 0; }
    else if (what === 'estimated') { F.pred = (i) => i.depEstimated; F.predLabel = 'Ödənişi təxmini bağlananlar'; tab = 0; }
    else if (what === 'rightYes' || what === 'missed') { tab = 1; rightView = 'yes'; }
    else if (what === 'rightNo') { tab = 1; rightView = 'no'; }
    else if (what === 'orphans') tab = 4;
    else if (what === 'customs') tab = 3;
    else if (what === 'unallocated') tab = 5;
    else if (what === 'mismatch' || what === 'decls') tab = 6;
    else if (what === 'nodecl') { $('cal').scrollIntoView({ block: 'center' }); return; }
    renderAll(true);
  }

  // ------------------------------------------------------------------ aylar xəritəsi
  const MST = { ok: ['Hamısı əvəzləşib', 's-ok'], warn: ['Qismən', 's-warn'], bad: ['Əvəzləşməyən var', 's-bad'], nodecl: ['Bəyannamə yoxdur', 's-nodecl'], empty: ['Alış yoxdur', 's-empty'], due: ['Bəyannamə vaxtı', 's-due'], current: ['Cari ay', 's-current'], off: ['ƏDV mükəlləfi deyil', 's-off'] };
  function renderCalendar() {
    $('legend').innerHTML = Object.entries(MST).filter(([k]) => R.months.some((m) => m.state === k)).map(([, [t, c]]) => `<span><i class="${c}"></i>${t}</span>`).join('');
    const years = [...new Set(R.months.map((m) => m.y))];
    $('cal').innerHTML = years.map((y) => {
      const cells = [];
      for (let m = 1; m <= 12; m++) {
        const mo = R.months.find((x) => x.y === y && x.m === m);
        if (!mo) { cells.push('<div class="mt s-none"></div>'); continue; }
        const st = MST[mo.state] || ['', ''];
        const dg = mo.decl ? (mo.decl.type === 'CLARIFYING' ? 'D' : mo.decl.type === 'CAMERAL' ? 'K' : 'C') : (mo.state === 'nodecl' ? '!' : '');
        const sub = mo.state === 'nodecl' ? 'bəyannamə yoxdur' : mo.remaining > 0.01 ? `qalıq ${short(mo.remaining)}` : mo.count ? `${mo.count} qaimə` : (mo.ccdVat ? `YGB ${short(mo.ccdVat)}` : st[0]);
        cells.push(`<div class="mt ${st[1]}${F.month === mo.key ? ' sel' : ''}" data-m="${mo.key}" title="${esc(mo.label)} — ${esc(st[0])}">
          ${dg ? `<span class="dg" title="${mo.decl ? esc(TYPE[mo.decl.type] || mo.decl.type) + ' bəyannamə' : 'Bəyannamə tapılmadı'}">${dg}</span>` : ''}
          <span class="mn">${MSH[m - 1]}</span><b>${mo.vat ? short(mo.vat) : '—'}</b><small>${esc(sub)}</small></div>`);
      }
      return `<div class="yr"><div class="yl">${y}</div>${cells.join('')}</div>`;
    }).join('');
    $('cal').querySelectorAll('.mt[data-m]').forEach((el) => el.onclick = () => {
      const mo = R.months.find((x) => x.key === el.dataset.m);
      if (!mo || mo.state === 'off') return;
      F.month = F.month === mo.key ? null : mo.key; tab = 0;
      renderAll(false);
    });
  }

  function renderChart() {
    const ms = R.months.filter((m) => m.oblActive);
    if (!ms.length) { $('chart').innerHTML = ''; return; }
    const W = 38, H = 150, P = 26;
    const max = Math.max(1, ...ms.map((m) => Math.max(m.vat, m.declOffVat)));
    const width = ms.length * W + 60;
    const y = (v) => Math.max(2, H - (Math.min(v, max * 1.05) / max) * (H - 10));
    let s = `<svg width="${width}" height="${H + P + 8}" role="img" aria-label="Aylar üzrə alış ƏDV-si və əvəzləşmə">`;
    [0.5, 1].forEach((f) => { s += `<line x1="40" x2="${width}" y1="${y(max * f)}" y2="${y(max * f)}" stroke="#e1e8e6"/><text class="tt" x="0" y="${y(max * f) + 4}">${short(max * f)}</text>`; });
    ms.forEach((m, i) => {
      const x = 46 + i * W;
      const g = Math.min(m.offOfThese, m.vat), r = Math.max(0, m.vat - g);
      s += `<g data-m="${m.key}" style="cursor:pointer"><title>${esc(m.label)}\nAlış ƏDV-si: ${money(m.vat)}\nBu qaimələrdən əvəzləşib: ${money(g)}\nQalıq: ${money(m.remaining)}\nBəyannamədə əvəzləşmə (Əlavə 1): ${money(m.declOffVat)}${m.ccdVat ? `\nİdxal (YGB): ${money(m.ccdVat)}` : ''}</title>`;
      s += `<rect x="${x}" y="${y(m.vat)}" width="${W - 12}" height="${H - y(m.vat)}" fill="#f1c2ca" rx="3"/>`;
      if (g) s += `<rect x="${x}" y="${y(g)}" width="${W - 12}" height="${H - y(g)}" fill="#1f7a55" rx="3"/>`;
      if (m.ccdVat) s += `<rect x="${x + W - 16}" y="${y(m.ccdVat)}" width="4" height="${H - y(m.ccdVat)}" fill="#6b3fa0" rx="1"/>`;
      if (m.declOffVat) s += `<circle cx="${x + (W - 12) / 2}" cy="${y(m.declOffVat)}" r="4.5" fill="#d9a93a" stroke="#fff" stroke-width="1.5"/>`;
      s += `<text class="tt" x="${x + (W - 12) / 2}" y="${H + 14}" text-anchor="middle">${MSH[m.m - 1]}</text>`;
      if (m.m === 1 || i === 0) s += `<text class="tt" x="${x + (W - 12) / 2}" y="${H + 26}" text-anchor="middle" style="font-weight:700">${m.y}</text>`;
      s += '</g>';
    });
    s += '</svg>';
    $('chart').innerHTML = `<div class="legend" style="margin-bottom:6px"><span><i style="background:#1f7a55"></i>Əvəzləşən alış ƏDV-si</span><span><i style="background:#f1c2ca"></i>Əvəzləşməyən qalıq</span><span><i style="background:#d9a93a;border-radius:50%"></i>Ayın bəyannaməsində əvəzləşmə (bütün qaimələr)</span><span><i style="background:#6b3fa0"></i>İdxal (YGB)</span></div>` + s;
    $('chart').querySelectorAll('g[data-m]').forEach((g) => g.onclick = () => { F.month = g.dataset.m; tab = 0; renderAll(false); });
  }

  function renderMonthBox() {
    const box = $('monthBox');
    const mo = F.month && R.months.find((m) => m.key === F.month);
    if (!mo) { box.hidden = true; return; }
    box.hidden = false;
    const d = mo.decl;
    const cell = (l, v, c) => `<div><span>${l}</span><b${c ? ` style="color:${c}"` : ''}>${v}</b></div>`;
    box.innerHTML = `<h3>${esc(mo.label)} <span class="badge ${MST[mo.state] ? 'b-' + ({ ok: 'full', warn: 'partial', bad: 'none' }[mo.state] || 'novat') : ''}">${esc((MST[mo.state] || [''])[0])}</span>
      <button class="btn" id="mClose" style="margin-left:auto">Bağla</button></h3>
      <div class="mgrid">
        ${cell('Bu ayın alış qaimələri', `${mo.count} · ${money(mo.vat)}`)}
        ${cell('Onlardan əvəzləşib', money(mo.offOfThese), 'var(--ok)')}
        ${cell('Qalıq (əvəzləşməyib)', money(mo.remaining), mo.remaining > 0.01 ? 'var(--bad)' : '')}
        ${cell('Bəyannamə', d ? `${esc(TYPE[d.type] || d.type)} · ${esc(d.reg || '')}` : (mo.state === 'nodecl' ? '<span style="color:var(--bad)">tapılmadı</span>' : '—'))}
        ${cell('Əlavə 1 — əvəzləşən (308)', `${money(mo.declOffVat)} <small class="muted">(${mo.declRows} sətir)</small>`)}
        ${cell('— bu ayın qaimələri', money(mo.declOwnVat))}
        ${cell('— əvvəlki ayların qaimələri', money(mo.declPrevVat))}
        ${mo.declNonOff ? cell('Əvəzləşdirilməyən (314)', money(mo.declNonOff)) : ''}
        ${cell('İdxal ƏDV-si (310 — YGB)', money(mo.ccdVat))}
        ${mo.outVat != null ? cell('Satış üzrə hesablanmış ƏDV', money(mo.outVat)) : ''}
        ${mo.payable != null ? cell('Büdcəyə ödənilməli (326)', money(mo.payable), mo.payable > 0 ? 'var(--nar)' : '') : ''}
        ${mo.depOut != null ? cell('Depozitdən təchizatçılara ödənən ƏDV', money(mo.depOut)) : ''}
        ${mo.budget ? cell('Depozitdən büdcəyə ödəniş', money(mo.budget)) : ''}
      </div>
      <div class="mnote">${mo.mismatch ? `⚠ 308-ci sətrin cəmi (${money(mo.l308.vat)}) Əlavə 1-in sətirlərinin cəmindən ${money(mo.mismatch)} fərqlənir. ` : ''}
      ${mo.state === 'nodecl' ? `Bu ay üzrə təqdim edilmiş ƏDV bəyannaməsi tapılmadı (son tarix ${dmy(mo.due)} idi). ` : ''}
      ${mo.state === 'due' ? `Bəyannamənin son təqdim tarixi: <b>${dmy(mo.due)}</b>. ` : ''}
      Aşağıdakı cədvəl yalnız bu ayın qaimələrini göstərir.</div>`;
    $('mClose').onclick = () => { F.month = null; renderAll(false); };
  }

  // ------------------------------------------------------------------ cədvəl
  let sortState = {};
  function table(id, cols, rows, opts = {}) {
    const ss = sortState[id];
    if (ss) {
      const c = cols[ss.i];
      const val = (r) => { const v = c.sv ? c.sv(r) : c.v ? c.v(r) : ''; return v; };
      rows = rows.slice().sort((a, b) => { const x = val(a), y = val(b); const r = typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), 'az'); return ss.d * r; });
    }
    const limit = opts.limit || 2000;
    let h = `<div class="wrap"><table><thead><tr>${cols.map((c, i) => `<th class="${c.n ? 'n' : ''}" data-i="${i}">${esc(c.t)}${ss && ss.i === i ? (ss.d > 0 ? ' ▲' : ' ▼') : ''}</th>`).join('')}</tr></thead><tbody>`;
    if (!rows.length) h += `<tr><td colspan="${cols.length}" class="empty">${opts.empty || 'Bu bölmədə məlumat yoxdur.'}</td></tr>`;
    rows.slice(0, limit).forEach((r, k) => {
      h += '<tr>' + cols.map((c) => {
        const v = c.h ? c.h(r, k) : c.v ? c.v(r, k) : '';
        return `<td class="${c.n ? 'n' : ''}${c.wrap ? ' wrapc' : ''}">${c.h ? v : c.n ? (v === '' || v == null ? '' : money(v)) : esc(v)}</td>`;
      }).join('') + '</tr>';
    });
    if (opts.totals && rows.length) h += '<tr class="total">' + cols.map((c, i) => `<td class="${c.n ? 'n' : ''}">${i === 0 ? 'Cəmi' : c.sum ? money(rows.reduce((s, r) => s + (Number(c.v(r)) || 0), 0)) : ''}</td>`).join('') + '</tr>';
    h += '</tbody></table></div>';
    if (rows.length > limit) h += `<div class="muted" style="margin-top:6px">İlk ${limit} sətir göstərilir — hamısı Excel-dədir.</div>`;
    return h;
  }
  function bindTable(root, id, rerender) {
    root.querySelectorAll('th[data-i]').forEach((th) => th.onclick = () => {
      const i = +th.dataset.i; const s = sortState[id];
      sortState[id] = s && s.i === i ? { i, d: -s.d } : { i, d: 1 };
      rerender();
    });
    root.querySelectorAll('[data-inv]').forEach((b) => b.onclick = () => openInvoice(R.invoices.find((x) => x.key === b.dataset.inv)));
    root.querySelectorAll('[data-orph]').forEach((b) => b.onclick = () => openOrphan(b.dataset.orph));
  }

  const badge = (st) => `<span class="badge b-${st}">${esc((STATE[st] || [st])[0])}</span>`;
  const flagsHtml = (i) => i.flags.filter((f) => FLAG[f] && f !== 'over').map((f) => `<span class="flag ${FLAG[f][1]}">${FLAG[f][0]}</span>`).join('');
  const progress = (i) => { const p = i.vat > 0 ? Math.min(100, ((i.offVat + i.nonOffVat) / i.vat) * 100) : 0; return `<span class="bar${i.state === 'over' ? ' over' : ''}"><i style="width:${p}%"></i></span><span class="pc">${Math.round(p)}%</span>`; };
  const serialBtn = (i) => `<button class="serial" data-inv="${esc(i.key)}" title="Qaiməni aç">${esc(i.series)} ${esc(i.number)}</button>`;

  function invList() {
    let list = R.invoices.filter((i) => i.inRange);
    if (F.month) list = list.filter((i) => E.ym(i.date) === F.month);
    if (F.state) list = list.filter((i) => i.state === F.state);
    if (F.flag) list = list.filter((i) => i.flags.includes(F.flag));
    if (F.pred) list = list.filter(F.pred);
    if (F.tin) list = list.filter((i) => i.tin === F.tin);
    if (F.q) { const q = fold(F.q); list = list.filter((i) => fold([i.series, i.number, i.serial, i.name, i.tin, i.comment].join(' ')).includes(q)); }
    return list;
  }

  function tabInvoices(body) {
    const list = invList();
    const active = [];
    if (F.month) active.push(['month', E.ymLabel(F.month)]);
    if (F.state) active.push(['state', STATE[F.state][0]]);
    if (F.flag) active.push(['flag', FLAG[F.flag][0]]);
    if (F.pred) active.push(['pred', F.predLabel]);
    if (F.tin) active.push(['tin', (R.suppliers.find((s) => s.tin === F.tin) || {}).name || F.tin]);
    const cols = [
      { t: 'Tarix', v: (i) => dmy(i.date), sv: (i) => i.date },
      { t: 'Seriya və nömrə', h: serialBtn, sv: (i) => i.series + i.number },
      { t: 'Təchizatçı', v: (i) => i.name, wrap: true },
      { t: 'VÖEN', v: (i) => i.tin },
      { t: 'ƏDV', n: true, v: (i) => i.vat, sum: true },
      { t: 'Əvəzləşib', n: true, v: (i) => i.offVat, sum: true },
      { t: 'Qalıq', n: true, v: (i) => i.remaining, sum: true },
      { t: 'Gedişat', h: progress, sv: (i) => i.pct },
      { t: 'Əvəzləşdiyi ay(lar)', v: (i) => i.periods.map(E.ymLabel).join(', ') },
    ];
    if (dep) cols.push({ t: 'Depozitdən ödənib', n: true, v: (i) => i.depPaid, sum: true }, { t: 'Hüquq', h: rightBadge, sv: (i) => i.right || '' });
    cols.push({ t: 'Vəziyyət', h: (i) => badge(i.state), sv: (i) => i.state }, { t: 'Qeyd', h: flagsHtml, sv: (i) => i.flags.join() });
    body.innerHTML = `<div class="toolbar"><input type="search" id="q" placeholder="Seriya, nömrə, təchizatçı, VÖEN və ya qeyd üzrə axtar…" value="${esc(F.q)}">
      <span class="fchips">${active.map(([k, t]) => `<span class="chip on" data-x="${k}">${esc(t)} ×</span>`).join('')}</span>
      ${active.length ? '<button class="clr" id="clr">Filtrləri sıfırla</button>' : ''}<span class="rowinfo">${list.length} qaimə</span></div>` + table('inv', cols, list, { totals: true, empty: 'Seçilmiş filtrə uyğun qaimə yoxdur.' });
    const q = $('q');
    q.oninput = () => { F.q = q.value; clearTimeout(q.t); q.t = setTimeout(() => { renderTab(); const n = $('q'); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }, 220); };
    body.querySelectorAll('[data-x]').forEach((c) => c.onclick = () => { const k = c.dataset.x; if (k === 'month') F.month = null; if (k === 'state') F.state = null; if (k === 'flag') F.flag = null; if (k === 'pred') F.pred = null; if (k === 'tin') F.tin = null; renderAll(false); });
    if ($('clr')) $('clr').onclick = () => { F.month = F.state = F.flag = F.pred = F.tin = null; F.q = ''; renderAll(false); };
    bindTable(body, 'inv', renderTab);
  }

  // ------------------------------------------------------------------ v1.20: əvəzləşmə hüququ (ƏDV depozit hesabı üzrə)
  const RIGHT = { yes: ['Hüququ var', 'b-full'], part: ['Qismən hüquq', 'b-partial'], no: ['Hüququ yoxdur', 'b-none'], unknown: ['Bilinmir', 'b-novat'] };
  const rightBadge = (i) => (i.right ? `<span class="badge ${RIGHT[i.right][1]}">${RIGHT[i.right][0]}</span>` : '');
  const WHY = { notPaid: 'ƏDV depozit hesabından ödənilməyib', partPaid: 'ƏDV-nin yalnız bir hissəsi ödənilib', passive: 'Qaimə passivdir (ləğv edilib)' };
  let rightView = 'yes';
  function tabRight(body) {
    if (!dep) {
      body.innerHTML = `<div class="empty">ƏDV depozit hesabının əməliyyatları yoxdur — əvəzləşmə hüququnu müəyyən etmək mümkün olmadı.<br>
        Panelde «ƏDV depozit hesabını portaldan avtomatik çək» seçili olaraq yenidən hesablayın və ya «Mənbələr» → depozit Excel-ini atın.</div>`;
      return;
    }
    const T = R.totals;
    const open = R.invoices.filter((i) => i.inRange && i.remaining > 0.01 && i.state !== 'novat');
    const yes = open.filter((i) => i.rightVat > 0.01), no = open.filter((i) => i.noRightVat > 0.01);
    const payMonths = (i) => [...new Set(i.payments.map((p) => E.ym(p.date)).filter(Boolean))];
    const colsYes = [
      { t: 'Tarix', v: (i) => dmy(i.date), sv: (i) => i.date },
      { t: 'Seriya və nömrə', h: serialBtn, sv: (i) => i.series + i.number },
      { t: 'Təchizatçı', v: (i) => i.name, wrap: true }, { t: 'VÖEN', v: (i) => i.tin },
      { t: 'ƏDV', n: true, v: (i) => i.vat, sum: true }, { t: 'Əvəzləşib', n: true, v: (i) => i.offVat, sum: true },
      { t: 'Depozitdən ödənib', n: true, v: (i) => i.depPaid, sum: true },
      { t: 'Əvəzləşdirilə bilər', n: true, v: (i) => i.rightVat, sum: true },
      { t: 'Ödəniş (məxaric)', h: (i) => i.payments.map((p) => `${dmy(p.date)} · ${money(p.amount)}${p.est ? ' <span class="flag">təxmini</span>' : ''}`).join('<br>'), sv: (i) => (i.payments[0] || {}).date || '' },
      { t: 'Hansı bəyannamədə (308)', v: (i) => payMonths(i).map(E.ymLabel).join(', ') },
      { t: 'Hüquq', h: rightBadge, sv: (i) => i.right },
    ];
    const colsNo = [
      { t: 'Tarix', v: (i) => dmy(i.date), sv: (i) => i.date },
      { t: 'Seriya və nömrə', h: serialBtn, sv: (i) => i.series + i.number },
      { t: 'Təchizatçı', v: (i) => i.name, wrap: true }, { t: 'VÖEN', v: (i) => i.tin },
      { t: 'ƏDV', n: true, v: (i) => i.vat, sum: true }, { t: 'Əvəzləşib', n: true, v: (i) => i.offVat, sum: true },
      { t: 'Depozitdən ödənib', n: true, v: (i) => i.depPaid, sum: true },
      { t: 'Hüququ olmayan qalıq', n: true, v: (i) => i.noRightVat, sum: true },
      { t: 'Səbəb', v: (i) => WHY[i.noRightWhy] || '', wrap: true },
      { t: 'Təchizatçıya bağlanmamış ödəniş', n: true, v: (i) => i.supplierUnallocated || '' },
      { t: 'Gün', v: (i) => i.age, sv: (i) => i.age },
    ];
    const src = dep.source === 'portal' ? `portaldan avtomatik (vat-account) · ${dmy(dep.from)} – ${dmy(dep.to)}` : `Excel faylı · ${dmy(dep.from)} – ${dmy(dep.to)}`;
    body.innerHTML = `
      <div class="rights">
        <button class="rcard yes${rightView === 'yes' ? ' on' : ''}" data-rv="yes"><span>Əvəzləşmə HÜQUQU VAR, amma əvəzləşməyib</span><b>${money(T.rightVat)} ₼</b><small>${yes.length} qaimə — ƏDV depozit hesabından təchizatçıya MƏXARİC edilib</small></button>
        <button class="rcard no${rightView === 'no' ? ' on' : ''}" data-rv="no"><span>Əvəzləşmə hüququ YOXDUR</span><b>${money(T.noRightVat)} ₼</b><small>${no.length} qaimə — ƏDV depozitdən ödənilməyib (və ya qaimə passivdir)</small></button>
      </div>
      <p class="muted">${rightView === 'yes'
        ? '<b>VM 175.1:</b> ƏDV depozit hesabından ödənildiyi üçün bu qaimələr üzrə əvəzləşmə hüququ yaranıb. Ödənişin edildiyi ayın ƏDV bəyannaməsini dəqiqləşdirərək Əlavə 1-də (308-ci sətir) göstərin — «Hansı bəyannamədə» sütunu ayı göstərir.'
        : 'Bu qaimələr üzrə ƏDV depozit hesabından təchizatçının depozit hesabına köçürülməyib — əvəzləşmə hüququ hələ yaranmayıb. ƏDV-ni depozitdən ödədiyiniz ayın bəyannaməsində əvəzləşdirə biləcəksiniz. «Təchizatçıya bağlanmamış ödəniş» doludursa — ödəniş ola bilsin bu qaimə üçündür (təyinatda nömrə yazılmayıb), yoxlayın.'}
        <br>Depozit məlumatı: ${esc(src)} · ${dep.payments.filter((p) => p.dir === 'out').length} məxaric əməliyyatı.</p>
      ${table('right_' + rightView, rightView === 'yes' ? colsYes : colsNo, rightView === 'yes' ? yes : no, { totals: true, empty: rightView === 'yes' ? 'Hüququ olub əvəzləşməyən qaimə yoxdur — əla!' : 'Depozitdən ödənilməmiş qaimə yoxdur.' })}`;
    body.querySelectorAll('[data-rv]').forEach((b) => b.onclick = () => { rightView = b.dataset.rv; renderTabs(); renderTab(); });
    bindTable(body, 'right_' + rightView, renderTab);
  }

  function tabSuppliers(body) {
    const cols = [
      { t: 'Təchizatçı', h: (s) => `<button class="serial" data-tin="${s.tin}">${esc(s.name)}</button>`, sv: (s) => s.name },
      { t: 'VÖEN', v: (s) => s.tin }, { t: 'Qaimə', n: false, v: (s) => s.count, sv: (s) => s.count },
      { t: 'ƏDV', n: true, v: (s) => s.vat, sum: true }, { t: 'Əvəzləşib', n: true, v: (s) => s.offVat, sum: true },
      { t: 'Qalıq', n: true, v: (s) => s.remaining, sum: true },
      { t: 'Gedişat', h: (s) => progress({ vat: s.vat, offVat: s.offVat, nonOffVat: 0, state: '' }), sv: (s) => s.vat ? s.offVat / s.vat : 0 },
      { t: 'Əvəzləşməyən qaimə', v: (s) => s.none || '', sv: (s) => s.none },
    ];
    if (dep) cols.push({ t: 'Depozitdən ödənib', n: true, v: (s) => s.depPaid, sum: true }, { t: 'Ödənib, əvəzləşməyib', n: true, v: (s) => s.missed, sum: true });
    body.innerHTML = '<p class="muted" style="margin-top:0">Təchizatçının adına basın — yalnız onun qaimələri göstəriləcək.</p>' + table('sup', cols, R.suppliers, { totals: true });
    body.querySelectorAll('[data-tin]').forEach((b) => b.onclick = () => { F.tin = b.dataset.tin; tab = 0; renderAll(true); });
    bindTable(body, 'sup', renderTab);
  }

  function tabCustoms(body) {
    const cols = [
      { t: 'Tarix', v: (g) => dmy(g.date), sv: (g) => g.date || '' },
      { t: 'YGB nömrəsi', h: (g) => `<button class="serial" data-copy="${g.gb}" title="Kopyala">${esc(g.gb)}</button>`, sv: (g) => g.gb },
      { t: 'Göndərən / mal', v: (g) => [g.name, (g.goods || []).join('; ')].filter(Boolean).join(' — ').slice(0, 160), wrap: true },
      { t: 'Gömrük dəyəri', n: true, v: (g) => g.value, sum: true },
      { t: 'Gömrükdə ödənən ƏDV (32)', n: true, v: (g) => (g.inCustoms ? g.vat : ''), sum: true },
      { t: 'Bəyannamədə əvəzləşib (310)', n: true, v: (g) => g.offVat, sum: true },
      { t: 'Qalıq', n: true, v: (g) => g.remaining, sum: true },
      { t: 'Ay(lar)', v: (g) => g.periods.map(E.ymLabel).join(', ') },
      { t: 'Depozitdən ödəniş', v: (g) => (g.paidBy ? `${dmy(g.paidBy.date)} · ${money(g.paidBy.amount)}` : '') },
      { t: 'Vəziyyət', h: (g) => badge(g.state), sv: (g) => g.state },
    ];
    const totalOnly = R.months.filter((m) => m.ccdVat > 0.01).length && !R.gbs.length;
    body.innerHTML = `<p class="muted" style="margin-top:0">İdxal zamanı gömrükdə ödənilmiş ƏDV yük gömrük bəyannaməsi (YGB) və ödəniş sənədi əsasında əvəzləşdirilir (VM 175.2) — bəyannamənin 310-cu sətri.
      ${cus ? `Gömrük məlumatı: ${cus.rows.length} sətir (${esc(cus.src || '')}, ${new Date(cus.at).toLocaleDateString('az-AZ')}).` : '<b>Gömrükdə ödənilən ƏDV ilə tutuşdurmaq üçün «Mənbələr» → gömrük məlumatını əlavə edin.</b>'}
      ${totalOnly ? ' Portal YGB-lərin siyahısını vermədi — yalnız ayların 310-cu sətir cəmi göstərilir (Aylar xəritəsində).' : ''}</p>` + table('gb', cols, R.gbs, { totals: true, empty: 'Seçilmiş dövrdə YGB tapılmadı.' });
    body.querySelectorAll('[data-copy]').forEach((b) => b.onclick = () => copy(b.dataset.copy));
    bindTable(body, 'gb', renderTab);
  }

  function tabOrphans(body) {
    const rows = R.orphans.map((o) => ({ ...o, kind: 'Tapılmadı' })).concat(R.earlier.map((o) => ({ ...o, kind: 'Əvvəlki dövrün qaiməsi' })));
    const cols = [
      { t: 'Bəyannamə ayı', v: (o) => E.ymLabel(o.period), sv: (o) => o.period },
      { t: 'Sətir', v: (o) => o.code },
      { t: 'VÖEN', v: (o) => o.tin },
      { t: 'Qaimə tarixi', v: (o) => dmy(o.date), sv: (o) => o.date },
      { t: 'Seriya və nömrə', h: (o) => `<button class="serial" data-orph="${esc(o.series + '|' + o.number)}">${esc(o.series)} ${esc(o.number)}</button>`, sv: (o) => o.series + o.number },
      { t: 'Ödənilmiş məbləğ', n: true, v: (o) => o.paidAmount, sum: true },
      { t: 'Ödənilmiş ƏDV', n: true, v: (o) => o.paidVat, sum: true },
      { t: 'Səbəb', v: (o) => o.kind },
    ];
    body.innerHTML = `<p class="muted" style="margin-top:0">Bəyannamələrin Əlavə 1-ində göstərilib, amma seçilmiş dövrün alış qaimələri arasında yoxdur. «Əvvəlki dövrün qaiməsi» — qaimə dövrdən əvvəl yazılıb, sonra ödənilib (normaldır). «Tapılmadı» — seriya/nömrə səhv yazıla, qaimə ləğv edilə bilər: nömrəyə basın, AMMO portalda axtaracaq.</p>` + table('orph', cols, rows, { totals: true, empty: 'Hamısı uyğundur — Əlavə 1-dəki bütün qaimələr tapıldı.' });
    bindTable(body, 'orph', renderTab);
  }

  function tabUnallocated(body) {
    if (!dep) { body.innerHTML = '<div class="empty">ƏDV depozit hesabının əməliyyatları yüklənməyib. «Mənbələr» düyməsi ilə portaldan yüklədiyiniz Excel-i əlavə edin.</div>'; return; }
    const cols = [
      { t: 'Tarix', v: (p) => dmy(p.date), sv: (p) => p.date }, { t: 'Alan', v: (p) => p.name, wrap: true }, { t: 'VÖEN', v: (p) => p.tin },
      { t: 'Ödəniş', n: true, v: (p) => p.amount, sum: true }, { t: 'Bağlanmayan hissə', n: true, v: (p) => p.left, sum: true },
      { t: 'Təyinat', v: (p) => p.desc, wrap: true },
    ];
    body.innerHTML = `<p class="muted" style="margin-top:0">Depozit hesabından təchizatçılara ödənilən, amma heç bir alış qaiməsinə bağlanmayan ƏDV. Adətən avansdır — avans qaiməsini tələb edin. Depozit faylı: ${esc(dep.company || '')} · ${dmy(dep.from)} – ${dmy(dep.to)} · ${dep.payments.length} əməliyyat.</p>` + table('una', cols, R.unallocated, { totals: true, empty: 'Bütün ödənişlər qaimələrə bağlandı.' });
    bindTable(body, 'una', renderTab);
  }

  function tabDecls(body) {
    const cols = [
      { t: 'Ay', v: (m) => m.label, sv: (m) => m.key },
      { t: 'Bəyannamə', v: (m) => (m.decl ? `${TYPE[m.decl.type] || m.decl.type}` : m.state === 'nodecl' ? 'YOXDUR' : '') },
      { t: 'Sənəd nömrəsi', v: (m) => (m.decl ? m.decl.reg : '') },
      { t: 'Əlavə 1 sətir', v: (m) => m.declRows || '' },
      { t: 'Əvəzləşən ƏDV (308)', n: true, v: (m) => m.declOffVat, sum: true },
      { t: '308 cəmi (bəyannamə)', n: true, v: (m) => (m.l308 ? m.l308.vat : '') },
      { t: 'Fərq', n: true, v: (m) => m.mismatch || '' },
      { t: 'İdxal ƏDV (310)', n: true, v: (m) => m.ccdVat, sum: true },
      { t: 'Satış ƏDV-si', n: true, v: (m) => (m.outVat == null ? '' : m.outVat), sum: true },
      { t: 'Büdcəyə ödənilməli', n: true, v: (m) => (m.payable == null ? '' : m.payable), sum: true },
      { t: 'Vəziyyət', h: (m) => `<span class="badge ${({ ok: 'b-full', warn: 'b-partial', bad: 'b-none', nodecl: 'b-none' })[m.state] || 'b-novat'}">${esc((MST[m.state] || [''])[0])}</span>` },
    ];
    const drafts = (inputs.declDrafts || []);
    body.innerHTML = `<p class="muted" style="margin-top:0">Hər ay üçün son (qüvvədə olan) ƏDV bəyannaməsi götürülür: dəqiqləşdirilmiş varsa — o. ${drafts.length ? `Qaralaması olan aylar: ${drafts.map(E.ymLabel).join(', ')}.` : ''}</p>` + table('dec', cols, R.months.filter((m) => m.oblActive), { totals: true });
    bindTable(body, 'dec', renderTab);
  }

  function tabLaw(body) {
    const L = [
      ['VM 175.1', 'Əvəzləşdirmənin əsası', 'Alınmış mal, iş və xidmətlər üzrə elektron qaimə-faktura əsasında. Dəyər alıcının bank hesabından satıcının bank hesabına, ƏDV isə ƏDV depozit hesabından satıcının depozit hesabına ödənilməlidir. Əvəzləşmə ödənişin aparıldığı hesabat dövründə edilir; qismən ödənişdə — ödənilmiş hissəyə mütənasib ƏDV. Bəyannamədə: <b>308-ci sətir</b>.'],
      ['VM 175.2', 'İdxal', 'Gömrükdə ödənilmiş ƏDV yük gömrük bəyannaməsi və ödənişi təsdiq edən sənəd əsasında əvəzləşdirilir (ödəniş üsulundan asılı olmayaraq). Bəyannamədə: <b>310-cu sətir</b>, Əlavə 1 — YGB siyahısı.'],
      ['VM 175.3', 'Əvəzləşdirilməyən ƏDV', 'ƏDV-dən azad və ya ƏDV-yə cəlb olunmayan əməliyyatlar, qeyri-sahibkarlıq məqsədləri üçün alınan mallar üzrə ödənilmiş ƏDV əvəzləşdirilmir — <b>314-cü sətir</b>. Qarışıq istifadədə əvəzləşmə mütənasib aparılır.'],
      ['Nağd', 'Nağd ödəniş', 'Nağd aparılan əməliyyatlar, qəbz, çek və nağd ödəniş sənədləri əsasında ƏDV əvəzləşdirilmir.'],
      ['Risk', 'Riskli ödəyicilər', 'Riskli vergi ödəyicisindən və ya əmtəəsiz (faktiki mal/xidmət olmadan rəsmiləşdirilən) əməliyyatlar üzrə alınan qaimələr əvəzləşmə üçün qəbul edilmir. Əsas təchizatçıların statusunu vaxtaşırı yoxlayın.'],
      ['316', '0% dərəcə', 'ƏDV-yə sıfır (0) dərəcə ilə cəlb olunan əməliyyatlar üzrə ödənilmiş məbləğ ayrıca — <b>316-cı sətir</b>.'],
      ['Müddət', 'Bəyannamə', 'ƏDV bəyannaməsi hesabat ayından sonrakı ayın 20-dək təqdim edilir. Ödəniş ayının bəyannaməsində unudulmuş əvəzləşmə həmin ay üzrə dəqiqləşdirilmiş bəyannamə ilə bərpa edilə bilər.'],
      ['Avans', 'Avans ödənişləri', 'Avans üzrə ödənilmiş ƏDV avans qaimə-fakturası (portalda «Alınmış avans ödənişləri barədə» növü) əsasında əvəzləşdirilir. Avans qaiməsi olmadan depozitdən ödənilmiş ƏDV əvəzləşdirilə bilməz.'],
      ['Agent', 'Agent / komisyonçu', 'Vəkalətverən tərəfindən agentə verilən qaimə alıcı üçün əvəzləşmə əsası deyil; alıcı agentin «alıcıya təqdim» qaiməsi və ödəniş əsasında əvəzləşdirir.'],
    ];
    body.innerHTML = `<div class="law">${L.map(([c, t, p]) => `<div><h4><span class="code">${c}</span>${t}</h4><p>${p}</p></div>`).join('')}</div>
      <div class="disc">Məlumat Azərbaycan Respublikasının Vergi Məcəlləsi və Dövlət Vergi Xidmətinin izahlarına əsasən qısa xülasədir, hüquqi məsləhət deyil. Mübahisəli hallarda vergi məsləhətçisinə və ya 195 Çağrı Mərkəzinə müraciət edin. Mənbələr: e-qanun.az (Vergi Məcəlləsi, 175-ci maddə), taxes.gov.az.</div>`;
  }

  const TABS = [
    { t: 'Qaimələr', n: () => invList().length, f: tabInvoices },
    { t: 'Əvəzləşmə hüququ', n: () => (dep ? `${R.totals.rightCount} / ${R.totals.noRightCount}` : '—'), f: tabRight },
    { t: 'Təchizatçılar', n: () => R.suppliers.length, f: tabSuppliers },
    { t: 'Gömrük (YGB)', n: () => R.gbs.length, f: tabCustoms },
    { t: 'Əlavə 1 — tapılmayan', n: () => R.orphans.length + R.earlier.length, f: tabOrphans },
    { t: 'Depozit — bağlanmayan', n: () => (dep ? R.unallocated.length : '—'), f: tabUnallocated },
    { t: 'Bəyannamələr', n: () => R.decls.length, f: tabDecls },
    { t: 'Qanunvericilik', n: () => '', f: tabLaw },
  ];
  function renderTabs() {
    $('tabs').innerHTML = TABS.map((t, i) => `<button class="${i === tab ? 'active' : ''}" data-t="${i}">${t.t}${t.n() !== '' ? `<em>${t.n()}</em>` : ''}</button>`).join('');
    $('tabs').querySelectorAll('button').forEach((b) => b.onclick = () => { tab = +b.dataset.t; renderTabs(); renderTab(); });
  }
  function renderTab() { TABS[tab].f($('tabBody')); }

  function renderAll(scroll) {
    renderHero(); renderCalendar(); renderMonthBox(); renderTabs(); renderTab();
    if (scroll) $('tabs').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // ------------------------------------------------------------------ qaimə kartı
  function openDrawer(title, html) {
    $('dTitle').innerHTML = title; $('dBody').innerHTML = html;
    $('drawer').classList.add('on'); $('shade').classList.add('on'); $('drawer').setAttribute('aria-hidden', 'false');
  }
  function closeDrawer() { $('drawer').classList.remove('on'); $('shade').classList.remove('on'); $('drawer').setAttribute('aria-hidden', 'true'); }
  $('dClose').onclick = closeDrawer; $('shade').onclick = closeDrawer;
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeDrawer(); $('srcModal').hidden = true; } });

  function advice(i) {
    const a = [];
    if (i.state === 'none' && !i.depPaid) a.push('ƏDV hələ əvəzləşdirilməyib. Əgər təchizatçıya ödəniş edilməyibsə — əsas məbləği bank hesabından, ƏDV-ni depozit hesabından ödəyin; ödəniş ayının bəyannaməsində (308) əvəzləşəcək.');
    if (i.flags.includes('paidNotOffset')) a.push(`Depozitdən ${money(i.depPaid)} ödənilib, amma yalnız ${money(i.offVat)} əvəzləşib. Fərqi (${money(i.missed)}) ödəniş ayının bəyannaməsini dəqiqləşdirərək əvəzləşdirin.`);
    if (i.state === 'partial') a.push(`Qaimənin ${Math.round(i.pct)}%-i əvəzləşib. Qalan ${money(i.remaining)} ƏDV ödəniləndə növbəti bəyannamədə əvəzləşdiriləcək.`);
    if (i.state === 'over') a.push(`Qaimədəki ƏDV-dən ${money(i.offVat - i.vat)} artıq əvəzləşdirilib — dəqiqləşdirilmiş bəyannamə ilə düzəldin.`);
    if (i.flags.includes('passiveOffset')) a.push('Qaimə passiv edilib, amma əvəzləşmə qalıb — düzəliş qaiməsini yoxlayın.');
    if (i.flags.includes('offsetNotPaid')) a.push('Əvəzləşdirilib, amma yüklənmiş depozit əməliyyatlarında ödəniş tapılmadı. Ödənişin ƏDV depozit hesabından aparıldığını yoxlayın.');
    if (i.flags.includes('offsetBeforePay')) a.push('Əvəzləşmə ödənişdən əvvəlki aya düşüb — kameral yoxlamada sual yarada bilər.');
    if (i.depEstimated) a.push('Depozit ödənişinin təyinatında bu qaimə göstərilməyib; ödəniş AMMO tərəfindən təxmini bağlanıb.');
    if (i.right === 'yes' || i.right === 'part') a.push(`ƏVƏZLƏŞMƏ HÜQUQU VAR: ${money(i.rightVat)} — ƏDV depozit hesabından ödənilib (${[...new Set(i.payments.map((p) => E.ymLabel(E.ym(p.date))))].join(', ')}). Həmin ayın bəyannaməsini dəqiqləşdirib 308-ci sətirdə göstərin.`);
    if (i.right === 'no' || i.right === 'part') a.push(`ƏVƏZLƏŞMƏ HÜQUQU YOXDUR: ${money(i.noRightVat)} — ${WHY[i.noRightWhy] || 'ödəniş tapılmadı'}.${i.supplierUnallocated ? ` Bu təchizatçıya ${money(i.supplierUnallocated)} qaiməyə bağlanmamış depozit ödənişi var — bəlkə bu qaimə üçündür.` : ''}`);
    if (i.state === 'full') a.push(`Tam əvəzləşib${i.lag != null ? ` — qaimədən ${i.lag === 0 ? 'həmin ay' : i.lag + ' ay sonra'}` : ''}.`);
    return a;
  }

  function openInvoice(i) {
    if (!i) return;
    const tl = [];
    tl.push(`<li class="inv"><b>${dmy(i.date)}</b> — qaimə yazılıb · ƏDV ${money(i.vat)}<small>${esc(INV_ST[i.status] || i.status)} · ${i.type === 'corrected' ? 'Düzəliş' : 'Cari'}</small></li>`);
    const ev = [];
    i.payments.forEach((p) => ev.push({ d: p.date || '', h: `<li class="pay"><b>${dmy(p.date)}</b> — depozitdən ödəniş ${money(p.amount)}${p.of > p.amount + 0.01 ? ` <span class="muted">(${money(p.of)} ödənişin hissəsi)</span>` : ''}${p.est ? ' <span class="flag">təxmini</span>' : ''}<small>${esc(p.desc || '')}</small></li>` }));
    i.offsets.forEach((o) => ev.push({ d: o.period + '-28', h: `<li class="off"><b>${E.ymLabel(o.period)}</b> — bəyannamədə əvəzləşib ${money(o.paidVat)} <span class="muted">(dəyər ${money(o.paidAmount)}, sətir ${esc(o.code)})</span><small>${esc(TYPE[o.declType] || o.declType || '')} bəyannamə · ${esc(o.reg || '')}</small></li>` }));
    i.nonOffsets.forEach((o) => ev.push({ d: o.period + '-28', h: `<li class="warnli"><b>${E.ymLabel(o.period)}</b> — 314: əvəzləşdirilməyən ${money(o.paidVat)}</li>` }));
    ev.sort((a, b) => a.d.localeCompare(b.d)).forEach((e) => tl.push(e.h));
    if (i.remaining > 0.01) tl.push(`<li class="warnli"><b>Bu gün</b> — əvəzləşməyən qalıq ${money(i.remaining)}<small>${i.age} gün keçib</small></li>`);
    const adv = advice(i);
    openDrawer(`<b>${esc(i.name)}</b><small>${esc(i.series)} ${esc(i.number)} · ${dmy(i.date)} · VÖEN ${esc(i.tin)}</small>`, `
      <div class="card2"><div class="big3"><div><span>Qaimədə ƏDV</span><b>${money(i.vat)}</b></div><div class="g"><span>Əvəzləşib</span><b>${money(i.offVat)}</b></div><div class="${i.remaining > 0.01 ? 'r' : ''}"><span>Qalıq</span><b>${money(i.remaining)}</b></div></div>
        <div style="margin-top:10px">${progress(i)} &nbsp; ${badge(i.state)} ${flagsHtml(i)}</div></div>
      ${adv.length ? `<div class="card2"><h4>Nə etməli</h4><ul class="why">${adv.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
      <div class="card2"><h4>Tarixçə</h4><ul class="tl">${tl.join('')}</ul></div>
      <div class="card2"><h4>Qaimə</h4><div class="kv">
        <span>Seriya və nömrə</span><div><b>${esc(i.series)} ${esc(i.number)}</b></div>
        <span>Təchizatçı</span><div>${esc(i.name)}</div><span>VÖEN</span><div>${esc(i.tin)}</div>
        <span>Tarix</span><div>${dmy(i.date)}</div>
        <span>ƏDV-yə cəlb edilən</span><div>${money(i.base)}</div><span>Yekun məbləğ</span><div>${money(i.total)}</div>
        ${i.comment ? `<span>Əsas qeyd</span><div>${esc(i.comment)}</div>` : ''}
      </div>
      <div class="btnrow"><button class="btn" id="dCopy">Seriya-nömrəni kopyala</button><button class="btn" id="dSup">Bu təchizatçının qaimələri</button><button class="btn" id="dPortal">Portalda qaimələr</button></div></div>
      <div class="card2"><h4>Mallar / xidmətlər</h4><div id="dItems" class="muted">Portaldan yüklənir…</div></div>`);
    $('dCopy').onclick = () => copy(`${i.series}${i.number}`);
    $('dSup').onclick = () => { closeDrawer(); F.tin = i.tin; tab = 0; F.month = null; renderAll(true); };
    $('dPortal').onclick = () => { copy(`${i.series}${i.number}`); chrome.tabs.create({ url: 'https://new.e-taxes.gov.az/eportal/invoice' }); };
    loadItems(i);
  }

  const detCache = new Map();
  async function loadItems(i) {
    const box = () => $('dItems');
    try {
      let det = detCache.get(i.key);
      if (!det) {
        let id = i.id, src = i.sourceSystem;
        if (!id) { const f = await portal('serial', { serial: i.series + i.number }); if (!f) throw new Error('Qaimə portalda tapılmadı.'); id = f.id; src = f.sourceSystem; }
        det = await portal('detail', { id, sourceSystem: src });
        detCache.set(i.key, det);
      }
      if (!box()) return;
      const items = (det && det.items) || [];
      if (!items.length) { box().textContent = 'Qaimədə mal sətri tapılmadı.'; return; }
      const n0 = (v) => Number(v) || 0;
      box().classList.remove('muted');
      box().innerHTML = `<div class="wrap" style="max-height:340px"><table class="items"><thead><tr><th>Malın / xidmətin adı</th><th>Kod</th><th>Vahid</th><th class="n">Miqdar</th><th class="n">Qiymət</th><th class="n">Dəyər</th><th class="n">ƏDV</th></tr></thead><tbody>
        ${items.map((it) => `<tr><td class="wrapc">${esc(it.productName || '')}</td><td>${esc((it.productGroup && it.productGroup.code) || '')}</td><td>${esc(it.unit || (it.unitFromDict && (it.unitFromDict.name || it.unitFromDict.code)) || '')}</td>
          <td class="n">${n0(it.quantity).toLocaleString('az-AZ')}</td><td class="n">${money(it.pricePerUnit)}</td><td class="n">${money(it.cost)}</td><td class="n">${money(n0(it.vat18) * 0.18)}</td></tr>`).join('')}
        </tbody></table></div>${det.invoiceComment2 ? `<div class="muted" style="margin-top:6px">Əlavə qeyd: ${esc(det.invoiceComment2)}</div>` : ''}`;
    } catch (e) { if (box()) box().innerHTML = `Mal sətirləri alınmadı: ${esc(e.message)}<br><span class="muted">e-taxes.gov.az tabını açıq saxlayın (daxil olunmuş vəziyyətdə) və qaiməni yenidən açın.</span>`; }
  }

  async function openOrphan(sk) {
    const [series, number] = sk.split('|');
    const rows = R.orphans.concat(R.earlier).filter((o) => o.series === series && o.number === number);
    const o = rows[0] || {};
    openDrawer(`<b>${esc(series)} ${esc(number)}</b><small>Əlavə 1-də var · VÖEN ${esc(o.tin || '')}</small>`, `
      <div class="card2"><h4>Bəyannamələrdə</h4><ul class="tl">${rows.map((r) => `<li class="off"><b>${E.ymLabel(r.period)}</b> — əvəzləşib ${money(r.paidVat)} <span class="muted">(dəyər ${money(r.paidAmount)}, sətir ${esc(r.code)})</span><small>${esc(r.reg || '')}</small></li>`).join('')}</ul></div>
      <div class="card2"><h4>Portalda axtarış</h4><div id="dFind" class="muted">Qaimə portalda axtarılır…</div></div>`);
    try {
      const f = await portal('serial', { serial: series + number });
      if (!f) { $('dFind').innerHTML = '<b style="color:var(--bad)">Bu seriya-nömrə ilə qaimə portalda tapılmadı.</b> Bəyannamədə səhv yazılmış ola bilər — dəqiqləşdirin.'; return; }
      const s = f.sender || {};
      $('dFind').innerHTML = `<div class="kv"><span>Təchizatçı</span><div>${esc(s.name || '')} (${esc(s.tin || '')})</div><span>Tarix</span><div>${esc(E.dmy(E.isoDate(f.createdAt)))}</div><span>ƏDV</span><div>${money(f.vat)}</div><span>Status</span><div>${esc(INV_ST[f.status] || f.status)}</div><span>İstiqamət</span><div>${f._direction === 'inbox' ? 'Gələn' : 'Göndərilən (!)'}</div></div>`;
    } catch (e) { $('dFind').textContent = 'Axtarış alınmadı: ' + e.message; }
  }

  // ------------------------------------------------------------------ mənbələr (depozit + gömrük)
  function openSources() {
    $('srcModal').hidden = false;
    const depInfo = (depPortal ? `<div class="srcst ok">✓ Portaldan avtomatik: ${depPortal.payments.length} əməliyyat · ${dmy(depPortal.from)} – ${dmy(depPortal.to)}${dep === depPortal ? ' (istifadə olunur)' : ''}</div>` : '')
      + (depExcel ? `<div class="srcst ok">✓ Excel: ${depExcel.payments.length} əməliyyat · ${dmy(depExcel.from)} – ${dmy(depExcel.to)}${dep === depExcel ? ' (istifadə olunur)' : ''} <button class="clr" id="depDel">sil</button></div>` : '')
      + (!depPortal && !depExcel ? '<div class="srcst">Yüklənməyib</div>' : '')
      + `<div class="btnrow" style="margin-top:8px"><button class="btn pri" id="depLive">Portaldan yenidən çək (${dmy(R.range.from)} – bu gün)</button><button class="btn" id="depDiag">Diaqnostika faylı</button><button class="btn" id="depForget">Sorğunu yenidən öyrən</button></div>`;
    const cusInfo = cus ? `<div class="srcst ok">✓ ${cus.rows.length} sətir · ${esc(cus.src || '')} · ${new Date(cus.at).toLocaleDateString('az-AZ')} <button class="clr" id="cusDel">sil</button></div>` : '<div class="srcst">Yüklənməyib</div>';
    $('srcBody').innerHTML = `
      <div class="src"><h4>1. ƏDV depozit hesabının əməliyyatları</h4>
        <p>Portal: <b>ƏDV depozit hesabı → Əməliyyatlar (köçürmələr, ödənişlər) → Excel</b>. Tarixi ƏDV mükəlləfiyyətinin başlanğıcından bu günə seçin. AMMO hansı qaimənin ƏDV-si ödənilib, amma əvəzləşməyib — onu tapacaq.</p>
        <div class="drop" id="depDrop"><b>Excel faylını bura atın</b> və ya basıb seçin<input type="file" id="depFile" accept=".xlsx" hidden></div>${depInfo}</div>
      <div class="src"><h4>2. Gömrük — idxal ƏDV-si</h4>
        <p>a) <b>e.customs.gov.az</b> açıqdırsa (Asan İmza ilə daxil olunubsa) — bir kliklə çəkin; b) və ya «AMMO Gömrük» pəncərəsinin Excel-ini atın.</p>
        <div class="btnrow" style="margin-bottom:10px"><button class="btn pri" id="cusLive">Gömrük saytından çək</button></div>
        <div class="drop" id="cusDrop"><b>AMMO Gömrük Excel-ini bura atın</b> və ya basıb seçin<input type="file" id="cusFile" accept=".xlsx" hidden></div>${cusInfo}</div>`;
    const wire = (dropId, fileId, fn) => {
      const d = $(dropId), f = $(fileId);
      d.onclick = () => f.click();
      d.ondragover = (e) => { e.preventDefault(); d.classList.add('hover'); };
      d.ondragleave = () => d.classList.remove('hover');
      d.ondrop = (e) => { e.preventDefault(); d.classList.remove('hover'); if (e.dataTransfer.files[0]) fn(e.dataTransfer.files[0]); };
      f.onchange = () => { if (f.files[0]) fn(f.files[0]); };
    };
    wire('depDrop', 'depFile', loadDeposit);
    wire('cusDrop', 'cusFile', loadCustomsFile);
    $('cusLive').onclick = loadCustomsLive;
    if ($('depDel')) $('depDel').onclick = async () => { depExcel = null; dep = depPortal; await chrome.storage.local.remove(DEP_KEY); recompute('Depozit Excel-i silindi.'); openSources(); };
    $('depLive').onclick = async () => {
      try {
        toast('ƏDV depozit hesabı portaldan oxunur…');
        const d = await portal('deposit', { from: R.range.from, to: R.today });
        dep = { ...d, source: 'portal' }; inputs.deposit = d; stored.created = Date.now();
        await chrome.storage.local.set({ [key]: stored });
        recompute(`Depozit: portaldan ${d.payments.length} əməliyyat alındı.`); openSources();
      } catch (e) { toast('Portaldan oxunmadı: ' + e.message); }
    };
    $('depDiag').onclick = async () => {
      const o = await chrome.storage.local.get(['ammo_vatacc_tpl', 'ammo_vatacc_debug']);
      const blob = new Blob([JSON.stringify({ version: chrome.runtime.getManifest().version, template: o.ammo_vatacc_tpl || null, debug: o.ammo_vatacc_debug || null, depSource: dep ? dep.source : null, depKeys: dep ? dep.keys : null }, null, 2)], { type: 'application/json' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'AMMO_depozit_diaqnostika.json'; a.click();
    };
    $('depForget').onclick = async () => { await chrome.storage.local.remove(['ammo_vatacc_tpl', 'ammo_vatacc_debug']); toast('Unuduldu. Portalda «ƏDV depozit hesabı» səhifəsini açın — AMMO sorğunu yenidən öyrənəcək.'); };
    if ($('cusDel')) $('cusDel').onclick = async () => { cus = null; await chrome.storage.local.remove(CUS_KEY); recompute('Gömrük məlumatı silindi.'); openSources(); };
  }
  $('srcClose').onclick = () => { $('srcModal').hidden = true; };
  $('btnSrc').onclick = openSources;

  async function loadDeposit(file) {
    try {
      const sheets = await AMMO_XLSX_READ.readFileAll(file);
      let d = null, lastErr = null;
      for (const sh of sheets) { try { d = E.parseDeposit(sh.rows, inputs.ownTin); if (d.payments.length) break; } catch (e) { lastErr = e; } }
      if (!d) throw lastErr || new Error('Faylda vərəq tapılmadı.');
      if (inputs.ownTin && d.ownTin && d.ownTin !== inputs.ownTin) throw new Error(`Bu fayl başqa VÖEN-ə aiddir (${d.ownTin}), portalda isə ${inputs.ownTin} ilə daxil olunub.`);
      if (!d.payments.length) throw new Error('Faylda əməliyyat tapılmadı.');
      dep = depExcel = { ...d, at: Date.now(), source: 'excel' };
      await chrome.storage.local.set({ [DEP_KEY]: dep });
      recompute(`Depozit: ${d.payments.length} əməliyyat əlavə edildi.`);
      openSources();
    } catch (e) { toast('Depozit faylı oxunmadı: ' + e.message); }
  }
  async function loadCustomsFile(file) {
    try {
      const rows = E.customsFromRows(await AMMO_XLSX_READ.readFile(file));
      if (!rows.length) throw new Error('GB sətri tapılmadı.');
      cus = { rows, src: 'Excel: ' + file.name, at: Date.now() };
      await chrome.storage.local.set({ [CUS_KEY]: cus });
      recompute(`Gömrük: ${rows.length} GB əlavə edildi.`); openSources();
    } catch (e) { toast('Gömrük faylı oxunmadı: ' + e.message); }
  }
  async function loadCustomsLive() {
    const btn = $('cusLive'); btn.disabled = true; btn.textContent = 'Çəkilir…';
    try {
      const tabs = await chrome.tabs.query({ url: 'https://e.customs.gov.az/*' });
      if (!tabs.length) throw new Error('e.customs.gov.az açıq deyil. Saytı açın, Asan İmza ilə daxil olun və yenidən basın.');
      const F2 = ['REG_NUMBER', 'PROCESS_DATE', 'SHORTNAME', 'NAZ_EXP', 'GOODS_NAME', 'STATISTIC_COST', 'ADV'];
      const all = [];
      const y1 = +R.range.from.slice(0, 4), y2 = +R.range.to.slice(0, 4);
      for (let y = y1; y <= y2; y++) {
        const a = y === y1 ? R.range.from : `${y}-01-01`, b = y === y2 ? R.range.to : `${y}-12-31`;
        btn.textContent = `Çəkilir… ${y}`;
        let res = null, err = '';
        for (const t of tabs) {
          try { res = await chrome.tabs.sendMessage(t.id, { type: 'AMMO_GMR_FETCH', path: 'dictionaries/report?order=0&exportType=xml', method: 'POST', body: { dateFrom: a, dateTo: b, type: '' } }); if (res && res.ok) break; err = res && res.status === 401 ? 'Gömrük saytında sessiya bitib — yenidən daxil olun.' : 'cavab yoxdur'; }
          catch (e) { err = 'Gömrük səhifəsini yeniləyin (F5).'; }
        }
        if (!res || !res.ok) {
          let j = null; try { j = JSON.parse(res && res.text); } catch (e) { /* */ }
          if (j && j.exception && j.exception.code === '041') continue; // məlumat yoxdur
          throw new Error(err || 'Gömrük hesabatı alınmadı');
        }
        const t = String(res.text || '').trim();
        if (!t.startsWith('<')) continue;
        const doc = new DOMParser().parseFromString(t.replace(/^<\?xml[^>]*\?>/, ''), 'application/xml');
        [...doc.getElementsByTagName('GetImpExpReport')].forEach((el) => { const o = {}; F2.forEach((f) => { const c = el.getElementsByTagName(f)[0]; o[f] = c ? c.textContent : ''; }); all.push(o); });
      }
      const rows = E.customsFromReport(all);
      cus = { rows, src: 'e.customs.gov.az', at: Date.now() };
      await chrome.storage.local.set({ [CUS_KEY]: cus });
      recompute(`Gömrük: ${rows.length} mal sətri çəkildi.`); openSources();
    } catch (e) { toast(e.message); btn.disabled = false; btn.textContent = 'Gömrük saytından çək'; }
  }

  function recompute(msg) { compute(); renderHead(); renderAlerts(); renderChart(); renderAll(false); if (msg) toast(msg); }

  // ------------------------------------------------------------------ Excel
  $('btnPrint').onclick = () => window.print();
  $('btnXlsx').onclick = () => {
    const H = (v) => ({ v, s: 'h' });
    const N = (v) => ({ v: Math.round((Number(v) || 0) * 100) / 100, s: 'n2' });
    const sheet = (name, head, list, row, sumCols) => {
      const rows = [head.map(H), ...list.map(row)];
      if (sumCols && list.length) { const t = head.map(() => ''); t[0] = { v: 'Cəmi', s: 'b' }; sumCols.forEach((c) => { t[c] = { v: Math.round(list.reduce((s, r) => s + (Number(row(r)[c] && row(r)[c].v != null ? row(r)[c].v : row(r)[c]) || 0), 0) * 100) / 100, s: 'bn2' }; }); rows.push(t); }
      return { name, rows, headerRow: 0, maxWidth: 48 };
    };
    const T = R.totals;
    const sum = [[H('Göstərici'), H('Dəyər')],
      ['Dövr', `${dmy(R.range.from)} – ${dmy(R.range.to)}`], ['VÖEN', R.ownTin], ['ƏDV mükəlləfiyyəti', R.obligation.start ? `${E.ymLabel(R.obligation.start)} – ${R.obligation.end ? E.ymLabel(R.obligation.end) : 'davam edir'}` : ''],
      ['Alış qaimələri (ƏDV-li)', T.invoices], ['Alış ƏDV-si', N(T.vat)], ['Əvəzləşib', N(T.offVat)], ['Qalıq', N(T.remaining)], ['Əvəzləşmə faizi', T.pct + '%'],
      ['Tam / Qismən / Əvəzləşməyən / Artıq', `${T.full} / ${T.partial} / ${T.none} / ${T.over}`],
      ['Əvəzləşmə hüququ VAR, əvəzləşməyib', dep ? N(T.rightVat) : 'depozit məlumatı yoxdur'], ['Əvəzləşmə hüququ YOXDUR (depozitdən ödənilməyib)', dep ? N(T.noRightVat) : ''], ['İdxal ƏDV-si (gömrük)', N(T.customsVat)], ['İdxal — əvəzləşib (310)', N(T.customsOff)],
      [], [H('Tapıntı'), H('İzah'), H('Məbləğ')], ...R.alerts.map((a) => [a.title, a.text, a.amount == null ? '' : N(a.amount)])];
    const scope = R.invoices.filter((i) => i.inRange);
    const invHead = ['Tarix', 'Seriya', 'Nömrə', 'Təchizatçı', 'VÖEN', 'ƏDV-yə cəlb', 'ƏDV', 'Əvəzləşib', 'Qalıq', '%', 'Əvəzləşdiyi aylar', 'Depozitdən ödənib', 'Vəziyyət', 'Qeydlər', 'Qaimə statusu', 'Əsas qeyd'];
    const invRow = (i) => [dmy(i.date), i.series, i.number, i.name, i.tin, N(i.base), N(i.vat), N(i.offVat), N(i.remaining), i.pct, i.periods.map(E.ymLabel).join(', '), dep ? N(i.depPaid) : '', (STATE[i.state] || [i.state])[0], i.flags.map((f) => (FLAG[f] || [f])[0]).join(', '), INV_ST[i.status] || i.status, i.comment];
    const sheets = [
      { name: 'Xülasə', rows: sum, maxWidth: 70 },
      sheet('Aylar', ['Ay', 'Qaimə', 'Alış ƏDV', 'Onlardan əvəzləşib', 'Qalıq', 'Bəyannamə', 'Sənəd №', 'Əlavə 1 (308)', 'o cümlədən bu ayın', 'əvvəlki ayların', '310 (YGB)', 'Satış ƏDV', 'Büdcəyə ödənilməli', 'Vəziyyət'],
        R.months.filter((m) => m.oblActive), (m) => [m.label, m.count, N(m.vat), N(m.offOfThese), N(m.remaining), m.decl ? (TYPE[m.decl.type] || m.decl.type) : (m.state === 'nodecl' ? 'YOXDUR' : ''), m.decl ? m.decl.reg : '', N(m.declOffVat), N(m.declOwnVat), N(m.declPrevVat), N(m.ccdVat), m.outVat == null ? '' : N(m.outVat), m.payable == null ? '' : N(m.payable), (MST[m.state] || [''])[0]], [2, 3, 4, 7, 10]),
      sheet('Qaimələr', invHead, scope, invRow, [5, 6, 7, 8]),
      sheet('Əvəzləşməyənlər', invHead, scope.filter((i) => i.state === 'none' || i.state === 'partial'), invRow, [6, 7, 8]),
    ];
    if (dep) {
      sheets.push(sheet('Hüququ var-əvəzləşməyib', [...invHead, 'Əvəzləşdirilə bilər', 'Ödəniş tarix(lər)i', 'Bəyannamə ayı (308)'], scope.filter((i) => i.rightVat > 0.01),
        (i) => [...invRow(i), N(i.rightVat), i.payments.map((p) => `${dmy(p.date)} ${money(p.amount)}${p.est ? ' (təxmini)' : ''}`).join('; '), [...new Set(i.payments.map((p) => E.ymLabel(E.ym(p.date))))].join(', ')], [6, 7, 11, 16]));
      sheets.push(sheet('Hüququ yoxdur', [...invHead, 'Hüququ olmayan qalıq', 'Səbəb', 'Təchizatçıya bağlanmamış ödəniş'], scope.filter((i) => i.noRightVat > 0.01),
        (i) => [...invRow(i), N(i.noRightVat), WHY[i.noRightWhy] || '', i.supplierUnallocated ? N(i.supplierUnallocated) : ''], [6, 7, 11, 16]));
      sheets.push(sheet('Depozit əməliyyatları', ['Tarix', 'VÖEN', 'Ad', 'İstiqamət', 'Məbləğ', 'Təyinat', 'Qaimə(lər)'], dep.payments,
        (p) => [dmy(p.date), p.tin, p.name, { out: 'Məxaric (təchizatçıya)', in: 'Mədaxil', budget: 'Büdcə', self: 'Öz hesabları arasında' }[p.dir] || p.dir, N(p.amount), p.desc, p.serials.map((x) => x.series + x.number).join(', ')], [4]));
    }
    sheets.push(sheet('Əvəzləşmə tarixçəsi', ['Bəyannamə ayı', 'Sənəd №', 'Sətir', 'Seriya', 'Nömrə', 'VÖEN', 'Təchizatçı', 'Qaimə tarixi', 'Ödənilmiş məbləğ', 'Ödənilmiş ƏDV'],
      R.invoices.flatMap((i) => i.offsets.map((o) => ({ o, i }))).sort((a, b) => a.o.period.localeCompare(b.o.period)), ({ o, i }) => [E.ymLabel(o.period), o.reg, o.code, i.series, i.number, i.tin, i.name, dmy(i.date), N(o.paidAmount), N(o.paidVat)], [8, 9]));
    sheets.push(sheet('Təchizatçılar', ['Təchizatçı', 'VÖEN', 'Qaimə', 'ƏDV', 'Əvəzləşib', 'Qalıq', 'Depozitdən ödənib', 'Ödənib-əvəzləşməyib'], R.suppliers, (s) => [s.name, s.tin, s.count, N(s.vat), N(s.offVat), N(s.remaining), dep ? N(s.depPaid) : '', dep ? N(s.missed) : ''], [3, 4, 5]));
    if (R.gbs.length) sheets.push(sheet('Gömrük (YGB)', ['Tarix', 'YGB', 'Göndərən', 'Mal', 'Gömrük dəyəri', 'Gömrükdə ƏDV', 'Əvəzləşib (310)', 'Qalıq', 'Aylar', 'Vəziyyət'], R.gbs, (g) => [dmy(g.date), g.gb, g.name, (g.goods || []).join('; '), N(g.value), g.inCustoms ? N(g.vat) : '', N(g.offVat), N(g.remaining), g.periods.map(E.ymLabel).join(', '), (STATE[g.state] || [g.state])[0]], [4, 6, 7]));
    const orph = R.orphans.map((o) => ({ ...o, k: 'Tapılmadı' })).concat(R.earlier.map((o) => ({ ...o, k: 'Əvvəlki dövr' })));
    if (orph.length) sheets.push(sheet('Əlavə1-tapılmayan', ['Bəyannamə ayı', 'Sətir', 'VÖEN', 'Tarix', 'Seriya', 'Nömrə', 'Ödənilmiş məbləğ', 'Ödənilmiş ƏDV', 'Səbəb'], orph, (o) => [E.ymLabel(o.period), o.code, o.tin, dmy(o.date), o.series, o.number, N(o.paidAmount), N(o.paidVat), o.k], [6, 7]));
    if (dep && R.unallocated.length) sheets.push(sheet('Depozit-bağlanmayan', ['Tarix', 'Alan', 'VÖEN', 'Ödəniş', 'Bağlanmayan', 'Təyinat'], R.unallocated, (p) => [dmy(p.date), p.name, p.tin, N(p.amount), N(p.left), p.desc], [3, 4]));
    AMMO_XLSX.download(sheets, `AMMO_EDV_Evezlesme_${R.range.from}_${R.range.to}.xlsx`);
  };

  // ------------------------------------------------------------------ başla
  compute(); renderHead(); renderAlerts(); renderChart(); renderAll(false);
  if ((inputs.notes || []).length) setTimeout(() => toast(inputs.notes[0]), 600);
})();
