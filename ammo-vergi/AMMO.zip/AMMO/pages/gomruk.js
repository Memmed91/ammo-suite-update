/* AMMO — Gömrük idxal bəyannamələri (v1.17.0)
 * Mənbə: e.customs.gov.az (açıq tabdakı sessiya ilə, content/gomruk-site.js vasitəsilə)
 *  1) «İdxal etdiyim mallar haqqında hesabat» (POST dictionaries/report, order=0, xml) — mal sətirləri, rüsum, ƏDV.
 *  2) Hər GB üçün elektron GB faylı (GET egb → egb/file) — ADOC (zip) içində PDF-lər:
 *     qr. 22 (valyuta, invoys cəmi), qr. 23 (məzənnə), qr. 12 (gömrük dəyəri), 31-ci qrafa əlavəsi (mal üzrə invoys dəyəri).
 * Nəticə istifadəçinin Excel nümunəsi formasındadır: hər GB bir sətir + ödəniş kodları (01…87). */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const qs = new URLSearchParams(location.search);
  let tabId = +qs.get('tab') || 0;


  // ------------------------------------------------------------ köməkçilər
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const dmy = (d) => `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;
  const parseIso = (s) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
  const parseDmy = (s) => { const m = /(\d{2})\.(\d{2})\.(\d{4})/.exec(s || ''); return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null; };
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const num = (s) => { if (s == null || s === '') return null; const v = parseFloat(String(s).replace(/\s/g, '').replace(',', '.')); return isFinite(v) ? v : null; };
  const r2 = (v) => (v == null ? null : Math.round(v * 100) / 100);
  const fmt = (v, d = 2) => (v == null || !isFinite(v) ? '' : v.toLocaleString('az-AZ', { minimumFractionDigits: d, maximumFractionDigits: d }));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function status(msg, bad) { const s = $('status'); s.textContent = msg || ''; s.className = 'status' + (bad ? ' bad' : ''); }
  function progress(p) { $('bar').firstElementChild.style.width = (p == null ? 0 : Math.max(0, Math.min(100, p))) + '%'; }

  // ------------------------------------------------------------ gömrük tabı vasitəsilə sorğu
  async function customsTabs() {
    const list = await chrome.tabs.query({ url: 'https://e.customs.gov.az/*' });
    list.sort((a, b) => (b.id === tabId) - (a.id === tabId) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
    return list.map((t) => t.id);
  }
  async function gfetch(path, method, body) {
    const ids = await customsTabs();
    if (!ids.length) throw new Error('e.customs.gov.az səhifəsi açıq deyil. Gömrük saytını açıb daxil olun, bu pəncərəni bağlamayın.');
    let last = null;
    for (const id of ids) {
      let res;
      try { res = await chrome.tabs.sendMessage(id, { type: 'AMMO_GMR_FETCH', path, method, body }); }
      catch (e) { last = 'Gömrük səhifəsini yeniləyin (F5) — AMMO ora qoşulmayıb.'; continue; }
      if (!res) { last = 'Cavab yoxdur'; continue; }
      if (res.status === 401 || res.error === 'login') { last = 'Gömrük saytında sessiya bitib. Saytda yenidən daxil olun (və ya səhifəni yeniləyin) və «Doldur»u yenidən basın.'; continue; }
      tabId = id;
      return res;
    }
    throw new Error(last || 'Sorğu alınmadı');
  }
  async function gjson(path, method, body) {
    const res = await gfetch(path, method, body);
    let j = null; try { j = JSON.parse(res.text); } catch (e) { /* */ }
    if (!res.ok || !j || (j.code && j.code >= 400)) {
      const m = j && j.exception && j.exception.errorMessage;
      const err = new Error(m || ('HTTP ' + res.status)); err.code = j && j.exception && j.exception.code; throw err;
    }
    return j.data;
  }

  // ------------------------------------------------------------ 1) idxal hesabatı
  const FIELDS = ['REG_NUMBER', 'PROCESS_DATE', 'REJIM', 'SHORTNAME', 'OLKA', 'NAZ_IMP', 'GOODS_NAME', 'GOODS_CODE', 'QUANTITY1', 'NETTO', 'STATISTIC_COST', 'GR_YIG', 'T2025', 'AKSIZ', 'ADV', 'DGR', 'KOD_EXP', 'NAZ_EXP'];
  async function reportChunk(from, to) {
    for (let attempt = 0; attempt < 3; attempt++) {
      // Diqqət: portal tarixi YYYY-MM-DD formatında gözləyir (DD.MM.YYYY-ni ay/gün kimi səhv oxuyur)
      const res = await gfetch('dictionaries/report?order=0&exportType=xml', 'POST', { dateFrom: iso(from), dateTo: iso(to), type: '' });
      const t = (res.text || '').trim();
      if (t.startsWith('<')) {
        const doc = new DOMParser().parseFromString(t.replace(/^<\?xml[^>]*\?>/, ''), 'application/xml');
        return [...doc.getElementsByTagName('GetImpExpReport')].map((el) => {
          const o = {}; FIELDS.forEach((f) => { const c = el.getElementsByTagName(f)[0]; o[f] = c ? c.textContent : ''; }); return o;
        });
      }
      let j = null; try { j = JSON.parse(t); } catch (e) { /* */ }
      const code = j && j.exception && j.exception.code;
      if (code === '041') return []; // «Qeyd olunan tarix intervalında məlumat tapılmadı»
      if (code === '053B' && attempt < 2) { await sleep(1200); continue; } // «Təkrar cəhd edin»
      throw new Error((j && j.exception && j.exception.errorMessage) || ('Hesabat alınmadı (HTTP ' + res.status + ')'));
    }
    return [];
  }
  async function fetchReport(from, to) {
    // Bir sorğuda maksimum 1 il — aralığı təqvim illərinə bölürük
    const chunks = [];
    let a = new Date(from);
    while (a <= to) { const b = new Date(Math.min(new Date(a.getFullYear(), 11, 31).getTime(), to.getTime())); chunks.push([a, b]); a = addDays(b, 1); }
    const seen = new Set(); const rows = [];
    for (let i = 0; i < chunks.length; i++) {
      status(`Hesabat alınır… (${dmy(chunks[i][0])} – ${dmy(chunks[i][1])})`);
      const part = await reportChunk(chunks[i][0], chunks[i][1]);
      const regs = new Set(part.map((r) => r.REG_NUMBER).filter((r) => seen.has(r)));
      part.forEach((r) => { if (!regs.has(r.REG_NUMBER)) rows.push(r); });
      part.forEach((r) => seen.add(r.REG_NUMBER));
      progress(5 + 15 * (i + 1) / chunks.length);
    }
    return rows.filter((r) => { const d = parseDmy(r.PROCESS_DATE); return d && d >= from && d <= to; });
  }

  // ------------------------------------------------------------ 2) GB faylı (ADOC = zip) → PDF-lər
  async function inflateRaw(u8) {
    const ds = new DecompressionStream('deflate-raw');
    const out = new Response(new Blob([u8]).stream().pipeThrough(ds));
    return new Uint8Array(await out.arrayBuffer());
  }
  async function unzip(b) {
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    let e = -1; for (let i = b.length - 22; i >= Math.max(0, b.length - 66000); i--) if (dv.getUint32(i, true) === 0x06054b50) { e = i; break; }
    if (e < 0) throw new Error('zip deyil');
    const n = dv.getUint16(e + 10, true); let p = dv.getUint32(e + 16, true); const files = {};
    for (let k = 0; k < n; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true), csz = dv.getUint32(p + 20, true);
      const nl = dv.getUint16(p + 28, true), xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true);
      const name = new TextDecoder().decode(b.subarray(p + 46, p + 46 + nl));
      const lnl = dv.getUint16(off + 26, true), lxl = dv.getUint16(off + 28, true);
      const data = b.subarray(off + 30 + lnl + lxl, off + 30 + lnl + lxl + csz);
      files[name] = method === 8 ? await inflateRaw(data) : data.slice();
      p += 46 + nl + xl + cl;
    }
    return files;
  }

  let pdfjsP = null;
  function pdfjs() {
    if (!pdfjsP) pdfjsP = import('../lib/pdfjs/pdf.min.mjs').then((m) => { m.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdfjs/pdf.worker.min.mjs'); return m; });
    return pdfjsP;
  }
  /** PDF → sətirlər: [{p, x, y, s}] (eyni sətirdə yanaşı parçalar birləşdirilir) */
  async function pdfLines(u8) {
    const P = await pdfjs();
    const doc = await P.getDocument({ data: u8, isEvalSupported: false }).promise;
    const out = [];
    for (let p = 1; p <= doc.numPages; p++) {
      const pg = await doc.getPage(p);
      const tc = await pg.getTextContent();
      const its = tc.items.filter((i) => i.str && i.str.trim()).map((i) => ({ x: i.transform[4], y: i.transform[5], s: i.str, w: i.width || 0 }));
      its.sort((a, b) => b.y - a.y || a.x - b.x);
      const groups = [];
      for (const it of its) {
        const g = groups.find((q) => Math.abs(q.y - it.y) <= 1.5 && it.x - q.ex < 3 && it.x - q.ex > -2);
        if (g) { g.s += it.s; g.ex = it.x + it.w; } else groups.push({ p, x: it.x, y: it.y, s: it.s, ex: it.x + it.w });
      }
      groups.forEach((g) => { g.s = g.s.replace(/\s+/g, ' ').trim(); out.push(g); });
      pg.cleanup();
    }
    doc.destroy();
    return out;
  }
  const fold = (s) => String(s || '').toLowerCase().replace(/ə/g, 'e').replace(/ı/g, 'i').replace(/i̇/g, 'i').replace(/ö/g, 'o').replace(/ü/g, 'u').replace(/ş/g, 's').replace(/ç/g, 'c').replace(/ğ/g, 'g');
  const AMT = /^-?\d[\d\s]*,\d{2}$/;

  /** GB PDF-lərindən: valyuta, məzənnə, invoys cəmi (qr.22), gömrük dəyəri (qr.12), nəqliyyat nömrəsi (qr.18),
   *  ödənişlər (qr.47 «B» bölməsi: kod → məbləğ) və mal üzrə invoys dəyəri (31-ci qrafa əlavəsi) */
  function parseGb(docs) {
    const r = { curCode: '', rate: null, invoiceTotal: null, customsTotal: null, transportNo: '', pays: null, items: {} };
    for (const L of docs) {
      const p1 = L.filter((l) => l.p === 1);
      // Qrafa 22/23: 3 rəqəmli valyuta kodu, yanında invoys cəmi və 4 onluqlu məzənnə
      if (r.invoiceTotal == null) {
        for (const c of p1.filter((l) => /^\d{3}$/.test(l.s) && l.x > 285 && l.x < 340 && l.y > 480 && l.y < 580)) {
          const amt = p1.find((l) => Math.abs(l.y - c.y) <= 4 && l.x > c.x + 20 && l.x < 450 && AMT.test(l.s));
          const rate = p1.find((l) => Math.abs(l.y - c.y) <= 4 && l.x > 440 && l.x < 520 && /^\d+,\d{2,6}$/.test(l.s));
          if (amt) { r.curCode = c.s; r.invoiceTotal = num(amt.s); r.rate = rate ? num(rate.s) : null; break; }
        }
      }
      // Qrafa 12: ümumi gömrük dəyəri (AZN)
      if (r.customsTotal == null) {
        const g12 = p1.find((l) => l.x > 470 && l.x < 545 && l.y > 595 && l.y < 640 && AMT.test(l.s));
        if (g12) r.customsTotal = num(g12.s);
      }
      // Qrafa 18: nəqliyyat vasitəsinin nömrəsi
      if (!r.transportNo) {
        const t = p1.find((l) => l.x > 50 && l.x < 80 && l.y > 545 && l.y < 565 && /^[A-Z0-9][A-Z0-9\-\/ ]{2,}$/i.test(l.s));
        if (t) r.transportNo = t.s;
      }
      // Qrafa 47 «B» bölməsi: «02 - 400,00 - 932»
      if (!r.pays) {
        const pays = {};
        p1.filter((l) => /^\d{2}$/.test(l.s) && l.x > 375 && l.x < 400 && l.y < 320).forEach((c) => {
          const v = p1.find((l) => Math.abs(l.y - c.y) <= 3 && l.x > c.x + 20 && /^-?[\d\s]+,\d{2}\s*-/.test(l.s));
          if (v) pays[c.s] = (pays[c.s] || 0) + num(/^-?[\d\s]+,\d{2}/.exec(v.s)[0]);
        });
        if (Object.keys(pays).length) r.pays = pays;
      }
      // 31-ci qrafa əlavəsi: «N- mala aiddir» … «İnvoys dəyəri X»
      const marks = L.filter((l) => /^(\d+)\s*-\s*mala aiddir/i.test(l.s)).map((l) => ({ ...l, n: +/^(\d+)/.exec(l.s)[1] }));
      if (marks.length) {
        L.filter((l) => /nvoys\s*deyeri/.test(fold(l.s))).forEach((lab) => {
          const val = L.find((v) => v.p === lab.p && Math.abs(v.y - lab.y) <= 4 && v.x > lab.x + 40 && AMT.test(v.s));
          if (!val) return;
          const m = marks.filter((k) => k.p < lab.p || (k.p === lab.p && k.y > lab.y)).sort((a, b) => b.p - a.p || a.y - b.y)[0];
          if (!m) return;
          r.items[m.n] = (r.items[m.n] || 0) + num(val.s);
        });
      }
    }
    if (r.rate == null && r.curCode === '944') r.rate = 1;
    return r;
  }

  const gbCache = new Map();
  async function gbInfo(reg, voen) {
    if (gbCache.has(reg)) return gbCache.get(reg);
    const meta = await gjson(`egb?regNumber=${encodeURIComponent(reg)}&voen=${encodeURIComponent(voen)}`);
    const f = await gjson(`egb/file/${meta.id}/${meta.importVoen || voen}`);
    if (!f || !f.file) throw new Error('GB faylı boşdur');
    const bin = Uint8Array.from(atob(f.file), (c) => c.charCodeAt(0));
    let pdfs = [];
    if (bin[0] === 0x25 && bin[1] === 0x50) pdfs = [bin]; // birbaşa PDF
    else { const files = await unzip(bin); pdfs = Object.keys(files).filter((n) => /\.pdf$/i.test(n)).sort().map((n) => files[n]); }
    const docs = [];
    for (const u8 of pdfs) { try { docs.push(await pdfLines(u8)); } catch (e) { /* zədəli PDF */ } }
    const info = parseGb(docs);
    info.settlement = meta.shippingSettlementCode;
    gbCache.set(reg, info);
    return info;
  }

  // ------------------------------------------------------------ format (istifadəçinin nümunəsi üzrə)
  const CUR_AZ = { '840': 'ABŞ dolları', '978': 'Avro', '643': 'Rusiya rublu', '949': 'Türkiyə lirəsi', '156': 'Çin yuanı', '944': 'Azərbaycan manatı', '826': 'İngilis funt sterlinqi', '981': 'Gürcüstan larisi', '398': 'Qazaxıstan tengesi', '784': 'BƏƏ dirhəmi', '756': 'İsveçrə frankı', '392': 'Yapon yeni', '410': 'Cənubi Koreya vonu', '356': 'Hindistan rupisi', '933': 'Belarus rublu', '980': 'Ukrayna qrivnası', '860': 'Özbəkistan somu', '364': 'İran rialı', '682': 'Səudiyyə rialı', '036': 'Avstraliya dolları', '124': 'Kanada dolları', '208': 'Danimarka kronu', '752': 'İsveç kronu', '578': 'Norveç kronu', '985': 'Polşa zlotısı' };
  const SETTLE = { 100: 'malın dəyəri əvvəlcədən ödənilmişdir' };
  const PAY_GROUPS = [
    ['1. Gömrük yığımları', [
      ['01', 'Malların gömrük rəsmiləşdirilməsinə görə gömrük yığımları'],
      ['02', 'Mallara gömrük nəzarəti gömrük orqanlarının iş vaxtından kənar saatlarda və iş yerindən kənarda həyata keçirildikdə malların gömrük rəsmiləşdirilməsinə görə ikiqat məbləğdə gömrük yığımları'],
      ['03', 'Malların gömrük rəsmiləşdirilməsinə görə əlavə gömrük yığımları'],
      ['04', 'Mallara gömrük nəzarəti gömrük orqanlarının iş vaxtından kənar saatlarda və iş yerindən kənarda həyata keçirildikdə malların gömrük rəsmiləşdirilməsinə görə ikiqat məbləğdə əlavə gömrük yığımları'],
      ['05', 'Azərbaycan Respublikasının gömrük ərazisinə gətirilən (o cümlədən müvəqqəti gətirilən) nəqliyyat vasitələrinin qeydə alınması üçün vəsiqə verilməsinə görə gömrük yığımları'],
      ['06', 'Mallara gömrük nəzarəti gömrük orqanlarının iş vaxtından kənar saatlarda və iş yerindən kənarda həyata keçirildikdə Azərbaycan Respublikasının gömrük ərazisinə gətirilən (o cümlədən müvəqqəti gətirilən) nəqliyyat vasitələrinin qeydə alınması üçün vəsiqə verilməsinə görə ikiqat məbləğdə gömrük yığımları'],
      ['07', 'Malların gömrük nəzarəti altında məhvinə görə gömrük yığımları'],
      ['08', 'Mallara gömrük nəzarəti gömrük orqanlarının iş vaxtından kənar saatlarda və iş yerindən kənarda həyata keçirildikdə malların gömrük nəzarəti altında məhvinə görə ikiqat məbləğdə gömrük yığımları'],
      ['09', 'Hasilatın pay bölgüsü haqqında sazişlərin icrası ilə bağlı Azərbaycan Respublikasının gömrük ərazisinə gətirilən və bu ərazidən aparılan malların, o cümlədən mənfəət karbohidrogenlərinin gömrük rəsmiləşdirilməsinə görə bu sazişlərin müvafıq müddəaları ilə müəyyən edilmiş miqdarda gömrük yığımları'],
      ['70', 'Malların saxlancına görə gömrük yığımları'],
      ['17', '1) Azəri, Çıraq yataqlarında və Günəşli yatağının dərin sulu hissəsindən hasil edilən XAM NRFTİN, 2) Xəzər Dənizinin Azərbaycan sektorunda Şah Dəniz perspektiv sahəsindən hasil edilən TƏBİİ QAZIN VƏ QAZ KONDENSATI-XAM NEFTİN rəsmiləşdirilməsinə görə gömrük yığımı'],
      ['18', 'Fiziki olaraq gömrük müşayiətinin aparılmasına görə gömrük yığımları'],
      ['19', 'GPS xidməti vasitəsilə gömrük müşayiətinin aparılmasına görə gömrük yığımları'],
    ]],
    ['2. Gömrük rüsumları', [
      ['20', 'İdxal gömrük rüsumu'], ['21', 'xüsusi rüsumlar'], ['23', 'antidempinq rüsumları'], ['24', 'kompensasiya rüsumları'], ['25', 'İxrac gömrük rüsumları'], ['26', 'mövsümü rüsumları'],
    ]],
    ['3. Gömrük orqanları tərəfindən alınan vergilər', [['30', 'Aksiz'], ['32', 'Əlavə dəyər vergisi']]],
    ['4. Digər gömrük ödənişləri', [
      ['91', 'Gömrük ödənişlərinə möhlət verilməsinə görə faizlər'], ['95', 'Dəbbə pulu'], ['75', 'Elektron gömrük xidməti haqqı'], ['76', 'Gömrük təmsilçiliyi xidməti haqqı'],
      ['77', 'Tərəzi haqqı'], ['85', 'Elektron gömrük xidməti üzrə ƏDV'], ['86', 'Gömrük təmsilçiliyi xidməti üzrə ƏDV'], ['87', 'Tərəzi xidməti üzrə ƏDV'],
    ]],
  ];
  const PAY_CODES = PAY_GROUPS.flatMap(([, list]) => list.map(([c]) => c));
  const PAY_DESC = Object.fromEntries(PAY_GROUPS.flatMap(([, list]) => list));
  // Sabit sütunlar: [başlıq, açar, onluq (rəqəmdirsə), cəmlənsin]
  const FIX = [
    ['№', 'i'], ['Əməliyyat tarixi', 'date'], ['GB nömrəsi', 'reg'], ['Göndərənin adı', 'sender'], ['Malın adı', 'name'], ['Malın kodu', 'code'],
    ['Miqdarı', 'qty', 3, 1], ['Ölçü vahidi', 'unit'], ['İnvoys dəyəri', 'inv', 2, 1], ['Valyuta', 'cur'], ['Valyuta məzənnəsi', 'rate', 4],
    ['Ödəniş kodu', 'settle'], ['Nəqliyyat nömrəsi', 'transportNo'], ['Gömrük dəyəri', 'customs', 2, 1], ['Statistik dəyəri', 'stat', 2, 1], ['Daşıma xərci', 'transport', 2, 1],
  ];

  const uniq = (a) => [...new Set(a.filter((x) => x !== '' && x != null))];
  const cleanName = (s) => String(s || '').split(/\s*\n+\s*/).map((x) => x.trim()).filter(Boolean).join(' ');
  function splitQty(q) {
    const m = /^\s*([\d.,]+)\s*(.*)$/.exec(q || '');
    return m ? { qty: num(m[1]), unit: (m[2] || '').trim() } : { qty: null, unit: (q || '').trim() };
  }

  /** Hər GB = bir sətir (nümunədəki kimi) */
  function buildRows(groups) {
    return groups.map((g) => {
      const info = g.info || {};
      const items = g.items;
      const qs = items.map((it) => splitQty(it.QUANTITY1));
      const units = uniq(qs.map((q) => q.unit));
      const stat = items.reduce((s, it) => s + (num(it.STATISTIC_COST) || 0), 0);
      // ödənişlər: GB-nin 47-ci qrafasının «B» bölməsi; GB oxunmadısa — hesabatdakı cəmlərdən
      let pays = info.pays, estimated = false;
      if (!pays) {
        estimated = true;
        const sum = (f) => items.reduce((s, it) => s + (num(it[f]) || 0), 0);
        const dgr = sum('DGR'), e75 = r2(dgr / 1.18);
        pays = { '02': sum('GR_YIG'), '20': sum('T2025'), '30': sum('AKSIZ'), '32': sum('ADV'), '75': e75, '85': r2(dgr - e75) };
      }
      let transport = null;
      if (info.customsTotal != null && info.invoiceTotal != null && info.rate != null) {
        transport = r2(info.customsTotal - info.invoiceTotal * info.rate);
        if (Math.abs(transport) < 0.01) transport = 0;
      }
      const row = {
        date: items[0].PROCESS_DATE, reg: g.reg, sender: uniq(items.map((it) => it.NAZ_IMP)).join(' / '),
        name: items.map((it) => cleanName(it.GOODS_NAME)).join('/'), code: uniq(items.map((it) => it.GOODS_CODE)).join('/'),
        qty: units.length <= 1 ? qs.reduce((s, q) => s + (q.qty || 0), 0) : null, unit: units.join('/'),
        inv: info.invoiceTotal, cur: info.curCode ? `${info.curCode} | ${CUR_AZ[info.curCode] || info.curCode} (1)` : '', rate: info.rate,
        settle: info.settlement != null ? (SETTLE[info.settlement] ? `${info.settlement} - ${SETTLE[info.settlement]}` : String(info.settlement)) : '',
        transportNo: info.transportNo || '', customs: info.customsTotal, stat: r2(stat), transport,
        warn: g.error ? g.error + (estimated ? ' — ödənişlər hesabatdan götürüldü' : '') : '',
      };
      if (row.qty == null) row.qtyText = qs.map((q) => q.qty).join('/');
      PAY_CODES.forEach((c) => (row['p' + c] = r2(pays[c] || 0)));
      return row;
    });
  }

  // ------------------------------------------------------------ cədvəl (ekranda — yalnız məbləği olan ödəniş kodları)
  let ROWS = [];
  function view() {
    const q = fold($('search').value.trim());
    return q ? ROWS.filter((r) => fold([r.reg, r.sender, r.name, r.code, r.transportNo].join(' ')).includes(q)) : ROWS;
  }
  const allCols = () => FIX.concat(PAY_CODES.map((c) => [c, 'p' + c, 2, 1]));
  function sums(rows, cols) { const s = {}; cols.forEach(([, k, , sum]) => { if (sum) s[k] = r2(rows.reduce((a, r) => a + (r[k] || 0), 0)); }); return s; }
  function render() {
    const usedCodes = PAY_CODES.filter((c) => ROWS.some((r) => r['p' + c]));
    const cols = FIX.concat(usedCodes.map((c) => [c, 'p' + c, 2, 1]));
    const rows = view();
    $('thead').innerHTML = '<tr>' + cols.map(([h, k, d]) => `<th class="${d != null ? 'n' : ''}" title="${esc(PAY_DESC[h] || '')}">${esc(PAY_DESC[h] ? h + ' · ' + shortDesc(h) : h)}</th>`).join('') + '</tr>';
    if (!ROWS.length) { $('tbody').innerHTML = `<tr><td class="empty" colspan="${cols.length}">Tarix aralığını seçib «Doldur» düyməsini basın.</td></tr>`; $('tfoot').innerHTML = ''; $('rowinfo').textContent = ''; $('cards').innerHTML = ''; return; }
    $('tbody').innerHTML = rows.map((r, i) => `<tr class="${r.warn ? 'warn' : ''}" title="${esc(r.warn)}">` + cols.map(([, k, d]) => {
      const v = k === 'i' ? i + 1 : r[k];
      if (k === 'qty' && v == null) return `<td class="n">${esc(r.qtyText || '')}</td>`;
      if (d != null && k !== 'i') return `<td class="n">${typeof v === 'number' ? fmt(v, d === 4 ? 4 : d === 3 ? 0 : 2) : ''}</td>`;
      return `<td class="${k === 'name' ? 'name' : ''}">${esc(v)}</td>`;
    }).join('') + '</tr>').join('');
    const s = sums(rows, cols);
    $('tfoot').innerHTML = '<tr>' + cols.map(([, k, d, sum], i) => (i === 0 ? '<td>Cəmi</td>' : sum && k !== 'qty' ? `<td class="n">${fmt(s[k], 2)}</td>` : '<td></td>')).join('') + '</tr>';
    $('rowinfo').textContent = `${rows.length} bəyannamə`;
    const t = sums(ROWS, allCols());
    const card = (l, v) => `<div class="card"><span>${l}</span><b>${v}</b></div>`;
    $('cards').innerHTML = card('Bəyannamə', ROWS.length) + card('Gömrük dəyəri (AZN)', fmt(t.customs)) + card('Daşıma xərci (AZN)', fmt(t.transport))
      + card('Gömrük yığımları', fmt(PAY_GROUPS[0][1].reduce((a, [c]) => a + (t['p' + c] || 0), 0))) + card('Gömrük rüsumları', fmt(PAY_GROUPS[1][1].reduce((a, [c]) => a + (t['p' + c] || 0), 0)))
      + card('ƏDV (32)', fmt(t.p32));
  }
  function shortDesc(c) {
    const m = { '01': 'Yığım', '02': 'Yığım (ikiqat)', '03': 'Əlavə yığım', '20': 'İdxal rüsumu', '30': 'Aksiz', '32': 'ƏDV', '75': 'E-xidmət haqqı', '76': 'Təmsilçilik', '77': 'Tərəzi', '85': 'E-xidmət ƏDV', '86': 'Təmsilçilik ƏDV', '87': 'Tərəzi ƏDV', '70': 'Saxlanc', '91': 'Faiz', '95': 'Dəbbə' };
    return m[c] || PAY_DESC[c].slice(0, 22) + '…';
  }

  // ------------------------------------------------------------ Excel (nümunədəki forma: 3 başlıq sətri)
  function exportXlsx() {
    const rows = view(); if (!rows.length) return;
    const nF = FIX.length;
    const H = (v) => ({ v, s: 'h' });
    const r1 = FIX.map(([h]) => H(h)), r2_ = FIX.map(() => H('')), r3 = FIX.map(() => H(''));
    const merges = FIX.map((_, i) => `${AMMO_XLSX.colName(i)}1:${AMMO_XLSX.colName(i)}3`);
    let col = nF;
    PAY_GROUPS.forEach(([title, list]) => {
      merges.push(`${AMMO_XLSX.colName(col)}1:${AMMO_XLSX.colName(col + list.length - 1)}1`);
      list.forEach(([c, d], k) => { r1.push(H(k === 0 ? title : '')); r2_.push(H(d)); r3.push(H(' ' + c)); });
      col += list.length;
    });
    const cols = allCols();
    const body = rows.map((r, i) => cols.map(([, k, d]) => {
      if (k === 'i') return i + 1;
      const v = r[k];
      if (k === 'qty' && v == null) return r.qtyText || '';
      if (k === 'reg') return ' ' + v;
      if (d != null && typeof v === 'number') return { v, s: d === 4 ? 'n4' : d === 3 ? 'n0' : 'n2' };
      return v == null ? '' : v;
    }));
    const s = sums(rows, cols);
    const tot = cols.map(([, k, , sum], i) => (i === 0 ? { v: 'Cəmi', s: 'b' } : sum && k !== 'qty' ? { v: s[k], s: 'bn2' } : ''));
    const f = $('from').value.split('-').reverse().join('.'), t = $('to').value.split('-').reverse().join('.');
    const FW = [5, 12, 17, 30, 60, 14, 11, 9, 13, 22, 10, 30, 14, 14, 14, 12];
    const widths = {}; FW.forEach((w, i) => (widths[i] = w)); PAY_CODES.forEach((_, k) => (widths[nF + k] = 18));
    AMMO_XLSX.download([{ name: 'Gömrük bəyannamələri', rows: [r1, r2_, r3, ...body, tot], headerRow: 2, merges, widths, rowHeights: { 0: 30, 1: 190 }, filterLastRow: body.length + 3 }],
      `gomruk_beyannameleri_${f}-${t}.xlsx`);
  }

  // ------------------------------------------------------------ İlkin audit-ə göndər
  // Hər mal sətri ayrıca (mal qalığı üçün miqdar + ölçü vahidi + kod lazımdır); dəyər — GB-nin gömrük dəyəri
  // mal sətirlərinə statistik dəyər payına görə bölünür (GB oxunmayıbsa — statistik dəyər).
  let GROUPS = [], RANGE = null;
  function auditRows(groups) {
    const out = [];
    groups.forEach((g) => {
      const info = g.info || {};
      const stats = g.items.map((it) => num(it.STATISTIC_COST) || 0);
      const statSum = stats.reduce((a, b) => a + b, 0);
      const pays = info.pays || null;
      g.items.forEach((it, k) => {
        const share = statSum ? stats[k] / statSum : 1 / g.items.length;
        const q = splitQty(it.QUANTITY1);
        const d = parseDmy(it.PROCESS_DATE);
        const value = info.customsTotal != null ? r2(info.customsTotal * share) : r2(stats[k]);
        const vat = pays && pays['32'] != null ? r2(pays['32'] * share) : r2(num(it.ADV) || 0);
        const svc = pays ? r2(['85', '86', '87'].reduce((s, c) => s + (pays[c] || 0), 0) * share) : r2((num(it.DGR) || 0) - (num(it.DGR) || 0) / 1.18);
        out.push({ gb: String(g.reg || '').replace(/\D/g, ''), date: d ? iso(d) : '', name: cleanName(it.NAZ_EXP || it.SHORTNAME || it.NAZ_IMP || ''), sender: cleanName(it.NAZ_IMP || ''),
          goods: cleanName(it.GOODS_NAME), code: String(it.GOODS_CODE || '').trim(), qty: q.qty || 0, unit: q.unit, value, vat, svcVat: svc || 0 });
      });
    });
    return out.filter((r) => r.gb.length >= 10);
  }
  async function sendToAudit() {
    if (!GROUPS.length) return status('Əvvəlcə tarix aralığını seçib «Doldur» düyməsini basın.', true);
    const btn = $('toAudit');
    btn.disabled = true;
    try {
      const rows = auditRows(GROUPS);
      const tins = uniq(GROUPS.map((g) => String(g.voen || '').replace(/\D/g, '')).filter((v) => v.length >= 9));
      const tin = tins.length === 1 ? tins[0] : '';
      const data = { at: Date.now(), tin, rows, range: RANGE, src: 'AMMO Gömrük' + (RANGE ? ` · ${RANGE.from.split('-').reverse().join('.')} – ${RANGE.to.split('-').reverse().join('.')}` : '') };
      const set = { ammo_customs_last: data };
      if (tin) set['ammo_customs_' + tin] = data;
      await chrome.storage.local.set(set);
      btn.textContent = `✓ ${rows.length} sətir İlkin audit-ə göndərildi`;
      btn.classList.add('sent');
      status(`${rows.length} mal sətri (${GROUPS.length} GB) İlkin audit-ə göndərildi. Açıq audit səhifəsi özü yenilənəcək; bağlıdırsa, e-taxes-də İlkin audit-i yenidən açın.`);
      setTimeout(() => { btn.textContent = '📦 İlkin audit-ə göndər'; btn.classList.remove('sent'); btn.disabled = false; }, 6000);
    } catch (e) { status('Göndərilmədi: ' + (e && e.message || e), true); btn.disabled = false; }
  }

  // ------------------------------------------------------------ Doldur
  let busy = false;
  async function fill() {
    if (busy) return;
    const from = parseIso($('from').value), to = parseIso($('to').value);
    if (!from || !to) return status('Başlanğıc və son tarixi seçin.', true);
    if (from > to) return status('Başlanğıc tarix son tarixdən böyük ola bilməz.', true);
    busy = true; $('fill').disabled = true; $('xlsx').disabled = true; $('toAudit').disabled = true; progress(3);
    try {
      const items = await fetchReport(from, to);
      const groups = []; const idx = new Map();
      items.forEach((it) => { let g = idx.get(it.REG_NUMBER); if (!g) { g = { reg: it.REG_NUMBER, voen: it.KOD_EXP, items: [] }; idx.set(it.REG_NUMBER, g); groups.push(g); } g.items.push(it); });
      groups.sort((a, b) => (parseDmy(a.items[0].PROCESS_DATE) - parseDmy(b.items[0].PROCESS_DATE)) || a.reg.localeCompare(b.reg));
      if (!groups.length) { ROWS = []; render(); status('Seçilmiş dövrdə idxal bəyannaməsi tapılmadı.'); progress(0); return; }
      let done = 0, errs = 0;
      const queue = groups.slice();
      const worker = async () => {
        while (queue.length) {
          const g = queue.shift();
          try { g.info = await gbInfo(g.reg, g.voen); } catch (e) { g.info = null; g.error = 'GB faylı oxunmadı: ' + (e && e.message || e); errs++; }
          done++; progress(20 + 78 * done / groups.length);
          status(`Bəyannamələr oxunur… ${done} / ${groups.length}`);
        }
      };
      await Promise.all([worker(), worker(), worker()]);
      ROWS = buildRows(groups);
      GROUPS = groups; RANGE = { from: iso(from), to: iso(to) };
      render();
      $('xlsx').disabled = !ROWS.length;
      $('toAudit').disabled = !ROWS.length;
      status(`${groups.length} bəyannamə, ${items.length} mal sətri.` + (errs ? ` ${errs} GB faylı oxunmadı (sarı sətirlər — ödənişlər hesabatdan götürüldü).` : ''), !!errs);
      progress(100); setTimeout(() => progress(0), 900);
    } catch (e) {
      status(String(e && e.message || e), true); progress(0);
    } finally { busy = false; $('fill').disabled = false; }
  }

  // ------------------------------------------------------------ başlanğıc
  function setYear(y) {
    const today = new Date();
    if (!y) return;
    $('from').value = `${y}-01-01`;
    $('to').value = +y === today.getFullYear() ? iso(today) : `${y}-12-31`;
  }
  function init() {
    const now = new Date().getFullYear();
    const sel = $('year');
    sel.innerHTML = '<option value="">— seçilmiş aralıq —</option>' + Array.from({ length: now - 2015 + 1 }, (_, i) => now - i).map((y) => `<option value="${y}">${y}</option>`).join('');
    sel.value = String(now); setYear(now);
    sel.onchange = () => setYear(sel.value);
    const unsel = () => { const f = $('from').value, t = $('to').value; if (!(sel.value && f === `${sel.value}-01-01` && (t === `${sel.value}-12-31` || t === iso(new Date())))) sel.value = ''; };
    $('from').onchange = unsel; $('to').onchange = unsel;
    $('fill').onclick = fill;
    $('xlsx').onclick = exportXlsx;
    $('toAudit').onclick = sendToAudit;
    // İlkin audit səhifəsindən «AMMO Gömrük» ilə açılıbsa — göstəriş
    if (/[?&#]audit/.test(location.search + location.hash)) status('Tarix aralığını seçib «Doldur»u basın, sonra «📦 İlkin audit-ə göndər».');
    $('search').oninput = render;
    render();
  }
  init();
  // e2e testləri üçün (heç bir portal sorğusu etmir)
  window.__AMMO_GMR_TEST = { auditRows, load(groups) { GROUPS = groups; RANGE = { from: $('from').value, to: $('to').value }; $('toAudit').disabled = !groups.length; } };
})();
