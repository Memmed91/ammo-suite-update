(async function () {
  'use strict';
  const key = new URLSearchParams(location.search).get('key');
  const $ = (id) => document.getElementById(id);
  const data = key ? (await chrome.storage.local.get(key))[key] : null;
  if (!data) { $('sub').textContent = 'Nəticə tapılmadı (vaxtı keçib və ya silinib).'; return; }

  const money = (v) => (Number(v) || 0).toLocaleString('az-AZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const el = (t, a, ...k) => { const e = document.createElement(t); Object.entries(a || {}).forEach(([n, v]) => n === 'class' ? e.className = v : n === 'html' ? e.innerHTML = v : e.setAttribute(n, v)); k.flat().forEach((c) => c != null && c !== false && e.appendChild(c instanceof Node ? c : document.createTextNode(String(c)))); return e; };
  const fold = (s) => String(s || '').replace(/̇/g, '').toLocaleLowerCase('az');

  $('sub').textContent = `${data.stats.totalIn} daxil olan qaimə · ${data.stats.totalRep} əvəzləşən sətir`;

  // stat cards
  const S = data.stats;
  [['Daxil olanlar', S.totalIn, '', 'info'], ['Əvəzləşənlər', S.totalRep, '', 'info'],
   ['Tam əvəzləşən', S.full, 'qaimə', 'full'], ['Qismən əvəzləşən', S.partial, 'qaimə', 'partial'],
   ['Əvəzləşməyən', S.unmatched, 'qaimə', 'unmatched'], ['Uyğun olmayan', S.invalid, 'əvəzləşən', 'invalid']]
    .forEach(([t, v, s, c]) => $('cards').appendChild(el('div', { class: 'card ' + c }, el('span', null, t), el('b', null, String(v)), s && el('small', null, s))));
  const tot = Math.max(S.totalIn, 1);
  [['f', S.full], ['p', S.partial], ['u', S.unmatched]].forEach(([c, v]) => { if (v) $('chart').appendChild(el('i', { class: c, style: `flex:${v / tot}`, title: v })); });

  // ---- tab definitions: columns + row mapper over a dataset
  const n = (v) => ({ n: true, v });
  const diffCell = (v) => ({ n: true, v, cls: Math.abs(v) < 0.005 ? '' : v > 0 ? 'pos' : 'neg' });
  const statusBadge = (st) => ({ html: `<span class="badge ${st}">${st === 'full' ? 'Tam' : st === 'partial' ? 'Qismən' : 'Əvəzləşməyən'}</span>` });
  const incCols = ['№', 'VÖEN', 'Adı', 'Tarix', 'Ser', 'Nömrə', 'ƏDV-yə cəlb', 'ƏDV Məbl.', 'Yekun'];
  const incRow = (r, i) => [i + 1, r.voen, r.name, r.date, r.series, r.number, n(r.vatBase), n(r.vatAmount), n(r.total)];
  const incTot = (list) => ['', '', '', '', '', 'Cəmi', n(sum(list, 'vatBase')), n(sum(list, 'vatAmount')), n(sum(list, 'total'))];
  const repCols = ['№', 'İl', 'Ay', 'VÖEN', 'Adı', 'Seriya', 'Nömrə', 'Ümumi', 'ƏDV', 'Öd.Ümumi', 'Öd.ƏDV', 'Dövr'];
  const repRow = (r, i) => [i + 1, r.year, r.month, r.voen, r.name, r.series, r.number, n(r.total), n(r.vat), n(r.paidTotal), n(r.paidVat), r.periodCount > 1 ? `${r.periodCount}×` : ''];
  const repTot = (list) => ['', '', '', '', '', '', 'Cəmi', n(sum(list, 'total')), n(sum(list, 'vat')), n(sum(list, 'paidTotal')), n(sum(list, 'paidVat')), ''];
  const cmpCols = ['№', 'VÖEN', 'Adı', 'Tarix', 'Ser', 'Nömrə', 'ƏDV-yə cəlb', 'ƏDV Məbl.', 'Öd.Ümumi', 'Öd.ƏDV', 'Fərq baza', 'Fərq ƏDV', 'Status'];
  const cmpRow = (r, i) => [i + 1, r.voen, r.name, r.date, r.series, r.number, n(r.vatBase), n(r.vatAmount), n(r.match ? r.match.paidTotal : 0), n(r.match ? r.match.paidVat : 0), diffCell(r.diffBase), diffCell(r.diffVat), statusBadge(r.status)];
  const matchedCols = ['№', 'VÖEN', 'Adı', 'Seriya', 'Nömrə', 'Öd.Ümumi', 'Öd.ƏDV', 'Dövrlər'];
  const matchedRow = (r, i) => { const m = r.match || {}; return [i + 1, r.voen, r.name, r.series, r.number, n(m.paidTotal), n(m.paidVat), (m.periods || []).join(', ')]; };
  const diffCols = ['№', 'VÖEN', 'Adı', 'Tarix', 'Ser', 'Nömrə', 'ƏDV-yə cəlb', 'ƏDV', 'Öd.Ümumi', 'Öd.ƏDV', 'Fərq baza', 'Fərq ƏDV'];
  const diffRow = (r, i) => [i + 1, r.voen, r.name, r.date, r.series, r.number, n(r.vatBase), n(r.vatAmount), n(r.match.paidTotal), n(r.match.paidVat), diffCell(r.diffBase), diffCell(r.diffVat)];
  const invCols = ['№', 'VÖEN', 'Adı', 'Seriya', 'Nömrə', 'Ümumi', 'ƏDV', 'Öd.Ümumi', 'Öd.ƏDV', 'Dövrlər'];
  const invRow = (r, i) => [i + 1, r.voen, r.name, r.normSeries, r.normNumber, n(r.total), n(r.vat), n(r.paidTotal), n(r.paidVat), (r.periods || []).join(', ')];

  function sum(list, k) { return Math.round(list.reduce((s, r) => s + (Number(r[k]) || 0), 0) * 100) / 100; }

  const TABS = [
    { t: 'Daxil olanlar', data: () => data.incoming, cols: incCols, row: incRow, tot: incTot },
    { t: 'Əvəzləşənlər', data: () => data.replacement, cols: repCols, row: repRow, tot: repTot },
    { t: 'Müqayisə', data: () => data.incoming, cols: cmpCols, row: cmpRow },
    { t: 'Tam əvəzləşənlər', data: () => data.fullMatched, cols: matchedCols, row: matchedRow },
    { t: 'Əvəzləşməyənlər', data: () => data.unmatchedOnly, cols: incCols, row: incRow, tot: incTot },
    { t: 'Fərq', data: () => data.differenceOnly, cols: diffCols, row: diffRow },
    { t: 'Uyğun olmayan', data: () => data.invalid, cols: invCols, row: invRow },
  ];
  let cur = 0, query = '';

  const search = (list) => { if (!query) return list; const q = fold(query); return list.filter((r) => fold([r.voen, r.name, r.series, r.number, r.normSeries, r.normNumber].filter(Boolean).join(' ')).includes(q)); };

  function renderTabs() {
    const nav = $('tabs'); nav.innerHTML = '';
    TABS.forEach((tb, i) => { const b = el('button', { class: i === cur ? 'active' : '' }, `${tb.t} (${tb.data().length})`); b.onclick = () => { cur = i; renderTabs(); render(); }; nav.appendChild(b); });
  }
  function render() {
    const tb = TABS[cur];
    const list = search(tb.data());
    $('rowinfo').textContent = `${list.length} sətir`;
    const th = $('thead'); th.innerHTML = '';
    const htr = th.insertRow(); tb.cols.forEach((c) => htr.appendChild(el('th', null, c)));
    const body = $('tbody'); body.innerHTML = '';
    if (!list.length) { const tr = body.insertRow(); const td = tr.insertCell(); td.colSpan = tb.cols.length; td.className = 'empty'; td.textContent = 'Bu bölmədə məlumat yoxdur.'; return; }
    list.forEach((r, i) => {
      const tr = body.insertRow();
      tb.row(r, i).forEach((c) => {
        const td = tr.insertCell();
        if (c && typeof c === 'object' && c.html !== undefined) td.innerHTML = c.html;
        else if (c && typeof c === 'object' && c.n) { td.className = 'n' + (c.cls ? ' ' + c.cls : ''); td.textContent = money(c.v); }
        else td.textContent = c == null ? '' : c;
      });
    });
    if (tb.tot) { const tr = body.insertRow(); tr.className = 'total'; tb.tot(list).forEach((c) => { const td = tr.insertCell(); if (c && c.n) { td.className = 'n'; td.textContent = money(c.v); } else td.textContent = c == null ? '' : c; }); }
  }
  $('search').oninput = (e) => { query = e.target.value; render(); };
  $('print').onclick = () => window.print();

  $('xlsx').onclick = () => {
    const H = (v) => ({ v, s: 'h' });
    const toSheet = (name, cols, list, rowFn, totFn) => {
      const rows = [cols.map(H)];
      list.forEach((r, i) => rows.push(rowFn(r, i).map((c) => {
        if (c && typeof c === 'object' && c.html !== undefined) { const m = /">([^<]*)</.exec(c.html); return m ? m[1] : ''; }
        if (c && typeof c === 'object' && c.n) return { v: Math.round(c.v * 100) / 100, s: 'n2' };
        return c == null ? '' : c;
      })));
      if (totFn) rows.push(totFn(list).map((c) => (c && c.n ? { v: c.v, s: 'bn2' } : { v: c || '', s: 'b' })));
      return { name, rows, maxWidth: 40 };
    };
    AMMO_XLSX.download(TABS.map((t) => toSheet(t.t.slice(0, 31), t.cols, t.data(), t.row, t.tot)), `EDV_Analizi_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  renderTabs(); render();
})();
