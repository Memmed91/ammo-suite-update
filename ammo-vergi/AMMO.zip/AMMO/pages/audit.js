(async function () {
  'use strict';
  const key = new URLSearchParams(location.search).get('key');
  const $ = (id) => document.getElementById(id);
  const data = key ? (await chrome.storage.local.get(key))[key] : null;
  if (!data) { $('title').textContent = 'Nəticə tapılmadı (vaxtı keçib və ya silinib).'; return; }

  const MONTHS = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
  const MON3 = ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'İyn', 'İyl', 'Avq', 'Sen', 'Okt', 'Noy', 'Dek'];
  const n0 = (v) => { const x = Number(v); return isFinite(x) ? x : 0; };
  const money = (v) => {
    const x = Math.round(n0(v) * 100) / 100;
    const [i, f] = Math.abs(x).toFixed(2).split('.');
    return (x < 0 ? '−' : '') + i.replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ',' + f;
  };
  const short = (v) => { const a = Math.abs(v); return a >= 1e6 ? (v / 1e6).toFixed(1).replace('.', ',') + ' mln' : a >= 1e3 ? Math.round(v / 1e3) + ' min' : String(Math.round(v)); };
  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => { if (k === 'class') e.className = v; else if (k === 'style') e.style.cssText = v; else e.setAttribute(k, v); });
    kids.flat().forEach((c) => { if (c !== null && c !== undefined && c !== false) e.appendChild(c instanceof Node ? c : document.createTextNode(String(c))); });
    return e;
  };
  const fmtD = (iso) => { const [y, m, d] = String(iso).slice(0, 10).split('-'); return `${d}.${m}.${y}`; };

  const P = data.period;
  const periodText = P.fullYear ? `${P.fromISO.slice(0, 4)}-ci il` : `${fmtD(P.fromISO)} – ${fmtD(P.toISO)}`;
  document.title = `AMMO — İlkin audit ${periodText}`;
  $('title').textContent = data.self ? `İlkin audit: ${data.self}` : 'İlkin audit';
  $('sub').textContent = `${periodText}: ${data.counts.sales} satış və ${data.counts.purchases} alış qaiməsi, ${data.counts.acts} akt, ${data.payroll.declarations} muzdlu iş bəyannaməsi`;

  // ------------------------------------------------------------ income table
  const I = data.income;
  const incRows = [
    ['200.1', 'Malların satışı', I.goods],
    ['200.2', 'İşlərin görülməsi və xidmətlər', I.services],
    ['200', 'Növü müəyyən olunmayan sətirlər', I.unknown],
    ['', 'Alıcıların qaytardığı mallar', -I.returns],
  ].filter((r, i) => i < 2 || r[2]);
  const incT = $('inc-table');
  const incMax = Math.max(...incRows.map((r) => Math.abs(r[2])), 1);
  incRows.forEach(([c, l, v]) => incT.appendChild(el('tr', { class: (v < 0 ? 'minus' : '') + (v === 0 ? ' zero' : '') },
    el('td', { class: 'code' }, c), el('td', null, l, v > 0 ? el('span', { class: 'bar inc', style: `width:${(v / incMax) * 100}%` }) : null), el('td', { class: 'n' }, money(v)))));
  if (I.advances) incT.appendChild(el('tr', { class: 'zero' }, el('td', { class: 'code' }), el('td', null, 'Alınmış avanslar (gəlirə daxil edilmədi)'), el('td', { class: 'n' }, money(I.advances))));
  const incSum = el('tr', { class: 'sum' }, el('td', { class: 'code' }, '218'), el('td', null, 'Ümumi gəlir'), el('td', { class: 'n', id: 'inc-total' }, money(I.total)));
  incT.appendChild(incSum);
  const tot = Math.max(I.goods + I.services + I.unknown, 1);
  [[I.goods, 'var(--inc)', 'Mal'], [I.services, '#5bb8c4', 'Xidmət'], [I.unknown, '#b9c7c5', 'Təyin olunmayan']]
    .forEach(([v, c, t]) => { if (v > 0) $('split').appendChild(el('i', { style: `flex:${v / tot};background:${c}`, title: `${t}: ${money(v)}` })); });

  // ------------------------------------------------------------ expense table
  const expT = $('exp-table');
  const expMax = Math.max(...data.expenses.map((e) => e.amount), 1);
  data.expenses.forEach((e) => {
    if (!e.amount && !['221.1', '221.2', '221.4'].includes(e.code)) return;
    expT.appendChild(el('tr', { class: e.amount ? '' : 'zero' }, el('td', { class: 'code' }, e.code),
      el('td', null, e.label, e.amount > 0 ? el('span', { class: 'bar', style: `width:${(e.amount / expMax) * 100}%` }) : null),
      el('td', { class: 'n' }, money(e.amount))));
  });
  const adjRow = el('tr', { hidden: '' }, el('td', { class: 'code' }), el('td', null, 'Əl ilə əlavə edilən xərclər'), el('td', { class: 'n', id: 'adj-exp' }));
  expT.appendChild(adjRow);
  expT.appendChild(el('tr', { class: 'sum' }, el('td', { class: 'code' }, '234'), el('td', null, 'Cəmi xərclər'), el('td', { class: 'n', id: 'exp-total' }, money(data.expenseTotal))));

  // ------------------------------------------------------------ headline formula (recomputed with manual additions)
  const adj = { 227: 0, '221.13': 0, other: 0, income: 0 };
  function recompute() {
    const extraExp = adj[227] + adj['221.13'] + adj.other;
    const inc = data.income.total + adj.income;
    const exp = data.expenseTotal + extraExp;
    const pro = inc - exp;
    const tax = pro > 0 ? pro * 0.2 : 0;
    $('f-inc').textContent = money(inc);
    $('f-exp').textContent = money(exp);
    $('f-pro').textContent = money(pro);
    $('f-tax').textContent = money(tax);
    $('f-pro-cap').textContent = pro >= 0 ? 'Mənfəət' : 'Zərər';
    $('f-pro').parentElement.classList.toggle('loss', pro < 0);
    $('f-margin').textContent = inc ? `gəlirin ${(pro / inc * 100).toFixed(1).replace('.', ',')}%-i` : '';
    $('f-inc-n').textContent = `${data.income.count} qaimə`;
    $('f-exp-n').textContent = `${data.counts.purchases} qaimə, ${data.payroll.months} ay əmək haqqı`;
    document.querySelector('.formula').style.setProperty('--inc-share', `${(inc / Math.max(inc + exp, 1)) * 100}%`);
    $('inc-total').textContent = money(inc);
    $('exp-total').textContent = money(exp);
    adjRow.hidden = !extraExp;
    $('adj-exp').textContent = money(extraExp);
    state.inc = inc; state.exp = exp; state.pro = pro; state.tax = tax;
  }
  const state = {};
  document.querySelectorAll('[data-adj]').forEach((inp) => inp.addEventListener('input', () => { adj[inp.dataset.adj] = Math.max(0, n0(inp.value)); recompute(); }));
  recompute();

  // ------------------------------------------------------------ VAT
  $('v-out').textContent = money(I.vat);
  $('v-in').textContent = money(data.vatIn);
  const vd = I.vat - data.vatIn;
  $('v-lbl').textContent = vd >= 0 ? 'Büdcəyə ödəniləcək (təxmini)' : 'Artıq ödənilmiş ƏDV (təxmini)';
  $('v-diff').textContent = money(Math.abs(vd));

  // ------------------------------------------------------------ monthly chart (grouped bars, one axis, hover tooltip)
  (function chart() {
    const M = data.months;
    const box = $('chart');
    if (!M.length) { box.appendChild(el('p', { class: 'empty' }, 'Bu dövrdə hərəkət yoxdur.')); return; }
    const W = Math.max(640, M.length * 70), H = 260, pl = 56, pr = 10, pt = 12, pb = 28;
    const max = Math.max(...M.map((m) => Math.max(m.income, m.expense)), 1);
    const min = Math.min(0, ...M.map((m) => Math.min(m.income, m.expense)));
    const step = Math.pow(10, Math.floor(Math.log10(max))) * (max / Math.pow(10, Math.floor(Math.log10(max))) > 5 ? 2 : 1);
    const top = Math.ceil(max / step) * step;
    const y = (v) => pt + (H - pt - pb) * (1 - (v - min) / (top - min));
    const ns = 'http://www.w3.org/2000/svg';
    const s = (tag, a) => { const e = document.createElementNS(ns, tag); Object.entries(a || {}).forEach(([k, v]) => e.setAttribute(k, v)); return e; };
    const svg = s('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%', role: 'img', 'aria-label': 'Aylar üzrə gəlir və xərc' });
    const g = s('g', { class: 'grid' }); const ax = s('g', { class: 'axis' });
    for (let v = 0; v <= top + 1e-9; v += step) {
      g.appendChild(s('line', { x1: pl, x2: W - pr, y1: y(v), y2: y(v) }));
      const t = s('text', { x: pl - 8, y: y(v) + 4, 'text-anchor': 'end' }); t.textContent = short(v); ax.appendChild(t);
    }
    svg.appendChild(g);
    const bw = (W - pl - pr) / M.length;
    const barW = Math.min(22, bw * 0.3);
    const tip = $('tip');
    M.forEach((m, i) => {
      const cx = pl + bw * i + bw / 2;
      const grp = s('g', { class: 'm' });
      grp.appendChild(s('rect', { class: 'hit', x: pl + bw * i, y: pt, width: bw, height: H - pt - pb }));
      [[m.income, 'var(--inc)', -1], [m.expense, 'var(--exp)', 1]].forEach(([v, c, side]) => {
        const x = cx + (side < 0 ? -barW - 1 : 1);
        const y0 = y(Math.max(v, 0)), y1 = y(Math.min(v, 0));
        const h = Math.max(1, y1 - y0);
        const r = Math.min(4, barW / 2, h);
        // rounded only at the data end, square at the baseline
        const d = v >= 0
          ? `M${x},${y1} V${y0 + r} Q${x},${y0} ${x + r},${y0} H${x + barW - r} Q${x + barW},${y0} ${x + barW},${y0 + r} V${y1} Z`
          : `M${x},${y0} V${y1 - r} Q${x},${y1} ${x + r},${y1} H${x + barW - r} Q${x + barW},${y1} ${x + barW},${y1 - r} V${y0} Z`;
        grp.appendChild(s('path', { d, fill: c }));
      });
      const [yy, mm] = m.key.split('-');
      const t = s('text', { x: cx, y: H - 8, 'text-anchor': 'middle' }); t.textContent = MON3[Number(mm) - 1] + (M.length > 12 || i === 0 || mm === '01' ? ` ${yy.slice(2)}` : '');
      ax.appendChild(t);
      grp.addEventListener('mousemove', (ev) => {
        tip.hidden = false;
        tip.innerHTML = '';
        tip.append(el('div', null, `${MONTHS[Number(mm) - 1]} ${yy}`), el('div', null, 'Gəlir: ', el('b', null, money(m.income))),
          el('div', null, 'Xərc: ', el('b', null, money(m.expense))), el('div', null, 'Fərq: ', el('b', null, money(m.income - m.expense))));
        tip.style.left = Math.min(ev.clientX + 14, innerWidth - 200) + 'px'; tip.style.top = (ev.clientY + 14) + 'px';
      });
      grp.addEventListener('mouseleave', () => { tip.hidden = true; });
      svg.appendChild(grp);
    });
    svg.appendChild(s('line', { x1: pl, x2: W - pr, y1: y(0), y2: y(0), stroke: '#9fb3b0' }));
    svg.appendChild(ax);
    box.appendChild(svg);
    const mt = $('month-table');
    mt.appendChild(el('tr', null, el('th', null, 'Ay'), el('th', { class: 'n' }, 'Gəlir'), el('th', { class: 'n' }, 'Xərc'), el('th', { class: 'n' }, 'Fərq')));
    M.forEach((m) => { const [yy, mm] = m.key.split('-'); mt.appendChild(el('tr', null, el('td', null, `${MONTHS[Number(mm) - 1]} ${yy}`), el('td', { class: 'n' }, money(m.income)), el('td', { class: 'n' }, money(m.expense)), el('td', { class: 'n' }, money(m.income - m.expense)))); });
  })();

  // ------------------------------------------------------------ comparison with the filed declaration
  if (data.declared && data.declared.values) {
    const v = data.declared.values;
    $('cmp-panel').hidden = false;
    $('cmp-reg').textContent = `sənəd № ${data.declared.reg}`;
    const exp = (c) => (data.expenses.find((e) => e.code === c) || {}).amount || 0;
    const rows = [
      ['200.1', 'Malların satışından gəlir', I.goods, v['200.1']],
      ['200.2', 'İş və xidmətlərdən gəlir', I.services, v['200.2']],
      ['218', 'Ümumi gəlirlər', I.total, v['218']],
      ['221.1', 'Əmək haqqı', exp('221.1'), v['221.1']],
      ['221.2', 'Sosial sığorta haqları', exp('221.2'), v['221.2']],
      ['221.4', 'Malın dəyəri', exp('221.4'), v['221.4']],
      ['234', 'Cəmi xərclər', data.expenseTotal, v['234']],
      ['237', 'Vergitutma məqsədləri üçün mənfəət', data.profit, v['237']],
      ['243', 'Mənfəət vergisi', data.tax, v['243']],
    ];
    const t = $('cmp-table');
    t.appendChild(el('tr', null, el('th', null, 'Kod'), el('th', null, 'Göstərici'), el('th', { class: 'n' }, 'Portal məlumatı ilə'), el('th', { class: 'n' }, 'Bəyannamədə'), el('th', { class: 'n' }, 'Fərq')));
    rows.forEach(([c, l, a, b]) => {
      const d = n0(a) - n0(b);
      t.appendChild(el('tr', null, el('td', { class: 'code' }, c), el('td', null, l), el('td', { class: 'n' }, money(a)), el('td', { class: 'n' }, money(b)),
        el('td', { class: 'n d ' + (Math.abs(d) < 0.01 ? '' : d > 0 ? 'pos' : 'neg') }, Math.abs(d) < 0.01 ? 'uyğundur' : money(d))));
    });
  }

  // ------------------------------------------------------------ top counterparties
  const who = (id, list) => {
    const ol = $(id);
    if (!list.length) { ol.replaceWith(el('p', { class: 'empty' }, 'Qaimə yoxdur.')); return; }
    list.forEach((c) => ol.appendChild(el('li', null, el('span', { class: 'nm' }, c.name || '—', el('small', null, `${c.tin || ''}${c.tin ? ', ' : ''}${c.count} sətir`)), el('span', { class: 'am' }, money(c.amount)))));
  };
  who('top-c', data.customers);
  who('top-s', data.suppliers);

  // ------------------------------------------------------------ notes
  [
    'Gəlir: təsdiqlənmiş satış qaimələrinin ƏDV-siz və aksizsiz dəyəri. Mal və xidmət bölgüsü qaimə sətrinin növünə görədir.',
    'Xərc: təsdiqlənmiş alış qaimələri və alış aktları. Sətirlər adına və təchizatçıya görə bəyannamə xətlərinə (enerji, yanacaq, rabitə və s.) bölünür; qalan mallar 221.4, xidmətlər 221.15-ə düşür.',
    'Əmək haqqı və işəgötürənin sosial, işsizlik və tibbi sığorta haqları muzdlu iş bəyannamələrindən aylar üzrə götürülür.',
    'Avans qaimələri gəlirə daxil edilmir; qaytarma qaimələri gəliri və ya malın dəyərini azaldır.',
    'Amortizasiya, bank xərcləri və nağd xərclər portalda olmadığı üçün yuxarıdakı xanalara əl ilə əlavə edilə bilər.',
    'Bu, ilkin qiymətləndirmədir: dəqiq vergi bəyannaməsi mühasibat uçotu əsasında hazırlanmalıdır.',
  ].forEach((t) => $('notes').appendChild(el('li', null, t)));

  // ------------------------------------------------------------ Excel / print
  $('print').onclick = () => window.print();
  $('xlsx').onclick = () => {
    const H = (v) => ({ v, s: 'h' }), B = (v) => ({ v, s: 'b' }), BN = (v) => ({ v: Math.round(n0(v) * 100) / 100, s: 'bn2' }), N = (v) => ({ v: Math.round(n0(v) * 100) / 100, s: 'n2' });
    const sum = [
      [B(`İlkin audit — ${data.self || ''}`)], [periodText], [],
      [H('Kod'), H('Göstərici'), H('Məbləğ (manat)')],
      ['200.1', 'Malların satışı', N(I.goods)], ['200.2', 'İş və xidmətlər', N(I.services)], ['200', 'Növü müəyyən olunmayan', N(I.unknown)],
      ['', 'Qaytarılan mallar', N(-I.returns)], [B('218'), B('Ümumi gəlir'), BN(state.inc)], [],
      ...data.expenses.filter((e) => e.amount).map((e) => [e.code, e.label, N(e.amount)]),
      ...[['227', 'Amortizasiya (əl ilə)', adj[227]], ['221.13', 'Bank xidməti (əl ilə)', adj['221.13']], ['', 'Digər xərclər (əl ilə)', adj.other]].filter((r) => r[2]).map((r) => [r[0], r[1], N(r[2])]),
      [B('234'), B('Cəmi xərclər'), BN(state.exp)], [],
      [B(''), B(state.pro >= 0 ? 'Mənfəət' : 'Zərər'), BN(state.pro)],
      [B(''), B('Mənfəət vergisi (20%)'), BN(state.tax)], [],
      ['', 'Satışlar üzrə ƏDV', N(I.vat)], ['', 'Alışlar üzrə ƏDV', N(data.vatIn)],
    ];
    const months = [[H('Ay'), H('Gəlir'), H('Xərc'), H('Fərq')], ...data.months.map((m) => { const [yy, mm] = m.key.split('-'); return [`${MONTHS[Number(mm) - 1]} ${yy}`, N(m.income), N(m.expense), N(m.income - m.expense)]; })];
    const inc = [['Tarix', 'Seriya', 'Alıcının VÖEN', 'Alıcı', 'Mal / xidmət', 'Növ', 'Dəyər (ƏDV-siz)', 'ƏDV'].map(H), ...data.lines.income.map((r) => [fmtD(r[0]), r[1], r[2], r[3], r[4], r[5], N(r[6]), N(r[7])])];
    const exp = [['Tarix', 'Seriya', 'Təchizatçının VÖEN', 'Təchizatçı', 'Mal / xidmət', 'Kod', 'Xərc xətti', 'Dəyər (ƏDV-siz)', 'ƏDV'].map(H), ...data.lines.expense.map((r) => [fmtD(r[0]), r[1], r[2], r[3], r[4], r[5], r[6], N(r[7]), N(r[8])])];
    AMMO_XLSX.download([
      { name: 'Xülasə', rows: sum, autoFilter: false, maxWidth: 60 },
      { name: 'Aylar', rows: months },
      { name: 'Gəlir sətirləri', rows: inc, maxWidth: 50 },
      { name: 'Xərc sətirləri', rows: exp, maxWidth: 50 },
    ], `AMMO_Ilkin_audit_${P.fromISO}_${P.toISO}.xlsx`);
  };
})();
