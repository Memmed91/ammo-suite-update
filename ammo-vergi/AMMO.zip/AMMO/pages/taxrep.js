/* AMMO — Vergi hesabatı səhifəsi: portaldakı bəyannamə maketi ilə eyni cədvəllər, canlı hesablama, «Doldur — e-taxes». */
(async function () {
  'use strict';
  const T = window.AMMO_TAXREP_FORMS;
  const $ = (id) => document.getElementById(id);
  const key = new URLSearchParams(location.search).get('key');
  const data = key ? (await chrome.storage.local.get(key))[key] : null;
  if (!data) { $('title').textContent = 'Hesabat tapılmadı. AMMO panelində «Vergi hesabatları» → ili seçib «Doldur» basın.'; return; }

  const form = T.getForm(data.type);
  const P = data.type === 'profit';
  const n0 = T.n0, r2 = T.r2;
  const clone = (o) => JSON.parse(JSON.stringify(o));
  if (!data.auto) data.auto = { values: clone(data.values), rules: clone(data.rules), goods: clone(data.goods || {}) };
  if (!data.edited) data.edited = {};
  if (!data.meta) data.meta = {};
  const M = data.meta;
  const year = Number(data.year);

  // ------------------------------------------------------------------ köməkçilər
  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (v === undefined || v === null || v === false) return;
      if (k === 'class') e.className = v; else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2), v);
      else if (k === 'checked' || k === 'value' || k === 'readOnly') e[k] = v;
      else e.setAttribute(k, v === true ? '' : v);
    });
    kids.flat(Infinity).forEach((c) => { if (c !== null && c !== undefined && c !== false) e.appendChild(c instanceof Node ? c : document.createTextNode(String(c))); });
    return e;
  };
  const money = (v) => {
    const x = r2(v);
    const [i, f] = Math.abs(x).toFixed(2).split('.');
    return (x < 0 ? '−' : '') + i.replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ',' + f;
  };
  const parseNum = (s) => {
    let t = String(s || '').replace(/[\s ₼]/g, '').replace(/−/g, '-');
    if (/,\d{1,2}$/.test(t) && !/\.\d/.test(t)) t = t.replace(/\./g, '').replace(',', '.'); else t = t.replace(/,/g, '');
    const x = Number(t);
    return isFinite(x) ? x : 0;
  };
  const fmtD = (iso) => { const [y, m, d] = String(iso || '').slice(0, 10).split('-'); return d ? `${d}.${m}.${y}` : ''; };
  let saveTimer = null;
  const save = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => { data.updated = Date.now(); chrome.storage.local.set({ [key]: data }); }, 350); };
  function toast(text, kind = '', ms = 6500) {
    const t = $('toast'); t.textContent = text; t.className = 'toast ' + kind; t.hidden = false;
    clearTimeout(toast.tm); toast.tm = setTimeout(() => { t.hidden = true; }, ms);
  }

  // ------------------------------------------------------------------ başlıq
  const kind = P ? 'Mənfəət vergisinin bəyannaməsi' : 'Gəlir vergisinin bəyannaməsi';
  document.title = `AMMO — ${kind} ${year}`;
  $('title').textContent = `${kind} — ${year}-ci il${M.name ? ' · ' + M.name : ''}`;
  const c = data.counts || {};
  $('sub').textContent = `Portal məlumatı: ${c.sales || 0} satış və ${c.purchases || 0} alış qaiməsi, ${c.acts || 0} akt, ${(data.payroll && data.payroll.declarations) || 0} muzdlu iş bəyannaməsi · hazırlandı ${new Date(data.created).toLocaleString('az-AZ')}`;
  if (P) $('xml').hidden = false;

  // ------------------------------------------------------------------ Bölmə 1
  const sheet = $('sheet');
  const radios = (name, opts, cur, onChange) => el('div', { class: 'radios' }, opts.map(([v, l]) => el('label', null,
    el('input', { type: 'radio', name, value: v, checked: String(cur) === String(v), onchange: () => { onChange(v); save(); } }), l)));
  const txt = (val, onChange, ph) => el('input', { type: 'text', value: val || '', placeholder: ph || '', oninput: (e) => { onChange(e.target.value); save(); } });
  if (!M.declType) M.declType = 'current';
  const crit = radios('crit', [[1, 'Mikro'], [2, 'Kiçik'], [3, 'Orta'], [4, 'İri']], M.criterion || 1, (v) => { M.criterion = Number(v); });
  const infoRows = P ? [
    ['1', 'VÖEN', txt(M.tin, (v) => (M.tin = v), '10 rəqəm')],
    ['2', 'Vergi ödəyicisinin (agentinin) tam adı', txt(M.name, (v) => (M.name = v))],
    ['3', 'Vergi ödəyicisinin qrupu', radios('grp', [[1, 'Vergi Məcəlləsinin çərçivəsində fəaliyyət göstərən'], [2, 'İxrac məqsədli neft-qaz fəaliyyətinə dair xüsusi rejim']], M.group || 1, (v) => (M.group = Number(v)))],
    ['4', 'Əsas fəaliyyət növünün kodu və adı', el('div', { style: 'display:grid;grid-template-columns:110px 1fr;gap:6px' }, txt(M.activityCode, (v) => (M.activityCode = v), 'kod'), txt(M.activityName, (v) => (M.activityName = v), 'adı'))],
    ['5', 'Təqdim olunmuş əlavələrin sayı', txt(M.attachments || '0', (v) => (M.attachments = v))],
    ['6', 'Bəyannamənin növü', radios('dtype', [['current', 'Cari'], ['clarifying', 'Dəqiqləşdirilmiş'], ['voluntary', 'Könüllü açıqlama'], ['liquidation', 'Ləğv olma']], M.declType, (v) => (M.declType = v))],
    ['7', 'Uçot metodu', radios('meth', [['cash', 'Kassa metodu'], ['accrual', 'Hesablama metodu']], M.method || 'accrual', (v) => (M.method = v))],
    ['8', 'Sahibkarlıq subyektinin meyarı', crit],
    ['9', 'Vergi dövrü', el('b', null, String(year))],
    ['10', 'Vergi agenti olması barədə qeyd', el('label', { class: 'radios' }, el('input', { type: 'checkbox', checked: !!M.agent, onchange: (e) => { M.agent = e.target.checked; save(); } }), 'Vergi agentidir')],
  ] : [
    ['1', 'VÖEN', txt(M.tin, (v) => (M.tin = v), '10 rəqəm')],
    ['2', 'Vergi ödəyicisinin soyadı, adı, atasının adı', txt(M.name, (v) => (M.name = v))],
    ['3', 'Əsas fəaliyyət növünün kodu və adı', el('div', { style: 'display:grid;grid-template-columns:110px 1fr;gap:6px' }, txt(M.activityCode, (v) => (M.activityCode = v), 'kod'), txt(M.activityName, (v) => (M.activityName = v), 'adı'))],
    ['4', 'Təqdim olunmuş əlavələrin sayı', txt(M.attachments || '0', (v) => (M.attachments = v))],
    ['5', 'Bəyannamənin növü', radios('dtype', [['current', 'Cari'], ['clarifying', 'Dəqiqləşdirilmiş'], ['voluntary', 'Könüllü açıqlama'], ['liquidation', 'Fəaliyyətin dayandırılması']], M.declType, (v) => (M.declType = v))],
    ['6', 'Uçot metodu', radios('meth', [['cash', 'Kassa metodu'], ['accrual', 'Hesablama metodu']], M.method || 'accrual', (v) => (M.method = v))],
    ['7', 'Sahibkarlıq subyektinin meyarı', crit],
    ['8', 'Vergi dövrü', el('b', null, String(year))],
    ['9', 'Vergi agenti olması barədə qeyd', el('label', { class: 'radios' }, el('input', { type: 'checkbox', checked: !!M.agent, onchange: (e) => { M.agent = e.target.checked; save(); } }), 'Vergi agentidir')],
  ];
  sheet.appendChild(el('div', { class: 'doc-head' },
    el('div', { class: 'org' }, 'Azərbaycan Respublikasının İqtisadiyyat Nazirliyi yanında Dövlət Vergi Xidməti'),
    el('h2', null, form.title),
    el('div', { class: 'yr' }, `Hesabat ili: ${year}`),
    el('div', { class: 'note' }, 'Məbləğlər manatla, ƏDV, aksiz və yol vergisi nəzərə alınmadan göstərilir.')));
  const stepDefs = [['b1', 'Bölmə 1']];
  sheet.appendChild(el('section', { class: 'blk', id: 'b1' }, el('h3', null, 'Bölmə 1. Vergi ödəyicisi (agenti) haqqında ümumi məlumat'),
    el('div', { class: 'info' }, infoRows.map(([n, l, ctl]) => el('div', null, el('span', { class: 'n' }, n), el('div', { class: 'c' }, el('small', null, l), ctl))))));

  // ------------------------------------------------------------------ mənbə sətirləri (ⓘ) — hansı qaimələrdən gəlib
  const SRC = {};
  const incLines = data.incomeLines || [], expLines = data.expenseLines || [];
  const RENT = /icar[əe]|kiray[əe]|arenda/i;
  const incPick = (fn) => incLines.filter(fn);
  SRC[P ? '200.1.2' : '1200.1.2'] = () => ['Satış qaimələri — mallar', incPick((l) => !RENT.test(l[4]) && l[5] !== 'Xidmət'), 'inc'];
  SRC[P ? '200.2' : '1200.2'] = () => ['Satış qaimələri — iş və xidmətlər', incPick((l) => !RENT.test(l[4]) && l[5] === 'Xidmət'), 'inc'];
  SRC[P ? '203.2' : '1203.2.1'] = () => ['Satış qaimələri — icarə', incPick((l) => RENT.test(l[4])), 'inc'];
  const EXPMAP = P
    ? { '221.4': '221.4', '221.5.1.1': '221.5', '221.5.1.2': '221.5', '221.7': '221.7', '221.8': '221.8', '221.9': '221.9', '221.10': '221.10', '221.11': '221.11', '221.12': '221.12', '221.13': '221.13', '221.14': '221.14', '221.15': '221.15', '228.4': '228', '229.1': '229', '230.2': '230.2' }
    : { '1226.4': '221.4', '1226.5.1.1': '221.5', '1226.5.1.2': '221.5', '1226.7': '221.7', '1226.8': '221.8', '1226.9': '221.9', '1226.10': '221.10', '1226.11': '221.11', '1226.12': '221.12', '1226.13': '221.13', '1226.14': '221.14', '1226.15': '221.15', '1232.4': '228', '1233.1': '229', '1234': '230.2' };
  Object.entries(EXPMAP).forEach(([code, ac]) => {
    SRC[code] = () => ['Alış qaimələri və aktlar', expLines.filter((l) => l[5] === ac && (code.endsWith('.1.2') ? /2$/.test(String(l[2])) : code.includes('.5.1.1') ? !/2$/.test(String(l[2])) : true)), 'exp'];
  });
  function showSource(code) {
    const [title, list, kindL] = SRC[code]();
    const sum = list.reduce((s, l) => s + n0(kindL === 'inc' ? l[6] : l[7]), 0);
    $('dlg-t').textContent = `${code} — ${title} (${list.length} sətir, ${money(sum)} ₼)`;
    const head = kindL === 'inc' ? ['Tarix', 'Seriya', 'VÖEN', 'Alıcı', 'Mal / xidmət', 'Növ', 'Dəyər (ƏDV-siz)'] : ['Tarix', 'Seriya', 'VÖEN', 'Təchizatçı', 'Mal / xidmət', 'Dəyər (ƏDV-siz)'];
    const rows = list.slice(0, 2000).map((l) => (kindL === 'inc' ? [fmtD(l[0]), l[1], l[2], l[3], l[4], l[5], money(l[6])] : [fmtD(l[0]), l[1], l[2], l[3], l[4], money(l[7])]));
    const b = $('dlg-b'); b.innerHTML = '';
    b.appendChild(el('table', null, el('thead', null, el('tr', null, head.map((h) => el('th', null, h)))),
      el('tbody', null, rows.map((r) => el('tr', null, r.map((x, i) => el('td', { class: i === r.length - 1 ? 'n' : '' }, x)))))));
    if (!list.length) b.appendChild(el('p', null, 'Bu sətir üçün qaimə tapılmadı (dəyər əl ilə və ya digər mənbədən yazılıb).'));
    $('dlg').showModal();
  }

  // ------------------------------------------------------------------ bölmələr (portal maketi)
  const TOTALS = new Set(P ? ['218', '220', '234', '236', '237', '241', '243', '245', '1', '2'] : ['1223', '1225', '1238', '1240', '1241', '1245', '1246', '1248', '1', '2']);
  const cells = []; // {sid, code, k, input, td}
  const rowEls = []; // {sid, code, tr}
  const filedOn = () => $('cmp').checked && data.filed && data.filed.values;
  const labelOf = (sec, r) => {
    if (P && /^240\.[1-5]$/.test(r.code)) { const i = Number(r.code.split('.')[1]); return `${T.ilText(year - 6 + i)} üzrə zərərin məbləği`; }
    return r.text;
  };
  const SHORT = { incomes: 'Gəlirlər', expenses: 'Xərclər', calc: 'Verginin hesablanması', assets: 'Əlavə 1 · Aktivlər', capital: 'Əlavə 1 · Kapital' };
  form.sections.forEach((sec) => {
    const id = 's-' + sec.id;
    stepDefs.push([id, SHORT[sec.id], sec]);
    const ncol = sec.fields.length;
    const table = el('table', { class: 'decl' + (sec.balance ? ' bal' : ''), style: `--vw:${sec.balance ? 120 : ncol > 1 ? 170 : 200}px` },
      el('colgroup', null, el('col', null), sec.fields.map(() => el('col', { style: `width:${sec.balance ? 118 : ncol > 1 ? 170 : 200}px` }))),
      el('thead', null, el('tr', null, sec.header.map((h) => el('th', null, h)))));
    const tb = el('tbody');
    sec.rows.forEach((r) => {
      const tr = el('tr', { class: `l${Math.min(r.level, 4)}${r.level === 0 ? ' lvl0' : ''}${TOTALS.has(r.code) ? ' total' : ''}`, 'data-code': r.code });
      tr.appendChild(el('td', { class: 'k' }, el('span', { class: 'code' }, r.code), ' ', labelOf(sec, r),
        SRC[r.code] && !sec.balance ? el('button', { class: 'src', type: 'button', title: 'Hansı qaimələrdən yığılıb', onclick: () => showSource(r.code) }, 'mənbə') : null));
      for (let k = 0; k < ncol; k++) {
        const calc = T.isCalcCol(form, sec, r.code, k);
        const input = el('input', { type: 'text', inputmode: 'decimal', readOnly: calc, 'aria-label': `${r.code} ${sec.header[k + 1] || ''}` });
        const td = el('td', { class: 'v' + (calc ? ' calc' : '') }, input);
        if (!calc) {
          input.addEventListener('focus', () => { const x = n0(data.values[sec.id][r.code][k]); input.value = x ? String(x) : ''; input.select(); });
          input.addEventListener('blur', () => commit(sec, r.code, k, input.value));
          input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); focusNext(input); } });
        }
        tr.appendChild(td);
        cells.push({ sid: sec.id, code: r.code, k, input, td, calc });
      }
      tb.appendChild(tr);
      rowEls.push({ sid: sec.id, code: r.code, tr });
    });
    table.appendChild(tb);
    sheet.appendChild(el('section', { class: 'blk', id }, el('h3', null, sec.title), table));
  });
  sheet.appendChild(el('div', { class: 'legend' },
    el('span', null, el('i', { class: 'a' }), 'portal məlumatından avtomatik'), el('span', null, el('i', { class: 'c' }), 'hesablanan xana (düstur)'),
    el('span', null, el('i', { class: 'e' }), 'əl ilə dəyişdirilib')));
  sheet.appendChild(el('div', { class: 'signs' }, el('div', null, 'Vergi ödəyicisi (rəhbər) — imza'), el('div', null, `Tarix: ____ . ____ . ${year + 1}`)));
  function focusNext(input) {
    const list = cells.filter((x) => !x.calc).map((x) => x.input);
    const i = list.indexOf(input); if (i >= 0 && list[i + 1]) list[i + 1].focus();
  }

  // addım paneli
  const steps = $('steps');
  const stepLinks = stepDefs.map(([id, label]) => {
    const a = el('a', { href: '#' + id, onclick: (e) => { e.preventDefault(); document.getElementById(id).scrollIntoView({ behavior: 'smooth' }); } }, label, el('b'));
    steps.appendChild(a); return a;
  });
  const io = new IntersectionObserver((ents) => ents.forEach((en) => {
    if (en.isIntersecting) { const i = stepDefs.findIndex((d) => d[0] === en.target.id); stepLinks.forEach((a, j) => a.classList.toggle('on', i === j)); }
  }), { rootMargin: '-120px 0px -70% 0px' });
  stepDefs.forEach(([id]) => io.observe(document.getElementById(id)));

  // ------------------------------------------------------------------ dəyərlər
  const ruleCodes = P ? { rel: '238', loss: ['240', '240.1', '240.2', '240.3', '240.4', '240.5'] } : { rel: '1242', loss: ['1244'] };
  const goodsCode = P ? '221.4' : '1226.4';
  function commit(sec, code, k, raw) {
    const x = r2(parseNum(raw));
    const old = n0(data.values[sec.id][code][k]);
    if (x !== old) {
      data.values[sec.id][code][k] = x;
      const auto = n0(((data.auto.values[sec.id] || {})[code] || [])[k]);
      const ek = `${sec.id}|${code}|${k}`;
      if (x !== auto) data.edited[ek] = true; else delete data.edited[ek];
      if (sec.id === 'calc' && code === ruleCodes.rel && data.rules.relief) { data.rules.relief = null; $('relief').checked = false; }
      if (sec.id === 'calc' && ruleCodes.loss.includes(code) && data.rules.lossOn !== false) { data.rules.lossOn = false; $('loss').checked = false; }
      if (sec.id === 'expenses' && code === goodsCode) { data.goods.closing = r2(n0(data.goods.opening) + n0(data.goods.purchases) - x); syncGoodsInputs(); }
    }
    refresh();
  }
  function runRules() {
    const R = { year, relief: data.rules.relief === true ? true : (data.rules.relief === false ? false : undefined) };
    if (data.rules.lossOn !== false) R.losses = data.rules.losses || [];
    T.applyRules(form, data.values, R);
  }
  function refresh() {
    runRules();
    const filed = filedOn();
    cells.forEach(({ sid, code, k, input, td }) => {
      const x = n0(data.values[sid][code][k]);
      if (document.activeElement !== input) input.value = x ? money(x) : '';
      td.classList.toggle('edited', !!data.edited[`${sid}|${code}|${k}`]);
      const auto = n0(((data.auto.values[sid] || {})[code] || [])[k]);
      td.classList.toggle('auto', !td.classList.contains('calc') && !data.edited[`${sid}|${code}|${k}`] && auto !== 0);
      let was = td.querySelector('.was');
      if (filed) {
        const fv = ((filed[sid] || {})[code] || [])[k];
        if (fv !== undefined) {
          if (!was) { was = el('small', { class: 'was' }); td.appendChild(was); }
          was.textContent = 'portalda: ' + money(fv);
          was.classList.toggle('diff', Math.abs(n0(fv) - x) > 0.009);
        } else if (was) was.remove();
      } else if (was) was.remove();
    });
    rowEls.forEach(({ sid, code, tr }) => tr.classList.toggle('zero', !(data.values[sid][code] || []).some((x) => n0(x))));
    renderSide();
    save();
  }

  // ------------------------------------------------------------------ yan panel
  const V = (sid, code, k = 0) => n0(((data.values[sid] || {})[code] || [])[k]);
  function renderSide() {
    const dl = $('totals'); dl.innerHTML = '';
    const rows = P ? [
      ['Ümumi gəlirlər (218)', V('incomes', '218')], ['Gəlirdən çıxılmalar (219)', V('incomes', '219')],
      ['Gəlirdən çıxılan xərclər (236)', V('expenses', '236')],
      [V('calc', '239') ? 'Zərər (239)' : 'Mənfəət (237)', V('calc', '239') || V('calc', '237')],
      ['Güzəştlər (238)', V('calc', '238')], ['Keçmiş illərin zərəri (240)', V('calc', '240')],
      ['Vergiyə cəlb olunan mənfəət (241)', V('calc', '241')], [`Mənfəət vergisi ${V('calc', '242')}% (243)`, V('calc', '243')],
      ['Azaldılmalı vergi (244)', V('calc', '244')],
    ] : [
      ['Ümumi gəlirlər (1223)', V('incomes', '1223') + V('incomes', '1223', 1)], ['Çıxılmalar (1224)', V('incomes', '1224') + V('incomes', '1224', 1)],
      ['Gəlirdən çıxılan xərclər (1240)', V('expenses', '1240') + V('expenses', '1240', 1)],
      [V('calc', '1243') ? 'Zərər (1243)' : 'Vergiyə cəlb olunan gəlir (1241)', V('calc', '1243') || V('calc', '1241')],
      ['Güzəştlər (1242)', V('calc', '1242')], ['Keçmiş illərin zərəri (1244)', V('calc', '1244')],
      ['Vergi tutulan gəlir (1245)', V('calc', '1245')], ['Gəlir vergisi 20% / 14% (1246)', V('calc', '1246') + V('calc', '1246', 1)],
      ['Azaldılmalı vergi (1247)', V('calc', '1247')],
    ];
    rows.forEach(([l, x]) => dl.appendChild(el('div', null, el('dt', null, l), el('dd', null, money(x)))));
    $('pay').textContent = money(P ? V('calc', '245') : V('calc', '1248') + V('calc', '1248', 1));
    // addımlarda bölmə cəmləri
    const stepSum = { incomes: P ? V('incomes', '218') : V('incomes', '1223'), expenses: P ? V('expenses', '234') : V('expenses', '1238'), calc: P ? V('calc', '245') : V('calc', '1248'), assets: V('assets', '1', 5), capital: V('capital', '2', 5) };
    stepDefs.forEach(([, , sec], i) => { if (sec) stepLinks[i].querySelector('b').textContent = money(stepSum[sec.id]); });
    // yoxlamalar
    const list = T.checks(form, data.values, { year, microOk: M.microOk });
    const ul = $('checks'); ul.innerHTML = '';
    if (!list.some((x) => x.kind === 'bad' || x.kind === 'warn')) ul.appendChild(el('li', { class: 'ok' }, 'Məntiqi nəzarət: cəmlər və düsturlar düzgündür.'));
    list.forEach((x) => ul.appendChild(el('li', { class: x.kind }, x.text)));
    // mallar
    const cogs = Math.max(n0(data.goods.opening) + n0(data.goods.purchases) - n0(data.goods.closing), 0);
    $('g-cogs').textContent = money(cogs);
  }

  // ---- qaydalar
  const reliefArt = P ? 'VM 106.1.20' : 'VM 102.1.30';
  $('relief-lbl').textContent = `Mikro sahibkar güzəşti — ${P ? 'mənfəətin' : 'gəlirin'} 75%-i (${reliefArt})`;
  $('relief-hint').textContent = `Meyar: ${M.criterionLabel || '—'} · orta aylıq muzdlu işçi sayı ${n0(M.avgEmployees).toFixed(2)} (tələb: ən azı ${M.needEmp || (P ? 3 : 1)}), DSMF borcu olmamalıdır. ${M.microOk ? 'Şərtlər portal məlumatına görə ödənilir.' : 'Şərtlər ödənilmir — yalnız əminsinizsə yandırın.'}`;
  $('relief').checked = data.rules.relief === true;
  $('relief').onchange = (e) => { data.rules.relief = e.target.checked ? true : false; data.rules._reliefWasAuto = true; if (!e.target.checked) data.values.calc[ruleCodes.rel][0] = 0; refresh(); };
  const losses = data.rules.losses || [];
  $('loss').checked = data.rules.lossOn !== false;
  $('loss-hint').textContent = losses.length
    ? 'Qalıq: ' + losses.map((l) => `${l.year}: ${money(l.amount)}`).join('; ') + ` (VM ${P ? '121.1 — 5 il' : '121.2 — 3 il'})`
    : `Əvvəlki ${P ? '5' : '3'} ilin bəyannamələrində kompensasiya olunmamış zərər tapılmadı.`;
  $('loss').onchange = (e) => {
    data.rules.lossOn = e.target.checked;
    if (!e.target.checked) ruleCodes.loss.forEach((c) => { if (data.values.calc[c]) data.values.calc[c][0] = 0; });
    refresh();
  };
  $('onlyfilled').onchange = (e) => document.body.classList.toggle('onlyfilled', e.target.checked);
  if (data.filed && data.filed.values) {
    $('cmp-wrap').hidden = false;
    $('cmp-wrap').querySelector('span').textContent = `Portalda təqdim olunmuş bəyannamə ilə müqayisə (№ ${data.filed.reg})`;
    $('cmp').onchange = () => refresh();
  }

  // ---- mallar
  $('g-code').textContent = `(${goodsCode} və Əlavə 1 · 1.3.2)`;
  function syncGoodsInputs() {
    [['g-open', 'opening'], ['g-buy', 'purchases'], ['g-close', 'closing']].forEach(([id, k]) => { if (document.activeElement !== $(id)) $(id).value = money(data.goods[k]); });
  }
  [['g-open', 'opening'], ['g-buy', 'purchases'], ['g-close', 'closing']].forEach(([id, k]) => {
    $(id).addEventListener('focus', (e) => { e.target.value = String(n0(data.goods[k]) || ''); e.target.select(); });
    $(id).addEventListener('change', (e) => {
      data.goods[k] = r2(parseNum(e.target.value));
      const cogs = r2(Math.max(n0(data.goods.opening) + n0(data.goods.purchases) - n0(data.goods.closing), 0));
      data.values.expenses[goodsCode][0] = cogs;
      const a = data.values.assets['1.3.2']; a[0] = r2(data.goods.opening); a[1] = r2(data.goods.purchases); a[2] = cogs;
      data.edited[`expenses|${goodsCode}|0`] = cogs !== n0(data.auto.values.expenses[goodsCode][0]) || undefined;
      if (!data.edited[`expenses|${goodsCode}|0`]) delete data.edited[`expenses|${goodsCode}|0`];
      syncGoodsInputs(); refresh();
    });
  });
  syncGoodsInputs();

  // ---- qeydlər
  const notes = $('notes');
  const nl = [
    `Gəlirlər: ${c.sales || 0} satış e-qaiməsinin hər sətri (ƏDV-siz) — mallar ${P ? '200.1.2' : '1200.1.2'} (topdan), iş və xidmətlər ${P ? '200.2' : '1200.2'}, icarə ${P ? '203.2' : '1203.2.1'}.`,
    `Xərclər: ${c.purchases || 0} alış e-qaiməsi və ${c.acts || 0} alış aktı sətir adına görə xərc maddələrinə bölündü (enerji, qaz, yanacaq, rabitə, icarə, təmir, nəqliyyat, sığorta, reklam, bank…).`,
    `Əmək haqqı və işəgötürənin sosial sığorta haqları — ${(data.payroll && data.payroll.declarations) || 0} muzdlu iş (vahid) bəyannaməsindən.`,
    ...(data.notes || []),
    ...(data.prevRead && data.prevRead.length ? [`Oxunan əvvəlki bəyannamələr: ${data.prevRead.map((x) => `${x.year} (№ ${x.reg})`).join(', ')}.`] : []),
    data.filed ? `Diqqət: ${year}-ci il üçün portalda artıq bəyannamə var (№ ${data.filed.reg}). Dəyişiklik üçün «Dəqiqləşdirilmiş» bəyannamə təqdim edilir.` : null,
    'Amortizasiya, nağd xərclər, bank komissiyaları və kassa (POS) satışları portalda e-qaimə kimi görünmür — lazım olsa müvafiq sətirlərə əl ilə yazın.',
  ].filter(Boolean);
  nl.forEach((t) => notes.appendChild(el('li', null, t)));
  $('reset').onclick = () => {
    if (!confirm('Bütün əl ilə edilən dəyişikliklər silinsin və portal məlumatından yığılan dəyərlər bərpa olunsun?')) return;
    data.values = clone(data.auto.values); data.rules = clone(data.auto.rules); data.goods = clone(data.auto.goods); data.edited = {};
    $('relief').checked = data.rules.relief === true; $('loss').checked = true; syncGoodsInputs(); refresh();
  };

  // ------------------------------------------------------------------ Doldur — e-taxes
  $('fill').onclick = async () => {
    const btn = $('fill'); btn.disabled = true; const old = btn.textContent; btn.textContent = 'Doldurulur...';
    try {
      const payload = T.fillPayload(form, data.values, { year });
      await chrome.storage.local.set({ [`ammo_taxrep_fill_${data.type}`]: { payload, at: Date.now(), key } });
      const res = await chrome.runtime.sendMessage({ type: 'AMMO_DECL_FILL', payload });
      if (!res || !res.ok) {
        toast((res && res.error) || 'e-taxes-də açıq bəyannamə tapılmadı. Portalda bəyannaməni (doldurma səhifəsini) açın və yenidən basın.', 'bad', 10000);
      } else {
        const r = res.result || {};
        const lines = [`e-taxes: ${r.filled || 0} xana dolduruldu${r.skipped ? `, ${r.skipped} hesablanan xana portalın özünə saxlanıldı` : ''}.`];
        if (r.missing && r.missing.length) lines.push(`Səhifədə görünməyən sətirlər (${r.missing.length}): ${r.missing.slice(0, 12).join(', ')}${r.missing.length > 12 ? '…' : ''}`);
        if (r.watching) lines.push('Portalda digər bölməyə keçdikdə həmin bölmənin xanaları da avtomatik dolacaq.');
        toast(lines.join('\n'), r.filled ? 'ok' : 'bad', 12000);
      }
    } catch (e) { toast('Xəta: ' + (e && e.message ? e.message : e), 'bad'); }
    finally { btn.disabled = false; btn.textContent = old; }
  };

  // ------------------------------------------------------------------ Excel / XML / çap
  $('xlsx').onclick = () => {
    const H = (v) => ({ v, s: 'h' }), B = (v) => ({ v, s: 'b' }), N = (v) => ({ v: r2(v), s: 'n2' }), BN = (v) => ({ v: r2(v), s: 'bn2' });
    const sheets = [{ name: 'Bölmə 1', autoFilter: false, maxWidth: 70, rows: [[H('№'), H('Göstərici'), H('Məlumat')],
      ...infoRows.map(([n, l]) => [n, l, n === '1' ? M.tin : n === '2' ? M.name : (/fəaliyyət/i.test(l) ? `${M.activityCode || ''} ${M.activityName || ''}` : /dövrü/.test(l) ? String(year) : /meyar/.test(l) ? ['', 'Mikro', 'Kiçik', 'Orta', 'İri'][M.criterion || 1] : /metod/.test(l) ? (M.method === 'cash' ? 'Kassa' : 'Hesablama') : '')])] }];
    form.sections.forEach((sec) => {
      sheets.push({ name: SHORT[sec.id], maxWidth: 90, autoFilter: false, rows: [
        [H('Kod'), ...sec.header.map(H)],
        ...sec.rows.map((r) => { const t = TOTALS.has(r.code); return [t ? B(r.code) : r.code, t ? B(labelOf(sec, r)) : labelOf(sec, r), ...data.values[sec.id][r.code].map((x) => (t ? BN(x) : N(x)))]; }),
      ] });
    });
    if (incLines.length) sheets.push({ name: 'Gəlir sətirləri', maxWidth: 50, rows: [['Tarix', 'Seriya', 'VÖEN', 'Alıcı', 'Mal / xidmət', 'Növ', 'Dəyər (ƏDV-siz)', 'ƏDV'].map(H), ...incLines.map((l) => [fmtD(l[0]), l[1], l[2], l[3], l[4], l[5], N(l[6]), N(l[7])])] });
    if (expLines.length) sheets.push({ name: 'Xərc sətirləri', maxWidth: 50, rows: [['Tarix', 'Seriya', 'VÖEN', 'Təchizatçı', 'Mal / xidmət', 'Kod', 'Xərc maddəsi', 'Dəyər (ƏDV-siz)', 'ƏDV'].map(H), ...expLines.map((l) => [fmtD(l[0]), l[1], l[2], l[3], l[4], l[5], l[6], N(l[7]), N(l[8])])] });
    AMMO_XLSX.download(sheets, `AMMO_${P ? 'Menfeet' : 'Gelir'}_beyanname_${year}${M.tin ? '_' + M.tin : ''}.xlsx`);
  };
  $('xml').onclick = () => {
    const xml = T.profitXml(form, data.values, { ...M, year });
    const blob = new Blob([xml], { type: 'application/xml' });
    const a = el('a', { href: URL.createObjectURL(blob), download: `MENFEET_${M.tin || 'beyanname'}_${year}.xml` });
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
    toast('XML faylı (MENFEET_1 formatı) yükləndi — e-taxes-də «Bəyannaməni fayldan yüklə» ilə istifadə edə bilərsiniz.', 'ok');
  };
  $('print').onclick = () => window.print();

  const setTop = () => document.documentElement.style.setProperty('--toph', document.querySelector('header.top').offsetHeight + 'px');
  setTop(); window.addEventListener('resize', setTop);
  refresh();
})();
