(async function () {
  'use strict';
  const key = new URLSearchParams(location.search).get('key');
  const $ = (id) => document.getElementById(id);
  const data = key ? (await chrome.storage.local.get(key))[key] : null;
  if (!data) { $('title').textContent = 'Nəticə tapılmadı (vaxtı keçib və ya silinib).'; return; }
  document.title = 'AMMO — ' + data.title;
  $('title').textContent = data.title;
  let cur = 0;

  const isNum = (v) => typeof v === 'number' || /^-?[\d\s ]+([.,]\d+)?\s*(₼|%)?$/.test(String(v || '').trim());
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt !== undefined) e.textContent = txt; return e; };
  const fmt = (v, two) => (typeof v === 'number' ? v.toLocaleString('az-AZ', two ? { minimumFractionDigits: 2, maximumFractionDigits: 2 } : { maximumFractionDigits: 4 }) : v);

  function renderTabs() {
    const nav = $('tabs');
    nav.innerHTML = '';
    data.decls.forEach((d, i) => {
      const b = el('button', (i === cur ? 'active' : '') + (d.error ? ' err' : ''), d.label);
      b.onclick = () => { cur = i; renderTabs(); render(); };
      nav.appendChild(b);
    });
  }

  function render() {
    const box = $('content');
    box.innerHTML = '';
    const d = data.decls[cur];
    if (!d) return;
    if (d.error) box.appendChild(el('div', 'error', 'Bu bəyannamə oxuna bilmədi: ' + d.error));
    const multiStep = d.steps.length > 1;
    d.steps.forEach((stp) => {
      if (multiStep && stp.name) box.appendChild(el('h2', 'step', stp.name));
      stp.sections.forEach((s) => {
        box.appendChild(el('h3', null, s.title || stp.name));
        if (s.empty) { box.appendChild(el('div', 'empty', 'Bu bölmə üçün məlumat yoxdur')); return; }
        const wrap = el('div', 'wrap');
        const t = el('table', s.merge3 ? 'wide' : null);
        if (s.header.length) {
          const th = t.createTHead();
          s.header.forEach((hr, hi) => {
            const tr = th.insertRow();
            hr.forEach((c, ci) => {
              if (s.merge3 && hi > 0 && ci === 0 && !c.t) return; // covered by the row-spanning cells of the first row
              const x = el('th', null, c.t);
              if (c.span > 1) x.colSpan = c.span;
              if (s.merge3 && hi === 0 && ci < 5) x.rowSpan = s.header.length;
              tr.appendChild(x);
            });
          });
        }
        const tb = t.createTBody();
        s.rows.forEach((r) => { const tr = tb.insertRow(); r.forEach((v, i) => { const td = tr.insertCell(); td.textContent = fmt(v, s.merge3); if (i > 0 && typeof v === 'number') td.className = 'n'; }); });
        if (s.totals) { const tr = tb.insertRow(); tr.className = 'total'; s.totals.forEach((v) => { const td = tr.insertCell(); td.textContent = fmt(v, s.merge3); if (typeof v === 'number') td.className = 'n'; }); }
        wrap.appendChild(t);
        box.appendChild(wrap);
      });
    });
    if (!d.steps.length && !d.error) box.appendChild(el('div', 'empty', 'Bu bəyannamədə cədvəl tapılmadı'));
  }

  function tsv() {
    const d = data.decls[cur];
    const lines = [d.label, ''];
    d.steps.forEach((stp) => stp.sections.forEach((s) => {
      lines.push(s.title || stp.name);
      s.header.forEach((hr) => lines.push(hr.flatMap((c) => [c.t, ...Array(Math.max(0, c.span - 1)).fill('')]).join('\t')));
      if (s.empty) lines.push('Bu bölmə üçün məlumat yoxdur');
      else s.rows.forEach((r) => lines.push(r.map((v) => String(v ?? '').replace(/[\t\n]/g, ' ')).join('\t')));
      if (s.totals) lines.push(s.totals.join('\t'));
      lines.push('');
    }));
    return lines.join('\n');
  }

  $('copy').onclick = async () => {
    try { await navigator.clipboard.writeText(tsv()); $('copied').hidden = false; setTimeout(() => { $('copied').hidden = true; }, 3000); }
    catch (e) { alert('Kopyalamaq alınmadı: ' + e.message); }
  };
  $('print').onclick = () => window.print();
  $('xlsx').onclick = () => AMMO_XLSX.download(AMMO_DECL_XLSX.sheets(data), `${data.fileBase}.xlsx`);
  renderTabs();
  render();
})();
