/* AMMO — Sənəd hazırla: interfeys (v1.14) */
const S = globalThis.SENED, X = globalThis.SENED_EXPORT, IMG = globalThis.SENED_IMG, I = globalThis.SENED_IMPORT;
const BUILTIN = globalThis.SENED_TEMPLATES, CLAUSES = globalThis.SENED_CLAUSES;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const clone = (o) => JSON.parse(JSON.stringify(o));
function toast(t) { const x = $('#toast'); x.textContent = t; x.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => x.classList.remove('show'), 3600); }

// ------------------------------------------------------------------ yaddaş
const K = { custom: 'sened_custom', parties: 'sened_parties', docs: 'sened_docs', settings: 'sened_settings' };
const st = { view: 'home', doc: null, tab: 'parties', custom: [], parties: [], docs: [], settings: {}, q: '' };
const DEF_SETTINGS = { sigRect: { x: 0.03, y: 0.72, w: 0.38, h: 0.25 }, sens: 55, city: 'Bakı şəhəri', counters: {}, ourParty: '' };
async function load() {
  const r = await chrome.storage.local.get(Object.values(K));
  st.custom = r[K.custom] || []; st.parties = r[K.parties] || []; st.docs = r[K.docs] || [];
  st.settings = { ...DEF_SETTINGS, ...(r[K.settings] || {}) };
}
const save = async (...keys) => { const o = {}; for (const k of keys) o[K[k]] = st[k]; await chrome.storage.local.set(o); $('#savedTxt').textContent = 'Yadda saxlanıldı · ' + new Date().toTimeString().slice(0, 5); };
let saveT = null;
function autosave() {
  clearTimeout(saveT);
  saveT = setTimeout(async () => {
    const d = st.doc; if (!d) return;
    d.updatedAt = new Date().toISOString();
    const i = st.docs.findIndex((x) => x.id === d.id);
    if (i >= 0) st.docs[i] = clone(d); else st.docs.unshift(clone(d));
    await save('docs'); counts();
  }, 500);
}
const allTemplates = () => [...BUILTIN, ...st.custom];
function fixParty(P) {
  const E = S.EMPTY_PARTY();
  const o = { ...E, ...(P || {}) }; o.person = { ...E.person, ...((P && P.person) || {}) }; o.raw = { ...E.raw, ...((P && P.raw) || {}) };
  return o;
}

// ------------------------------------------------------------------ yeni sənəd
function newDoc(t, extra = {}) {
  const y = new Date().getFullYear();
  const pre = t.prefix || 'MQ';
  const n = (st.settings.counters[`${pre}-${y}`] || 0) + 1;
  st.settings.counters[`${pre}-${y}`] = n; save('settings');
  const our = st.parties.find((p) => p.id === st.settings.ourParty);
  const A = our ? fixParty(clone(our.data)) : S.EMPTY_PARTY();
  const B = S.EMPTY_PARTY(); if (t.typeB === 'physical') B.type = 'physical';
  const values = {}; for (const f of t.fields || []) if (f.def != null) values[f.key] = f.def;
  return {
    id: uid(), templateId: t.id, name: `${t.name} — ${S.fmtDate(S.ymd())}`, title: t.title, subtitle: t.subtitle || '', number: `${pre}-${y}/${String(n).padStart(3, '0')}`,
    date: S.ymd(), city: st.settings.city, currency: 'AZN', vat: '', extra: '', mainMoney: t.mainMoney || '', roles: { ...t.roles }, parties: { A, B },
    fields: clone(t.fields || []), values, sections: clone(t.sections || []),
    header: t.header !== false, preamble: t.preamble !== false, requisites: t.requisites !== false, numbering: t.numbering !== false,
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), ...extra
  };
}
function openDoc(d) { d.parties.A = fixParty(d.parties.A); d.parties.B = fixParty(d.parties.B); st.doc = d; st.view = 'edit'; st.tab = 'parties'; render(); }

// ------------------------------------------------------------------ naviqasiya
function counts() { $('#docCount').textContent = st.docs.length || ''; $('#partyCount').textContent = st.parties.length || ''; }
function go(v) { st.view = v; if (v !== 'edit') st.doc = null; render(); window.scrollTo(0, 0); }
$$('#topnav [data-view]').forEach((b) => b.onclick = () => go(b.dataset.view));
function render() {
  $$('#topnav [data-view]').forEach((b) => b.classList.toggle('on', b.dataset.view === st.view || (st.view === 'edit' && b.dataset.view === 'home')));
  counts();
  ({ home: viewHome, edit: viewEdit, docs: viewDocs, parties: viewParties })[st.view]();
}

// ================================================================== ŞABLONLAR
function viewHome() {
  const q = S.lowerAz(st.q);
  const list = allTemplates().filter((t) => !q || S.lowerAz(`${t.name} ${t.desc || ''} ${t.cat || ''}`).includes(q));
  const cats = [...new Set(list.map((t) => t.custom ? 'Mənim şablonlarım' : t.cat))];
  const recent = st.docs.slice().sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt))).slice(0, 6);
  $('#app').innerHTML = `<div class="hero">
    <div class="hero-main"><h1>Müqavilə hazırla</h1><p>Şablonu seçin və ya öz müqavilənizi yükləyin. Sol və sağ tərəfə vəsiqəni, şirkət məlumatlarını və bank rekvizitlərini olduğu kimi yapışdırın — hamısı avtomatik oxunub yerinə yazılır. İmza vəsiqədən götürülür, möhür imzanın üstünə qoyulur. Word və PDF yükləyin.</p><input id="tq" placeholder="Axtar: icarə, alqı-satqı, xidmət…" value="${esc(st.q)}"></div>
    <label class="drop" id="drop"><input type="file" id="tfile" accept=".docx,.doc,.pdf,.txt" hidden><div><div class="ic">📄</div><b>Öz müqavilənizi yükləyin</b><br><small>Word (.docx, .doc), PDF və ya mətn. Strukturu avtomatik təyin olunur: başlıq, nömrə, tarix, tərəflərin rolları, bölmə və bəndlər, məbləğ və tarixlər. Rekvizit hissəsindən tərəflərin məlumatları da götürülür.</small></div></label></div>
    ${recent.length ? `<div class="cat-h">Son sənədlər</div><div class="tgrid">${recent.map((d) => `<button class="tcard" data-doc="${d.id}"><span class="ti">🖋️</span><span><b>${esc(d.name)}</b><small>${esc(d.number)} · ${esc(S.partyName(fixParty(d.parties.B)))}</small></span></button>`).join('')}</div>` : ''}
    ${cats.map((c) => `<div class="cat-h">${esc(c)}</div><div class="tgrid">${list.filter((t) => (t.custom ? 'Mənim şablonlarım' : t.cat) === c).map((t) => `<div class="tcard" data-t="${t.id}"><span class="ti">${t.icon || '📄'}</span><span><b>${esc(t.name)}</b><small>${esc(t.desc || `${(t.sections || []).length} bölmə · ${t.roles.A} / ${t.roles.B}`)}</small></span>${t.custom ? `<button class="x" data-del="${t.id}" title="Şablonu sil">✕</button>` : ''}</div>`).join('')}</div>`).join('') || '<div class="empty">Tapılmadı</div>'}`;
  const tq = $('#tq'); tq.oninput = () => { st.q = tq.value; const p = tq.selectionStart; viewHome(); const n = $('#tq'); n.focus(); n.setSelectionRange(p, p); };
  $$('[data-t]').forEach((c) => c.onclick = (e) => { if (e.target.closest('[data-del]')) return; const t = allTemplates().find((x) => x.id === c.dataset.t); openDoc(newDoc(t)); autosave(); });
  $$('[data-del]').forEach((b) => b.onclick = async (e) => { e.stopPropagation(); if (!confirm('Bu şablon silinsin?')) return; st.custom = st.custom.filter((x) => x.id !== b.dataset.del); await save('custom'); render(); });
  $$('[data-doc]').forEach((c) => c.onclick = () => openDoc(clone(st.docs.find((d) => d.id === c.dataset.doc))));
  const drop = $('#drop'), inp = $('#tfile');
  inp.onchange = () => { importFile(inp.files[0]); inp.value = ''; };
  drop.ondragover = (e) => { e.preventDefault(); drop.classList.add('over'); };
  drop.ondragleave = () => drop.classList.remove('over');
  drop.ondrop = (e) => { e.preventDefault(); drop.classList.remove('over'); importFile(e.dataTransfer.files[0]); };
}

// ------------------------------------------------------------------ fayl idxalı
async function fileParas(file) {
  const name = file.name.toLowerCase();
  if (name.endsWith('.txt')) return (await file.text()).split(/\r?\n/);
  if (name.endsWith('.docx')) {
    const files = await AMMO_XLSX_READ.unzip(await file.arrayBuffer(), (n) => n === 'word/document.xml' || n === 'word/styles.xml');
    const td = new TextDecoder();
    return I.docxParagraphs(td.decode(files['word/document.xml']), files['word/styles.xml'] ? td.decode(files['word/styles.xml']) : '');
  }
  if (name.endsWith('.doc')) return SENED_MSDOC.docText(await file.arrayBuffer());
  if (name.endsWith('.pdf')) {
    const pdfjs = await import('../lib/pdfjs/pdf.min.mjs');
    pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdfjs/pdf.worker.min.mjs');
    const pdf = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
    const lines = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i); const tc = await page.getTextContent();
      let lastY = null, line = '', lastX = null;
      for (const it of tc.items) {
        const y = Math.round(it.transform[5]), x = it.transform[4];
        if (lastY != null && Math.abs(y - lastY) > 3) { lines.push(line); line = ''; lastX = null; }
        const gap = lastX != null && x - lastX > 60 ? '\t' : '';
        line += gap || (line && !line.endsWith(' ') && !it.str.startsWith(' ') ? ' ' : '') ; line += it.str; lastY = y; lastX = x + (it.width || 0);
        if (it.hasEOL) { lines.push(line); line = ''; lastY = null; lastX = null; }
      }
      if (line) lines.push(line);
      lines.push('');
    }
    const merged = []; for (const l of lines) { const t = l.trim(); if (!t) { merged.push(''); continue; } const prev = merged[merged.length - 1]; if (prev && !prev.includes('\t') && !t.includes('\t') && !/[.:;!?]$/.test(prev) && /^[a-zəöüığşç(«"“]/.test(t)) merged[merged.length - 1] = prev + ' ' + t; else merged.push(t); }
    return merged;
  }
  throw new Error('Yalnız .docx, .doc, .pdf və .txt faylları dəstəklənir');
}
async function importFile(file) {
  if (!file) return;
  try {
    toast('Fayl oxunur, struktur təyin olunur…');
    const paras = await fileParas(file);
    if (!paras.some((p) => String(typeof p === 'string' ? p : p.t).trim())) throw new Error('Faylda mətn tapılmadı (skan edilmiş PDF-dirsə, Word variantını yükləyin)');
    const r = I.importParagraphs(paras, file.name);
    const roles = { A: r.roles[0] || 'Birinci tərəf', B: r.roles[1] || 'İkinci tərəf' };
    const fields = r.fields.map((f) => ({ ...f, def: r.values[f.key] != null ? r.values[f.key] : f.def }));
    const t = { id: 'c_' + uid(), custom: true, name: file.name.replace(/\.[^.]+$/, ''), icon: '📄', cat: 'Mənim şablonlarım', desc: `${r.stats.sections} bölmə · ${r.stats.clauses} bənd · ${roles.A} / ${roles.B}`, title: r.title, subtitle: r.subtitle, prefix: 'MQ', roles, fields, sections: r.sections, mainMoney: r.mainMoney || '', header: true, preamble: true, requisites: true, sourceFile: file.name, importedAt: new Date().toISOString() };
    st.custom.push(t); await save('custom');
    const extra = {};
    if (r.number) extra.number = r.number; if (r.date) extra.date = r.date; if (r.city) extra.city = r.city; if (r.currency) extra.currency = r.currency;
    const d = newDoc(t, extra);
    const found = [];
    for (const [k, src] of [['A', r.partyA], ['B', r.partyB]]) {
      if (!src) continue;
      const P = S.EMPTY_PARTY(); I.applyParty(P, src); if (!P.type) P.type = 'legal';
      d.parties[k] = P; if (S.partyName(P).replace(/[_\s“”]/g, '')) found.push(S.partyName(P));
    }
    d.importInfo = { file: file.name, sections: r.stats.sections, clauses: r.stats.clauses, fields: r.stats.fields, roles: [roles.A, roles.B], parties: found, preamble: !!r.preamble, rek: !!r.rekText };
    openDoc(d); autosave();
    toast(`Struktur tapıldı: ${r.stats.sections} bölmə, ${r.stats.clauses} bənd — şablon kimi yadda saxlanıldı`);
  } catch (e) { console.error(e); toast('Fayl oxunmadı: ' + e.message); }
}

// ================================================================== REDAKTOR
const TABS = [['parties', '1. Tərəflər'], ['terms', '2. Məbləğ və şərtlər'], ['text', '3. Mətn'], ['doc', '4. Sənəd']];
function viewEdit() {
  const d = st.doc;
  $('#app').innerHTML = `<div class="ed-top"><button class="btn ghost" id="back">← Şablonlar</button><input class="name" id="dname" value="${esc(d.name)}"><button class="btn ghost" id="asTpl" title="Bu sənədin strukturunu yeni şablon kimi saxla">☆ Şablon kimi saxla</button><button class="btn soft" id="dlWord">⬇ Word</button><button class="btn gold" id="dlPdf">⬇ PDF</button></div>
    <div class="steps">${TABS.map(([k, l]) => `<button class="step ${st.tab === k ? 'on' : ''}" data-tab="${k}">${l}</button>`).join('')}</div>
    <div id="work"></div>`;
  $('#back').onclick = () => go('home');
  $('#dname').oninput = (e) => { d.name = e.target.value; autosave(); };
  $$('[data-tab]').forEach((b) => b.onclick = () => { st.tab = b.dataset.tab; $$('[data-tab]').forEach((x) => x.classList.toggle('on', x === b)); work(); });
  $('#dlWord').onclick = () => exportDoc('docx');
  $('#dlPdf').onclick = () => exportDoc('pdf');
  $('#asTpl').onclick = saveAsTemplate;
  work();
}
function work() {
  if (st.tab === 'parties') { $('#work').innerHTML = '<div id="pp"></div>'; viewPartiesTab(); return; }
  $('#work').innerHTML = `<div class="ed"><aside class="side"><div class="side-b" id="sideB"></div></aside><section><div class="paper-wrap"><article class="paper" id="paper"></article></div></section></div>`;
  side(); preview();
}
const fname = () => (st.doc.name || 'muqavile').replace(/[\\/:*?"<>|]+/g, ' ').trim();
async function exportDoc(kind) {
  try {
    const c = S.compose(st.doc);
    const miss = [...JSON.stringify(c.sections).matchAll(/_{6,}/g)].length + [st.doc.parties.A, st.doc.parties.B].filter((P) => !S.partyName(P).replace(/[_\s“”F/Ş]/g, '')).length;
    if (miss) toast(`Diqqət: ${miss} doldurulmamış yer var — sənəd yenə də yüklənir`);
    if (kind === 'docx') await X.docx(c, fname() + '.docx'); else await X.pdf(c, fname() + '.pdf');
    st.doc.exported = (st.doc.exported || 0) + 1; autosave();
    if (!miss) toast(kind === 'docx' ? 'Word faylı yükləndi' : 'PDF yükləndi');
  } catch (e) { console.error(e); toast('Xəta: ' + e.message); }
}
async function saveAsTemplate() {
  const d = st.doc; const name = prompt('Şablonun adı:', d.name.replace(/ — .*$/, '')); if (!name) return;
  const fields = clone(d.fields).map((f) => ({ ...f, def: d.values[f.key] ?? f.def }));
  st.custom.push({ id: 'c_' + uid(), custom: true, name, icon: '⭐', cat: 'Mənim şablonlarım', desc: 'Öz şablonum', title: d.title, subtitle: d.subtitle, prefix: 'MQ', roles: { ...d.roles }, fields, sections: clone(d.sections), mainMoney: d.mainMoney, header: d.header, preamble: d.preamble, requisites: d.requisites });
  await save('custom'); toast('Şablon yadda saxlanıldı — “Şablonlar” bölməsində “Mənim şablonlarım”');
}

// ------------------------------------------------------------------ önizləmə
let prevT = null;
function preview() { clearTimeout(prevT); prevT = setTimeout(renderPaper, 120); }
function reqTableHtml(c) {
  const R = c.req;
  return `<div class="req-h">TƏRƏFLƏRİN REKVİZİTLƏRİ VƏ İMZALARI</div><table class="rq"><tr>${R.roles.map((r) => `<th>“${esc(r)}”</th>`).join('')}</tr>
    <tr>${R.names.map((n) => `<td><b>${esc(n)}</b></td>`).join('')}</tr>
    ${R.rows.map(([l, a, b]) => `<tr>${[a, b].map((v) => `<td><b>${esc(l)}:</b> ${v ? esc(v) : '<span class="muted">—</span>'}</td>`).join('')}</tr>`).join('')}
    <tr class="sgrow">${c.parties.map((p) => `<td><div class="sigline"><span class="lbl">İmza:</span><span class="ln"></span>${p.sig ? `<img class="sig" src="${p.sig}">` : ''}${p.seal ? `<img class="seal" src="${p.seal}">` : ''}</div><div class="signer">${esc(p.signer)}</div>${p.legal ? '<div class="small">M.Y.</div>' : ''}</td>`).join('')}</tr></table>`;
}
function renderPaper() {
  const el = $('#paper'); if (!el) return;
  const c = S.compose(st.doc);
  const hi = (t) => esc(t).replace(/_{6,}/g, (m) => `<span class="blank">${m}</span>`);
  el.innerHTML = `${c.header ? `<h1>${esc(c.title)}</h1>${c.subtitle ? `<div class="subt">${esc(c.subtitle)}</div>` : ''}${c.number ? `<div class="no">№ ${esc(c.number)}</div>` : ''}<div class="cd"><span>${esc(c.city)}</span><span>${esc(c.dateText)}</span></div>` : ''}
    ${c.preamble ? `<p class="pre">${hi(c.preamble)}</p>` : ''}
    ${c.sections.map((s) => `${s.title ? `<h2>${esc(s.title)}</h2>` : ''}${s.clauses.map((cl) => `<p class="${cl.no ? '' : 'pre'} ${cl.sub ? 'sub' : ''}">${cl.no ? esc(cl.no) + ' ' : ''}${hi(cl.text)}</p>`).join('')}`).join('')}
    ${c.requisites ? reqTableHtml(c) : ''}`;
}

// ================================================================== 1. TƏRƏFLƏR (sol və sağ)
const TYPES = [['legal', 'Hüquqi şəxs'], ['fs', 'Fərdi sahibkar'], ['physical', 'Fiziki şəxs']];
function chip(label, v) { return `<span class="chip ${v ? 'ok' : ''}">${v ? '✓ ' : ''}${esc(label)}${v ? `: <b>${esc(v)}</b>` : ''}</span>`; }
function idChips(P) { const p = P.person; return [chip('Soyad', p.last), chip('Ad', p.first), chip('Ata adı', p.father ? S.titleAz(p.father) + (p.gender === 'f' ? ' qızı' : ' oğlu') : ''), chip('FİN', p.fin && S.upperAz(p.fin)), chip('Sənəd', p.idNumber ? `${p.idSeries || ''} ${p.idNumber}`.trim() : '')].join(''); }
function coChips(P) {
  if (P.type === 'fs') return [chip('VÖEN', P.voen), chip('Ünvan', P.address), chip('Telefon', P.phone)].join('');
  return [chip('Şirkət', P.company ? `“${P.company}” ${P.form || ''}`.trim() : ''), chip('VÖEN', P.voen), chip('Ünvan', P.address), chip('Rəhbər', S.personName(P.person) ? `${P.dirTitle || 'Direktor'} ${S.personName(P.person)}` : ''), P.phone ? chip('Tel', P.phone) : ''].join('');
}
function bankChips(P) { return [chip('Bank', P.bank), chip('Kod', P.bankCode), chip('Bankın VÖEN-i', P.bankVoen), chip('M/h', P.corr), chip('SWIFT', P.swift), chip('H/h', P.iban)].join(''); }

function viewPartiesTab() {
  const d = st.doc, info = d.importInfo;
  $('#pp').innerHTML = `${info && !info.closed ? `<div class="alert ok imp"><b>“${esc(info.file)}” oxundu:</b> ${info.sections} bölmə, ${info.clauses} bənd, ${info.fields} sahə; rollar — “${esc(info.roles[0])}” və “${esc(info.roles[1])}”${info.parties.length ? `; tərəflər: ${info.parties.map(esc).join(' və ')}` : ''}. Yeni tərəfləri aşağıda yapışdırın — köhnə məlumatlar avtomatik əvəzlənəcək. <button class="ib" id="impX" title="Bağla">✕</button></div>` : ''}
    <div class="pcols">${partyCol('A')}<button class="swap" id="swap" title="Tərəflərin yerini dəyiş">⇄</button>${partyCol('B')}</div>
    <div class="next"><button class="btn primary" id="toTerms">Növbəti: Məbləğ və şərtlər →</button></div>`;
  const ix = $('#impX'); if (ix) ix.onclick = () => { info.closed = true; autosave(); viewPartiesTab(); };
  $('#swap').onclick = () => { [d.parties.A, d.parties.B] = [d.parties.B, d.parties.A]; autosave(); viewPartiesTab(); toast('Tərəflərin yeri dəyişdi (rollar yerində qaldı)'); };
  $('#toTerms').onclick = () => { st.tab = 'terms'; viewEdit(); };
  ['A', 'B'].forEach(bindCol);
}
function partyCol(k) {
  const d = st.doc, P = d.parties[k], t = P.type;
  const raw = P.raw || (P.raw = { id: '', company: '', bank: '' });
  const ph = {
    id: t === 'legal' ? 'Direktorun vəsiqəsi — mətni yapışdırın, məs.:\nSoyadı: Məmmədov  Adı: Elvin  Atasının adı: Ramiz oğlu\nFİN: 5XK2P9L  AZE 14570704' : 'Mətni yapışdırın, məs.:\nQuliyev Davud Tanrıqulu oğlu, FİN 2MWCQE9, ş/v AA1580528, doğum tarixi 30.05.1970',
    company: t === 'fs' ? 'Fərdi sahibkarın məlumatları, məs.:\nF/Ş Baxışova Fatma Yusif qızı, VÖEN 5502194552, ünvan: İmişli ş., H.Əliyev pr. 144, tel 050 555 44 33' : 'Şirkətin məlumatlarını olduğu kimi yapışdırın (VÖEN çıxarışı, e-taxes, köhnə müqavilə), məs.:\n“AMMO KONSALTİNQ” MMC, VÖEN 1405678901, hüquqi ünvan: Bakı ş., Nəsimi r., Azadlıq pr. 12, direktor Həsənov Kamran Əli oğlu',
    bank: 'Bank rekvizitlərini yapışdırın, məs.:\nBank: Kapital Bank ASC, kod 200026, VÖEN 9900003611\nM/h: AZ37NABZ01350100000000001944  SWIFT: AIIBAZ2X\nH/h: AZ15AIIB400600G9449636921114'
  };
  const box = (kind, icon, title, sub, chipsHtml, extra = '') => `<div class="paste" data-kind="${kind}"><div class="paste-h"><span class="pi">${icon}</span><div><b>${title}</b><small>${sub}</small></div><button class="ib clr" data-clr="${kind}" title="Təmizlə">✕</button></div>
    <textarea data-raw="${kind}" rows="3" placeholder="${esc(ph[kind])}">${esc(raw[kind] || '')}</textarea>${extra}<div class="chips" data-chips="${kind}">${chipsHtml}</div></div>`;
  const idImgs = `<div class="idimgs">${['idFront', 'idBack'].map((slot) => `<label class="idmini" data-id="${slot}">${P[slot] ? `<img src="${P[slot]}"><button class="x" data-idx="${slot}">✕</button>` : `<span>${slot === 'idFront' ? '📇 Ön üz (imza)' : '🔁 Arxa üz'}</span>`}<input type="file" accept="image/*" hidden></label>`).join('')}<div class="ocr-st" data-ocr></div></div>`;
  const sealOk = t !== 'physical';
  return `<div class="pcol" data-party="${k}">
    <div class="pcol-h"><span class="side-lbl">${k === 'A' ? 'SOL TƏRƏF' : 'SAĞ TƏRƏF'}</span><input class="role" data-role="${k}" value="${esc(d.roles[k])}" title="Tərəfin rolu (müqavilədə belə yazılacaq)"></div>
    <div class="pcol-t"><span class="seg">${TYPES.map(([v, l]) => `<button data-type="${v}" class="${t === v ? 'on' : ''}">${l}</button>`).join('')}</span>
      <select data-book title="Tərəflər kitabından seç"><option value="">📒 Kitabdan seç…</option>${st.parties.map((x) => `<option value="${x.id}">${esc(x.label)}${x.id === st.settings.ourParty ? ' ★' : ''}</option>`).join('')}</select></div>
    <div class="pname">${esc(S.partyName(P))}</div>
    ${t !== 'physical' ? box('company', t === 'fs' ? '🧾' : '🏢', t === 'fs' ? 'Fərdi sahibkarın məlumatları' : 'Şirkət məlumatları', 'kor (xam) mətni yapışdırın — ad, VÖEN, ünvan, rəhbər avtomatik', coChips(P)) : ''}
    ${box('id', '🪪', t === 'legal' ? 'Direktorun şəxsiyyət vəsiqəsi' : 'Şəxsiyyət vəsiqəsi', 'mətni yapışdırın və ya şəklini atın — imza vəsiqədən götürülür', idChips(P), idImgs)}
    ${box('bank', '🏦', 'Bank rekvizitləri', 'bank, kod, VÖEN, M/h, SWIFT, H/h — hansı formada olursa olsun', bankChips(P))}
    <div class="paste signp"><div class="paste-h"><span class="pi">✍️</span><div><b>İmza${sealOk ? ' və möhür' : ''}</b><small>${sealOk ? 'möhürü əlavə edən kimi imzanın üstünə qoyulur' : 'vəsiqənin ön üzündən avtomatik'}</small></div></div>
      <div class="sgrid"><div class="sigprev">${P.sig ? `<img class="s" src="${P.sig}">` : '<span class="muted small">İmza yoxdur</span>'}${sealOk && P.seal ? `<img class="m" src="${P.seal}">` : ''}<span class="ln"></span></div>
      <div class="sacts"><button class="btn sm soft" data-sigcrop ${P.idFront ? '' : 'disabled title="Əvvəlcə vəsiqənin ön üzünü əlavə edin"'}>✂ Vəsiqədən</button><label class="btn sm ghost">🖼 İmza şəkli<input type="file" accept="image/*" data-sigfile hidden></label>${sealOk ? `<label class="btn sm ${P.seal ? 'ghost' : 'primary'}">🔵 Möhür${P.seal ? 'ü dəyiş' : ' əlavə et'}<input type="file" accept="image/*" data-sealfile hidden></label>` : ''}${P.sig ? '<button class="btn sm danger" data-sigdel>✕ imza</button>' : ''}${sealOk && P.seal ? '<button class="btn sm danger" data-sealdel>✕ möhür</button>' : ''}</div></div></div>
    <details class="full"><summary>✎ Bütün sahələri yoxla / düzəlt</summary>${fullForm(k)}</details>
    <div class="pfoot"><button class="btn sm ghost" data-tobook>📒 Kitaba yadda saxla</button>${k === 'A' ? '<button class="btn sm ghost" data-our title="Yeni müqavilələrdə bu tərəf avtomatik yazılsın">★ Bizim şirkət</button>' : ''}<button class="btn sm ghost" data-reset title="Bu tərəfi təmizlə">↺ Təmizlə</button></div>
  </div>`;
}
function fullForm(k) {
  const P = st.doc.parties[k], p = P.person, t = P.type;
  const inp = (path, label, val, type = 'text', extra = '') => `<label class="f"><span>${label}</span><input data-p="${path}" type="${type}" value="${esc(val ?? '')}" ${extra}></label>`;
  return `${t === 'legal' ? `<div class="row">${inp('company', 'Şirkətin adı', P.company)}<label class="f"><span>Forma</span><select data-p="form">${['MMC', 'ASC', 'QSC', 'İB', 'Filial', ''].map((x) => `<option ${P.form === x ? 'selected' : ''} value="${x}">${x || '—'}</option>`).join('')}</select></label></div>` : ''}
    ${t !== 'physical' ? `<div class="row">${inp('voen', 'VÖEN', P.voen, 'text', 'maxlength="10"')}${inp('address', 'Hüquqi ünvan', P.address)}</div>` : ''}
    ${t === 'legal' ? `<div class="row">${inp('dirTitle', 'Rəhbərin vəzifəsi', P.dirTitle)}${inp('basis', 'Hansı sənəd əsasında', P.basis)}</div>` : ''}
    <div class="sub-h">${t === 'legal' ? 'Direktor' : 'Şəxs'}</div>
    <div class="row">${inp('person.last', 'Soyad', p.last)}${inp('person.first', 'Ad', p.first)}${inp('person.father', 'Ata adı', p.father)}<label class="f"><span>Cins</span><select data-p="person.gender"><option value="m" ${p.gender !== 'f' ? 'selected' : ''}>Kişi (oğlu)</option><option value="f" ${p.gender === 'f' ? 'selected' : ''}>Qadın (qızı)</option></select></label></div>
    <div class="row">${inp('person.fin', 'FİN', p.fin, 'text', 'maxlength="7" style="text-transform:uppercase"')}<label class="f"><span>Seriya</span><select data-p="person.idSeries">${['AZE', 'AA', 'MYI', 'DYI', ''].map((x) => `<option ${p.idSeries === x ? 'selected' : ''} value="${x}">${x || '—'}</option>`).join('')}</select></label>${inp('person.idNumber', 'Nömrə', p.idNumber)}</div>
    ${t === 'physical' ? `<div class="row">${inp('person.idIssuer', 'Verən orqan', p.idIssuer)}${inp('person.idDate', 'Verilmə tarixi', p.idDate, 'date')}${inp('person.address', 'Qeydiyyat ünvanı', p.address)}</div>` : ''}
    <div class="row">${inp('phone', 'Telefon', P.phone)}${inp('email', 'E-poçt', P.email)}</div>
    <div class="sub-h">Bank</div>
    <div class="row">${inp('bank', 'Bank', P.bank)}${inp('bankCode', 'Kod', P.bankCode)}${inp('bankVoen', 'Bankın VÖEN-i', P.bankVoen)}</div>
    <div class="row">${inp('corr', 'M/h', P.corr)}${inp('swift', 'SWIFT', P.swift)}${inp('iban', 'H/h (IBAN)', P.iban)}</div>`;
}
function setPath(obj, path, v) { const k = path.split('.'); let o = obj; while (k.length > 1) o = o[k.shift()]; o[k[0]] = v; }
function refreshCol(k, refocus) {
  const P = st.doc.parties[k], col = $(`[data-party="${k}"]`); if (!col) return;
  const ae = document.activeElement, kind = ae && ae.dataset && ae.dataset.raw, pos = kind ? [ae.selectionStart, ae.selectionEnd] : null;
  const open = $('details.full', col).open;
  col.outerHTML = partyCol(k);
  bindCol(k);
  const nc = $(`[data-party="${k}"]`); $('details.full', nc).open = open;
  if (refocus !== false && kind) { const ta = $(`[data-raw="${kind}"]`, nc); if (ta) { ta.focus(); ta.setSelectionRange(pos[0], pos[1]); } }
}
function parseInto(k, kind, text) {
  const P = st.doc.parties[k];
  const before = P.type;
  if (kind === 'id') {
    const r = I.parseIdAny(text);
    for (const key of ['last', 'first', 'father', 'gender', 'fin', 'idSeries', 'idNumber', 'idDate', 'idIssuer', 'birth']) if (r[key]) P.person[key] = key === 'fin' ? S.upperAz(r[key]) : r[key];
    if (r.address && P.type === 'physical') P.person.address = r.address;
  } else if (kind === 'company') {
    const r = I.parseCompanyText(text);
    if (r.type) P.type = r.type;
    for (const key of ['company', 'form', 'voen', 'address', 'phone', 'email', 'dirTitle', 'basis']) if (r[key]) P[key] = r[key];
    if (r.person && (r.person.last || r.person.first)) for (const [key, v] of Object.entries(r.person)) if (v && !['ini', 'weak'].includes(key)) P.person[key] = v;
    const b = I.parseBankText(text); if (b.iban || b.bank) for (const [key, v] of Object.entries(b)) if (v && !P[key]) P[key] = v;
  } else if (kind === 'bank') {
    const b = I.parseBankText(text);
    for (const [key, v] of Object.entries(b)) if (v) P[key] = v;
  }
  if (before !== P.type) toast(`${TYPES.find(([v]) => v === P.type)[1]} kimi tanındı`);
  return before !== P.type;
}
function bindCol(k) {
  const d = st.doc, col = $(`[data-party="${k}"]`), P = d.parties[k];
  $$('[data-raw]', col).forEach((ta) => {
    const kind = ta.dataset.raw;
    let t = null;
    const run = () => { P.raw[kind] = ta.value; const typeChanged = parseInto(k, kind, ta.value); autosave(); if (typeChanged) refreshCol(k); else { const c = $(`[data-chips="${kind}"]`, col); c.innerHTML = kind === 'id' ? idChips(P) : kind === 'company' ? coChips(P) : bankChips(P); $('.pname', col).textContent = S.partyName(P); syncForm(k); } };
    ta.oninput = () => { clearTimeout(t); t = setTimeout(run, 350); };
    ta.onpaste = () => setTimeout(run, 30);
    if (kind === 'id') { ta.ondragover = (e) => e.preventDefault(); ta.ondrop = (e) => { const f = e.dataTransfer.files[0]; if (f && /^image\//.test(f.type)) { e.preventDefault(); takeId(k, P.idFront ? 'idBack' : 'idFront', f); } }; }
  });
  $$('[data-clr]', col).forEach((b) => b.onclick = () => { P.raw[b.dataset.clr] = ''; const ta = $(`[data-raw="${b.dataset.clr}"]`, col); ta.value = ''; ta.focus(); autosave(); });
  $$('[data-p]', col).forEach((el) => el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => { let v = el.value; if (el.dataset.p === 'person.fin') v = v.toUpperCase(); setPath(P, el.dataset.p, v); autosave(); $('.pname', col).textContent = S.partyName(P); }));
  $('[data-role]', col).oninput = (e) => { d.roles[k] = e.target.value; autosave(); };
  $$('[data-type]', col).forEach((b) => b.onclick = () => { P.type = b.dataset.type; autosave(); refreshCol(k, false); });
  $('[data-book]', col).onchange = (e) => { const x = st.parties.find((q) => q.id === e.target.value); if (!x) return; d.parties[k] = fixParty(clone(x.data)); autosave(); refreshCol(k, false); toast(`${x.label} əlavə olundu`); };
  for (const slot of ['idFront', 'idBack']) {
    const lab = $(`[data-id="${slot}"]`, col), fi = $('input', lab);
    fi.onchange = () => takeId(k, slot, fi.files[0]);
    lab.ondragover = (e) => e.preventDefault(); lab.ondrop = (e) => { e.preventDefault(); takeId(k, slot, e.dataTransfer.files[0]); };
  }
  $$('[data-idx]', col).forEach((b) => b.onclick = (e) => { e.preventDefault(); P[b.dataset.idx] = ''; autosave(); refreshCol(k, false); });
  const sc = $('[data-sigcrop]', col); if (sc) sc.onclick = () => cropSignature(k);
  $('[data-sigfile]', col).onchange = async (e) => { const f = e.target.files[0]; if (!f) return; P.sig = await IMG.removeBackground(await IMG.fileToDataUrl(f, 1400), 50); P.sigAuto = false; autosave(); refreshCol(k, false); toast('İmza əlavə olundu (fon silindi)'); };
  const sd = $('[data-sigdel]', col); if (sd) sd.onclick = () => { P.sig = ''; P.sigAuto = false; autosave(); refreshCol(k, false); };
  const sf = $('[data-sealfile]', col); if (sf) sf.onchange = async (e) => { const f = e.target.files[0]; if (!f) return; P.seal = await IMG.removeBackground(await IMG.fileToDataUrl(f, 1400), 50); autosave(); refreshCol(k, false); toast('Möhür əlavə olundu — imzanın üstünə qoyuldu'); };
  const sl = $('[data-sealdel]', col); if (sl) sl.onclick = () => { P.seal = ''; autosave(); refreshCol(k, false); };
  $('[data-tobook]', col).onclick = async () => { const label = S.partyName(P).replace(/_+/g, '').trim() || 'Adsız tərəf'; const ex = st.parties.find((x) => x.label === label); if (ex) ex.data = clone(P); else st.parties.push({ id: uid(), label, data: clone(P) }); await save('parties'); counts(); toast(`“${label}” tərəflər kitabına yazıldı`); refreshCol(k, false); };
  const our = $('[data-our]', col); if (our) our.onclick = async () => { const label = S.partyName(P).replace(/_+/g, '').trim() || 'Bizim şirkət'; let ex = st.parties.find((x) => x.label === label); if (!ex) { ex = { id: uid(), label, data: clone(P) }; st.parties.push(ex); } else ex.data = clone(P); st.settings.ourParty = ex.id; await save('parties', 'settings'); toast('Yadda saxlanıldı — yeni müqavilələrdə sol tərəf avtomatik yazılacaq'); refreshCol(k, false); };
  $('[data-reset]', col).onclick = () => { if (!confirm('Bu tərəfin bütün məlumatları silinsin?')) return; const t = P.type; d.parties[k] = S.EMPTY_PARTY(); d.parties[k].type = t; autosave(); refreshCol(k, false); };
}
function syncForm(k) {
  const P = st.doc.parties[k], col = $(`[data-party="${k}"]`);
  $$('[data-p]', col).forEach((el) => { if (el === document.activeElement) return; const v = el.dataset.p.split('.').reduce((o, x) => (o || {})[x], P); el.value = v ?? ''; });
}

async function takeId(k, slot, file) {
  if (!file) return;
  const P = st.doc.parties[k];
  P[slot] = await IMG.fileToDataUrl(file, 1800);
  if (slot === 'idFront' && (!P.sig || P.sigAuto)) { P.sig = await IMG.extractSignature(P.idFront, st.settings.sigRect, st.settings.sens); P.sigAuto = true; }
  autosave(); refreshCol(k, false);
  const stEl = () => $(`[data-party="${k}"] [data-ocr]`);
  stEl().innerHTML = `<span>Vəsiqə oxunur…</span><div class="bar"><i></i></div>`;
  try {
    const text = await IMG.ocr(P[slot], (pr, status) => { const i = $(`[data-party="${k}"] [data-ocr] i`); if (i) i.style.width = pr + '%'; const s = $(`[data-party="${k}"] [data-ocr] span`); if (s) s.textContent = status === 'recognizing text' ? `Mətn tanınır… ${pr}%` : 'OCR mühərriki yüklənir (ilk dəfə bir az çəkir)…'; });
    const r = I.parseIdAny(text);
    const got = [];
    for (const [key, f] of [['last', 'soyad'], ['first', 'ad'], ['father', 'ata adı'], ['fin', 'FİN'], ['idNumber', 'nömrə'], ['idSeries', ''], ['gender', ''], ['idDate', ''], ['birth', '']]) {
      if (r[key]) { P.person[key] = key === 'fin' ? S.upperAz(r[key]) : r[key]; if (f) got.push(f); }
    }
    autosave(); refreshCol(k, false);
    stEl().innerHTML = got.length ? `<span class="pill ok">✓ Şəkildən oxundu: ${esc(got.join(', '))}</span>` : '<span class="pill">Şəkil aydın oxunmadı — mətni yuxarıya yapışdırın</span>';
  } catch (e) {
    const el = stEl(); if (el) el.innerHTML = `<span class="pill">Avtomatik oxuma alınmadı: ${esc(e.message)}. Mətni yuxarıya yapışdırın.</span>`;
  }
}

function cropSignature(k) {
  const P = st.doc.parties[k];
  let rect = { ...st.settings.sigRect }, sens = st.settings.sens, result = P.sig;
  modal({
    title: 'İmzanı vəsiqədən götür', wide: true,
    body: `<div class="alert info">Sarı çərçivəni imzanın üstünə çəkin (siçanla yeni çərçivə çəkmək və ya sürüşdürmək olar). Seçim yadda qalır — növbəti vəsiqələrdə imza avtomatik həmin yerdən götürüləcək.</div>
      <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:14px;align-items:start"><div class="crop" id="crop"><img src="${P.idFront}" draggable="false"><div class="r" id="r"><span class="h"></span></div></div>
      <div><div class="sub-h">Nəticə</div><div class="prev-ck" id="sp">${result ? `<img src="${result}">` : ''}</div><label class="f" style="margin-top:10px"><span>Həssaslıq <b id="sv">${sens}</b></span><input type="range" min="10" max="95" value="${sens}" id="sr"></label><p class="small muted">İmza qırıq-qırıqdırsa həssaslığı artırın, fon da gəlirsə azaldın.</p></div></div>`,
    actions: [{ label: 'Ləğv et' }, { label: 'Tətbiq et', cls: 'primary', onClick: async () => { P.sig = result; P.sigAuto = true; st.settings.sigRect = rect; st.settings.sens = sens; await save('settings'); autosave(); refreshCol(k, false); toast('İmza əlavə olundu'); } }],
    onMount(m) {
      const crop = $('#crop', m), r = $('#r', m), img = $('img', crop);
      const draw = () => { r.style.left = rect.x * 100 + '%'; r.style.top = rect.y * 100 + '%'; r.style.width = rect.w * 100 + '%'; r.style.height = rect.h * 100 + '%'; };
      let t = null; const run = () => { clearTimeout(t); t = setTimeout(async () => { result = await IMG.extractSignature(P.idFront, rect, sens); $('#sp', m).innerHTML = result ? `<img src="${result}">` : '<span class="small muted">İmza tapılmadı</span>'; }, 120); };
      const pos = (e) => { const b = img.getBoundingClientRect(); return { x: Math.min(1, Math.max(0, (e.clientX - b.left) / b.width)), y: Math.min(1, Math.max(0, (e.clientY - b.top) / b.height)) }; };
      let mode = null, start = null, orig = null;
      crop.onmousedown = (e) => { e.preventDefault(); const p = pos(e); start = p; orig = { ...rect }; mode = e.target.classList.contains('h') ? 'size' : e.target === r ? 'move' : 'new'; if (mode === 'new') rect = { x: p.x, y: p.y, w: 0.01, h: 0.01 }; draw(); };
      window.onmousemove = (e) => { if (!mode) return; const p = pos(e); if (mode === 'move') { rect.x = Math.min(1 - rect.w, Math.max(0, orig.x + p.x - start.x)); rect.y = Math.min(1 - rect.h, Math.max(0, orig.y + p.y - start.y)); } else if (mode === 'size') { rect.w = Math.max(0.03, Math.min(1 - rect.x, orig.w + p.x - start.x)); rect.h = Math.max(0.03, Math.min(1 - rect.y, orig.h + p.y - start.y)); } else { rect = { x: Math.min(p.x, start.x), y: Math.min(p.y, start.y), w: Math.max(0.03, Math.abs(p.x - start.x)), h: Math.max(0.03, Math.abs(p.y - start.y)) }; } draw(); };
      window.onmouseup = () => { if (mode) { mode = null; run(); } };
      $('#sr', m).oninput = (e) => { sens = Number(e.target.value); $('#sv', m).textContent = sens; run(); };
      draw(); run();
    }
  });
}

// ------------------------------------------------------------------ yan panel (2-4)
function side() { ({ terms: sideTerms, text: sideText, doc: sideDoc })[st.tab](); }
const ch = () => { preview(); autosave(); };

function sideTerms() {
  const d = st.doc;
  const mk = S.mainMoneyKey(d), mf = d.fields.find((f) => f.key === mk);
  const groups = [...new Set(d.fields.filter((f) => f.key !== mk).map((f) => f.group || 'Əsas'))];
  const ctl = (f) => {
    const v = d.values[f.key] ?? '';
    const tok = `<button class="tok" data-copy="{{${f.key}}}" title="Mətnə əlavə etmək üçün kopyala">{{${esc(f.key)}}}</button>`;
    let el;
    if (f.type === 'select') el = `<select data-v="${f.key}">${(f.options || []).map((o) => `<option ${o === v ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
    else if (f.type === 'textarea') el = `<textarea data-v="${f.key}" rows="3">${esc(v)}</textarea>`;
    else el = `<input data-v="${f.key}" type="${f.type === 'date' ? 'date' : f.type === 'number' || f.type === 'money' ? 'number' : 'text'}" ${f.type === 'money' ? 'step="0.01"' : ''} value="${esc(v)}">`;
    const words = f.type === 'money' && v !== '' ? `<small class="muted" data-w="${f.key}">${esc(S.moneyText(v, d.currency))}</small>` : '';
    if (f.custom || f.imported || /^bosluq/.test(f.key)) return `<div class="f"><span style="display:flex;gap:4px;align-items:center"><input data-lbl="${f.key}" value="${esc(f.label)}" class="lblin" title="Sahənin adını dəyiş"><button class="ib" data-fdel="${f.key}" title="Sil">✕</button></span>${el}${words}</div>`;
    return `<label class="f"><span style="display:flex;justify-content:space-between;align-items:center">${esc(f.label)} ${tok}</span>${el}${words}</label>`;
  };
  $('#sideB').innerHTML = `<div class="money">
      <div class="sub-h" style="margin-top:0">💰 Müqavilənin məbləği</div>
      ${mf ? `<label class="f"><span>${esc(mf.label)}</span><input class="big" data-v="${mf.key}" type="number" step="0.01" value="${esc(d.values[mf.key] ?? '')}" placeholder="0.00"></label>
      <div class="row"><label class="f"><span>Valyuta</span><select id="mCur">${['AZN', 'USD', 'EUR'].map((c) => `<option ${d.currency === c ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
        <label class="f"><span>ƏDV</span><select id="mVat"><option value="" ${!d.vat ? 'selected' : ''}>qeyd etmə</option><option value="daxil" ${d.vat === 'daxil' ? 'selected' : ''}>ƏDV daxil</option><option value="xaric" ${d.vat === 'xaric' ? 'selected' : ''}>ƏDV xaric</option><option value="yox" ${d.vat === 'yox' ? 'selected' : ''}>ƏDV-yə cəlb edilmir</option></select></label></div>
      <div class="words" data-w="${mf.key}">${d.values[mf.key] ? esc(S.moneyText(d.values[mf.key], d.currency) + (S.VAT[d.vat] || '')) : 'Məbləği yazın — sözlə avtomatik yazılacaq'}</div>
      ${d.fields.filter((f) => f.type === 'money').length > 1 ? `<label class="f" style="margin-top:6px"><span>Əsas məbləğ sahəsi</span><select id="mKey">${d.fields.filter((f) => f.type === 'money').map((f) => `<option value="${f.key}" ${f.key === mk ? 'selected' : ''}>${esc(f.label)}</option>`).join('')}</select></label>` : ''}`
      : `<p class="small muted">Bu sənəddə məbləğ sahəsi yoxdur.</p><button class="btn sm primary" id="addMoney">＋ Məbləğ əlavə et</button>`}
    </div>
    ${groups.map((g) => `<div class="fgroup"><div class="sub-h">${esc(g)}</div><div class="row">${d.fields.filter((f) => f.key !== mk && (f.group || 'Əsas') === g).map(ctl).join('')}</div></div>`).join('')}
    <div class="fgroup"><div class="sub-h">📝 Xüsusi şərtlər <small class="muted">— hər sətir ayrıca bənd olacaq</small></div>
      <textarea id="extra" rows="5" placeholder="Məs.:\nAvtomobilin yürüşü ayda 3000 km-dən çox olmamalıdır.\nCərimələri İcarəçi ödəyir.">${esc(d.extra || '')}</textarea>
      <p class="small muted">Müqavilədə “XÜSUSİ ŞƏRTLƏR” bölməsi kimi yekun bölmələrdən əvvəl görünəcək.</p></div>
    <div class="card" style="box-shadow:none;margin-top:8px"><b>Yeni sahə əlavə et</b><p class="small muted" style="margin:4px 0 8px">Məs. “Avtomobilin yürüşü”, “Əlavə ödəniş”. Sahə yaradıldıqdan sonra mətndə {{açar}} kimi istifadə edin.</p>
      <div class="row"><input id="nfL" placeholder="Sahənin adı"><select id="nfT"><option value="text">Mətn</option><option value="money">Məbləğ (sözlə də yazılır)</option><option value="number">Rəqəm</option><option value="date">Tarix</option><option value="textarea">Uzun mətn</option></select><button class="btn sm primary" id="nfAdd">＋ Əlavə et</button></div></div>`;
  const words = () => { const k = S.mainMoneyKey(d); const w = $(`.words[data-w="${k}"]`); if (w) w.textContent = d.values[k] ? S.moneyText(d.values[k], d.currency) + (S.VAT[d.vat] || '') : 'Məbləği yazın — sözlə avtomatik yazılacaq'; };
  $$('[data-v]').forEach((el) => el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => { d.values[el.dataset.v] = el.value; ch(); const s = $(`small[data-w="${el.dataset.v}"]`); if (s) s.textContent = S.moneyText(el.value, d.currency); words(); }));
  const mc = $('#mCur'); if (mc) mc.onchange = () => { d.currency = mc.value; words(); ch(); };
  const mv = $('#mVat'); if (mv) mv.onchange = () => { d.vat = mv.value; words(); ch(); };
  const mkS = $('#mKey'); if (mkS) mkS.onchange = () => { d.mainMoney = mkS.value; sideTerms(); ch(); };
  const am = $('#addMoney'); if (am) am.onclick = () => {
    d.fields.push({ key: 'mebleg', label: 'Müqavilənin məbləği', type: 'money', group: 'Məbləğ və ödəniş', custom: true }); d.mainMoney = 'mebleg';
    const i = Math.max(0, d.sections.findIndex((s) => /dəyər|ödəniş|haqq|məbləğ|hesablaşma/i.test(S.lowerAz(s.title || ''))));
    if (d.sections[i]) d.sections[i].clauses.unshift('Müqavilənin ümumi məbləği {{mebleg}} təşkil edir.');
    sideTerms(); ch(); toast('Məbləğ sahəsi əlavə olundu və müvafiq bölməyə bənd kimi yazıldı');
  };
  $('#extra').oninput = (e) => { d.extra = e.target.value; ch(); };
  $$('[data-lbl]').forEach((el) => el.oninput = () => { const f = d.fields.find((x) => x.key === el.dataset.lbl); f.label = el.value; autosave(); });
  $$('[data-fdel]').forEach((b) => b.onclick = () => { if (!confirm('Sahə silinsin? Mətndə qalan işarə boş yer kimi görünəcək.')) return; d.fields = d.fields.filter((f) => f.key !== b.dataset.fdel); sideTerms(); ch(); });
  $$('[data-copy]').forEach((b) => b.onclick = (e) => { e.preventDefault(); navigator.clipboard.writeText(b.dataset.copy); toast(`${b.dataset.copy} kopyalandı — “Mətn” bölməsində bəndə yapışdırın`); });
  $('#nfAdd').onclick = () => {
    const label = $('#nfL').value.trim(); if (!label) return toast('Sahənin adını yazın');
    let key = S.lowerAz(label).replace(/[əƏ]/g, 'e').replace(/[ıİ]/g, 'i').replace(/[öÖ]/g, 'o').replace(/[üÜ]/g, 'u').replace(/[şŞ]/g, 's').replace(/[çÇ]/g, 'c').replace(/[ğĞ]/g, 'g').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'sahe';
    while (d.fields.some((f) => f.key === key)) key += '_2';
    d.fields.push({ key, label, type: $('#nfT').value, group: 'Əlavə sahələr', custom: true });
    sideTerms(); ch(); navigator.clipboard.writeText(`{{${key}}}`).catch(() => {}); toast(`Sahə əlavə olundu: {{${key}}} (kopyalandı)`);
  };
}

let lastTa = null;
function sideText() {
  const d = st.doc;
  const toks = [['A.ad', `${d.roles.A} — ad`], ['B.ad', `${d.roles.B} — ad`], ['A.rol', `“${d.roles.A}”`], ['B.rol', `“${d.roles.B}”`], ['A.rol:gen', `“${d.roles.A}”${S.suffix(d.roles.A, 'gen')}`], ['B.rol:gen', `“${d.roles.B}”${S.suffix(d.roles.B, 'gen')}`], ['A.rol:dat', `“${d.roles.A}”${S.suffix(d.roles.A, 'dat')}`], ['B.rol:dat', `“${d.roles.B}”${S.suffix(d.roles.B, 'dat')}`], ...d.fields.map((f) => [f.key, f.label])];
  const nos = (s, i) => { let k = 0, m = 0; return (s.clauses || []).map((c) => { c = String(c); if (c.startsWith('¶')) return '¶'; if (c.startsWith('»') && k) { m++; return `${i + 1}.${k}.${m}`; } k++; m = 0; return `${i + 1}.${k}`; }); };
  $('#sideB').innerHTML = `<label class="f"><span>Müqavilənin başlığı</span><input id="tTitle" value="${esc(d.title)}"></label>
    <label class="f" style="margin-top:6px"><span>Alt başlıq (istəyə görə)</span><input id="tSub" value="${esc(d.subtitle || '')}" placeholder="məs. (mühasibat xidmətinin göstərilməsinə dair)"></label>
    <div class="sub-h">Əlavə etmək üçün klikləyin (kursorun yerinə yazılır)</div><div>${toks.map(([k, l]) => `<button class="tok" data-tok="${esc(k)}" title="{{${esc(k)}}}">${esc(l)}</button>`).join('')}</div>
    <p class="small muted">Bəndin əvvəlinə <b>»</b> yazsanız alt bənd (1.1.1), <b>¶</b> yazsanız nömrəsiz abzas olur.</p>
    <div class="sub-h">Bölmələr və bəndlər</div><div id="secs">${d.sections.map((s, i) => { const nn = nos(s, i); return `<div class="sec" data-s="${i}"><div class="sec-h"><input data-st="${i}" value="${esc(s.title)}" placeholder="Bölmənin adı"><button class="ib" data-sup="${i}" title="Yuxarı">↑</button><button class="ib" data-sdown="${i}" title="Aşağı">↓</button><button class="ib" data-sdel="${i}" title="Bölməni sil">✕</button></div>
      ${(s.clauses || []).map((c, j) => `<div class="cl"><span class="no">${s.numbered === false ? '¶' : nn[j]}</span><textarea data-c="${i}.${j}" rows="3">${esc(c)}</textarea><div style="display:grid;gap:3px"><button class="ib" data-cup="${i}.${j}">↑</button><button class="ib" data-cdel="${i}.${j}">✕</button></div></div>`).join('')}
      <div style="display:flex;gap:6px"><button class="btn sm ghost" data-cadd="${i}">＋ Bənd</button><select class="btn sm ghost" data-clib="${i}" style="width:auto"><option value="">＋ Hazır bənd…</option>${CLAUSES.map((c, k) => `<option value="${k}">${esc(c.title)}</option>`).join('')}</select></div></div>`; }).join('')}</div>
    <button class="btn soft" id="sAdd" style="width:100%">＋ Yeni bölmə</button>`;
  $('#tTitle').oninput = (e) => { d.title = e.target.value; ch(); };
  $('#tSub').oninput = (e) => { d.subtitle = e.target.value; ch(); };
  const resize = (ta) => { ta.style.height = 'auto'; ta.style.height = ta.scrollHeight + 2 + 'px'; };
  $$('[data-c]').forEach((ta) => { resize(ta); ta.onfocus = () => { lastTa = ta; }; ta.oninput = () => { const [i, j] = ta.dataset.c.split('.').map(Number); d.sections[i].clauses[j] = ta.value; resize(ta); ch(); }; });
  $$('[data-st]').forEach((el) => el.oninput = () => { d.sections[Number(el.dataset.st)].title = el.value; ch(); });
  $$('[data-tok]').forEach((b) => b.onclick = () => {
    const t = `{{${b.dataset.tok}}}`;
    if (!lastTa || !document.body.contains(lastTa)) { navigator.clipboard.writeText(t).catch(() => {}); toast(`${t} kopyalandı — bəndə yapışdırın`); return; }
    const a = lastTa.selectionStart, z = lastTa.selectionEnd; lastTa.value = lastTa.value.slice(0, a) + t + lastTa.value.slice(z); lastTa.focus(); lastTa.selectionStart = lastTa.selectionEnd = a + t.length; lastTa.dispatchEvent(new Event('input'));
  });
  const re = () => { const y = $('#sideB').scrollTop; sideText(); $('#sideB').scrollTop = y; ch(); };
  $$('[data-sup]').forEach((b) => b.onclick = () => { const i = Number(b.dataset.sup); if (i) { [d.sections[i - 1], d.sections[i]] = [d.sections[i], d.sections[i - 1]]; re(); } });
  $$('[data-sdown]').forEach((b) => b.onclick = () => { const i = Number(b.dataset.sdown); if (i < d.sections.length - 1) { [d.sections[i + 1], d.sections[i]] = [d.sections[i], d.sections[i + 1]]; re(); } });
  $$('[data-sdel]').forEach((b) => b.onclick = () => { if (confirm('Bölmə silinsin?')) { d.sections.splice(Number(b.dataset.sdel), 1); re(); } });
  $$('[data-cadd]').forEach((b) => b.onclick = () => { d.sections[Number(b.dataset.cadd)].clauses.push(''); re(); const tas = $$(`[data-c^="${b.dataset.cadd}."]`); const ta = tas[tas.length - 1]; ta && ta.focus(); });
  $$('[data-cup]').forEach((b) => b.onclick = () => { const [i, j] = b.dataset.cup.split('.').map(Number); if (j) { const c = d.sections[i].clauses; [c[j - 1], c[j]] = [c[j], c[j - 1]]; re(); } });
  $$('[data-cdel]').forEach((b) => b.onclick = () => { const [i, j] = b.dataset.cdel.split('.').map(Number); d.sections[i].clauses.splice(j, 1); re(); });
  $$('[data-clib]').forEach((s) => s.onchange = () => { if (s.value === '') return; d.sections[Number(s.dataset.clib)].clauses.push(CLAUSES[Number(s.value)].text); re(); toast('Hazır bənd əlavə olundu'); });
  $('#sAdd').onclick = () => { d.sections.splice(Math.max(0, d.sections.length - 1), 0, { title: 'YENİ BÖLMƏ', clauses: [''] }); re(); };
}

function sideDoc() {
  const d = st.doc;
  const chk = (k, l) => `<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" data-flag="${k}" ${d[k] !== false ? 'checked' : ''} style="width:auto"> ${l}</label>`;
  $('#sideB').innerHTML = `<div class="row"><label class="f"><span>Nömrə</span><input id="dNo" value="${esc(d.number)}"></label><label class="f"><span>Tarix</span><input id="dDate" type="date" value="${esc(d.date)}"></label></div>
    <div class="row"><label class="f"><span>Şəhər</span><input id="dCity" value="${esc(d.city)}"></label><label class="f"><span>Valyuta</span><select id="dCur">${['AZN', 'USD', 'EUR'].map((c) => `<option ${d.currency === c ? 'selected' : ''}>${c}</option>`).join('')}</select></label></div>
    <div class="sub-h">Sənədin quruluşu</div>${chk('header', 'Başlıq, nömrə, şəhər və tarix')}${chk('preamble', 'Preambula (tərəflərin təqdimatı) — avtomatik')}${chk('numbering', 'Bölmə və bəndlərin avtomatik nömrələnməsi')}${chk('requisites', 'Rekvizitlər cədvəli, imza və möhür')}
    <div class="alert info" style="margin-top:12px">Rekvizitlər bütün müqavilələrdə eyni səliqəli cədvəl şəklindədir: sol və sağ tərəf yan-yana, sətirlər hizalı, imza və möhür altda.</div>
    <div class="big-dl"><button class="btn soft" id="dW2">⬇ Word (.docx) yüklə</button><button class="btn gold" id="dP2">⬇ PDF yüklə</button></div>`;
  $('#dNo').oninput = (e) => { d.number = e.target.value; ch(); };
  $('#dDate').oninput = (e) => { d.date = e.target.value; ch(); };
  $('#dCity').oninput = (e) => { d.city = e.target.value; st.settings.city = e.target.value; save('settings'); ch(); };
  $('#dCur').onchange = (e) => { d.currency = e.target.value; ch(); };
  $$('[data-flag]').forEach((c) => c.onchange = () => { d[c.dataset.flag] = c.checked; ch(); });
  $('#dW2').onclick = () => exportDoc('docx'); $('#dP2').onclick = () => exportDoc('pdf');
}

// ================================================================== SİYAHILAR
function viewDocs() {
  const list = st.docs.slice().sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
  $('#app').innerHTML = `<div class="card" style="padding:0;overflow:hidden"><table class="t"><thead><tr><th>Sənəd</th><th>Nömrə</th><th>Tərəflər</th><th>Tarix</th><th>Dəyişib</th><th></th></tr></thead><tbody>
    ${list.map((d) => `<tr><td><b>${esc(d.name)}</b></td><td>${esc(d.number)}</td><td>${esc(S.partyName(fixParty(d.parties.A)))}<br><span class="muted">${esc(S.partyName(fixParty(d.parties.B)))}</span></td><td>${S.fmtDate(d.date)}</td><td class="small muted">${new Date(d.updatedAt).toLocaleString('az')}</td>
    <td style="white-space:nowrap"><button class="btn sm primary" data-open="${d.id}">Aç</button> <button class="btn sm ghost" data-dup="${d.id}" title="Surətini çıxar">⧉</button> <button class="btn sm danger" data-del="${d.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">Hələ sənəd yoxdur</td></tr>'}</tbody></table></div>`;
  $$('[data-open]').forEach((b) => b.onclick = () => openDoc(clone(st.docs.find((d) => d.id === b.dataset.open))));
  $$('[data-dup]').forEach((b) => b.onclick = () => { const d = clone(st.docs.find((x) => x.id === b.dataset.dup)); d.id = uid(); d.name += ' (surət)'; d.createdAt = d.updatedAt = new Date().toISOString(); openDoc(d); autosave(); });
  $$('[data-del]').forEach((b) => b.onclick = async () => { if (!confirm('Sənəd silinsin?')) return; st.docs = st.docs.filter((d) => d.id !== b.dataset.del); await save('docs'); render(); });
}
function viewParties() {
  $('#app').innerHTML = `<div class="alert info">Tez-tez istifadə etdiyiniz şirkət və şəxslər (vəsiqə, imza və möhürü ilə birlikdə). Redaktorda “Kitabdan seç” ilə bir kliklə əlavə olunur. ★ — bizim şirkət (yeni müqavilələrdə avtomatik sol tərəf).</div>
    <div class="card" style="padding:0;overflow:hidden"><table class="t"><thead><tr><th>Ad</th><th>Növ</th><th>VÖEN / FİN</th><th>Rəhbər</th><th>İmza / möhür</th><th></th></tr></thead><tbody>
    ${st.parties.map((x) => { const P = fixParty(x.data); return `<tr><td><b>${esc(x.label)}</b> ${x.id === st.settings.ourParty ? '<span class="pill acc">★ bizim şirkət</span>' : ''}</td><td>${P.type === 'legal' ? 'Hüquqi' : P.type === 'fs' ? 'Fərdi sahibkar' : 'Fiziki'}</td><td>${esc(P.voen || P.person.fin || '')}</td><td>${esc(P.type === 'legal' ? S.personName(P.person) : '')}</td><td>${P.sig ? `<img src="${P.sig}" style="height:28px;vertical-align:middle">` : '—'} ${P.seal ? `<img src="${P.seal}" style="height:34px;vertical-align:middle">` : ''}</td>
      <td style="white-space:nowrap"><button class="btn sm ghost" data-star="${x.id}">★</button> <button class="btn sm danger" data-pdel="${x.id}">✕</button></td></tr>`; }).join('') || '<tr><td colspan="6" class="empty">Kitab boşdur — redaktorda tərəfi doldurub “Kitaba yadda saxla” basın</td></tr>'}</tbody></table></div>`;
  $$('[data-star]').forEach((b) => b.onclick = async () => { st.settings.ourParty = st.settings.ourParty === b.dataset.star ? '' : b.dataset.star; await save('settings'); render(); });
  $$('[data-pdel]').forEach((b) => b.onclick = async () => { if (!confirm('Silinsin?')) return; st.parties = st.parties.filter((x) => x.id !== b.dataset.pdel); await save('parties'); render(); });
}

// ------------------------------------------------------------------ modal
function modal({ title, body, actions = [], wide, onMount }) {
  const bg = document.createElement('div'); bg.className = 'mbg';
  bg.innerHTML = `<div class="mdl ${wide ? 'wide' : ''}"><div class="mdl-h"><h3>${esc(title)}</h3><button>✕</button></div><div class="mdl-b">${body}</div><div class="mdl-f">${actions.map((a, i) => `<button class="btn ${a.cls || 'ghost'}" data-a="${i}">${esc(a.label)}</button>`).join('')}</div></div>`;
  $('#modal').appendChild(bg);
  const close = () => { bg.remove(); window.onmousemove = null; window.onmouseup = null; };
  $('.mdl-h button', bg).onclick = close;
  actions.forEach((a, i) => { $(`[data-a="${i}"]`, bg).onclick = async () => { if (a.onClick) await a.onClick(); close(); }; });
  onMount && onMount(bg);
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { const m = $$('.mbg').pop(); if (m) $('.mdl-h button', m).click(); } });

// ------------------------------------------------------------------ başlanğıc
(async () => {
  await load();
  const key = new URLSearchParams(location.search).get('key');
  const d = key && st.docs.find((x) => x.id === key);
  if (d) openDoc(clone(d)); else render();
})();
