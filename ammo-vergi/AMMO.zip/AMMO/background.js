/* AMMO — fon skripti (service worker), v1.23
 *  • Firebase (Konsalting) sorğuları üçün körpü (kontent skriptləri birbaşa getmir — CSP/CORS)
 *  • Avtomatik yeniləmə: update.json + «AMMO-Yenile.exe» (native host az.ammo.vergi.updater) — AMMO SUITE modeli
 *  • Admin ayarları (panellər) və cihaz qeydi
 *  • Sosial şəbəkə analizi: WhatsApp / Gmail / Telegram tablarının idarəsi */
importScripts('lib/config.js', 'lib/dd-inbox.js', 'lib/ammo-cloud.js');
const PORTAL = 'https://new.e-taxes.gov.az/eportal/';
const CFG = self.AMMO_CONFIG || {};
const C = self.AMMO_CLOUD;

chrome.action.onClicked.addListener(async (tab) => {
  if (tab && tab.url && tab.url.startsWith('https://new.e-taxes.gov.az/eportal')) {
    try { await chrome.tabs.sendMessage(tab.id, { type: 'AMMO_TOGGLE' }); return; } catch (e) { /* not ready */ }
    chrome.tabs.reload(tab.id);
    return;
  }
  chrome.tabs.create({ url: PORTAL });
});

// ---------------------------------------------------------------- yeniləmə
function cmpVer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}
async function updConf() {
  let conf = {};
  try { conf = (await C.auth()) ? (await C.getConfig()) : ((await chrome.storage.local.get('ammoAdminConfig')).ammoAdminConfig || {}); } catch (e) { conf = (await chrome.storage.local.get('ammoAdminConfig')).ammoAdminConfig || {}; }
  const u = conf.update || {};
  return {
    url: u.url || CFG.UPDATE_URL, page: u.page || CFG.DOWNLOAD_PAGE,
    every: Math.max(1, +u.everyMin || CFG.CHECK_EVERY_MIN || 5),
    autoApply: u.autoApply == null ? CFG.AUTO_APPLY !== false : !!u.autoApply,
    delay: u.delaySec == null ? (CFG.RESTART_DELAY_SEC || 60) : +u.delaySec,
    blocked: Array.isArray(u.blocked) ? u.blocked.map((x) => String(x).toLowerCase()) : [],
  };
}
function nativeCall(msg, timeoutMs = 180000) {
  return new Promise((resolve) => {
    let done = false;
    const t = setTimeout(() => { if (!done) { done = true; resolve({ ok: false, error: 'timeout' }); } }, timeoutMs);
    try {
      chrome.runtime.sendNativeMessage(CFG.NATIVE_HOST, msg, (res) => {
        if (done) return; done = true; clearTimeout(t);
        const err = chrome.runtime.lastError;
        if (err) resolve({ ok: false, error: /not found|Specified native messaging host/i.test(err.message) ? 'no_host' : err.message });
        else resolve(res || { ok: false, error: 'empty' });
      });
    } catch (e) { done = true; clearTimeout(t); resolve({ ok: false, error: String(e && e.message || e) }); }
  });
}
async function checkUpdate(opts = {}) {
  const current = chrome.runtime.getManifest().version;
  const uc = await updConf();
  const state = { current, checkedAt: Date.now(), latest: null, available: false, url: uc.url, page: uc.page, autoApply: uc.autoApply };
  if (!uc.url || uc.url.startsWith('__')) { state.error = 'not-configured'; await chrome.storage.local.set({ ammo_update: state }); return state; }
  try {
    const res = await fetch(uc.url + (uc.url.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' });
    if (res.ok) {
      const info = await res.json();
      state.latest = info;
      state.available = !!info.version && cmpVer(info.version, current) > 0;
    } else state.error = 'HTTP ' + res.status;
  } catch (e) { state.error = String(e && e.message || e); }
  const a = await C.auth().catch(() => null);
  if (a && uc.blocked.includes(String(a.email).toLowerCase())) { state.available = false; state.blocked = true; }
  await chrome.storage.local.set({ ammo_update: state });
  chrome.action.setBadgeText({ text: state.available ? 'NEW' : '' });
  if (state.available) chrome.action.setBadgeBackgroundColor({ color: '#2f7d5b' });
  if (state.available && (opts.apply || uc.autoApply)) await scheduleApply(state, opts.apply ? 0 : uc.delay);
  return state;
}
/** açıq AMMO pəncərəsi varsa — istifadəçiyə zolaq göstərilir və gecikmə ilə yenilənir */
async function scheduleApply(state, delaySec) {
  const busy = await anyAmmoPageOpen();
  const wait = busy ? Math.max(0, delaySec) : 0;
  const pending = { version: state.latest.version, notes: state.latest.notes || [], applyAt: Date.now() + wait * 1000, at: Date.now() };
  await chrome.storage.local.set({ ammo_update_pending: pending });
  if (wait <= 0) return applyUpdate();
  chrome.alarms.create('ammo_apply', { when: pending.applyAt });
}
async function anyAmmoPageOpen() {
  try { const ctx = await chrome.runtime.getContexts({ contextTypes: ['TAB'] }); return ctx.some((c) => c.documentUrl && /\/pages\/(dovriyye|audit2|social|admin|evez|taxrep)\.html/.test(c.documentUrl)); } catch (e) { return false; }
}
let applying = false;
async function applyUpdate() {
  if (applying) return { ok: false, error: 'busy' };
  applying = true;
  try {
    const st = (await chrome.storage.local.get('ammo_update')).ammo_update || {};
    const a = await C.auth().catch(() => null);
    // açıq səhifələrin son dəyişiklikləri buluda yazılsın
    try { await Promise.race([chrome.runtime.sendMessage({ type: 'AMMO_FLUSH_NOW' }), new Promise((r) => setTimeout(r, 4000))]); } catch (e) { /* səhifə yoxdur */ }
    try { await storeFlush(); } catch (e) { /* */ }
    const res = await nativeCall({ action: 'check_and_update', url: st.url || CFG.UPDATE_URL, email: a ? a.email : '', current: chrome.runtime.getManifest().version });
    const log = { at: Date.now(), res };
    await chrome.storage.local.set({ ammo_update_log: log });
    if (res && res.ok && res.updated) {
      await chrome.storage.local.set({ ammo_just_updated: { from: chrome.runtime.getManifest().version, to: res.to || (st.latest && st.latest.version), notes: (st.latest && st.latest.notes) || [], at: Date.now(), reason: 'update' } });
      await chrome.storage.local.remove('ammo_update_pending');
      setTimeout(() => chrome.runtime.reload(), 400);
      return { ok: true };
    }
    await chrome.storage.local.set({ ammo_update_pending: { ...(await chrome.storage.local.get('ammo_update_pending')).ammo_update_pending, failed: res && res.error ? res.error : 'naməlum', applyAt: 0 } });
    return { ok: false, error: res && res.error };
  } finally { applying = false; }
}

async function setupAlarms() {
  const uc = await updConf().catch(() => ({ every: CFG.CHECK_EVERY_MIN || 5 }));
  chrome.alarms.create('ammo_update', { periodInMinutes: uc.every, delayInMinutes: 1 });
  chrome.alarms.create('ammo_cloud', { periodInMinutes: 10, delayInMinutes: 2 });
  chrome.alarms.create('ammo_remote', { periodInMinutes: 0.5, delayInMinutes: 0.5 }); // v1.25: AMMO Mobil əmrləri
}
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name === 'ammo_update') checkUpdate();
  if (a.name === 'ammo_apply') applyUpdate();
  if (a.name === 'ammo_cloud') { try { if (await C.auth()) { await C.getConfig(true); await C.heartbeat(); } } catch (e) { /* oflayn */ } }
  if (a.name === 'ammo_remote') remoteTick(false);
});

// ---------------------------------------------------------------- v1.25: uzaqdan əmrlər (AMMO Mobil)
//  Telefon «remoteCommands»-a əmr yazır və suiteSharedV3/_rev_ammo_remote nişanını yeniləyir.
//  Bu kompüterdə e-taxes açıqdırsa: 30 saniyədən bir yalnız nişan oxunur (1 oxuma), dəyişibsə yeni əmrlər
//  götürülür, VÖEN-i uyğun gələn tabda icra olunur. e-taxes açıq deyilsə Firebase-ə heç bir sorğu getmir.
const REMOTE_OPS = new Set(['profile', 'debts', 'mail', 'declarations', 'cash804', 'audit']);
const REMOTE_MAX_AGE = 24 * 3600 * 1000;
let remoteBusy = false, remoteRev = null, remoteFullAt = 0, remoteAgentAt = 0, remoteAgentSig = '';
async function remoteTabs() {
  const tabs = await chrome.tabs.query({ url: 'https://new.e-taxes.gov.az/eportal/*' });
  const infos = await Promise.all(tabs.map(async (t) => {
    try { const r = await chrome.tabs.sendMessage(t.id, { type: 'AMMO_REMOTE_WHO' }); return r && r.ok && r.tin ? { tabId: t.id, tin: String(r.tin), name: r.name || '', busy: !!r.busy } : null; } catch (e) { return null; }
  }));
  return infos.filter(Boolean);
}
async function remoteQuery(a) {
  const r = await C.netDirect({ url: `${C.BASE}:runQuery`, method: 'POST', headers: { Authorization: 'Bearer ' + a.idToken, 'Content-Type': 'application/json' },
    body: { structuredQuery: { from: [{ collectionId: 'remoteCommands' }], where: { fieldFilter: { field: { fieldPath: 'status' }, op: 'EQUAL', value: { stringValue: 'new' } } }, limit: 20 } } });
  if (!r.ok) { const e = new Error((r.json && r.json[0] && r.json[0].error && r.json[0].error.message) || ('HTTP ' + r.status)); e.status = r.status; throw e; }
  return (Array.isArray(r.json) ? r.json : []).filter((x) => x.document).map((x) => x.document);
}
async function remotePatch(a, id, fields, updateTime) {
  const mask = Object.keys(fields).map((k) => 'updateMask.fieldPaths=' + k).join('&');
  const pre = updateTime ? '&currentDocument.updateTime=' + encodeURIComponent(updateTime) : '';
  const r = await C.netDirect({ url: `${C.BASE}/remoteCommands/${encodeURIComponent(id)}?${mask}${pre}`, method: 'PATCH', headers: { Authorization: 'Bearer ' + a.idToken, 'Content-Type': 'application/json' }, body: { fields: Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, C.enc(v)])) } });
  return r.ok;
}
async function remoteTick(force) {
  if (remoteBusy) return; remoteBusy = true;
  try {
    const a = await C.auth().catch(() => null); if (!a) return;
    const infos = await remoteTabs(); if (!infos.length) return;
    // «onlayn kompüterlər» — telefonda hansı kabinetlərin açıq olduğu görünür
    const sig = infos.map((i) => i.tin).sort().join(',');
    if (force || sig !== remoteAgentSig || Date.now() - remoteAgentAt > 120000) {
      remoteAgentSig = sig; remoteAgentAt = Date.now();
      const tabs = []; const seen = new Set(); infos.forEach((i) => { if (!seen.has(i.tin)) { seen.add(i.tin); tabs.push({ tin: i.tin, name: i.name }); } });
      C.kv.put('ammoRemoteAgents', a.uid, { email: a.email, device: C.deviceLabel(), version: chrome.runtime.getManifest().version, at: new Date().toISOString(), tabs }, a).catch(() => {});
    }
    const rev = await C.rev.read('remote', a).catch(() => null);
    if (!force && rev !== null && rev === remoteRev && Date.now() - remoteFullAt < 300000) return;
    let docs;
    try { docs = await remoteQuery(a); } catch (e) { return; } // qaydalar əlavə edilməyib / oflayn
    remoteRev = rev; remoteFullAt = Date.now();
    const used = new Set();
    for (const doc of docs) {
      const d = C.decDoc(doc) || {}, id = String(doc.name).split('/').pop();
      if (!REMOTE_OPS.has(d.op) || !C.isAdminEmail(d.createdBy)) continue; // yalnız admin əmrləri
      if (Date.now() - new Date(d.createdAt || 0).getTime() > REMOTE_MAX_AGE) { await remotePatch(a, id, { status: 'error', error: 'Əmr 24 saat ərzində icra olunmadı (heç bir kompüterdə həmin kabinet açılmadı)', finishedAt: new Date() }, doc.updateTime).catch(() => {}); continue; }
      const want = String((d.target && d.target.tin) || '');
      const tab = infos.find((i) => !i.busy && !used.has(i.tabId) && (!want || i.tin === want));
      if (!tab) continue;
      // götür (başqa kompüter eyni anda götürübsə — updateTime fərqlidir, keç)
      const claimed = await remotePatch(a, id, { status: 'running', startedAt: new Date(), progress: 'Başladı…', runner: { email: a.email, device: C.deviceLabel(), tin: tab.tin, version: chrome.runtime.getManifest().version } }, doc.updateTime).catch(() => false);
      if (!claimed) continue;
      used.add(tab.tabId);
      let ok = false;
      try { const r = await chrome.tabs.sendMessage(tab.tabId, { type: 'AMMO_REMOTE_RUN', id, op: d.op, params: d.params || {}, tin: tab.tin }); ok = !!(r && r.ok); } catch (e) { ok = false; }
      if (!ok) await remotePatch(a, id, { status: 'new', progress: '' }).catch(() => {}); // başqa tab/kompüter götürsün
    }
  } catch (e) { /* növbəti dəfə */ }
  finally { remoteBusy = false; }
}
let remoteForceAt = 0;
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete' || !/^https:\/\/new\.e-taxes\.gov\.az\/eportal/.test(tab.url || '') || Date.now() - remoteForceAt < 60000) return;
  remoteForceAt = Date.now(); setTimeout(() => remoteTick(true), 4000); // kabinet açılan kimi növbədəki əmrlər
});

chrome.runtime.onInstalled.addListener(async (details) => {
  cleanup();
  setupAlarms();
  checkUpdate();
  if (details.reason === 'update' || details.reason === 'install') {
    const prev = (await chrome.storage.local.get('ammo_just_updated')).ammo_just_updated;
    await chrome.storage.local.set({ ammo_just_updated: { ...(prev && prev.to === chrome.runtime.getManifest().version ? prev : {}), from: details.previousVersion || (prev && prev.from) || null, to: chrome.runtime.getManifest().version, at: Date.now(), reason: details.reason } });
    // açıq portal tablarını yenilə ki, yeni versiya dərhal işləsin (doldurulan forma səhifələrinə toxunulmur)
    const tabs = await chrome.tabs.query({ url: 'https://new.e-taxes.gov.az/eportal/*' });
    tabs.forEach((t) => { if (!/\/declaration\/|\/create|\/edit/.test(t.url || '')) chrome.tabs.reload(t.id); });
    // açıq WhatsApp / Gmail / Yahoo / Telegram tablarına sosial oxuyucunu yerləşdir (tabı yeniləmədən)
    setTimeout(async () => { for (const k of Object.keys(SOC)) { try { for (const t of await chrome.tabs.query({ url: SOC[k].match })) await socInject(t.id, k); } catch (e) { /* */ } } }, 1500);
  }
  try { if (await C.auth()) C.heartbeat(); } catch (e) { /* */ }
});
chrome.runtime.onStartup.addListener(() => { cleanup(); setupAlarms(); checkUpdate(); });

// ---------------------------------------------------------------- mesajlar
const PAGES = /^pages\/(result|decl|audit|audit2|edv|evez|sened|dovriyye|taxrep|admin|social)\.html$/;
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  if (msg.type === 'AMMO_NET' && msg.req && sender.id === chrome.runtime.id) {
    if (!C.ALLOWED_NET.test(String(msg.req.url || ''))) { sendResponse({ error: 'icazəsiz ünvan' }); return false; }
    C.netDirect(msg.req).then(sendResponse, (e) => sendResponse({ error: String(e && e.message || e) }));
    return true;
  }
  if (msg.type === 'AMMO_OPEN_PAGE' && PAGES.test(msg.page)) {
    const opts = { url: chrome.runtime.getURL(msg.page) + '?key=' + encodeURIComponent(msg.key || '') };
    if (sender.tab) { opts.index = sender.tab.index + 1; opts.openerTabId = sender.tab.id; }
    chrome.tabs.create(opts).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === 'AMMO_GMR_OPEN') { // v1.17: Gömrük bəyannamələri pəncərəsi
    const qs = [sender.tab && /^https:/.test(sender.tab.url || '') ? 'tab=' + sender.tab.id : '', msg.audit ? 'audit=1' : ''].filter(Boolean).join('&');
    const opts = { url: chrome.runtime.getURL('pages/gomruk.html') + (qs ? '?' + qs : '') };
    if (sender.tab) { opts.index = sender.tab.index + 1; opts.openerTabId = sender.tab.id; }
    chrome.tabs.create(opts).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === 'AMMO_GMR_REPORT') { gmrReport(msg).then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) })); return true; }
  if (msg.type === 'AMMO_HELPER_OPEN' && Array.isArray(msg.ids)) { helperOpen(msg, sender).then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) })); return true; }
  if (msg.type === 'AMMO_HELPER_STATUS') { helperAlive(true).then((port) => sendResponse({ alive: !!port, port })); return true; }
  if (msg.type === 'AMMO_DECL_FILL' && msg.payload) { declFill(msg.payload).then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) })); return true; }
  if (msg.type === 'AMMO_VATACC_LEARN') { vatAccLearn(sender).then(sendResponse, () => sendResponse({ ok: false })); return true; }
  if (msg.type === 'AMMO_CHECK_UPDATE') { checkUpdate({ apply: !!msg.apply }).then(sendResponse); return true; }
  if (msg.type === 'AMMO_APPLY_NOW') { applyUpdate().then(sendResponse); return true; }
  if (msg.type === 'AMMO_POSTPONE') { postpone(msg.min || 5).then(sendResponse); return true; }
  if (msg.type === 'AMMO_NATIVE_PING') { nativeCall({ action: 'ping' }, 8000).then(sendResponse); return true; }
  if (msg.type === 'AMMO_CLOUD_CHANGED') { setupAlarms(); sendResponse({ ok: true }); return false; }
  if (msg.type === 'AMMO_OPEN_URL' && /^https:\/\//.test(msg.url)) { chrome.tabs.create({ url: msg.url, active: msg.active !== false }); sendResponse({ ok: true }); return false; }
  if (msg.type === 'AMMO_RELOAD') { sendResponse({ ok: true }); setTimeout(() => chrome.runtime.reload(), 200); return false; }
  if (msg.type === 'AMMO_SOCIAL' && sender.id === chrome.runtime.id) { socialOp(msg).then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) })); return true; }
  return false;
});
async function postpone(min) {
  const p = (await chrome.storage.local.get('ammo_update_pending')).ammo_update_pending;
  if (!p) return { ok: false };
  p.applyAt = Date.now() + min * 60000;
  await chrome.storage.local.set({ ammo_update_pending: p });
  chrome.alarms.create('ammo_apply', { when: p.applyAt });
  return { ok: true };
}

// ---------------------------------------------------------------- Gömrük: açıq e.customs tabından idxal hesabatı (İlkin audit — mal qalığı)
async function gmrReport(msg) {
  const tabs = await chrome.tabs.query({ url: 'https://e.customs.gov.az/*' });
  if (!tabs.length) return { ok: false, error: 'no_tab' };
  tabs.sort((a, b) => (b.active - a.active) || ((b.lastAccessed || 0) - (a.lastAccessed || 0)));
  const out = [];
  const from = new Date(msg.from), to = new Date(msg.to);
  for (let y = from.getFullYear(); y <= to.getFullYear(); y++) {
    const a = y === from.getFullYear() ? msg.from : `${y}-01-01`, b = y === to.getFullYear() ? msg.to : `${y}-12-31`;
    let res = null;
    for (const t of tabs) {
      try { res = await chrome.tabs.sendMessage(t.id, { type: 'AMMO_GMR_FETCH', path: 'dictionaries/report?order=0&exportType=xml', method: 'POST', body: { dateFrom: a, dateTo: b, type: '' } }); if (res) break; } catch (e) { /* növbəti tab */ }
    }
    if (!res) return { ok: false, error: 'no_bridge' };
    if (res.status === 401 || res.error === 'login') return { ok: false, error: 'login' };
    out.push({ year: y, text: res.text || '' });
  }
  return { ok: true, parts: out };
}
// ---------------------------------------------------------------- v1.20: Vergi hesabatları → e-taxes-dəki açıq bəyannaməni doldur
async function declFill(payload) {
  const tabs = await chrome.tabs.query({ url: 'https://new.e-taxes.gov.az/eportal/*' });
  if (!tabs.length) return { ok: false, error: 'e-taxes.gov.az açıq deyil. Portala daxil olub bəyannaməni açın, sonra «Doldur» basın.' };
  const score = (t) => {
    const u = (t.url || '').toLowerCase();
    let s = 0;
    if (u.includes('/declaration/')) s += 100;
    if (payload.type === 'profit' && /profit/.test(u)) s += 50;
    if (payload.type === 'income' && /income|gelir/.test(u)) s += 50;
    if (payload.year && u.includes('/' + payload.year)) s += 25;
    if (t.active) s += 5;
    return s + (t.lastAccessed || 0) / 1e13;
  };
  tabs.sort((a, b) => score(b) - score(a));
  const tab = tabs[0];
  if (!/\/declaration\//.test(tab.url || '')) return { ok: false, error: 'e-taxes-də bəyannamə səhifəsi açıq deyil. «Bəyannamələr» bölməsində ' + (payload.type === 'profit' ? 'Mənfəət' : 'Gəlir') + ' vergisinin bəyannaməsini (' + (payload.year || '') + ') açın və yenidən «Doldur» basın.' };
  let res;
  try { res = await chrome.tabs.sendMessage(tab.id, { type: 'AMMO_DECL_FILL_DO', payload }); }
  catch (e) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['lib/decl-maps.js', 'lib/taxrep-forms.js', 'content/decl-fill.js'] }); res = await chrome.tabs.sendMessage(tab.id, { type: 'AMMO_DECL_FILL_DO', payload }); }
    catch (e2) { return { ok: false, error: 'Portal səhifəsi AMMO-ya cavab vermədi. e-taxes tabını yeniləyin (F5) və yenidən cəhd edin.' }; }
  }
  try { await chrome.tabs.update(tab.id, { active: true }); await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) { /* */ }
  return res || { ok: false, error: 'Cavab alınmadı.' };
}

// ---------------------------------------------------------------- v1.20: ƏDV depozit hesabı sorğusunu öyrən (vat-account səhifəsini fonda aç)
async function vatAccLearn(sender) {
  const KEY = 'ammo_vatacc_tpl';
  if ((await chrome.storage.local.get(KEY))[KEY]) return { ok: true };
  const opts = { url: 'https://new.e-taxes.gov.az/eportal/vat-account', active: false };
  if (sender && sender.tab) { opts.windowId = sender.tab.windowId; opts.index = sender.tab.index + 1; }
  const tab = await chrome.tabs.create(opts);
  const ok = await new Promise((resolve) => {
    const t = setTimeout(() => { chrome.storage.onChanged.removeListener(fn); resolve(false); }, 30000);
    function fn(ch, area) { if (area === 'local' && ch[KEY] && ch[KEY].newValue) { clearTimeout(t); chrome.storage.onChanged.removeListener(fn); setTimeout(() => resolve(true), 1500); } }
    chrome.storage.onChanged.addListener(fn);
  });
  try { await chrome.tabs.remove(tab.id); } catch (e) { /* */ }
  return { ok };
}

// Housekeeping: drop stored results older than 2 days
async function cleanup() {
  const all = await chrome.storage.local.get(null);
  const old = Object.entries(all)
    .filter(([k, v]) => /^ammo_(result|print)_/.test(k) && v && v.created && Date.now() - v.created > 2 * 864e5)
    .map(([k]) => k);
  if (old.length) await chrome.storage.local.remove(old);
}

// ---------------------------------------------------------------- v1.16: yükləmələrin tutulması
// Chrome-da sənəd faylı yüklənəndə kiçik pəncərə: «Sənəd dövriyyəsinə göndərilsin?» Bəli / Xeyr.
const DD_WATCH_DEF = { enabled: true, helper: false, exts: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'odt', 'ods', 'rtf', 'adoc', 'edoc', 'asice'] };
let askOpening = false;
chrome.downloads.onChanged.addListener((d) => { if (d.state && d.state.current === 'complete') onDownloadDone(d.id).catch(() => {}); });
async function onDownloadDone(id) {
  const [item] = await chrome.downloads.search({ id });
  if (!item || item.incognito || item.exists === false) return;
  const w = { ...DD_WATCH_DEF, ...((await chrome.storage.local.get('ammo_dd_watch')).ammo_dd_watch || {}) };
  if (!w.enabled) return;
  if (await helperAlive()) return; // Windows köməkçisi işləyir — sualı o verir (iki dəfə soruşulmasın)
  const own = 'chrome-extension://' + chrome.runtime.id;
  if (item.byExtensionId === chrome.runtime.id || [item.url, item.finalUrl, item.referrer].some((u) => u && (u.startsWith(own) || u.startsWith('blob:' + own)))) return; // AMMO-nun öz faylları
  const ext = (String(item.filename).toLowerCase().match(/\.([a-z0-9]+)$/) || [])[1] || '';
  if (!(w.exts || []).includes(ext)) return;
  const q = (await chrome.storage.session.get('ammo_ask_q')).ammo_ask_q || [];
  if (!q.includes(id)) q.push(id);
  await chrome.storage.session.set({ ammo_ask_q: q });
  const base = chrome.runtime.getURL('pages/ask.html');
  let ctx = null;
  try { ctx = (await chrome.runtime.getContexts({ contextTypes: ['TAB'] })).find((c) => c.documentUrl && c.documentUrl.startsWith(base) && !c.documentUrl.includes('go=1')); } catch (e) { /* */ }
  if (ctx) { chrome.runtime.sendMessage({ type: 'AMMO_ASK_SYNC' }).catch(() => {}); chrome.windows.update(ctx.windowId, { focused: true }).catch(() => {}); return; }
  if (askOpening) { chrome.runtime.sendMessage({ type: 'AMMO_ASK_SYNC' }).catch(() => {}); return; } // pəncərə artıq açılır — siyahını özü oxuyacaq
  askOpening = true; setTimeout(() => (askOpening = false), 2500);
  const W = 460, H = 330, o = { url: base, type: 'popup', width: W, height: H, focused: true };
  try {
    const win = await chrome.windows.getLastFocused({ windowTypes: ['normal'] });
    if (win && win.state === 'normal' && win.left != null) { o.left = Math.max(0, win.left + win.width - W - 24); o.top = Math.max(0, win.top + win.height - H - 24); }
  } catch (e) { /* */ }
  try { await chrome.windows.create(o); } catch (e) { delete o.left; delete o.top; await chrome.windows.create(o); } // ekran hüdudlarından kənara düşərsə
}

// ---------------------------------------------------------------- v1.16.1: Windows köməkçisi (bütün brauzerlər və proqramlar)
// Köməkçi 127.0.0.1:47321-də kiçik yerli körpü saxlayır. «Bəli»dən sonra Chrome-da /ammo/open səhifəsini açır,
// content/helper-bridge.js id-ləri bura ötürür, biz faylı körpüdən götürüb Sənəd dövriyyəsi panelinə göndəririk.
const HELPER_PORTS = [47321, 47322, 47323];
let helperCache = { at: 0, port: 0 };
async function helperAlive(fresh) {
  if (!fresh && Date.now() - helperCache.at < 20000) return helperCache.port;
  let port = 0;
  for (const p of HELPER_PORTS) {
    const ac = new AbortController(); const t = setTimeout(() => ac.abort(), 700);
    try { const r = await fetch(`http://127.0.0.1:${p}/ammo/ping`, { cache: 'no-store', signal: ac.signal }); if (r.ok && /^AMMO-OK/.test(await r.text())) { port = p; break; } } catch (e) { /* işləmir */ }
    clearTimeout(t);
  }
  helperCache = { at: Date.now(), port };
  return port;
}
async function helperOpen(msg, sender) {
  const port = HELPER_PORTS.includes(+msg.port) ? +msg.port : 47321;
  let n = 0, err = '';
  for (const id of msg.ids.slice(0, 50)) {
    if (!/^[a-f0-9]{16,64}$/i.test(id)) continue;
    try {
      const r = await fetch(`http://127.0.0.1:${port}/ammo/file?id=${id}`, { cache: 'no-store' });
      if (!r.ok) { err = 'Fayl köməkçidə tapılmadı'; continue; }
      const blob = await r.blob();
      const dec = (v, d) => { try { return v ? decodeURIComponent(v) : d; } catch (e) { return d; } };
      await DD_INBOX.put({ id, name: dec(r.headers.get('X-Ammo-Name'), 'sened'), type: '', blob, at: Date.now(), src: dec(r.headers.get('X-Ammo-Src'), 'Windows') });
      n++;
    } catch (e) { err = String(e && e.message || e); }
  }
  if (n) await routeToPanel(sender.tab ? sender.tab.windowId : null, sender.tab ? sender.tab.id : null);
  else if (sender.tab) return { ok: false, error: err || 'Fayl götürülmədi' };
  if (sender.tab) setTimeout(() => chrome.tabs.remove(sender.tab.id).catch(() => {}), 600);
  return { ok: n > 0, n };
}
/** Sənəd dövriyyəsi panelini önə çıxarır (açıq deyilsə açır) və gələn faylları oxumağı bildirir */
async function routeToPanel(preferWin, replaceTab) {
  const base = chrome.runtime.getURL('pages/dovriyye.html');
  let tab = null;
  try { const c = (await chrome.runtime.getContexts({ contextTypes: ['TAB'] })).find((x) => x.documentUrl && x.documentUrl.startsWith(base)); if (c) tab = { id: c.tabId, windowId: c.windowId }; } catch (e) { /* */ }
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true }).catch(() => {});
    await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
    chrome.runtime.sendMessage({ type: 'AMMO_DD_INBOX' }).catch(() => {});
    return;
  }
  const url = base + '?key=inbox';
  if (replaceTab != null) { try { await chrome.tabs.create({ windowId: preferWin, url, active: true, index: undefined }); await chrome.windows.update(preferWin, { focused: true }); return; } catch (e) { /* */ } }
  const wins = await chrome.windows.getAll({ windowTypes: ['normal'] });
  const w = wins.find((x) => x.focused) || wins[wins.length - 1];
  if (w) { await chrome.tabs.create({ windowId: w.id, url, active: true }); await chrome.windows.update(w.id, { focused: true }); }
  else await chrome.windows.create({ url, type: 'normal', focused: true });
}

// ---------------------------------------------------------------- v1.23: Sosial şəbəkə analizi — tabların idarəsi
const SOC = {
  wa: { url: 'https://web.whatsapp.com/', match: 'https://web.whatsapp.com/*', files: ['content/social-wa.js'] },
  gmail: { url: 'https://mail.google.com/mail/u/0/#inbox', match: 'https://mail.google.com/*', files: ['content/social-gmail.js'] },
  yahoo: { url: 'https://mail.yahoo.com/n/folders/1', match: 'https://mail.yahoo.com/*', files: ['content/social-yahoo.js'] },
  tg: { url: 'https://web.telegram.org/k/', match: 'https://web.telegram.org/*', files: ['content/social-tg.js'] },
};
async function socTab(source, open, idx) {
  const s = SOC[source]; if (!s) throw new Error('naməlum mənbə');
  // v1.23.3: Gmail — hər hesab ayrıca (mail/u/0, u/1, …)
  if (source === 'gmail' && idx != null) {
    const pre = `https://mail.google.com/mail/u/${idx}/`;
    const tabs = (await chrome.tabs.query({ url: 'https://mail.google.com/*' })).filter((t) => (t.url || '').startsWith(pre));
    if (tabs.length) return { tab: tabs[0], fresh: false };
    if (!open) return { tab: null };
    return { tab: await chrome.tabs.create({ url: pre + '#inbox', active: false }), fresh: true };
  }
  let tabs = await chrome.tabs.query({ url: s.match });
  if (source === 'gmail' && tabs.length > 1) tabs.sort((a, b) => (/#inbox/.test(b.url) - /#inbox/.test(a.url)) || ((b.lastAccessed || 0) - (a.lastAccessed || 0)));
  if (tabs.length) return { tab: tabs[0], fresh: false };
  if (!open) return { tab: null };
  const tab = await chrome.tabs.create({ url: s.url, active: false });
  return { tab, fresh: true };
}
/** v1.23.1: tab AMMO quraşdırılmadan / yenilənmədən ƏVVƏL açılıbsa, oxuyucu skript orada yoxdur — özümüz yeridirik (F5 lazım deyil) */
async function socInject(tabId, source) {
  const s = SOC[source]; if (!s || !s.files) return false;
  try { await chrome.scripting.executeScript({ target: { tabId }, files: s.files }); return true; } catch (e) { return false; }
}
async function socSend(tabId, payload, tries = 40, source) {
  let last = null, injected = false;
  for (let i = 0; i < tries; i++) {
    try { const r = await chrome.tabs.sendMessage(tabId, payload); if (r) return r; } catch (e) { last = e; }
    if (!injected && source && i >= 1) { injected = await socInject(tabId, source); if (injected) { await new Promise((r) => setTimeout(r, 800)); continue; } }
    if (i === 12 && source) { try { await chrome.tabs.reload(tabId); injected = false; await new Promise((r) => setTimeout(r, 6000)); } catch (e) { /* */ } }
    await new Promise((r) => setTimeout(r, 1500));
  }
  throw new Error(last ? 'Səhifə AMMO-ya cavab vermədi — həmin saytda daxil olduğunuzu yoxlayın' : 'cavab yoxdur');
}
async function socialOp(msg) {
  const { op, source } = msg;
  if (op === 'status') {
    const out = {};
    for (const k of Object.keys(SOC)) { const { tab } = await socTab(k, false); out[k] = tab ? { open: true, url: tab.url, title: tab.title } : { open: false }; }
    return { ok: true, tabs: out };
  }
  if (op === 'scan') {
    const { tab, fresh } = await socTab(source, true);
    if (fresh) await new Promise((r) => setTimeout(r, 6000));
    const r = await socSend(tab.id, { type: 'AMMO_SOC_SCAN', opts: msg.opts || {} }, fresh ? 60 : 30, source);
    return r;
  }
  if (op === 'tab') {
    // v1.23.2: səhifə tabla özü danışır (xidmət işçisinin 5 dəqiqəlik limiti yoxdur) — burada yalnız tab tapılır və oxuyucu hazırlanır
    const { tab, fresh } = await socTab(source, true, msg.idx);
    try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) { /* */ }
    if (fresh) await new Promise((r) => setTimeout(r, 6000));
    const extra = source === 'gmail' && msg.idx > 0; // əlavə Gmail hesabı yoxdursa — tez imtina
    let r = null;
    try { r = await socSend(tab.id, { type: 'AMMO_SOC_PING' }, extra ? 14 : fresh ? 60 : 30, extra ? null : source); }
    catch (e) { if (extra && fresh) chrome.tabs.remove(tab.id).catch(() => {}); throw e; }
    return { ok: !!(r && r.ok), tabId: tab.id, fresh, url: (r && r.href) || tab.url || '' };
  }
  if (op === 'mail') {
    // v1.24: Thunderbird poçtu (3 hesab) — AMMO-Yenile.exe birbaşa profil fayllarını oxuyur (yalnız oxuma)
    const r = await nativeCall({ action: 'mail_scan', days: +msg.days || 30, max: +msg.max || 1500 }, 240000);
    if (!r || !r.ok) {
      const e = (r && r.error) || 'cavab yoxdur';
      return { ok: false, error: e === 'no_host' ? 'AMMO köməkçisi qeydiyyatda deyil — AMMO qovluğundakı AMMO-Yenile.exe faylını bir dəfə işə salın'  : e === 'no_thunderbird' ? 'Thunderbird profili tapılmadı — Thunderbird quraşdırılıb hesablar əlavə olunmalıdır' : /unknown action|naməlum/i.test(e) ? 'AMMO-Yenile.exe köhnədir — yeni AMMO qovluğundakı AMMO-Yenile.exe faylını bir dəfə işə salın' : e };
    }
    return r;
  }
  if (op === 'open') {
    const { tab } = await socTab(source, true);
    if (source === 'gmail' && msg.ref && /^https:\/\/mail\.google\.com\//.test(msg.ref.url || '')) await chrome.tabs.update(tab.id, { url: msg.ref.url, active: true });
    else { await chrome.tabs.update(tab.id, { active: true }); try { await socSend(tab.id, { type: 'AMMO_SOC_OPEN', ref: msg.ref || {} }, 10, source); } catch (e) { /* tab açıldı, söhbəti əl ilə seçmək olar */ } }
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) { /* */ }
    return { ok: true };
  }
  if (op === 'gmail_token') {
    // Gmail API (yalnız oxuma) — admin panelində Google OAuth Client ID yazılıbsa
    const cid = msg.clientId; if (!cid) return { ok: false, error: 'no_client' };
    const redirect = chrome.identity.getRedirectURL('gmail');
    const url = 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({ client_id: cid, response_type: 'token', redirect_uri: redirect, scope: 'https://www.googleapis.com/auth/gmail.readonly', prompt: msg.prompt || 'select_account', login_hint: msg.hint || '' });
    const back = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
    const p = new URLSearchParams((back.split('#')[1] || ''));
    if (!p.get('access_token')) return { ok: false, error: p.get('error') || 'token alınmadı' };
    return { ok: true, token: p.get('access_token'), expiresIn: +p.get('expires_in') || 3600, redirect };
  }
  return { ok: false, error: 'naməlum əməliyyat' };
}

// ---------------------------------------------------------------- v1.23: AMMO ayarları və iş məlumatı → Firebase (itməsin)
// Sənəd dövriyyəsi öz güzgüsü ilə (lib/dd-cloud.js) yazılır; burada chrome.storage-dakı daimi açarlar: vergi hesabatları,
// gömrük və ƏMAS siyahıları, ƏDV əvəzləşmə ayarları, sənəd hazırla profilləri və s. Yeni kompüterdə avtomatik geri gəlir.
const STORE_NS = 'ammoVergi_store';
const SYNC_RX = /^(ammo_taxrep_|ammo_customs_|ammo_emas_staff_|ammo_evez_(cus|ccd|obl|dep)|ammo_vatacc_tpl$|ammo_dd_watch$|ammo_hf_opts$|sened_|ammo_decl_labels$|ammo_social_pref$|ammo_bank_)/;
let storeDirty = new Set(), storeTimer = null, storeRestoring = false;
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local' || storeRestoring) return;
  let any = false;
  for (const k of Object.keys(ch)) if (SYNC_RX.test(k)) { storeDirty.add(k); any = true; }
  if (ch.ammoAuth && ch.ammoAuth.newValue && !ch.ammoAuth.oldValue) setTimeout(() => storeRestore().catch(() => {}), 1500); // giriş edilən kimi — buluddan bərpa
  if (any) { clearTimeout(storeTimer); storeTimer = setTimeout(storeFlush, 3000); }
});
async function storeFlush() {
  if (!storeDirty.size) return;
  const a = await C.auth().catch(() => null); if (!a) return;
  const keys = [...storeDirty]; storeDirty = new Set();
  const vals = await chrome.storage.local.get(keys);
  const meta = (await chrome.storage.local.get('ammo_store_meta')).ammo_store_meta || {};
  for (const k of keys) {
    try {
      if (vals[k] === undefined) await C.kv.remove(STORE_NS, k, a); else await C.kv.put(STORE_NS, k, vals[k], a);
      meta[k] = new Date().toISOString();
    } catch (e) { storeDirty.add(k); }
  }
  await chrome.storage.local.set({ ammo_store_meta: meta });
  if (storeDirty.size) { clearTimeout(storeTimer); storeTimer = setTimeout(storeFlush, 60000); }
}
async function storeRestore() {
  const a = await C.auth().catch(() => null); if (!a) return { ok: false };
  const all = await C.kv.all(STORE_NS, a);
  const local = await chrome.storage.local.get(null);
  const meta = local.ammo_store_meta || {};
  const set = {}, rm = [];
  for (const [k, rec] of all) {
    if (!SYNC_RX.test(k)) continue;
    const newer = !meta[k] || String(rec.updatedAt) > String(meta[k]);
    if (rec.deleted) { if (newer && k in local) rm.push(k); continue; }
    if (!(k in local) || newer) { set[k] = rec.value; meta[k] = String(rec.updatedAt || new Date().toISOString()); }
  }
  // bu kompüterdə olub buludda olmayanlar — yüklə (ilk keçid)
  Object.keys(local).filter((k) => SYNC_RX.test(k) && !all.has(k)).forEach((k) => storeDirty.add(k));
  storeRestoring = true;
  try { if (Object.keys(set).length) await chrome.storage.local.set(set); if (rm.length) await chrome.storage.local.remove(rm); await chrome.storage.local.set({ ammo_store_meta: meta }); }
  finally { storeRestoring = false; }
  if (storeDirty.size) { clearTimeout(storeTimer); storeTimer = setTimeout(storeFlush, 2000); }
  return { ok: true, restored: Object.keys(set).length };
}
chrome.runtime.onStartup.addListener(() => setTimeout(() => storeRestore().catch(() => {}), 5000));
chrome.runtime.onInstalled.addListener(() => setTimeout(() => storeRestore().catch(() => {}), 5000));
