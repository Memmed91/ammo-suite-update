/* AMMO — e-taxes API client. Runs as a content script on new.e-taxes.gov.az,
 * reusing the session the user is already signed in with. */
(function (root) {
  'use strict';

  const BASE = 'https://new.e-taxes.gov.az/api/po';
  // v1.21.2 — davamlı sorğu qatı:
  //  • eyni anda portala ən çox 2 axtarış (find.*) və 4 digər sorğu gedir — portal paralel sorğularda «Sistemdə xəta baş verdi» (HTTP 500) qaytarır
  //  • vaxt bitdikdə, şəbəkə xətasında, 429 / 500 / 502 / 503 / 504 cavablarında 4 dəfəyədək artan fasilə ilə təkrar
  //  • hər uğursuz sorğu «xəta jurnalına» yazılır (ünvan, status, mesaj) — panelden yüklənə bilər
  const TIMEOUTS_MS = [45000, 70000, 100000, 120000];
  const BACKOFF_MS = [1500, 4000, 9000];
  const RETRY_STATUS = [429, 500, 502, 503, 504];
  const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));

  function token() {
    try { return localStorage.getItem('aztax-jwt'); } catch (e) { return null; }
  }

  class ApiError extends Error {
    constructor(status, message, info) { super(message); this.status = status; if (info) Object.assign(this, info); }
  }

  // ---- sadə semafor
  function limiter(max) {
    let active = 0; const q = [];
    const next = () => { if (active >= max || !q.length) return; active++; const { fn, res, rej } = q.shift(); fn().then(res, rej).finally(() => { active--; next(); }); };
    return (fn) => new Promise((res, rej) => { q.push({ fn, res, rej }); next(); });
  }
  const limFind = limiter(2), limOther = limiter(4);

  // ---- xəta jurnalı (son 40 xəta)
  const ERR_KEY = 'ammo_errlog';
  async function logError(entry) {
    try {
      const o = await chrome.storage.local.get(ERR_KEY);
      const list = (o[ERR_KEY] || []).slice(-39);
      list.push({ at: new Date().toISOString(), page: location.pathname, version: chrome.runtime.getManifest().version, ...entry });
      await chrome.storage.local.set({ [ERR_KEY]: list });
    } catch (e) { /* */ }
  }
  const shortBody = (b) => { try { const o = { ...(b || {}) }; ['kinds', 'statuses', 'types'].forEach((k) => { if (Array.isArray(o[k])) o[k] = o[k].length + ' ədəd'; }); return JSON.stringify(o).slice(0, 600); } catch (e) { return ''; } };

  function request(method, path, body, opts = {}) {
    const lim = /\/find\./.test(path) ? limFind : limOther;
    return lim(() => requestNow(method, path, body, opts));
  }

  async function requestNow(method, path, body, { binary = false, retries } = {}) {
    const t = token();
    if (!t) throw new ApiError(401, 'Sessiya tapılmadı. Zəhmət olmasa e-taxes.gov.az portalına daxil olun.');
    const headers = { Accept: binary ? '*/*' : 'application/json, text/plain, */*', 'x-authorization': 'Bearer ' + t };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const maxAttempts = retries != null ? retries + 1 : TIMEOUTS_MS.length;
    let res, lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), TIMEOUTS_MS[Math.min(attempt, TIMEOUTS_MS.length) - 1]);
      try {
        res = await fetch(BASE + path, {
          method, headers: { ...headers, 'x-authorization': 'Bearer ' + (token() || t) },
          body: body !== undefined ? JSON.stringify(body) : undefined,
          credentials: 'include', signal: ctrl.signal,
        });
        if (RETRY_STATUS.includes(res.status) && attempt < maxAttempts) {
          let m = ''; try { const j = await res.clone().json(); m = (j.message && (j.message.az || j.message.en)) || j.debug || ''; } catch (e) { /* */ }
          lastErr = { status: res.status, msg: m };
          await sleepMs(BACKOFF_MS[Math.min(attempt, BACKOFF_MS.length) - 1]);
          continue;
        }
        lastErr = null;
        break;
      } catch (e) {
        lastErr = { status: 0, msg: e && e.name === 'AbortError' ? 'timeout' : String(e && e.message || e) };
        if (attempt < maxAttempts) { await sleepMs(BACKOFF_MS[Math.min(attempt, BACKOFF_MS.length) - 1]); continue; }
        logError({ method, path: path.slice(0, 200), body: shortBody(body), status: 0, message: lastErr.msg, attempts: attempt });
        throw new ApiError(0, lastErr.msg === 'timeout'
          ? `Portal ${attempt} cəhddə cavab vermədi (vaxt bitdi).`
          : 'Portal ilə əlaqə alınmadı: ' + lastErr.msg, { path });
      } finally {
        clearTimeout(timer);
      }
    }
    if (res.status === 401 || res.status === 403) {
      throw new ApiError(res.status, 'Sessiyanın vaxtı bitib. Portalda yenidən daxil olun (səhifəni yeniləyin).', { path });
    }
    if (!res.ok) {
      let msg = `Server xətası (${res.status})`, raw = '';
      try { raw = await res.text(); const j = JSON.parse(raw); msg = (j.message && (j.message.az || j.message.en)) || j.debug || msg; } catch (e) { /* ignore */ }
      logError({ method, path: path.slice(0, 200), body: shortBody(body), status: res.status, message: msg, response: String(raw).slice(0, 600), attempts: maxAttempts });
      throw new ApiError(res.status, msg, { path });
    }
    if (binary) return res.blob();
    const txt = await res.text();
    return txt ? JSON.parse(txt) : null;
  }

  function firstArray(obj) {
    if (Array.isArray(obj)) return obj;
    if (!obj || typeof obj !== 'object') return [];
    for (const k of ['invoices', 'acts', 'items', 'content', 'data', 'list']) if (Array.isArray(obj[k])) return obj[k];
    for (const v of Object.values(obj)) if (Array.isArray(v)) return v;
    return [];
  }

  // Generic paginator for find.* endpoints (offset / maxCount / hasMore).
  // Portal vaxtında cavab verməsə — həmin səhifə daha kiçik ölçü ilə yenidən istənilir (100 → 50 → 25).
  async function paginate(path, body, onProgress, pageSize = 100) {
    const out = [];
    let offset = 0, size = pageSize;
    for (let guard = 0; guard < 2000; guard++) {
      let res;
      try { res = await request('POST', path, { ...body, offset, maxCount: size }); }
      catch (e) {
        if ((e.status === 0 || e.status >= 500) && size > 25) { size = Math.max(25, Math.floor(size / 2)); guard--; continue; }
        throw e;
      }
      const arr = firstArray(res);
      out.push(...arr);
      if (onProgress) onProgress(out.length);
      const more = res && typeof res.hasMore === 'boolean' ? res.hasMore : arr.length >= size;
      if (!more || !arr.length) break;
      offset += arr.length;
    }
    return out;
  }

  // Exactly the statuses the portal itself sends for incoming/outgoing invoices
  const SITE_STATUSES = ['approved', 'onApproval', 'updateApproval', 'updateRequested', 'cancelRequested',
    'approvedBySystem', 'onApprovalEdited', 'deactivated', 'cancelationRefused', 'correctionRefused'];

  const pad2 = (n) => String(n).padStart(2, '0');
  function yearWindow(y) {
    const now = new Date();
    const from = `01-01-${y} 00:00`;
    let to = `01-01-${y + 1} 00:00`;
    if (y === now.getFullYear()) {
      const t = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      to = `${pad2(t.getDate())}-${pad2(t.getMonth() + 1)}-${t.getFullYear()} 00:00`;
    }
    return { from, to };
  }
  // "dd-MM-yyyy HH:mm" -> Date
  const parseApi = (s) => { const m = /^(\d\d)-(\d\d)-(\d{4})/.exec(s || ''); return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null; };
  const fmtApi = (d) => `${pad2(d.getDate())}-${pad2(d.getMonth() + 1)}-${d.getFullYear()} 00:00`;
  // v1.21.1: [from, to) aralığını AY-AY pəncərələrə böl — portal böyük aralıqda «vaxt bitdi» verir, aylıq sorğular yüngüldür
  function splitByMonth(from, to) {
    const f = parseApi(from), t = parseApi(to);
    if (!f || !t) return [{ from, to }];
    const out = [];
    let cur = f;
    while (cur < t) {
      const next = new Date(cur.getFullYear(), cur.getMonth() + 1, 1);
      const end = next < t ? next : t;
      out.push({ from: fmtApi(cur), to: fmtApi(end) });
      cur = end;
    }
    return out.length ? out : [{ from, to }];
  }
  // v1.21.2: pəncərələr ARDICIL yüklənir. Əvvəl il (portalın öz qaydası — bir təqvim ili), alınmasa həmin il AY-AY,
  // ay da alınmasa — yarım ay. Beləcə həm sürətli, həm də ləng portalda dayanıqlı işləyir.
  function halves(w) {
    const f = parseApi(w.from), t = parseApi(w.to);
    if (!f || !t || t - f <= 864e5 * 2) return null;
    const mid = new Date(f.getTime() + Math.floor((t - f) / 864e5 / 2) * 864e5);
    return [{ from: w.from, to: fmtApi(mid) }, { from: fmtApi(mid), to: w.to }];
  }
  async function byWindows(path, body, from, to, onProgress) {
    let done = 0;
    const out = [];
    const fetchWin = async (w, level) => {
      try {
        const part = await paginate(path, { ...body, creationDateFrom: w.from, creationDateTo: w.to }, (n) => onProgress && onProgress(done + n));
        done += part.length; out.push(...part);
      } catch (e) {
        if (e.status === 401 || e.status === 403) throw e;
        const sub = level === 0 ? splitByMonth(w.from, w.to) : halves(w);
        if (!sub || sub.length < 2 || level >= 2) {
          throw new ApiError(e.status, `${e.message} [${w.from.slice(0, 10)} – ${w.to.slice(0, 10)}]`, { path: e.path || path });
        }
        for (const s2 of sub) await fetchWin(s2, level + 1);
      }
    };
    for (const w of splitByYear(from, to)) await fetchWin(w, 0);
    return out;
  }
  // Split [from, to) into windows that never cross a calendar year
  function splitByYear(from, to) {
    const f = parseApi(from), t = parseApi(to);
    if (!f || !t) return [{ from, to }];
    const out = [];
    let cur = f;
    while (cur < t) {
      const next = new Date(cur.getFullYear() + 1, 0, 1);
      const end = next < t ? next : t;
      out.push({ from: fmtApi(cur), to: fmtApi(end) });
      cur = end;
    }
    return out.length ? out : [{ from, to }];
  }

  const api = {
    token,
    ApiError,

    findInvoices({ direction, statuses, kinds, from, to, tin, serialNumber }, onProgress) {
      const inbox = direction !== 'outbox';
      const body = {
        sortBy: 'creationDate',
        sortAsc: true,
        statuses,
        types: ['current', 'corrected'],
        kinds,
        serialNumber: serialNumber ? [].concat(serialNumber) : null,
        senderTin: inbox ? (tin || null) : null,
        senderName: null,
        productName: null,
        productCode: null,
        receiverTin: inbox ? null : (tin || null),
        receiverName: null,
        creationDateFrom: from,
        creationDateTo: to,
        amountFrom: null,
        amountTo: null,
        actionOwner: null,
      };
      const path = `/invoice/public/v2/invoice/find.${inbox ? 'inbox' : 'outbox'}`;
      return byWindows(path, body, from, to, onProgress).catch(async (e) => {
        // portal bəzi status/növ birləşmələrini qəbul etmir — öz tam siyahısı ilə yenidən istə, sonra süz
        const full = statuses && statuses.length && SITE_STATUSES.some((x) => !statuses.includes(x));
        if (!(e.status >= 500 || e.status === 400) || !full) throw e;
        const all = await byWindows(path, { ...body, statuses: SITE_STATUSES }, from, to, onProgress);
        return all.filter((i) => statuses.includes(i.status));
      });
    },

    findReturnInvoices({ statuses, from, to, tin }, onProgress) {
      const body = {
        statuses,
        types: ['current', 'corrected'],
        kinds: ['mtkInvoice'],
        serialNumber: null,
        senderTin: null,
        senderName: null,
        receiverFin: tin || null,
        receiverName: null,
        creationDateFrom: from,
        creationDateTo: to,
        amountFrom: null,
        amountTo: null,
        sortAsc: true,
        sortBy: 'creationDate',
        amountType: 'from-to',
      };
      return byWindows('/invoice/public/v3/invoice/find.outbox', body, from, to, onProgress);
    },

    findActs({ statuses, kinds, from, to }, onProgress) {
      const body = {
        sortBy: 'creationDate',
        sortAsc: true,
        statuses,
        types: ['current', 'corrected'],
        serialNumber: null,
        sellerFin: null,
        sellerName: null,
        productName: null,
        productCode: null,
        kinds,
        creationDateFrom: from,
        creationDateTo: to,
        amountFrom: null,
        amountTo: null,
        phoneNumber: null,
      };
      return byWindows('/invoice/public/v1/act/find.sent', body, from, to, onProgress);
    },

    invoiceDetail(id, sourceSystem) {
      const q = sourceSystem ? `?sourceSystem=${encodeURIComponent(sourceSystem)}` : '';
      return request('GET', `/invoice/public/v2/invoice/${encodeURIComponent(id)}${q}`);
    },

    // Find an invoice by its serial number in both inbox and outbox.
    async findBySerial(serial, onStep) {
      // The portal only accepts its own status list and a date window inside one calendar year.
      const statuses = SITE_STATUSES;
      const kinds = AMMO_DICT.INVOICE_KINDS.map((k) => k[0]);
      const digits = String(serial).replace(/\D/g, '');
      const yy = 2000 + Number(digits.slice(0, 2));
      const mm = Number(digits.slice(2, 4));
      const now = new Date();
      const thisYear = now.getFullYear();
      const startYear = isFinite(yy) && yy >= 2019 && yy <= thisYear ? yy : thisYear;

      // Windows to try, smallest first: serial month (−1 … +1 month, same year), then whole years
      const windows = [];
      if (mm >= 1 && mm <= 12) {
        const f = new Date(startYear, Math.max(0, mm - 2), 1);
        let t = new Date(startYear, Math.min(12, mm + 1), 1);
        const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
        if (t > tomorrow) t = tomorrow;
        if (f < t) windows.push({ from: fmtApi(f), to: fmtApi(t), label: `${pad2(mm)}.${startYear}` });
      }
      [startYear, startYear + 1, startYear - 1].filter((y) => y >= 2019 && y <= thisYear)
        .forEach((y) => windows.push({ ...yearWindow(y), label: String(y) }));

      let lastErr = null;
      for (const w of windows) {
        for (const direction of ['inbox', 'outbox']) {
          if (onStep) onStep(`${serial}: ${direction === 'inbox' ? 'gələnlər' : 'göndərilənlər'}, ${w.label}`);
          let res;
          try {
            res = await request('POST', `/invoice/public/v2/invoice/find.${direction}`, {
              sortBy: 'creationDate', sortAsc: true, statuses, types: ['current', 'corrected'], kinds,
              serialNumber: [serial], senderTin: null, senderName: null, productName: null, productCode: null,
              receiverTin: null, receiverName: null, creationDateFrom: w.from, creationDateTo: w.to,
              amountFrom: null, amountTo: null, offset: 0, maxCount: 10, actionOwner: null,
            });
          } catch (e) {
            if (e.status === 401 || e.status === 403 || e.status === 0) throw e;
            lastErr = e; continue;
          }
          const hit = firstArray(res).filter((i) => i.serialNumber === serial);
          if (hit.length) {
            hit.sort((a, b) => (b.version || 0) - (a.version || 0));
            return { ...hit[0], _direction: direction };
          }
        }
      }
      if (lastErr) throw lastErr;
      return null;
    },

    declarations(year) {
      return request('GET', `/declaration/public/v1/declaration/list?year=${encodeURIComponent(year)}`)
        .then((r) => (r && r.declarations) || firstArray(r));
    },

    // Bəyannamənin bütün rəqəmləri (TaxPro da bunu oxuyur)
    async declarationBase(regNumber) {
      const res = await request('GET', `/declaration/public/v1/base?reg_number=${encodeURIComponent(regNumber)}`);
      try { return JSON.parse((res && res.baseJson) || '{}'); } catch (e) { return {}; }
    },

    // Bəyannamə əlavələrinin siyahıları (məs. UNIFIED_APPENDIX_1_EMPLOYEE_LIST)
    async declarationCalc(name, regNumber, extraQuery = '') {
      const out = [];
      let offset = 0;
      for (let guard = 0; guard < 50; guard++) {
        const res = await request('GET', `/declaration/public/v1/calc/${name}?reg_number=${encodeURIComponent(regNumber)}&offset=${offset}&maxCount=1000${extraQuery}`);
        let part = [];
        try { part = JSON.parse((res && res.calcPartJson) || '[]') || []; } catch (e) { part = []; }
        out.push(...part);
        if (!res || !res.hasMore || !part.length) break;
        offset += part.length;
      }
      return out;
    },

    // ƏDV bəyannaməsinin Əlavə 1 (əvəzləşdirmə üçün elektron qaimələr) sətirləri
    async vatAppendix1(regNumber) {
      const out = [];
      let offset = 0;
      for (let guard = 0; guard < 50; guard++) {
        const res = await request('GET', `/declaration/public/v1/calc/VAT_APPENDIX_1_REPORT_PERIOD_INVOICE?reg_number=${encodeURIComponent(regNumber)}&offset=${offset}&maxCount=1000`);
        let part = [];
        try { part = JSON.parse((res && res.calcPartJson) || '[]') || []; } catch (e) { part = []; }
        out.push(...part);
        if (!res || !res.hasMore || !part.length) break;
        offset += part.length;
      }
      return out;
    },

    // Portalın istənilən /api/po sorğusu (ƏDV depozit hesabı üçün öyrənilmiş sorğu təkrarlanır)
    raw(method, pathOrUrl, body) {
      const path = String(pathOrUrl).replace(/^https:\/\/new\.e-taxes\.gov\.az/, '').replace(/^\/api\/po(?=\/)/, '');
      if (!path.startsWith('/')) throw new ApiError(0, 'Yanlış ünvan');
      return request(method, path, body === null ? undefined : body);
    },

    declarationPdf(id) {
      return request('GET', `/declaration/public/v1/declarations/${encodeURIComponent(id)}/print`, undefined, { binary: true });
    },

    // ---------------------------------------------------------------- v1.23: portalın öz API-ləri (yalnız OXUMA)
    // Şirkət profili — portalın «Profil» səhifəsinin istifadə etdiyi ünvanlar (səhifəni açmağa ehtiyac yoxdur)
    profile() { return request('GET', '/profile/public/v2/profile', undefined, { retries: 1 }).then((r) => (r && r.profile) || r); },
    profileList(kind) { return request('GET', `/profile/public/v1/profile/${encodeURIComponent(kind)}/list`, undefined, { retries: 1 }); },
    branches() { return request('GET', '/profile/public/v1/branches', undefined, { retries: 1 }); },
    objects() { return request('GET', '/profile/public/v1/object/list', undefined, { retries: 1 }); },
    profileListV2(kind, body) { return request('POST', `/profile/public/v2/profile/${encodeURIComponent(kind)}/list`, body || { offset: 0, maxCount: 200 }, { retries: 1 }); },
    // Borclar: vergi və sosial öhdəliklər (şəxsi hesab vərəqəsinin yekunları)
    liabilities() { return request('GET', '/budget/public/v1/liabilities', undefined, { retries: 1 }); },
    liabilitiesTotal() { return request('GET', '/budget/public/v1/liabilities/total', undefined, { retries: 1 }); },
    // Məktublar (vergi orqanından gələnlər)
    unreadCount() { return request('GET', '/edi/public/v1/message/countUnread', undefined, { retries: 1 }); },
    async messages({ from, to, unreadOnly = null, max = 1000, kind = 'taxauthority' } = {}) {
      const out = [];
      for (let offset = 0; offset < max; offset += 100) {
        const r = await request('POST', '/edi/public/v1/message/find.inbox', {
          offset, maxCount: 100, containsText: '', categoryCodes: [], docGroups: null, unreadOnly, registerNumber: null, withActionOnly: null, withAttachmentsOnly: null,
          startDate: from, endDate: to, correspondent: kind ? { kind, tin: null, taxAuthorityCode: null, name: null, fin: null } : null,
        }, { retries: 1 });
        const part = (r && r.messages) || [];
        out.push(...part);
        if (!r || !r.hasMore || !part.length) break;
      }
      return out;
    },
    // Bəyannamə yaratmaq (yalnız QARALAMA — təqdim edilmir, imzalanmır) və qaralamanı silmək
    taxTermTypes(taxCode) { return request('GET', `/declaration/public/v1/dictionary/taxCode/${encodeURIComponent(taxCode)}/taxTermTypes`); },
    registerDraft({ taxCode, year, month, periodType, declarationType = 'CURRENT' }) {
      const reportingPeriod = periodType === 'YEAR' ? { year, type: periodType } : { month, year, type: periodType };
      return request('POST', '/declaration/public/v1/register', { declarationType, reportingPeriod, taxCode }, { retries: 1 });
    },
    // v1.23.1: boş (yeni) bəyannamənin portalın özünün avtomatik doldurduğu xanaları (məs. sadələşdirilmiş: 801–804 bank/POS daxilolmaları)
    async prefillData(regNumber) {
      const arr = await request('GET', `/declaration/public/v1/prefillData?reg_number=${encodeURIComponent(regNumber)}`);
      const out = {};
      for (const x of Array.isArray(arr) ? arr : []) { try { out[x.id] = JSON.parse(x.json || 'null'); } catch (e) { out[x.id] = null; } }
      return out;
    },
    deleteDraft(id) { return request('DELETE', `/declaration/public/v1/declaration/${encodeURIComponent(id)}`, undefined, { retries: 1 }); },
    // Elektron alış aktının sətirləri (mal qalığı üçün)
    actDetail(id, sourceSystem) { return request('GET', `/invoice/public/v1/act/${encodeURIComponent(id)}?sourceSystem=${encodeURIComponent(sourceSystem || '')}`); },
  };

  // Run async jobs with limited concurrency
  api.pool = async function pool(items, limit, fn, onProgress) {
    const results = new Array(items.length);
    let i = 0, done = 0;
    const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
      while (i < items.length) {
        const idx = i++;
        try { results[idx] = await fn(items[idx], idx); } catch (e) { results[idx] = { __error: e }; }
        done++;
        if (onProgress) onProgress(done, items.length);
      }
    });
    await Promise.all(workers);
    return results;
  };

  root.AMMO_API = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
