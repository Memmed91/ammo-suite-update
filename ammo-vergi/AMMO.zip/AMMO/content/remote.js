/* AMMO v1.25 — Uzaqdan əmrlər (AMMO Mobil): telefondan verilən e-taxes əmrlərini bu kabinetdə icra edir.
 *  • Fon skripti (background.js) Firestore-dakı «remoteCommands»-dan yeni əmri götürür, VÖEN-i bu tabdakı
 *    kabinetlə uyğun gəlirsə, əmri bu skriptə ötürür. Nəticə birbaşa həmin sənədə yazılır və telefonda görünür.
 *  • YALNIZ OXUMA: profil, borclar, məktublar, bəyannamə siyahısı, 804 (daxil olan pullar), tam audit.
 *    Heç nə təqdim edilmir, imzalanmır. 804 üçün (İlkin auditdəki kimi) köməkçi qaralama yaradılıb dərhal silinə bilər.
 *  • Yalnız admin hesabının (memmed@ammo.az) yaratdığı əmrlər icra olunur — Firestore qaydaları bunu təmin edir. */
(function (root) {
  'use strict';
  if (window.top !== window || root.__AMMO_REMOTE__) return;
  root.__AMMO_REMOTE__ = true;

  const OPS = new Set(['profile', 'debts', 'mail', 'declarations', 'cash804', 'audit']);
  const pad = (x) => String(x).padStart(2, '0');
  const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
  const r2 = (v) => Math.round((Number(v) || 0) * 100) / 100;
  let busy = false, nameCache = { tin: '', name: '' };

  const tinNow = () => { try { return root.AMMO_EVEZ_PORTAL ? String(root.AMMO_EVEZ_PORTAL.ownTin() || '') : ''; } catch (e) { return ''; } };
  async function companyName() {
    const t = tinNow();
    if (nameCache.tin === t && nameCache.name) return nameCache.name;
    try {
      const p = await root.AMMO_API.profile();
      const n = (p && (p.companyName || p.individualName || p.name || p.fullName)) || '';
      nameCache = { tin: t, name: typeof n === 'object' ? (n.az || n.en || '') : String(n) };
    } catch (e) { /* sessiya bitib */ }
    return nameCache.name;
  }

  // obyektin qısa, oxunaqlı forması (portal sahələrinin adları dəyişsə də işləsin)
  const txt = (v) => (v == null ? '' : typeof v === 'object' ? (v.az || v.en || v.name || v.value || '') : v);
  function brief(o, max = 8) {
    if (!o || typeof o !== 'object') return o;
    const out = {};
    for (const [k, v] of Object.entries(o)) {
      if (Object.keys(out).length >= max) break;
      if (/(^id$|Id$|uuid|hash|json|^_)/i.test(k)) continue;
      const t = txt(v);
      if (t === '' || t == null || typeof t === 'object') continue;
      out[k] = typeof t === 'string' ? t.slice(0, 160) : t;
    }
    return out;
  }
  const briefList = (arr, n = 60) => (Array.isArray(arr) ? arr.slice(0, n).map((x) => brief(x)) : []);

  async function exec(op, p, step) {
    const API = root.AMMO_API, A2 = root.AMMO_AUDIT2, ST = root.AMMO_STOCK;
    if (!API || !A2) throw new Error('AMMO modulları yüklənməyib — səhifəni yeniləyin (F5)');
    if (!API.token()) throw Object.assign(new Error('e-taxes sessiyası yoxdur'), { status: 401 });
    const today = todayISO();
    const year = Number(p.year) || new Date().getFullYear();
    const base = { tin: tinNow(), company: await companyName(), at: Date.now() };

    if (op === 'profile') {
      step('Profil oxunur…');
      const pr = await A2.readProfile(API);
      return { ...base, main: brief(pr.main, 30), obligations: briefList(pr.obligations), banks: briefList(pr.banks), licenses: briefList(pr.licenses), branches: briefList(pr.branches, 30), objects: briefList(pr.objects, 30), cash: briefList(pr.cash, 30), pos: briefList(pr.pos, 30), errors: pr.errors || {} };
    }
    if (op === 'debts') { step('Şəxsi hesab oxunur…'); return { ...base, ...(await A2.readDebts(API)) }; }
    if (op === 'mail') {
      step('Məktublar oxunur…');
      const m = await A2.readMail(API, today);
      return { ...base, unread: m.unread, unreadTp: m.unreadTp, total: m.total, list: (m.list || []).slice(0, 120), error: m.error || '' };
    }
    if (op === 'declarations') {
      step(`${year}-ci il bəyannamələri…`);
      const list = ((await API.declarations(year)) || []).map(A2.normDecl)
        .sort((a, b) => a.taxCode.localeCompare(b.taxCode) || (a.year - b.year) || (a.month - b.month));
      return { ...base, year, list };
    }
    if (op === 'cash804') {
      step('Bəyannamə siyahısı…');
      const decls = ((await API.declarations(year)) || []).map(A2.normDecl);
      const notes = [];
      const list = await A2.cash804(API, [year], decls, today, {}, step, notes);
      return { ...base, year, list, notes };
    }
    if (op === 'audit') {
      const res = await A2.collect({ mode: 'year', year, fullStock: true, vat: false }, step);
      step('Mal qalığı hesablanır…');
      let stock = [], stockValue = 0, stockCount = 0;
      try {
        const mv = (res.moves || []).map((m) => ({ d: m[0], dir: m[1], key: m[2], code: m[3], name: m[4], unit: m[5], q: m[6], cost: m[7], doc: m[8], party: m[9], svc: !!m[10] }));
        const bal = ST.balance(mv, res.period && res.period.toISO).filter((x) => !x.svc && x.rest > 1e-9);
        stockCount = bal.length; stockValue = r2(bal.reduce((s, x) => s + Math.max(0, x.restV), 0));
        stock = bal.slice(0, 100).map((x) => ({ code: x.code, name: x.name, unit: x.unit, rest: r2(x.rest), restV: r2(x.restV), avg: r2(x.avg) }));
      } catch (e) { (res.notes = res.notes || []).push('Mal qalığı hesablanmadı: ' + e.message); }
      const a = res.audit || {};
      return {
        ...base, company: res.company || base.company, tin: res.tin || base.tin, period: res.period,
        audit: { income: a.income, expenseTotal: a.expenseTotal, profit: a.profit, tax: a.tax, counts: a.counts, payroll: a.payroll, months: a.months, customers: a.customers, suppliers: a.suppliers },
        debts: res.debts ? { totals: res.debts.totals, asOf: res.debts.asOf } : null,
        mailUnread: res.mail ? res.mail.unread : null,
        missing: (res.missing || []).slice(0, 80),
        stock, stockValue, stockCount,
        cash: (res.cash || []).map((x) => ({ year: x.year, q: x.q, v804: x.v804, src: x.src })),
        notes: (res.notes || []).slice(0, 20),
      };
    }
    throw new Error('Naməlum əməliyyat: ' + op);
  }

  async function run({ id, op, params }) {
    const C = root.AMMO_CLOUD;
    const path = `remoteCommands/${encodeURIComponent(id)}`;
    let last = 0;
    const step = (t) => { if (Date.now() - last < 4000) return; last = Date.now(); C.fs.merge(path, { progress: String(t || '').slice(0, 200) }).catch(() => {}); };
    try {
      if (!OPS.has(op)) throw new Error('İcazəsiz əməliyyat');
      const res = await exec(op, params || {}, step);
      let json = JSON.stringify(res);
      if (json.length > 900000) { // Firestore sənəd limiti — böyük siyahıları qısalt
        ['list', 'stock', 'missing', 'obligations', 'objects'].forEach((k) => { if (Array.isArray(res[k])) res[k] = res[k].slice(0, 40); });
        if (res.audit) { delete res.audit.months; delete res.audit.customers; delete res.audit.suppliers; }
        json = JSON.stringify(res).slice(0, 900000);
      }
      await C.fs.merge(path, { status: 'done', result: json, finishedAt: new Date(), progress: '' });
    } catch (e) {
      const msg = e && (e.status === 401 || e.status === 403) ? 'e-taxes sessiyası bitib və ya icazə yoxdur — kabinetə yenidən daxil olun' : String((e && e.message) || e);
      await C.fs.merge(path, { status: 'error', error: msg.slice(0, 500), finishedAt: new Date(), progress: '' }).catch(() => {});
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || sender.id !== chrome.runtime.id) return false;
    if (msg.type === 'AMMO_REMOTE_WHO') {
      companyName().then((name) => sendResponse({ ok: true, tin: tinNow(), name, busy }), () => sendResponse({ ok: true, tin: tinNow(), name: '', busy }));
      return true;
    }
    if (msg.type === 'AMMO_REMOTE_RUN') {
      if (busy) { sendResponse({ ok: false, error: 'busy' }); return false; }
      if (msg.tin && String(msg.tin) !== tinNow()) { sendResponse({ ok: false, error: 'tin_mismatch' }); return false; }
      busy = true; sendResponse({ ok: true });
      run(msg).finally(() => { busy = false; });
      return false;
    }
    return false;
  });
})(typeof globalThis !== 'undefined' ? globalThis : this);
