/* AMMO — Sosial şəbəkə analizi: Gmail (mail.google.com) oxuyucu (v1.23).
 * Gələnlər qutusunun siyahısını oxuyur: kimdən, mövzu, qısa mətn, tarix, oxunub-oxunmayıb, sonuncu yazan sizsinizmi.
 * Heç nə yazmır/göndərmir. Daha dəqiq analiz üçün admin panelində Gmail API (yalnız oxuma) qoşmaq olar. */
(function () {
  'use strict';
  if (window.top !== window) return;
  // v1.23.1: genişlənmə yeniləndikdən sonra açıq tabda skript yenidən yeridilir — yalnız SON yeridilən nüsxə cavab verir
  const TOK = Math.random().toString(36).slice(2);
  window.__AMMO_GM_TOK = TOK;
  const live = () => window.__AMMO_GM_TOK === TOK;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const T = (el) => (el ? (el.innerText || el.textContent || '').trim() : '');
  const vis = (el) => !!(el && (el.offsetParent !== null || el.getClientRects().length));
  const acct = () => (/\/mail\/u\/(\d+)/.exec(location.pathname) || [, '0'])[1];
  function me() {
    const m = /([\w.+-]+@[\w-]+\.[\w.-]+)/.exec(document.title || '');
    if (m) return m[1].toLowerCase();
    const a = document.querySelector('a[aria-label*="@"][href*="SignOutOptions"], a[aria-label*="@"][href*="accounts.google.com"]');
    const m2 = a && /([\w.+-]+@[\w-]+\.[\w.-]+)/.exec(a.getAttribute('aria-label') || '');
    return m2 ? m2[1].toLowerCase() : '';
  }
  function readRows(myEmail) {
    return [...document.querySelectorAll('tr.zA')].filter(vis).map((r) => {
      const ps = [...r.querySelectorAll('.yW span[email], .yW span[name], .yX span[email]')].map((n) => ({ email: (n.getAttribute('email') || '').toLowerCase(), name: n.getAttribute('name') || T(n) }));
      const isMe = (p) => (p.email && p.email === myEmail) || /^(me|mən|men|я|ich|moi)$/i.test(p.name || '');
      const last = ps[ps.length - 1];
      const tidEl = r.querySelector('[data-legacy-thread-id]') || r.querySelector('[data-thread-id]');
      let tid = tidEl ? (tidEl.getAttribute('data-legacy-thread-id') || (tidEl.getAttribute('data-thread-id') || '').replace(/^#?thread-f:/, '')) : '';
      const date = (r.querySelector('td.xW span[title], .xW span[title], .apt span[title]') || {}).title || '';
      const subject = T(r.querySelector('.bog, .bqe, span[data-thread-id]'));
      const snippet = T(r.querySelector('.y2')).replace(/^[\s\u2013\u2014-]+/, '');
      const count = parseInt(T(r.querySelector('.bx0')), 10) || 1;
      const sender = (ps.find((p) => !isMe(p)) || last || {});
      return { tid, subject, snippet, date, unread: r.classList.contains('zE'), participants: ps.map((p) => p.name || p.email), lastDir: last && isMe(last) ? 'out' : 'in', replied: ps.some(isMe), sender: sender.name || sender.email || '', senderEmail: sender.email || '', count };
    });
  }
  const parseDate = (s) => { const t = Date.parse(String(s).replace(/,?\s+at\s+/i, ' ')); return isFinite(t) ? new Date(t).toISOString() : ''; };
  async function waitRows(prevKey) {
    for (let i = 0; i < 40; i++) { await sleep(400); const r = [...document.querySelectorAll('tr.zA')].filter(vis); const k = r.slice(0, 3).map((x) => x.id).join(); if (r.length && k !== prevKey) return k; if (document.querySelector('td.TC') && i > 6) return ''; }
    return '';
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!live()) return false;
    if (!msg || sender.id !== chrome.runtime.id) return false;
    if (msg.type === 'AMMO_SOC_PING') { sendResponse({ ok: true, href: location.href }); return false; }
    if (msg.type === 'AMMO_SOC_SCAN') {
      (async () => {
        const o = msg.opts || {};
        for (let i = 0; i < 30 && !document.querySelector('div[role="main"]'); i++) await sleep(1000);
        if (!document.querySelector('div[role="main"]')) return { ok: false, error: 'Gmail açılmadı — hesaba daxil olun' };
        const my = me();
        const origHash = location.hash;
        const q = `in:inbox newer_than:${o.days || 30}d -category:promotions -category:social -category:forums`;
        let key = [...document.querySelectorAll('tr.zA')].filter(vis).slice(0, 3).map((x) => x.id).join();
        location.hash = '#search/' + encodeURIComponent(q).replace(/%20/g, '+');
        key = await waitRows(key);
        const all = new Map();
        for (let page = 0; page < (o.pages || 4); page++) {
          readRows(my).forEach((r) => { const k = r.tid || r.subject + r.date; if (!all.has(k)) all.set(k, r); });
          const older = [...document.querySelectorAll('div[role="button"][aria-label]')].find((b) => /older|köhnə|daha köhnə|старые|следующ/i.test(b.getAttribute('aria-label')) && b.getAttribute('aria-disabled') !== 'true' && vis(b));
          if (!older) break;
          ['mousedown', 'mouseup', 'click'].forEach((t) => older.dispatchEvent(new MouseEvent(t, { bubbles: true })));
          key = await waitRows(key); if (!key) break;
        }
        if (o.restore !== false) location.hash = origHash || '#inbox';
        const threads = [...all.values()].map((r) => ({
          source: 'gmail', chat: r.sender || r.participants.join(', '), subject: r.subject, unread: r.unread ? 1 : 0, lastDir: r.lastDir, at: parseDate(r.date), dateText: r.date,
          preview: (r.subject ? r.subject + ' — ' : '') + r.snippet, link: r.tid ? `https://mail.google.com/mail/u/${acct()}/#inbox/${r.tid}` : '', ref: { tid: r.tid }, replied: r.replied, count: r.count, email: r.senderEmail, messages: [],
        }));
        return { ok: true, source: 'gmail', account: my, threads };
      })().then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
      return true;
    }
    if (msg.type === 'AMMO_SOC_OPEN') { if (msg.ref && msg.ref.tid) location.hash = '#inbox/' + msg.ref.tid; sendResponse({ ok: true }); return false; }
    return false;
  });
})();
