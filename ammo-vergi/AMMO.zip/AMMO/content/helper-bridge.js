/* AMMO — Windows köməkçisi ilə körpü (v1.16.1).
 * Köməkçi «Bəli»dən sonra Chrome-da http://127.0.0.1:47321/ammo/open?ids=… səhifəsini açır.
 * Bu skript id-ləri AMMO-nun fon prosesinə ötürür: o, faylları köməkçidən götürüb Sənəd dövriyyəsi panelinə göndərir. */
(() => {
  if (location.hostname !== '127.0.0.1' || !/^\/ammo\/open/.test(location.pathname)) return;
  const ids = (new URLSearchParams(location.search).get('ids') || '').split(',').filter((x) => /^[a-f0-9]{16,64}$/i.test(x));
  if (!ids.length) return;
  const show = (t) => { const el = document.getElementById('st'); if (el) el.textContent = t; };
  show('AMMO faylı qəbul edir…');
  chrome.runtime.sendMessage({ type: 'AMMO_HELPER_OPEN', ids, port: location.port || '47321' }, (r) => {
    if (chrome.runtime.lastError) { show('⚠️ ' + chrome.runtime.lastError.message); return; }
    show(r && r.ok ? `✅ ${r.n} fayl Sənəd dövriyyəsinə göndərildi` : '⚠️ ' + ((r && r.error) || 'Fayl götürülmədi'));
  });
})();
