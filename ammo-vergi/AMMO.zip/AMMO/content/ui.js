/* AMMO — "Vergi xidmətləri" modal injected into new.e-taxes.gov.az */
(function () {
  'use strict';
  if (window.__AMMO_LOADED__) return;
  window.__AMMO_LOADED__ = true;

  const D = AMMO_DICT;
  const API = AMMO_API;
  const X = AMMO_XLSX;

  // ------------------------------------------------------------------ helpers
  function h(tag, attrs, ...children) {
    const el = document.createElement(tag);
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v === undefined || v === null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'style') el.style.cssText = v;
        else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (k === 'checked' || k === 'value' || k === 'disabled' || k === 'selected') el[k] = v;
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    for (const c of children.flat(Infinity)) {
      if (c === null || c === undefined || c === false) continue;
      el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
    }
    return el;
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const foldAz = (x) => String(x || '').toLocaleLowerCase('az').replace(/ə/g, 'e').replace(/ö/g, 'o').replace(/ü/g, 'u').replace(/ı/g, 'i').replace(/i̇/g, 'i').replace(/ç/g, 'c').replace(/ğ/g, 'g').replace(/ş/g, 's').trim();
  const todayISO = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
  const yearStartISO = () => `${new Date().getFullYear()}-01-01`;
  const yearEndISO = () => `${new Date().getFullYear()}-12-31`;
  const stamp = () => { const d = new Date(); const p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`; };

  function statusBox() {
    const el = h('div', { class: 'status' });
    el.set = (kind, text) => { el.className = 'status show ' + kind; el.textContent = text; if (kind === 'info') el.lastStep = text; };
    el.clear = () => { el.className = 'status'; el.textContent = ''; el.lastStep = ''; };
    return el;
  }
  // v1.21.2: xəta jurnalını yüklə (portal hansı sorğuya hansı cavabı verib — diaqnostika üçün)
  async function downloadErrLog() {
    const o = await chrome.storage.local.get('ammo_errlog');
    const blob = new Blob([JSON.stringify({ version: chrome.runtime.getManifest().version, at: new Date().toISOString(), errors: o.ammo_errlog || [] }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `AMMO_xeta_hesabati_${stamp()}.json`;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }

  async function runButton(btn, status, fn) {
    if (btn.disabled) return;
    const old = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Gözləyin...';
    try {
      await fn();
    } catch (e) {
      console.error('[AMMO]', e);
      const step = status.lastStep ? `\nMərhələ: ${status.lastStep}` : '';
      const st = e && e.status ? ` (HTTP ${e.status})` : '';
      const hint = e && (e.status >= 500 || e.status === 0) ? '\nPortal müvəqqəti xəta verdi — AMMO sorğunu bir neçə dəfə, kiçik hissələrlə təkrarladı. Bir neçə dəqiqə sonra yenidən basın.' : '';
      status.set('bad', (e && e.message ? e.message : String(e)) + st + step + hint);
      status.appendChild(h('div', { style: 'margin-top:6px' }, h('a', { href: '#', onclick: (ev) => { ev.preventDefault(); downloadErrLog(); } }, 'Xəta hesabatını yüklə (AMMO dəstəyinə göndərin)')));
    } finally {
      btn.disabled = false;
      btn.textContent = old;
    }
  }

  // Deliver a tabular result: Excel download, or open the AMMO result tab
  async function deliver({ title, fileBase, sheets, excel, meta }) {
    if (excel) {
      X.download(sheets, `${fileBase}_${stamp()}.xlsx`);
      return 'Excel faylı yükləndi.';
    }
    const key = 'ammo_result_' + Date.now();
    await chrome.storage.local.set({ [key]: { title, fileBase, sheets, meta: meta || {}, created: Date.now() } });
    await chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/result.html', key });
    return 'Nəticə yeni tabda açıldı.';
  }

  // ------------------------------------------------------------------ widgets
  // Status selector: dropdown + removable chips
  function statusPicker(list, placeholder) {
    const selected = new Set(list.filter((s) => s[2]).map((s) => s[0]));
    const chips = h('div', { class: 'chips' });
    const select = h('select', {
      onchange: () => {
        if (select.value === '__all') list.forEach((s) => selected.add(s[0]));
        else if (select.value) selected.add(select.value);
        select.value = '';
        render();
      },
    });
    function render() {
      select.innerHTML = '';
      select.appendChild(h('option', { value: '' }, placeholder || '-- Seçin --'));
      const rest = list.filter((s) => !selected.has(s[0]));
      if (rest.length > 1) select.appendChild(h('option', { value: '__all' }, '★ Hamısını seç'));
      rest.forEach((s) => select.appendChild(h('option', { value: s[0] }, s[1])));
      chips.innerHTML = '';
      list.filter((s) => selected.has(s[0])).forEach((s) => {
        chips.appendChild(h('span', { class: 'chip' }, s[1],
          h('button', { title: 'Sil', onclick: () => { selected.delete(s[0]); render(); } }, '×')));
      });
    }
    render();
    return { el: h('div', null, select, h('label', { class: 'lbl' }, 'Seçilmiş statuslar:'), chips), get: () => [...selected] };
  }

  // Kind selector: search + checkbox list with "Bütün növlər"
  function kindPicker(list) {
    const boxes = list.map((k) => {
      const cb = h('input', { type: 'checkbox', checked: true, onchange: syncAll });
      const row = h('label', null, cb, h('span', null, k[1]));
      return { code: k[0], text: k[1].toLowerCase(), cb, row };
    });
    const all = h('input', { type: 'checkbox', checked: true, onchange: () => boxes.forEach((b) => { b.cb.checked = all.checked; }) });
    function syncAll() { all.checked = boxes.every((b) => b.cb.checked); }
    const search = h('input', {
      type: 'text', placeholder: 'Axtar...',
      oninput: () => {
        const q = search.value.trim().toLowerCase();
        boxes.forEach((b) => { b.row.style.display = !q || b.text.includes(q) ? '' : 'none'; });
      },
    });
    const box = h('div', { class: 'kinds' }, h('label', null, all, h('span', null, 'Bütün növlər')), boxes.map((b) => b.row));
    return { el: h('div', null, search, box), get: () => boxes.filter((b) => b.cb.checked).map((b) => b.code) };
  }

  function dateRange(fromDefault, toDefault) {
    const from = h('input', { type: 'date', value: fromDefault || '' });
    const to = h('input', { type: 'date', value: toDefault || '' });
    const el = h('div', null, h('label', { class: 'lbl' }, 'Tarix intervalı:'), h('div', { class: 'row2' }, from, to));
    return {
      el,
      get() {
        const f = from.value || yearStartISO();
        const t = to.value || todayISO();
        if (f > t) throw new Error('Tarix intervalı düzgün deyil: başlanğıc tarixi son tarixdən böyükdür.');
        return { from: D.apiDate(f), to: D.apiDate(t, true), fromISO: f, toISO: t };
      },
    };
  }

  function check(text, checked) {
    const cb = h('input', { type: 'checkbox', checked: !!checked });
    return { el: h('label', { class: 'chk' }, cb, text), cb };
  }

  function seg(labels, onChange) {
    const btns = labels.map((l, i) => h('button', { class: i === 0 ? 'active' : '', onclick: () => set(i) }, l));
    let cur = 0;
    function set(i) { cur = i; btns.forEach((b, j) => b.classList.toggle('active', i === j)); if (onChange) onChange(i); }
    return { el: h('div', { class: 'seg' }, btns), get: () => cur };
  }

  // ------------------------------------------------------------------ row mappers
  const num = (v) => (v === null || v === undefined || v === '' ? null : D.r2(v));

  // Generic flatten for structures whose shape we don't model explicitly (acts)
  const ACT_LABELS = {
    serialNumber: 'Seriya və nömrə', createdAt: 'Tarix', status: 'Status', kind: 'Növ', type: 'Tip', version: 'Versiya',
    amount: 'Yekun məbləğ', 'seller.fin': 'Satıcının FİN', 'seller.tin': 'Satıcının VÖEN', 'seller.name': 'Satıcının adı',
    'seller.phoneNumber': 'Satıcının telefonu', 'buyer.tin': 'Alıcının VÖEN', 'buyer.name': 'Alıcının adı',
    comment: 'Qeyd', invoiceComment: 'Əsas', id: 'ID', sourceSystem: 'Mənbə sistem',
  };
  function flatten(obj, prefix = '', out = {}) {
    for (const [k, v] of Object.entries(obj || {})) {
      const key = prefix ? `${prefix}.${k}` : k;
      if (v && typeof v === 'object' && !Array.isArray(v)) flatten(v, key, out);
      else if (!Array.isArray(v)) out[key] = v;
    }
    return out;
  }
  function genericSheet(list, labels, transform) {
    const flat = list.map((o) => flatten(o));
    const keys = [];
    const pref = Object.keys(labels);
    pref.forEach((k) => { if (flat.some((f) => k in f)) keys.push(k); });
    flat.forEach((f) => Object.keys(f).forEach((k) => { if (!keys.includes(k) && flat.some((x) => x[k] !== null && x[k] !== '' && x[k] !== undefined)) keys.push(k); }));
    const header = ['№', ...keys.map((k) => labels[k] || k)];
    const rows = flat.map((f, i) => [i + 1, ...keys.map((k) => (transform ? transform(k, f[k]) : f[k]) ?? '')]);
    return [header, ...rows];
  }

  // ------------------------------------------------------------------ TaxPro-format invoice report
  // One row per goods/service line; № is the invoice ordinal (repeated for multi-line invoices);
  // "Cəmi" row at the bottom (merged A:N) sums columns 15-27.
  const EQF_HEADER = ['№', 'Tipi', 'Növü', 'EQF Statusu', 'Təqdim edənin VÖEN-i', 'Təqdim edənin adı', 'Əldə edənin VÖEN-i',
    'Əldə edənin adı', 'EQF Tarixi', 'EQF Seriyası', 'Malın adı', 'Malın Kodu', 'Əmtəənin qlobal identifikasiya nömrəsi (GTIN)',
    'Ölçü Vahidi', 'Malın miqdarı', 'Malın buraxılış qiyməti', 'Cəmi qiyməti', 'Aksiz dərəcəsi(%)', 'Aksiz məbləği(AZN)', 'Cəmi',
    'ƏDV-yə 18 faiz dərəcə ilə cəlb edilən', 'ƏDV-yə "0" dərəcə ilə cəlb edilən', 'ƏDV-yə cəlb edilməyən', 'ƏDV-dən azad olunan',
    'ƏDV məbləği', 'Yol vergisi (manatla)', 'Yekun məbləğ', 'Mal/Xidmət', 'Əsas qeyd', 'Əlavə qeyd', 'Qaimə növləri üzrə tarixçə',
    'Qaimənin son dəyişmə tarixi', 'Emala verilən mallardan istifadə edilən(silinən) malların dəyəri'];
  const SUM_FROM = 14, SUM_TO = 26; // 0-based: "Malın miqdarı" .. "Yekun məbləğ"

  const n0 = (v) => { const x = Number(v); return isFinite(x) ? x : 0; };
  const r3 = (v) => Math.round(n0(v) * 1000) / 1000;
  const dmy = (iso) => { const d = new Date(iso); if (!iso || isNaN(d)) return ''; const p = (x) => String(x).padStart(2, '0'); return `${p(d.getDate())}-${p(d.getMonth() + 1)}-${d.getFullYear()}`; };
  const ymd = (iso) => { const d = new Date(iso); if (!iso || isNaN(d)) return ''; const p = (x) => String(x).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
  const goodOrService = (pg) => { const t = String((pg && pg.type) || '').toLowerCase(); return t === 'good' ? 'Mal' : t === 'service' ? 'Xidmət' : (pg && pg.type) || ''; };

  function historyText(det) {
    const src = det.sourceInvoices || det.sourceInvoicesDetail;
    if (!src) return '';
    const arr = Array.isArray(src) ? src : [src];
    return arr.map((x) => (typeof x === 'string' ? x : x && (x.serialNumber || x.number || ''))).filter(Boolean).join(', ');
  }

  function eqfRows(inv, det, ordinal) {
    const d = det && !det.__error ? { ...inv, ...det } : inv;
    const s = d.sender || {}, r = d.receiver || {};
    const head = [ordinal, D.INVOICE_TYPE_LABEL[d.type] || d.type || '', D.label(D.INVOICE_KINDS, d.kind) || d.kind || '',
      D.label(D.INVOICE_STATUSES.concat(D.RETURN_STATUSES), d.status), s.tin || s.fin || '', s.name || '',
      r.tin || r.fin || r.pin || '', r.name || '', dmy(d.createdAt), d.serialNumber || ''];
    const tail = (gs) => [gs, d.invoiceComment || '', d.invoiceComment2 || '', historyText(d), ymd(d.lastUpdatedAt || d.createdAt)];
    const items = (det && !det.__error && det.items) || [];
    if (!items.length) {
      // Detail unavailable: one summary line from the list record
      const cost = n0(d.costWithoutVat), exc = n0(d.excise), vat = r3(d.vat), road = n0(d.roadTax);
      return [[...head, '', '', '', '', '', '', cost, '', exc, cost + exc, n0(d.vat18), n0(d.zeroVat), n0(d.withoutVat), n0(d.vatFree),
        { v: vat, s: 'n3' }, road, { v: r3(n0(d.amount) || cost + exc + vat + road), s: 'n3' }, ...tail(''), 0]];
    }
    return items.map((it) => {
      const cost = n0(it.cost), exc = n0(it.excise), road = n0(it.roadTax);
      const vat = r3(n0(it.vat18) * 0.18);
      const total = cost + exc;
      return [...head, it.productName || '', (it.productGroup && it.productGroup.code) || '', ' ' + (it.barcode ?? ''),
        it.unit || (it.unitFromDict && (it.unitFromDict.name || it.unitFromDict.code)) || '', n0(it.quantity), n0(it.pricePerUnit), cost,
        n0(it.exciseRate), exc, total, n0(it.vat18), n0(it.vat0), n0(it.exempt), n0(it.vatFree),
        { v: vat, s: 'n3' }, road, { v: r3(total + vat + road), s: 'n3' },
        ...tail(goodOrService(it.productGroup)), n0(it.usedRecycledCost ?? it.recycledCost ?? 0)];
    });
  }

  function eqfSheet(name, list, details) {
    const order = list.map((inv, i) => i).sort((a, b) => new Date(list[b].createdAt) - new Date(list[a].createdAt));
    const body = [];
    order.forEach((i, k) => body.push(...eqfRows(list[i], details[i], k + 1)));
    const total = EQF_HEADER.map(() => '');
    total[0] = { v: 'Cəmi', s: 'b' };
    for (let c = SUM_FROM; c <= SUM_TO; c++) {
      total[c] = { v: Math.round(body.reduce((sum, r) => sum + n0(X.cellVal(r[c])), 0) * 100) / 100, s: 'bn2' };
    }
    const rows = [[], EQF_HEADER, ...body, total];
    const lastRow = rows.length; // 1-based index of the totals row
    return { name, rows, headerRow: 1, filterLastRow: lastRow - 1, merges: [`A${lastRow}:N${lastRow}`], maxWidth: 45 };
  }

  async function loadDetails(list, st) {
    const det = await API.pool(list, 5, (inv) => API.invoiceDetail(inv.id, inv.sourceSystem),
      (d, n) => st.set('info', `Qaimələrin mal/xidmət sətirləri yüklənir... ${d}/${n}`));
    return det;
  }

  // ------------------------------------------------------------------ panels
  function panelInvoices() {
    const direction = seg(['Gələnlər', 'Göndərilənlər']);
    const dates = dateRange(yearStartISO(), yearEndISO());
    const tin = h('input', { type: 'text', placeholder: '', maxlength: 10 });
    const tinLbl = h('label', { class: 'lbl' }, 'VÖEN');
    const statuses = statusPicker(D.INVOICE_STATUSES);
    const kinds = kindPicker(D.INVOICE_KINDS);
    const excel = check('Nəticəni Excel faylı kimi yüklə (yeni tab açılmasın)');
    const st = statusBox();
    const btn = h('button', { class: 'primary' }, 'Axtar');

    btn.onclick = () => runButton(btn, st, async () => {
      const dr = dates.get();
      const s = statuses.get(), k = kinds.get();
      if (!s.length) throw new Error('Ən azı bir status seçin.');
      if (!k.length) throw new Error('Ən azı bir qaimə növü seçin.');
      const t = tin.value.trim();
      if (t && !/^\d{10}$/.test(t)) throw new Error('VÖEN 10 rəqəmdən ibarət olmalıdır.');
      const dir = direction.get() === 0 ? 'inbox' : 'outbox';
      const dirName = dir === 'inbox' ? 'Gələnlər' : 'Göndərilənlər';
      st.set('info', 'Qaimələr yüklənir...');
      const list = await API.findInvoices({ direction: dir, statuses: s, kinds: k, from: dr.from, to: dr.to, tin: t },
        (n) => st.set('info', `Qaimələr yüklənir... ${n}`));
      if (!list.length) { st.set('ok', 'Seçilmiş parametrlər üzrə qaimə tapılmadı.'); return; }

      const details = await loadDetails(list, st);
      const failed = details.filter((d) => !d || d.__error).length;
      const sheet = eqfSheet(dirName, list, details);
      const msg = await deliver({
        title: `Elektron qaimələr — ${dirName} (${D.fmtDate(dr.fromISO)} – ${D.fmtDate(dr.toISO)})`,
        fileBase: `AMMO_EQF_${dir === 'inbox' ? 'Gelenler' : 'Gonderilenler'}`,
        sheets: [sheet], excel: excel.cb.checked,
      });
      st.set(failed ? 'info' : 'ok', `${list.length} qaimə, ${sheet.rows.length - 3} sətir. ${msg}` +
        (failed ? `\n${failed} qaimənin sətirləri alına bilmədi — onlar ümumi məbləğlə bir sətir kimi göstərildi.` : ''));
    });

    return h('div', null, direction.el, dates.el, tinLbl, tin,
      h('hr'), h('label', { class: 'lbl' }, 'Qaimə statusu:'), statuses.el,
      h('hr'), h('label', { class: 'lbl' }, 'Qaimə növü:'), kinds.el,
      h('hr'), excel.el, btn, st);
  }

  function panelReturns() {
    const dates = dateRange(yearStartISO(), yearEndISO());
    const tin = h('input', { type: 'text', maxlength: 10 });
    const statuses = statusPicker(D.RETURN_STATUSES);
    const excel = check('Nəticəni Excel faylı kimi yüklə (yeni tab açılmasın)');
    const st = statusBox();
    const btn = h('button', { class: 'primary' }, 'Axtar');
    btn.onclick = () => runButton(btn, st, async () => {
      const dr = dates.get();
      const s = statuses.get();
      if (!s.length) throw new Error('Ən azı bir status seçin.');
      st.set('info', 'ƏDV qaytarmaq üçün qaimələr yüklənir...');
      const list = await API.findReturnInvoices({ statuses: s, from: dr.from, to: dr.to, tin: tin.value.trim() },
        (n) => st.set('info', `Yüklənir... ${n}`));
      if (!list.length) { st.set('ok', 'Seçilmiş dövr üzrə ƏDV qaytarmaq üçün qaimə tapılmadı.'); return; }
      const details = await loadDetails(list, st);
      const sheet = eqfSheet('Qaytarma qaimələri', list, details);
      const msg = await deliver({
        title: `ƏDV qaytarmaq üçün qaimələr (${D.fmtDate(dr.fromISO)} – ${D.fmtDate(dr.toISO)})`,
        fileBase: 'AMMO_EDV_Qaytarma_Qaimeleri',
        sheets: [sheet],
        excel: excel.cb.checked,
      });
      st.set('ok', `${list.length} qaimə tapıldı. ${msg}`);
    });
    return h('div', null,
      h('div', { class: 'note' }, 'Portaldakı “ƏDV qaytarmaq üçün qaimə” bölməsindəki göndərilmiş qaimələr.'),
      dates.el, h('label', { class: 'lbl' }, 'Alıcının VÖEN / FİN'), tin,
      h('hr'), h('label', { class: 'lbl' }, 'Qaimə statusu:'), statuses.el,
      h('hr'), excel.el, btn, st);
  }

  function panelActs() {
    const dates = dateRange('', '');
    const statuses = statusPicker(D.ACT_STATUSES, '-- Akt statusu seçin --');
    const kinds = kindPicker(D.ACT_KINDS);
    const excel = check('Nəticəni Excel faylı kimi yüklə (yeni tab açılmasın)');
    const st = statusBox();
    const btn = h('button', { class: 'primary' }, 'Axtar');
    btn.onclick = () => runButton(btn, st, async () => {
      const dr = dates.get();
      const s = statuses.get(), k = kinds.get();
      if (!s.length) throw new Error('Ən azı bir akt statusu seçin.');
      if (!k.length) throw new Error('Ən azı bir akt növü seçin.');
      st.set('info', 'Aktlar yüklənir...');
      const list = await API.findActs({ statuses: s, kinds: k, from: dr.from, to: dr.to }, (n) => st.set('info', `Aktlar yüklənir... ${n}`));
      if (!list.length) { st.set('ok', 'Seçilmiş parametrlər üzrə akt tapılmadı.'); return; }
      const rows = genericSheet(list, ACT_LABELS, (key, v) => {
        if (key === 'status') return D.label(D.ACT_STATUSES, v);
        if (key === 'kind') return D.label(D.ACT_KINDS, v);
        if (key === 'type') return D.INVOICE_TYPE_LABEL[v] || v;
        if (/date|At$/i.test(key) && typeof v === 'string' && /^\d{4}-\d\d-\d\d/.test(v)) return D.fmtDateTime(v);
        if (typeof v === 'number' && !Number.isInteger(v)) return D.r2(v);
        return v;
      });
      const msg = await deliver({
        title: `Elektron alış aktları (${D.fmtDate(dr.fromISO)} – ${D.fmtDate(dr.toISO)})`,
        fileBase: 'AMMO_Alis_Aktlari',
        sheets: [{ name: 'Aktlar', rows }],
        excel: excel.cb.checked,
      });
      st.set('ok', `${list.length} akt tapıldı. ${msg}`);
    });
    return h('div', null, dates.el, h('hr'), h('label', { class: 'lbl' }, 'Akt statusu:'), statuses.el,
      h('hr'), h('label', { class: 'lbl' }, 'Akt növü:'), kinds.el, h('hr'), excel.el, btn, st);
  }

  function panelDeclarations() {
    let typeIdx = 0;
    const subBtns = D.DECL_TYPES.map((t, i) => h('button', { class: i === 0 ? 'active' : '', onclick: () => { typeIdx = i; subBtns.forEach((b, j) => b.classList.toggle('active', i === j)); } }, t.label));
    const year = h('select', null);
    const cy = new Date().getFullYear();
    for (let y = cy; y >= 2019; y--) year.appendChild(h('option', { value: y }, String(y)));
    const prev = check('Öncəki bəyannamələri çap et');
    const drafts = check('Qaralama bəyannamələri də çap et');
    const camToClar = check('Sonuncu Kameraldırsa, onun əvəzinə son Dəqiqləşdirilmişi çap et');
    const clarToCam = check('Sonuncu Dəqiqləşdirilmişdirsə, onun əvəzinə son Kameralı çap et');
    camToClar.cb.addEventListener('change', () => { if (camToClar.cb.checked) clarToCam.cb.checked = false; });
    clarToCam.cb.addEventListener('change', () => { if (clarToCam.cb.checked) camToClar.cb.checked = false; });
    const MONTHS = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
    const monthSel = () => { const sel = h('select', null, h('option', { value: '' }, 'Ay seçin')); MONTHS.forEach((m, i) => sel.appendChild(h('option', { value: i + 1 }, m))); return sel; };
    const mFrom = monthSel(), mTo = monthSel();
    const pdf = check('Bəyannamələrin PDF-ini də yüklə');
    const excel = check('Nəticəni Excel faylı kimi yüklə (yeni tab açılmasın)');
    const st = statusBox();
    const btn = h('button', { class: 'primary' }, 'Axtar');

    const TYPE_LBL = { CURRENT: 'Cari', CLARIFYING: 'Dəqiqləşdirilmiş', CAMERAL: 'Kameral' };
    // the list gives a quarter as its first month (1, 4, 7, 10); older records may hold the quarter number itself
    const quarterOf = (p) => { const m = Number(p.month) || 1; return [1, 4, 7, 10].includes(m) ? (m + 2) / 3 : m <= 3 ? m : Math.ceil(m / 3); };
    const tabLabel = (d) => {
      const p = d.reportingPeriod || {};
      const t = TYPE_LBL[d.declarationType] || d.declarationType || '';
      const n = p.type === 'QUARTER' ? quarterOf(p) : p.type === 'HALF_YEAR' ? (Number(p.month) === 2 || Number(p.month) > 6 ? 2 : 1) : Number(p.month);
      return (p.type === 'YEAR' ? `${p.year}` : `${p.year}/${n}`) + ` - ${t}` + (/DRAFT/i.test(d.declarationStatus || '') ? ' (qaralama)' : '');
    };
    const periodWord = (p) => {
      if (!p) return '';
      if (p.type === 'YEAR') return `İllik ${p.year}`;
      if (p.type === 'MONTH') return `${MONTHS[(p.month || 1) - 1]} ${p.year}`;
      if (p.type === 'QUARTER') { const q = quarterOf(p); return `${q}-${[3, 4].includes(q) ? 'cü' : 'ci'} rüb ${p.year}`; }
      return `${p.month || ''} ${p.year || ''}`;
    };
    // months covered by a reporting period
    const monthsOf = (p) => {
      if (!p) return [];
      if (p.type === 'MONTH') return [Number(p.month)];
      if (p.type === 'QUARTER') { const q = quarterOf(p); return [q * 3 - 2, q * 3 - 1, q * 3]; }
      if (p.type === 'HALF_YEAR') return !(Number(p.month) === 2 || Number(p.month) > 6) ? [1, 2, 3, 4, 5, 6] : [7, 8, 9, 10, 11, 12];
      return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    };

    btn.onclick = () => runButton(btn, st, async () => {
      const type = D.DECL_TYPES[typeIdx];
      const f1 = Number(mFrom.value) || 1, f2 = Number(mTo.value) || 12;
      if (f1 > f2) throw new Error('Başlama ayı bitmə ayından böyük ola bilməz.');
      st.set('info', `${year.value}-ci il üzrə bəyannamələr yüklənir...`);
      const all = await API.declarations(year.value);
      const isDraft = (d) => /DRAFT/i.test(d.declarationStatus || '');
      const entries = all.filter((e) => e && e.declaration && type.match(e.declaration))
        .filter((e) => drafts.cb.checked || !isDraft(e.declaration))
        .filter((e) => monthsOf(e.declaration.reportingPeriod).some((m) => m >= f1 && m <= f2));
      if (!entries.length) { st.set('ok', `“${type.label}” üzrə seçilmiş dövrdə bəyannamə tapılmadı.`); return; }

      const when = (d) => new Date(d.submissionDate || d.modificationDate || d.registrationDate || 0).getTime();
      const groups = new Map();
      entries.forEach((e) => {
        const d = e.declaration, p = d.reportingPeriod || {};
        const k = [d.taxCode, d.obligationPactCode || '', p.type, Number(p.month) || 0, p.year].join('|');
        if (!groups.has(k)) groups.set(k, []);
        groups.get(k).push(e);
      });
      const picked = [];
      for (const g of groups.values()) {
        g.sort((a, b) => when(a.declaration) - when(b.declaration));
        if (prev.cb.checked) { picked.push(...g); continue; }
        const nonDraft = g.filter((e) => !isDraft(e.declaration));
        let last = nonDraft.find((e) => e.declaration.lastClarifying === 'LAST') || nonDraft[nonDraft.length - 1] || g[g.length - 1];
        const latestOf = (t) => [...nonDraft].reverse().find((e) => e.declaration.declarationType === t);
        if (camToClar.cb.checked && last.declaration.declarationType === 'CAMERAL') last = latestOf('CLARIFYING') || last;
        if (clarToCam.cb.checked && last.declaration.declarationType === 'CLARIFYING') last = latestOf('CAMERAL') || last;
        picked.push(last);
        if (drafts.cb.checked) g.filter((e) => isDraft(e.declaration) && e !== last).forEach((e) => picked.push(e));
      }
      picked.sort((a, b) => {
        const pa = a.declaration.reportingPeriod || {}, pb = b.declaration.reportingPeriod || {};
        return (pa.year - pb.year) || (pa.month - pb.month) || (when(a.declaration) - when(b.declaration));
      });
      const decls = picked.map((e) => e.declaration);
      const yr = year.value;

      // ---------- ƏDV əvəzləşmə: Əlavə 1 invoices of all chosen VAT declarations
      if (type.id === 'vatOffset') {
        const header = ['İl/Ay', 'Kod və Təsviri', 'VÖEN/Adı', 'Tarix', 'Qaimənin seriyası', 'Qaimənin nömrəsi', 'Ümumi məbləğ,manatla', 'ƏDV məbləği,manatla', 'Ödənilmiş ümumi məbləğ,manatla', 'Ödənilmiş ƏDV məbləği,manatla'];
        const rows = [];
        for (let i = 0; i < decls.length; i++) {
          const d = decls[i], p = d.reportingPeriod || {};
          st.set('info', `Əlavə 1 oxunur: ${tabLabel(d)} (${i + 1}/${decls.length})`);
          const lines = await API.vatAppendix1(d.id || d.registrationNumber);
          const ym = p.type === 'MONTH' ? `${p.year}/${MONTHS[(p.month || 1) - 1]}` : periodWord(p);
          lines.sort((a, b) => (a.rowOrder || 0) - (b.rowOrder || 0)).forEach((l) => rows.push([
            ym, l.indicator === '_101' ? '308' : String(l.indicator || '').replace(/^_/, ''), l.tin || '', l.documentDate || '',
            l.documentSerial || '', l.documentNumber || '', Number(l.amount) || 0, Number(l.vat) || 0, Number(l.paidAmount) || 0, Number(l.paidVat) || 0,
          ]));
        }
        const sum = (ci) => Math.round(rows.reduce((s2, r) => s2 + (Number(r[ci]) || 0), 0) * 100) / 100;
        const data = {
          title: `ƏDV əvəzləşmə — ${yr}`, fileBase: `AMMO_EDV_Evezlesme_${yr}`, created: Date.now(),
          decls: [{ label: 'Bütün Bəyannamələr', steps: [{ name: '', sections: [{ title: 'ƏDV Sub Bəyanatları', header: [header.map((t) => ({ t, span: 1 }))], rows, totals: ['Cəmi', '', '', '', '', '', sum(6), sum(7), sum(8), sum(9)], empty: !rows.length }] }] }],
        };
        const msg = await deliverDecl(data, excel.cb.checked);
        st.set('ok', `${decls.length} ƏDV bəyannaməsi, ${rows.length} qaimə sətri. ${msg}`);
        return;
      }

      // ---------- PDFs (TaxPro-style file names)
      let pdfInfo = '';
      if (pdf.cb.checked) {
        const pdfs = await API.pool(decls, 3, (d) => API.declarationPdf(d.id).then((b) => b.arrayBuffer()),
          (dn, n) => st.set('info', `PDF-lər hazırlanır... ${dn}/${n}`));
        const files = [];
        pdfs.forEach((buf, i) => {
          if (!buf || buf.__error) return;
          const d = decls[i];
          const name = `${String(i + 1).padStart(2, '0')}_${type.label}_${periodWord(d.reportingPeriod)}_${TYPE_LBL[d.declarationType] || d.declarationType}_${d.registrationNumber || d.id}_1.pdf`
            .replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, '_');
          files.push({ name, data: new Uint8Array(buf) });
        });
        if (files.length === 1) saveBlob(new Blob([files[0].data], { type: 'application/pdf' }), files[0].name);
        else if (files.length > 1) saveBlob(new Blob([X.zip(files)], { type: 'application/zip' }), `Beyannameler_${type.label.replace(/\s+/g, '_')}_${yr}.zip`);
        pdfInfo = `, ${files.length} PDF yükləndi`;
      }

      const F = AMMO_DECL_FAST;
      let out = [];
      let done = 0;
      const tick = () => st.set('info', `Bəyannamələr oxunur... ${++done}/${decls.length}`);
      const calc = (name, reg, q) => API.declarationCalc(name, reg, q).catch(() => []);
      if (type.id === 'vat') {
        // ƏDV: TaxPro-style single wide table, one row per declaration
        const bases = await API.pool(decls, 6, (d) => API.declarationBase(d.id || d.registrationNumber), tick);
        const items = decls.map((decl, i) => ({ decl, base: bases[i] && !bases[i].__error ? bases[i] : {} }));
        out = [{ label: `${yr} - Hesabat Cədvəli`, steps: [{ name: '', sections: [F.vatTable(items)] }] }];
      } else {
        out = await API.pool(decls, 5, async (d) => {
          const reg = d.id || d.registrationNumber;
          const tc = String(d.taxCode || '');
          let sections;
          if (type.id === 'payroll' || tc === '_0901') {
            const [base, employees, unemployed, vacation, foreign] = await Promise.all([
              API.declarationBase(reg),
              calc('UNIFIED_APPENDIX_1_EMPLOYEE_LIST', reg, '&private_emp=false'),
              calc('UNIFIED_APPENDIX_1_UNEMPLOYED_DAYS', reg),
              calc('UNIFIED_APPENDIX_1_VACATION', reg),
              calc('UNIFIED_APPENDIX_2_FOREIGN_EMPLOYEE', reg),
            ]);
            sections = F.unifiedSections(base, { employees, unemployed, vacation, foreign });
          } else if (tc === '_1600') {
            const [base, residents, nonResidentLegal, nonResidentPhysical, preferential] = await Promise.all([
              API.declarationBase(reg),
              calc('WITHHOLDING_APPENDIX_1_TAX_CALCULATION', reg),
              calc('WITHHOLDING_APPENDIX_2_NON_RESIDENT_LEGAL', reg),
              calc('WITHHOLDING_APPENDIX_2_NON_RESIDENT_PHYSICAL', reg),
              calc('WITHHOLDING_APPENDIX_2_PREFERENTIAL_TAX', reg),
            ]);
            sections = F.withholdingSections(base, { residents, nonResidentLegal, nonResidentPhysical, preferential });
          } else if (tc === '_0200') {
            sections = F.profitSections(await API.declarationBase(reg));
          } else {
            sections = F.genericSections(await API.declarationBase(reg));
          }
          return { label: tabLabel(d), reg, steps: sections.length ? [{ name: '', sections }] : [] };
        }, tick);
        out = out.map((x, i) => (x && !x.__error ? x : { label: tabLabel(decls[i]), error: (x && x.__error && x.__error.message) || 'xəta', steps: [] }));
      }

      const data = { title: `${type.label} — ${yr}`, fileBase: `AMMO_Beyanname_${type.id}_${yr}`, created: Date.now(), decls: out };
      const msg = await deliverDecl(data, excel.cb.checked);
      const failed = out.filter((x) => x.error).length;
      st.set(failed ? 'info' : 'ok', `${decls.length} bəyannamə oxundu${pdfInfo}. ${msg}` + (failed ? `\n${failed} bəyannamə açıla bilmədi.` : ''));
    });

    return h('div', null, h('div', { class: 'subtabs' }, subBtns),
      h('label', { class: 'lbl' }, 'Bəyannamənin ili'), year,
      prev.el, drafts.el, camToClar.el, clarToCam.el,
      h('label', { class: 'lbl' }, 'Başlama Tarixi:'), mFrom,
      h('label', { class: 'lbl' }, 'Bitmə tarixi:'), mTo,
      h('hr'), pdf.el, excel.el, btn, st);
  }

  // Declarations: Excel workbook (one sheet per declaration) or the AMMO analysis tab
  const declSheets = (data) => AMMO_DECL_XLSX.sheets(data);
  async function deliverDecl(data, excel) {
    if (excel) { X.download(declSheets(data), `${data.fileBase}_${stamp()}.xlsx`); return 'Excel faylı yükləndi.'; }
    const key = 'ammo_result_' + Date.now();
    await chrome.storage.local.set({ [key]: { ...data, kind: 'decl' } });
    await chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/decl.html', key });
    return 'Nəticə yeni tabda açıldı.';
  }

  function saveBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 3000);
  }

  function panelHfTta() {
    const ta = h('textarea', { placeholder: 'MT123456789012, KT123456789013' });
    const err = h('div', { class: 'err' });
    const parse = () => [...new Set((ta.value.toUpperCase().match(/[A-Z]{2}\d{12}/g) || []))];
    const validate = () => { err.textContent = parse().length ? '' : 'Zəhmət olmasa ən azı bir düzgün EQF nömrəsi daxil edin (12 rəqəm).'; };
    ta.addEventListener('input', validate);
    validate();
    const tta = check('Təhvil-təslim aktı çap olunsun', true);
    const proto = check('Razılaşma protokolu çap olunsun');
    const notes = check('Qeydlər çap olunsun');
    const ttaPrice = check('Təhvil-təslim aktında qiymət sütunu çap olunsun', true);
    const hf = check('Hesab faktura çap olunsun');

    // Extra parameters (remembered)
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem('ammo_hf_opts') || '{}'); } catch (e) { saved = {}; }
    const cNo = h('input', { type: 'text', value: saved.contractNo || '001' });
    const cDate = h('input', { type: 'date', value: saved.contractDate || todayISO() });
    const city = h('input', { type: 'text', value: saved.city || 'Bakı şəhəri' });
    const signer = h('input', { type: 'text', value: saved.signer || 'Direktor' });
    const extra = h('details', { style: 'margin-top:8px' },
      h('summary', { style: 'cursor:pointer;font-size:13px;color:#334155' }, 'Əlavə parametrlər (müqavilə, şəhər, vəzifə)'),
      h('div', { class: 'row2' },
        h('div', null, h('label', { class: 'lbl' }, 'Müqavilə nömrəsi'), cNo),
        h('div', null, h('label', { class: 'lbl' }, 'Müqavilə tarixi'), cDate)),
      h('div', { class: 'row2' },
        h('div', null, h('label', { class: 'lbl' }, 'Şəhər'), city),
        h('div', null, h('label', { class: 'lbl' }, 'İmza edənin vəzifəsi'), signer)));

    const st = statusBox();
    const btn = h('button', { class: 'primary' }, 'Axtar');
    btn.onclick = () => runButton(btn, st, async () => {
      const serials = parse();
      if (!serials.length) { validate(); throw new Error('Düzgün EQF nömrəsi yoxdur.'); }
      const kinds = [[tta, 'TTA', 'tta'], [proto, 'RP', 'rp'], [notes, 'QEYD', 'notes'], [hf, 'HF', 'hf']].filter(([c]) => c.cb.checked);
      if (!kinds.length) throw new Error('Ən azı bir sənəd növü seçin.');
      const opts = { contractNo: cNo.value.trim() || '001', contractDate: cDate.value || todayISO(), city: city.value.trim() || 'Bakı şəhəri', signer: signer.value.trim() || 'Direktor' };
      try { localStorage.setItem('ammo_hf_opts', JSON.stringify(opts)); } catch (e) { /* ignore */ }
      opts.ttaPrice = ttaPrice.cb.checked;

      const files = [];
      const missing = [];
      for (let i = 0; i < serials.length; i++) {
        st.set('info', `Qaimələr axtarılır... ${i + 1}/${serials.length}`);
        const found = await API.findBySerial(serials[i], (txt) => st.set('info', `Qaimə axtarılır (${i + 1}/${serials.length}) — ${txt}`));
        if (!found) { missing.push(serials[i]); continue; }
        st.set('info', `${serials[i]} tapıldı, mal/xidmət sətirləri yüklənir...`);
        const detail = await API.invoiceDetail(found.id, found.sourceSystem);
        const det = { ...found, ...detail };
        for (const [, suffix, fn] of kinds) {
          files.push({ name: `${det.serialNumber}_${suffix}.docx`, data: AMMO_HFDOCS[fn](det, opts) });
        }
      }
      if (!files.length) throw new Error('Heç bir qaimə tapılmadı: ' + missing.join(', '));
      const zipName = `documents_${todayISO()}.zip`;
      saveBlob(new Blob([X.zip(files)], { type: 'application/zip' }), zipName);
      st.set(missing.length ? 'info' : 'ok', `${files.length} sənəd hazırlandı və ${zipName} yükləndi.` +
        (missing.length ? `\nTapılmadı: ${missing.join(', ')}` : ''));
    });
    return h('div', null, h('label', { class: 'lbl' }, 'Elektron qaimə nömrələri'), ta, err,
      tta.el, proto.el, notes.el, ttaPrice.el, h('br'), hf.el, extra, btn, st);
  }

  function panelSubAccount() {
    let mode = 0;
    const cols = [
      ['VÖEN', 'Qaimə nömrəsi', 'Ödəniləcək məbləğ', 'Təyinat'],
      ['VÖEN', 'Alıcının / satıcının adı', 'Ödəniləcək məbləğ (ƏDV daxil)', 'Təyinat'],
    ];
    const thead = h('thead');
    const tbody = h('tbody');
    const table = h('table', { class: 'grid' }, thead, tbody);
    const store = [[], []];

    function addRow(vals = ['', '', '', '']) {
      const inputs = vals.map((v, i) => h('input', { type: i === 2 ? 'text' : 'text', value: v, inputmode: i === 2 ? 'decimal' : null }));
      const tr = h('tr', null, inputs.map((inp) => h('td', null, inp)),
        h('td', { class: 'x' }, h('button', { title: 'Sətri sil', onclick: () => { tr.remove(); ensureEmpty(); } }, '✕')));
      inputs.forEach((inp, ci) => {
        inp.addEventListener('input', ensureEmpty);
        inp.addEventListener('paste', (ev) => {
          const text = (ev.clipboardData || window.clipboardData).getData('text');
          if (!/[\t\n]/.test(text)) return;
          ev.preventDefault();
          const lines = text.replace(/\r/g, '').split('\n').filter((l) => l.trim());
          let cur = tr;
          lines.forEach((line, li) => {
            const cells = line.split('\t');
            if (li > 0) cur = addRow();
            const ins = [...cur.querySelectorAll('input')];
            cells.forEach((c, k) => { if (ins[ci + k]) ins[ci + k].value = c.trim(); });
          });
          ensureEmpty();
        });
      });
      tbody.appendChild(tr);
      return tr;
    }
    function rowsData() {
      return [...tbody.querySelectorAll('tr')].map((tr) => [...tr.querySelectorAll('input')].map((i) => i.value.trim()))
        .filter((r) => r.some(Boolean));
    }
    function ensureEmpty() {
      const trs = [...tbody.querySelectorAll('tr')];
      const last = trs[trs.length - 1];
      if (!last || [...last.querySelectorAll('input')].some((i) => i.value.trim())) addRow();
    }
    function render() {
      thead.innerHTML = '';
      thead.appendChild(h('tr', null, cols[mode].map((c) => h('th', null, c)), h('th')));
      tbody.innerHTML = '';
      store[mode].forEach((r) => addRow(r));
      ensureEmpty();
    }
    const sg = seg(['Qaimə üzrə', 'Avans üzrə'], (i) => { store[mode] = rowsData(); mode = i; render(); });
    render();

    const parseAmt = (s) => {
      if (!s) return null;
      let t = String(s).replace(/\s/g, '');
      if (t.includes(',') && t.includes('.')) t = t.replace(/,/g, '');
      else t = t.replace(',', '.');
      const n = Number(t);
      return isFinite(n) ? n : NaN;
    };

    const st = statusBox();
    const btn = h('button', { class: 'primary' }, 'Axtar');
    btn.onclick = () => runButton(btn, st, async () => {
      const data = rowsData();
      if (!data.length) throw new Error('Cədvələ ən azı bir sətir daxil edin.');
      const header = ['№', 'Alanın VÖEN', 'Alanın adı', 'Qaimə nömrəsi', 'Qaimə tarixi', 'Qaimənin yekun məbləği', 'Qaimənin ƏDV məbləği',
        'Ödəniləcək məbləğ', 'Əsas hesaba (ƏDV-siz)', 'ƏDV depozit hesabına', 'Təyinat', 'Qeyd'];
      const out = [];
      if (mode === 0) {
        for (let i = 0; i < data.length; i++) {
          const [tin, serialRaw, amtRaw, purpose] = data[i];
          const serial = (serialRaw || '').toUpperCase().replace(/\s/g, '');
          st.set('info', `Qaimələr yoxlanılır... ${i + 1}/${data.length}`);
          let note = '';
          let inv = null;
          if (/^[A-Z]{2}\d{12}$/.test(serial)) {
            try { inv = await API.findBySerial(serial); } catch (e) { note = e.message; }
            if (!inv && !note) note = 'Qaimə tapılmadı';
          } else note = 'Qaimə nömrəsi düzgün deyil';
          const total = inv ? Number(inv.amount) || 0 : null;
          const vat = inv ? Number(inv.vat) || 0 : null;
          let pay = parseAmt(amtRaw);
          if (pay === null) pay = total;
          if (Number.isNaN(pay)) { note = 'Məbləğ düzgün deyil'; pay = null; }
          let vatPart = null, mainPart = null;
          if (pay !== null && inv && total) {
            vatPart = D.r2(pay * vat / total);
            mainPart = D.r2(pay - vatPart);
          } else if (pay !== null && !inv) {
            vatPart = D.r2(pay * 18 / 118); mainPart = D.r2(pay - vatPart);
            note = (note ? note + '; ' : '') + 'ƏDV 18% ilə hesablanıb';
          }
          const counterpart = inv ? (inv._direction === 'inbox' ? inv.sender : inv.receiver) || {} : {};
          const tinOut = tin || counterpart.tin || '';
          if (inv && tin && counterpart.tin && tin !== counterpart.tin) note = (note ? note + '; ' : '') + `VÖEN qaimədəki ilə uyğun deyil (${counterpart.tin})`;
          out.push([i + 1, tinOut, counterpart.name || '', serial, inv ? D.fmtDate(inv.createdAt) : '', total !== null ? D.r2(total) : '', vat !== null ? D.r2(vat) : '',
            pay !== null ? D.r2(pay) : '', mainPart ?? '', vatPart ?? '',
            purpose || (serial ? `${serial} saylı e-qaimə-faktura üzrə ödəniş` : ''), note]);
        }
      } else {
        data.forEach(([tin, name, amtRaw, purpose], i) => {
          const pay = parseAmt(amtRaw);
          const ok = pay !== null && !Number.isNaN(pay);
          const vatPart = ok ? D.r2(pay * 18 / 118) : '';
          out.push([i + 1, tin, name, '', '', '', '', ok ? D.r2(pay) : '', ok ? D.r2(pay - vatPart) : '', vatPart,
            purpose || 'Avans ödənişi', ok ? (/^\d{10}$/.test(tin) ? '' : 'VÖEN yoxlanılmalıdır') : 'Məbləğ düzgün deyil']);
        });
      }
      const tot = header.map(() => '');
      tot[2] = 'CƏMİ';
      [7, 8, 9].forEach((ci) => { tot[ci] = D.r2(out.reduce((s, r) => s + (Number(r[ci]) || 0), 0)); });
      const msg = await deliver({
        title: `Sub-uçot köçürmələri — ${mode === 0 ? 'Qaimə üzrə' : 'Avans üzrə'}`,
        fileBase: `AMMO_SubUcot_${mode === 0 ? 'Qaime' : 'Avans'}`,
        sheets: [{ name: 'Köçürmələr', rows: [header, ...out, tot] }],
        excel: false,
      });
      st.set('ok', `${out.length} sətir hazırlandı. ${msg}`);
    });

    return h('div', null, sg.el,
      h('div', { class: 'right' }, h('button', { class: 'danger', onclick: () => { store[mode] = []; render(); } }, 'Hamısını Sil')),
      table,
      h('div', { class: 'hint' }, 'Excel-dən bir neçə sətri birbaşa kopyalayıb cədvələ yapışdıra bilərsiniz. Məbləğ boş qalarsa, qaimənin tam məbləği götürülür.'),
      btn, st);
  }

  function panelQuickSubmit() {
    const st = statusBox();
    const btn = h('button', { class: 'primary' }, 'Təqdim et');
    btn.onclick = () => runButton(btn, st, async () => {
      if (!/\/eportal\/invoice\/?$/.test(location.pathname)) {
        sessionStorage.setItem('ammo_quick_submit', '1');
        st.set('info', 'Qaimələr səhifəsinə keçilir...');
        location.href = 'https://new.e-taxes.gov.az/eportal/invoice';
        return;
      }
      await quickSubmit(st);
    });
    return h('div', null,
      h('div', { class: 'note' },
        'Bu düymə portalın “Elektron qaimə-fakturalar” səhifəsində ', h('b', null, 'Qaralamalar'),
        ' bölməsini açır, bütün qaralamaları seçir və portalın öz “Təqdim etmə” düyməsini basır. ',
        'İmzalama (ASAN İmza) və son təsdiq həmişə sizin tərəfinizdən portalın pəncərəsində edilir — AMMO heç nəyi sizin yerinizə imzalamır.'),
      btn, st);
  }

  // ---- DOM automation for quick submit (uses the portal's own controls)
  function findByText(selector, re) {
    return [...document.querySelectorAll(selector)].find((el) => re.test((el.textContent || '').trim()) && el.offsetParent !== null);
  }
  async function waitFor(fn, timeout = 10000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) { const v = fn(); if (v) return v; await sleep(250); }
    return null;
  }
  async function quickSubmit(st) {
    st.set('info', 'Qaralamalar açılır...');
    const draftsTab = await waitFor(() => findByText('button, a, div[role=tab], span', /^Qaralamalar$/));
    if (!draftsTab) throw new Error('“Qaralamalar” bölməsi tapılmadı.');
    draftsTab.click();
    await sleep(1800);
    const rowsCount = () => document.querySelectorAll('input[type=checkbox]').length;
    const hasRows = await waitFor(() => rowsCount() > 1, 6000);
    if (!hasRows) { st.set('ok', 'Təqdim ediləcək qaralama qaimə yoxdur.'); return; }
    const headerCb = [...document.querySelectorAll('input[type=checkbox]')].find((c) => c.offsetParent !== null || c.parentElement.offsetParent !== null);
    if (!headerCb) throw new Error('Seçim xanası tapılmadı.');
    if (!headerCb.checked) { (headerCb.closest('label') || headerCb).click(); await sleep(400); if (!headerCb.checked) headerCb.click(); }
    await sleep(500);
    const selected = [...document.querySelectorAll('input[type=checkbox]')].filter((c) => c.checked).length - 1;
    const submit = findByText('button', /^Təqdim etmə/);
    if (!submit) throw new Error('Portalda “Təqdim etmə” düyməsi tapılmadı.');
    submit.click();
    st.set('ok', `${Math.max(selected, 0)} qaralama seçildi və “Təqdim etmə” açıldı. Portalın pəncərəsində davam edib ASAN İmza ilə imzalayın.`);
    closeModal();
  }


  // ------------------------------------------------------------------ İlkin audit (v1.23)
  function panelAudit() {
    const mode = seg(['İl', 'Tarix aralığı', 'Bütün dövr'], (i) => { yearBox.hidden = i !== 0; dates.el.hidden = i !== 1; });
    const year = h('select', null);
    const cy = new Date().getFullYear();
    for (let y = cy; y >= 2019; y--) year.appendChild(h('option', { value: y }, String(y)));
    year.value = String(new Date().getMonth() < 3 ? cy - 1 : cy);
    const yearBox = h('div', null, h('label', { class: 'lbl' }, 'İl'), year);
    const dates = dateRange(yearStartISO(), todayISO());
    dates.el.hidden = true;
    const vat = check('ƏDV əvəzləşmə analizini daxil et (yaranan / əvəzləşən / qalan / hüquq, depozit qalığı) — daha uzun çəkir', true);
    const full = check('Mal qalığı — şirkətin portaldakı bütün tarixçəsi üzrə (ilk dəfə uzun çəkə bilər, sonra yaddaşdan sürətli)', true);
    const auto804 = check('Daxil olan pullar — bəyannamə olmayan rüblər üçün 804-ü arxa planda oxu (köməkçi qaralama dərhal silinir)', true);
    const st = statusBox();
    const btn = h('button', { class: 'primary' }, 'Hazırla');
    const snaps = h('div', { class: 'note', style: 'margin-top:14px' });
    (async () => {
      const tin = (window.AMMO_EVEZ_PORTAL && AMMO_EVEZ_PORTAL.ownTin()) || 'x';
      const o = await chrome.storage.local.get([`ammo_emas_staff_${tin}`, 'ammo_emas_staff_last', `ammo_customs_${tin}`, 'ammo_customs_last']);
      const cus = [o[`ammo_customs_${tin}`], o.ammo_customs_last].filter((x) => x && x.rows && x.rows.length).sort((x, y) => (y.at || 0) - (x.at || 0))[0] || null;
      const row = (ok, t, hint) => h('div', { style: 'margin:3px 0' }, h('b', { style: `color:${ok ? 'var(--ok)' : 'var(--mute)'}` }, ok ? '✓ ' : '○ '), t, ok ? '' : h('span', { class: 'hint' }, ' — ' + hint));
      const dt = (x) => (x ? ` (${new Date(x.at).toLocaleDateString('az-AZ')})` : '');
      snaps.replaceChildren(h('b', null, 'Avtomatik oxunur: '), 'şirkət profili, borclar, məktublar, bəyannamələr, qaimələr, aktlar, 804 — heç bir səhifə açmaq lazım deyil.',
        h('div', { style: 'margin-top:6px' }, h('b', null, 'Kənar sistemlər:')),
        row(cus, 'Gömrük (idxal)' + dt(cus), 'e.customs.gov.az açıqdırsa AMMO özü oxuyur'),
        row(o[`ammo_emas_staff_${tin}`] || o.ammo_emas_staff_last, 'İşçilər və vəzifələr (ƏMAS)' + dt(o[`ammo_emas_staff_${tin}`] || o.ammo_emas_staff_last), 'ƏMAS-da «İşçiləri İlkin audit-ə göndər»'));
    })().catch(() => {});
    btn.onclick = () => runButton(btn, st, async () => {
      const m = mode.get();
      let opts;
      if (m === 0) opts = { mode: 'year', year: Number(year.value) };
      else if (m === 1) { const dr = dates.get(); opts = { mode: 'range', fromISO: dr.fromISO, toISO: dr.toISO }; }
      else opts = { mode: 'all' };
      opts.vat = vat.cb.checked; opts.fullStock = full.cb.checked; opts.auto804 = auto804.cb.checked;
      const t0 = Date.now();
      const res = await AMMO_AUDIT2.collect(opts, (t) => st.set('info', t));
      const key = 'ammo_result_' + Date.now();
      await chrome.storage.local.set({ [key]: res });
      await chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/audit2.html', key });
      st.set('ok', `Hazırdır (${Math.round((Date.now() - t0) / 1000)} san): ${res.decls.length} bəyannamə, ${res.audit ? res.audit.counts.sales + res.audit.counts.purchases : 0} qaimə (dövr üzrə), ${res.moves.length} mal hərəkəti. Nəticə yeni tabda açıldı.`);
    });
    return h('div', null, mode.el, yearBox, dates.el, vat.el, full.el, auto804.el,
      h('div', { class: 'note', style: 'margin-top:14px' },
        h('b', null, 'İlkin audit: '), 'şirkət profili, təsdiqlənmiş və uyğunsuzluqda olan bəyannamələr (necə təsdiqlənib: kameral / analoji / adi), təqdim edilməyənlər, ',
        'real gəlir-xərc-mənfəət (qaimələr, aktlar, gömrük, maaş, satılan malın maya dəyəri), mal qalığı (mal kodu üzrə), daxil olan pullar (804, rüblər üzrə), ',
        'ƏDV və depozit, borclar, məktublar, işçilər — hamısı bir səhifədə.'),
      snaps, btn, st);
  }

  // ------------------------------------------------------------------ Vergi hesabatları (v1.20): Mənfəət / Gəlir bəyannaməsi
  function panelTaxRep(type) {
    const P = type === 'profit';
    const name = P ? 'Mənfəət vergisinin bəyannaməsi' : 'Gəlir vergisinin bəyannaməsi';
    const cy = new Date().getFullYear();
    let year = cy - 1;
    const years = [];
    for (let y = cy; y >= 2019; y--) years.push(y);
    const st = statusBox();
    const saved = h('div', { class: 'tr-saved' });
    const yearBtns = years.map((y) => h('button', { type: 'button', class: y === year ? 'active' : '', onclick: () => { year = y; yearBtns.forEach((b, i) => b.classList.toggle('active', years[i] === y)); showSaved(); } }, String(y)));
    const keyOf = () => `ammo_taxrep_${type}_${year}`;
    async function openReport() { await chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/taxrep.html', key: keyOf() }); }
    async function showSaved() {
      saved.innerHTML = '';
      const o = (await chrome.storage.local.get(keyOf()))[keyOf()];
      if (!o) { saved.appendChild(h('span', { class: 'hint' }, `${year}-ci il üçün hələ hazırlanmayıb.`)); return; }
      const pay = P ? (o.values.calc['245'] || [0])[0] : (o.values.calc['1248'] || [0, 0]).reduce((a, b) => a + (Number(b) || 0), 0);
      saved.appendChild(h('div', { class: 'tr-card' },
        h('div', null, h('b', null, `${year} · hazırdır`), h('small', null, `${new Date(o.updated || o.created).toLocaleString('az-AZ')} · ödənilməli: ${D.money(pay)} ₼`)),
        h('button', { type: 'button', class: 'tr-open', onclick: openReport }, 'Hesabatı aç'),
        onDeclPage() ? h('button', { type: 'button', class: 'tr-open', onclick: () => fillHere(o) }, 'Bu səhifəni doldur') : null));
    }
    const onDeclPage = () => /\/eportal\/declaration\//.test(location.pathname);
    async function fillHere(o) {
      try {
        const T = window.AMMO_TAXREP_FORMS;
        const r = await window.AMMO_DECL_FILL.fill(T.fillPayload(T.getForm(o.type), o.values, { year: o.year }));
        st.set(r.filled ? 'ok' : 'bad', r.filled ? `${r.filled} xana dolduruldu. Yoxlayın və portalda özünüz təsdiq edin.` : 'Bu səhifədə doldurulacaq xana tapılmadı — bəyannamənin redaktə səhifəsini açın.');
        if (r.filled) closeModal();
      } catch (e) { st.set('bad', e.message || String(e)); }
    }
    const btn = h('button', { class: 'primary' }, 'Doldur');
    btn.onclick = () => runButton(btn, st, async () => {
      const res = await AMMO_TAXREP.build(type, year, (t) => st.set('info', t));
      const prevSaved = (await chrome.storage.local.get(keyOf()))[keyOf()];
      if (prevSaved && prevSaved.meta) ['activityCode', 'activityName', 'tin', 'name', 'method', 'group', 'agent'].forEach((k) => { if (prevSaved.meta[k] && !res.meta[k]) res.meta[k] = prevSaved.meta[k]; });
      await chrome.storage.local.set({ [keyOf()]: res });
      await openReport();
      const pay = P ? res.values.calc['245'][0] : res.values.calc['1248'][0] + res.values.calc['1248'][1];
      st.set('ok', `Hazırdır: ${year}-ci il, ödənilməli vergi ${D.money(pay)} ₼. Bəyannamə yeni tabda açıldı — orada «Doldur — e-taxes» düyməsi portaldakı açıq bəyannaməni doldurur.`);
      showSaved();
    });
    let tinNote = null;
    try {
      const tin = window.AMMO_EVEZ_PORTAL ? AMMO_EVEZ_PORTAL.ownTin() : '';
      if (tin && P && /2$/.test(tin)) tinNote = h('div', { class: 'note warn' }, `VÖEN ${tin} fiziki şəxsə (fərdi sahibkar) aiddir — adətən «Gəlir hesabatı» təqdim edilir.`);
      if (tin && !P && /1$/.test(tin)) tinNote = h('div', { class: 'note warn' }, `VÖEN ${tin} hüquqi şəxsə aiddir — adətən «Mənfəət hesabatı» təqdim edilir.`);
    } catch (e) { /* */ }
    showSaved();
    return h('div', null,
      h('div', { class: 'tr-hero' },
        h('div', null, h('b', null, name), h('small', null, P ? 'Hüquqi şəxslər · VM 103-106 · dərəcə 20%' : 'Fərdi sahibkarlar · VM 99-102 · sahibkarlıq 20%, qeyri-sahibkarlıq 14%'))),
      tinNote,
      h('label', { class: 'lbl' }, 'Hesabat ili'),
      h('div', { class: 'seg tr-years' }, yearBtns),
      btn, st, saved,
      h('div', { class: 'note', style: 'margin-top:14px' },
        h('b', null, 'Nə edir: '), 'seçilmiş il üzrə satış və alış e-qaimələrini, alış aktlarını, muzdlu iş bəyannamələrini və əvvəlki illərin ',
        P ? 'mənfəət' : 'gəlir', ' bəyannamələrini oxuyur və bəyannaməni portalın maketi ilə eyni formada doldurur: gəlirlər, xərclər, verginin hesablanması, Əlavə 1 (aktivlər və kapital). ',
        'Əvvəlki ilin qalıqları, keçmiş illərin zərəri və mikro sahibkar güzəşti avtomatik nəzərə alınır. ',
        h('br'), h('b', null, 'Portala köçürmə: '), 'e-taxes-də bəyannaməni açıq saxlayın — hesabat səhifəsində və ya portaldakı «AMMO · Doldur» düyməsini basın, xanalar dolacaq. ',
        'Təqdim etmə və ASAN İmza həmişə sizin tərəfinizdən edilir.'));
  }

  // ------------------------------------------------------------------ Bank Çıxarışı
  const BANKS = [['AUTO', 'Avtomatik'], ['ABB', 'ABB'], ['KAPITAL', 'Kapital Bank'], ['PASHA', 'Pasha Bank'], ['RESPUBLIKA', 'Bank Respublika'], ['RABITA', 'Rabitəbank'], ['UNIBANK', 'Unibank (köhnə)'], ['EDV_DEPOSIT', 'ƏDV Depozit']];
  function panelBank() {
    const st = statusBox();
    const picked = []; // {file, selEl}
    const listBox = h('div', { class: 'bnk-files' });
    const file = h('input', { type: 'file', accept: '.xlsx,.xls', multiple: true, style: 'display:none' });
    const addBtn = h('button', { class: 'ghost', style: 'flex:1' }, '＋ Fayl(lar) seç');
    addBtn.onclick = () => file.click();
    const extra = h('div', { class: 'bnk-extra' });
    const btn = h('button', { class: 'primary' }, 'Faylları yüklə və emal et');

    function renderFiles() {
      listBox.innerHTML = '';
      picked.forEach((p, i) => {
        const sel = h('select', null, ...BANKS.map(([v, l]) => h('option', { value: v, selected: p.bank === v }, l)));
        sel.onchange = () => { p.bank = sel.value; };
        const del = h('button', { class: 'asan-ic', title: 'Sil' }, '×');
        del.onclick = () => { picked.splice(i, 1); renderFiles(); };
        listBox.appendChild(h('div', { class: 'bnk-file' }, h('span', { class: 'bnk-fn' }, p.file.name), sel, del));
      });
    }
    file.onchange = () => { Array.from(file.files).forEach((f) => picked.push({ file: f, bank: 'AUTO' })); file.value = ''; renderFiles(); };

    async function finish(result) {
      extra.innerHTML = '';
      const sheets = AMMO_BANK.buildSheets(result);
      X.download(sheets, `icmal_merged_${result.currency}.xlsx`);
      st.set('ok', `Hazırdır: ${result.logs.length} əməliyyat, ${result.incoming.length} daxil olan, ${result.outgoing.length} ödəniş. İcmal Excel yükləndi.`);
    }

    function askUnknowns(result) {
      extra.innerHTML = '';
      const cats = AMMO_BANK_CAT.allCategories();
      const choices = {};
      const box = h('div', { class: 'bnk-unk' },
        h('h3', { style: 'margin:0 0 6px' }, `Qruplaşdırılmamış əməliyyatlar: ${result.unknowns.length}`),
        h('div', { class: 'hint', style: 'margin-bottom:8px' }, 'Hər biri üçün kateqoriya seçin, sonra Excel yaradılacaq.'));
      result.unknowns.forEach(([k, amt]) => {
        const sel = h('select', null,
          h('option', { value: '' }, 'Seçin...'),
          h('option', { value: amt >= 0 ? '[in]' : '[out]' }, amt >= 0 ? 'Digər Şirkətlərdən Daxilolmalar' : 'Digər Şirkətlərə Ödənişlər'),
          ...cats.map((c) => h('option', { value: c }, c)));
        sel.onchange = () => { choices[k] = sel.value; };
        box.appendChild(h('div', { class: 'bnk-unkrow' }, h('div', { class: 'bnk-unkd' }, h('span', null, k.replace(/^\?\?\s*/, '')), h('b', null, D.money(amt))), sel));
      });
      const go = h('button', { class: 'primary', style: 'margin-top:10px' }, 'Təsdiq et və Excel yarat');
      go.onclick = () => finish(AMMO_BANK.applyManual(result, choices));
      box.appendChild(go);
      extra.appendChild(box);
    }

    btn.onclick = () => runButton(btn, st, async () => {
      if (!picked.length) throw new Error('Ən azı bir fayl seçin.');
      st.set('info', 'Fayllar oxunur və emal edilir...');
      const result = await AMMO_BANK.process(picked.map((p) => ({ file: p.file, bankCode: p.bank, name: p.file.name })));
      if (result.cardStatement) throw new Error('Kart çıxarışı aşkar edildi. Hesab (cari) çıxarışını yükləyin.');
      if (result.nothing) throw new Error('Faylda əməliyyat tapılmadı. Düzgün bank seçildiyini yoxlayın.');
      if (result.currencies.length > 1) throw new Error('Fərqli valyutalı fayllar: ' + result.currencies.join(', ') + '. Eyni valyutalı faylları yükləyin.');
      if (result.voens.length > 1) throw new Error('Fərqli VÖEN-lərə aid fayllar: ' + result.voens.join(', ') + '. Eyni VÖEN-ə aid faylları yükləyin.');
      if (result.unknowns.length) { st.set('info', `${result.unknowns.length} əməliyyat avtomatik tanınmadı — aşağıda kateqoriya seçin.`); askUnknowns(result); }
      else await finish(result);
    });

    return h('div', null,
      h('div', { class: 'note', style: 'margin:0 0 12px' }, 'Bank çıxarışını (Excel) seçin, bankı təyin edin — proqram əməliyyatları kateqoriyalara bölüb “İcmal” Excel yaradır. Hər şey brauzer daxilində aparılır. Birdən çox faylı (eyni VÖEN və valyuta) birləşdirə bilərsiniz.'),
      h('div', { class: 'bnk-top' }, addBtn), file, listBox, extra, btn, st);
  }

  // ------------------------------------------------------------------ ƏDV Analiz
  function panelEdv() {
    const st = statusBox();
    const mkFile = (label, hint) => {
      const inp = h('input', { type: 'file', accept: '.xlsx', style: 'display:none' });
      const name = h('span', { class: 'edv-fname' }, 'Fayl seçilməyib');
      const btn = h('button', { class: 'ghost' }, 'Fayl seç');
      btn.onclick = () => inp.click();
      inp.onchange = () => { name.textContent = inp.files[0] ? inp.files[0].name : 'Fayl seçilməyib'; name.classList.toggle('has', !!inp.files[0]); };
      return { el: h('div', { class: 'edv-drop' }, h('div', { class: 'edv-dh' }, h('strong', null, label), h('small', null, hint)), h('div', { class: 'edv-dr' }, btn, name), inp), inp };
    };
    const fIn = mkFile('Daxil olan qaimələr (Excel)', 'Vergi portalından yüklənmiş əsas fayl');
    const fRep = mkFile('Əvəzləşən qaimələr (Excel)', 'Nümunəyə uyğun doldurulmuş əvəzləşmə faylı');
    const btn = h('button', { class: 'primary' }, 'Faylları yüklə və analiz et');
    const tpl = h('a', { href: '#', class: 'edv-tpl', onclick: (e) => { e.preventDefault(); downloadTemplate(); } }, 'Boş nümunə Excel yüklə');

    function downloadTemplate() {
      const head = ['İl', 'Ay', 'VÖEN', 'Qaimənin seriyası', 'Qaimənin nömrəsi', 'Ümumi məbləğ, manatla', 'ƏDV məbləği, manatla', 'Ödənilmiş ümumi məbləğ, manatla', 'Ödənilmiş ƏDV məbləği, manatla'];
      const rows = [head.map((v) => ({ v, s: 'h' })), ['2025', 'Yanvar', '1234567890', 'E', '001245', 1000, 180, 1000, 180]];
      X.download([{ name: 'Əvəzləşənlər', rows, maxWidth: 34 }], 'evezleshme_numune.xlsx');
    }

    btn.onclick = () => runButton(btn, st, async () => {
      if (!fIn.inp.files[0]) throw new Error('“Daxil olan qaimələr” faylını seçin.');
      if (!fRep.inp.files[0]) throw new Error('“Əvəzləşən qaimələr” faylını seçin.');
      st.set('info', 'Fayllar oxunur...');
      const [incRows, repRows] = await Promise.all([AMMO_XLSX_READ.readFile(fIn.inp.files[0]), AMMO_XLSX_READ.readFile(fRep.inp.files[0])]);
      st.set('info', 'Analiz edilir...');
      const res = AMMO_EDV.run(incRows, repRows);
      const key = 'ammo_result_' + Date.now();
      await chrome.storage.local.set({ [key]: res });
      await chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/edv.html', key });
      const s = res.stats;
      st.set('ok', `Hazırdır: ${s.full} tam, ${s.partial} qismən, ${s.unmatched} əvəzləşməyən, ${s.invalid} uyğun olmayan. Nəticə yeni tabda açıldı.`);
    });

    return h('div', null,
      h('div', { class: 'note', style: 'margin:0 0 14px' },
        'Vergi portalından yüklədiyiniz “Daxil olan qaimələr” faylı ilə özünüzün “Əvəzləşən qaimələr” faylını tutuşdurur. ',
        'Hər iki Excel brauzer daxilində oxunur, heç yerə göndərilmir. ', tpl, '.'),
      fIn.el, fRep.el,
      h('div', { class: 'note edv-info', style: 'margin-top:12px' },
        'Müqayisədə daxil olan fayldakı “ƏDV-yə cəlb edilən” məbləğ əvəzləşən fayldakı “Ödənilmiş ümumi məbləğ” ilə, “Malın ƏDV məbləği” isə “Ödənilmiş ƏDV məbləği” ilə tutuşdurulur.'),
      btn, st);
  }

  // ------------------------------------------------------------------ ƏDV Əvəzləşməsi (v1.19.0)
  function panelEvez() {
    const P = window.AMMO_EVEZ_PORTAL;
    const st = statusBox();
    const cy = new Date().getFullYear();
    const year = h('select', null, h('option', { value: 'all' }, '★ Bütün illər (mükəlləfiyyətdən bu günə)'));
    for (let y = cy; y >= 2019; y--) year.appendChild(h('option', { value: String(y) }, `${y}-ci il`));
    year.appendChild(h('option', { value: 'range' }, 'Tarix aralığı (aşağıda)'));
    const from = h('input', { type: 'date' }), to = h('input', { type: 'date', value: todayISO() });
    const oblBox = h('div', { class: 'ev-obl' }, 'ƏDV mükəlləfiyyəti yoxlanılır…');
    const oblIn = h('input', { type: 'month', style: 'max-width:180px' });
    const oblEdit = h('div', { class: 'ev-edit', style: 'display:none' }, h('label', { class: 'lbl' }, 'Başlama ayını əl ilə yazın (istəyə bağlı)'), oblIn);
    const drafts = check('Qaralama halında olan bəyannaməni də götür (həmin ay üçün başqa bəyannamə yoxdursa)');
    const autoDep = check('ƏDV depozit hesabını portaldan avtomatik çək və əvəzləşməyənləri «hüququ var / hüququ yoxdur» kimi ayır', true);
    const depState = h('div', { class: 'hint', style: 'margin:-2px 0 6px 26px' });
    chrome.storage.local.get('ammo_vatacc_tpl').then((o) => {
      const t = o.ammo_vatacc_tpl;
      depState.textContent = t ? `✓ ƏDV depozit hesabının sorğusu öyrənilib (${new Date(t.at).toLocaleDateString('az-AZ')}) — seçilmiş tarix aralığı üçün avtomatik yüklənəcək.`
        : 'İlk dəfə: AMMO «ƏDV depozit hesabı» (vat-account) səhifəsini fonda açıb sorğunu öyrənəcək. Alınmasa — portalda həmin səhifəni bir dəfə açın.';
    }).catch(() => {});
    const btn = h('button', { class: 'primary' }, 'Əvəzləşməni hesabla');
    let obl = null;

    const syncDates = () => {
      const v = year.value;
      if (v === 'all') { from.value = obl && obl.start ? `${obl.start}-01` : ''; to.value = todayISO(); }
      else if (v !== 'range') { from.value = `${v}-01-01`; to.value = `${v}-12-31` < todayISO() ? `${v}-12-31` : todayISO(); }
    };
    year.onchange = syncDates;
    const toRange = () => { year.value = 'range'; };
    from.onchange = toRange; to.onchange = toRange;

    (async () => {
      try {
        const tin = P.ownTin();
        obl = await P.savedObligation(tin);
        oblBox.innerHTML = '';
        if (obl) {
          oblBox.append(h('b', null, `ƏDV: ${AMMO_EVEZ.ymLabel(obl.start)} → ${obl.end ? AMMO_EVEZ.ymLabel(obl.end) : 'bu gün (aktiv)'}`),
            h('small', null, `Mənbə: portalın «Mükəlləfiyyətlər» bölməsi${tin ? ' · VÖEN ' + tin : ''}`));
        } else {
          oblBox.append(h('b', null, 'ƏDV mükəlləfiyyətinin başlanğıcı hələ məlum deyil'),
            h('small', null, 'Portalda Şəxsi kabinet → «Mükəlləfiyyətlər» bölməsini bir dəfə açın — AMMO tarixi özü oxuyub yadda saxlayacaq. Açmasanız, ilk ƏDV bəyannaməsinin ayı götürüləcək.'));
        }
        const ed = h('a', { href: '#', onclick: (e) => { e.preventDefault(); oblEdit.style.display = oblEdit.style.display === 'none' ? '' : 'none'; } }, 'dəyiş');
        oblBox.append(ed);
        syncDates();
      } catch (e) { oblBox.textContent = ''; }
    })();

    btn.onclick = () => runButton(btn, st, async () => {
      const mode = year.value === 'all' ? 'all' : year.value === 'range' ? 'range' : 'year';
      if (mode === 'range' && (!from.value || !to.value)) throw new Error('Başlanğıc və son tarixi seçin.');
      if (mode === 'range' && from.value > to.value) throw new Error('Başlanğıc tarixi son tarixdən böyük ola bilməz.');
      const t0 = Date.now();
      const { inputs } = await P.collect({ mode, year: year.value, fromISO: from.value, toISO: to.value, drafts: drafts.cb.checked, oblOverride: oblIn.value || '', autoDeposit: autoDep.cb.checked }, (t) => st.set('info', t));
      st.set('info', 'Nəticə hazırlanır…');
      const res = AMMO_EVEZ.analyze({ ...inputs, deposit: inputs.deposit || null });
      const key = 'ammo_result_' + Date.now();
      await chrome.storage.local.set({ [key]: { kind: 'evez', inputs, created: Date.now() } });
      await chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/evez.html', key });
      const T = res.totals;
      st.set('ok', `Hazırdır (${Math.round((Date.now() - t0) / 1000)} san): ${T.invoices} qaimə, ${inputs.decls.length} bəyannamə.\n` +
        `Əvəzləşib ${D.money(T.offVat)} / ${D.money(T.vat)} (${T.pct}%) · tam ${T.full}, qismən ${T.partial}, əvəzləşməyən ${T.none}.\n` +
        (inputs.deposit ? `Əvəzləşmə HÜQUQU VAR, əvəzləşməyib: ${D.money(T.rightVat)} (${T.rightCount} qaimə) · hüququ YOXDUR: ${D.money(T.noRightVat)} (${T.noRightCount} qaimə).\n` : (inputs.notes && inputs.notes[0] ? inputs.notes[0] + '\n' : '')) +
        'Nəticə yeni tabda açıldı.');
    });

    return h('div', null,
      h('div', { class: 'note', style: 'margin:0 0 14px' },
        'AMMO arxa planda bütün ƏDV bəyannamələrini açır, Əlavə 1-dəki (308, 314, 316 və 310 — YGB) qaimələri alış qaimələri ilə seriya-nömrə üzrə tutuşdurur və ',
        h('b', null, 'hansı qaimənin nə qədəri əvəzləşib, nə qədəri əvəzləşməyib'), ' — aylar və illər üzrə göstərir. Portala heç nə yazılmır, yalnız oxunur.'),
      oblBox, oblEdit,
      h('label', { class: 'lbl' }, 'İl'), year,
      h('div', { class: 'row2' }, h('div', null, h('label', { class: 'lbl' }, 'Başlanğıc tarixi'), from), h('div', null, h('label', { class: 'lbl' }, 'Son tarix'), to)),
      h('div', { class: 'hint' }, 'İl seçəndə tarixlər özü dolur; tarixi dəyişsəniz «Tarix aralığı» rejiminə keçir. Əvəzləşmə sonrakı aylarda da ola bildiyi üçün bəyannamələr həmişə bu günə qədər oxunur.'),
      drafts.el, autoDep.el, depState,
      h('div', { class: 'note ev-tip', style: 'margin-top:12px' },
        h('b', null, 'Əvəzləşmə hüququ (VM 175.1): '), 'ƏDV depozit hesabından təchizatçıya MƏXARİC olan qaimələr üzrə hüquq yaranıb — əvəzləşməyibsə, ödəniş ayının bəyannaməsində əvəzləşdirilə bilər. Depozitdən ödənilməyən qaimələr üzrə hüquq hələ yoxdur. ',
        'Gömrük məlumatını nəticə səhifəsində «Mənbələr» ilə əlavə edə bilərsiniz.'),
      btn, st);
  }

  // ------------------------------------------------------------------ Linklər
  const LINKS = [
    // Gömrük / vergi / dövlət
    { n: 'E-Taxes', d: 'Yeni e-taxes portalı (ASAN İmza girişi)', u: 'https://new.e-taxes.gov.az/eportal/login/asan', c: 'gov' },
    { n: 'ƏMAS — Gömrük', d: 'Gömrük ƏMAS / trader portalı (bəyannamə)', u: 'https://egbtrader2.customs.gov.az/', c: 'customs' },
    { n: 'E-Customs', d: 'Elektron gömrük portalı', u: 'https://e.customs.gov.az/auth/asan', c: 'customs' },
    { n: 'E-Sosial', d: 'Əmək və sosial müdafiə portalı', u: 'https://e-social.gov.az/az', c: 'gov' },
    { n: 'MyGovID', d: 'ASAN login / dövlət giriş sistemi', u: 'https://mygovid.gov.az/auth/with-asan-login', c: 'gov' },
    { n: 'myGov', d: 'Dövlət xidmətləri portalı', u: 'https://my.gov.az', c: 'gov' },
    { n: 'ASAN Doc', d: 'Elektron sənəd imzalama', u: 'https://asandoc.az/', c: 'gov' },
    { n: 'Statistika', d: 'Dövlət Statistika Komitəsi hesabatları', u: 'https://www.azstat.gov.az/', c: 'gov' },
    { n: 'E-Qanun', d: 'Azərbaycan qanunvericilik bazası', u: 'https://e-qanun.az/', c: 'gov' },
    // Banklar
    { n: 'BirBank Business', d: 'Kapital Bank biznes kabineti', u: 'https://my.birbank.business/login', c: 'bank' },
    { n: 'ABB Business', d: 'ABB korporativ internet bank', u: 'https://cb.abb-bank.az/login/az', c: 'bank' },
    { n: 'Azər-Türk Bank Business', d: 'ATB korporativ giriş', u: 'https://business.atb.az/corporate/login', c: 'bank' },
    { n: 'Bank Respublika iOfis', d: 'Bank Respublika biznes kabineti', u: 'https://iofis.bankrespublika.az/login', c: 'bank' },
    { n: 'Unibank Business', d: 'Unibank korporativ giriş', u: 'https://online.unibank.az/corporate/', c: 'bank' },
    { n: 'PASHA Bank Digital', d: 'Paşa Bank biznes giriş', u: 'https://pashabank.digital/login#/asan-login', c: 'bank' },
    { n: 'Rabitəbank iBank', d: 'Rabitəbank internet bank', u: 'https://ib.rabitabank.com/InterBank/#/', c: 'bank' },
    { n: 'MyAccess (Access Bank)', d: 'Access Bank giriş sistemi', u: 'https://myaccess.az/login', c: 'bank' },
    { n: 'Premium Bank', d: 'Premium Bank internet bank', u: 'https://ibank.premiumbank.az/auth?id=2', c: 'bank' },
    { n: 'Expressbank', d: 'Expressbank korporativ giriş', u: 'https://cb.expressbank.az/auth/login', c: 'bank' },
    { n: 'ASB Internet Bank', d: 'ASB Bank internet bank', u: 'https://internet.asb.az/CustomLogin/Retail', c: 'bank' },
    { n: 'Bank of Baku E-Bank', d: 'Bank of Baku internet bank', u: 'https://www.e-bankofbaku.com/InterBankNew/asan_login', c: 'bank' },
    { n: 'XalqOnline', d: 'Xalq Bank online giriş', u: 'https://xalqonline.az/az/auth/login', c: 'bank' },
    { n: 'AFB Bank', d: 'AFB Bank biznes giriş', u: 'https://business.afb.az/login', c: 'bank' },
    { n: 'VTB Bank', d: 'VTB biznes giriş', u: 'https://business.vtb.az/login', c: 'bank' },
    { n: 'Ziraat Bank', d: 'Ziraat Bank korporativ giriş', u: 'https://online.ziraatbank.az/', c: 'bank' },
    { n: 'TuranBank Online', d: 'TuranBank ASAN giriş', u: 'https://online.turanbank.az/login/juridical/asan/', c: 'bank' },
    { n: 'Yelo Business', d: 'Yelo Bank biznes giriş', u: 'https://yelo.business/az/login', c: 'bank' },
    { n: 'Yapı Kredi Internet Bank', d: 'Yapı Kredi korporativ giriş', u: 'https://intbank.yapikredi.com.az/', c: 'bank' },
    { n: 'Kapital Bank', d: 'Kapital Bank internet bank', u: 'https://www.kapitalbank.az/login', c: 'bank' },
    // Alətlər
    { n: 'iLovePDF', d: 'PDF alətləri', u: 'https://www.ilovepdf.com/', c: 'tool' },
    { n: 'ChatGPT', d: 'Süni intellekt köməkçisi', u: 'https://chatgpt.com/', c: 'tool' },
    { n: 'Claude', d: 'Süni intellekt köməkçisi', u: 'https://claude.ai/', c: 'tool' },
  ];
  const LINK_ICON = { gov: '🏛️', customs: '🚚', bank: '🏦', tool: '🧰' };
  const LINK_CAT = { gov: 'Dövlət', customs: 'Gömrük', bank: 'Bank', tool: 'Alət' };

  function panelLinks() {
    const grid = h('div', { class: 'lnk-grid' });
    const count = h('span', { class: 'lnk-count' });
    const search = h('input', { type: 'text', placeholder: 'Axtarış: məsələn ABB, vergi, gömrük, asan, bank...', autocomplete: 'off' });
    function render() {
      const q = foldAz(search.value);
      const list = LINKS.filter((l) => !q || foldAz(l.n + ' ' + l.d + ' ' + LINK_CAT[l.c]).includes(q));
      count.textContent = `${list.length} link`;
      grid.innerHTML = '';
      list.forEach((l) => {
        const card = h('button', { class: 'lnk-card', title: l.u },
          h('span', { class: 'lnk-ic ' + l.c }, LINK_ICON[l.c]),
          h('span', { class: 'lnk-tx' }, h('strong', null, l.n), h('small', null, l.d), h('span', { class: 'lnk-url' }, l.u.replace(/^https?:\/\//, ''))));
        card.onclick = () => chrome.runtime.sendMessage({ type: 'AMMO_OPEN_URL', url: l.u });
        grid.appendChild(card);
      });
    }
    search.oninput = render;
    render();
    return h('div', null,
      h('div', { class: 'lnk-top' }, search, count),
      h('div', { class: 'note', style: 'margin:0 0 12px' }, 'Bank, vergi, gömrük və gündəlik istifadə olunan keçidlər. Üstünə vuranda sayt yeni tabda açılır — ASAN İmza ilə daxil olun.'),
      grid);
  }

  // ------------------------------------------------------------------ Sənəd hazırla
  function panelSened() {
    const open = (key) => chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/sened.html', key: key || 'new' });
    const list = h('div', { class: 'sened-list' });
    const TPL = [['🏢', 'İcarə'], ['🚗', 'Avtomobil icarəsi'], ['🛒', 'Alqı-satqı'], ['📦', 'Mal göndərişi'], ['🤝', 'Xidmət'], ['📊', 'Mühasibat xidməti'], ['🏗️', 'Podrat'], ['💰', 'Borc'], ['🧭', 'Agent'], ['🔒', 'Məxfilik (NDA)'], ['🧑‍💼', 'Mülki-hüquqi'], ['🚚', 'Yükdaşıma']];
    chrome.storage.local.get('sened_docs').then((o) => {
      const docs = (o.sened_docs || []).slice().sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt))).slice(0, 6);
      list.innerHTML = '';
      if (!docs.length) { list.appendChild(h('div', { class: 'note' }, 'Hələ sənəd hazırlanmayıb.')); return; }
      list.appendChild(h('div', { style: 'font-weight:700;margin:14px 0 6px' }, 'Son sənədlər'));
      docs.forEach((d) => list.appendChild(h('button', { style: 'display:block;width:100%;text-align:left;margin:4px 0;padding:8px 10px;border:1px solid rgba(0,0,0,.12);border-radius:8px;background:#fff;cursor:pointer', onclick: () => open(d.id) }, `🖋️ ${d.name} · ${d.number || ''}`)));
    }).catch(() => {});
    return h('div', null,
      h('div', { class: 'note', style: 'margin:0 0 12px' },
        'Hazır şablonlar və ya öz müqaviləniz (Word .docx/.doc, PDF) — strukturu avtomatik təyin olunur. Sol və sağ tərəfə vəsiqəni, şirkət məlumatlarını və bank rekvizitlərini olduğu kimi yapışdırın — hamısı özü doldurulur. İmza vəsiqədən götürülür, möhür imzanın üstünə qoyulur, rekvizitlər hər müqavilədə eyni səliqəli cədvəldə. Word və PDF yükləyin.'),
      h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px' }, TPL.map(([i, n]) => h('span', { style: 'border:1px solid rgba(0,0,0,.12);border-radius:20px;padding:4px 10px;font-size:12.5px' }, `${i} ${n}`))),
      h('button', { class: 'primary', style: 'font-size:15px;padding:12px 18px', onclick: () => open('new') }, '📄 Sənəd hazırla pəncərəsini aç'),
      list);
  }

  // ------------------------------------------------------------------ Sənəd dövriyyəsi
  function panelDovriyye() {
    const open = (key) => chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/dovriyye.html', key: key || 'home' });
    const tile = (n, t, key) => h('button', { style: 'flex:1;min-width:120px;text-align:left;border:1px solid rgba(0,0,0,.12);border-radius:10px;background:#fff;padding:10px 12px;cursor:pointer', onclick: () => open(key) }, h('b', { style: 'display:block;font-size:20px' }, String(n)), h('span', { style: 'font-size:12px;opacity:.7' }, t));
    const stats = h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin:14px 0' });
    const list = h('div');
    chrome.storage.local.get('ammo_dd_summary').then((o) => {
      const s = o.ammo_dd_summary; if (!s) return;
      stats.append(tile(s.total, 'sənəd arxivdə', 'arxiv'), tile(s.month, 'bu ay əlavə edilib', 'arxiv'), tile(s.subjects, 'subyekt (hüquqi/fiziki)', 'subjects'), tile(s.expiring, 'müddəti bitən', 'arxiv'));
      if ((s.recent || []).length) {
        list.appendChild(h('div', { style: 'font-weight:700;margin:6px 0' }, 'Son sənədlər'));
        s.recent.forEach((d) => list.appendChild(h('button', { style: 'display:block;width:100%;text-align:left;margin:4px 0;padding:8px 10px;border:1px solid rgba(0,0,0,.12);border-radius:8px;background:#fff;cursor:pointer', onclick: () => open('doc:' + d.id) }, `${d.icon} ${d.title} · ${d.subj}`)));
      }
    }).catch(() => {});
    return h('div', null,
      h('div', { class: 'note', style: 'margin:0 0 12px' },
        'Elektron arxiv və kargüzarlıq: hesab-faktura, qiymət razılaşdırma protokolu, müqavilələr, təhvil-təslim və üzləşmə aktları, əmək müqavilələri, ərizə, əmr, arayış, tabel, hesablama-ödəmə cədvəli və s. Sənədi yükləyin — AMMO onu oxuyur (PDF, Word, Excel, skan/şəkil), növünü və sahibini (hüquqi və ya fiziki şəxs — VÖEN/FİN/ad üzrə) özü təyin edir, «Sənəd dövriyyəsinə göndərilsin?» deyə soruşur və uyğun qovluğa yerləşdirir. Sonra tarix aralığı, ad, şirkət, VÖEN və mətn üzrə axtarın, vergi orqanına və başqalarına paket kimi göndərin.'),
      h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap' },
        h('button', { class: 'primary', style: 'font-size:15px;padding:12px 18px', onclick: () => open('home') }, '🗄️ Sənəd dövriyyəsini aç'),
        h('button', { style: 'font-size:14px;padding:12px 16px;border:1px solid rgba(0,0,0,.15);border-radius:10px;background:#fff;cursor:pointer', onclick: () => open('arxiv') }, '🔎 Arxivdə axtar')),
      stats, list);
  }

  // ------------------------------------------------------------------ Sosial şəbəkə analizi (v1.23)
  function panelSocial() {
    const open = () => chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/social.html', key: 'home' });
    const last = h('div', { class: 'note', style: 'margin-top:12px' }, 'Son hesabat yüklənir…');
    chrome.storage.local.get('ammo_social_last').then((o) => {
      const r = o.ammo_social_last;
      if (!r) { last.textContent = 'Hələ analiz aparılmayıb.'; return; }
      last.replaceChildren(h('b', null, `Son analiz: ${new Date(r.at).toLocaleString('az-AZ')}`), h('div', null, `Cavabsız: ${r.counts.unanswered} · Tapşırıq: ${r.counts.task} · Sual: ${r.counts.question} · Səsli: ${r.counts.voice}`));
    }).catch(() => { last.textContent = ''; });
    return h('div', null,
      h('div', { class: 'note', style: 'margin:0 0 12px' }, 'Gmail / e-poçt, WhatsApp və Telegram yazışmalarınızı oxuyur: sizə gələn, amma cavablamadığınız suallar, tapşırıqlar, səsli mesajlar — tarixi ilə, hesabat şəklində. Hər sətrin üzərinə basanda həmin yazışma birbaşa açılır.'),
      h('button', { class: 'primary', style: 'font-size:15px;padding:12px 18px', onclick: open }, '💬 Sosial şəbəkə analizini aç'), last);
  }

  // ------------------------------------------------------------------ shell
  // [ad, panel, izah, ikon, qrup, id] — id admin panelində (İdarəetmə) panelləri bağlamaq üçündür
  const TABS = [
    ['Elektron Qaimələr', panelInvoices, 'Alış və satış qaimələri mal sətirləri ilə, Excel-ə hazır', 'doc', null, 'invoices'],
    ['Elektron Qaimələrin Qaytarılması', panelReturns, 'ƏDV-nin qaytarılması üçün qaimələrin siyahısı', 'back', null, 'returns'],
    ['Aktlar', panelActs, 'Elektron alış aktları — status və növ üzrə', 'stamp', null, 'acts'],
    ['Bəyannamələr', panelDeclarations, 'Seçdiyiniz il və aylar üzrə bəyannamə cədvəlləri', 'chart', null, 'declarations'],
    ['HF və TTA', panelHfTta, 'Qaimə nömrələri üzrə Word sənədləri: TTA, RP, HF', 'word', null, 'hftta'],
    ['Sub-uçot Köçürmələr', panelSubAccount, 'Ödənişin əsas hesab və ƏDV depoziti arasında bölgüsü', 'split', null, 'subaccount'],
    ['Sürətli təqdim etmə', panelQuickSubmit, 'Qaralamaları bir dəfəyə təqdimə hazırlayın', 'bolt', null, 'quicksubmit'],
    ['İlkin audit', panelAudit, 'Şirkətin tam mənzərəsi: profil, bəyannamələr, real gəlir-xərc, mal qalığı, daxil olan pullar, ƏDV, borclar, məktublar', 'scale', null, 'audit'],
    ['Bank Çıxarışı', panelBank, 'Bank çıxarışını kateqoriyalara böl və İcmal Excel yarat', 'bank', null, 'bank'],
    ['ƏDV Əvəzləşməsi', panelEvez, 'Bütün bəyannamələr üzrə hansı qaimə nə qədər əvəzləşib — aylar, illər, gömrük, depozit ödənişləri', 'evez', null, 'evez'],
    ['ƏDV Analiz', panelEdv, 'Daxil olan və əvəzləşən qaimələri tutuşdur — tam/qismən/əvəzləşməyən', 'edv', null, 'edv'],
    ['Sənəd hazırla', panelSened, 'Müqavilələr: icarə, alqı-satqı, xidmət və s. — vəsiqədən ad, imza və möhür avtomatik; Word və PDF', 'contract', null, 'sened'],
    ['Sənəd dövriyyəsi', panelDovriyye, 'Elektron arxiv: yüklə → AMMO oxusun, növünü və şirkəti təyin etsin → qovluğa düşsün', 'archive', null, 'dovriyye'],
    ['Sosial şəbəkə analizi', panelSocial, 'Gmail, WhatsApp, Telegram: cavabsız suallar, tapşırıqlar, səsli mesajlar — hesabat və birbaşa keçid', 'chat', null, 'social'],
    ['Linklər', panelLinks, 'Bank, vergi, gömrük (ƏMAS) və gündəlik portallar — bir kliklə aç', 'link', null, 'links'],
    ['MƏNFƏƏT HESABATI', () => panelTaxRep('profit'), 'Mənfəət vergisinin illik bəyannaməsi — il seçin, «Doldur»: portal məlumatından avtomatik', 'profit', 'taxrep', 'taxrep_profit'],
    ['GƏLİR HESABATI', () => panelTaxRep('income'), 'Gəlir vergisinin (fərdi sahibkar) illik bəyannaməsi — il seçin, «Doldur»: portal məlumatından avtomatik', 'income', 'taxrep', 'taxrep_income'],
  ];
  // Rail sırası: «Vergi hesabatları» qrupu «Bəyannamələr»-dən sonra; üzərinə gələndə aşağı açılır
  const GROUPS = { taxrep: { label: 'Vergi hesabatları', icon: 'report', after: 3 } };
  const ICONS = {
    evez: '<path d="M7 4h10M7 20h10"/><path d="M5 8h14v8H5z"/><path d="m9 12 2 2 4-4"/>',
    archive: '<path d="M3 4h18v4H3z"/><path d="M5 8v12h14V8"/><path d="M10 12h4"/>',
    bank: '<path d="M3 10 12 4l9 6M5 10v9M19 10v9M9 10v9M15 10v9M3 21h18"/>',
    contract: '<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 11h7M9 14h7"/><path d="M9 18c1-1.4 2-1.4 2.6 0s1.6 1.2 2.4-.4"/>',
    edv: '<path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h5"/><path d="m15 15 2 2 3-3.5"/>',
    link: '<path d="M9 13a4 4 0 0 0 5.66 0l2.83-2.83a4 4 0 0 0-5.66-5.66l-1 1"/><path d="M15 11a4 4 0 0 0-5.66 0L6.5 13.83a4 4 0 0 0 5.66 5.66l1-1"/>',
    doc: '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M10 12h5M10 16h5"/>',
    back: '<path d="M9 7 4 12l5 5"/><path d="M4 12h11a5 5 0 0 1 0 10h-2"/>',
    stamp: '<path d="M9 3h6v6l3 4H6l3-4z"/><path d="M5 17h14v4H5z"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    word: '<path d="M5 3h10l4 4v14H5z"/><path d="m8 11 1.5 6L12 12l2.5 5L16 11"/>',
    split: '<path d="M12 3v6M12 9 5 15v6M12 9l7 6v6"/>',
    bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
    scale: '<path d="M12 3v18M7 21h10M4 7h16"/><path d="m4 7-3 7a3.5 3.5 0 0 0 6 0zM20 7l-3 7a3.5 3.5 0 0 0 6 0z"/>',
    report: '<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4"/><path d="M9 17v-3M12 17v-6M15 17v-4"/>',
    profit: '<path d="M4 19h16"/><path d="m5 15 4-4 3 3 6-7"/><path d="M14 7h4v4"/>',
    income: '<circle cx="12" cy="8" r="3.2"/><path d="M5.5 20a6.5 6.5 0 0 1 13 0"/><path d="M17 4.5h4M19 2.5v4"/>',
    chat: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
    chev: '<path d="m6 9 6 6 6-6"/>',
  };
  const icon = (name) => { const sp = h('span', { class: 'ico', 'aria-hidden': 'true' }); sp.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ''}</svg>`; return sp; };

  const host = document.createElement('div');
  host.id = 'ammo-root';
  const root = host.attachShadow({ mode: 'open' });
  root.appendChild(h('link', { rel: 'stylesheet', href: chrome.runtime.getURL('content/ui.css') }));

  // edge tab: sits on the right edge, a little above the middle; slides out on hover
  const launcher = h('button', { class: 'launcher', title: 'AMMO — Vergi xidmətləri', 'aria-label': 'AMMO pəncərəsini aç', onclick: () => openModal() },
    h('span', { class: 'l-mark' }, h('i', null, 'A'), h('b', null)), h('span', { class: 'l-word' }, 'AMMO'));

  // ---- versiya, istifadəçi, yeniləmə zolağı
  const CL = window.AMMO_CLOUD;
  const VERSION = chrome.runtime.getManifest().version;
  let ME = null, CONF = null;
  const verText = h('span', null, `Versiya ${VERSION}`);
  const checkLink = h('a', { href: '#', onclick: (e) => { e.preventDefault(); manualCheck(); } }, 'Yenilikləri yoxla');
  const userLine = h('span', { class: 'who' });
  const adminBtn = h('button', { class: 'tab admin-btn', style: 'display:none', onclick: () => chrome.runtime.sendMessage({ type: 'AMMO_OPEN_PAGE', page: 'pages/admin.html', key: 'home' }) }, icon('gear'), h('span', null, 'İdarəetmə paneli'));
  const logoutLink = h('a', { href: '#', onclick: async (e) => { e.preventDefault(); await CL.logout(); ME = null; gate(); } }, 'Çıxış');
  const verLine = h('div', { class: 'ver' },
    h('strong', { style: 'color:#fff' }, 'AMMO şirkəti'),
    h('a', { href: 'tel:+994705539141' }, 'Tel: 070 553 91 41'),
    userLine, verText, checkLink);
  const updText = h('div', { class: 'upd-text' });
  const updBtns = h('div', { class: 'upd-btns' });
  const updBanner = h('div', { class: 'upd', style: 'display:none' }, updText, updBtns);
  let updTimer = null;
  function openDownload(st) {
    const url = (st && st.latest && (st.latest.page || st.latest.url)) || (st && st.page) || (window.AMMO_CONFIG && AMMO_CONFIG.DOWNLOAD_PAGE);
    if (url && /^https:\/\//.test(url)) chrome.runtime.sendMessage({ type: 'AMMO_OPEN_URL', url });
  }
  function renderUpdate(stt, pend) {
    clearInterval(updTimer);
    updText.innerHTML = ''; updBtns.innerHTML = '';
    const latest = stt && stt.latest;
    if (!(stt && stt.available && latest)) { updBanner.style.display = 'none'; return; }
    const notes = Array.isArray(latest.notes) ? latest.notes : (latest.notes ? [latest.notes] : []);
    updText.appendChild(h('b', null, `Yeni versiya: ${latest.version} (sizdə ${VERSION})`));
    if (notes.length) updText.appendChild(h('ul', null, notes.slice(0, 6).map((n) => h('li', null, n))));
    if (pend && pend.failed) {
      updText.appendChild(h('div', { class: 'hint' }, pend.failed === 'no_host'
        ? 'Avtomatik yeniləmə köməkçisi (AMMO-Yenile.exe) bu kompüterdə quraşdırılmayıb. AMMO qovluğundakı AMMO-Yenile.exe faylını bir dəfə açın — sonra yeniləmələr özü gələcək. İndilik ZIP-i yükləyib faylları əvəz edə bilərsiniz.'
        : `Avtomatik yeniləmə alınmadı (${pend.failed}). Yenidən cəhd edin və ya ZIP-i yükləyin.`));
      updBtns.append(h('button', { class: 'upd-dl', onclick: () => chrome.runtime.sendMessage({ type: 'AMMO_APPLY_NOW' }) }, 'Yenidən cəhd et'),
        h('button', { class: 'upd-rl', onclick: () => openDownload(stt) }, 'ZIP-i yüklə'),
        h('button', { class: 'upd-rl', onclick: () => chrome.runtime.sendMessage({ type: 'AMMO_RELOAD' }) }, 'Faylları əvəz etdim — Yenilə'));
    } else if (pend && pend.applyAt) {
      const left = h('span', { class: 'hint' });
      const tick = () => { const s = Math.max(0, Math.round((pend.applyAt - Date.now()) / 1000)); left.textContent = s ? `AMMO ${s} saniyəyə özü yenilənəcək (açıq işləriniz buluda yazılır).` : 'Yenilənir…'; };
      tick(); updTimer = setInterval(tick, 1000);
      updText.appendChild(left);
      updBtns.append(h('button', { class: 'upd-dl', onclick: () => chrome.runtime.sendMessage({ type: 'AMMO_APPLY_NOW' }) }, 'İndi yenilə'),
        h('button', { class: 'upd-rl', onclick: () => chrome.runtime.sendMessage({ type: 'AMMO_POSTPONE', min: 5 }) }, '5 dəq. sonra'));
    } else {
      updBtns.append(h('button', { class: 'upd-dl', onclick: () => chrome.runtime.sendMessage({ type: 'AMMO_CHECK_UPDATE', apply: true }) }, 'İndi yenilə'),
        h('button', { class: 'upd-rl', onclick: () => openDownload(stt) }, 'ZIP-i yüklə'));
    }
    updBanner.style.display = '';
  }
  async function loadUpdateState() {
    try {
      const o = await chrome.storage.local.get(['ammo_update', 'ammo_update_pending', 'ammo_just_updated']);
      renderUpdate(o.ammo_update, o.ammo_update_pending);
      const ju = o.ammo_just_updated;
      if (ju && ju.to === VERSION && Date.now() - ju.at < 864e5 && ju.reason === 'update' && !ju.shown) {
        toast(`✅ AMMO yeniləndi: ${ju.from || ''} → ${ju.to}${(ju.notes || []).length ? '\n• ' + ju.notes.slice(0, 4).join('\n• ') : ''}`);
        chrome.storage.local.set({ ammo_just_updated: { ...ju, shown: true } });
      }
    } catch (e) { /* ignore */ }
  }
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.ammo_update || ch.ammo_update_pending) loadUpdateState();
    if (ch.ammoAdminConfig && ME) { CONF = ch.ammoAdminConfig.newValue || CONF; applyPolicy(); }
  });
  async function manualCheck() {
    checkLink.textContent = 'yoxlanılır...';
    try {
      const stt = await chrome.runtime.sendMessage({ type: 'AMMO_CHECK_UPDATE' });
      checkLink.textContent = stt && stt.available ? 'Yeni versiya var!' : (stt && stt.error === 'not-configured' ? 'Yeniləmə ünvanı qurulmayıb' : (stt && stt.error ? 'Yoxlamaq alınmadı' : 'Ən son versiyadır ✓'));
      loadUpdateState();
    } catch (e) { checkLink.textContent = 'Yoxlamaq alınmadı'; }
    setTimeout(() => { checkLink.textContent = 'Yenilikləri yoxla'; }, 5000);
  }
  function toast(text) {
    const t = h('div', { class: 'toast' }, text);
    root.appendChild(t);
    setTimeout(() => t.remove(), 7000);
  }

  const body = h('div', { class: 'body' });
  const panels = TABS.map(() => null);
  const headTitle = h('h2', null);
  const headSub = h('p', null);
  const tabBtns = TABS.map(([name, , , ic, grp], i) => h('button', { class: 'tab' + (grp ? ' sub' : ''), onclick: () => showTab(i) }, icon(ic), h('span', null, name)));
  const railItems = [];
  const groupEls = {};
  TABS.forEach(([, , , , grp], i) => { if (!grp) railItems.push(tabBtns[i]); });
  Object.entries(GROUPS).forEach(([gid, g]) => {
    const subs = TABS.map((t, i) => (t[4] === gid ? tabBtns[i] : null)).filter(Boolean);
    const head = h('button', { class: 'tab grp-head', 'aria-haspopup': 'true', 'aria-expanded': 'false', onclick: () => { wrap.classList.toggle('open'); head.setAttribute('aria-expanded', wrap.classList.contains('open')); } },
      icon(g.icon), h('span', null, g.label), h('span', { class: 'chev' }, icon('chev')));
    const wrap = h('div', { class: 'grp' }, head, h('div', { class: 'grp-items', role: 'group', 'aria-label': g.label }, subs));
    groupEls[gid] = wrap;
    railItems.splice(Math.min(g.after + 1, railItems.length), 0, wrap);
  });
  const rail = h('aside', { class: 'rail' },
    h('div', { class: 'brand' }, h('span', { class: 'l-mark big' }, h('i', null, 'A'), h('b', null)),
      h('div', null, h('strong', null, 'AMMO'), h('small', null, 'vergi masası'))),
    h('nav', { class: 'tabs', 'aria-label': 'Bölmələr' }, railItems, adminBtn),
    verLine);
  const overlay = h('div', { class: 'overlay', onclick: (e) => { if (e.target === overlay) closeModal(); } },
    h('section', { class: 'modal', role: 'dialog', 'aria-label': 'AMMO Vergi xidmətləri' },
      rail,
      h('div', { class: 'main' },
        h('header', { class: 'head' }, h('div', null, headTitle, headSub),
          h('button', { class: 'close', title: 'Bağla (Esc)', 'aria-label': 'Bağla', onclick: () => closeModal() }, '×')),
        updBanner,
        body)));

  // ---- giriş (Firebase — AMMO SUITE ilə eyni hesablar)
  function loginView(msg) {
    const email = h('input', { type: 'email', placeholder: 'E-poçt (məs. ad@ammo.az)', autocomplete: 'username' });
    const pass = h('input', { type: 'password', placeholder: 'Parol', autocomplete: 'current-password' });
    const st = statusBox();
    if (msg) st.set('bad', msg);
    const btn = h('button', { class: 'primary', style: 'width:100%;padding:12px' }, 'Daxil ol');
    const go = () => runButton(btn, st, async () => {
      if (!email.value.trim() || !pass.value) throw new Error('E-poçt və parolu yazın');
      await CL.login(email.value, pass.value);
      pass.value = '';
      await gate(true);
    });
    btn.onclick = go;
    pass.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    chrome.storage.local.get('ammoLastEmail').then((o) => { if (o.ammoLastEmail) { email.value = o.ammoLastEmail; pass.focus(); } }).catch(() => {});
    email.addEventListener('change', () => chrome.storage.local.set({ ammoLastEmail: email.value.trim() }));
    return h('div', { class: 'login' },
      h('div', { class: 'login-card' },
        h('div', { class: 'login-mark' }, 'A'),
        h('h3', null, 'AMMO-ya daxil olun'),
        h('p', { class: 'hint' }, 'AMMO SUITE ilə eyni hesab. Bütün məlumatınız Firebase (Konsalting) serverində saxlanılır — kompüter dəyişsə də itmir.'),
        h('label', { class: 'lbl' }, 'E-poçt'), email, h('label', { class: 'lbl' }, 'Parol'), pass, h('div', { style: 'height:10px' }), btn, st));
  }
  function blockedView(text) {
    return h('div', { class: 'login' }, h('div', { class: 'login-card' }, h('div', { class: 'login-mark' }, '!'), h('h3', null, 'Giriş məhdudlaşdırılıb'), h('p', null, text),
      h('button', { onclick: async () => { await CL.logout(); ME = null; gate(); } }, 'Başqa hesabla daxil ol')));
  }
  let gated = false;
  async function gate(fresh) {
    gated = true;
    const a = await CL.auth().catch(() => null);
    if (!a) {
      ME = null; rail.classList.add('locked');
      headTitle.textContent = 'Giriş'; headSub.textContent = 'AMMO — vergi masası';
      body.innerHTML = ''; body.appendChild(loginView());
      return false;
    }
    let prof = null;
    try { prof = await CL.profile(a, fresh); } catch (e) { prof = { email: a.email, role: CL.isAdminEmail(a.email) ? 'admin' : 'employee', active: true, offline: true }; }
    if (!prof || !prof.active) {
      rail.classList.add('locked');
      headTitle.textContent = 'Hesab aktiv deyil'; headSub.textContent = a.email;
      body.innerHTML = ''; body.appendChild(blockedView('Hesabınız hələ aktivləşdirilməyib. Admin (İdarəetmə paneli → İstifadəçilər) hesabınızı aktivləşdirməlidir.'));
      return false;
    }
    ME = { ...prof, email: a.email, admin: CL.isAdminEmail(a.email) || prof.role === 'admin' };
    try { CONF = await CL.getConfig(fresh); } catch (e) { CONF = (await chrome.storage.local.get('ammoAdminConfig')).ammoAdminConfig || {}; }
    rail.classList.remove('locked');
    userLine.replaceChildren(h('span', null, ME.email), ' · ', logoutLink);
    adminBtn.style.display = ME.admin ? '' : 'none';
    CL.heartbeat({ page: location.pathname }).catch(() => {});
    applyPolicy();
    return true;
  }
  const visible = (i) => !ME || CL.panelVisible(CONF, TABS[i][5], ME.email);
  function applyPolicy() {
    TABS.forEach((t, i) => { tabBtns[i].style.display = visible(i) ? '' : 'none'; });
    Object.entries(groupEls).forEach(([gid, w]) => { w.style.display = TABS.some((t, i) => t[4] === gid && visible(i)) ? '' : 'none'; });
    if (overlay.classList.contains('open') && ME) {
      const cur = tabBtns.findIndex((b) => b.classList.contains('active'));
      if (cur < 0 || !visible(cur)) { const f = TABS.findIndex((t, i) => visible(i)); if (f >= 0) showTab(f); else { body.innerHTML = ''; body.appendChild(blockedView('Admin bu kompüter üçün bütün panelləri bağlayıb.')); } }
    }
  }

  function showTab(i) {
    if (!ME) { gate(); return; }
    if (!visible(i)) { const f = TABS.findIndex((t, j) => visible(j)); if (f < 0) return; i = f; }
    tabBtns.forEach((b, j) => { b.classList.toggle('active', i === j); b.setAttribute('aria-current', i === j ? 'page' : 'false'); });
    Object.entries(groupEls).forEach(([gid, w]) => w.classList.toggle('has-active', TABS[i][4] === gid));
    headTitle.textContent = TABS[i][0];
    headSub.textContent = TABS[i][2];
    if (!panels[i]) panels[i] = TABS[i][1]();
    body.innerHTML = '';
    body.appendChild(panels[i]);
    body.scrollTop = 0;
    try { localStorage.setItem('ammo_last_tab_id', TABS[i][5]); } catch (e) { /* ignore */ }
  }
  async function openModal(tab) {
    overlay.classList.add('open');
    launcher.classList.add('hide');
    loadUpdateState();
    if (!(await gate())) return;
    let i = tab;
    if (i === undefined) { try { const id = localStorage.getItem('ammo_last_tab_id'); i = Math.max(0, TABS.findIndex((t) => t[5] === id)); } catch (e) { i = 0; } }
    showTab(Math.min(Math.max(i, 0), TABS.length - 1));
  }
  function closeModal() { overlay.classList.remove('open'); launcher.classList.remove('hide'); launcher.focus({ preventScroll: true }); }

  root.appendChild(launcher);
  root.appendChild(overlay);
  document.documentElement.appendChild(host);
  loadUpdateState();

  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && overlay.classList.contains('open')) closeModal(); });
  window.addEventListener('ammo-close-modal', () => { if (overlay.classList.contains('open')) closeModal(); });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'AMMO_TOGGLE') {
      if (overlay.classList.contains('open')) closeModal(); else openModal();
    }
  });

  // Continue quick-submit after navigating to the invoice page
  if (sessionStorage.getItem('ammo_quick_submit') === '1' && /\/eportal\/invoice\/?$/.test(location.pathname)) (async () => {
    sessionStorage.removeItem('ammo_quick_submit');
    await openModal(6);
    const panel = panels[6];
    if (!panel) return;
    const st = panel.querySelector('.status');
    st.set = (kind, text) => { st.className = 'status show ' + kind; st.textContent = text; };
    setTimeout(() => quickSubmit(st).catch((e) => st.set('bad', e.message)), 1500);
  })();
})();
