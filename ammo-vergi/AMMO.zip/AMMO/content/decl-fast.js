/* AMMO — declaration reports built straight from the portal's declaration data
 * (GET /declaration/public/v1/base + a few calc lists). One request per declaration, no page scraping. */
(function (root) {
  'use strict';

  const MAPS = () => root.AMMO_DECL_MAPS;
  const MONTHS_UP = ['YANVAR', 'FEVRAL', 'MART', 'APREL', 'MAY', 'İYUN', 'İYUL', 'AVQUST', 'SENTYABR', 'OKTYABR', 'NOYABR', 'DEKABR'];
  const TYPE_LBL = { CURRENT: 'Cari', CLARIFYING: 'Dəqiqləşdirilmiş', CAMERAL: 'Kameral' };
  const num = (v) => { const x = Number(v); return v === null || v === undefined || v === '' || !isFinite(x) ? 0 : x; };
  const r2 = (v) => Math.round(num(v) * 100) / 100;
  const pad2 = (n) => String(n).padStart(2, '0');
  const hdr = (labels) => [labels.map((t) => ({ t, span: 1 }))];

  function get(obj, path) {
    let o = obj;
    for (const k of String(path).split('.')) { if (o === null || o === undefined) return undefined; o = o[k]; }
    return o;
  }
  const arr = (x) => (Array.isArray(x) ? x : []);
  const byInd = (list) => { const m = new Map(); arr(list).forEach((e) => { if (e && e.indicator && !m.has(e.indicator)) m.set(e.indicator, e); }); return m; };

  // Rows in the form's code order; indicators the form does not know are added at the end with their raw name
  function codeRows(def, ti, extraLookup) {
    const list = arr(get(ti, def.path));
    const map = byInd(list);
    const known = new Set(def.rows.map((r) => r[0]));
    const rows = def.rows.map(([ind, label, alt]) => {
      const e = map.get(ind);
      if (alt) { const v = get(extraLookup || ti, alt); if (num(v) && !num(e && e[def.fields[0]])) return [label, num(v)]; }
      return [label, ...def.fields.map((f) => num(e && e[f]))];
    });
    list.forEach((e) => { if (e && e.indicator && !known.has(e.indicator)) rows.push([e.indicator, ...def.fields.map((f) => num(e[f]))]); });
    return rows;
  }
  const isEmpty = (base) => !base || !base.taxInformation || !Object.keys(base.taxInformation).length;
  const section = (title, header, rows) => ({ title, header: typeof header[0] === 'string' ? hdr(header) : header, rows, empty: !rows.length });

  // ------------------------------------------------------------ Mənfəət vergisi
  function profitSections(base) {
    if (isEmpty(base)) return [];
    const ti = (base && base.taxInformation) || {};
    return MAPS().PROFIT.map((def) => section(def.title, def.header, codeRows(def, ti)));
  }

  // ------------------------------------------------------------ Muzdlu iş (vahid bəyannamə)
  const EMP_COLS = [
    ['2.3', 'INCOME_AMOUNT'], ['2.3.1', 'OTHER_INCOME_AMOUNT'], ['2.4', 'COMPENSATION'], ['4.5', 'MDSS_LIFE_INSURANCE_INVOLVE_AMOUNT'], ['2.6', '#techPark'],
    ['3.1', 'DISCOUNT_AMOUNT', 1], ['3.2', 'INVOLVE_AMOUNT'], ['3.3', 'TAX_AMOUNT'], ['4.1', 'MDSS_NON_INVOLVE_AMOUNT', 1], ['4.2', 'MDSS_INVOLVE_AMOUNT'],
    ['4.3', 'MDSS_INSURER_CALC_AMOUNT'], ['4.4', 'MDSS_INSURER_COMPENSATION_AMOUNT'], ['2.5', 'MDSS_LIFE_INSURANCE_AMOUNT', 1],
    ['4.6', 'MDSS_INSURANT_CALC_AMOUNT'], ['4.7', 'MDSS_INSURANT_COMPENSATION_AMOUNT'], ['5.1', 'UNEMPLOYMENT_NON_INVOLVE_AMOUNT', 1],
    ['5.2', 'UNEMPLOYMENT_INVOLVE_AMOUNT'], ['5.3', 'UNEMPLOYMENT_INSURER_CALC_AMOUNT'], ['5.4', 'UNEMPLOYMENT_INSURANT_CALC_AMOUNT'],
    ['6.2', 'COMPULSORY_INSURANCE_INVOLVE_AMOUNT'], ['6.3', 'COMPULSORY_INSURANCE_INSURER_CALC_AMOUNT'], ['6.4', 'COMPULSORY_INSURANCE_INSURANT_CALC_AMOUNT'],
  ];
  const TECHPARK = { HIRED_INCOME: 'Muzdlu işdən əldə edilən gəlirlərdən', FOUR_TIMES_MINIMUM_WAGE: 'Minimum aylıq əməkhaqqı məbləğinin dörd misli miqdarından' };

  function employeeSection(list) {
    const M = MAPS().EMP;
    const present = new Set();
    list.forEach((e) => arr(e && e.amounts).forEach((a) => present.add(a.indicator)));
    const cols = EMP_COLS.filter(([, ind, opt]) => !opt || present.has(ind));
    const label = (code) => M.header.find((h) => h.startsWith(code + ' ')) || code;
    const header = ['Period', M.header[1], M.header[2], M.header[3], ...cols.map(([c]) => label(c))];
    const rows = [];
    const sorted = [...list].sort((a, b) => num(a.main && a.main.rowOrder) - num(b.main && b.main.rowOrder));
    for (const e of sorted) {
      const m = e.main || {};
      const am = byInd(e.amounts);
      [['Rüb', 'Quarter'], ['1-ci ay', 'M1'], ['2-ci ay', 'M2'], ['3-cü ay', 'M3']].forEach(([p, suf]) => {
        rows.push([p, m.fullName || '', m.pin || '', num(m['dayCount' + suf]), ...cols.map(([, ind]) => {
          if (ind === '#techPark') { if (suf === 'Quarter') return ''; const v = m['techParkMdssInvolveInfo' + suf]; return v ? (TECHPARK[v] || v) : ''; }
          const a = am.get(ind); return num(a && a['amount' + suf]);
        })]);
      });
    }
    return section(M.title, header, rows);
  }

  function unifiedSections(base, extra = {}) {
    if (isEmpty(base)) return [];
    const ti = (base && base.taxInformation) || {};
    const M = MAPS();
    const out = M.UNIFIED.map((def) => {
      if (def.path === 'employeeCount' && !Array.isArray(ti.employeeCount) && ti.employeeCount) {
        const e = ti.employeeCount; return section(def.title, def.header, [[def.rows[0][1], ...def.fields.map((f) => num(e[f]))]]);
      }
      return section(def.title, def.header, codeRows(def, ti));
    });
    const vac = arr(extra.vacation);
    if (vac.length) {
      out.push(section('İstifadə edilməmiş məzuniyyətə görə kompensasiya', ['Kod və Təsviri', 'İşçinin (sığortaolunanın) soyadı, adı, atasının adı', 'FİN', 'İl', 'Kompensasiya məbləği'],
        [...vac].sort((a, b) => num(a.rowOrder) - num(b.rowOrder)).map((x) => [String(x.rowOrder ?? ''), x.fullName || '', x.pin || '', x.year || '', num(x.amount)])));
    }
    const un = arr(extra.unemployed);
    out.push(section(M.UNEMP.title, M.UNEMP.header,
      [...un].sort((a, b) => num(a.rowOrder) - num(b.rowOrder)).map((x) => [String(x.rowOrder ?? ''), x.fullName || '', x.pin || '',
        x.reasonName || x.reason || x.reasonCode || '', num(x.countTotal ?? x.dayCount ?? x.count)])));
    out.push(employeeSection(arr(extra.employees)));
    const fe = arr(extra.foreign);
    if (fe.length) out.push(genericList('Əcnəbi işçilər haqqında məlumat', fe));
    return out;
  }

  // ------------------------------------------------------------ Ödəmə mənbəyində vergi
  const STATUS = { CITIZEN: 'Vətəndaş' };
  const PROPERTY = { REAL_ESTATE: 'Daşınmaz', MOVABLE: 'Daşınar', MOVABLE_PROPERTY: 'Daşınar' };
  function withholdingSections(base, extra = {}) {
    if (isEmpty(base)) return [];
    const ti = (base && base.taxInformation) || {};
    const M = MAPS();
    const out = [section(M.WH.title, M.WH.header, codeRows(M.WH, ti))];
    const codeOf = new Map(M.WH.rows.map(([ind, label]) => [ind, (label.match(/^[\d.\-]+/) || [ind])[0]]));
    const order = new Map(M.WH.rows.map(([ind], i) => [ind, i]));
    const res = [...arr(extra.residents)].sort((a, b) => ((order.get(a.indicator) ?? 999) - (order.get(b.indicator) ?? 999)) || (num(a.rowOrder) - num(b.rowOrder)));
    out.push(section(M.WHR.title, M.WHR.header, res.map((x) => [
      codeOf.get(x.indicator) || x.indicator || '', STATUS[x.legalStatus] || x.legalStatus || '', x.name || x.fullName || '',
      x.birthDate || 'Boş', x.tin || '', num(x.incomeAmount), num(x.taxAmount), x.paymentPeriod || '', x.paymentDate || '',
      PROPERTY[x.propertyType] || x.propertyType || '',
    ])));
    [['nonResidentLegal', 'Qeyri-rezident hüquqi şəxslər'], ['nonResidentPhysical', 'Qeyri-rezident fiziki şəxslər'], ['preferential', 'Güzəştli vergi tutulan ölkələr']]
      .forEach(([k, t]) => { const l = arr(extra[k]); if (l.length) out.push(genericList(t, l)); });
    return out;
  }

  // ------------------------------------------------------------ ƏDV: one wide table, one row per declaration
  function vatValue(ti, src) {
    if (!src) return '';
    const p = src.split('|');
    if (p.length === 3) { const e = byInd(get(ti, p[0])).get(p[1]); return r2(e && e[p[2]]); }
    return r2(get(ti, src));
  }
  function spanRow(vals) {
    const out = [];
    vals.forEach((t) => { const last = out[out.length - 1]; if (last && last.t === t) last.span++; else out.push({ t, span: 1 }); });
    return out;
  }
  function vatTable(items) {
    const cols = MAPS().VAT;
    // first 5 columns are single cells spanning the 3 header rows; keep them as text in every row so Excel/merges stay simple
    const header = [0, 1, 2].map((r) => spanRow(cols.map((c, i) => (i < 5 ? (r === 0 ? c[0] : '') : c[r]))));
    const rows = items.map(({ decl, base }) => {
      const p = decl.reportingPeriod || {};
      const ti = (base && base.taxInformation) || {};
      const m = Number(p.month) || 1;
      const head = [String(decl.registrationNumber || decl.id || ''), String(p.year || ''),
        p.type === 'MONTH' ? MONTHS_UP[m - 1] : p.type === 'QUARTER' ? `${Math.ceil(m / 3)}-CÜ RÜB` : '',
        p.type === 'MONTH' ? `${pad2(m)}.${p.year}` : `${p.year}`, TYPE_LBL[decl.declarationType] || decl.declarationType || ''];
      return [...head, ...cols.slice(5).map((c) => vatValue(ti, c[3]))];
    });
    const totals = cols.map((c, i) => (i === 0 ? 'Cəmi' : i < 5 ? '' : r2(rows.reduce((s, r) => s + num(r[i]), 0))));
    return { title: 'Hesabat Cədvəli', header, rows, totals, empty: !rows.length, merge3: true };
  }

  // ------------------------------------------------------------ any other declaration: every table in its data, raw indicator codes
  const KEY_LBL = {
    amount: 'Məbləğ', cost: 'Dəyər', vat: 'ƏDV', taxAmount: 'Vergi məbləği', incomeAmount: 'Gəlir məbləği', expenseAmount: 'Xərc məbləği',
    fullName: 'Ad Soyad', name: 'Ad', pin: 'FİN', tin: 'VÖEN', rowOrder: '№', indicator: 'Kod',
  };
  function genericList(title, list) {
    const keys = [];
    list.forEach((o) => Object.keys(o || {}).forEach((k) => {
      if (!/^(id|uuid)$/i.test(k) && !keys.includes(k) && (o[k] === null || typeof o[k] !== 'object')) keys.push(k);
    }));
    ['rowOrder', 'indicator'].reverse().forEach((k) => { if (keys.includes(k)) { keys.splice(keys.indexOf(k), 1); keys.unshift(k); } });
    return section(title, keys.map((k) => KEY_LBL[k] || k), list.map((o) => keys.map((k) => (o[k] === null || o[k] === undefined ? '' : o[k]))));
  }
  function genericSections(base) {
    const ti = (base && base.taxInformation) || {};
    const out = [];
    const walk = (obj, path) => {
      Object.entries(obj || {}).forEach(([k, v]) => {
        const p = path ? `${path} / ${k}` : k;
        if (Array.isArray(v)) { if (v.length && typeof v[0] === 'object') out.push(genericList(p, v)); }
        else if (v && typeof v === 'object') {
          const flat = Object.entries(v).filter(([, x]) => x === null || typeof x !== 'object');
          if (flat.length) out.push(section(p, ['Göstərici', 'Dəyər'], flat.map(([a, b]) => [a, b ?? ''])));
          walk(Object.fromEntries(Object.entries(v).filter(([, x]) => x && typeof x === 'object')), p);
        }
      });
    };
    walk(ti, '');
    return out;
  }

  root.AMMO_DECL_FAST = { profitSections, unifiedSections, withholdingSections, vatTable, genericSections, genericList, get };
})(typeof globalThis !== 'undefined' ? globalThis : this);
