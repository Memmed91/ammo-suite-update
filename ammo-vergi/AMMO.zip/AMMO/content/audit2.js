/* AMMO — İlkin audit (v1.23): şirkətin bütün mənzərəsi, yalnız portal məlumatından (OXUMA).
 *  • Şirkət profili, borclar, məktublar — portalın öz API-lərindən AVTOMATİK (heç bir səhifə açmaq, düymə basmaq lazım deyil)
 *  • Bəyannamələr — yalnız «Təsdiqlənmiş» və «Uyğunsuzluq»; təsdiqin növü: Kameral / Analoji / Adi
 *  • Gəlir · xərc · mənfəət — real sistem məlumatı: satış/alış qaimələri, aktlar, gömrük, maaş + satılan malın maya dəyəri
 *  • Mal qalığı — şirkətin portaldakı bütün tarixçəsi üzrə, MAL KODU ilə (alış + akt + gömrük − satış)
 *  • Daxil olan pullar — hər rüb üçün sadələşdirilmiş bəyannamənin 804-cü sətri (portal bank+POS-dan özü doldurur).
 *    Bəyannamə yoxdursa AMMO arxa planda QARALAMA yaradır, 804-ü oxuyur və qaralamanı silir — heç nə təqdim edilmir. */
(function (root) {
  'use strict';
  if (window.top !== window) return;
  const n0 = (v) => { const x = Number(v); return isFinite(x) ? x : 0; };
  const r2 = (v) => Math.round(n0(v) * 100) / 100;
  const pad = (x) => String(x).padStart(2, '0');
  const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
  const dmyToIso = (s) => { s = String(s || ''); let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s); if (m) return m[0]; m = /(\d{2})\.(\d{2})\.(\d{4})/.exec(s); return m ? `${m[3]}-${m[2]}-${m[1]}` : ''; };

  // Portal vergi kodları → adlar
  const TAX = {
    _0300: 'ƏDV', _0901: 'Muzdlu iş (vahid)', _0200: 'Mənfəət vergisi', _1400: 'Mənfəət vergisi (xüsusi rejim)', _1200: 'Gəlir vergisi', _3200: 'Gəlir vergisi (notarius)',
    _0800: 'Sadələşdirilmiş vergi', _0802: 'Sadələşdirilmiş vergi (daşınmaz əmlak)', _0804: 'Sadələşdirilmiş vergi (pul vəsaiti)', _1600: 'ÖMV', _1601: 'ÖMV (uduşlar)', _1700: 'Subpodrat',
    _0400: 'Aksiz', _0500: 'Əmlak vergisi', _0600: 'Torpaq vergisi', _0700: 'Mədən vergisi', _0101: 'Yol vergisi', _1300: 'Qeyri-rezident', _1500: 'İxrac fərqi', _4000: 'Nəzarət olunan əməliyyatlar',
  };
  const taxName = (d) => TAX[d.taxCode] || d.taxName || String(d.taxCode || 'Digər');
  const STATUS = { CONFIRMED: 'Təsdiqlənmiş', APPROVED: 'Təsdiqlənmiş', DRAFT: 'Qaralama', FILED: 'Təsdiq gözləyir', SUBMITTED: 'Təsdiq gözləyir', REJECTED: 'İmtina edilmiş', CANCELED: 'Ləğv edilmiş' };
  const TYPE = { CURRENT: 'Cari', CLARIFYING: 'Dəqiqləşdirilmiş', LIQUIDATION: 'Ləğv', CLARIFYING_LIQUIDATION: 'Ləğvin dəqiqləşdirilmişi', VOLUNTARY_DISCLOSURE: 'Könüllü açıqlama', SIMILAR: 'Analoji', CAMERAL: 'Kameral', AUDITING: 'Audit', AUDITING_LIQUIDATION: 'Auditin ləğvi', CORRECTION: 'Səhvin düzəlişi', VIRTUAL: 'Virtual' };
  // təsdiqin növü (istifadəçinin istədiyi): Kameral / Analoji / Adi
  const HOW = (t) => (t === 'CAMERAL' ? 'Kameral' : t === 'SIMILAR' ? 'Analoji' : /AUDIT/.test(t) ? 'Audit' : 'Adi');
  // portal: uyğunsuzluq məktubu göstərilən statuslar (NOT_PERFORMED, NOT_FOUND, CLOSED_BY_DECL — uyğunsuzluq yoxdur)
  const VVS = { FOUND: 'Uyğunsuzluq aşkar edilib', CLOSED_BY_NOTIFICATION: 'Uyğunsuzluq — bildirişlə bağlanıb', INCOMPLETE_CLOSING: 'Uyğunsuzluq — natamam bağlanıb', CLOSED_BY_DECL: 'Dəqiqləşdirilmiş bəyannamə ilə bağlanıb', NOT_FOUND: 'Uyğunsuzluq yoxdur', NOT_PERFORMED: 'Yoxlama aparılmayıb' };
  const isViolation = (v) => ['FOUND', 'CLOSED_BY_NOTIFICATION', 'INCOMPLETE_CLOSING'].includes(String(v || '').toUpperCase());
  const quarterOf = (m) => { m = Number(m) || 1; return [1, 4, 7, 10].includes(m) ? (m + 2) / 3 : m <= 3 ? m : Math.ceil(m / 3); };

  function normDecl(e) {
    const d = (e && e.declaration) || e || {};
    const p = d.reportingPeriod || {};
    const st = String(d.declarationStatus || '').toUpperCase(), ty = String(d.declarationType || '').toUpperCase();
    const vvs = String(d.violationVerificationStatus || '').toUpperCase();
    return {
      id: d.id || '', reg: d.registrationNumber || d.id || '', taxCode: String(d.taxCode || ''), tax: taxName(d),
      year: Number(p.year) || 0, month: Number(p.month) || 0, ptype: p.type || 'YEAR',
      type: ty, typeName: TYPE[ty] || ty, status: st, statusName: STATUS[st] || st,
      how: st === 'CONFIRMED' ? HOW(ty) : '', vvs, vvsName: VVS[vvs] || '', violation: isViolation(vvs),
      submitted: d.submissionDate || d.registrationDate || d.modificationDate || '', statusDate: d.statusModificationDate || '', last: d.lastClarifying || '',
      amount: d.taxAmount != null ? Number(d.taxAmount) : null, channel: d.deliveryType || '', controlErrors: ((e && e.controlErrors) || []).map((x) => x.errorMessage).filter(Boolean).slice(0, 5),
    };
  }

  // gözlənilən dövrlər (təqdim edilməli) — vergi növünün ilk bəyannaməsindən bu günə
  function expectedPeriods(list, today) {
    const out = [];
    const byTax = new Map();
    list.forEach((d) => { if (d.taxCode === '_0800' || d.taxCode === '_0804' || d.taxCode === '_0802') return; const k = d.taxCode; if (!byTax.has(k)) byTax.set(k, []); byTax.get(k).push(d); });
    const [ty, tm] = today.split('-').map(Number);
    byTax.forEach((ds, code) => {
      const types = [...new Set(ds.map((d) => d.ptype))];
      const ptype = types.includes('MONTH') ? 'MONTH' : types.includes('QUARTER') ? 'QUARTER' : 'YEAR';
      const keyOf = (d) => (ptype === 'MONTH' ? `${d.year}-${pad(d.month)}` : ptype === 'QUARTER' ? `${d.year}-Q${quarterOf(d.month)}` : `${d.year}`);
      const have = new Map();
      ds.filter((d) => d.ptype === ptype).forEach((d) => { const k = keyOf(d); if (!have.has(k)) have.set(k, []); have.get(k).push(d); });
      const keys = [...have.keys()].sort();
      if (!keys.length) return;
      if (!ds.some((d) => d.status !== 'DRAFT')) return;
      const first = keys[0];
      const lastReal = ds.filter((d) => d.status !== 'DRAFT').map(keyOf).sort().pop();
      const cutY = ty - 1, cutKey = ptype === 'MONTH' ? `${cutY}-${pad(tm)}` : ptype === 'QUARTER' ? `${cutY}-Q${Math.ceil(tm / 3)}` : `${cutY - 1}`;
      const active = lastReal >= cutKey;
      const periods = [];
      if (ptype === 'MONTH') {
        let [y, m] = first.split('-').map(Number);
        for (; y < ty || (y === ty && m < tm); m === 12 ? (y++, m = 1) : m++) {
          const dy = m === 12 ? y + 1 : y, dm = m === 12 ? 1 : m + 1;
          periods.push({ key: `${y}-${pad(m)}`, y, label: `${['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'][m - 1]} ${y}`, due: `${dy}-${pad(dm)}-20` });
        }
      } else if (ptype === 'QUARTER') {
        let [y, q] = [Number(first.slice(0, 4)), Number(first.slice(6))];
        for (; y < ty || (y === ty && q * 3 < tm); q === 4 ? (y++, q = 1) : q++) {
          const dm = q * 3 + 1, dy = dm > 12 ? y + 1 : y;
          periods.push({ key: `${y}-Q${q}`, y, label: `${q}-${q >= 3 ? 'cü' : 'ci'} rüb ${y}`, due: `${dy}-${pad(dm > 12 ? 1 : dm)}-20` });
        }
      } else {
        for (let y = Number(first); y < ty; y++) periods.push({ key: `${y}`, y, label: `${y}-ci il`, due: `${y + 1}-03-31` });
      }
      periods.forEach((p) => {
        if (!active && p.key > lastReal) return;
        const g = have.get(p.key) || [];
        const real = g.filter((d) => d.status !== 'DRAFT');
        const draft = g.filter((d) => d.status === 'DRAFT');
        const overdue = today > p.due;
        const state = real.length ? 'ok' : draft.length ? (overdue ? 'draftLate' : 'draft') : (overdue ? 'missing' : 'due');
        if (state !== 'ok') out.push({ taxCode: code, tax: ds[0].tax, period: p.label, key: p.key, due: p.due, state, drafts: draft.map((d) => d.reg) });
      });
    });
    return out.sort((a, b) => a.key.localeCompare(b.key));
  }

  // ---------------------------------------------------------------- 804 (sadələşdirilmiş bəyannamə): göstərici _3004
  // Portal formasında «804» sətri JSON-da «_3004» kimi saxlanılır: taxAmountBaku — 220.1, taxAmountOther — 220.1-1, xüsusi iqtisadi zona ayrıca.
  function find804(ti) {
    const res = { main: null, other: 0, zone: 0, total: null };
    const scan = (arr, slot) => (Array.isArray(arr) ? arr : []).forEach((e) => {
      if (!e || typeof e !== 'object') return;
      const ind = String(e.indicator || '');
      if (!/(^|_)(3004|804)$/.test(ind)) return;
      const nums = Object.entries(e).filter(([k, v]) => typeof v === 'number' && !/rate|order|percent/i.test(k));
      if (slot === 'zone') { res.zone += nums.reduce((s, [, v]) => s + v, 0); return; }
      const baku = e.taxAmountBaku != null ? n0(e.taxAmountBaku) : null, oth = n0(e.taxAmountOther);
      if (baku != null || e.taxAmountOther != null) { res.main = n0(res.main) + n0(baku); res.other += oth; }
      else { const v = nums.reduce((s, [, x]) => s + x, 0); res.main = n0(res.main) + v; }
    });
    const T = ti || {};
    scan(T.calculations, 'main'); scan(T.before2019Calculations, 'main'); scan(T.specialZoneCalculations, 'zone');
    if (res.main == null && !res.other && !res.zone) {
      // köhnə forma: istənilən dərinlikdə «804» indikatoru
      let best = null;
      const walk = (o, d) => { if (!o || typeof o !== 'object' || d > 6) return; if (Array.isArray(o)) { o.forEach((x) => walk(x, d + 1)); return; }
        if (o.indicator && /(^|_)0*(804|3004)$/.test(String(o.indicator))) { const v = Object.entries(o).filter(([k, x]) => typeof x === 'number' && !/rate|order|percent|id$/i.test(k)).reduce((s, [, x]) => s + x, 0); if (best == null || v > best) best = v; }
        Object.values(o).forEach((x) => walk(x, d + 1)); };
      walk(T, 0);
      if (best != null) res.main = best;
    }
    if (res.main != null || res.other || res.zone) res.total = r2(n0(res.main) + res.other + res.zone);
    return res;
  }
  const qDone = (y, q, today) => `${y}-${pad(q * 3)}` < today.slice(0, 7); // portal bitməmiş rüb üçün bəyannamə açmağa icazə vermir
  async function cash804(API, years, decls, today, opts, step, notes) {
    const out = [];
    const SIMP = ['_0800'];
    let created = 0, removed = 0;
    for (const y of years) {
      for (let q = 1; q <= 4; q++) {
        if (!qDone(y, q, today)) continue;
        const g = decls.filter((d) => SIMP.includes(d.taxCode) && d.year === y && d.ptype === 'QUARTER' && quarterOf(d.month) === q);
        g.sort((a, b) => (a.status === 'CONFIRMED' ? -1 : 1) - (b.status === 'CONFIRMED' ? -1 : 1) || (b.last === 'LAST') - (a.last === 'LAST'));
        const ex = g[0];
        step(`Daxil olan pullar (804): ${q}-${q >= 3 ? 'cü' : 'ci'} rüb ${y}…`);
        try {
          if (ex) {
            const base = await API.declarationBase(ex.reg || ex.id);
            let v = find804((base && base.taxInformation) || {});
            if (v.total == null) { try { const pf = await API.prefillData(ex.reg || ex.id); v = find804({ calculations: pf.calculations || [], specialZoneCalculations: pf.specialZoneCalculations || [] }); } catch (e) { /* */ } }
            out.push({ year: y, q, v804: v.total, parts: v, reg: ex.reg, src: ex.status === 'DRAFT' ? 'draft' : 'filed', statusName: ex.statusName });
            continue;
          }
          if (opts.auto804 === false) { out.push({ year: y, q, v804: null, src: 'none' }); continue; }
          // bəyannamə yoxdur — arxa planda qaralama yarat → 804-ü oxu → qaralamanı sil
          const r = await API.registerDraft({ taxCode: '_0800', year: y, month: q * 3 - 2, periodType: 'QUARTER' });
          const reg = (r && (r.registrationNumber || r.regNumber)) || (typeof r === 'string' ? r : '');
          if (!reg) throw new Error('qaralama nömrəsi alınmadı');
          created++;
          let v = { total: null };
          try {
            // portal yeni bəyannaməni açanda 801–804-ü bank və POS daxilolmalarından özü doldurur (prefillData) — eyni mənbə
            const pf = await API.prefillData(reg);
            v = find804({ calculations: pf.calculations || [], specialZoneCalculations: pf.specialZoneCalculations || [] });
            if (v.total == null) { const base = await API.declarationBase(reg); v = find804((base && base.taxInformation) || {}); }
            if (v.total == null && pf && 'calculations' in pf) v = { total: 0, main: 0, other: 0, zone: 0 }; // forma açıldı, 804 boşdur → daxilolma yoxdur
          } finally {
            // yalnız AMMO-nun indi yaratdığı (hələ saxlanmamış, siyahıda görünməyən) bəyannamə silinir — qeydiyyat nömrəsi ilə
            try { await API.deleteDraft(reg); removed++; }
            catch (e) { notes.push(`${q}-${q >= 3 ? 'cü' : 'ci'} rüb ${y}: köməkçi bəyannamə (${reg}) silinmədi (${e.message}).`); }
          }
          out.push({ year: y, q, v804: v.total, parts: v, reg, src: 'auto' });
        } catch (e) {
          if (e.status === 401 || e.status === 403) throw e;
          out.push({ year: y, q, v804: null, src: 'error', error: e.message });
        }
      }
    }
    if (created) notes.push(`Daxil olan pullar: ${created} rüb üçün 804 arxa planda oxundu (köməkçi qaralama yaradılıb, ${removed} silinib). Heç bir bəyannamə təqdim edilməyib.`);
    return out;
  }

  // ---------------------------------------------------------------- şirkət profili (API)
  const settled = async (p) => { try { return { ok: true, v: await p }; } catch (e) { if (e.status === 401) throw e; return { ok: false, e: e.message, status: e.status }; } };
  async function readProfile(API) {
    const [main, lic, obl, bank, legal, br, obj, cash, pos] = await Promise.all([
      settled(API.profile()), settled(API.profileList('license')), settled(API.profileList('obligation')), settled(API.profileList('bankAccount')),
      settled(API.profileList('legalEntity')), settled(API.branches()), settled(API.objects()),
      settled(API.profileListV2('cashRegister', { offset: 0, maxCount: 200 })), settled(API.profileListV2('posTerminal', { offset: 0, maxCount: 200 })),
    ]);
    const val = (r, k) => (r.ok && r.v ? (k ? r.v[k] : r.v) : null);
    return {
      v: 3, at: Date.now(), main: val(main),
      licenses: val(lic, 'licenses'), obligations: val(obl, 'obligations'), banks: val(bank, 'bankAccounts'), legal: val(legal, 'legalEntities'),
      branches: val(br, 'branches'), objects: val(obj, 'objectInfoShortList'), cash: val(cash, 'cashRegisters'), pos: val(pos, 'posTerminals'),
      errors: Object.fromEntries([['main', main], ['licenses', lic], ['obligations', obl], ['banks', bank], ['legal', legal], ['branches', br], ['objects', obj], ['cash', cash], ['pos', pos]].filter(([, r]) => !r.ok).map(([k, r]) => [k, r.status === 403 ? 'Bu girişin bu bölməyə icazəsi yoxdur' : r.e])),
    };
  }
  // ---------------------------------------------------------------- borclar (API)
  async function readDebts(API) {
    const [L, T] = await Promise.all([settled(API.liabilities()), settled(API.liabilitiesTotal())]);
    if (!L.ok && !T.ok) return { at: Date.now(), error: L.e || T.e };
    const j = L.ok ? L.v || {} : {};
    const tax = ((j.taxLiabilities || {}).budgetLiabilities || []).map((x) => {
      const od = x.overdueDebt || {}, ad = x.accruedDebt || {};
      const principal = n0(od.taxPayments) + n0(ad.taxPayments), sanction = n0(od.penalty) + n0(ad.penalty), faiz = n0(od.fine) + n0(ad.fine);
      return { code: x.budgetClassificationCode || '', name: (x.budgetClassificationName && x.budgetClassificationName.az) || '', sheet: (x.categoryName && x.categoryName.az) || '', principal: r2(principal), sanction: r2(sanction), faiz: r2(faiz), total: r2(principal + sanction + faiz), overpay: r2(x.overpayment), toPay: r2(x.toPayByBudget), unverified: r2(x.unverifiedReductions) };
    }).filter((x) => x.total || x.overpay || x.toPay);
    const soc = j.socialLiabilities || {};
    const socRows = [];
    [['pensionContributionLiabilities', 'Məcburi dövlət sosial sığorta'], ['socialInsuranceLiabilities', 'İşsizlikdən sığorta'], ['medicalInsuranceLiabilities', 'İcbari tibbi sığorta']].forEach(([k, label]) => {
      const o = soc[k]; if (!o) return;
      const t = (o.activityLiabilities || []).reduce((s, x) => s + n0(x.toPayByActivity), 0);
      if (t || n0(o.unallocatedSocialBenefits)) socRows.push({ name: label, toPay: r2(t), unallocated: r2(o.unallocatedSocialBenefits) });
    });
    const sum = (k) => r2(tax.reduce((s, x) => s + n0(x[k]), 0));
    const tot = T.ok && T.v ? T.v : {};
    return { at: Date.now(), asOf: j.informationOn || '', tax, social: socRows,
      totals: { principal: sum('principal'), sanction: sum('sanction'), faiz: sum('faiz'), debt: sum('total'), overpay: r2(tot.excessPayment != null ? tot.excessPayment : sum('overpay')), overdue: r2(tot.totalOverdueDebt), accrued: r2(tot.totalAccruedDebt), calculated: r2(tot.totalCalculatedDebt), unverified: r2(tot.unverifiedReduce) } };
  }
  // ---------------------------------------------------------------- məktublar (API)
  async function readMail(API, today) {
    const from = `${+today.slice(0, 4) - 2}-01-01`;
    const [cnt, list] = await Promise.all([settled(API.unreadCount()), settled(API.messages({ from, to: today, max: 600 }))]);
    const rows = list.ok ? (list.v || []).map((m) => ({ id: m.id, reg: m.newRegisterNumber || m.registerNumber || '', date: m.createdAt || '', subject: m.subject || '', from: (m.correspondent && m.correspondent.name && (m.correspondent.name.az || m.correspondent.name.en)) || '', read: m.isRead !== false, deadline: m.deadlineDate || '', attach: !!m.hasAttachment, violation: !!m.violationLetter })) : [];
    const c = cnt.ok && cnt.v ? cnt.v : {};
    return { at: Date.now(), unread: c.fromTaxAuthorityCount != null ? n0(c.fromTaxAuthorityCount) : rows.filter((r) => !r.read).length, unreadTp: n0(c.fromTaxpayersCount), total: rows.length, list: rows, error: list.ok ? '' : list.e };
  }

  // ---------------------------------------------------------------- qaimə sətirləri — keş (təsdiqlənmiş qaimə dəyişmir)
  const compactDet = (d) => (d && !d.__error ? { items: (d.items || []).map((it) => ({ productGroup: it.productGroup ? { code: it.productGroup.code, type: it.productGroup.type, name: it.productGroup.name && (it.productGroup.name.az || it.productGroup.name) } : null, productName: it.productName, unit: it.unit || (it.unitFromDict && (it.unitFromDict.name || it.unitFromDict.code)) || '', quantity: it.quantity, pricePerUnit: it.pricePerUnit, cost: it.cost, vat18: it.vat18 })) } : d);
  async function detailsCached(API, list, tin, step, label) {
    const key = 'ammo_invd_' + (tin || 'x');
    const cache = (await chrome.storage.local.get(key))[key] || {};
    const k = (inv) => `${inv.id}|${inv.version || 1}`;
    const need = list.filter((inv) => !cache[k(inv)]);
    let done = 0;
    if (need.length) {
      const det = await API.pool(need, 6, (inv) => API.invoiceDetail(inv.id, inv.sourceSystem), () => { done++; if (done % 5 === 0 || done === need.length) step(`${label}: qaimə sətirləri oxunur ${done}/${need.length} (qalanı yaddaşdan)…`); });
      need.forEach((inv, i) => { if (det[i] && !det[i].__error) cache[k(inv)] = compactDet(det[i]); });
      try { await chrome.storage.local.set({ [key]: cache }); } catch (e) { /* yer */ }
    }
    return list.map((inv) => cache[k(inv)] || { __error: true });
  }

  // ---------------------------------------------------------------- gömrük: açıq e.customs tabından avtomatik (yoxdursa — saxlanmış)
  async function customsRows(store, tin, fromISO, toISO, step, notes) {
    try {
      step('Gömrük (idxal): e.customs açıqdırsa oxunur…');
      const r = await chrome.runtime.sendMessage({ type: 'AMMO_GMR_REPORT', from: fromISO, to: toISO });
      if (r && r.ok) {
        const rows = r.parts.flatMap((p) => root.AMMO_STOCK.customsFromXml(p.text, tin));
        const data = { at: Date.now(), tin, rows, range: { from: fromISO, to: toISO }, src: 'e.customs (avtomatik)' };
        await chrome.storage.local.set({ ['ammo_customs_' + (tin || 'x')]: data, ammo_customs_last: data });
        return data;
      }
      if (r && r.error === 'login') notes.push('Gömrük: e.customs.gov.az-da sessiya bitib — yenidən daxil olun ki, idxal malları da qalığa düşsün.');
    } catch (e) { /* körpü yoxdur */ }
    const cands = [store['ammo_customs_' + (tin || 'x')], store['ammo_evez_cus_' + (tin || 'x')], store.ammo_customs_last].filter((c) => c && Array.isArray(c.rows) && c.rows.length && (!c.tin || !tin || String(c.tin) === String(tin)));
    return cands.sort((a, b) => (b.at || 0) - (a.at || 0))[0] || null;
  }

  // ---------------------------------------------------------------- əsas
  async function collect(opts, onStep) {
    const API = root.AMMO_API, A = root.AMMO_AUDIT, P = root.AMMO_EVEZ_PORTAL, ST = root.AMMO_STOCK;
    const step = (t) => onStep && onStep(t);
    const tin = P ? P.ownTin() : '';
    const today = todayISO();
    const notes = [];
    const store = await chrome.storage.local.get(null);

    step('Şirkət profili, borclar və məktublar oxunur…');
    const [profile, debts, mail] = await Promise.all([readProfile(API), readDebts(API), readMail(API, today)]);
    const pm = profile.main || {};
    const regISO = dmyToIso(pm.taxpayerRegistrationDate) || dmyToIso(pm.stateRegistrationDocumentIssuedDate) || '';

    // dövr
    let fromISO = opts.fromISO, toISO = opts.toISO;
    if (opts.mode === 'year') { fromISO = `${opts.year}-01-01`; toISO = `${opts.year}-12-31`; }
    if (opts.mode === 'all') { fromISO = regISO && regISO > '2019-01-01' ? regISO : '2019-01-01'; toISO = today; }
    if (toISO > today) toISO = today;
    const y1 = +fromISO.slice(0, 4), y2 = +toISO.slice(0, 4), curY = +today.slice(0, 4);

    // 1) bəyannamələr
    const decls = [], seen = new Set(), failedYears = new Set();
    const firstY = Math.min(y1, regISO ? Math.max(2019, +regISO.slice(0, 4)) : y1);
    for (let y = firstY; y <= Math.max(y2, curY); y++) {
      step(`Bəyannamələrin siyahısı: ${y}…`);
      try {
        (await API.declarations(y) || []).forEach((e) => {
          const d = normDecl(e);
          const sig = d.id || d.reg || JSON.stringify([d.taxCode, d.year, d.month, d.ptype, d.type, d.status, d.submitted]);
          if (seen.has(sig)) return; seen.add(sig); decls.push(d);
        });
      } catch (e) { if (e.status === 401 || e.status === 403) throw e; failedYears.add(y); notes.push(`${y}-ci ilin bəyannamə siyahısı alınmadı: ${e.message}`); }
    }
    const fromM = fromISO.slice(0, 7), toM = toISO.slice(0, 7);
    const spanOf = (key) => { const y = key.slice(0, 4); if (/^\d{4}-Q\d$/.test(key)) { const q = +key.slice(6); return [`${y}-${pad(q * 3 - 2)}`, `${y}-${pad(q * 3)}`]; } if (/^\d{4}-\d{2}$/.test(key)) return [key, key]; return [`${y}-01`, `${y}-12`]; };
    const missing = expectedPeriods(decls, today).filter((m) => { const [a, b] = spanOf(m.key); return b >= fromM && a <= toM; })
      .map((m) => (failedYears.has(+m.key.slice(0, 4)) && m.state !== 'draft' && m.state !== 'draftLate' ? { ...m, state: 'unknown' } : m));

    // 2) qaimələr — mal qalığı üçün bütün tarixçə (şirkətin yarandığı gündən; portalda e-qaimə ~2019-dan), maliyyə üçün seçilmiş dövr
    const histFrom = opts.fullStock === false ? fromISO : (regISO && regISO > '2018-01-01' ? regISO : '2018-01-01');
    const loadFrom = histFrom < fromISO ? histFrom : fromISO;
    let inv = null, audit = null, stockMoves = [], cus = null;
    try {
      const { sales, purchases, acts } = await A.fetchInvoices(API, loadFrom, today, step, { all: true });
      const saleDetails = await detailsCached(API, sales, tin, step, 'Satış');
      const purchaseDetails = await detailsCached(API, purchases, tin, step, 'Alış');
      let actDetails = [];
      if (acts.length) { step('Alış aktlarının sətirləri…'); actDetails = await API.pool(acts, 4, (a) => (Array.isArray(a.items) && a.items.length ? a : API.actDetail(a.id, a.sourceSystem))); }
      inv = { sales, purchases, acts, saleDetails, purchaseDetails, actDetails };
      cus = await customsRows(store, tin, histFrom, today, step, notes);
      step('Mal qalığı hesablanır (mal kodu üzrə)…');
      stockMoves = ST.moves({ sales, saleDetails, purchases, purchaseDetails, acts, actDetails, customs: cus ? cus.rows : [] });
      step('Muzdlu iş bəyannamələri…');
      const rawDecls = decls.map((d) => ({ id: d.id, registrationNumber: d.reg, taxCode: d.taxCode, declarationStatus: d.status, lastClarifying: d.last, submissionDate: d.submitted, reportingPeriod: { year: d.year, month: d.month, type: d.ptype } }));
      const pr = await A.payroll(API, fromISO, toISO, rawDecls, step);
      audit = A.compute({ fromISO, toISO, ...inv, payroll: pr });
      if (opts.fullStock !== false) {
        const first = [...sales, ...purchases].map((x) => String(x.createdAt || '').slice(0, 10)).filter(Boolean).sort()[0];
        if (first && regISO && regISO < first.slice(0, 7) + '-01') notes.push(`Mal qalığı: portalda bu şirkətin ilk elektron qaiməsi ${first.split('-').reverse().join('.')} tarixlidir (şirkət ${regISO.split('-').reverse().join('.')}-də yaranıb). Ondan əvvəlki dövrün qalığı portalda olmadığı üçün nəzərə alınmayıb.`);
      }
    } catch (e) { if (e.status === 401 || e.status === 403) throw e; notes.push('Qaimələr oxunmadı: ' + e.message); }

    // 3) təqdim edilmiş Mənfəət / Gəlir bəyannaməsi — yalnız MÜQAYİSƏ üçün (əsas rəqəmlər real məlumatdandır)
    let filed = null;
    try {
      const fy = opts.mode === 'year' ? +opts.year : (toISO.slice(5) === '12-31' ? y2 : y2 - 1);
      const pick = (codes) => { const g = decls.filter((d) => codes.includes(d.taxCode) && d.year === fy && d.status !== 'DRAFT'); g.sort((a, b) => new Date(a.submitted) - new Date(b.submitted)); return g.find((d) => d.last === 'LAST') || g[g.length - 1]; };
      const prof = pick(['_0200', '_1400']), inc = pick(['_1200', '_3200']);
      const d = prof || inc;
      if (d) {
        step(`${fy}-ci il ${prof ? 'mənfəət' : 'gəlir'} bəyannaməsi (müqayisə üçün)…`);
        const base = await API.declarationBase(d.id || d.reg);
        const T = root.AMMO_TAXREP_FORMS, TR = root.AMMO_TAXREP;
        const form = T.getForm(prof ? 'profit' : 'income');
        filed = { year: fy, type: form.id, reg: d.reg, typeName: d.typeName, statusName: d.statusName, values: TR.valuesFromBase(form, (base && base.taxInformation) || {}) };
      }
    } catch (e) { if (e.status === 401 || e.status === 403) throw e; }

    // 4) daxil olan pullar — 804, rüblər üzrə
    let cash = [];
    try {
      const years = []; for (let y = Math.max(y1, curY - 5); y <= y2; y++) years.push(y);
      cash = await cash804(API, years, decls, today, opts, step, notes);
    } catch (e) { if (e.status === 401) throw e; notes.push('Daxil olan pullar oxunmadı: ' + e.message); }

    // 5) ƏDV — əvəzləşmə analizi (istəyə görə)
    let vat = null;
    if (opts.vat && P) {
      try {
        const { inputs } = await P.collect({ mode: 'range', fromISO, toISO, drafts: false, autoDeposit: true }, (t) => step('ƏDV: ' + t));
        const R = root.AMMO_EVEZ.analyze({ ...inputs, deposit: inputs.deposit || null });
        const T = R.totals, months = R.months;
        vat = {
          totals: { vat: T.vat, offVat: T.offVat, remaining: T.remaining, pct: T.pct, rightVat: T.rightVat, rightCount: T.rightCount, noRightVat: T.noRightVat, noRightCount: T.noRightCount, customsVat: T.customsVat, customsOff: T.customsOff },
          outVat: r2(months.reduce((s, m) => s + n0(m.outVat), 0)), payable: r2(months.reduce((s, m) => s + n0(m.payable), 0)), refund: r2(months.reduce((s, m) => s + n0(m.refund), 0)),
          months: months.map((m) => ({ key: m.key, label: m.label, outVat: m.outVat, payable: m.payable, declOffVat: m.declOffVat, state: m.state })),
          deposit: inputs.deposit ? { closing: inputs.deposit.closing, count: inputs.deposit.payments.length, inSum: r2(inputs.deposit.payments.filter((p) => p.dir === 'in').reduce((s, p) => s + p.amount, 0)), outSum: r2(inputs.deposit.payments.filter((p) => p.dir === 'out').reduce((s, p) => s + p.amount, 0)), budget: r2(inputs.deposit.payments.filter((p) => p.dir === 'budget').reduce((s, p) => s + p.amount, 0)) } : null,
          notes: inputs.notes || [],
        };
      } catch (e) { if (e.status === 401 || e.status === 403) throw e; notes.push('ƏDV analizi alınmadı: ' + e.message); }
    }

    const staffKey = (tin && store['ammo_emas_staff_' + tin] ? 'ammo_emas_staff_' + tin : null) || (store.ammo_emas_staff_last ? 'ammo_emas_staff_last' : null);
    step('Hazırlanır…');
    return {
      kind: 'audit2', version: 3, created: Date.now(), tin, today,
      company: pm.companyName || pm.individualName || (audit && audit.self) || '',
      period: { mode: opts.mode, fromISO, toISO, year: opts.year || null }, regISO, histFrom,
      profile, debts, mail,
      staff: staffKey ? store[staffKey] : null,
      customs: cus ? cus.rows : null, customsMeta: cus ? { at: cus.at || 0, src: cus.src || '', range: cus.range || null } : null,
      decls, missing,
      audit: audit ? { income: audit.income, expenses: audit.expenses, expenseTotal: audit.expenseTotal, profit: audit.profit, tax: audit.tax, payroll: audit.payroll, months: audit.months, customers: audit.customers, suppliers: audit.suppliers, counts: audit.counts, vatIn: audit.vatIn, self: audit.self, actsTotal: audit.actsTotal, lines: { income: audit.lines.income, expense: audit.lines.expense } } : null,
      moves: stockMoves.map((m) => [m.d, m.dir, m.key, m.code, m.name, m.unit, m.q, r2(m.cost), m.doc, m.party, m.svc ? 1 : 0]),
      filed, cash, vat, notes,
    };
  }

  // nəticə səhifəsi üçün körpü: bəyannamənin PDF-i (yalnız oxuma)
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== 'AMMO_AUDIT_API' || sender.id !== chrome.runtime.id) return false;
    (async () => {
      if (msg.op === 'pdf') {
        const blob = await root.AMMO_API.declarationPdf(String(msg.id));
        return await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsDataURL(blob); });
      }
      const API = root.AMMO_API, today = todayISO();
      if (msg.op === 'profile') return readProfile(API);
      if (msg.op === 'debts') return readDebts(API);
      if (msg.op === 'mail') return readMail(API, today);
      if (msg.op === 'cash') {
        const years = (msg.years && msg.years.length ? msg.years : [+today.slice(0, 4)]).map(Number);
        const decls = [];
        for (const y of years) (await API.declarations(y) || []).forEach((e) => decls.push(normDecl(e)));
        return cash804(API, years, decls, today, {}, () => {}, []);
      }
      throw new Error('naməlum əməliyyat');
    })().then((data) => sendResponse({ ok: true, data }), (e) => sendResponse({ ok: false, error: e && e.message ? e.message : String(e) }));
    return true;
  });

  root.AMMO_AUDIT2 = { quarterOf, collect, normDecl, expectedPeriods, find804, cash804, readProfile, readDebts, readMail }; // v1.25: cash804 — uzaqdan əmrlər üçün
})(typeof globalThis !== 'undefined' ? globalThis : this);
