/* AMMO — Gömrük (e.customs.gov.az) körpüsü, v1.17.0
 * 1) Saytda "AMMO Gömrük" düyməsi göstərir → AMMO-nun "Gömrük bəyannamələri" pəncərəsini açır.
 * 2) Pəncərədən gələn sorğuları saytın öz sessiyası (localStorage-dakı token) ilə icra edir.
 *    Token heç yerə göndərilmir və saxlanılmır — sorğu bu tabda, saytın öz adından gedir. */
(function () {
  'use strict';
  if (window.top !== window) return;
  if (window.__AMMO_GMR__) return;
  window.__AMMO_GMR__ = true;

  const API = 'https://c2b-fbusiness.customs.gov.az/api/v1/';
  const store = () => { try { return JSON.parse(localStorage.getItem('__store__') || '{}') || {}; } catch (e) { return {}; } };
  const token = () => store().localToken || '';

  // ------------------------------------------------------------ sorğu körpüsü
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== 'AMMO_GMR_FETCH') return false;
    (async () => {
      const t = token();
      if (!t) return { ok: false, status: 401, text: '', error: 'login' };
      if (!/^[a-z0-9\-/?=&.%_]+$/i.test(String(msg.path || ''))) return { ok: false, status: 0, error: 'bad path' };
      const headers = { Authorization: 'Bearer ' + t, lang: 'az', requestSource: 'ECustoms' };
      const init = { method: msg.method === 'POST' ? 'POST' : 'GET', headers };
      if (init.method === 'POST') { headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(msg.body || {}); }
      const r = await fetch(API + msg.path, init);
      return { ok: r.ok, status: r.status, text: await r.text() };
    })().then(sendResponse, (e) => sendResponse({ ok: false, status: 0, error: String(e && e.message || e) }));
    return true;
  });

  // ------------------------------------------------------------ düymə
  const CSS = `
  :host{all:initial;}
  *{box-sizing:border-box;font-family:'Segoe UI',system-ui,Arial,sans-serif;}
  .tab{position:fixed;right:0;bottom:176px;z-index:2147483646;display:flex;align-items:center;gap:7px;
    background:linear-gradient(135deg,#7a1f30,#c3324a);color:#fff;border:none;border-radius:12px 0 0 12px;
    padding:10px 13px 10px 12px;cursor:pointer;box-shadow:-3px 3px 14px rgba(0,0,0,.28);font-size:13px;font-weight:600;
    transition:transform .15s ease;}
  .tab:hover{transform:translateX(-3px);}
  .mk{width:22px;height:22px;border-radius:7px;background:#d9a93a;color:#0d3a42;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;}
  .toast{position:fixed;right:14px;bottom:226px;z-index:2147483647;max-width:320px;background:#9e2740;color:#fff;
    padding:11px 14px;border-radius:12px;font-size:12.5px;line-height:1.45;box-shadow:0 10px 30px rgba(0,0,0,.3);display:none;}
  .toast.on{display:block;}`;

  function mount() {
    const host = document.createElement('div');
    host.id = 'ammo-gmr-host';
    (document.body || document.documentElement).appendChild(host);
    const sh = host.attachShadow({ mode: 'open' });
    const st = document.createElement('style'); st.textContent = CSS; sh.appendChild(st);
    const btn = document.createElement('button');
    btn.className = 'tab';
    btn.title = 'İdxal bəyannamələri: ölkə, mal, miqdar, invoys dəyəri, nəqliyyat, rüsumlar, ƏDV — Excel';
    btn.innerHTML = '<span class="mk">A</span><span>AMMO Gömrük</span>';
    const toast = document.createElement('div'); toast.className = 'toast';
    sh.appendChild(btn); sh.appendChild(toast);
    let tt;
    btn.onclick = async () => {
      if (!token()) {
        toast.textContent = 'Əvvəlcə e.customs.gov.az-a Asan İmza ilə daxil olun, sonra yenidən basın.';
        toast.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => toast.classList.remove('on'), 5000);
        return;
      }
      try { await chrome.runtime.sendMessage({ type: 'AMMO_GMR_OPEN' }); }
      catch (e) {
        toast.textContent = 'AMMO yeniləndi — səhifəni yeniləyin (F5) və yenidən basın.';
        toast.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => toast.classList.remove('on'), 5000);
      }
    };
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount, { once: true });
})();
