/* AMMO — Bank Çıxarışı: read one or more bank statements, categorise every transaction
 * and build an "İcmal" Excel (summary + incoming/outgoing companies + full transaction log). */
(function (root) {
  'use strict';
  const P = () => root.AMMO_BANK_PARSE;
  const CAT = () => root.AMMO_BANK_CAT;
  const r2 = (v) => Math.round((Number(v) || 0) * 100) / 100;

  async function readFile(file, bankCode) {
    if (bankCode === 'UNIBANK') {
      const text = await file.text();
      const doc = new DOMParser().parseFromString(text, 'text/html');
      const rows = [];
      doc.querySelectorAll('table tr').forEach((tr) => {
        const cells = Array.from(tr.querySelectorAll('td,th')).map((td) => td.textContent.trim());
        if (cells.some((c) => c !== '')) rows.push(cells);
      });
      if (rows.length) return rows;
    }
    return root.AMMO_XLSX_READ.readFile(file);
  }

  // files: [{ file, bankCode, name }]
  async function process(files) {
    const VAT = P().VAT_ACC;
    const catTotals = new Map();
    const incoming = new Map(), outgoing = new Map();
    const unknowns = new Map();
    const logs = [];
    let companyName = '', currency = '', opening = 0, closing = 0;
    let cardStatement = false, nothing = true;
    const voens = new Set(), currencies = new Set();

    for (let fi = 0; fi < files.length; fi++) {
      const { file, bankCode, name } = files[fi];
      const rows = await readFile(file, bankCode);
      const b = P().parse(bankCode, rows);
      if (b.isCardStatement) cardStatement = true;
      if (b.userVoen) voens.add(b.userVoen);
      if (b.currency) currencies.add(b.currency);
      if (fi === 0) companyName = b.companyName || '';
      currency = b.currency || currency || 'AZN';
      opening += Number(b.opening) || 0; closing += Number(b.closing) || 0;
      const opts = { ownVoen: b.userVoen, bankVoen: b.bankVoen };
      b.records.forEach((rec) => {
        nothing = false;
        const res = CAT().detect(rec.desc, rec.voen, rec.amount, opts);
        let displayCat = res.category;
        if (res.byVoen) {
          const map = rec.amount >= 0 ? incoming : outgoing;
          const key = rec.voen || ('NONAME_' + (rec.cpName || rec.desc));
          const e = map.get(key) || { voen: rec.voen || '', name: rec.cpName || rec.desc || '—', amount: 0, vat: 0 };
          e.amount += rec.amount;
          if (String(rec.account || '').toUpperCase().includes(VAT)) e.vat += rec.amount;
          if (!e.name && rec.cpName) e.name = rec.cpName;
          map.set(key, e);
          displayCat = rec.amount >= 0 ? 'Digər Şirkətlərdən Daxilolmalar' : 'Digər Şirkətlərə Ödənişlər';
        } else if (res.category) {
          catTotals.set(res.category, r2((catTotals.get(res.category) || 0) + rec.amount));
        } else {
          const k = '?? ' + (rec.desc || 'Naməlum').trim();
          unknowns.set(k, r2((unknowns.get(k) || 0) + rec.amount));
          displayCat = k;
        }
        logs.push({ bank: bankCode, date: rec.date, voen: rec.voen, cpName: rec.cpName, desc: String(rec.desc || '').replace(/\s+/g, ' ').trim(), amount: rec.amount, cat: displayCat });
      });
    }
    return {
      kind: 'bank', created: Date.now(), companyName, currency: currency || 'AZN',
      opening: r2(opening), closing: r2(closing),
      catTotals: [...catTotals.entries()], incoming: [...incoming.values()], outgoing: [...outgoing.values()],
      unknowns: [...unknowns.entries()], logs,
      cardStatement, nothing, voens: [...voens], currencies: [...currencies],
    };
  }

  // apply manual choices for unknowns before building the workbook
  function applyManual(result, choices) {
    // choices: { '?? desc' : 'CategoryName' | '[in]' | '[out]' }
    const cat = new Map(result.catTotals);
    const incoming = result.incoming.map((e) => ({ ...e })); const outgoing = result.outgoing.map((e) => ({ ...e }));
    result.unknowns.forEach(([key, amt]) => {
      const ch = choices[key]; if (!ch) return;
      if (ch === '[in]' || ch === '[out]') { (ch === '[in]' ? incoming : outgoing).push({ voen: '', name: key.replace(/^\?\?\s*/, ''), amount: amt, vat: 0 }); }
      else cat.set(ch, r2((cat.get(ch) || 0) + amt));
      result.logs.forEach((l) => { if (l.cat === key) l.cat = ch === '[in]' ? 'Digər Şirkətlərdən Daxilolmalar' : ch === '[out]' ? 'Digər Şirkətlərə Ödənişlər' : ch; });
    });
    return { ...result, catTotals: [...cat.entries()], incoming, outgoing, unknowns: result.unknowns.filter(([k]) => !choices[k]) };
  }

  // -------------------------------------------------- İcmal workbook (computed values)
  function buildSheets(result) {
    const CUR = result.currency || 'AZN';
    const money = (v) => ({ v: r2(v), s: 'n2' });
    const H = (v) => ({ v, s: 'h' });
    const income = [], expense = [];
    result.catTotals.forEach(([c, a]) => { if (a > 0.0001) income.push([c, a]); else if (a < -0.0001) expense.push([c, -a]); });
    const inSum = result.incoming.reduce((s, e) => s + e.amount, 0);
    const outSum = result.outgoing.reduce((s, e) => s + Math.abs(e.amount), 0);
    if (inSum > 0.0001) income.push(['Digər Şirkətlərdən Daxilolmalar', inSum]);
    if (outSum > 0.0001) expense.push(['Digər Şirkətlərə Ödənişlər', outSum]);
    income.sort((a, b) => b[1] - a[1]); expense.sort((a, b) => b[1] - a[1]);
    const totIn = r2(result.logs.reduce((s, l) => s + (l.amount > 0 ? l.amount : 0), 0));
    const totOut = r2(result.logs.reduce((s, l) => s + (l.amount < 0 ? -l.amount : 0), 0));

    // İcmal
    const icmal = [];
    icmal.push([{ v: `İcmal hesabat (${CUR})`, s: 'b' }]);
    icmal.push([{ v: '⚠️ Diqqət: kateqoriyalar avtomatik təyin olunub, “Əməliyyatlar” vərəqində yoxlayın.', s: 'b' }]);
    icmal.push([]);
    if (result.companyName) icmal.push([{ v: 'Şirkət: ' + result.companyName, s: 'b' }]);
    icmal.push([{ v: 'İlkin qalıq', s: 'b' }, money(result.opening), '', { v: 'Son qalıq', s: 'b' }, money(result.closing)]);
    icmal.push([{ v: 'MƏDAXİL', s: 'b' }, { v: totIn, s: 'bn2' }, '', { v: 'MƏXARİC', s: 'b' }, { v: totOut, s: 'bn2' }]);
    icmal.push([H('Təyinat'), H('Məbləğ'), '', H('Təyinat'), H('Məbləğ')]);
    const n = Math.max(income.length, expense.length);
    for (let i = 0; i < n; i++) {
      icmal.push([income[i] ? income[i][0] : '', income[i] ? money(income[i][1]) : '', '', expense[i] ? expense[i][0] : '', expense[i] ? money(expense[i][1]) : '']);
    }
    if (result.unknowns.length) {
      icmal.push([]); icmal.push([{ v: 'Qruplaşdırılmamış əməliyyatlar:', s: 'b' }]);
      icmal.push([H('Təyinat'), '', H('Məbləğ')]);
      result.unknowns.forEach(([k, a]) => icmal.push([k.replace(/^\?\?\s*/, ''), '', money(a)]));
    }

    // Daxilolmalar
    const dax = [[{ v: 'Digər Şirkətlərdən Daxilolmalar', s: 'b' }], [], [H('VÖEN'), H('Ad'), H('Məbləğ')]];
    result.incoming.sort((a, b) => b.amount - a.amount).forEach((e) => dax.push([e.voen || '', e.name, money(e.amount)]));
    if (!result.incoming.length) dax.push(['—', '—', '—']);
    dax.push([]); dax.push([{ v: 'CƏMİ', s: 'b' }, '', { v: inSum, s: 'bn2' }]);

    // Ödənişlər
    const ode = [[{ v: 'Digər Şirkətlərə Ödənişlər', s: 'b' }], [], [H('VÖEN'), H('Ad'), H('Əsas'), H('ƏDV'), H('Cəmi')]];
    result.outgoing.sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount)).forEach((e) => { const cemi = Math.abs(e.amount), vat = Math.abs(e.vat); ode.push([e.voen || '', e.name, money(cemi - vat), money(vat), money(cemi)]); });
    if (!result.outgoing.length) ode.push(['—', '—', '—', '—', '—']);
    ode.push([]); ode.push([{ v: 'CƏMİ', s: 'b' }, '', money(result.outgoing.reduce((s, e) => s + (Math.abs(e.amount) - Math.abs(e.vat)), 0)), money(result.outgoing.reduce((s, e) => s + Math.abs(e.vat), 0)), { v: outSum, s: 'bn2' }]);

    // Əməliyyatlar
    const op = [[H('#'), H('Tarix'), H('VÖEN'), H('Kontragent'), H('Təyinat'), H('Məbləğ'), H('Kateqoriya')]];
    result.logs.forEach((l, i) => op.push([i + 1, l.date ? l.date.split('-').reverse().join('.') : '', l.voen || '', l.cpName || '', l.desc, { v: r2(l.amount), s: 'n2' }, l.cat]));

    return [
      { name: 'İcmal', rows: icmal, autoFilter: false, maxWidth: 48, merges: ['A2:E2'] },
      { name: 'Daxilolmalar', rows: dax, autoFilter: false, maxWidth: 40 },
      { name: 'Ödənişlər', rows: ode, autoFilter: false, maxWidth: 40 },
      { name: 'Əməliyyatlar', rows: op, headerRow: 0, maxWidth: 55 },
    ];
  }

  root.AMMO_BANK = { process, applyManual, buildSheets, readFile };
})(typeof globalThis !== 'undefined' ? globalThis : this);
