/* AMMO — Sosial şəbəkə analizi: Yahoo Mail (mail.yahoo.com) oxuyucu (v1.23.1).
 * Yalnız OXUYUR: Gələnlər qutusu (kimdən, mövzu, qısa mətn, tarix, oxunub-oxunmayıb) + Göndərilənlər qovluğu
 * (cavab verilibmi?). Heç nə yazmır, göndərmir, silmir. Sonda istifadəçinin açıq olduğu qovluğa qayıdır. */
(function () {
  'use strict';
  if (window.top !== window) return;
  const TOK = Math.random().toString(36).slice(2);
  window.__AMMO_YH_TOK = TOK;
  const live = () => window.__AMMO_YH_TOK === TOK;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const T = (el) => (el ? (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim() : '');
  const low = (s) => String(s || '').toLocaleLowerCase('az');
  const ROW_SEL = '[data-test-id="message-list-item"], a[href*="/messages/"][role="link"], li[data-test-id="message-list-item-container"] a';
  const rows = () => { const L = [...document.querySelectorAll(ROW_SEL)]; return L.filter((x, i) => L.findIndex((y) => y === x || y.contains(x)) === i); };
  const listBox = () => { const r = rows()[0]; let p = r && r.parentElement; while (p && p !== document.body) { if (p.scrollHeight > p.clientHeight + 20 && /auto|scroll/.test(getComputedStyle(p).overflowY)) return p; p = p.parentElement; } return document.scrollingElement; };
  const normSubj = (s) => low(s).replace(/^((re|fw|fwd|aw|wg|cavab|ответ|пересл)\s*(\[\d+\])?\s*:\s*)+/g, '').replace(/\s+/g, ' ').trim();

  function me() {
    const m = /([\w.+-]+@[\w-]+\.[\w.-]+)/.exec(document.title || '');
    if (m) return m[1].toLowerCase();
    const el = document.querySelector('[data-test-id="account-email"], [data-test-id="ybar-account-email"], [aria-label*="@"]');
    const m2 = el && /([\w.+-]+@[\w-]+\.[\w.-]+)/.exec(el.getAttribute('aria-label') || T(el));
    return m2 ? m2[1].toLowerCase() : '';
  }
  function parseWhen(row) {
    const tm = row.querySelector('time[datetime]');
    if (tm) { const t = Date.parse(tm.getAttribute('datetime')); if (isFinite(t)) return new Date(t).toISOString(); }
    const el = row.querySelector('[data-test-id="message-date"], time, [title*=":"]');
    const s = (el && (el.getAttribute('title') || T(el))) || '';
    let t = Date.parse(s);
    if (!isFinite(t)) {
      const now = new Date();
      if (/^\d{1,2}:\d{2}\s*(am|pm)?$/i.test(s)) { const [h, mi] = s.split(':'); const d = new Date(now); d.setHours((+h % 12) + (/pm/i.test(s) ? 12 : 0), parseInt(mi, 10), 0, 0); t = d.getTime(); }
      else { const m = /^([A-Za-z]{3})\s+(\d{1,2})$/.exec(s); if (m) t = Date.parse(`${m[1]} ${m[2]} ${now.getFullYear()}`); }
    }
    return isFinite(t) ? new Date(t).toISOString() : '';
  }
  function readRow(row) {
    const sEl = row.querySelector('[data-test-id="senders"]') || row.querySelector('[data-test-id="senders_list"]');
    const ppl = sEl ? [...sEl.querySelectorAll('span[title]')].map((x) => ({ name: T(x), email: low(x.getAttribute('title')) })) : [];
    const subject = T(row.querySelector('[data-test-id="message-subject"]'));
    const snippet = T(row.querySelector('[data-test-id="snippet"]'));
    const al = low(row.getAttribute('aria-label') || '');
    const unread = /unread|oxunmamış|непрочит/.test(al) || !!row.querySelector('[data-test-id="icon-btn-read"][title*="read" i]:not([title*="unread" i])') || row.matches('[data-test-read="false"]') || (() => { const s = row.querySelector('[data-test-id="message-subject"]'); return s ? +getComputedStyle(s).fontWeight >= 600 : false; })();
    const replied = !!row.querySelector('[data-test-id*="replied" i], [title*="replied" i], [aria-label*="replied" i], [title*="cavab verilib" i]');
    const count = parseInt(T(row.querySelector('[data-test-id="thread-count"], [data-test-id="message-count"]')), 10) || 1;
    const href = row.getAttribute('href') || (row.querySelector('a[href*="/messages/"]') || {}).getAttribute?.('href') || '';
    return { subject, snippet, people: ppl, sender: ppl[0] ? ppl[0].name || ppl[0].email : T(sEl), email: ppl[0] ? ppl[0].email : '', at: parseWhen(row), unread, replied, count, href };
  }
  async function waitList(prevFirst) {
    for (let i = 0; i < 50; i++) { await sleep(400); const r = rows(); if (r.length && (r[0].getAttribute('href') || T(r[0])) !== prevFirst) return true; if (i > 10 && document.querySelector('[data-test-id="empty-folder"], [data-test-id="no-messages"]')) return true; }
    return rows().length > 0;
  }
  async function scanFolder(maxRows, sinceISO) {
    const box = listBox(); const seen = new Map();
    if (box) { box.scrollTop = 0; await sleep(300); }
    for (let g = 0; g < 60 && seen.size < maxRows; g++) {
      let older = false;
      rows().forEach((r) => { const x = readRow(r); const k = x.href || x.subject + '|' + x.at + '|' + x.email; if (!seen.has(k)) seen.set(k, x); if (sinceISO && x.at && x.at < sinceISO) older = true; });
      if (older || !box) break;
      const b = box.scrollTop; box.scrollTop = b + box.clientHeight * 0.9; await sleep(700);
      if (box.scrollTop === b) break;
    }
    if (box) box.scrollTop = 0;
    return [...seen.values()].filter((x) => !sinceISO || !x.at || x.at >= sinceISO);
  }
  function folderLink(id, names) {
    return document.querySelector(`a[data-test-folder-id="${id}"]`) || [...document.querySelectorAll('a[href*="/folders/"]')].find((a) => new RegExp(`/folders/${id}(\\b|/|$)`).test(a.getAttribute('href') || '') || names.test(low(a.getAttribute('aria-label') || T(a))));
  }
  async function go(id, names) {
    const a = folderLink(id, names);
    const first = rows()[0] ? rows()[0].getAttribute('href') || T(rows()[0]) : '';
    if (a) a.click(); else location.assign(`/n/folders/${id}`);
    await waitList(first); await sleep(600);
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!live()) return false;
    if (!msg || sender.id !== chrome.runtime.id) return false;
    if (msg.type === 'AMMO_SOC_PING') { sendResponse({ ok: true, href: location.href }); return false; }
    if (msg.type === 'AMMO_SOC_SCAN') {
      (async () => {
        const o = msg.opts || {};
        for (let i = 0; i < 30 && !rows().length; i++) { if (/login\.yahoo\.com/.test(location.host)) break; await sleep(1000); }
        if (/login\.yahoo\.com/.test(location.host)) return { ok: false, error: 'Yahoo Mail-ə daxil olun' };
        if (!rows().length && !document.querySelector('[data-test-id="empty-folder"]')) return { ok: false, error: 'Yahoo Mail açılmadı — hesaba daxil olun' };
        const since = new Date(Date.now() - (o.days || 30) * 864e5).toISOString();
        const back = location.pathname;
        const my = me();
        // 1) Gələnlər
        if (!/\/folders\/1(\/|$)/.test(location.pathname)) await go(1, /inbox|gələnlər|входящ/);
        const inbox = await scanFolder(o.maxRows || 400, since);
        try { chrome.runtime.sendMessage({ type: 'AMMO_SOC_PROGRESS', source: 'yahoo', text: `Yahoo Mail: gələnlər — ${inbox.length} məktub` }); } catch (e) { /* */ }
        // 2) Göndərilənlər — cavab verilibmi?
        let sent = [];
        if (o.detail !== false) {
          try { await go(2, /sent|göndərilən|отправлен/); sent = await scanFolder(o.maxRows || 400, since); } catch (e) { /* */ }
          try { chrome.runtime.sendMessage({ type: 'AMMO_SOC_PROGRESS', source: 'yahoo', text: `Yahoo Mail: göndərilənlər — ${sent.length} məktub` }); } catch (e) { /* */ }
          try { if (!/\/folders\/1(\/|$)/.test(back)) history.back(); else await go(1, /inbox|gələnlər|входящ/); } catch (e) { /* */ }
        }
        const sentBy = new Map();
        for (const s of sent) { const k = normSubj(s.subject); if (!k) continue; if (!sentBy.has(k)) sentBy.set(k, []); sentBy.get(k).push(s); }
        const threads = inbox.map((r) => {
          const ans = (sentBy.get(normSubj(r.subject)) || []).some((s) => !r.at || !s.at || s.at >= r.at);
          const out = ans || r.replied;
          return {
            source: 'yahoo', chat: r.sender || r.email || '—', subject: r.subject, unread: r.unread ? 1 : 0, lastDir: out ? 'out' : 'in', at: r.at,
            preview: (r.subject ? r.subject + ' — ' : '') + r.snippet, link: r.href ? new URL(r.href, location.origin).href : '', ref: { href: r.href }, replied: out, count: r.count, email: r.email, messages: [],
          };
        });
        return { ok: true, source: 'yahoo', account: my, threads };
      })().then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
      return true;
    }
    if (msg.type === 'AMMO_SOC_OPEN') { const h = msg.ref && (msg.ref.href || msg.ref.url); if (h) location.assign(new URL(h, location.origin).href); sendResponse({ ok: true }); return false; }
    return false;
  });
})();
