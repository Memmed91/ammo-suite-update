/* AMMO — Sosial şəbəkə analizi: WhatsApp Web (web.whatsapp.com) oxuyucu (v1.23).
 * Yalnız OXUYUR: söhbət siyahısı (son mesaj kimdəndir, oxunmamış sayı), istəyə görə cavabsız söhbətləri bir-bir açıb
 * son mesajları götürür. Heç nə yazmır, göndərmir. AMMO-nun «Sosial şəbəkə analizi» səhifəsi «Analiz et» basanda işləyir. */
(function () {
  'use strict';
  if (window.top !== window) return;
  // v1.23.1: genişlənmə yeniləndikdən sonra açıq tabda skript yenidən yeridilir — yalnız SON yeridilən nüsxə cavab verir
  const TOK = Math.random().toString(36).slice(2);
  window.__AMMO_WA_TOK = TOK;
  const live = () => window.__AMMO_WA_TOK === TOK;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const T = (el) => (el ? (el.innerText || el.textContent || '').trim() : '');
  const pane = () => document.querySelector('#pane-side');
  const items = () => { const p = pane(); if (!p) return []; let L = [...p.querySelectorAll('[role="listitem"]')]; if (!L.length) L = [...p.querySelectorAll('[role="row"]')]; return L; };
  const MINE_ICONS = '[data-icon^="status-"],[data-icon^="msg-check"],[data-icon^="msg-dblcheck"],[data-icon="msg-time"],[data-icon^="status-dblcheck"]';
  const VOICE_ICONS = '[data-icon="ptt-status"],[data-icon*="ptt"],[data-icon="audio-file"],[data-icon="mic-outlined"],[data-icon="status-ptt"]';
  const TIME_RX = /^(\d{1,2}:\d{2}(\s?[AP]M)?|dünən|bu gün|yesterday|today|вчера|сегодня|\d{1,2}[./]\d{1,2}[./]\d{2,4}|bazar ertəsi|çərşənbə axşamı|çərşənbə|cümə axşamı|cümə|şənbə|bazar|monday|tuesday|wednesday|thursday|friday|saturday|sunday)$/i;

  function readItem(el) {
    const spans = [...el.querySelectorAll('span[title]')];
    const titleEl = el.querySelector('span[title][dir="auto"]') || spans[0];
    const chat = titleEl ? titleEl.getAttribute('title') : '';
    const prevEl = spans.find((s) => s !== titleEl && s.getAttribute('title'));
    const lines = T(el).split('\n').map((x) => x.trim()).filter(Boolean);
    const time = lines.find((l) => TIME_RX.test(l)) || '';
    let preview = prevEl ? prevEl.getAttribute('title') : lines.filter((l) => l !== chat && l !== time && !/^\d+$/.test(l)).join(' ');
    const mine = !!el.querySelector(MINE_ICONS) || /^(siz|you|вы)\s*:/i.test(preview);
    const unreadEl = el.querySelector('span[aria-label*="unread" i],span[aria-label*="oxunmamış" i],span[aria-label*="непрочит" i]');
    const unread = unreadEl ? (parseInt(T(unreadEl), 10) || 1) : 0;
    const voice = !!el.querySelector(VOICE_ICONS);
    const group = /:/.test(preview) && !mine && /^[^:]{2,40}:/.test(preview);
    return { chat, preview: preview.replace(/^(siz|you|вы)\s*:\s*/i, ''), lastDir: mine ? 'out' : 'in', unread, time, voice, group };
  }
  async function scanList(max) {
    const p = pane(); if (!p) return null;
    const seen = new Map();
    const scroller = p.closest('[class]') && (p.scrollHeight > p.clientHeight ? p : p.parentElement);
    const sc = scroller || p;
    sc.scrollTop = 0; await sleep(400);
    for (let guard = 0; guard < 40 && seen.size < max; guard++) {
      items().forEach((el) => { const r = readItem(el); if (r.chat && !seen.has(r.chat)) seen.set(r.chat, r); });
      const before = sc.scrollTop; sc.scrollTop = before + sc.clientHeight * 0.85; await sleep(450);
      if (sc.scrollTop === before) break;
    }
    sc.scrollTop = 0;
    return [...seen.values()].slice(0, max);
  }
  function clickEl(el) {
    const target = el.querySelector('[role="gridcell"]') || el.querySelector('span[title]') || el;
    ['mousedown', 'mouseup', 'click'].forEach((t) => target.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
  }
  async function findAndOpen(chat) {
    const p = pane(); if (!p) return false;
    const sc = p.scrollHeight > p.clientHeight ? p : p.parentElement;
    sc.scrollTop = 0; await sleep(300);
    for (let guard = 0; guard < 40; guard++) {
      const el = items().find((x) => readItem(x).chat === chat);
      if (el) { el.scrollIntoView({ block: 'center' }); await sleep(150); clickEl(el); for (let i = 0; i < 20; i++) { await sleep(250); const h = document.querySelector('#main header span[title], #main header span[dir="auto"]'); if (h && (h.getAttribute('title') === chat || T(h) === chat)) return true; } return true; }
      const b = sc.scrollTop; sc.scrollTop = b + sc.clientHeight * 0.85; await sleep(400); if (sc.scrollTop === b) break;
    }
    return false;
  }
  function parsePre(pre) {
    // «[14:05, 15.10.2026] Elçin: » və ya «[2:05 PM, 10/15/2026] Elchin: »
    const m = /\[(\d{1,2}):(\d{2})(?:\s*([AP]M))?,\s*(\d{1,4})[./-](\d{1,2})[./-](\d{1,4})\]\s*([^:]*):?/.exec(pre || '');
    if (!m) return { at: '', from: '' };
    let h = +m[1]; if (m[3] === 'PM' && h < 12) h += 12; if (m[3] === 'AM' && h === 12) h = 0;
    let a = +m[4], b = +m[5], c = +m[6], y, mo, d;
    if (a > 999) { y = a; mo = b; d = c; } else { y = c < 100 ? 2000 + c : c; if (/\//.test(pre) && a <= 12 && b > 12) { mo = a; d = b; } else if (/\//.test(pre) && a <= 12 && b <= 12 && m[3]) { mo = a; d = b; } else { d = a; mo = b; } }
    const dt = new Date(y, mo - 1, d, h, +m[2]);
    return { at: isNaN(dt) ? '' : dt.toISOString(), from: (m[7] || '').trim() };
  }
  async function voiceAudio(row) {
    // səs artıq yüklənibsə (oynadılıbsa) — blob-u götür; yoxdursa boş (səs çalınmır)
    const a = row.querySelector('audio[src^="blob:"]');
    if (!a) return null;
    try { const b = await (await fetch(a.src)).blob(); if (b.size > 8e6) return null; const buf = new Uint8Array(await b.arrayBuffer()); let s = ''; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000)); return { b64: btoa(s), mime: b.type || 'audio/ogg' }; } catch (e) { return null; }
  }
  async function readOpenChat(limit, withAudio) {
    const main = document.querySelector('#main'); if (!main) return [];
    const rows = [...main.querySelectorAll('[role="row"]')].filter((r) => r.querySelector('.message-in, .message-out'));
    const out = []; let lastAt = '';
    for (const r of rows.slice(-limit)) {
      const dir = r.querySelector('.message-out') ? 'out' : 'in';
      const copy = r.querySelector('[data-pre-plain-text]');
      const p = parsePre(copy && copy.getAttribute('data-pre-plain-text'));
      if (p.at) lastAt = p.at;
      const txtEl = copy && (copy.querySelector('span.selectable-text') || copy.querySelector('[dir]'));
      let text = T(txtEl || copy);
      const isVoice = !!r.querySelector('[data-icon="audio-play"],[data-icon="ptt-play"],[data-icon*="ptt"],button[aria-label*="voice" i],button[aria-label*="səsli" i],span[aria-label*="Voice message" i]');
      const isDoc = !!r.querySelector('[data-icon="document"],[data-icon*="doc-"],[title*=".pdf" i],[title*=".doc" i],[title*=".xls" i]');
      const isImg = !text && !!r.querySelector('img[src^="blob:"]');
      const dur = (T(r).match(/\b\d{1,2}:\d{2}\b/) || [''])[0];
      const m = { dir, from: dir === 'out' ? 'Mən' : p.from, text: isVoice ? '' : text, at: p.at || lastAt, kind: isVoice ? 'voice' : isDoc ? 'file' : isImg ? 'image' : 'text', dur: isVoice ? dur : '' };
      if (isVoice && withAudio) { const au = await voiceAudio(r); if (au) m.audio = au; }
      if (isDoc && !text) m.text = '📎 ' + (T(r.querySelector('[title]')) || 'Fayl');
      out.push(m);
    }
    return out;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!live()) return false;
    if (!msg || sender.id !== chrome.runtime.id) return false;
    if (msg.type === 'AMMO_SOC_PING') { sendResponse({ ok: true, href: location.href }); return false; }
    if (msg.type === 'AMMO_SOC_SCAN') {
      (async () => {
        const o = msg.opts || {};
        for (let i = 0; i < 30 && !pane(); i++) await sleep(1000);
        if (!pane()) return { ok: false, error: document.querySelector('canvas, [data-ref]') ? 'WhatsApp-a daxil olun: telefonla QR kodu skan edin' : 'WhatsApp Web açılmadı' };
        const list = await scanList(o.maxChats || 60);
        const threads = list.map((c) => ({ source: 'wa', chat: c.chat, ref: { chat: c.chat }, unread: c.unread, lastDir: c.lastDir, preview: c.preview, previewKind: c.voice ? 'voice' : 'text', timeText: c.time, messages: [] }));
        if (o.detail !== false) {
          const todo = threads.filter((t) => t.lastDir === 'in').slice(0, o.maxDetail || 25);
          let n = 0;
          for (const t of todo) {
            n++;
            try { if (await findAndOpen(t.chat)) { await sleep(900); t.messages = await readOpenChat(o.perChat || 15, !!o.audio); } } catch (e) { /* növbəti */ }
            try { chrome.runtime.sendMessage({ type: 'AMMO_SOC_PROGRESS', source: 'wa', text: `WhatsApp: ${n}/${todo.length} söhbət oxundu` }); } catch (e) { /* */ }
          }
        }
        return { ok: true, source: 'wa', account: T(document.querySelector('header [title]')) || '', threads };
      })().then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
      return true;
    }
    // v1.23.2: söhbətlər hissə-hissə oxunur (hər sorğu ≤ 6 söhbət) — uzun tək sorğu kəsilmir
    if (msg.type === 'AMMO_SOC_DETAIL') {
      (async () => {
        const want = new Set(msg.chats || []); const out = {};
        const p = pane(); if (!p) return { ok: false, error: 'WhatsApp siyahısı görünmür' };
        const sc = p.scrollHeight > p.clientHeight ? p : p.parentElement;
        sc.scrollTop = 0; await sleep(350);
        const t0 = Date.now();
        for (let guard = 0; guard < 60 && want.size && Date.now() - t0 < 45000; guard++) {
          const vis = items().map((el) => ({ el, r: readItem(el) })).filter((x) => want.has(x.r.chat));
          for (const x of vis) {
            if (!want.has(x.r.chat)) continue;
            want.delete(x.r.chat);
            try {
              x.el.scrollIntoView({ block: 'center' }); await sleep(120); clickEl(x.el);
              let ok = false;
              for (let i = 0; i < 24; i++) { await sleep(200); const h = document.querySelector('#main header span[title], #main header span[dir="auto"]'); if (h && (h.getAttribute('title') === x.r.chat || T(h) === x.r.chat)) { ok = true; break; } }
              await sleep(ok ? 500 : 900);
              out[x.r.chat] = await readOpenChat(msg.perChat || 15, !!msg.audio);
            } catch (e) { out[x.r.chat] = []; }
          }
          const b = sc.scrollTop; sc.scrollTop = b + sc.clientHeight * 0.85; await sleep(380);
          if (sc.scrollTop === b) break;
        }
        sc.scrollTop = 0;
        return { ok: true, results: out, missing: [...want] };
      })().then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
      return true;
    }
    if (msg.type === 'AMMO_SOC_OPEN') { findAndOpen((msg.ref && msg.ref.chat) || '').then((ok) => sendResponse({ ok })); return true; }
    return false;
  });
})();
