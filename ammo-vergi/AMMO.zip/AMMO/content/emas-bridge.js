/* AMMO ƏMAS — körpü (MAIN world).
 * eroom.e-social.gov.az portalının öz "magus.callApi" funksiyası ilə sorğu göndərir — yəni portalın
 * özü necə işləyirsə, AMMO da elə işləyir (sessiya, CSRF, sorğu nömrəsi, recaptcha — hamısı portalın
 * öz kodu ilə). Yalnız OXUMA sorğuları üçün istifadə olunur: hesabatlar, sənəd məlumatı, fayl mətni.
 * İzolyasiya olunmuş AMMO skripti ilə window.postMessage vasitəsilə danışır.
 */
(function () {
  'use strict';
  if (window.__ammoEmasBridge) return;
  window.__ammoEmasBridge = true;

  const ALLOWED = /^(magusbi\.(executeReport|getReportAttributes)|embas\.getVacationLeavesData|eroom\.(getAttachListByType|getDocMainData))$/;
  const ALLOWED_URL = /^\/request\/readFromStorage$/;
  const TIMEOUT = 90000;

  // eroom declares `magus` (and sometimes `pako`) with const/let at top level — such globals are NOT
  // properties of window, so window.magus is undefined. Resolve the bare identifier first.
  function getMagus() {
    try { if (typeof magus !== 'undefined' && magus && typeof magus.callApi === 'function') return magus; } catch (e) { /* not declared */ }
    if (window.magus && typeof window.magus.callApi === 'function') return window.magus;
    try { const g = Function('return typeof magus !== "undefined" ? magus : null')(); if (g && typeof g.callApi === 'function') return g; } catch (e) { /* CSP */ }
    return null;
  }
  function getPako() {
    try { if (typeof pako !== 'undefined' && pako && pako.inflate) return pako; } catch (e) { /* not declared */ }
    return window.pako && window.pako.inflate ? window.pako : null;
  }
  async function waitMagus(ms) {
    const end = Date.now() + ms;
    let m = getMagus();
    while (!m && Date.now() < end) { await new Promise((r) => setTimeout(r, 250)); m = getMagus(); }
    return m;
  }

  function reply(id, ok, data) {
    window.postMessage({ __ammoEmasRes: 1, id, ok, data }, location.origin);
  }

  function errInfo(e) {
    const r = e && e.response;
    return r ? { code: r.code, message: r.message } : { message: String((e && e.message) || e || 'Xəta') };
  }

  async function callApi(opts) {
    const m = await waitMagus(15000);
    return new Promise((resolve, reject) => {
      if (!m) { reject({ message: 'PORTAL_NOT_READY' }); return; }
      let done = false;
      const t = setTimeout(() => { if (!done) { done = true; reject({ message: 'TIMEOUT' }); } }, TIMEOUT);
      const fin = (fn, v) => { if (done) return; done = true; clearTimeout(t); fn(v); };
      try {
        m.callApi(Object.assign({}, opts, {
          loader: false,
          translate: false,
          callback: (r) => fin(resolve, r),
          errorCallback: (e) => fin(reject, errInfo(e)),
        }));
      } catch (e) { fin(reject, errInfo(e)); }
    });
  }

  async function inflateB64(b64) {
    if (!b64) return null;
    const bin = atob(b64);
    const pk = getPako();
    if (pk) {
      const u = pk.inflate(bin);
      return JSON.parse(new TextDecoder('utf-8').decode(u));
    }
    const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    for (const fmt of ['deflate', 'gzip', 'deflate-raw']) {
      try {
        const s = new Blob([bytes]).stream().pipeThrough(new DecompressionStream(fmt));
        return JSON.parse(await new Response(s).text());
      } catch (e) { /* try next */ }
    }
    throw { message: 'GZIP_DECODE' };
  }

  function trans(key) {
    try {
      const m = getMagus();
      if (!key || !m || !m.transWord) return key;
      const v = m.transWord(String(key));
      return typeof v === 'string' && v ? v : key;
    } catch (e) { return key; }
  }

  function context() {
    const txt = (sel) => { const el = document.querySelector(sel); return el ? el.textContent.replace(/\s+/g, ' ').trim() : ''; };
    const body = document.body ? document.body.innerText : '';
    const m = body.match(/([0-9A-Z]{5,7})\s*-\s*(\d{10})/);
    return {
      ready: !!getMagus(),
      pin: m ? m[1] : '',
      voen: m ? m[2] : '',
      org: (Array.from(document.querySelectorAll('a')).map((a) => a.textContent.trim()).find((t) => /\(\d{10}\)\s*$/.test(t)) || '').replace(/\s*\(\d{10}\)\s*$/, ''),
      title: txt('title'),
    };
  }

  window.addEventListener('message', async (ev) => {
    if (ev.source !== window || ev.origin !== location.origin) return;
    const d = ev.data;
    if (!d || d.__ammoEmasReq !== 1 || !d.id) return;
    try {
      if (d.op === 'ctx') return reply(d.id, true, context());
      if (d.op === 'trans') return reply(d.id, true, (d.keys || []).map(trans));
      if (d.op === 'call') {
        if (!ALLOWED.test(d.service || '')) throw { message: 'NOT_ALLOWED: ' + d.service };
        const r = await callApi({ serviceName: d.service, input: d.input || {} });
        if (r && r.gzipResult && !Array.isArray(r.result)) r.result = await inflateB64(r.gzipResult);
        return reply(d.id, true, r);
      }
      if (d.op === 'url') {
        if (!ALLOWED_URL.test(d.url || '')) throw { message: 'NOT_ALLOWED: ' + d.url };
        const raw = await callApi({ url: d.url, input: d.input || {}, dataType: 'text' });
        let j = raw;
        if (typeof raw === 'string') { try { j = JSON.parse(raw); } catch (e) { j = { fileContent: raw }; } }
        return reply(d.id, true, j);
      }
      throw { message: 'UNKNOWN_OP' };
    } catch (e) {
      reply(d.id, false, errInfo(e));
    }
  });

  window.postMessage({ __ammoEmasRes: 1, id: 'hello', ok: true, data: { ready: !!getMagus() } }, location.origin);
})();
