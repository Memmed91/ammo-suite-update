/* AMMO — İlkin audit: a quick profit picture for any period, built only from what the portal already holds:
 *   income   <- issued e-invoices (goods vs services by item type)
 *   expenses <- received e-invoices (sorted into profit-declaration lines), purchase acts,
 *               salaries and employer social contributions from the payroll (vahid) declarations
 *   profit   =  income - expenses;  profit tax 20%
 * When a whole calendar year is chosen, the filed profit declaration is shown alongside for comparison. */
(function (root) {
  'use strict';

  const n0 = (v) => { const x = Number(v); return isFinite(x) ? x : 0; };
  const r2 = (v) => Math.round(n0(v) * 100) / 100;
  const pad2 = (n) => String(n).padStart(2, '0');
  const monthKey = (iso) => { const d = new Date(iso); return isNaN(d) ? '' : `${d.getFullYear()}-${pad2(d.getMonth() + 1)}`; };
  const low = (s) => String(s || '').toLocaleLowerCase('az');

  const OK_STATUSES = ['approved', 'approvedBySystem'];
  const SALE_KINDS = ['defaultInvoice', 'agent', 'resale', 'taxCodex163', 'taxCodex177_5', 'exportNoteInvoice'];
  const RETURN_KINDS = ['returnInvoice', 'returnByAgent'];
  const ADVANCE_KINDS = ['advanceInvoice'];

  // Expense lines of the profit declaration (code, label) + how a purchase is recognised
  const EXP = [
    ['221.1', 'Əmək haqqı və ona bərabər tutulan ödəmələr'],
    ['221.2', 'Sosial sığorta haqları (işəgötürən hissəsi)'],
    ['221.4', 'Malın dəyəri'],
    ['221.5', 'İcarə haqqı', /icar[əe]|kiray[əe]/],
    ['221.7', 'Enerji xərcləri', /elektrik enerji|elektrik enerjisi|elektroenerji|az[əe]ri[şs]ıq|azerishiq|az[əe]renerji|\bkvt/],
    ['221.8', 'Qaz xərcləri', /t[əe]bii qaz|az[əe]riqaz|azeriqaz|qaz t[əe]chizat|qaz s[əe]rfiyyat/],
    ['221.9', 'Yanacaq xərcləri', /benzin|dizel|yanacaq|ai-9[25]|ai-98|\bai9[25]\b|propan|avtoqaz|azpetrol|lukoil|socar petroleum|motor yağ/],
    ['221.10', 'Su və kanalizasiya xərcləri', /az[əe]rsu|azersu|su t[əe]chizat|kanalizasiya|i[çc]m[əe]li su t[əe]chizat/],
    ['221.11', 'Rabitə xərcləri', /rabit[əe]|internet|azercell|bakcell|nar mobile|aztelekom|baktelecom|telefon xidm[əe]t|mobil [əe]laq[əe]|ip-tv/],
    ['221.12', 'Mühafizə xərcləri', /m[üu]hafiz[əe]/],
    ['221.13', 'Bank xidməti üzrə xərclər', /bank xidm[əe]t|inkassasiya/],
    ['221.14', 'Reklam xərcləri', /reklam|marketinq|banner/],
    ['228', 'Təmir xərcləri', /t[əe]mir/],
    ['229', 'Nəqliyyat xərcləri', /da[şs]ınma|y[üu]kda[şs]ıma|n[əe]qliyyat xidm[əe]t|logistik|kuryer|karqo|ekspeditor/],
    ['230.2', 'Ödənilmiş sığorta haqları', /sı[ğg]orta/],
    ['221.15', 'Sair xərclər (xidmətlər və digər)'],
  ];
  const EXP_LABEL = Object.fromEntries(EXP.map(([c, l]) => [c, l]));

  // Which expense line a received invoice item belongs to
  function classifyExpense(item, supplierName) {
    const text = low([item.productName, item.productGroup && item.productGroup.name, supplierName].filter(Boolean).join(' | '));
    for (const [code, , re] of EXP) if (re && re.test(text)) return code;
    const t = low(item.productGroup && item.productGroup.type);
    if (t === 'good') return '221.4';
    return '221.15';
  }
  const itemKind = (item) => { const t = low(item && item.productGroup && item.productGroup.type); return t === 'good' ? 'good' : t === 'service' ? 'service' : 'unknown'; };

  // One invoice -> its item lines (cost without VAT, VAT) — falls back to the list totals when the detail is missing
  function invoiceLines(inv, det) {
    const d = det && !det.__error ? { ...inv, ...det } : inv;
    const items = (det && !det.__error && Array.isArray(det.items)) ? det.items : [];
    if (!items.length) return [{ name: '(sətirlər alınmadı)', group: null, cost: n0(d.costWithoutVat ?? d.amount), vat: n0(d.vat), unknown: true }];
    return items.map((it) => ({ name: it.productName || '', group: it.productGroup || null, cost: n0(it.cost), vat: n0(it.vat18) * 0.18, item: it }));
  }

  function latestPerPeriod(decls) {
    const when = (d) => new Date(d.submissionDate || d.modificationDate || d.registrationDate || 0).getTime();
    const groups = new Map();
    decls.forEach((d) => {
      if (/DRAFT/i.test(d.declarationStatus || '')) return;
      const p = d.reportingPeriod || {};
      const k = [d.taxCode, p.type, Number(p.month) || 0, p.year].join('|');
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(d);
    });
    return [...groups.values()].map((g) => {
      g.sort((a, b) => when(a) - when(b));
      return g.find((d) => d.lastClarifying === 'LAST') || g[g.length - 1];
    });
  }

  // values of chosen codes in a filed profit declaration
  function declaredProfit(base, maps) {
    const ti = (base && base.taxInformation) || {};
    const out = {};
    for (const def of maps.PROFIT.slice(0, 3)) {
      const list = def.path.split('.').reduce((o, k) => (o ? o[k] : undefined), ti) || [];
      const by = new Map(list.map((e) => [e.indicator, e]));
      def.rows.forEach(([ind, label]) => {
        const m = String(label).match(/^([\d.\-]+)\s/);
        if (m) { const e = by.get(ind); out[m[1]] = n0(e && e[def.fields[0]]); }
      });
    }
    return out;
  }

  // ------------------------------------------------------------ pure aggregation (testable without the portal)
  function build({ period, sales, saleDetails, purchases, purchaseDetails, acts, payroll, declared, self }) {
    // v1.23: düzəliş edilmiş qaimələr iki dəfə sayılmasın (seriya üzrə son versiya); emala vermə / yerdəyişmə gəlir deyil
    const KEEP = new Set(SALE_KINDS.concat(RETURN_KINDS, ADVANCE_KINDS));
    const dd = (list, det) => {
      const S = root.AMMO_STOCK;
      const pairs = S ? S.latestBySerial(list, det) : list.map((inv, i) => ({ inv, det: det[i] }));
      const L = [], Dd = []; pairs.forEach(({ inv, det: x }) => { if (KEEP.has(inv.kind)) { L.push(inv); Dd.push(x); } });
      return [L, Dd];
    };
    [sales, saleDetails] = dd(sales, saleDetails); [purchases, purchaseDetails] = dd(purchases, purchaseDetails);
    const months = new Map();
    const mon = (k) => { if (!months.has(k)) months.set(k, { income: 0, expense: 0 }); return months.get(k); };
    const customers = new Map(), suppliers = new Map();
    const bump = (map, tin, name, v) => { const k = tin || name || '—'; const e = map.get(k) || { tin: tin || '', name: name || '', amount: 0, count: 0 }; e.amount += v; e.count++; map.set(k, e); };

    const income = { goods: 0, services: 0, unknown: 0, returns: 0, advances: 0, vat: 0, count: 0 };
    const incomeLines = [];
    // v1.22: mal hərəkəti (miqdar) — mal qalığı üçün: [tarix, istiqamət, ad, kod, ölçü, miqdar, qiymət, dəyər, tərəf]
    const qtyLines = [];
    const qtyOf = (l, dir, inv, party) => {
      const it = l.item; if (!it) return;
      const t = low(it.productGroup && it.productGroup.type);
      if (t === 'service') return;
      const q = n0(it.quantity); if (!q) return;
      qtyLines.push([inv.createdAt, dir, String(it.productName || '').trim(), (it.productGroup && it.productGroup.code) || it.productCode || '', it.unit || (it.unitFromDict && (it.unitFromDict.name || it.unitFromDict.code)) || '', q, n0(it.pricePerUnit) || (q ? n0(it.cost) / q : 0), n0(it.cost), party || '', inv.serialNumber || '']);
    };
    sales.forEach((inv, i) => {
      const kind = inv.kind;
      const lines = invoiceLines(inv, saleDetails[i]);
      const r = inv.receiver || {};
      const mk = monthKey(inv.createdAt);
      if (ADVANCE_KINDS.includes(kind)) { income.advances += lines.reduce((s, l) => s + l.cost, 0); return; }
      const sign = RETURN_KINDS.includes(kind) ? -1 : 1; // our own returns to suppliers are handled on the expense side
      if (sign < 0) return;
      income.count++;
      lines.forEach((l) => {
        qtyOf(l, 'out', inv, r.name);
        const k = l.unknown ? 'unknown' : itemKind(l.item);
        const v = l.cost;
        if (k === 'good') income.goods += v; else if (k === 'service') income.services += v; else income.unknown += v;
        income.vat += l.vat;
        mon(mk).income += v;
        bump(customers, r.tin || r.fin, r.name, v);
        incomeLines.push([inv.createdAt, inv.serialNumber || '', r.tin || r.fin || '', r.name || '', l.name, k === 'good' ? 'Mal' : k === 'service' ? 'Xidmət' : '—', r2(v), r2(l.vat)]);
      });
    });

    const exp = Object.fromEntries(EXP.map(([c]) => [c, 0]));
    const expCount = Object.fromEntries(EXP.map(([c]) => [c, 0]));
    let vatIn = 0;
    const expenseLines = [];
    purchases.forEach((inv, i) => {
      const kind = inv.kind;
      const lines = invoiceLines(inv, purchaseDetails[i]);
      const s = inv.sender || {};
      const mk = monthKey(inv.createdAt);
      if (ADVANCE_KINDS.includes(kind)) return;
      if (RETURN_KINDS.includes(kind)) { // a customer returned goods to us: income goes down
        lines.forEach((l) => { income.returns += l.cost; mon(mk).income -= l.cost; qtyOf(l, 'retIn', inv, s.name); });
        return;
      }
      lines.forEach((l) => {
        qtyOf(l, 'in', inv, s.name);
        const code = l.unknown ? '221.15' : classifyExpense(l.item, s.name);
        exp[code] += l.cost; expCount[code]++;
        vatIn += l.vat;
        mon(mk).expense += l.cost;
        bump(suppliers, s.tin || s.fin, s.name, l.cost);
        expenseLines.push([inv.createdAt, inv.serialNumber || '', s.tin || s.fin || '', s.name || '', l.name, code, EXP_LABEL[code], r2(l.cost), r2(l.vat)]);
      });
    });
    // returns we sent back to suppliers reduce what we spent on goods
    sales.forEach((inv, i) => {
      if (!RETURN_KINDS.includes(inv.kind)) return;
      invoiceLines(inv, saleDetails[i]).forEach((l) => qtyOf(l, 'retOut', inv, (inv.receiver || {}).name));
      const v = invoiceLines(inv, saleDetails[i]).reduce((s, l) => s + l.cost, 0);
      exp['221.4'] -= v; mon(monthKey(inv.createdAt)).expense -= v;
    });

    let actsTotal = 0;
    acts.forEach((a) => {
      const v = n0(a.amount ?? a.totalAmount ?? a.cost);
      actsTotal += v; exp['221.4'] += v; expCount['221.4']++; mon(monthKey(a.createdAt || a.creationDate)).expense += v;
      const sl = a.seller || {};
      (Array.isArray(a.items) ? a.items : Array.isArray(a.products) ? a.products : []).forEach((it) => { const q = n0(it.quantity); if (q) qtyLines.push([a.createdAt || a.creationDate, 'act', String(it.productName || it.name || '').trim(), it.productCode || '', it.unit || '', q, n0(it.pricePerUnit || it.price), n0(it.cost || it.amount), sl.name || '', a.serialNumber || '']); });
      expenseLines.push([a.createdAt || a.creationDate, a.serialNumber || '', sl.fin || sl.tin || '', sl.name || '', 'Alış aktı', '221.4', EXP_LABEL['221.4'], r2(v), 0]);
    });

    payroll.months.forEach((m) => {
      exp['221.1'] += m.salary; exp['221.2'] += m.social;
      const e = mon(m.key); e.expense += m.salary + m.social;
    });
    expCount['221.1'] = payroll.months.length; expCount['221.2'] = payroll.months.length;

    const incomeTotal = income.goods + income.services + income.unknown - income.returns;
    const expenseTotal = Object.values(exp).reduce((s, v) => s + v, 0);
    const profit = incomeTotal - expenseTotal;
    const tax = profit > 0 ? profit * 0.2 : 0;

    const keys = [...months.keys()].filter(Boolean).sort();
    const top = (map) => [...map.values()].sort((a, b) => b.amount - a.amount).slice(0, 8).map((e) => ({ ...e, amount: r2(e.amount) }));
    return {
      kind: 'audit', created: Date.now(), period, self: self || '',
      income: {
        goods: r2(income.goods), services: r2(income.services), unknown: r2(income.unknown), returns: r2(income.returns),
        advances: r2(income.advances), vat: r2(income.vat), count: income.count, total: r2(incomeTotal),
      },
      expenses: EXP.map(([code, label]) => ({ code, label, amount: r2(exp[code]), count: expCount[code] })),
      expenseTotal: r2(expenseTotal), vatIn: r2(vatIn), actsTotal: r2(actsTotal),
      payroll: { salary: r2(payroll.months.reduce((s, m) => s + m.salary, 0)), social: r2(payroll.months.reduce((s, m) => s + m.social, 0)),
        months: payroll.months.length, declarations: payroll.declarations, employees: payroll.employees, avgEmployees: payroll.avgEmployees || 0 },
      profit: r2(profit), taxRate: 20, tax: r2(tax),
      months: keys.map((k) => ({ key: k, income: r2(months.get(k).income), expense: r2(months.get(k).expense) })),
      customers: top(customers), suppliers: top(suppliers),
      counts: { sales: sales.length, purchases: purchases.length, acts: acts.length },
      declared: declared || null,
      lines: { income: incomeLines, expense: expenseLines, qty: qtyLines },
    };
  }

  // ------------------------------------------------------------ portal run
  // v1.23: qaimələrin yüklənməsi və hesablanma ayrıldı — İlkin audit bütün tarixçəni bir dəfə oxuyur, dövr üçün süzür
  async function payroll(API, fromISO, toISO, declsAll, step) {
    const fromKey = fromISO.slice(0, 7), toKey = toISO.slice(0, 7);
    if (!declsAll) {
      step && step('Muzdlu iş bəyannamələri oxunur...');
      const years = [];
      for (let y = Number(fromISO.slice(0, 4)); y <= Number(toISO.slice(0, 4)); y++) years.push(y);
      const lists = await Promise.all(years.map((y) => API.declarations(y).catch(() => [])));
      declsAll = lists.flat().map((e) => (e && e.declaration) || e).filter(Boolean);
    }
    const unified = latestPerPeriod(declsAll.filter((d) => d.taxCode === '_0901'));
    const bases = await API.pool(unified, 5, (d) => API.declarationBase(d.id || d.registrationNumber));
    const months = [];
    let employees = 0, empSum = 0;
    unified.forEach((d, i) => {
      const b = bases[i];
      if (!b || b.__error || !b.taxInformation) return;
      const ti = b.taxInformation;
      const p = d.reportingPeriod || {};
      const m = Number(p.month) || 1;
      const startMonth = [1, 4, 7, 10].includes(m) ? m : (m <= 4 ? (m - 1) * 3 + 1 : m);
      const sal = (ti.salary || []).find((e) => e.indicator === '_1300') || {};
      const mt = new Map((ti.mainTaxes || []).map((e) => [e.indicator, e]));
      const ec = Array.isArray(ti.employeeCount) ? (ti.employeeCount.find((e) => e.indicator === '_2901') || {}) : (ti.employeeCount || {});
      ['M1', 'M2', 'M3'].forEach((suf, k) => {
        const key = `${p.year}-${pad2(startMonth + k)}`;
        if (key < fromKey || key > toKey) return;
        const social = ['MDSS_INSURER_TAX_AMOUNT', 'UNEMPLOYMENT_INSURER_TAX_AMOUNT', 'ITS_INSURER_TAX_AMOUNT']
          .reduce((s, ind) => s + n0(mt.get(ind) && mt.get(ind)['amount' + suf]), 0);
        months.push({ key, salary: n0(sal['salary' + suf]), social });
        employees = Math.max(employees, n0(ec['count' + suf]));
        empSum += n0(ec['count' + suf]);
      });
    });
    const nMonths = new Set(months.map((m) => m.key)).size || 12;
    return { months, declarations: unified.length, employees, avgEmployees: Math.round((empSum / nMonths) * 100) / 100 };
  }
  // v1.23.1: all=true — mal qalığı üçün BÜTÜN qaimələr (bütün növlər, ləğv edilmiş/passiv olanlardan başqa bütün statuslar)
  const ALIVE_STATUSES = ['approved', 'approvedBySystem', 'onApproval', 'onApprovalEdited', 'updateApproval', 'updateRequested', 'cancelRequested', 'cancelationRefused', 'correctionRefused'];
  async function fetchInvoices(API, fromISO, toISO, step, opts = {}) {
    const D = root.AMMO_DICT;
    const from = D.apiDate(fromISO), to = D.apiDate(toISO, true);
    const all = !!opts.all;
    const statuses = all ? ALIVE_STATUSES : OK_STATUSES;
    const kinds = all ? D.INVOICE_KINDS.map((k) => k[0]) : SALE_KINDS.concat(RETURN_KINDS, ADVANCE_KINDS, ['recycling', 'exciseGoodsTransfer']);
    step('Göndərilən (satış) qaimələri yüklənir...');
    const sales = await API.findInvoices({ direction: 'outbox', statuses, kinds, from, to }, (n) => step(`Göndərilən qaimələr yüklənir... ${n}`));
    step('Gələn (alış) qaimələri yüklənir...');
    const purchases = await API.findInvoices({ direction: 'inbox', statuses, kinds, from, to }, (n) => step(`Gələn qaimələr yüklənir... ${n}`));
    step('Alış aktları yüklənir...');
    const acts = await API.findActs({ statuses: all ? ['approved', 'approvedAttachment', 'cancellationRefused', 'waitingForSellerCancelApproval', 'waitingForBuyerCancelApproval'] : ['approved'], kinds: D.ACT_KINDS.map((k) => k[0]), from, to }).catch(() => []);
    return { sales, purchases, acts };
  }
  /** hazır məlumatla dövr üzrə gəlir-xərc (qaimələr + aktlar + maaş) */
  function compute({ fromISO, toISO, sales, saleDetails, purchases, purchaseDetails, acts, payroll: pr, declared }) {
    const inP = (d) => { const x = String(d || '').slice(0, 10); return x >= fromISO && x <= toISO; };
    const okSt = (x) => !x.status || OK_STATUSES.includes(x.status);
    const pick = (list, det) => { const L = [], Dd = []; list.forEach((inv, i) => { if (inP(inv.createdAt) && okSt(inv)) { L.push(inv); Dd.push(det[i]); } }); return [L, Dd]; };
    const [s, sd] = pick(sales, saleDetails), [p, pd] = pick(purchases, purchaseDetails);
    const self = (sales[0] && sales[0].sender && sales[0].sender.name) || (purchases[0] && purchases[0].receiver && purchases[0].receiver.name) || '';
    return build({ period: { fromISO, toISO }, sales: s, saleDetails: sd, purchases: p, purchaseDetails: pd, acts: acts.filter((a) => inP(a.createdAt || a.creationDate) && (!a.status || a.status === 'approved')), payroll: pr, declared: declared || null, self });
  }
  async function run({ fromISO, toISO, fullYear }, step) {
    const API = root.AMMO_API;
    const { sales, purchases, acts } = await fetchInvoices(API, fromISO, toISO, step);
    const all = sales.concat(purchases);
    let done = 0;
    const det = await API.pool(all, 6, (inv) => API.invoiceDetail(inv.id, inv.sourceSystem),
      () => step(`Qaimə sətirləri oxunur (mal / xidmət)... ${++done}/${all.length}`));
    const pr = await payroll(API, fromISO, toISO, null, step);
    step('Hesablanır...');
    return compute({ fromISO, toISO, sales, saleDetails: det.slice(0, sales.length), purchases, purchaseDetails: det.slice(sales.length), acts, payroll: pr });
  }

  root.AMMO_AUDIT = { run, build, compute, payroll, fetchInvoices, classifyExpense, declaredProfit, latestPerPeriod, invoiceLines, EXP, OK_STATUSES };
})(typeof globalThis !== 'undefined' ? globalThis : this);
