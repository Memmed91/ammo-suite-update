/* AMMO — ƏMAS paneli (eroom.e-social.gov.az)
 *
 * 1) Reyestrlər → Excel: əmək müqavilələri, əmrlər (xitam, məzuniyyət, ezamiyyə) reyestrlərini portalın
 *    öz hesabatlarından (magusbi.executeReport) BÜTÜN səhifələri ilə çəkir və bir kliklə Excel-ə yazır.
 * 2) Məzuniyyət qalığı: hər işçi üçün iş illəri üzrə hüquq / istifadə / qalıq, istifadə etmədiyi illər,
 *    maaş tarixçəsi (nə vaxt, neçə idi, indi neçədir) — ekranda və Excel-də.
 *
 * Yalnız OXUYUR. Heç bir sənəd yaratmır, dəyişmir, imzalamır.
 * Sorğular portalın öz funksiyası ilə gedir (content/emas-bridge.js, MAIN world).
 */
(function () {
  'use strict';
  if (window.__ammoEmasPanel) return;
  window.__ammoEmasPanel = true;
  if (!/(^|\.)eroom\.e-social\.gov\.az$/.test(location.hostname)) return;

  // =====================================================================================
  // Bridge client
  // =====================================================================================
  const pending = new Map();
  let seq = 0;
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.origin !== location.origin) return;
    const d = ev.data;
    if (!d || d.__ammoEmasRes !== 1 || !pending.has(d.id)) return;
    const p = pending.get(d.id);
    pending.delete(d.id);
    clearTimeout(p.t);
    d.ok ? p.resolve(d.data) : p.reject(Object.assign(new Error(errText(d.data)), { info: d.data }));
  });
  function rpc(op, payload, timeout = 100000) {
    return new Promise((resolve, reject) => {
      const id = 'ae' + Date.now().toString(36) + (++seq);
      const t = setTimeout(() => { pending.delete(id); reject(new Error('Portal cavab vermədi (vaxt bitdi)')); }, timeout);
      pending.set(id, { resolve, reject, t });
      window.postMessage(Object.assign({ __ammoEmasReq: 1, id, op }, payload), location.origin);
    });
  }
  function errText(e) {
    if (!e) return 'Naməlum xəta';
    const m = String(e.message || '');
    if (m === 'PERMISSION_ERROR' || e.code === '11821') return 'Bu reyestrə icazəniz yoxdur (portal: PERMISSION_ERROR)';
    if (m === 'PORTAL_NOT_READY') return 'Portal hələ yüklənməyib — səhifəni yeniləyib yenidən cəhd edin';
    if (m === 'TIMEOUT') return 'Portal vaxtında cavab vermədi';
    if (/CSRF|SESSION|token/i.test(m) || e.code === 'CSRF') return 'Sessiya bitib — portala yenidən daxil olun';
    return m + (e.code && e.code !== '0' ? ' (kod ' + e.code + ')' : '');
  }
  const api = {
    call: (service, input) => rpc('call', { service, input }),
    url: (url, input) => rpc('url', { url, input }),
    trans: (keys) => rpc('trans', { keys }),
    ctx: () => rpc('ctx', {}, 8000),
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // =====================================================================================
  // Value helpers
  // =====================================================================================
  const TZ = 'Asia/Baku';
  const pad = (n) => String(n).padStart(2, '0');
  function msToDMY(ms) {
    try {
      const p = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, day: '2-digit', month: '2-digit', year: 'numeric' }).formatToParts(new Date(ms));
      const g = (t) => p.find((x) => x.type === t).value;
      return `${g('day')}.${g('month')}.${g('year')}`;
    } catch (e) { const d = new Date(ms); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`; }
  }
  function toDMY(v) {
    if (v == null || v === '') return '';
    if (typeof v === 'number' || /^\d{11,14}$/.test(String(v))) return msToDMY(Number(v));
    const s = String(v).trim();
    let m;
    if ((m = s.match(/^(\d{2})[.\-/](\d{2})[.\-/](\d{4})/))) return /^01\.01\.1900/.test(`${m[1]}.${m[2]}.${m[3]}`) ? '' : `${m[1]}.${m[2]}.${m[3]}`;
    if ((m = s.match(/^(\d{4})[.\-/](\d{2})[.\-/](\d{2})/))) return m[1] === '1900' ? '' : `${m[3]}.${m[2]}.${m[1]}`;
    return s;
  }
  function parseD(v) { // -> UTC-midnight Date or null
    const s = toDMY(v);
    const m = s.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
    return m ? new Date(Date.UTC(+m[3], +m[2] - 1, +m[1])) : null;
  }
  const fmtD = (d) => (d ? `${pad(d.getUTCDate())}.${pad(d.getUTCMonth() + 1)}.${d.getUTCFullYear()}` : '');
  const DAY = 86400000;
  const addDays = (d, n) => new Date(d.getTime() + n * DAY);
  function addYears(d, n) {
    const y = d.getUTCFullYear() + n, m = d.getUTCMonth(), day = d.getUTCDate();
    const last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    return new Date(Date.UTC(y, m, Math.min(day, last)));
  }
  const daysIncl = (a, b) => Math.round((b - a) / DAY) + 1;
  function todayUTC() { const p = toDMY(Date.now()); return parseD(p); }
  function num(v) {
    if (v == null || v === '') return null;
    if (typeof v === 'number') return isFinite(v) ? v : null;
    const n = Number(String(v).replace(/\s/g, '').replace(',', '.'));
    return isFinite(n) ? n : null;
  }
  const r2 = (x) => Math.round(x * 100) / 100;
  function serviceText(from, to) {
    if (!from || !to || to < from) return '';
    let y = to.getUTCFullYear() - from.getUTCFullYear();
    let m = to.getUTCMonth() - from.getUTCMonth();
    let d = to.getUTCDate() - from.getUTCDate() + 1;
    if (d < 0) { m -= 1; d += new Date(Date.UTC(to.getUTCFullYear(), to.getUTCMonth(), 0)).getUTCDate(); }
    if (m < 0) { y -= 1; m += 12; }
    return [y ? y + ' il' : '', m ? m + ' ay' : '', d ? d + ' gün' : ''].filter(Boolean).join(' ') || '0 gün';
  }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const normName = (s) => String(s || '').replace(/\s+/g, ' ').trim();

  const DOC_TYPES = {
    docType_3: 'Əmək müqaviləsi bildirişi', docType_4: 'Əmək müqaviləsi bildirişinə dəyişiklik',
    docType_46: 'Əmək müqaviləsi', docType_47: 'Əmək müqaviləsinə dəyişiklik', docType_5: 'Xitam əmri',
  };
  const DATE_KEYS = /(^|_)(date|birthday|begin|end|start)(_|$)|date$|Date$/i;

  // =====================================================================================
  // Reports
  // =====================================================================================
  const attrCache = new Map();
  async function reportMeta(reportId) {
    if (attrCache.has(reportId)) return attrCache.get(reportId);
    const r = await api.call('magusbi.getReportAttributes', { reportId });
    const a = r.attributes || {};
    const outs = r.outputParams || {};
    const order = String((a.extended && a.extended.columnOrder) || '').split(',').map((s) => s.trim()).filter(Boolean);
    Object.keys(outs).forEach((k) => { if (!order.includes(k)) order.push(k); });
    const cols = order.filter((k) => outs[k] && +outs[k].visible === 1 && outs[k].type !== 'fileDownload');
    // labels: may be language keys like "emas.pin"
    const rawLabels = cols.map((k) => { const o = outs[k]; return o.langId && !String(o.label).includes('.') ? o.langId + '.' + o.label : String(o.label || k); });
    let labels = rawLabels;
    try { labels = await api.trans(rawLabels); } catch (e) { /* keep raw */ }
    labels = labels.map((l, i) => (/^[\w-]+\.[\w-]+$/.test(l) ? prettyKey(cols[i]) : String(l).trim()));
    // value dictionaries from filter inputs (cm lists)
    const dict = {};
    Object.values(a.inputs || {}).forEach((inp) => {
      (inp.dataValues || []).forEach((dv) => { if (dv && dv.id != null) dict[String(dv.id)] = String(dv.text || '').trim(); });
    });
    const meta = { reportId, cols, labels, types: Object.fromEntries(cols.map((k) => [k, outs[k].type])), dict, inputs: a.inputs || {}, pageLimit: +a.pageLimit || 50 };
    attrCache.set(reportId, meta);
    return meta;
  }
  function prettyKey(k) {
    const map = { doc_no: 'Sənədin nömrəsi', doc_date: 'Sənədin tarixi', doc_status: 'Statusu', doc_type: 'Sənədin tipi', pin: 'FİN', full_name: 'Tam adı', fullname: 'Tam adı' };
    return map[k] || k.replace(/_/g, ' ');
  }

  async function fetchAll(reportId, attributes, onPage) {
    const out = [];
    const seen = new Set();
    const LIMIT = 100;
    let offset = 0;
    for (let page = 0; page < 400; page++) {
      const r = await api.call('magusbi.executeReport', { reportId, attributes: attributes || {}, pagination: { offset, limit: LIMIT } });
      const rows = Array.isArray(r.result) ? r.result : [];
      if (!rows.length) break;
      let fresh = 0;
      for (const row of rows) {
        const key = row.doc_oid || row.doc_no || row.contract_number || JSON.stringify(row);
        if (seen.has(key)) continue;
        seen.add(key); out.push(row); fresh++;
      }
      if (onPage) onPage(out.length);
      if (!fresh) break;                       // server ignored offset — stop safely
      offset += rows.length;
      if (rows.length < LIMIT && r.hasMore === false) break;
      await sleep(120);
    }
    return out;
  }

  async function transOps(values) {
    const uniq = [...new Set(values.filter((v) => typeof v === 'string' && /^fl[A-Z]/.test(v)))];
    if (!uniq.length) return {};
    const keys = [];
    uniq.forEach((v) => { const k = v.replace(/_invisible$|_visible$/, ''); ['embas', 'emas', 'common', 'orders', 'magusCommon'].forEach((ns) => keys.push(ns + '.' + k)); });
    let tr = keys;
    try { tr = await api.trans(keys); } catch (e) { /* ignore */ }
    const res = {};
    uniq.forEach((v, i) => {
      const cand = tr.slice(i * 5, i * 5 + 5).find((t, j) => t && t !== keys[i * 5 + j] && typeof t === 'string');
      res[v] = cand || v.replace(/_invisible$|_visible$/, '');
    });
    return res;
  }

  function cellValue(meta, k, v, opsDict) {
    if (v == null) return '';
    if (k === 'doc_type' && DOC_TYPES[v]) return DOC_TYPES[v];
    if (typeof v === 'string' && meta.dict[v] != null) return meta.dict[v];
    if (opsDict && opsDict[v]) return opsDict[v];
    const t = meta.types[k];
    if (t === 'date' || DATE_KEYS.test(k)) {
      if (k === 'doc_date' && (typeof v === 'number' || /^\d{11,14}$/.test(String(v)))) {
        const d = new Date(Number(v));
        const hm = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hour12: false }).format(d);
        return msToDMY(Number(v)) + ' ' + hm;
      }
      const s = toDMY(v);
      if (s) return s;
    }
    if (/salary|amount|məbləğ/i.test(k)) { const n = num(v); if (n != null) return n; }
    if (typeof v === 'number') return v;
    return String(v).trim();
  }

  // ---- registry catalogue (menu names exactly as in the portal) -------------------------
  const REGISTRIES = [
    { group: 'Əmək müqaviləsi reyestri', items: [
      { id: 'changes', name: 'Əmək müqaviləsinə dəyişiklik', note: 'bütün dəyişiklik sənədləri + maaş fərqi', special: 'changes' },
      { id: 'emasExpiredEmploymentContractOnline', name: 'Qüvvədən düşən əmək müqavilələri' },
      { id: 'emasSentForApprovalEmploymentContractOnline', name: 'Vətəndaşa təsdiq üçün göndərilən əmək müqavilələri' },
      { id: 'emasPendingEmploymentContractOnline', name: 'İcrada olan əmək müqavilələri' },
      { id: 'emasExpiredEmpContractsOnline', name: 'Müddəti bitən qüvvədə olan müddətli əmək müqavilələri' },
      { id: 'emasValidEmploymentContractOnline', name: 'Qüvvədə olan əmək müqavilələri' },
      { id: 'cancelled', name: 'Ləğv edilmiş əmək müqavilələri', note: 'işəgötürən + sistem tərəfindən', special: 'cancelled' },
      { id: 'emasSendToSignEmploymentContractOnline', name: 'İmzaya göndərilən əmək müqavilələri' },
      { id: 'emasPreviousTerminatedContracts', name: 'İşçinin Köhnə Əmək Müqavilələri' },
    ] },
    { group: 'Əmrlər', items: [
      { id: 'emasValidTerminatedContract', name: 'Etibarlı xitam əmrləri' },
      { id: 'embasHRApplicationsAll', name: 'Bütün məzuniyyət əmrləri', note: 'əmrin içindən: tarixlər, günlər, iş ili', special: 'vacAll' },
      { id: 'embasHRApplicationsEmployee', name: 'Məzuniyyət əmrləri', note: 'növlər üzrə', special: 'vacByType' },
      { id: 'embasBusinessTripOrderAll', name: 'Bütün ezamiyyə əmrləri' },
    ] },
    { group: 'Əlavə (istəyə görə)', optional: true, items: [
      { id: 'empVacation', name: 'Məzuniyyət günləri (ƏMAS statistikası)' },
      { id: 'workLeaveRecallAll', name: 'Bütün məzuniyyətdən geri çağırılma əmrləri' },
      { id: 'embasAllOrderAll', name: 'Bütün digər əmrlər' },
      { id: 'emasPendingTerminatedContract', name: 'İcra gözləyən xitam əmrləri' },
    ] },
  ];

  // Builds { title, header, rows, note } for one registry
  async function buildRegistry(item, progress) {
    if (item.special === 'changes') return buildChanges(progress);
    if (item.special === 'cancelled') return buildCancelled(progress);
    if (item.special === 'vacAll') return buildVacAll(progress);
    if (item.special === 'vacByType') return buildVacByType(progress);
    const meta = await reportMeta(item.id);
    const rows = await fetchAll(item.id, {}, (n) => progress(`${n} sətir…`));
    return tableFrom(meta, rows, item.name);
  }
  async function tableFrom(meta, rows, title, extraCols) {
    const ops = await transOps(rows.flatMap((r) => meta.cols.map((k) => r[k])));
    const header = ['№', ...meta.labels, ...((extraCols || []).map((c) => c.label))];
    const out = rows.map((r, i) => [i + 1, ...meta.cols.map((k) => cellValue(meta, k, r[k], ops)), ...((extraCols || []).map((c) => c.get(r)))]);
    return { title, header, rows: out };
  }

  // -- Əmək müqaviləsinə dəyişiklik: every change document (valid + superseded), with salary delta
  async function contractVersions(progress) {
    const [valid, expired] = await Promise.all([
      fetchAll('emasValidEmploymentContractOnline', {}, (n) => progress && progress(`qüvvədə olan: ${n}…`)),
      fetchAll('emasExpiredEmploymentContractOnline', {}, (n) => progress && progress(`qüvvədən düşən: ${n}…`)),
    ]);
    const all = [...valid.map((r) => Object.assign({ _src: 'valid' }, r)), ...expired.map((r) => Object.assign({ _src: 'expired' }, r))];
    const byKey = new Map();
    all.forEach((r) => { const k = r.doc_no || r.doc_oid; if (!byKey.has(k) || r._src === 'valid') byKey.set(k, r); });
    return [...byKey.values()];
  }
  const chainOf = (docNo) => String(docNo || '').slice(0, -2);
  const verOf = (docNo) => parseInt(String(docNo || '').slice(-2), 10) || 0;
  function sortVersions(list) {
    return list.slice().sort((a, b) => verOf(a.doc_no) - verOf(b.doc_no) || (num(a.doc_date) || 0) - (num(b.doc_date) || 0));
  }
  async function buildChanges(progress) {
    const meta = await reportMeta('emasValidEmploymentContractOnline');
    const versions = await contractVersions(progress);
    const chains = new Map();
    versions.forEach((r) => { const c = chainOf(r.doc_no); if (!chains.has(c)) chains.set(c, []); chains.get(c).push(r); });
    const prevSalary = new Map();
    chains.forEach((list) => { let prev = null; sortVersions(list).forEach((r) => { prevSalary.set(r.doc_no, prev); prev = num(r.monthly_salary); }); });
    const changes = versions.filter((r) => r.doc_type === 'docType_4' || r.doc_type === 'docType_47' || verOf(r.doc_no) > 0)
      .sort((a, b) => String(a.identification_number).localeCompare(String(b.identification_number)) || verOf(a.doc_no) - verOf(b.doc_no));
    const t = await tableFrom(meta, changes, 'Əmək müqaviləsinə dəyişikliklər', [
      { label: 'Əvvəlki maaş', get: (r) => (prevSalary.get(r.doc_no) == null ? '' : prevSalary.get(r.doc_no)) },
      { label: 'Maaş dəyişikliyi (AZN)', get: (r) => { const p = prevSalary.get(r.doc_no), c = num(r.monthly_salary); return p == null || c == null ? '' : r2(c - p); } },
      { label: 'Hazırkı vəziyyət', get: (r) => (r._src === 'valid' ? 'Qüvvədədir' : 'Əvəzlənib / qüvvədən düşüb') },
    ]);
    t.note = 'Hər işçinin bütün dəyişiklik sənədləri (qüvvədə olan və qüvvədən salınmış versiyalar) — maaş fərqi ilə.';
    return t;
  }
  async function buildCancelled(progress) {
    const parts = [['emasInvalidEmploymentContractOnline', 'İşəgötürən'], ['emasInvalidEmploymentContractOnlineSystem', 'Sistem']];
    let header = null; const rows = [];
    for (const [id, who] of parts) {
      const meta = await reportMeta(id);
      const data = await fetchAll(id, {}, (n) => progress(`${who}: ${n}…`));
      const t = await tableFrom(meta, data, '', [{ label: 'Ləğv edən', get: () => who }]);
      if (!header) header = t.header;
      t.rows.forEach((r) => { const row = header.map((h) => { const i = t.header.indexOf(h); return i >= 0 ? r[i] : ''; }); rows.push(row); });
    }
    rows.forEach((r, i) => (r[0] = i + 1));
    return { title: 'Ləğv edilmiş əmək müqavilələri', header, rows };
  }

  // -- Vacation orders, enriched from the order document itself
  let groundsCache = null;
  async function leaveGrounds() {
    if (groundsCache) return groundsCache;
    const map = new Map(); const paid = new Set();
    try {
      const r = await api.call('embas.getVacationLeavesData', { leaveType: 1 });
      (r.list || []).forEach((g) => {
        const code = `${g.item || ''}${g.subItem || ''}`.replace(/\s+/g, '');
        map.set(String(g.oid), code); paid.add(normCode(code));
      });
    } catch (e) { /* fallback below */ }
    if (!paid.size) ['114', '115', '116', '117', '118', '119', '120', '121'].forEach((c) => paid.add(c));
    groundsCache = { map, paid };
    return groundsCache;
  }
  const normCode = (c) => String(c || '').toLowerCase().replace(/\s+/g, '').replace(/[-–—]/g, '.').replace(/\.+/g, '.').replace(/^\.|\.$/g, '');
  function isPaidCode(code, grounds) {
    const n = normCode(code);
    if (grounds.paid.has(n)) return true;
    return /^1(1[4-9]|2[01])(\.|$)/.test(n);
  }
  function parseVacationDoc(html, grounds) {
    const s = String(html || '');
    const one = (cls) => { const m = new RegExp('class="' + cls + '"[^>]*>([\\s\\S]*?)<').exec(s); return m ? m[1].replace(/&nbsp;/g, ' ').trim() : ''; };
    const many = (cls) => { const out = []; const re = new RegExp('class="' + cls + '-(\\d+)"[^>]*>([\\s\\S]*?)<', 'g'); let m; while ((m = re.exec(s))) out[+m[1]] = m[2].replace(/&nbsp;/g, ' ').trim(); return out; };
    const nums = (arr) => arr.reduce((a, v) => a + (num(v) || 0), 0);
    const ysA = many('work_year_begin_date'), yeA = many('work_year_end_date');
    const mainA = many('work_leave_day_main'), addA = many('work_leave_day_additional');
    const basis = many('legal_basis').filter(Boolean).map((o) => grounds.map.get(String(o)) || String(o));
    const parts = [];
    const n = Math.max(ysA.length, yeA.length, mainA.length, addA.length);
    for (let i = 0; i < n; i++) {
      if (ysA[i] == null && mainA[i] == null && addA[i] == null) continue;
      parts.push({ ys: toDMY(ysA[i] || ''), ye: toDMY(yeA[i] || ''), main: num(mainA[i]) || 0, add: num(addA[i]) || 0 });
    }
    return {
      orderNo: one('order_no'), orderDate: toDMY(one('order_date')),
      begin: toDMY(one('work_leave_begin_date')), end: toDMY(one('work_leave_end_date')), back: toDMY(one('work_begin_date')),
      parts, daysMain: nums(mainA), daysAdd: nums(addA), basis,
      paid: basis.length ? basis.some((b) => isPaidCode(b, grounds)) : null,
      parsed: !!(one('work_leave_begin_date') || parts.length),
    };
  }
  let vacCache = null;
  async function vacationOrders(progress) {
    if (vacCache) return vacCache;
    const meta = await reportMeta('embasHRApplicationsAll');
    const list = await fetchAll('embasHRApplicationsAll', {}, (n) => progress && progress(`məzuniyyət əmrləri: ${n}…`));
    const grounds = await leaveGrounds();
    const out = [];
    let i = 0;
    for (const r of list) {
      i++;
      const statusText = meta.dict[r.doc_status] || r.doc_status || '';
      const o = { raw: r, pin: String(r.user_pin || '').trim(), name: normName(r.main_fullname), docNo: r.doc_no, docDate: toDMY(r.doc_date), status: statusText,
        signed: /vacationOrderStatus\.4$/.test(String(r.doc_status)) || /imzalanm/i.test(statusText) };
      if (o.signed && r.doc_oid) {
        progress && progress(`əmr sənədləri oxunur: ${i}/${list.length}…`);
        try {
          const att = await api.call('eroom.getAttachListByType', { docOid: [r.doc_oid], attachType: 'attachType_5' });
          const f = ((att && att.attachList) || []).find((x) => x.fileId);
          if (f) {
            const file = await api.url('/request/readFromStorage', { fileId: f.fileId });
            Object.assign(o, parseVacationDoc(file && file.fileContent, grounds));
          } else o.error = 'əmrin faylı tapılmadı';
        } catch (e) { o.error = e.message; }
        await sleep(150);
      }
      out.push(o);
    }
    vacCache = out;
    return out;
  }
  async function buildVacAll(progress) {
    const orders = await vacationOrders(progress);
    const header = ['№', 'Sənədin nömrəsi', 'Sənədin tarixi', 'FİN', 'Ad, soyad, ata adı', 'Statusu', 'Əmr №', 'Əmr tarixi',
      'Məzuniyyətin başlanması', 'Məzuniyyətin bitməsi', 'İşə çıxma', 'Əsas gün', 'Əlavə gün', 'Cəmi gün', 'İş ili (baş.)', 'İş ili (bit.)', 'Hüquqi əsas', 'Ödənişli əmək məzuniyyəti', 'Qeyd'];
    const rows = orders.map((o, i) => [i + 1, o.docNo, o.docDate, o.pin, o.name, o.status, o.orderNo || '', o.orderDate || '', o.begin || '', o.end || '', o.back || '',
      o.parsed ? o.daysMain : '', o.parsed ? o.daysAdd : '', o.parsed ? o.daysMain + o.daysAdd : '',
      (o.parts || []).map((p) => p.ys).filter(Boolean).join('; '), (o.parts || []).map((p) => p.ye).filter(Boolean).join('; '),
      (o.basis || []).join(', '), o.paid == null ? '' : o.paid ? 'Bəli' : 'Xeyr', o.error || (o.signed ? '' : 'İmzalanmayıb — günlər sayılmır')]);
    return { title: 'Bütün məzuniyyət əmrləri', header, rows, note: orders.length ? '' : 'Portalda məzuniyyət əmri yoxdur.' };
  }
  async function buildVacByType(progress) {
    const meta = await reportMeta('embasHRApplicationsEmployee');
    const inp = meta.inputs.lt1 || {};
    const types = (inp.dataValues || []).length ? inp.dataValues : [1, 2, 3, 4, 5, 6].map((id) => ({ id: String(id), text: 'Növ ' + id }));
    let header = null; const rows = [];
    for (const t of types) {
      const data = await fetchAll('embasHRApplicationsEmployee', { lt1: { value: String(t.id), type: (inp.extended && inp.extended.valueType) || 'string' } }, (n) => progress(`${t.text}: ${n}…`));
      const tb = await tableFrom(meta, data, '', [{ label: 'Əmrin növü', get: () => t.text }]);
      header = header || tb.header;
      tb.rows.forEach((r) => rows.push(r));
    }
    rows.forEach((r, i) => (r[0] = i + 1));
    return { title: 'Məzuniyyət əmrləri', header: header || ['№'], rows };
  }

  // =====================================================================================
  // Leave balance ("Məzuniyyətdən qalan işçilər")
  // =====================================================================================
  async function computeLeave(progress, opt) {
    opt = opt || { mode: 'all' };
    const today = todayUTC();
    progress('Əmək müqavilələri oxunur…');
    const versions = await contractVersions(progress);
    const valid = versions.filter((r) => r._src === 'valid' && !/qüvvəyə minəcək/i.test(String(r.contract_status)));
    progress('ƏMAS məzuniyyət normaları oxunur…');
    let norms = new Map();
    try {
      const nv = await fetchAll('empVacation', {});
      nv.forEach((r) => norms.set(String(r.pin).trim(), { main: num(r.vac_main_dur), add: num(r['Əlavə məzuniyyət günü']), total: num(r.vac_gen_dur), begin: toDMY(r.con_begin_date) }));
    } catch (e) { norms = new Map(); }
    progress('Məzuniyyət əmrləri oxunur…');
    let orders = [];
    let ordersError = '';
    try { orders = await vacationOrders(progress); } catch (e) { ordersError = e.message; }
    let recalls = [];
    try { recalls = await fetchAll('workLeaveRecallAll', {}); } catch (e) { /* optional */ }

    const chains = new Map();
    versions.forEach((r) => { const c = chainOf(r.doc_no); if (!chains.has(c)) chains.set(c, []); chains.get(c).push(r); });

    const people = [];
    for (const cur of valid) {
      const pin = String(cur.identification_number || '').trim();
      const chain = sortVersions(chains.get(chainOf(cur.doc_no)) || [cur]);
      // salary timeline (collapse equal consecutive)
      const timeline = [];
      let prevEff = null;
      chain.forEach((v) => {
        const s = num(v.monthly_salary);
        const reg = toDMY(v.doc_date);
        let eff = parseD(v.begin_date);
        // old notifications repeat the original start date — then the change date is the registration date
        if (!eff || (prevEff && eff <= prevEff)) eff = parseD(reg) || eff;
        prevEff = eff || prevEff;
        if (s == null) return;
        if (!timeline.length || timeline[timeline.length - 1].salary !== s) timeline.push({ salary: s, date: fmtD(eff), reg, docNo: v.doc_no, position: v.work_position_text || '' });
      });
      const first = timeline[0], last = timeline[timeline.length - 1];
      const anchor = parseD(cur.main_contract_begin_date) || parseD(chain[0] && chain[0].begin_date) || parseD(cur.begin_date);
      const nrm = norms.get(pin) || {};
      const vg = num(cur.vac_gen_dur);
      const vga = num(cur.vac_add_gen_dur);
      const norm = nrm.total || vg || ((nrm.main || 0) + (nrm.add || 0)) || 21;
      const normMain = nrm.main != null ? nrm.main : (vg != null && vga != null ? vg - vga : null);
      const normAdd = nrm.add != null ? nrm.add : (vga != null ? vga : (normMain != null ? norm - normMain : null));
      // work years
      const years = [];
      if (anchor) {
        for (let k = 0; k < 80; k++) {
          const ys = addYears(anchor, k);
          if (ys > today) break;
          const ye = addDays(addYears(anchor, k + 1), -1);
          const complete = ye < today;
          const span = daysIncl(ys, ye);
          const worked = complete ? span : daysIncl(ys, today);
          const earned = complete ? norm : r2(norm * worked / span);
          years.push({ k: k + 1, ys, ye, complete, worked, earned, used: 0, orders: [] });
        }
      }
      // period filter: which work years are counted
      let from = null;
      if (/^y\d+$/.test(opt.mode) && years.length) { const nY = +opt.mode.slice(1); from = years[Math.max(0, years.length - nY)].ys; }
      if (opt.mode === 'date' && opt.date) from = parseD(opt.date);
      years.forEach((y) => (y.counted = !from || y.ye >= from));
      // vacation usage
      const myOrders = orders.filter((o) => o.pin === pin && o.signed);
      const unmatched = [];
      myOrders.forEach((o) => {
        const counted = o.paid !== false; // unknown basis -> counted, flagged
        if (!counted) return;
        const parts = (o.parts && o.parts.length) ? o.parts : [{ ys: '', ye: '', main: o.daysMain || 0, add: o.daysAdd || 0 }];
        parts.forEach((p) => {
          const days = (p.main || 0) + (p.add || 0);
          if (!days) return;
          let y = null;
          const pys = parseD(p.ys);
          if (pys) y = years.find((Y) => Math.abs(Y.ys - pys) <= 3 * DAY) || years.find((Y) => pys >= Y.ys && pys <= Y.ye);
          if (!y) { const b = parseD(o.begin); if (b) y = years.find((Y) => b >= Y.ys && b <= Y.ye); }
          if (y) { y.used += days; y.orders.push(`${o.orderNo || o.docNo} (${o.begin || '?'}–${o.end || '?'}, ${days} gün)`); }
          else unmatched.push({ o, days });
        });
      });
      const unmatchedDays = unmatched.reduce((a, u) => a + u.days, 0);
      years.forEach((y) => (y.remain = r2(y.earned - y.used)));
      const cy = years.filter((y) => y.counted);
      const totEarned = r2(cy.reduce((a, y) => a + y.earned, 0));
      const totUsed = r2(cy.reduce((a, y) => a + y.used, 0) + unmatchedDays);
      const balance = r2(totEarned - totUsed);
      const unusedYears = cy.filter((y) => y.remain > 0.004);
      const lastLeave = myOrders.map((o) => parseD(o.begin)).filter(Boolean).sort((a, b) => b - a)[0] || null;
      const hasRecall = recalls.some((r) => String(r.pin || '').trim() === pin);
      people.push({
        pin, name: normName(cur.full_name), position: cur.work_position_text || '', workplace: cur.workplace_type || '', mode: cur.work_mode_type || '',
        contractType: cur.end_date ? 'Müddətli' : 'Müddətsiz', endDate: toDMY(cur.end_date),
        anchor, serviceText: anchor ? serviceText(anchor, today) : '', norm, normMain, normAdd, years, totEarned, totUsed, balance, unusedYears, unmatchedDays,
        orderCount: myOrders.length, lastLeave, hasRecall,
        timeline, firstSalary: first ? first.salary : null, firstDate: first ? first.date : '', curSalary: num(cur.monthly_salary), curDate: last ? last.date : toDMY(cur.begin_date),
        changeCount: Math.max(0, timeline.length - 1),
        status: !myOrders.length ? 'Heç istifadə etməyib' : balance > 0.004 ? 'Qismən istifadə edib' : 'Tam istifadə edib',
        docNo: cur.doc_no,
      });
    }
    people.sort((a, b) => b.balance - a.balance || a.name.localeCompare(b.name, 'az'));
    return { people, today, opt, ordersError, orderTotal: orders.length, signedTotal: orders.filter((o) => o.signed).length };
  }

  function periodText(o) {
    o = o || {};
    if (/^y\d+$/.test(o.mode || '')) return 'son ' + o.mode.slice(1) + ' iş ili';
    if (o.mode === 'date') return (o.date || '') + ' tarixindən sonrakı iş illəri';
    return 'bütün staj (işə başladığı gündən)';
  }
  function leaveSheets(res, org) {
    const { people, today } = res;
    const stamp = `${org ? org + ' · ' : ''}${fmtD(today)} tarixinə · dövr: ${periodText(res.opt)}`;
    const sum = [['№', 'FİN', 'Soyad, ad, ata adı', 'Vəzifə', 'İş yeri', 'İşə başlama (əsas müqavilə)', 'Staj (bu işəgötürəndə)', 'İllik norma (gün)', 'o cümlədən əsas', 'o cümlədən əlavə',
      'İş ili sayı (hesaba alınan)', 'Hüquq qazanılıb (gün)', 'İstifadə edilib (gün)', 'Qalıq (gün)', 'Vəziyyət', 'İstifadə edilməmiş iş illəri', 'Son məzuniyyət', 'Məzuniyyət əmri sayı',
      'İlk maaş', 'İlk maaş tarixi', 'Cari maaş', 'Cari maaşın tarixi', 'Maaş dəyişikliyi sayı', 'Fərq (AZN)', 'Fərq (%)', 'Maaş tarixçəsi', 'Qeyd']];
    people.forEach((p, i) => {
      const diff = p.firstSalary != null && p.curSalary != null ? r2(p.curSalary - p.firstSalary) : '';
      const pct = p.firstSalary ? r2((p.curSalary - p.firstSalary) / p.firstSalary * 100) : '';
      const notes = [];
      if (p.hasRecall) notes.push('Məzuniyyətdən geri çağırılma əmri var — günləri yoxlayın');
      if (p.unmatchedDays) notes.push(`${p.unmatchedDays} gün iş ilinə bağlanmadı`);
      if (p.contractType === 'Müddətli' && p.endDate && parseD(p.endDate) < today) notes.push(`Müddətli müqavilənin bitmə tarixi (${p.endDate}) keçib`);
      sum.push([i + 1, p.pin, p.name, p.position, p.workplace, fmtD(p.anchor), p.serviceText, p.norm, p.normMain == null ? '' : p.normMain, p.normAdd == null ? '' : p.normAdd,
        p.years.filter((y) => y.counted).length, { v: p.totEarned, s: 'n2' }, { v: p.totUsed, s: 'n2' }, { v: p.balance, s: 'bn2' }, p.status,
        p.unusedYears.map((y) => `${y.ys.getUTCFullYear()}-${y.ye.getUTCFullYear()}${y.complete ? '' : ' (cari)'}: ${y.remain} gün`).join('; '),
        fmtD(p.lastLeave), p.orderCount, p.firstSalary == null ? '' : p.firstSalary, p.firstDate, p.curSalary == null ? '' : p.curSalary, p.curDate, p.changeCount,
        diff, pct, p.timeline.map((t) => `${t.salary} (${t.date})`).join(' → '), notes.join('; ')]);
    });
    const tot = people.reduce((a, p) => ({ e: a.e + p.totEarned, u: a.u + p.totUsed, b: a.b + p.balance }), { e: 0, u: 0, b: 0 });
    sum.push(['', '', 'CƏMİ', '', '', '', '', '', '', '', '', { v: r2(tot.e), s: 'bn2' }, { v: r2(tot.u), s: 'bn2' }, { v: r2(tot.b), s: 'bn2' }]);

    const yrs = [['№', 'FİN', 'Soyad, ad, ata adı', 'Vəzifə', 'İş ili', 'İş ilinin başlanması', 'İş ilinin bitməsi', 'Tamamlanıb?', 'İşlənmiş gün', 'Norma (gün)', 'Qazanılıb (gün)', 'İstifadə edilib (gün)', 'Qalıq (gün)', 'Hesaba alınır?', 'Məzuniyyət əmrləri']];
    let n = 0;
    people.forEach((p) => p.years.forEach((y) => {
      yrs.push([++n, p.pin, p.name, p.position, `${y.k}-ci iş ili (${y.ys.getUTCFullYear()}/${y.ye.getUTCFullYear()})`, fmtD(y.ys), fmtD(y.ye), y.complete ? 'Bəli' : 'Xeyr (cari il)',
        y.worked, p.norm, { v: y.earned, s: 'n2' }, y.used, { v: y.remain, s: 'bn2' }, y.counted ? 'Bəli' : 'Xeyr (seçilmiş dövrdən əvvəl)', y.orders.join('; ')]);
    }));

    const sal = [['№', 'FİN', 'Soyad, ad, ata adı', 'Tarix (qüvvəyə minmə)', 'ƏMAS-da qeydiyyat', 'Maaş (AZN)', 'Əvvəlki maaş', 'Dəyişiklik (AZN)', 'Dəyişiklik (%)', 'Vəzifə', 'Sənəd №']];
    n = 0;
    people.forEach((p) => p.timeline.forEach((t, i) => {
      const prev = i ? p.timeline[i - 1].salary : null;
      sal.push([++n, p.pin, p.name, t.date, t.reg, t.salary, prev == null ? '' : prev, prev == null ? '' : r2(t.salary - prev), prev ? r2((t.salary - prev) / prev * 100) : '', t.position, t.docNo]);
    }));

    const notes = [['Necə hesablanır'],
      ['İş ili işçinin əsas əmək müqaviləsinin başlama tarixindən (ƏMAS: "Əsas müqavilənin başlama tarixi") 12 aylıq dövrlərlə sayılır.'],
      ['İllik norma — ƏMAS-ın "Məzuniyyət günləri" hesabatındakı cəmi gün (əsas + əlavə); orada yoxdursa, müqavilədəki məzuniyyət günü; o da yoxdursa 21 gün.'],
      ['Tamamlanmış iş ili üçün hüquq = illik norma. Cari (yarımçıq) iş ili üçün: norma × işlənmiş gün / iş ilinin günləri (təxmini).'],
      ['İstifadə — portalda İMZALANMIŞ məzuniyyət əmrlərinin sənədindən (əsas + əlavə günlər, iş ili) götürülür; hüquqi əsası əmək məzuniyyəti olmayan əmrlər (məs. ödənişsiz) çıxılmır.'],
      ['Maaş tarixçəsi — işçinin hazırkı müqaviləsinin bütün versiyalarından (ilkin müqavilə və bütün dəyişikliklər), qüvvəyə minmə tarixi ilə.'],
      ['Diqqət: ƏMAS-da yalnız ELEKTRON məzuniyyət əmrləri görünür. Kağız əmrlə verilmiş köhnə məzuniyyətlər burada yoxdur — buna görə panelde «Hesablama dövrü» seçimi var.'],
      ['Seçilmiş hesablama dövrü: ' + periodText(res.opt)],
      ['Bu hesabat məlumat xarakterlidir; qərar verməzdən əvvəl əmrləri və müqavilələri yoxlayın.'],
      [''],
      ['Məzuniyyət əmrləri (portalda): ' + res.orderTotal + ', imzalanmış: ' + res.signedTotal + (res.ordersError ? ' — XƏTA: ' + res.ordersError : '')]];
    const T = (t) => [{ v: t, s: 'b' }];
    return [
      { name: 'Xülasə', rows: [T(`Məzuniyyətdən qalan işçilər — ${stamp}`), [], ...sum], headerRow: 2, merges: ['A1:H1'], widths: { 0: 6 }, filterLastRow: sum.length + 1 },
      { name: 'İş illəri üzrə', rows: [T(`İş illəri üzrə məzuniyyət — ${stamp}`), [], ...yrs], headerRow: 2, merges: ['A1:H1'], widths: { 0: 6 } },
      { name: 'Maaş tarixçəsi', rows: [T(`Maaş tarixçəsi — ${stamp}`), [], ...sal], headerRow: 2, merges: ['A1:H1'], widths: { 0: 6 } },
      { name: 'Qaydalar', rows: notes.map((r, i) => (i === 0 ? [{ v: r[0], s: 'b' }] : r)), headerRow: 0, autoFilter: false, widths: { 0: 140 } },
    ];
  }

  // =====================================================================================
  // Excel helpers
  // =====================================================================================
  function sheetFrom(t, org, today) {
    const title = `${t.title}${org ? ' — ' + org : ''} (${fmtD(today)})`;
    const rows = [[{ v: title, s: 'b' }], [t.note || `${t.rows.length} sətir`], t.header, ...t.rows];
    return { name: t.sheetName || t.title, rows, headerRow: 2, merges: ['A1:H1', 'A2:H2'], widths: t.header[0] === '№' ? { 0: 6 } : undefined };
  }
  function safeName(s, used) {
    let n = String(s).replace(/[\\/?*[\]:]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 31) || 'Vərəq';
    let base = n, i = 2;
    while (used.has(n.toLowerCase())) n = base.slice(0, 28) + ' ' + i++;
    used.add(n.toLowerCase());
    return n;
  }
  function download(sheets, file) {
    const used = new Set();
    sheets.forEach((s) => (s.name = safeName(s.name, used)));
    window.AMMO_XLSX.download(sheets, file);
  }
  const fileStamp = () => { const d = todayUTC(); return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`; };
  const shortName = (name) => ({
    'Əmək müqaviləsinə dəyişiklik': 'Dəyişikliklər', 'Qüvvədən düşən əmək müqavilələri': 'Qüvvədən düşən', 'Vətəndaşa təsdiq üçün göndərilən əmək müqavilələri': 'Vətəndaşa təsdiqə',
    'İcrada olan əmək müqavilələri': 'İcrada olan müqavilələr', 'Müddəti bitən qüvvədə olan müddətli əmək müqavilələri': 'Müddəti bitən müddətli', 'Qüvvədə olan əmək müqavilələri': 'Qüvvədə olan',
    'Ləğv edilmiş əmək müqavilələri': 'Ləğv edilmiş', 'İmzaya göndərilən əmək müqavilələri': 'İmzaya göndərilən', 'İşçinin Köhnə Əmək Müqavilələri': 'Köhnə müqavilələr',
    'Etibarlı xitam əmrləri': 'Etibarlı xitam əmrləri', 'Bütün məzuniyyət əmrləri': 'Bütün məzuniyyət əmrləri', 'Məzuniyyət əmrləri': 'Məzuniyyət əmrləri',
    'Bütün ezamiyyə əmrləri': 'Bütün ezamiyyə əmrləri', 'Məzuniyyət günləri (ƏMAS statistikası)': 'Məzuniyyət günləri',
    'Bütün məzuniyyətdən geri çağırılma əmrləri': 'Geri çağırılma', 'Bütün digər əmrlər': 'Digər əmrlər', 'İcra gözləyən xitam əmrləri': 'İcra gözləyən xitam',
  }[name] || name);

  // =====================================================================================
  // UI (shadow DOM, AMMO "Xəzər" theme)
  // =====================================================================================
  const CSS = `
  :host{all:initial}
  *{box-sizing:border-box}
  .wrap{--sea:#0d3a42;--sea2:#145561;--nar:#c3324a;--brass:#d9a93a;--paper:#f3f6f5;--card:#fff;--ink:#17262c;--mute:#5d6e74;--line:#d5dfdd;--ok:#1f7a55;--okbg:#e5f4ec;--bad:#a3263a;--badbg:#fbe9ec;--warn:#8a5a00;--warnbg:#fdf3dc;
    font-family:"Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;color:var(--ink);font-size:14px;line-height:1.45}
  .disp{font-family:Bahnschrift,"DIN Alternate","Segoe UI Variable Display","Segoe UI",system-ui,sans-serif}
  .fab{position:fixed;right:0;top:58vh;z-index:2147483000;display:flex;flex-direction:column;align-items:center;gap:8px;padding:12px 8px 14px 10px;border:none;cursor:pointer;
    background:var(--sea);color:#fff;border-radius:16px 0 0 16px;box-shadow:-6px 8px 24px rgba(8,42,48,.28);transform:translateX(6px);transition:transform .18s,background .18s}
  .fab:hover,.fab:focus-visible{transform:none;background:var(--sea2)}.fab:focus-visible{outline:3px solid var(--brass);outline-offset:2px}
  .fab::before{content:"";position:absolute;left:0;top:14px;bottom:14px;width:3px;border-radius:3px;background:var(--nar)}
  .fab .w{writing-mode:vertical-rl;transform:rotate(180deg);font-size:12.5px;font-weight:700;letter-spacing:2.5px}
  .fab .m{width:28px;height:28px;border-radius:8px;background:#fff;color:var(--sea);display:grid;place-items:center;font-weight:800;font-size:15px}
  .fab.hide{transform:translateX(110%)}
  .ov{position:fixed;inset:0;z-index:2147483001;background:rgba(8,42,48,.38);display:none;justify-content:flex-end}
  .ov.open{display:flex}
  .dr{width:min(1180px,97vw);height:100vh;display:flex;flex-direction:column;background:var(--paper);box-shadow:-24px 0 60px rgba(8,42,48,.35);animation:sl .26s cubic-bezier(.2,.8,.2,1)}
  @keyframes sl{from{transform:translateX(40px);opacity:.4}to{transform:none;opacity:1}}
  .hd{display:flex;align-items:center;gap:14px;padding:14px 20px;background:var(--sea);color:#fff}
  .hd .m{width:36px;height:36px;border-radius:10px;background:#fff;color:var(--sea);display:grid;place-items:center;font-weight:800;font-size:18px;position:relative}
  .hd .m::after{content:"";position:absolute;right:-3px;top:-3px;width:10px;height:10px;border-radius:50%;background:var(--nar);border:2px solid var(--sea)}
  .hd h2{margin:0;font-size:18px;font-weight:700;letter-spacing:.3px}.hd small{display:block;opacity:.75;font-size:12px}
  .hd .sp{flex:1}.x{background:transparent;border:1px solid rgba(255,255,255,.35);color:#fff;border-radius:10px;width:36px;height:36px;font-size:20px;cursor:pointer}
  .x:hover{background:rgba(255,255,255,.12)}
  .tabs{display:flex;gap:4px;padding:10px 20px 0;background:var(--sea)}
  .tabs button{border:none;background:transparent;color:#cfe3e1;padding:10px 16px;border-radius:10px 10px 0 0;cursor:pointer;font-weight:700;font-size:13.5px;letter-spacing:.2px}
  .tabs button.on{background:var(--paper);color:var(--sea)}
  .bd{flex:1;overflow:auto;padding:18px 20px 30px}
  .card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin-bottom:14px}
  .row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .btn{border:1px solid var(--line);background:#fff;color:var(--ink);padding:9px 14px;border-radius:10px;font-weight:600;cursor:pointer;font-size:13.5px}
  .btn:hover{border-color:var(--sea2)}.btn:disabled{opacity:.5;cursor:default}
  .btn.p{background:var(--sea);border-color:var(--sea);color:#fff}.btn.p:hover{background:var(--sea2)}
  .btn.a{background:var(--nar);border-color:var(--nar);color:#fff}
  .btn.s{padding:6px 10px;font-size:12.5px}
  .grp{margin:4px 0 14px}.grp h4{margin:0 0 8px;font-size:12px;text-transform:uppercase;letter-spacing:1.2px;color:var(--mute)}
  .reg{display:grid;grid-template-columns:28px 1fr auto auto;gap:10px;align-items:center;padding:9px 10px;border:1px solid var(--line);border-radius:10px;background:#fff;margin-bottom:6px}
  .reg .nm{font-weight:600}.reg .nt{font-size:12px;color:var(--mute)}
  .st{font-size:12.5px;color:var(--mute);min-width:150px;text-align:right}
  .st.ok{color:var(--ok)}.st.bad{color:var(--bad)}.st.run{color:var(--sea2)}
  input[type=checkbox]{width:17px;height:17px;accent-color:var(--sea)}
  .kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px}
  .kpi{background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 14px}
  .kpi b{display:block;font-size:24px;font-family:Bahnschrift,"Segoe UI",sans-serif;color:var(--sea)}
  .kpi span{font-size:12px;color:var(--mute)}
  .kpi.n b{color:var(--nar)}
  .flt{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px}
  .flt input[type=search]{flex:1;min-width:200px;border:1px solid var(--line);border-radius:10px;padding:9px 12px;font:inherit}
  .seg{display:inline-flex;border:1px solid var(--line);border-radius:10px;overflow:hidden;background:#fff}
  .seg button{border:none;background:none;padding:8px 12px;cursor:pointer;font-weight:600;font-size:12.5px;color:var(--mute)}
  .seg button.on{background:var(--sea);color:#fff}
  .emp{background:#fff;border:1px solid var(--line);border-radius:14px;margin-bottom:10px;overflow:hidden}
  .eh{display:grid;grid-template-columns:1.6fr 1fr .8fr .8fr .9fr 24px;gap:10px;align-items:center;padding:12px 14px;cursor:pointer}
  .eh:hover{background:#f8fbfa}
  .eh .nm{font-weight:700}.eh .sub{font-size:12px;color:var(--mute)}
  .big{font-family:Bahnschrift,"Segoe UI",sans-serif;font-size:20px;font-weight:700}
  .big.pos{color:var(--nar)}.big.zero{color:var(--ok)}
  .pill{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11.5px;font-weight:700}
  .pill.never{background:var(--badbg);color:var(--bad)}.pill.part{background:var(--warnbg);color:var(--warn)}.pill.full{background:var(--okbg);color:var(--ok)}
  .eb{display:none;border-top:1px dashed var(--line);padding:12px 14px;background:#fbfdfc}
  .emp.open .eb{display:block}.emp.open .chev{transform:rotate(90deg)}
  .chev{transition:transform .15s;color:var(--mute)}
  .yrs{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:6px;margin:8px 0 12px}
  .yr{border:1px solid var(--line);border-radius:10px;padding:6px 9px;font-size:12px;background:#fff}
  .yr.off{opacity:.55;background:#f4f6f6}.yr.off b{color:var(--mute)}
  .sel{border:1px solid var(--line);border-radius:10px;padding:8px 10px;font:inherit;font-size:13px;background:#fff;color:var(--ink)}
  .yr b{display:block;font-size:14px}
  .yr.rem{border-color:#e7b3bd;background:#fff5f7}.yr.rem b{color:var(--nar)}
  .yr.done b{color:var(--ok)}.yr.cur{border-style:dashed}
  .tl{display:flex;align-items:center;flex-wrap:wrap;gap:6px;font-size:12.5px}
  .tl .s{background:#eef4f3;border-radius:8px;padding:4px 8px}.tl .s b{font-size:13.5px}
  .tl .ar{color:var(--mute)}.tl .up{color:var(--ok);font-weight:700}.tl .dn{color:var(--bad);font-weight:700}
  .muted{color:var(--mute);font-size:12.5px}
  .msg{padding:10px 12px;border-radius:10px;background:#e6f1f4;color:#134c63;font-size:13px;margin-bottom:12px}
  .msg.bad{background:var(--badbg);color:var(--bad)}
  .prog{height:4px;background:#e3ebe9;border-radius:4px;overflow:hidden;margin-top:8px}.prog i{display:block;height:100%;background:var(--nar);width:30%;animation:pg 1.1s ease-in-out infinite}
  @keyframes pg{0%{transform:translateX(-100%)}100%{transform:translateX(350%)}}
  table.mini{border-collapse:collapse;width:100%;font-size:12.5px;margin-top:6px}
  table.mini th,table.mini td{border-bottom:1px solid #e8eeec;padding:5px 6px;text-align:left}
  table.mini th{color:var(--mute);font-weight:600}
  @media (max-width:760px){.kpis{grid-template-columns:repeat(2,1fr)}.eh{grid-template-columns:1fr 1fr}.reg{grid-template-columns:28px 1fr}.st{text-align:left}}
  `;

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    kids.flat().forEach((c) => c != null && el.append(c.nodeType ? c : document.createTextNode(String(c))));
    return el;
  }

  const host = h('div', { id: 'ammo-emas-root' });
  const root = host.attachShadow({ mode: 'open' });
  root.append(h('style', {}, CSS));
  const wrap = h('div', { class: 'wrap' });
  root.append(wrap);
  document.documentElement.append(host);

  let ctx = { org: '', voen: '' };
  const fab = h('button', { class: 'fab', title: 'AMMO — ƏMAS reyestrləri və məzuniyyət qalığı', 'aria-label': 'AMMO ƏMAS panelini aç', onclick: () => open() },
    h('span', { class: 'm disp' }, 'A'), h('span', { class: 'w disp' }, 'AMMO ƏMAS'));
  const body = h('div', { class: 'bd' });
  const tabBtns = {};
  const tabs = h('div', { class: 'tabs', role: 'tablist' });
  [['reg', 'Reyestrlər → Excel'], ['leave', 'Məzuniyyətdən qalan işçilər']].forEach(([id, label]) => {
    tabBtns[id] = h('button', { class: 'disp', role: 'tab', onclick: () => show(id) }, label);
    tabs.append(tabBtns[id]);
  });
  const subtitle = h('small', {}, 'eroom.e-social.gov.az · yalnız oxuyur, heç nə göndərmir');
  const overlay = h('div', { class: 'ov', onclick: (e) => { if (e.target === overlay) close(); } },
    h('div', { class: 'dr', role: 'dialog', 'aria-label': 'AMMO ƏMAS' },
      h('div', { class: 'hd' }, h('div', { class: 'm disp' }, 'A'), h('div', {}, h('h2', { class: 'disp' }, 'AMMO · ƏMAS köməkçisi'), subtitle), h('div', { class: 'sp' }),
        h('button', { class: 'x', title: 'Bağla', 'aria-label': 'Bağla', onclick: () => close() }, '×')),
      tabs, body));
  wrap.append(fab, overlay);
  if (/ammo-staff/.test(location.hash)) setTimeout(() => open(), 1200);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && overlay.classList.contains('open')) close(); });

  const views = {};
  let current = 'reg';
  function open() {
    overlay.classList.add('open'); fab.classList.add('hide');
    api.ctx().then((c) => { ctx = c || ctx; if (ctx.org) subtitle.textContent = `${ctx.org}${ctx.voen ? ' · VÖEN ' + ctx.voen : ''} · yalnız oxuyur`; }).catch(() => {});
    show(current);
  }
  function close() { overlay.classList.remove('open'); fab.classList.remove('hide'); fab.focus({ preventScroll: true }); }
  function show(id) {
    current = id;
    Object.entries(tabBtns).forEach(([k, b]) => { b.classList.toggle('on', k === id); b.setAttribute('aria-selected', k === id); });
    body.replaceChildren(views[id] || (views[id] = id === 'reg' ? regView() : leaveView()));
  }

  // ---------------------------------------------------------------- Registries view
  function regView() {
    const el = h('div');
    const state = new Map(); // id -> {chk, st, result}
    const info = h('div', { class: 'msg' }, 'Lazım olan reyestrləri seçin və «Hamısını doldur → Excel» düyməsini basın. AMMO hər reyestrin bütün səhifələrini portalın özündən çəkir və hamısını bir Excel faylında ayrı-ayrı vərəqlərdə yazır. Hər reyestri tək-tək də yükləyə bilərsiniz.');
    const runAll = h('button', { class: 'btn a disp', onclick: () => doAll() }, '⤓ Hamısını doldur → Excel');
    const selAll = h('button', { class: 'btn s', onclick: () => setAll(true) }, 'Hamısını seç');
    const selNone = h('button', { class: 'btn s', onclick: () => setAll(false) }, 'Heç birini');
    const prog = h('div', { class: 'prog', style: 'display:none' }, h('i'));
    // v1.22: qüvvədə olan işçiləri (ad, FİN, vəzifə, maaş) AMMO «İlkin audit» panelinə ötür
    const staffSt = h('span', { class: 'st' }, '');
    const staffBtn = h('button', { class: 'btn p disp', title: 'Qüvvədə olan əmək müqavilələri → AMMO İlkin audit (işçilər və vəzifələr)', onclick: () => sendStaff() }, '👥 İşçiləri İlkin audit-ə göndər');
    async function sendStaff() {
      if (staffBtn.disabled) return;
      staffBtn.disabled = true; staffSt.textContent = 'yüklənir…';
      try {
        const c = await api.ctx().catch(() => ctx); if (c) ctx = c;
        const rows = await fetchAll('emasValidEmploymentContractOnline', {}, (n) => { staffSt.textContent = `${n} müqavilə…`; });
        const byPin = new Map();
        rows.forEach((r) => {
          const pin = String(r.identification_number || r.pin || '').trim();
          const k = pin || normName(r.full_name);
          const prev = byPin.get(k);
          if (!prev || (num(r.doc_date) || 0) > (num(prev.doc_date) || 0)) byPin.set(k, r);
        });
        const list = [...byPin.values()].map((r) => ({
          name: normName(r.full_name), pin: String(r.identification_number || r.pin || '').trim(), position: r.work_position_text || '',
          salary: num(r.monthly_salary), begin: toDMY(r.main_contract_begin_date || r.begin_date), end: toDMY(r.end_date), workplace: r.workplace_type || '', mode: r.work_mode_type || '',
        })).sort((a, b) => a.name.localeCompare(b.name, 'az'));
        const key = 'ammo_emas_staff_' + (String(ctx.voen || '').replace(/\D/g, '') || 'x');
        await chrome.storage.local.set({ [key]: { at: Date.now(), org: ctx.org || '', voen: ctx.voen || '', list }, ammo_emas_staff_last: { at: Date.now(), org: ctx.org || '', voen: ctx.voen || '', list } });
        staffSt.textContent = `✓ ${list.length} işçi göndərildi`;
      } catch (e) { staffSt.textContent = 'xəta: ' + (e && e.message ? e.message : e); }
      finally { staffBtn.disabled = false; }
    }
    if (/ammo-staff/.test(location.hash)) setTimeout(() => sendStaff(), 1500);
    const top = h('div', { class: 'card' }, info, h('div', { class: 'row' }, runAll, selAll, selNone, staffBtn, staffSt), prog);
    el.append(top);
    REGISTRIES.forEach((g) => {
      const box = h('div', { class: 'grp' }, h('h4', {}, g.group));
      g.items.forEach((it) => {
        const chk = h('input', { type: 'checkbox', 'aria-label': it.name });
        chk.checked = !g.optional;
        const st = h('span', { class: 'st' }, '');
        const one = h('button', { class: 'btn s', title: 'Yalnız bu reyestri Excel-ə yaz', onclick: () => doOne(it) }, 'Excel');
        state.set(it.id, { chk, st, it });
        box.append(h('label', { class: 'reg' }, chk, h('span', {}, h('span', { class: 'nm' }, it.name), it.note ? h('div', { class: 'nt' }, it.note) : null), st, one));
      });
      el.append(box);
    });
    function setAll(v) { state.forEach((s) => (s.chk.checked = v)); }
    function setSt(s, text, cls) { s.st.textContent = text; s.st.className = 'st ' + (cls || ''); }
    let busy = false;
    async function run(items) {
      const results = [];
      for (const it of items) {
        const s = state.get(it.id);
        setSt(s, 'yüklənir…', 'run');
        try {
          const t = await buildRegistry(it, (m) => setSt(s, m, 'run'));
          t.title = it.name; t.sheetName = shortName(it.name);
          results.push(t);
          setSt(s, `✓ ${t.rows.length} sətir`, 'ok');
        } catch (e) {
          results.push({ title: it.name, sheetName: shortName(it.name), header: ['Xəta'], rows: [[e.message]], note: 'Bu reyestr yüklənmədi' });
          setSt(s, '✗ ' + e.message, 'bad');
        }
      }
      return results;
    }
    async function doOne(it) {
      if (busy) return; busy = true; prog.style.display = '';
      try {
        const [t] = await run([it]);
        download([sheetFrom(t, ctx.org, todayUTC())], `ƏMAS_${shortName(it.name).replace(/\s+/g, '_')}_${fileStamp()}.xlsx`);
      } finally { busy = false; prog.style.display = 'none'; }
    }
    async function doAll() {
      if (busy) return;
      const items = [...state.values()].filter((s) => s.chk.checked).map((s) => s.it);
      if (!items.length) { info.textContent = 'Heç bir reyestr seçilməyib.'; return; }
      busy = true; runAll.disabled = true; prog.style.display = ''; info.className = 'msg';
      info.textContent = `${items.length} reyestr yüklənir… Pəncərəni bağlamayın.`;
      try {
        const res = await run(items);
        const today = todayUTC();
        const index = [['ƏMAS reyestrləri' + (ctx.org ? ' — ' + ctx.org : '') + ` (${fmtD(today)})`], [], ['№', 'Reyestr', 'Sətir sayı', 'Vərəq', 'Qeyd']];
        res.forEach((t, i) => index.push([i + 1, t.title, t.header[0] === 'Xəta' ? 0 : t.rows.length, shortName(t.title), t.header[0] === 'Xəta' ? 'XƏTA: ' + t.rows[0][0] : (t.note || '')]));
        download([{ name: 'Mündəricat', rows: index, headerRow: 2, merges: ['A1:E1'], widths: { 0: 6, 1: 52, 4: 60 } }, ...res.map((t) => sheetFrom(t, ctx.org, today))], `ƏMAS_reyestrlər_${fileStamp()}.xlsx`);
        const bad = res.filter((t) => t.header[0] === 'Xəta').length;
        info.textContent = `Hazırdır: ${res.length} reyestr, ${res.reduce((a, t) => a + (t.header[0] === 'Xəta' ? 0 : t.rows.length), 0)} sətir Excel-ə yazıldı.` + (bad ? ` ${bad} reyestr yüklənmədi (səbəb Excel-in «Mündəricat» vərəqində).` : '');
        if (bad) info.className = 'msg bad';
      } catch (e) { info.className = 'msg bad'; info.textContent = e.message; }
      finally { busy = false; runAll.disabled = false; prog.style.display = 'none'; }
    }
    return el;
  }

  // ---------------------------------------------------------------- Leave view
  function leaveView() {
    const el = h('div');
    let res = null, filter = 'rem', q = '';
    const info = h('div', { class: 'msg' }, '«Doldur» düyməsini basın: AMMO qüvvədə olan müqavilələri, bütün dəyişiklikləri (maaş tarixçəsi), ƏMAS məzuniyyət normalarını və imzalanmış məzuniyyət əmrlərinin içini oxuyub hər işçi üçün iş illəri üzrə qalan günləri hesablayır.');
    const go = h('button', { class: 'btn a disp', onclick: () => run() }, '↻ Doldur');
    const per = h('select', { class: 'sel', 'aria-label': 'Hesablama dövrü' },
      ...[['all', 'Bütün staj (işə başladığı gündən)'], ['y1', 'Yalnız cari iş ili'], ['y2', 'Son 2 iş ili'], ['y3', 'Son 3 iş ili'], ['y5', 'Son 5 iş ili'], ['date', 'Bu tarixdən…']]
        .map(([v, l]) => h('option', { value: v }, l)));
    const perDate = h('input', { type: 'date', class: 'sel', style: 'display:none', 'aria-label': 'Başlanğıc tarixi' });
    const saveOpt = () => { try { chrome.storage.local.set({ ammoEmasLeaveOpt: { mode: per.value, date: perDate.value } }); } catch (e) { /* ignore */ } };
    per.addEventListener('change', () => { perDate.style.display = per.value === 'date' ? '' : 'none'; saveOpt(); if (res) run(); });
    perDate.addEventListener('change', () => { saveOpt(); if (res && perDate.value) run(); });
    try { chrome.storage.local.get('ammoEmasLeaveOpt', (o) => { const v = o && o.ammoEmasLeaveOpt; if (v) { per.value = v.mode || 'all'; perDate.value = v.date || ''; perDate.style.display = per.value === 'date' ? '' : 'none'; } }); } catch (e) { /* ignore */ }
    const optNow = () => ({ mode: per.value, date: perDate.value ? perDate.value.split('-').reverse().join('.') : '' });
    const xl = h('button', { class: 'btn p disp', disabled: true, onclick: () => res && download(leaveSheets(res, ctx.org), `Məzuniyyət_qalığı_${fileStamp()}.xlsx`) }, '⤓ Excel');
    const prog = h('div', { class: 'prog', style: 'display:none' }, h('i'));
    const kpis = h('div', { class: 'kpis', style: 'display:none' });
    const search = h('input', { type: 'search', placeholder: 'Ad, FİN və ya vəzifə üzrə axtar…', oninput: (e) => { q = e.target.value.toLowerCase(); draw(); } });
    const seg = h('div', { class: 'seg' });
    [['rem', 'Qalığı olanlar'], ['never', 'Heç istifadə etməyənlər'], ['sal', 'Maaşı dəyişənlər'], ['all', 'Hamısı']].forEach(([k, l]) => {
      const b = h('button', { onclick: () => { filter = k; [...seg.children].forEach((x) => x.classList.toggle('on', x === b)); draw(); } }, l);
      if (k === filter) b.classList.add('on');
      seg.append(b);
    });
    const flt = h('div', { class: 'flt', style: 'display:none' }, search, seg);
    const list = h('div');
    const warn = h('div', { class: 'muted', style: 'margin-top:10px' }, 'ƏMAS-da yalnız elektron məzuniyyət əmrləri var. Kağız əmrlə verilmiş köhnə məzuniyyətlər görünmür — köhnə illər lazım deyilsə, «Hesablama dövrü»ndən son illəri seçin.');
    el.append(h('div', { class: 'card' }, info, h('div', { class: 'row' }, go, xl, h('span', { class: 'muted' }, 'Hesablama dövrü:'), per, perDate), warn, prog), kpis, flt, list);

    async function run() {
      go.disabled = true; xl.disabled = true; prog.style.display = ''; info.className = 'msg';
      vacCache = null;
      try {
        res = await computeLeave((m) => (info.textContent = m), optNow());
        const p = res.people;
        const totBal = r2(p.reduce((a, x) => a + Math.max(0, x.balance), 0));
        kpis.replaceChildren(
          h('div', { class: 'kpi' }, h('b', {}, p.length), h('span', {}, 'işçi (qüvvədə olan müqavilə)')),
          h('div', { class: 'kpi n' }, h('b', {}, totBal.toLocaleString('az-AZ')), h('span', {}, 'cəmi qalan məzuniyyət günü')),
          h('div', { class: 'kpi n' }, h('b', {}, p.filter((x) => x.status === 'Heç istifadə etməyib').length), h('span', {}, 'heç məzuniyyətə çıxmayıb')),
          h('div', { class: 'kpi' }, h('b', {}, p.filter((x) => x.changeCount > 0).length), h('span', {}, 'maaşı dəyişib')));
        kpis.style.display = ''; flt.style.display = '';
        info.textContent = `Hesablandı (${fmtD(res.today)} tarixinə, dövr: ${periodText(res.opt)}). Portalda ${res.orderTotal} məzuniyyət əmri var, ${res.signedTotal} imzalanmış əmr hesaba alındı.` + (res.ordersError ? ' Məzuniyyət əmrləri oxunmadı: ' + res.ordersError : '');
        if (res.ordersError) info.className = 'msg bad';
        xl.disabled = false;
        draw();
      } catch (e) { info.className = 'msg bad'; info.textContent = e.message; }
      finally { go.disabled = false; prog.style.display = 'none'; }
    }

    function draw() {
      if (!res) return;
      let p = res.people;
      if (filter === 'rem') p = p.filter((x) => x.balance > 0.004);
      if (filter === 'never') p = p.filter((x) => x.status === 'Heç istifadə etməyib');
      if (filter === 'sal') p = p.filter((x) => x.changeCount > 0);
      if (q) p = p.filter((x) => (x.name + ' ' + x.pin + ' ' + x.position).toLowerCase().includes(q));
      list.replaceChildren(...(p.length ? p.map(card) : [h('div', { class: 'muted' }, 'Bu filtrə uyğun işçi yoxdur.')]));
    }

    function card(p) {
      const pillCls = p.status === 'Heç istifadə etməyib' ? 'never' : p.status === 'Tam istifadə edib' ? 'full' : 'part';
      const diff = p.firstSalary != null && p.curSalary != null ? r2(p.curSalary - p.firstSalary) : null;
      const box = h('div', { class: 'emp' });
      const head = h('div', { class: 'eh', role: 'button', tabindex: '0', 'aria-expanded': 'false' },
        h('div', {}, h('div', { class: 'nm' }, p.name), h('div', { class: 'sub' }, `${p.pin} · ${p.position}${p.workplace ? ' · ' + p.workplace : ''}`)),
        h('div', {}, h('div', { class: 'sub' }, 'İşə başlama · staj'), h('div', {}, `${fmtD(p.anchor)} · ${p.serviceText}`)),
        h('div', {}, h('div', { class: 'sub' }, 'Norma / istifadə'), h('div', {}, `${p.norm} gün/il · ${p.totUsed} gün`)),
        h('div', {}, h('div', { class: 'sub' }, 'Qalıq'), h('div', { class: 'big ' + (p.balance > 0.004 ? 'pos' : 'zero') }, `${p.balance} gün`)),
        h('div', {}, h('span', { class: 'pill ' + pillCls }, p.status), h('div', { class: 'sub' }, p.curSalary != null ? `Maaş: ${p.curSalary} AZN${diff ? ` (${diff > 0 ? '+' : ''}${diff})` : ''}` : '')),
        h('span', { class: 'chev' }, '▸'));
      const toggle = () => { box.classList.toggle('open'); head.setAttribute('aria-expanded', box.classList.contains('open')); };
      head.addEventListener('click', toggle);
      head.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
      const yrs = h('div', { class: 'yrs' }, ...p.years.map((y) => h('div', { class: 'yr ' + (!y.counted ? 'off' : y.remain > 0.004 ? 'rem' : 'done') + (y.complete ? '' : ' cur'), title: y.orders.join('\n') || 'Bu iş ilində məzuniyyət əmri yoxdur' },
        h('div', { class: 'muted' }, `${y.k}-ci il · ${y.ys.getUTCFullYear()}/${y.ye.getUTCFullYear()}${y.complete ? '' : ' (cari)'}`),
        h('b', {}, !y.counted ? 'hesaba alınmır' : y.remain > 0.004 ? `${y.remain} gün qalıb` : 'tam istifadə'),
        h('div', { class: 'muted' }, `${fmtD(y.ys)} – ${fmtD(y.ye)} · hüquq ${y.earned}, istifadə ${y.used}`))));
      const tl = h('div', { class: 'tl' });
      p.timeline.forEach((t, i) => {
        if (i) { const prev = p.timeline[i - 1].salary; const d = r2(t.salary - prev); tl.append(h('span', { class: 'ar' }, '→'), h('span', { class: d >= 0 ? 'up' : 'dn' }, `${d > 0 ? '+' : ''}${d}`), h('span', { class: 'ar' }, '→')); }
        tl.append(h('span', { class: 's' }, h('b', {}, `${t.salary} AZN`), ` · ${t.date}`));
      });
      const notes = [];
      if (p.hasRecall) notes.push('Məzuniyyətdən geri çağırılma əmri var — həmin günləri əl ilə yoxlayın.');
      if (p.unmatchedDays) notes.push(`${p.unmatchedDays} gün heç bir iş ilinə bağlanmadı (cəmi istifadəyə daxildir).`);
      if (p.contractType === 'Müddətli' && p.endDate) notes.push(parseD(p.endDate) < res.today ? `Diqqət: müddətli müqavilənin bitmə tarixi (${p.endDate}) keçib, ƏMAS-da isə hələ «qüvvədədir».` : `Müddətli müqavilə, bitmə tarixi: ${p.endDate}.`);
      box.append(head, h('div', { class: 'eb' },
        h('div', { class: 'muted' }, `İllik norma: ${p.norm} gün${p.normMain != null ? ` (əsas ${p.normMain} + əlavə ${p.normAdd})` : ''} · ${p.years.filter((y) => y.counted).length}/${p.years.length} iş ili hesaba alınıb · hüquq ${p.totEarned} gün · istifadə ${p.totUsed} gün · məzuniyyət əmri: ${p.orderCount}${p.lastLeave ? ' · son məzuniyyət: ' + fmtD(p.lastLeave) : ''}`),
        yrs,
        h('div', { class: 'muted', style: 'margin-bottom:4px' }, `Maaş tarixçəsi (${p.changeCount} dəyişiklik):`), tl,
        notes.length ? h('div', { class: 'muted', style: 'margin-top:10px' }, notes.join(' ')) : null));
      return box;
    }
    return el;
  }
})();
