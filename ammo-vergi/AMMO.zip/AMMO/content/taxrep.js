/* AMMO — Vergi hesabatları: seçilmiş il üçün Mənfəət / Gəlir vergisi bəyannaməsini portal məlumatından avtomatik yığır.
 *   gəlirlər   ← satış e-qaimələri (mal → 200.1.2 topdan, xidmət → 200.2, icarə → 203.2), alıcı qaytarmaları çıxılır
 *   xərclər    ← alış e-qaimələri (sətir adına görə xərc maddələri), alış aktları, muzdlu iş bəyannamələri (əmək haqqı, DSMF)
 *   malın dəyəri ← əvvəlki ilin bəyannaməsindəki mal qalığı + alışlar − ilin sonuna qalıq (Əlavə 1, 1.3.2)
 *   Əlavə 1    ← əvvəlki ilin «hesabat dövrünün sonuna» sütunu bu ilin «əvvəlinə» sütununa köçürülür
 *   240 / 1244 ← keçmiş illərin istifadə olunmamış zərəri (VM 121: hüquqi şəxs 5 il, fərdi sahibkar 3 il)
 *   238 / 1242 ← mikro sahibkar güzəşti 75% (VM 106.1.20 / 102.1.30), şərtlər yoxlanılır
 * Portala heç nə yazılmır — yalnız oxunur. */
(function (root) {
  'use strict';

  const n0 = (v) => { const x = Number(v); return v === null || v === undefined || v === '' || !isFinite(x) ? 0 : x; };
  const r2 = (v) => Math.round(n0(v) * 100) / 100;
  const low = (s) => String(s || '').toLocaleLowerCase('az');
  const RENT_RE = /icar[əe]|kiray[əe]|arenda/;

  // portal bəyannamə JSON-unda göstəricini (indicator) harada olursa olsun tap
  function findInd(ti, ind) {
    let hit = null;
    const walk = (o, d) => {
      if (hit || !o || typeof o !== 'object' || d > 6) return;
      if (Array.isArray(o)) { o.forEach((x) => walk(x, d + 1)); return; }
      if (o.indicator === ind) { hit = o; return; }
      Object.values(o).forEach((x) => walk(x, d + 1));
    };
    walk(ti, 0);
    return hit;
  }
  const amountOf = (e) => {
    if (!e) return 0;
    if (e.amount !== undefined) return n0(e.amount);
    const k = Object.keys(e).find((x) => x !== 'rowOrder' && x !== 'indicator' && typeof e[x] === 'number');
    return k ? n0(e[k]) : 0;
  };
  function findStr(obj, re) {
    let out = '';
    const walk = (o, d) => {
      if (out || !o || typeof o !== 'object' || d > 5) return;
      for (const [k, v] of Object.entries(o)) {
        if (out) return;
        if ((typeof v === 'string' || typeof v === 'number') && re.test(k) && String(v).trim()) { out = String(v).trim(); return; }
        if (v && typeof v === 'object') walk(v, d + 1);
      }
    };
    walk(obj, 0);
    return out;
  }

  // Mikro / kiçik / orta / iri — Nazirlər Kabinetinin meyarları (illik gəlir üzrə)
  function criterionOf(income, employees) {
    if (income <= 200000 && employees <= 10) return { id: 1, label: 'Mikro' };
    if (income <= 3000000 && employees <= 50) return { id: 2, label: 'Kiçik' };
    if (income <= 30000000 && employees <= 250) return { id: 3, label: 'Orta' };
    return { id: 4, label: 'İri' };
  }

  // ------------------------------------------------------------------ saf hissə: audit nəticəsi + əvvəlki illər → bəyannamə dəyərləri
  function prefill(type, year, audit, prev) {
    const T = root.AMMO_TAXREP_FORMS;
    const form = T.getForm(type);
    const v = T.emptyValues(form);
    const P = type === 'profit';
    const put = (sid, code, val, col = 0) => { if (v[sid] && v[sid][code]) v[sid][code][col] = r2(n0(v[sid][code][col]) + n0(val)); };
    const notes = [];

    // ---- gəlirlər (satış qaimələrinin sətirləri)
    let goods = 0, services = 0, rent = 0, unknown = 0;
    (audit.lines && audit.lines.income || []).forEach((l) => {
      const name = low(l[4]), kind = l[5], cost = n0(l[6]);
      if (RENT_RE.test(name)) rent += cost;
      else if (kind === 'Mal') goods += cost;
      else if (kind === 'Xidmət') services += cost;
      else unknown += cost;
    });
    if (!audit.lines || !audit.lines.income || !audit.lines.income.length) { goods = n0(audit.income.goods); services = n0(audit.income.services); unknown = n0(audit.income.unknown); }
    const returns = n0(audit.income.returns);
    const goodsNet = Math.max(goods + unknown - returns, 0);
    put('incomes', P ? '200.1.2' : '1200.1.2', goodsNet);
    put('incomes', P ? '200.2' : '1200.2', services);
    put('incomes', P ? '203.2' : '1203.2.1', rent);
    if (unknown) notes.push(`Növü (mal/xidmət) bilinməyən ${r2(unknown)} ₼ satış malların topdan satışına aid edildi — lazım olsa düzəldin.`);
    if (returns) notes.push(`Alıcıların qaytardığı ${r2(returns)} ₼ mal satışından çıxıldı.`);
    if (n0(audit.income.advances)) notes.push(`Avans qaimələri (${r2(audit.income.advances)} ₼) gəlirə daxil edilmədi — mal/xidmət təqdim edildikdə gəlir sayılır.`);

    // ---- xərclər
    const E = Object.fromEntries((audit.expenses || []).map((e) => [e.code, n0(e.amount)]));
    const map = P
      ? { '221.1': '221.1.2', '221.2': '221.2', '221.7': '221.7', '221.8': '221.8', '221.9': '221.9', '221.10': '221.10', '221.11': '221.11', '221.12': '221.12', '221.13': '221.13', '221.14': '221.14', '221.15': '221.15', '228': '228.4', '229': '229.1', '230.2': '230.2' }
      : { '221.1': '1226.1.2', '221.2': '1226.2', '221.7': '1226.7', '221.8': '1226.8', '221.9': '1226.9', '221.10': '1226.10', '221.11': '1226.11', '221.12': '1226.12', '221.13': '1226.13', '221.14': '1226.14', '221.15': '1226.15', '228': '1232.4', '229': '1233.1', '230.2': '1234' };
    Object.entries(map).forEach(([a, b]) => put('expenses', b, E[a]));
    // icarə: VÖEN-in son rəqəmi 1 — hüquqi şəxs, 2 — fiziki şəxs
    let rentL = 0, rentF = 0;
    (audit.lines && audit.lines.expense || []).forEach((l) => { if (l[5] === '221.5') { if (/2$/.test(String(l[2]))) rentF += n0(l[7]); else rentL += n0(l[7]); } });
    if (!rentL && !rentF) rentL = n0(E['221.5']);
    put('expenses', P ? '221.5.1.1' : '1226.5.1.1', rentL);
    put('expenses', P ? '221.5.1.2' : '1226.5.1.2', rentF);

    // ---- mallar: malın dəyəri = əvvəlinə qalıq + alış − sonuna qalıq
    const goodsRow = '1.3.2';
    const opening = prev && prev.balances ? n0((prev.balances.assets[goodsRow] || [])[5]) : 0;
    const purchases = n0(E['221.4']);
    const closing = opening; // standart fərziyyə: qalıq dəyişməyib; istifadəçi səhifədə dəyişə bilər
    const cogs = Math.max(opening + purchases - closing, 0);
    put('expenses', P ? '221.4' : '1226.4', cogs);

    // ---- Əlavə 1: əvvəlki ilin sonu → bu ilin əvvəli
    if (prev && prev.balances) {
      ['assets', 'capital'].forEach((sid) => {
        const sec = form.sections.find((s) => s.id === sid);
        sec.rows.forEach((r) => { const pe = prev.balances[sid][r.code]; if (pe) v[sid][r.code][0] = r2(pe[5]); });
      });
      notes.push(`Əlavə 1-də «Hesabat dövrünün əvvəlinə» sütunu ${year - 1}-ci ilin bəyannaməsinin «sonuna» sütunundan götürüldü.`);
    }
    v.assets[goodsRow][1] = r2(purchases);
    v.assets[goodsRow][2] = r2(cogs);

    // ---- işçi sayı, meyar, güzəşt
    const avgEmp = n0(audit.payroll && audit.payroll.avgEmployees);
    const totalIncome = goodsNet + services + rent;
    const crit = criterionOf(totalIncome, Math.ceil(avgEmp));
    const needEmp = P ? 3 : 1;
    const microOk = crit.id === 1 && avgEmp >= needEmp;
    const rules = { year, relief: microOk, losses: prev && prev.losses ? prev.losses : [] };
    T.applyRules(form, v, rules);

    return {
      form, values: v, rules, notes,
      goods: { opening: r2(opening), purchases: r2(purchases), closing: r2(closing) },
      meta: { avgEmployees: avgEmp, maxEmployees: n0(audit.payroll && audit.payroll.employees), criterion: crit.id, criterionLabel: crit.label, microOk, needEmp },
    };
  }

  // ------------------------------------------------------------------ əvvəlki illərin bəyannamələri
  async function previousYears(type, year, step) {
    const API = root.AMMO_API, D = root.AMMO_DICT, A = root.AMMO_AUDIT, T = root.AMMO_TAXREP_FORMS;
    const form = T.getForm(type);
    const typeDef = D.DECL_TYPES.find((t) => t.id === type);
    const window = type === 'profit' ? 5 : 3; // VM 121.1 / 121.2
    const years = [];
    for (let y = year - window; y <= year; y++) years.push(y);
    step('Əvvəlki illərin bəyannamələri axtarılır...');
    const lists = await Promise.all(years.map((y) => API.declarations(y).catch(() => [])));
    const all = lists.flat().map((e) => (e && e.declaration) || e).filter(Boolean);
    const mine = A.latestPerPeriod(all.filter((d) => typeDef.match(d) && (d.reportingPeriod || {}).type !== 'MONTH' && (d.reportingPeriod || {}).type !== 'QUARTER'));
    const byYear = new Map(mine.map((d) => [Number((d.reportingPeriod || {}).year), d]));
    const out = { balances: null, losses: [], filed: null, activity: { code: '', name: '' }, read: [] };
    const lossInd = type === 'profit' ? ['_3002', '_3003'] : ['_1304', '_1305'];
    const queue = []; // [{year, amount}]
    for (const y of years) {
      const d = byYear.get(y);
      if (!d) continue;
      step(`${y}-ci il bəyannaməsi oxunur...`);
      const base = await API.declarationBase(d.id || d.registrationNumber).catch(() => null);
      const ti = base && base.taxInformation;
      if (!ti) continue;
      out.read.push({ year: y, reg: d.registrationNumber || d.id, type: d.declarationType });
      if (!out.activity.code) {
        out.activity.code = findStr(base, /activit.*code|faaliyy.*kod|okved|activityCode/i);
        out.activity.name = findStr(base, /activit.*name|faaliyy.*ad/i);
      }
      if (y === year) { out.filed = { reg: d.registrationNumber || d.id, status: d.declarationStatus, values: valuesFromBase(form, ti) }; continue; }
      // zərər: əvvəl həmin il istifadə olunanı köhnə zərərlərdən sil, sonra həmin ilin zərərini əlavə et
      let used = amountOf(findInd(ti, lossInd[1]));
      while (used > 0 && queue.length) { const q = queue[0]; const t = Math.min(q.amount, used); q.amount -= t; used -= t; if (q.amount <= 0.004) queue.shift(); }
      const loss = amountOf(findInd(ti, lossInd[0]));
      if (loss > 0) queue.push({ year: y, amount: r2(loss) });
      if (y === year - 1) out.balances = balancesFromBase(form, ti);
    }
    out.losses = queue.filter((q) => q.year >= year - window && q.amount > 0).map((q) => ({ year: q.year, amount: r2(q.amount) }));
    return out;
  }

  const BAL_KEYS = ['periodStart', 'obtained', 'presented', 'removed', 'cancelled', 'periodEnd'];
  function balancesFromBase(form, ti) {
    const out = { assets: {}, capital: {} };
    ['assets', 'capital'].forEach((sid) => {
      const sec = form.sections.find((s) => s.id === sid);
      // eyni göstərici iki bölmədə ola bilər (məs. _4051) — bölmənin öz siyahısını üstün tut
      const list = sec.path ? sec.path.split('.').reduce((o, k) => (o ? o[k] : undefined), ti) : null;
      sec.rows.forEach((r) => {
        if (!r.ind) return;
        const e = (Array.isArray(list) ? list.find((x) => x && x.indicator === r.ind) : null) || findInd(ti, r.ind);
        if (e) out[sid][r.code] = BAL_KEYS.map((k) => n0(e[k]));
      });
    });
    return out;
  }
  function valuesFromBase(form, ti) {
    const out = {};
    form.sections.forEach((s) => {
      out[s.id] = {};
      const list = s.path ? s.path.split('.').reduce((o, k) => (o ? o[k] : undefined), ti) : null;
      s.rows.forEach((r) => {
        if (!r.ind) return;
        const e = (Array.isArray(list) ? list.find((x) => x && x.indicator === r.ind) : null) || findInd(ti, r.ind);
        if (!e) return;
        out[s.id][r.code] = s.balance ? BAL_KEYS.map((k) => n0(e[k])) : [amountOf(e)];
      });
    });
    return out;
  }

  // ------------------------------------------------------------------ əsas: il seç → bəyannamə
  async function build(type, year, step) {
    const T = root.AMMO_TAXREP_FORMS, A = root.AMMO_AUDIT;
    year = Number(year);
    const fromISO = `${year}-01-01`;
    const now = new Date();
    const toISO = year === now.getFullYear() ? `${year}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}` : `${year}-12-31`;
    const audit = await A.run({ fromISO, toISO, fullYear: false }, step);
    const prev = await previousYears(type, year, step).catch((e) => { console.warn('[AMMO taxrep] prev', e); return null; });
    step('Bəyannamə xanaları doldurulur...');
    const pf = prefill(type, year, audit, prev);
    let tin = '';
    try { tin = root.AMMO_EVEZ_PORTAL ? root.AMMO_EVEZ_PORTAL.ownTin() : ''; } catch (e) { /* */ }
    const filed = prev && prev.filed;
    return {
      kind: 'taxrep', type, year, created: Date.now(),
      meta: {
        ...pf.meta, year, tin, name: audit.self || '', method: 'accrual',
        activityCode: (prev && prev.activity.code) || '', activityName: (prev && prev.activity.name) || '',
        period: { fromISO, toISO },
      },
      values: pf.values, rules: pf.rules, goods: pf.goods, notes: pf.notes,
      prevRead: (prev && prev.read) || [], filed: filed || null,
      counts: audit.counts, payroll: audit.payroll,
      income: audit.income, expenseLines: (audit.lines && audit.lines.expense) || [], incomeLines: (audit.lines && audit.lines.income) || [],
      checks: T.checks(pf.form, pf.values, { year, microOk: pf.meta.microOk }),
    };
  }

  root.AMMO_TAXREP = { build, prefill, previousYears, criterionOf, findInd, valuesFromBase, amountOf };
})(typeof globalThis !== 'undefined' ? globalThis : this);
