/* AMMO — Sosial şəbəkə analizi: Telegram Web (web.telegram.org /k/ və /a/) oxuyucu (v1.23). Yalnız OXUYUR. */
(function () {
  'use strict';
  if (window.top !== window) return;
  // v1.23.1: genişlənmə yeniləndikdən sonra açıq tabda skript yenidən yeridilir — yalnız SON yeridilən nüsxə cavab verir
  const TOK = Math.random().toString(36).slice(2);
  window.__AMMO_TG_TOK = TOK;
  const live = () => window.__AMMO_TG_TOK === TOK;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const T = (el) => (el ? (el.innerText || el.textContent || '').trim() : '');
  const isA = () => /\/a\//.test(location.pathname);
  function chats() {
    if (isA()) return [...document.querySelectorAll('.chat-list .ListItem.Chat, .chat-list .chat-item-clickable')].map((el) => {
      const a = el.querySelector('a[href^="#"]') || el;
      return { el, peer: (a.getAttribute('href') || '').replace('#', ''), chat: T(el.querySelector('.fullName, h3, .title')), preview: T(el.querySelector('.last-message, .subtitle')), mine: !!el.querySelector('.MessageOutgoingStatus, .icon-message-read, .icon-message-succeeded'), unread: parseInt(T(el.querySelector('.ChatBadge:not(.muted), .Badge.unread')), 10) || 0, voice: /voice|səsli|голосов/i.test(T(el.querySelector('.last-message'))) };
    });
    return [...document.querySelectorAll('.chatlist-chat')].map((el) => ({ el, peer: el.getAttribute('data-peer-id') || (el.getAttribute('href') || '').replace('#', ''), chat: T(el.querySelector('.peer-title')), preview: T(el.querySelector('.dialog-subtitle, .row-subtitle')), mine: !!el.querySelector('.message-status, .tgico-check, .tgico-checks, .icon-check, .icon-checks'), unread: parseInt(T(el.querySelector('.badge-unread, .dialog-subtitle-badge-unread')), 10) || 0, voice: !!el.querySelector('.tgico-microphone, .icon-microphone') }));
  }
  async function readOpen(limit) {
    await sleep(1200);
    const out = [];
    if (isA()) {
      [...document.querySelectorAll('.messages-container .Message')].slice(-limit).forEach((m) => out.push({ dir: m.classList.contains('own') ? 'out' : 'in', text: T(m.querySelector('.text-content')), kind: m.querySelector('.Audio.voice, .voice-message, .Audio .voice') ? 'voice' : m.querySelector('.File, .document') ? 'file' : 'text', at: (m.querySelector('.message-time') || {}).title || '', from: T(m.querySelector('.message-title, .sender-title')) }));
    } else {
      [...document.querySelectorAll('.bubbles-inner .bubble')].filter((b) => /is-in|is-out/.test(b.className)).slice(-limit).forEach((b) => out.push({ dir: b.classList.contains('is-out') ? 'out' : 'in', text: T(b.querySelector('.message .translatable-message, .message')).replace(/\s*\d{1,2}:\d{2}\s*$/, ''), kind: b.querySelector('.audio.is-voice, audio-element[voice], .is-voice') ? 'voice' : b.querySelector('.document-container, .document') ? 'file' : 'text', at: (b.querySelector('.time .inner, .time') || {}).title || '', from: T(b.querySelector('.peer-title, .name')) }));
    }
    return out.map((m) => ({ ...m, at: m.at && isFinite(Date.parse(m.at)) ? new Date(Date.parse(m.at)).toISOString() : '' }));
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!live()) return false;
    if (!msg || sender.id !== chrome.runtime.id) return false;
    if (msg.type === 'AMMO_SOC_PING') { sendResponse({ ok: true, href: location.href }); return false; }
    if (msg.type === 'AMMO_SOC_SCAN') {
      (async () => {
        const o = msg.opts || {};
        for (let i = 0; i < 25 && !chats().length; i++) await sleep(1000);
        const list = chats().filter((c) => c.chat).slice(0, o.maxChats || 60);
        if (!list.length) return { ok: false, error: 'Telegram Web-ə daxil olun (QR və ya telefon nömrəsi ilə)' };
        const threads = list.map((c) => ({ source: 'tg', chat: c.chat, ref: { peer: c.peer, chat: c.chat }, unread: c.unread, lastDir: c.mine ? 'out' : 'in', preview: c.preview, previewKind: c.voice ? 'voice' : 'text', link: c.peer ? `https://web.telegram.org/${isA() ? 'a' : 'k'}/#${c.peer}` : '', messages: [] }));
        if (o.detail !== false) {
          const todo = threads.filter((t) => t.lastDir === 'in' && t.ref.peer).slice(0, o.maxDetail || 20);
          let n = 0;
          for (const t of todo) { n++; location.hash = '#' + t.ref.peer; try { t.messages = await readOpen(o.perChat || 15); } catch (e) { /* */ } try { chrome.runtime.sendMessage({ type: 'AMMO_SOC_PROGRESS', source: 'tg', text: `Telegram: ${n}/${todo.length} söhbət oxundu` }); } catch (e) { /* */ } }
        }
        return { ok: true, source: 'tg', account: '', threads };
      })().then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
      return true;
    }
    if (msg.type === 'AMMO_SOC_OPEN') { if (msg.ref && msg.ref.peer) location.hash = '#' + msg.ref.peer; sendResponse({ ok: true }); return false; }
    return false;
  });
})();
