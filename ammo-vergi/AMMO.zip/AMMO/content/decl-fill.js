/* AMMO — e-taxes-də açıq bəyannamənin xanalarını AMMO-nun hazırladığı dəyərlərlə doldurur.
 * Sətirlər səhifədəki kodla («200.1», «1226.4», «1.3.2» …) və ya sətrin adı ilə tapılır, xanalar sütun başlığına görə seçilir.
 * Dəyər portalın öz sahəsinə yazılır və «input/change/blur» hadisələri göndərilir — portal öz hesablamalarını özü aparır.
 * Heç nə təqdim edilmir və imzalanmır: yoxlayıb təsdiqləmək həmişə istifadəçinin işidir. */
(function () {
  'use strict';
  if (window.__AMMO_FILL__) return;
  window.__AMMO_FILL__ = true;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const n0 = (v) => { const x = Number(v); return isFinite(x) ? x : 0; };
  const norm = (s) => String(s || '').toLocaleLowerCase('az').replace(/̇/g, '').replace(/[“”"«»()]/g, '').replace(/\s+/g, ' ').trim();
  const CODE_RE = /^\s*(\d{1,4}(?:[.\-]\d{1,3})*)(?=$|[\s.\-–:)])/;
  const cleanCode = (c) => String(c || '').replace(/\.$/, '');

  // ------------------------------------------------------------------ səhifədəki sətirlər
  const visible = (el) => !!(el && (el.offsetParent !== null || el.getClientRects().length));
  const editableInput = (i) => !i.disabled && !i.readOnly && i.getAttribute('aria-readonly') !== 'true';
  function fieldInputs(root) {
    return [...root.querySelectorAll('input, textarea')].filter((i) => {
      const t = (i.type || 'text').toLowerCase();
      return !['hidden', 'checkbox', 'radio', 'button', 'submit', 'file', 'date', 'search'].includes(t) && visible(i) && !i.closest('#ammo-root, #ammo-fill-root');
    });
  }
  // sətrin «baş» mətni (kod + ad): cədvəldə ilk xanalar, div-sətirdə ilk mətn hissələri
  function headText(row) {
    if (row.tagName === 'TR') {
      const cells = [...row.cells].filter((c) => !c.querySelector('input, textarea'));
      return cells.map((c) => c.innerText || c.textContent || '').join(' ').trim();
    }
    const parts = [];
    const walker = document.createTreeWalker(row, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.parentElement && n.parentElement.closest('input, textarea, button, select') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
    });
    let n, len = 0;
    while ((n = walker.nextNode()) && len < 400) { const t = n.nodeValue.trim(); if (t) { parts.push(t); len += t.length; } }
    return parts.join(' ');
  }
  function rowOf(input) {
    let el = input.parentElement;
    for (let d = 0; el && d < 9; d++, el = el.parentElement) {
      if (el.tagName === 'TR' || el.getAttribute('role') === 'row') return el;
      if (el.tagName === 'TABLE' || el === document.body) return null;
      const t = headText(el);
      if (CODE_RE.test(t) && t.length > 2) return el;
    }
    return null;
  }
  function scanRows() {
    const rows = new Map();
    fieldInputs(document).forEach((i) => {
      const r = rowOf(i);
      if (!r) return;
      if (!rows.has(r)) rows.set(r, []);
      rows.get(r).push(i);
    });
    const out = [];
    rows.forEach((inputs, el) => {
      const t = headText(el);
      const m = CODE_RE.exec(t);
      const code = m ? cleanCode(m[1]) : '';
      const label = norm(m ? t.slice(m[0].length).replace(/^[\s.\-–:]+/, '') : t);
      out.push({ el, inputs, code, label });
    });
    return out;
  }

  // sütun başlığı: cədvəldə th mətnləri, input-un xanası hansı başlığın altındadır
  function columnTitle(input) {
    const td = input.closest('td, th');
    const table = input.closest('table');
    if (!td || !table) return '';
    const tr = td.parentElement;
    let x = 0;
    for (const c of tr.cells) { if (c === td) break; x += c.colSpan || 1; }
    const heads = table.tHead ? [...table.tHead.rows] : [...table.rows].filter((r) => r.querySelector('th') && !r.querySelector('input'));
    for (let i = heads.length - 1; i >= 0; i--) {
      let cx = 0;
      for (const c of heads[i].cells) {
        const span = c.colSpan || 1;
        if (x >= cx && x < cx + span) { const t = norm(c.innerText || c.textContent); if (t) return t; break; }
        cx += span;
      }
    }
    return '';
  }

  // ------------------------------------------------------------------ dəyəri portalın sahəsinə yaz
  let decimalComma = null;
  function detectComma() {
    if (decimalComma !== null) return decimalComma;
    const vals = fieldInputs(document).map((i) => i.value).filter(Boolean);
    decimalComma = vals.some((v) => /^\d[\d\s]*,\d{1,2}$/.test(v.trim())) && !vals.some((v) => /^\d+\.\d{1,2}$/.test(v.trim()));
    return decimalComma;
  }
  const fmt = (v) => { const s = (Math.round(n0(v) * 100) / 100).toString(); return detectComma() ? s.replace('.', ',') : s; };
  const parseShown = (s) => { const t = String(s || '').replace(/[\s ]/g, ''); return n0(/,\d{1,2}$/.test(t) ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, '')); };
  function setValue(input, v) {
    const str = fmt(v);
    const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    input.dispatchEvent(new FocusEvent('focus', { bubbles: false }));
    input.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
    setter.call(input, str);
    input.dispatchEvent(new InputEvent('input', { bubbles: true, data: str, inputType: 'insertText' }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' }));
    input.dispatchEvent(new FocusEvent('blur', { bubbles: false }));
    input.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
    input.style.boxShadow = 'inset 0 0 0 2px #22c55e';
    input.style.transition = 'box-shadow .4s';
    input.title = 'AMMO tərəfindən dolduruldu';
  }

  // ------------------------------------------------------------------ doldurma
  function indexPayload(payload) {
    const byCode = new Map(), byLabel = new Map();
    payload.sections.forEach((s) => s.rows.forEach((r) => {
      const item = { sec: s, row: r };
      if (r.code) { if (!byCode.has(r.code)) byCode.set(r.code, []); byCode.get(r.code).push(item); }
      const lk = norm(r.text).slice(0, 48);
      if (lk.length > 10 && !byLabel.has(lk)) byLabel.set(lk, item);
    }));
    return { byCode, byLabel };
  }
  function pickItem(idx, domRow) {
    let list = domRow.code ? idx.byCode.get(domRow.code) : null;
    if (list && list.length > 1 && domRow.label) {
      const hit = list.find((it) => norm(it.row.text).slice(0, 20) === domRow.label.slice(0, 20));
      if (hit) return hit;
    }
    if (list && list.length) {
      // qısa kodlar (Əlavə 1: «1», «1.1») səhifədə başqa yerdə də ola bilər — adla təsdiqlə
      const it = list[0];
      if (domRow.code.length > 3 || !domRow.label || norm(it.row.text).slice(0, 12) === domRow.label.slice(0, 12) || it.sec.balance === (domRow.inputs.length > 2)) return it;
    }
    if (domRow.label) {
      const lk = domRow.label.slice(0, 48);
      if (idx.byLabel.has(lk)) return idx.byLabel.get(lk);
      for (const [k, it] of idx.byLabel) if (k.length >= 24 && lk.startsWith(k.slice(0, 24))) return it;
    }
    return null;
  }
  // hansı input hansı sütundur
  function mapColumns(item, inputs) {
    const n = item.row.vals.length;
    const headers = item.sec.header.slice(1).map(norm);
    const out = [];
    if (inputs.length === n) { inputs.forEach((inp, k) => out.push([inp, k])); return out; }
    const titled = inputs.map((inp) => [inp, columnTitle(inp)]);
    if (titled.every(([, t]) => t)) {
      titled.forEach(([inp, t]) => {
        const k = headers.findIndex((h) => h && (t.startsWith(h.slice(0, 14)) || h.startsWith(t.slice(0, 14))));
        if (k >= 0) out.push([inp, k]);
      });
      if (out.length) return out;
    }
    const ed = inputs.filter(editableInput);
    if (ed.length === n) { ed.forEach((inp, k) => out.push([inp, k])); return out; }
    if (n === 2 && inputs.length === 1) return [[inputs[0], 0]]; // gəlir: yalnız sahibkarlıq sütunu
    if (item.sec.balance && inputs.length === 2) return [[inputs[0], 0], [inputs[1], 5]]; // yalnız «əvvəlinə» və «sonuna»
    inputs.slice(0, n).forEach((inp, k) => out.push([inp, k]));
    return out;
  }

  const state = { payload: null, idx: null, done: new WeakSet(), until: 0, observer: null, stats: null, lastHref: location.href };
  async function fillOnce(payload, { quiet } = {}) {
    const idx = state.idx;
    const rows = scanRows();
    let filled = 0, skipped = 0;
    const seen = new Set();
    const calcLater = [];
    for (const dr of rows) {
      const it = pickItem(idx, dr);
      if (!it) continue;
      seen.add(it.sec.id + '|' + it.row.code);
      for (const [inp, k] of mapColumns(it, dr.inputs)) {
        const v = it.row.vals[k];
        if (v === undefined) continue;
        if (!editableInput(inp)) { skipped++; continue; }
        const calc = it.row.calc || (it.sec.balance && k === 5);
        if (calc) { calcLater.push([inp, v]); continue; }
        const cur = parseShown(inp.value);
        if (Math.abs(cur - n0(v)) < 0.005 && (inp.value !== '' || !n0(v))) { state.done.add(inp); continue; }
        if (!n0(v) && inp.value === '') { state.done.add(inp); continue; }
        setValue(inp, v); state.done.add(inp); filled++;
        if (filled % 12 === 0) await sleep(30);
      }
    }
    // hesablanan xanalar: portal özü hesablamırsa (redaktə oluna bilirsə və fərqlidirsə) bizim dəyəri yaz
    if (calcLater.length) {
      await sleep(350);
      for (const [inp, v] of calcLater) {
        const cur = parseShown(inp.value);
        if (Math.abs(cur - n0(v)) < 0.005) { skipped++; continue; }
        if (!n0(v) && inp.value === '') continue;
        setValue(inp, v); filled++;
      }
    }
    const missing = [];
    state.payload.sections.forEach((s) => s.rows.forEach((r) => { if (r.vals.some((x) => n0(x)) && !r.calc && !seen.has(s.id + '|' + r.code)) missing.push(r.code); }));
    return { filled, skipped, rows: rows.length, missing };
  }

  function watch() {
    if (state.observer) state.observer.disconnect();
    state.until = Date.now() + 20 * 60 * 1000;
    let tm = null;
    state.observer = new MutationObserver(() => {
      if (Date.now() > state.until) { state.observer.disconnect(); state.observer = null; return; }
      clearTimeout(tm);
      tm = setTimeout(async () => {
        if (!state.payload) return;
        const pending = fieldInputs(document).some((i) => !state.done.has(i) && rowOf(i));
        if (!pending) return;
        const r = await fillOnce(state.payload, { quiet: true });
        if (r.filled) badge(`AMMO: daha ${r.filled} xana dolduruldu`);
      }, 700);
    });
    state.observer.observe(document.body, { childList: true, subtree: true });
  }

  async function fill(payload) {
    try { window.dispatchEvent(new Event('ammo-close-modal')); } catch (e) { /* */ }
    state.payload = payload;
    state.idx = indexPayload(payload);
    decimalComma = null;
    const r = await fillOnce(payload);
    watch();
    badge(r.filled ? `AMMO: ${r.filled} xana dolduruldu ✓` : 'AMMO: bu səhifədə doldurulacaq xana tapılmadı', !r.filled);
    return { ...r, watching: true, url: location.href };
  }

  // ------------------------------------------------------------------ portal üzərində kiçik düymə
  let host = null, shadow = null, btn = null, msg = null;
  const isDeclPage = () => /\/eportal\/declaration\//.test(location.pathname);
  function pageType() {
    const p = location.pathname.toLowerCase();
    if (/profit|menfeet|mənfəət/.test(p)) return 'profit';
    if (/income|gelir|gəlir|fs-?income|individual/.test(p)) return 'income';
    return '';
  }
  const pageYear = () => { const m = location.pathname.match(/\/(20\d\d)(?:\.\d+)?(?:\/|$)/); return m ? Number(m[1]) : 0; };
  function ensureButton() {
    if (!isDeclPage()) { if (host) host.style.display = 'none'; return; }
    if (!host) {
      host = document.createElement('div');
      host.id = 'ammo-fill-root';
      shadow = host.attachShadow({ mode: 'open' });
      shadow.innerHTML = `<style>
        .w{position:fixed;left:18px;bottom:18px;z-index:2147483000;display:flex;flex-direction:column;align-items:flex-start;gap:6px;font:13px "Segoe UI",system-ui,sans-serif}
        button{display:flex;align-items:center;gap:8px;border:none;border-radius:999px;padding:10px 16px 10px 10px;background:#0d3a42;color:#fff;font-weight:700;cursor:pointer;box-shadow:0 6px 20px rgba(13,58,66,.35);font:inherit;font-weight:700}
        button:hover{background:#145561} button:focus-visible{outline:3px solid #d9a93a;outline-offset:2px}
        i{width:24px;height:24px;border-radius:50%;background:#fff;color:#0d3a42;display:grid;place-items:center;font-style:normal;font-weight:800}
        .m{background:#fff;color:#17262c;border:1px solid #d5dfdd;border-radius:10px;padding:8px 12px;max-width:360px;box-shadow:0 6px 20px rgba(0,0,0,.12);display:none}
        .m.on{display:block} .m.bad{border-color:#c3324a;color:#a3263a}
      </style><div class="w"><div class="m" role="status"></div><button type="button" title="AMMO-da hazırlanmış bəyannamə dəyərləri ilə xanaları doldur"><i>A</i><span>AMMO · Doldur</span></button></div>`;
      btn = shadow.querySelector('button');
      msg = shadow.querySelector('.m');
      btn.addEventListener('click', onButton);
      document.documentElement.appendChild(host);
    }
    host.style.display = '';
    const t = pageType();
    btn.querySelector('span').textContent = `AMMO · Doldur${t === 'profit' ? ' (mənfəət)' : t === 'income' ? ' (gəlir)' : ''}${pageYear() ? ' ' + pageYear() : ''}`;
  }
  function badge(text, bad) {
    ensureButton();
    if (!msg) return;
    msg.textContent = text; msg.className = 'm on' + (bad ? ' bad' : '');
    clearTimeout(badge.tm); badge.tm = setTimeout(() => { msg.className = 'm'; }, 7000);
  }
  async function storedPayload() {
    const T = window.AMMO_TAXREP_FORMS;
    const all = await chrome.storage.local.get(null);
    const t = pageType(), y = pageYear();
    const reports = Object.entries(all).filter(([k, v]) => /^ammo_taxrep_(profit|income)_\d{4}$/.test(k) && v && v.values)
      .map(([k, v]) => v).filter((v) => (!t || v.type === t) && (!y || Number(v.year) === y));
    reports.sort((a, b) => (b.updated || b.created || 0) - (a.updated || a.created || 0));
    if (reports.length && T) { const r = reports[0]; return T.fillPayload(T.getForm(r.type), r.values, { year: r.year }); }
    const last = Object.entries(all).filter(([k, v]) => /^ammo_taxrep_fill_/.test(k) && v && v.payload && (!t || v.payload.type === t))
      .sort((a, b) => b[1].at - a[1].at)[0];
    return last ? last[1].payload : null;
  }
  async function onButton() {
    try {
      btn.disabled = true;
      const p = await storedPayload();
      if (!p) { badge(`AMMO-da ${pageYear() || ''} ili üçün ${pageType() === 'income' ? 'Gəlir' : pageType() === 'profit' ? 'Mənfəət' : ''} hesabatı hazırlanmayıb. AMMO → Vergi hesabatları → il seçin → «Doldur».`, true); return; }
      await fill(p);
    } catch (e) { badge('AMMO: ' + (e && e.message ? e.message : e), true); }
    finally { btn.disabled = false; }
  }

  // SPA: səhifə dəyişəndə düyməni yenilə
  setInterval(() => { if (location.href !== state.lastHref) { state.lastHref = location.href; ensureButton(); } }, 800);
  ensureButton();

  chrome.runtime.onMessage.addListener((m, sender, sendResponse) => {
    if (!m || m.type !== 'AMMO_DECL_FILL_DO') return false;
    fill(m.payload).then((result) => sendResponse({ ok: true, result }), (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true;
  });
  window.AMMO_DECL_FILL = { fill, scanRows, pickItem, indexPayload, mapColumns };
})();
