/* AMMO — ƏDV Analiz: compare the portal's "Daxil olan qaimələr" export against the
 * user's "Əvəzləşən qaimələr" sheet and classify each invoice as fully offset, partly
 * offset, not offset, or (for replacement rows) having no matching incoming invoice.
 * Pure logic — takes rows (arrays of strings) from AMMO_XLSX_READ, returns a result object. */
(function (root) {
  'use strict';

  const fold = (s) => String(s == null ? '' : s).replace(/̇/g, '').toLocaleLowerCase('az').trim();
  const num = (v) => { const n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : 0; };
  const digits = (v) => String(v == null ? '' : v).replace(/\D/g, '');
  const isBlankSeries = (s) => { const t = String(s || '').trim(); return t === '' || t === '-' || t === '0'; };
  function normNum(series, number) {
    const s = String(series || '').trim().toUpperCase();
    const d = digits(number);
    if (isBlankSeries(series) || s.startsWith('E')) return d ? d.padStart(6, '0') : String(number || '').trim();
    if (s.startsWith('MT')) return d ? d.padStart(8, '0') : String(number || '').trim();
    return String(number || '').trim();
  }
  const fmtDate = (v) => {
    if (v == null || v === '') return '';
    const n = Number(v);
    if (isFinite(n) && n > 20000 && n < 60000) { const d = new Date(Math.round((n - 25569) * 86400000)); return `${String(d.getUTCDate()).padStart(2, '0')}.${String(d.getUTCMonth() + 1).padStart(2, '0')}.${d.getUTCFullYear()}`; }
    const m = /^(\d{4})[-./](\d{1,2})[-./](\d{1,2})/.exec(String(v)); if (m) return `${m[3].padStart(2, '0')}.${m[2].padStart(2, '0')}.${m[1]}`;
    const m2 = /^(\d{1,2})[-./](\d{1,2})[-./](\d{4})/.exec(String(v)); if (m2) return `${m2[1].padStart(2, '0')}.${m2[2].padStart(2, '0')}.${m2[3]}`;
    return String(v).slice(0, 10);
  };

  function headerRow(rows, needle, maxScan) {
    const nd = fold(needle);
    for (let i = 0; i < Math.min(rows.length, maxScan); i++) if (rows[i].some((c) => fold(c).includes(nd))) return i;
    return -1;
  }
  const colFinder = (H) => (test) => H.findIndex(test);

  // ---------------------------------------------------------------- incoming (portal export)
  function parseIncoming(rows) {
    const hr = headerRow(rows, 'vöen', 25);
    if (hr < 0) throw new Error('Daxil olan qaimələr faylında başlıq (VÖEN) tapılmadı.');
    const H = rows[hr].map(fold);
    const f = colFinder(H);
    const cVoen = f((h) => h === 'vöen' || h === 'voen');
    const cName = f((h) => h === 'adı' || h === 'adi');
    const cDate = f((h) => h.includes('tarixi'));
    const cSeries = f((h) => h.includes('seriyası') || h.includes('seriyasi'));
    const cNumber = f((h) => h.includes('nömrəsi') || h.includes('nomresi'));
    const cBase = f((h) => h.includes('cəlb edilən') || h.includes('celb edilen'));
    const cVat = f((h) => (h.includes('ədv məbləği') || h.includes('malın ədv')) && !h.includes('cəlb') && !h.includes('ödənilmiş'));
    const cTotal = f((h) => h.includes('yekun məbləğ') || h.includes('yekun mebleg'));
    const miss = [];
    if (cVoen < 0) miss.push('VÖEN'); if (cSeries < 0) miss.push('seriyası'); if (cNumber < 0) miss.push('nömrəsi');
    if (cBase < 0) miss.push('ƏDV-yə cəlb edilən'); if (cVat < 0) miss.push('ƏDV məbləği'); if (cTotal < 0) miss.push('Yekun məbləğ');
    if (miss.length) throw new Error('Daxil olan faylda sütunlar tapılmadı: ' + miss.join(', '));
    const out = [];
    for (let i = hr + 1; i < rows.length; i++) {
      const r = rows[i];
      const vatBase = num(r[cBase]);
      if (!(vatBase > 0)) continue;
      const series = String(r[cSeries] || '').trim();
      const number = String(r[cNumber] || '').trim();
      out.push({
        voen: digits(r[cVoen]), name: String(r[cName] || '').trim(), date: fmtDate(r[cDate]),
        series, number, normNumber: normNum(series, number),
        vatBase, vatAmount: num(r[cVat]), total: num(r[cTotal]),
        match: null, status: '', diffBase: 0, diffVat: 0,
      });
    }
    return out;
  }

  // ---------------------------------------------------------------- replacement (user sheet)
  function parseReplacement(rows) {
    let hr = headerRow(rows, 'qaimənin nömrəsi', 50);
    if (hr < 0) hr = headerRow(rows, 'nömrəsi', 50);
    if (hr < 0) throw new Error('Əvəzləşən qaimələr faylında başlıq (Qaimənin nömrəsi) tapılmadı.');
    const H = rows[hr].map(fold);
    const f = colFinder(H);
    const cPeriod = f((h) => h === 'il/ay' || h === 'il / ay');
    const cYear = f((h) => h === 'il');
    const cMonth = f((h) => h === 'ay');
    const cVoen = f((h) => h === 'vöen' || h === 'voen' || h.includes('vöen'));
    const cName = f((h) => h === 'adı' || h === 'adi');
    const cSeries = f((h) => h.includes('seriyası') || h.includes('seriyasi'));
    const cNumber = f((h) => h.includes('nömrəsi') || h.includes('nomresi'));
    const cTotal = f((h) => h === 'ümumi' || h.includes('ümumi məbləğ'));
    const cVat = f((h) => h === 'ədv' || (h.includes('ədv məbləği') && !h.includes('ödənilmiş')));
    const cPaidTotal = f((h) => h.includes('ödənilmiş ümumi'));
    const cPaidVat = f((h) => h.includes('ödənilmiş ədv'));
    const miss = [];
    if (cVoen < 0) miss.push('VÖEN'); if (cSeries < 0) miss.push('seriyası'); if (cNumber < 0) miss.push('nömrəsi');
    if (cPaidTotal < 0) miss.push('Ödənilmiş ümumi'); if (cPaidVat < 0) miss.push('Ödənilmiş ƏDV');
    if (miss.length) throw new Error('Əvəzləşən faylda sütunlar tapılmadı: ' + miss.join(', '));
    const out = [];
    for (let i = hr + 1; i < rows.length; i++) {
      const r = rows[i];
      const series = String(r[cSeries] || '').trim();
      const number = String(r[cNumber] || '').trim();
      if (!number && !digits(r[cVoen])) continue;
      let year = cYear >= 0 ? String(r[cYear] || '').trim() : '';
      let month = cMonth >= 0 ? String(r[cMonth] || '').trim() : '';
      let period = cPeriod >= 0 ? String(r[cPeriod] || '').trim() : '';
      if (period && period.includes('/')) { const p = period.split('/'); year = year || p[0].trim(); month = month || p[1].trim(); }
      else if (!period) period = [year, month].filter(Boolean).join('/');
      const normSeries = isBlankSeries(series) ? '' : series.toUpperCase();
      const nn = normNum(series, number);
      out.push({
        period, year, month, voen: digits(r[cVoen]), name: String(r[cName] || '').trim(),
        series, normSeries, number, normNumber: nn, key: (normSeries || 'NO_SERIES') + '|' + nn,
        total: num(r[cTotal]), vat: num(r[cVat]), paidTotal: num(r[cPaidTotal]), paidVat: num(r[cPaidVat]),
      });
    }
    // duplicate markers
    const byKey = new Map();
    out.forEach((r) => { byKey.set(r.key, (byKey.get(r.key) || 0) + 1); });
    out.forEach((r) => { r.periodCount = byKey.get(r.key); });
    return out;
  }

  // ---------------------------------------------------------------- analyze
  const TOL = 0.01;
  function analyze(incoming, replacement) {
    // collapse replacement by key (sum paid amounts, list periods)
    const collapsed = new Map();
    replacement.forEach((r) => {
      let c = collapsed.get(r.key);
      if (!c) { c = { key: r.key, normSeries: r.normSeries, normNumber: r.normNumber, voen: r.voen, name: r.name, total: 0, vat: 0, paidTotal: 0, paidVat: 0, periods: [] }; collapsed.set(r.key, c); }
      c.total += r.total; c.vat += r.vat; c.paidTotal += r.paidTotal; c.paidVat += r.paidVat;
      if (r.period) c.periods.push(r.period);
    });
    const byKey = {}, byNumberOnly = {};
    collapsed.forEach((c) => { byKey[c.key] = c; if (!c.normSeries) byNumberOnly[c.normNumber] = c; });
    const usedKeys = new Set();

    const fullMatched = [], partialMatched = [], unmatchedOnly = [], differenceOnly = [];
    incoming.forEach((inv) => {
      const s = inv.series.trim().toUpperCase();
      const lk = (s || 'NO_SERIES') + '|' + inv.normNumber;
      let m = byKey[lk] || byKey[s + '|' + inv.normNumber];
      if (!m && (s.startsWith('E') || !s)) m = byNumberOnly[inv.normNumber];
      if (m) {
        usedKeys.add(m.key);
        inv.match = m;
        inv.diffBase = Math.round((inv.vatBase - m.paidTotal) * 100) / 100;
        inv.diffVat = Math.round((inv.vatAmount - m.paidVat) * 100) / 100;
        if (Math.abs(inv.diffBase) < TOL && Math.abs(inv.diffVat) < TOL) { inv.status = 'full'; fullMatched.push(inv); }
        else { inv.status = 'partial'; partialMatched.push(inv); differenceOnly.push(inv); }
      } else { inv.status = 'unmatched'; unmatchedOnly.push(inv); }
    });
    const invalid = [];
    collapsed.forEach((c) => { if (!usedKeys.has(c.key)) invalid.push(c); });

    return {
      kind: 'edv', created: Date.now(),
      incoming, replacement,
      fullMatched, partialMatched, unmatchedOnly, differenceOnly, invalid,
      repCollapsed: [...collapsed.values()],
      stats: {
        totalIn: incoming.length, totalRep: replacement.length,
        withMatch: fullMatched.length + partialMatched.length,
        unmatched: unmatchedOnly.length, full: fullMatched.length, partial: partialMatched.length, invalid: invalid.length,
      },
    };
  }

  function run(incomingRows, replacementRows) {
    return analyze(parseIncoming(incomingRows), parseReplacement(replacementRows));
  }

  root.AMMO_EDV = { run, analyze, parseIncoming, parseReplacement, normNum, fmtDate };
})(typeof globalThis !== 'undefined' ? globalThis : this);
