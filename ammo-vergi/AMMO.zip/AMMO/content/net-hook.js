/* AMMO — (səhifə dünyası) ƏDV depozit hesabı səhifəsinin portal sorğusunu öyrənmək üçün yüngül müşahidəçi.
 * Yalnız new.e-taxes.gov.az/api/po/... cavablarına baxır; heç nə dəyişmir, heç yerə göndərmir —
 * sorğunun ünvanı, gövdəsi və cavabın quruluşu (ilk bir neçə sətir) eyni səhifədəki AMMO-ya window.postMessage ilə ötürülür. */
(function () {
  'use strict';
  if (window.__AMMO_NET_HOOK__) return;
  window.__AMMO_NET_HOOK__ = true;

  const INTERESTING = /vat.?account|vat.?acc|deposit|depozit|sub.?account|subaccount|sub-uchot|subuchot/i;
  const SKIP = /\/(notification|notifications|menu|common|dictionary|dictionaries|auth|token|profile|user|messages?|news|banner|invoice\/public|declaration\/public)\b/i;
  const onVatPage = () => /vat-account|vat_account|deposit/i.test(location.pathname);

  function firstArray(obj, depth = 0) {
    if (Array.isArray(obj)) return { path: '', arr: obj };
    if (!obj || typeof obj !== 'object' || depth > 3) return null;
    let best = null;
    for (const [k, v] of Object.entries(obj)) {
      if (Array.isArray(v) && v.length && typeof v[0] === 'object') { if (!best || v.length > best.arr.length) best = { path: k, arr: v }; }
      else if (v && typeof v === 'object' && !Array.isArray(v)) { const r = firstArray(v, depth + 1); if (r && (!best || r.arr.length > best.arr.length)) best = { path: k + (r.path ? '.' + r.path : ''), arr: r.arr }; }
    }
    return best;
  }
  // v1.22: məktublar — oxunmamışların sayı
  const MAIL = /(mail|message|letter|correspond|notification|mektub|inbox(?!.*invoice))/i;
  function mailSnap(u, json) {
    try {
      if (/invoice|declaration/i.test(u)) return;
      let unread = null, total = null;
      const walk = (o, d) => {
        if (!o || typeof o !== 'object' || d > 3) return;
        for (const [k, v] of Object.entries(o)) {
          if (typeof v === 'number' && /unread|notread|newcount|new_count|unseen|unreadcount/i.test(k) && unread == null) unread = v;
          else if (typeof v === 'number' && /^(total|totalcount|count|totalelements)$/i.test(k) && total == null) total = v;
          else if (v && typeof v === 'object' && !Array.isArray(v)) walk(v, d + 1);
        }
      };
      walk(json, 0);
      const fa = firstArray(json);
      if (unread == null && fa && fa.arr.length) {
        const isUnread = (x) => x && (x.read === false || x.isRead === false || x.seen === false || x.opened === false || /unread|new|oxunmay/i.test(String(x.status || x.readStatus || '')));
        if (fa.arr.some((x) => x && ('read' in x || 'isRead' in x || 'seen' in x || 'opened' in x || 'readStatus' in x))) unread = fa.arr.filter(isUnread).length;
        if (total == null) total = fa.arr.length;
      }
      if (unread == null && total == null) return;
      window.postMessage({ __ammo: 'snap', kind: 'mail', url: new URL(u, location.href).href, unread, total, page: location.pathname }, location.origin);
    } catch (e) { /* */ }
  }
  // v1.22.3: sadələşdirilmiş bəyannamənin 804-cü sətri (rüb üzrə hasilat) — portal formanı açanda öz cavabında göndərir
  const VAL_KEYS = /^(amount|value|sum|total|cost|amountTotal|quarterAmount|hasilat|revenue)$/i;
  function val804(o) {
    for (const [k, v] of Object.entries(o)) if (VAL_KEYS.test(k) && typeof v === 'number') return v;
    const nums = Object.entries(o).filter(([k, v]) => typeof v === 'number' && !/order|rate|faiz|percent|id$/i.test(k)).map(([, v]) => v);
    return nums.length ? Math.max(...nums) : null;
  }
  function snap804(u, json) {
    try {
      let root = json;
      if (json && typeof json.baseJson === 'string') { try { root = JSON.parse(json.baseJson); } catch (e) { /* */ } }
      let v = null, per = null, reg = '', tc = '';
      const walk = (o, d) => {
        if (!o || typeof o !== 'object' || d > 8) return;
        if (Array.isArray(o)) { o.forEach((x) => walk(x, d + 1)); return; }
        if (o.indicator != null && /(^|_)0*804$/.test(String(o.indicator))) { const x = val804(o); if (x != null && (v == null || x > v)) v = x; }
        for (const [k, x] of Object.entries(o)) {
          if (typeof x === 'number' && /(^|[^0-9])804$/.test(k) && v == null) v = x;
          else if (k === 'reportingPeriod' && x && typeof x === 'object' && x.year) per = per || x;
          else if (/^(registrationNumber|regNumber|reg_number)$/.test(k) && typeof x === 'string' && !reg) reg = x;
          else if (k === 'taxCode' && typeof x === 'string' && !tc) tc = x;
          else if (x && typeof x === 'object') walk(x, d + 1);
        }
      };
      walk(root, 0);
      if (v == null) return;
      if (!per) { try { const q = new URL(u, location.href).searchParams; const y = +(q.get('year') || ''); if (y) per = { year: y, month: +(q.get('month') || q.get('quarter') || 0), type: q.get('quarter') ? 'QUARTER' : '' }; } catch (e) { /* */ } }
      if (!per) { const m = /(20\d\d)[./-]?(?:q|Q)?([1-4])\b/.exec(location.pathname + location.search); if (m) per = { year: +m[1], month: (+m[2]) * 3 - 2, type: 'QUARTER' }; }
      window.postMessage({ __ammo: 'snap', kind: '804', url: new URL(u, location.href).href, value: v, period: per, reg, taxCode: tc, page: location.pathname }, location.origin);
    } catch (e) { /* */ }
  }
  function report(url, method, body, json) {
    try {
      const u = String(url || '');
      if (!/\/api\/po\//.test(u)) return;
      if (/declaration/i.test(u)) snap804(u, json);
      if (MAIL.test(u)) mailSnap(u, json);
      if (SKIP.test(u)) return;
      if (!INTERESTING.test(u) && !onVatPage()) return;
      const fa = firstArray(json);
      if (!fa || !fa.arr.length) return;
      const top = json && typeof json === 'object' && !Array.isArray(json) ? Object.fromEntries(Object.entries(json).filter(([, v]) => v === null || typeof v !== 'object')) : {};
      window.postMessage({ __ammo: 'net', url: new URL(u, location.href).href, method: String(method || 'GET').toUpperCase(), body: body == null ? null : String(body).slice(0, 4000),
        arrPath: fa.path, count: fa.arr.length, sample: fa.arr.slice(0, 4), top, page: location.pathname }, location.origin);
    } catch (e) { /* səssiz */ }
  }

  const ofetch = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    const method = (init && init.method) || (input && input.method) || 'GET';
    const body = init && typeof init.body === 'string' ? init.body : null;
    const p = ofetch.apply(this, arguments);
    if (/\/api\/po\//.test(url)) p.then((res) => { try { res.clone().json().then((j) => report(url, method, body, j), () => {}); } catch (e) { /* */ } }, () => {});
    return p;
  };
  const oopen = XMLHttpRequest.prototype.open, osend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) { this.__ammo = { method, url }; return oopen.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (body) {
    const meta = this.__ammo;
    if (meta && /\/api\/po\//.test(String(meta.url))) {
      this.addEventListener('load', () => {
        try {
          const t = this.responseType === '' || this.responseType === 'text' ? this.responseText : (this.responseType === 'json' ? JSON.stringify(this.response) : '');
          if (t) report(meta.url, meta.method, typeof body === 'string' ? body : null, JSON.parse(t));
        } catch (e) { /* */ }
      });
    }
    return osend.apply(this, arguments);
  };
})();
