/* AMMO — ƏDV Əvəzləşməsi: portal qatı (v1.19.0). new.e-taxes.gov.az-da content script kimi işləyir.
 *  • collect(): alış qaimələri + ƏDV bəyannamələrinin Əlavə 1-i (qaimələr və YGB) + 308/310 cəmləri → xam məlumat
 *  • Mükəlləfiyyətlər bölməsi açılanda ƏDV-nin başlama/bitmə dövrünü özü oxuyub yadda saxlayır
 *  • Nəticə səhifəsi üçün körpü: qaimənin mal sətirləri, seriya ilə qaimə axtarışı (yalnız OXUMA) */
(function (root) {
  'use strict';
  if (window.top !== window) return;
  const API = root.AMMO_API;
  const E = root.AMMO_EVEZ;
  if (!API || !E) return;

  const pad = (x) => String(x).padStart(2, '0');
  const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
  const fold = (s) => String(s == null ? '' : s).replace(/̇/g, '').toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();

  // ------------------------------------------------------------------ istifadəçinin VÖEN-i (JWT-dən, yalnız oxunur)
  function ownTin() {
    try {
      const t = API.token(); if (!t) return '';
      const b = t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      const j = JSON.parse(decodeURIComponent(escape(atob(b + '==='.slice((b.length + 3) % 4)))));
      let best = '';
      const walk = (o, depth) => {
        if (!o || depth > 4 || best) return;
        for (const [k, v] of Object.entries(o)) {
          if (typeof v === 'string' && /^\d{10}$/.test(v) && /tin|voen|taxpayer|legal|org|company/i.test(k)) { best = v; return; }
          if (v && typeof v === 'object') walk(v, depth + 1);
        }
      };
      walk(j, 0);
      if (!best) { const m = /"(\d{10})"/.exec(JSON.stringify(j)); best = m ? m[1] : ''; }
      return best;
    } catch (e) { return ''; }
  }

  // ------------------------------------------------------------------ Mükəlləfiyyətlər bölməsini oxu (portal səhifəsi açıq olanda)
  const OBL_KEY = (tin) => 'ammo_evez_obl_' + (tin || 'x');
  function scanObligations() {
    const rows = [...document.querySelectorAll('tr')];
    if (!rows.length) return null;
    const hits = [];
    rows.forEach((tr) => {
      const cells = [...tr.querySelectorAll('td')].map((td) => td.textContent.replace(/\s+/g, ' ').trim());
      if (cells.length < 3 || !fold(cells[0]).startsWith('əlavə dəyər vergisi')) return;
      const dates = cells.join(' ').match(/\d{2}\.\d{2}\.\d{4}/g) || [];
      const perText = cells[3] || cells[cells.length - 1] || '';
      const parts = perText.split(/\s[-–]\s/);
      const start = E.parsePeriodText(parts[0]) || (dates[0] ? E.ym(E.isoDate(dates[0])) : '');
      const end = parts[1] ? E.parsePeriodText(parts[1]) : (dates[1] ? E.ym(E.isoDate(dates[1])) : '');
      if (start) hits.push({ start, end, startDate: dates[0] ? E.isoDate(dates[0]) : '', endDate: dates[1] ? E.isoDate(dates[1]) : '', period: cells[1] || '' });
    });
    return hits.length ? hits : null;
  }
  let lastSaved = '';
  async function captureObligations() {
    if (!/mükəlləfiyyət/i.test(document.body ? document.body.innerText.slice(0, 20000) : '')) return;
    const hits = scanObligations();
    if (!hits) return;
    const tin = ownTin();
    const sig = JSON.stringify(hits);
    if (sig === lastSaved) return;
    lastSaved = sig;
    const key = OBL_KEY(tin);
    const prev = (await chrome.storage.local.get(key))[key] || { list: [] };
    const list = prev.list || [];
    hits.forEach((h) => { const i = list.findIndex((x) => x.start === h.start); if (i >= 0) list[i] = { ...list[i], ...h }; else list.push(h); });
    list.sort((a, b) => a.start.localeCompare(b.start));
    await chrome.storage.local.set({ [key]: { list, at: Date.now(), tin } });
  }
  setInterval(() => { captureObligations().catch(() => {}); }, 3000);

  /** Mükəlləfiyyət: yadda saxlanmış (portal bölməsindən) — yoxdursa null */
  async function savedObligation(tin) {
    const o = (await chrome.storage.local.get(OBL_KEY(tin)))[OBL_KEY(tin)];
    if (!o || !(o.list || []).length) return null;
    // ən son fasiləsiz dövr: aktiv (bitməyən) varsa — o, yoxdursa sonuncu
    const active = o.list.filter((x) => !x.end);
    const cur = active.length ? active[active.length - 1] : o.list[o.list.length - 1];
    const first = o.list[0];
    return { start: cur.start, end: cur.end || '', firstStart: first.start, startDate: cur.startDate, history: o.list, source: 'Mükəlləfiyyətlər bölməsi', at: o.at };
  }

  // ------------------------------------------------------------------ v1.20: ƏDV depozit hesabı — portaldan avtomatik (vat-account)
  // Portalın «ƏDV depozit hesabı» səhifəsi öz sorğusunu göndərəndə (net-hook.js) AMMO onu öyrənir,
  // sonra istənilən tarix aralığı üçün eyni sorğunu təkrarlayır. Yalnız OXUMA.
  const TPL_KEY = 'ammo_vatacc_tpl';
  const tplScore = (m) => {
    const d = E.depositFromApi(m.sample || [], ownTin());
    const k = d.keys || {};
    let sc = d.payments.length * 10;
    if (k.tin) sc += 5; if (k.date) sc += 5; if (k.inc || k.out) sc += 8; if (k.desc) sc += 3; if (k.ser || k.num) sc += 4;
    if (/oper|transac|movement|history|statement|transfer|köçür|payment/i.test(m.url)) sc += 4;
    if (/balance|saldo/i.test(m.url) && !(k.inc || k.out)) sc -= 10;
    return sc;
  };
  window.addEventListener('message', async (ev) => {
    const m = ev.data;
    if (ev.source !== window || !m || m.__ammo !== 'net') return;
    try {
      const sc = tplScore(m);
      if (sc < 18) return;
      const prev = (await chrome.storage.local.get(TPL_KEY))[TPL_KEY];
      const same = prev && prev.url.split('?')[0] === m.url.split('?')[0];
      if (prev && !same && prev.score > sc && Date.now() - prev.at < 90 * 864e5) return;
      await chrome.storage.local.set({ [TPL_KEY]: { url: m.url, method: m.method, body: m.body, arrPath: m.arrPath, top: m.top, sample: (m.sample || []).slice(0, 3), score: sc, at: Date.now(), page: m.page } });
    } catch (e) { /* */ }
  });

  // tarix sahələrini yeni aralıqla əvəz et (format qorunur)
  const DATE_FORMATS = [
    [/^(\d{2})-(\d{2})-(\d{4}) (\d{2}):(\d{2})$/, (iso, end) => { const d = new Date(iso + 'T00:00:00'); if (end) d.setDate(d.getDate() + 1); return `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()} 00:00`; }],
    [/^(\d{4})-(\d{2})-(\d{2})T/, (iso, end, orig) => (end ? `${iso}T23:59:59${/\.\d+/.test(orig) ? '.999' : ''}${/Z$/.test(orig) ? 'Z' : ''}` : `${iso}T00:00:00${/\.\d+/.test(orig) ? '.000' : ''}${/Z$/.test(orig) ? 'Z' : ''}`)],
    [/^(\d{4})-(\d{2})-(\d{2})$/, (iso) => iso],
    [/^(\d{2})\.(\d{2})\.(\d{4})$/, (iso) => `${iso.slice(8, 10)}.${iso.slice(5, 7)}.${iso.slice(0, 4)}`],
    [/^(\d{2})-(\d{2})-(\d{4})$/, (iso) => `${iso.slice(8, 10)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}`],
    [/^(\d{2})\/(\d{2})\/(\d{4})$/, (iso) => `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}`],
  ];
  const isDateStr = (v) => typeof v === 'string' && DATE_FORMATS.some(([re]) => re.test(v.trim()));
  function substDates(entries, fromISO, toISO) {
    // entries: [{key, value, set(v)}]
    const ds = entries.filter((e) => isDateStr(e.value));
    if (!ds.length) return 0;
    const role = (k) => (/(from|start|begin|min|since|bas|first)/i.test(k) ? 'from' : /(to|end|till|until|max|son|last|finish)$|(to|end)[A-Z_]/i.test(k) ? 'to' : '');
    let roles = ds.map((e) => role(e.key));
    if (roles.some((r) => !r)) { const sorted = ds.map((e, i) => [E.isoDate(e.value), i]).sort(); roles = ds.map(() => 'from'); if (sorted.length > 1) roles[sorted[sorted.length - 1][1]] = 'to'; }
    ds.forEach((e, i) => {
      const v = e.value.trim();
      const f = DATE_FORMATS.find(([re]) => re.test(v));
      const end = roles[i] === 'to';
      e.set(f[1](end ? toISO : fromISO, end, v));
    });
    return ds.length;
  }
  function walkEntries(obj, out = [], depth = 0) {
    if (!obj || typeof obj !== 'object' || depth > 4) return out;
    Object.keys(obj).forEach((k) => {
      const v = obj[k];
      if (v && typeof v === 'object' && !Array.isArray(v)) walkEntries(v, out, depth + 1);
      else out.push({ key: k, value: v, set: (x) => { obj[k] = x; } });
    });
    return out;
  }
  const getPath = (o, path) => (path ? path.split('.').reduce((a, k) => (a ? a[k] : undefined), o) : o);

  async function vatAccountRange(tpl, fromISO, toISO) {
    const u = new URL(tpl.url);
    let body = null;
    try { body = tpl.body ? JSON.parse(tpl.body) : null; } catch (e) { body = null; }
    const qEntries = [...u.searchParams.keys()].map((k) => ({ key: k, value: u.searchParams.get(k), set: (x) => u.searchParams.set(k, x) }));
    const n1 = substDates(qEntries, fromISO, toISO);
    const n2 = body ? substDates(walkEntries(body), fromISO, toISO) : 0;
    if (!n1 && !n2) throw Object.assign(new Error('Depozit sorğusunda tarix sahəsi tapılmadı'), { code: 'nodate' });
    // səhifələmə
    const pageKeys = { off: ['offset', 'start', 'skip', 'from'], size: ['maxCount', 'limit', 'size', 'pageSize', 'count', 'take'], page: ['page', 'pageNumber', 'pageNo', 'pageIndex'] };
    const findK = (names) => {
      const q = [...u.searchParams.keys()].find((k) => names.includes(k)); if (q) return { where: 'q', k: q };
      const b = body && Object.keys(body).find((k) => names.includes(k) && typeof body[k] === 'number'); return b ? { where: 'b', k: b } : null;
    };
    const offK = findK(pageKeys.off), sizeK = findK(pageKeys.size), pageK = findK(pageKeys.page);
    const setK = (K, v) => { if (!K) return; if (K.where === 'q') u.searchParams.set(K.k, String(v)); else body[K.k] = v; };
    const getK = (K) => (K ? Number(K.where === 'q' ? u.searchParams.get(K.k) : body[K.k]) || 0 : 0);
    const size = getK(sizeK) || 0;
    const page0 = getK(pageK);
    const all = [];
    for (let i = 0; i < 300; i++) {
      if (offK) setK(offK, all.length); else if (pageK) setK(pageK, page0 + i);
      const res = await API.raw(tpl.method || 'GET', u.pathname + u.search, tpl.method === 'GET' ? null : body);
      if (res && typeof res === 'object') vatAccountRange.lastTop = res;
      let arr = getPath(res, tpl.arrPath);
      if (!Array.isArray(arr)) arr = Array.isArray(res) ? res : [];
      all.push(...arr);
      const hasMore = res && typeof res.hasMore === 'boolean' ? res.hasMore
        : res && (res.last === false || res.isLast === false) ? true
        : res && res.totalPages != null ? page0 + i + 1 < Number(res.totalPages) - (page0 ? 0 : 0)
        : res && (res.total != null || res.totalCount != null || res.totalElements != null) ? all.length < Number(res.total ?? res.totalCount ?? res.totalElements)
        : size && arr.length >= size;
      if (!arr.length || !hasMore || (!offK && !pageK)) break;
    }
    return all;
  }

  async function learnTemplate(onStep) {
    let tpl = (await chrome.storage.local.get(TPL_KEY))[TPL_KEY];
    if (tpl) return tpl;
    onStep && onStep('ƏDV depozit hesabı səhifəsi açılır (sorğu öyrənilir)…');
    const r = await chrome.runtime.sendMessage({ type: 'AMMO_VATACC_LEARN' }).catch(() => null);
    tpl = (await chrome.storage.local.get(TPL_KEY))[TPL_KEY];
    return tpl || null;
  }

  /** ƏDV depozit hesabının əməliyyatları: {payments, from, to, …} və ya xəta */
  async function vatAccountOps(fromISO, toISO, onStep) {
    const tpl = await learnTemplate(onStep);
    if (!tpl) throw Object.assign(new Error('ƏDV depozit hesabının sorğusu öyrənilmədi'), { code: 'notpl' });
    onStep && onStep(`ƏDV depozit hesabı: ${E.dmy(fromISO)} – ${E.dmy(toISO)} əməliyyatları yüklənir…`);
    let rows = [];
    try { rows = await vatAccountRange(tpl, fromISO, toISO); }
    catch (e) {
      if (e.status === 401 || e.status === 403) throw e;
      if (e.status === 404 || e.status === 405 || e.code === 'nodate') {
        // öyrənilmiş sorğu yararsızdır — unut, növbəti dəfə yenidən öyrənilsin
        await chrome.storage.local.remove(TPL_KEY);
        throw Object.assign(new Error('Öyrənilmiş depozit sorğusu portalda tapılmadı (' + (e.status || e.code) + '). AMMO onu sildi — portalda «ƏDV depozit hesabı» səhifəsini açıb əməliyyatları göstərin (lazım olsa «Axtar»), sonra yenidən «Portaldan çək» basın.'), { code: 'notpl' });
      }
      // portal uzun aralığı qəbul etməzsə — il-il
      rows = [];
      for (let y = +fromISO.slice(0, 4); y <= +toISO.slice(0, 4); y++) {
        const f = y === +fromISO.slice(0, 4) ? fromISO : `${y}-01-01`, t = y === +toISO.slice(0, 4) ? toISO : `${y}-12-31`;
        onStep && onStep(`ƏDV depozit hesabı: ${y}…`);
        rows.push(...await vatAccountRange(tpl, f, t));
      }
    }
    const dep = E.depositFromApi(rows, ownTin(), { from: fromISO, to: toISO });
    dep.rawCount = rows.length; dep.at = Date.now(); dep.endpoint = tpl.url.split('?')[0];
    // depozit hesabının qalığı (cavabda varsa)
    try {
      const top = vatAccountRange.lastTop || {};
      let bal = null;
      const walk = (o, d) => { if (!o || typeof o !== 'object' || d > 3 || bal != null) return; for (const [k, v] of Object.entries(o)) { if (bal != null) return; if (typeof v === 'number' && /(closing|end|final|current)?.*(balance|saldo|qaliq|remain)/i.test(k) && !/open|start|begin/i.test(k)) bal = v; else if (v && typeof v === 'object' && !Array.isArray(v)) walk(v, d + 1); } };
      walk(top, 0);
      if (bal != null) dep.closing = bal;
    } catch (e) { /* */ }
    if (rows.length && !dep.payments.length) {
      await chrome.storage.local.set({ ammo_vatacc_debug: { at: Date.now(), tpl, sample: rows.slice(0, 5), keys: dep.keys } });
      throw Object.assign(new Error('Depozit əməliyyatları portaldan alındı, amma sütunlar tanınmadı'), { code: 'parse' });
    }
    return dep;
  }

  // ------------------------------------------------------------------ ƏDV bəyannamələri
  const isVat = (d) => d && String(d.taxCode) === '_0300';
  const isDraft = (d) => /DRAFT/i.test(d.declarationStatus || '');
  const when = (d) => new Date(d.submissionDate || d.modificationDate || d.registrationDate || 0).getTime();
  async function vatDeclsOfYear(y) {
    const all = await API.declarations(y);
    return (all || []).map((e) => (e && e.declaration) || e).filter((d) => isVat(d) && d.reportingPeriod && d.reportingPeriod.type === 'MONTH');
  }
  /** «Bütün illər» və mükəlləfiyyət bilinmirsə: ilk ƏDV bəyannaməsinin ayı */
  async function firstVatMonth(onStep) {
    const cy = new Date().getFullYear();
    let first = '', last = '', emptyRun = 0;
    const cache = {};
    for (let y = cy; y >= 2019; y--) {
      onStep && onStep(`ƏDV mükəlləfiyyətinin başlanğıcı axtarılır… ${y}`);
      const list = await vatDeclsOfYear(y).catch(() => []);
      cache[y] = list;
      const ms = list.filter((d) => !isDraft(d)).map((d) => `${d.reportingPeriod.year}-${pad(d.reportingPeriod.month)}`).sort();
      if (ms.length) { first = ms[0]; if (!last) last = ms[ms.length - 1]; emptyRun = 0; } else if (first) { if (++emptyRun >= 1) break; }
    }
    return { first, last, cache };
  }

  // Əlavə 1 — YGB sətirlərinin adı portalda dəqiq bilinmir: bir neçə ad sınanır, işləyən yadda qalır
  const CCD_NAMES = ['VAT_APPENDIX_1_REPORT_PERIOD_CCD', 'VAT_APPENDIX_1_REPORT_PERIOD_CUSTOMS_DECLARATION', 'VAT_APPENDIX_1_REPORT_PERIOD_CARGO_CUSTOMS_DECLARATION', 'VAT_APPENDIX_1_REPORT_PERIOD_YGB'];
  async function ccdRows(reg, base) {
    const a1 = (base && base.taxInformation && base.taxInformation.appendix1) || {};
    const total = a1.reportPeriodCCDTotal || null;
    if (!(total && Number(total.vat) > 0)) return { rows: [], total };     // bu ay YGB yoxdur — sorğuya ehtiyac yox
    // 1) bəyannamənin özündə (base) massiv
    for (const [k, v] of Object.entries(a1)) {
      if (Array.isArray(v) && v.length && /ccd|custom/i.test(k)) return { rows: v.map(E.appendixCcdRow), total };
    }
    // 2) ayrıca siyahı (calc) — adı portalda dəqiq bilinmir: bir neçə ad sınanır, nəticə verən yadda qalır
    let known = ''; try { known = localStorage.getItem('ammo_evez_ccd') || ''; } catch (e) { /* */ }
    const names = known ? [known, ...CCD_NAMES.filter((x) => x !== known)] : CCD_NAMES;
    for (const nm of names) {
      try {
        const rows = await API.declarationCalc(nm, reg);
        if (rows.length) { try { localStorage.setItem('ammo_evez_ccd', nm); } catch (e) { /* */ } return { rows: rows.map(E.appendixCcdRow), total }; }
      } catch (e) { if (e.status === 401 || e.status === 0) throw e; }
    }
    return { rows: [], total };   // yalnız ayın cəmi (310-cu sətir) məlumdur
  }

  const byInd = (list) => { const m = new Map(); (Array.isArray(list) ? list : []).forEach((e) => { if (e && e.indicator && !m.has(e.indicator)) m.set(e.indicator, e); }); return m; };
  function baseNumbers(base) {
    const ti = (base && base.taxInformation) || {};
    const rc = byInd(ti.refundCalculations);
    const calc = byInd(ti.calculations);
    const g = (m, k, f) => { const e = m.get(k); return e ? E.r2(e[f]) : 0; };
    const mt = ti.mainTax || {};
    let outVat = 0; calc.forEach((e) => { outVat += Number(e.vat) || 0; });
    return {
      l308: { paid: g(rc, '_1008', 'paidAmount'), vat: g(rc, '_1008', 'vat') },
      l310: { paid: g(rc, '_1010', 'paidAmount'), vat: g(rc, '_1010', 'vat') },
      payable: E.r2(mt.mustBePaid), refund: E.r2(mt.mustBeReturned), outVat: E.r2(outVat),
    };
  }

  // ------------------------------------------------------------------ əsas toplama
  /**
   * opts: {mode:'all'|'year'|'range', year, fromISO, toISO, drafts:boolean, oblOverride:'YYYY-MM'|''}
   * Qaytarır: { inputs } — nəticə səhifəsi AMMO_EVEZ.analyze(inputs) ilə hesablayır.
   */
  async function collect(opts, onStep) {
    const step = (t) => onStep && onStep(t);
    const tin = ownTin();
    const today = todayISO();
    const notes = [];

    // 1) mükəlləfiyyət dövrü
    let obl = await savedObligation(tin);
    let scan = null;
    if (opts.oblOverride) obl = { start: opts.oblOverride, end: '', source: 'əl ilə daxil edilib' };
    if (!obl) {
      scan = await firstVatMonth(step);
      if (scan.first) obl = { start: scan.first, end: '', source: 'ilk ƏDV bəyannaməsinə görə' };
      else obl = { start: '', end: '', source: 'tapılmadı' };
      notes.push('ƏDV mükəlləfiyyətinin başlanğıcı ilk ƏDV bəyannaməsinə görə təyin edildi. Dəqiq tarix üçün portalda «Mükəlləfiyyətlər» bölməsini bir dəfə açın — AMMO onu yadda saxlayacaq.');
    }

    // 2) dövr
    let from, to;
    const endCap = obl.end ? `${obl.end}-31` : today;
    if (opts.mode === 'all') { from = obl.start ? `${obl.start}-01` : `${new Date().getFullYear()}-01-01`; to = endCap < today ? endCap : today; }
    else if (opts.mode === 'year') { from = `${opts.year}-01-01`; to = `${opts.year}-12-31` < today ? `${opts.year}-12-31` : today; }
    else { from = opts.fromISO; to = opts.toISO; }
    if (obl.start && from < `${obl.start}-01` && opts.mode !== 'range') from = `${obl.start}-01`;
    if (!from || !to || from > to) throw new Error('Tarix aralığı düzgün deyil.');
    if (to > today) to = today;
    // əvəzləşmə qaimədən sonrakı aylarda da ola bilər → bəyannamələr seçilmiş başlanğıcdan bu günə (və ya mükəlləfiyyətin sonuna) qədər oxunur
    const declTo = endCap < today ? endCap : today;

    // 3) bəyannamələr
    const y1 = +from.slice(0, 4), y2 = +declTo.slice(0, 4);
    let list = [];
    for (let y = y1; y <= y2; y++) {
      step(`ƏDV bəyannamələrinin siyahısı: ${y}…`);
      const part = scan && scan.cache[y] ? scan.cache[y] : await vatDeclsOfYear(y);
      list.push(...part);
    }
    const fromYm = from.slice(0, 7), toYm = declTo.slice(0, 7);
    const groups = new Map();
    list.forEach((d) => {
      const p = d.reportingPeriod; const k = `${p.year}-${pad(p.month)}`;
      if (k < fromYm || k > toYm) return;
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(d);
    });
    const picked = [];
    for (const [k, g] of groups) {
      g.sort((a, b) => when(a) - when(b));
      const nd = g.filter((d) => !isDraft(d));
      let last = nd.find((d) => d.lastClarifying === 'LAST') || nd[nd.length - 1];
      if (!last && opts.drafts) last = g[g.length - 1];
      if (last) picked.push({ k, d: last, drafts: g.filter(isDraft).length });
    }
    picked.sort((a, b) => a.k.localeCompare(b.k));

    let done = 0;
    const decls = await API.pool(picked, 4, async ({ k, d }) => {
      const reg = d.id || d.registrationNumber;
      const [rows, base] = await Promise.all([API.vatAppendix1(reg), API.declarationBase(reg).catch(() => ({}))]);
      const ccd = await ccdRows(reg, base).catch(() => ({ rows: [], total: null }));
      step(`Bəyannamələr oxunur (Əlavə 1)… ${++done}/${picked.length}`);
      return {
        period: k, reg: d.registrationNumber || reg, id: d.id || '', type: d.declarationType || '', status: d.declarationStatus || '',
        submitted: d.submissionDate || d.registrationDate || '', rows: rows.map(E.appendixInvoiceRow), ccd: ccd.rows,
        ccdTotal: ccd.total ? { amount: E.r2(ccd.total.amount), vat: E.r2(ccd.total.vat) } : null, ...baseNumbers(base),
      };
    });
    const failed = decls.filter((x) => !x || x.__error);
    if (failed.length) notes.push(`${failed.length} bəyannamə oxuna bilmədi (portal xətası) — həmin aylar «bəyannamə yoxdur» kimi görünə bilər.`);

    // 4) alış qaimələri
    step('Alış qaimələri (gələnlər) yüklənir…');
    const SITE = ['approved', 'onApproval', 'updateApproval', 'updateRequested', 'cancelRequested', 'approvedBySystem', 'onApprovalEdited', 'deactivated', 'cancelationRefused', 'correctionRefused'];
    const kinds = (root.AMMO_DICT ? root.AMMO_DICT.INVOICE_KINDS : []).map((x) => x[0]);
    const D = root.AMMO_DICT;
    const raw = await API.findInvoices({ direction: 'inbox', statuses: SITE, kinds, from: D.apiDate(from), to: D.apiDate(to, true) }, (c) => step(`Alış qaimələri yüklənir… ${c}`));
    const invoices = raw.map(E.invoiceFromApi);

    // 5) ƏDV depozit hesabı — əvəzləşmə HÜQUQU (ödəniş qaimədən sonra da ola bilər → bu günə qədər)
    let deposit = null;
    if (opts.autoDeposit !== false) {
      try {
        deposit = await vatAccountOps(from, today, step);
        notes.push(`ƏDV depozit hesabı portaldan avtomatik oxundu: ${deposit.payments.length} əməliyyat (${E.dmy(from)} – ${E.dmy(today)}).`);
      } catch (e) {
        if (e.status === 401 || e.status === 403) throw e;
        const why = e.code === 'notpl' ? 'Portalda «ƏDV depozit hesabı» (vat-account) səhifəsini bir dəfə açıb əməliyyatları göstərin (lazım olsa «Axtar»), sonra yenidən hesablayın — AMMO sorğunu öyrənəcək. Və ya «Mənbələr» → depozit Excel-ini atın.'
          : e.code === 'parse' ? 'ƏDV depozit cavabının sütunları tanınmadı — «Mənbələr» → depozit Excel-ini atın (və ya «Diaqnostika» faylını AMMO-ya göndərin).'
          : 'ƏDV depozit hesabı portaldan oxunmadı (' + (e.message || e) + '). «Mənbələr» → depozit Excel-ini atın.';
        notes.unshift(why);
      }
    }

    return {
      inputs: {
        invoices, decls: decls.filter((x) => x && !x.__error), range: { from, to }, obligation: obl, today, ownTin: tin, notes, deposit, created: Date.now(),
        declDrafts: picked.filter((x) => x.drafts).map((x) => x.k),
      },
    };
  }

  // ------------------------------------------------------------------ nəticə səhifəsi üçün körpü (yalnız oxuma)
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== 'AMMO_EVEZ_API') return false;
    if (sender.id !== chrome.runtime.id) return false;
    (async () => {
      if (msg.op === 'detail') return API.invoiceDetail(String(msg.id), msg.sourceSystem ? String(msg.sourceSystem) : '');
      if (msg.op === 'serial') return API.findBySerial(String(msg.serial).replace(/[^A-Za-z0-9]/g, ''));
      if (msg.op === 'tin') return { tin: ownTin() };
      if (msg.op === 'deposit') return vatAccountOps(String(msg.from), String(msg.to));
      throw new Error('naməlum əməliyyat');
    })().then((data) => sendResponse({ ok: true, data }), (e) => sendResponse({ ok: false, error: e && e.message ? e.message : String(e), status: e && e.status }));
    return true;
  });

  root.AMMO_EVEZ_PORTAL = { collect, ownTin, savedObligation, OBL_KEY, vatAccountOps, substDates, walkEntries, TPL_KEY };
})(typeof globalThis !== 'undefined' ? globalThis : this);
