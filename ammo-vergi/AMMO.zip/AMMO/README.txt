AMMO — Vergi xidmətləri (Chrome genişlənməsi) v1.23.3

QURAŞDIRMA (işçi kompüteri — bir dəfə)
1. ZIP-i açın (məs. C:\AMMO). chrome://extensions → «Developer mode» → «Load unpacked» → AMMO qovluğu.
2. AMMO qovluğundakı AMMO-Yenile.exe-ni bir dəfə işə salın — avtomatik yeniləmə qurulur
   (Chrome və Edge üçün; Windows açılanda özü yoxlayır). Sonrakı versiyalar özü gəlir.
3. Portalda AMMO düyməsinə basın → AMMO SUITE hesabı ilə (e-poçt + şifrə) daxil olun.

v1.23.3 (YENİ)
  • WhatsApp oxuması «Receiving end does not exist» ilə kəsilirdi: Chrome arxa plandakı tabı dondururdu (taymerlər
    dəqiqədə 1 dəfəyə enir, sonra tab yaddaşdan atılır). İndi oxunan tab qısa müddət önə çıxarılır, dondurulmur və
    oxuma bitəndə analiz səhifəsinə qayıdılır.
  • E-poçt: Gmail bölməsi brauzerdə daxil olunmuş BÜTÜN Gmail hesablarını oxuyur (bbec.tm, bbec.mmc …) + Yahoo —
    yəni Outlook-a qoşulan 3 poçtun hamısı. (Yeni Outlook proqramının içini genişlənmə oxuya bilmir — eyni poçtlar
    birbaşa Gmail / Yahoo-dan götürülür.)

v1.23.2 (YENİ)
  • Sosial analiz — WhatsApp: «message channel closed» xətası aradan qaldırıldı. Səbəb: bütün oxuma bir uzun sorğu
    idi və Chrome onu 5 dəqiqədən sonra kəsirdi. İndi analiz səhifəsi WhatsApp tabı ilə birbaşa danışır: əvvəl
    söhbət siyahısı, sonra cavabsız söhbətlər 6-6 oxunur (hər addım jurnalda görünür). Söhbətlər siyahıdan bir
    keçidlə açılır — əvvəlkindən bir neçə dəfə sürətli.

v1.23.1 (YENİ)
  • Mal qalığı — qayda dəqiq: şirkətin yarandığı gündən BÜTÜN gələn qaimələr + alış aktları + gömrük idxalı
    − BÜTÜN göndərilən qaimələr, mal kodu üzrə. Qaimənin növünə və «mal/xidmət» işarəsinə görə heç nə atılmır
    (təchizatçılar dizel, sement, boru kimi malları tez-tez 99… xidmət kodu ilə yazır). Yalnız avans və ləğv
    edilmiş/passiv qaimələr daxil deyil. Cədvəldə «Bütün kodlar / Mal kodları / Xidmət kodları» süzgəci.
  • Daxil olan pullar (804): portal yeni sadələşdirilmiş bəyannaməni açanda xanaları özü doldurur (prefill) —
    AMMO həmin dəyəri götürür, köməkçi bəyannaməni dərhal silir. Bitməmiş rüb göstərilmir.
  • Sosial analiz: WhatsApp «Səhifə cavab vermədi» xətası aradan qaldırıldı (açıq taba oxuyucu özü yerləşdirilir,
    F5 lazım deyil). Yahoo Mail əlavə olundu (gələnlər + göndərilənlər — cavab verilibmi).
  • Sənəd dövriyyəsi: vergi orqanının ADOC məktubları — «Qapalı Səhmdar Cəmiyyəti» kimi formalar, «No: …» nömrəsi,
    sənədin öz başlığı, imza blokundakı vergi orqanı (kontragent), cavab müddəti (5 iş günü → tarix), məbləğ,
    bəyannamə/dövr qeydi oxunur; ünvan sahibi şirkət sahib (subyekt) kimi avtomatik seçilir.

v1.23.0
  • Vahid, gözü yormayan dizayn: bütün panellər və səhifələr eyni sakit dəniz-yaşılı palitrada.
  • «Asan İmza Pro» paneli silindi.
  • Giriş, idarəetmə paneli, versiya və yeniləmə (AMMO SUITE kimi): admin panelləri işçilərdə bağlaya,
    yalnız seçilmiş e-poçtlara aça, istifadəçini dayandıra, cihazların versiyasını görə bilir.
    Yeni versiya çıxanda işçidə banner: 60 san. geri sayım → «İndi yenilə» / «5 dəq sonra». Məlumat itmir:
    yeniləmədən əvvəl hər şey Firebase-ə (Konsalting) yazılır və ehtiyat nüsxə (AMMO_backup) saxlanır.
  • Sənəd dövriyyəsi: ADOC/EDOC/ASiC (e-imzalı), ZIP, skan PDF (OCR aze+rus+eng), Word, Excel, şəkil oxunur.
    Yeni növlər: məhkəmə (qətnamə, qərardad, iddia, çağırış, icra vərəqəsi...), vergi orqanı (uyğunsuzluq
    bildirişi, tələb, sanksiya qərarı), müqavilə növləri (icarə, alqı-satqı, xidmət, podrat...). Sənəddəki
    şirkətlər çıxarılır — birini seçəndə sənəd o şirkətin qovluğuna özü düşür. Arxiv Firebase-də saxlanır.
  • İlkin audit:
     – Mal qalığı mal kodu üzrə, şirkətin qeydiyyat tarixindən bu günə: alış qaimələri + alış aktları
       + gömrük idxalı − satış qaimələri (qaytarmalar və düzəliş qaimələri nəzərə alınır).
     – Bəyannamələr: yalnız Təsdiqlənmiş və Uyğunsuzluq; təsdiqlənmişdə «necə»: Adi / Kameral / Analoji.
     – Gəlir · xərc · mənfəət: mənfəət bəyannaməsindən yox, real sistem məlumatından (qaimə, akt, gömrük, maaş).
     – Şirkət profili, Borclar, Məktublar açıq portal sessiyasından avtomatik oxunur (əlavə düymə yoxdur).
     – Daxil olan pullar: hər rüb üçün sadələşdirilmiş bəyannamənin 804-cü sətri arxa planda oxunur
       (yoxdursa köməkçi qaralama yaradılır və dərhal silinir, heç nə təqdim edilmir).
  • Yeni «Sosial şəbəkə analizi»: Gmail, WhatsApp Web, Telegram Web — cavabsız sual və tapşırıqlar
    tarixləri ilə hesabat şəklində; sətrə basanda həmin yazışma açılır. Excel ixracı.

BÖLMƏLƏR
- v1.22.3 (YENİ):
  • Profil qısa və konkret: «Bank hesablar» — yalnız bankların adları (alt-alta, hesab sayı və valyutalar kiçik yazı ilə);
    «Mükəlləfiyyətlər» — yalnız vergi növü və yaranma dövrü. Uzun mətnlər 12 sətirdən sonra «Daha … sətir» altında.
  • Boş tablar (Kassa aparatları, POS-terminallar, Lisenziyalar): AMMO portalı 15 saniyəyə qədər yenidən gözləyir;
    yenə boşdursa, səbəbi yazılır (portalın öz cavabı ilə) — yəni şirkətin adına həmin qeyd yoxdur.
  • Daxil olan pullar (hasilat): satış qaimələri yox — 804 (bank + POS daxilolmaları). Sadələşdirilmiş bəyannaməsi
    olmayan şirkətdə: portalda sadələşdirilmiş bəyannamə formasını rüb üçün açmaq kifayətdir (təqdim etmədən) —
    AMMO 804-ü portalın cavabından dərhal götürür. Əlavə olaraq ƏDV bəyannamələri üzrə dövriyyə (müqayisə üçün).
  • Hər bölmənin öz rəngi və nişanı — başlıqlar və sol menyu bir-birindən seçilir.
- v1.22.2 (YENİ):
  • Bəyannamə statusları portaldakı kimi: AMMO portalın «Bəyannamələr» siyahısı səhifəsi açılanda statusların və
    bəyannamə növlərinin dəqiq adını oradan öyrənir (məs. FILED kodu əvəzinə portalın öz yazısı) və İlkin audit-də
    eyni adları göstərir. Hər vergi növündə forma + status birlikdə: «Cari · Təsdiqlənmiş 9», «Dəqiqləşdirilmiş · …».
  • Şirkət profili tabları alt-alta, səliqəli: «ad — dəyər» sətirləri, cədvəlin hər sətri ayrıca nömrəli kart.
    Səhifənin menyusu/başlığı artıq tab məzmununa qarışmır. Köhnə oxunuş varsa — «Profili yenilə».
  • Sadələşdirilmiş bəyannaməsi olmayan (ƏDV ödəyicisi) şirkətlər üçün «Daxil olan pullar» bölməsində izah.
- v1.22.1 (YENİ):
  • «Təqdim edilməmiş bəyannamə» səhv sayı düzəldildi: əvvəl seçilmiş ildən sonrakı bəyannamələr nəzərə alınmırdı
    (məs. 2025 seçiləndə 2026-nın təqdim edilmiş ƏDV, Muzdlu iş, ÖMV bəyannamələri «təqdim edilməyib» görünürdü).
    İndi siyahılar bu ilə qədər oxunur, təkrarlar çıxarılır, nəticə yalnız seçilmiş dövr üzrə göstərilir; siyahısı
    alınmayan il «yoxlanılmadı» kimi işarələnir. Köhnə nəticəni yox, «Hazırla» ilə YENİDƏN hazırlanmış nəticəyə baxın.
  • AMMO Gömrük pəncərəsində «📦 İlkin audit-ə göndər» düyməsi: mal sətirləri (kod, miqdar, ölçü vahidi, gömrük dəyəri,
    ƏDV) Mal qalığına düşür; açıq İlkin audit səhifəsi özü yenilənir.
  • Mal qalığı və İşçilər bölmələrində addım-addım kartlar: «Gömrük saytını aç / AMMO Gömrük», «ƏMAS-ı aç» — məlumat
    gələndə kart yaşıl olur, nə vaxt və neçə sətir gəldiyini göstərir.
  • Şirkət profili daha etibarlı tanınır (tab adlarının fərqli yazılışları, saylar, role=tab); profil səhifəsində sol altda
    «🏢 AMMO · Profili İlkin audit-ə oxu» düyməsi.
- İlkin audit 2.0 (YENİ, v1.22.0): paneldə «İlkin audit» → İl / Tarix aralığı / Bütün illər → «Hazırla». Nəticə səhifəsində:
  • Ümumi baxış — gəlir, xərc, mənfəət, vergi, daxil olan pullar, ƏDV qalığı və hüququ, depozit qalığı, təqdim edilməmiş
    bəyannamələr, vergi borcu, oxunmamış məktublar, işçi sayı, mal qalığı (hər karta basın — bölmə açılır).
  • Şirkət profili — rəhbər, VÖEN, FİN, qeydiyyat, ünvan, əlaqə + Əsas məlumatlar, Obyektlər, Lisenziyalar, Reyestr,
    Filiallar, Kassa aparatları, Bank hesablar, Mükəlləfiyyətlər, POS-terminallar. Portalda Şəxsi kabinet → Əsas məlumatlar
    səhifəsini BİR DƏFƏ açın — AMMO tabları özü bir-bir açıb oxuyur (7 gündən bir yenilənir, «Profili yenilə» düyməsi də var).
  • Bəyannamələr — illər üzrə; hər vergi növü üçün statuslar sayı ilə (məs. ƏDV · Təsdiqlənmiş 9, Kameral 1, Qaralama 1);
    statusa basın — ay/il/növ/məbləğ siyahısı və «PDF aç». «Qalan / təqdim edilməmiş» siyahısı: müddəti keçmiş, qaralamada qalan.
  • Gəlir · xərc · mənfəət — təqdim edilmiş mənfəət (gəlir) bəyannaməsinin bütün sətirləri + qaimələrlə müqayisə və fərq.
  • Mal qalığı — alış qaimələri + alış aktları + gömrük (AMMO Gömrük Excel-i) + qaytarmalar − satış qaimələri: miqdar,
    orta alış qiyməti, qalığın dəyəri, marja, mənfi qalıq xəbərdarlığı. Gömrük saytına və AMMO Gömrük-ə keçid.
  • Daxil olan pullar — sadələşdirilmiş bəyannamənin 804-cü sətri, 1-4-cü rüblər və «Daxil olmuş pullar cəmi»
    (həmin rübün qaralaması kifayətdir), satış qaimələri ilə müqayisə.
  • ƏDV və depozit — yaranan, əvəzləşən, qalan, hüququ var/yoxdur, büdcəyə ödənilməli, depozit qalığı və hərəkəti.
  • Borclar — «Şəxsi hesab vərəqəsi» səhifəsi açılanda borc / penya / artıq ödəniş cədvəli avtomatik götürülür.
  • Məktublar — oxunmamışların sayı (məktublar səhifəsi açılanda).
  • İşçilər — vahid bəyannamədən say və əmək haqqı fondu; ƏMAS-da «👥 İşçiləri İlkin audit-ə göndər» → ad, FİN, vəzifə, maaş.
  Hamısı Excel-ə (bölmələr ayrı vərəqlərdə) və çapa. Portalda yeni məlumat oxunanda açıq səhifə özü yenilənir.
- v1.22.0 düzəlişlər: «Portaldan yenidən çək» → «Server xətası (404)» (sorğu ünvanı ikiqat /api/po alırdı) düzəldildi; öyrənilmiş
  sorğu yararsızdırsa avtomatik silinir. Depozit Excel-i: bütün vərəqlər yoxlanılır, başlıq daha çevik tanınır
  (VÖEN + tarix + mədaxil/məxaric), tanınmasa faylın ilk sətirləri xəta mesajında göstərilir.
- v1.21.2 düzəliş: «Sistemdə xəta baş verdi» (portalın HTTP 500 cavabı).
  Səbəb: v1.21.1-də qaimələr eyni anda 3 paralel sorğu ilə yüklənirdi — portal bir sessiyadan paralel axtarışlarda xəta qaytarır.
  İndi: axtarışlar ARDICIL gedir (eyni anda ən çox 2 sorğu); əvvəl il üzrə, portal xəta versə həmin il AY-AY, ay da alınmasa
  YARIM AY hissələrlə; 500/502/503/504/429 və vaxt bitməsində 4 dəfəyədək artan fasilə ilə təkrar; səhifə ölçüsü avtomatik
  kiçilir; portal status siyahısını qəbul etməsə — tam siyahı ilə istəyib özü süzür.
  Xəta yenə olarsa: mesajda HTTP kodu, mərhələ və tarix aralığı göstərilir, «Xəta hesabatını yüklə» faylını AMMO-ya göndərin.
- v1.21.1 düzəliş: «Portal cavab vermir (vaxt bitdi)» xətası. Qaimə və aktlar indi AY-AY (3 paralel sorğu) yüklənir,
  hər sorğu ləng cavabda 3 dəfə (45 / 75 / 110 san) təkrarlanır, səhifə ölçüsü avtomatik kiçildilir (100 → 50 → 25),
  portalın 502/503/504 cavablarında da təkrar cəhd edilir. Mənfəət/Gəlir hesabatı, ƏDV Əvəzləşməsi, İlkin audit,
  Elektron Qaimələr — hamısı bu yeni yükləmədən istifadə edir.
- ƏDV Əvəzləşməsi — ƏVƏZLƏŞMƏ HÜQUQU (YENİ, v1.21.0):
  1. Paneldə «ƏDV depozit hesabını portaldan avtomatik çək» seçilidir: AMMO seçilmiş tarixdən bu günə qədər ƏDV depozit
     hesabının (new.e-taxes.gov.az/eportal/vat-account) əməliyyatlarını özü oxuyur — Excel yükləməyə ehtiyac yoxdur.
     İlk dəfə AMMO depozit səhifəsini fonda açıb portalın sorğusunu öyrənir. Alınmasa: portalda «ƏDV depozit hesabı»
     səhifəsini bir dəfə açın (əməliyyatlar görünsün, lazım olsa «Axtar») — sonra hər dəfə avtomatik işləyir.
  2. Əvəzləşməyən qaimələr iki yerə bölünür (VM 175.1):
     • ƏVƏZLƏŞMƏ HÜQUQU VAR — ƏDV depozit hesabından həmin təchizatçıya MƏXARİC olub (qaimə üzrə), amma bəyannamədə
       əvəzləşdirilməyib: məbləğ, ödəniş tarixi və hansı ayın bəyannaməsində (308) əvəzləşdirilməli olduğu göstərilir.
     • ƏVƏZLƏŞMƏ HÜQUQU YOXDUR — ƏDV depozitdən ödənilməyib (və ya qismən ödənilib, ya da qaimə passivdir); həmin
       təchizatçıya qaiməyə bağlanmamış ödəniş varsa ayrıca qeyd olunur.
  3. Nəticə səhifəsində yeni «Əvəzləşmə hüququ» bölməsi, yuxarıda iki kart, Excel-də «Hüququ var-əvəzləşməyib»,
     «Hüququ yoxdur», «Depozit əməliyyatları» vərəqləri. «Mənbələr» → «Portaldan yenidən çək», Excel ilə əvəz etmək,
     «Diaqnostika faylı» (depozit sütunları tanınmasa — AMMO-ya göndərmək üçün).
- Vergi hesabatları (YENİ, v1.20.0): paneldə «Vergi hesabatları» — üzərinə gələndə aşağı açılır:
  «MƏNFƏƏT HESABATI» (hüquqi şəxslər, VM 103-106, 20%) və «GƏLİR HESABATI» (fərdi sahibkarlar, VM 99-102: 20% / 14%).
  1. İli seçin (2026, 2025, …) və «Doldur» basın. AMMO portaldan avtomatik oxuyur:
     gəlirlər — satış e-qaimələri (mal → topdan satış, xidmət → iş/xidmət, icarə → daşınmaz əmlakın icarəsi), alıcı qaytarmaları çıxılır;
     xərclər — alış e-qaimələri və aktlar sətir adına görə maddələrə (malın dəyəri, icarə: hüquqi/fiziki şəxs, enerji, qaz, yanacaq,
     su, rabitə, mühafizə, bank, reklam, təmir, nəqliyyat, sığorta, sair); əmək haqqı və DSMF — muzdlu iş bəyannamələrindən;
     Əlavə 1 — əvvəlki ilin bəyannaməsindəki «hesabat dövrünün sonuna» qalıqları bu ilin «əvvəlinə» sütununa;
     keçmiş illərin zərəri (VM 121: hüquqi şəxs 5 il, FS 3 il) — 240.1-240.5 / 1244;
     mikro sahibkar güzəşti 75% (VM 106.1.20 / 102.1.30) — orta aylıq işçi sayı və gəlir meyarı yoxlanılır.
  2. Bəyannamə yeni tabda portalın maketi ilə eyni açılır: Bölmə 1, Hissə 1 Gəlirlər, Hissə 2 Xərclər, Hissə 3 Verginin hesablanması,
     Əlavə 1 Aktivlər və Kapital — eyni kodlar, eyni sətir adları, eyni sütunlar. Bütün cəmlər portalın düsturları ilə canlı hesablanır.
     Xananı dəyişin — nəticə dərhal yenilənir (sarı — əl ilə dəyişdirilib, mavi xətt — portaldan avtomatik, boz — düstur).
     «mənbə» — sətrin hansı qaimələrdən yığıldığını göstərir. «Malların hərəkəti» — ilin sonuna qalığı yazın, malın dəyəri yenilənir.
     Yoxlamalar: aktiv = kapital+öhdəlik, mənfi məbləğ, zərər limiti, təqdim etmə müddəti (31 mart).
  3. «⇢ Doldur — e-taxes»: portalda açıq saxladığınız bəyannamənin xanaları AMMO-dakı dəyərlərlə dolur (kod və sətir adı ilə tapılır).
     Portalda digər bölməyə (Hissə 3, Əlavə 1 …) keçəndə həmin bölmə də avtomatik dolur. Portalın öz səhifəsində də
     sol aşağıda «AMMO · Doldur» düyməsi var. Təqdim etmə və ASAN İmza həmişə sizin tərəfinizdən edilir.
  4. Excel (bütün bölmələr + qaimə sətirləri), XML (Mənfəət — e-taxes oflayn formatı MENFEET_1), Çap.
  Qeyd: nağd xərclər, amortizasiya, bank komissiyaları və POS (kassa) satışları portalda e-qaimə kimi görünmür — əl ilə əlavə edin.
- ƏDV Əvəzləşməsi (YENİ, v1.19.0): paneldə «ƏDV Əvəzləşməsi».
  1. İl seçin: «★ Bütün illər» — ƏDV mükəlləfiyyətinin başladığı aydan (məs. İyul 2024) bu günə (və ya mükəlləfiyyət
     bitibsə — bitmə ayına) qədər; və ya konkret il; və ya iki tarix aralığı. «Əvəzləşməni hesabla» basın.
     Mükəlləfiyyət tarixi: portalda Şəxsi kabinet → «Mükəlləfiyyətlər» bölməsini BİR DƏFƏ açın — AMMO «Əlavə dəyər vergisi /
     Aylıq / 11.07.2024 / İyul 2024» sətrini özü oxuyub yadda saxlayır. Açılmayıbsa ilk ƏDV bəyannaməsinin ayı götürülür.
  2. Arxa planda: hər ay üçün son (qüvvədə olan) ƏDV bəyannaməsi açılır, Əlavə 1-dəki qaimələr (308, 314, 316) və yük gömrük
     bəyannamələri (310) oxunur, alış qaimələri (gələnlər) ilə seriya-nömrə üzrə tutuşdurulur.
  3. Nəticə səhifəsi: əvəzləşmə faizi, aylar/illər üzrə rəngli xəritə (yaşıl — hamısı əvəzləşib, sarı — qismən,
     qırmızı — əvəzləşməyən var, ştrixli — bəyannamə yoxdur), qrafik, «Diqqət» kartları; Qaimələr, Təchizatçılar,
     Gömrük (YGB), Əlavə 1 — tapılmayan, Depozit — bağlanmayan, Bəyannamələr, Qanunvericilik bölmələri.
     Hər qaimə: ƏDV, əvəzləşən, qalıq, hansı ayda əvəzləşib, vəziyyət (tam / qismən / əvəzləşməyib / artıq).
  4. Qaimənin seriya-nömrəsinə basın — kart açılır: kimdən, nə vaxt, mallar/xidmətlər (portaldan), ödəniş və əvəzləşmə
     tarixçəsi, «Nə etməli» tövsiyəsi.
  5. «Mənbələr»: ƏDV depozit hesabının əməliyyatları (portalın Excel-i) — «ödənilib, amma əvəzləşdirilməyib» qaimələri
     (geri alına bilən ƏDV), avans ödənişləri; gömrük — e.customs.gov.az açıqdırsa bir kliklə və ya AMMO Gömrük Excel-i.
  6. Excel: Xülasə, Aylar, Qaimələr, Əvəzləşməyənlər, Ödənilib-əvəzləşməyib, Əvəzləşmə tarixçəsi, Təchizatçılar, Gömrük…
  Portala heç nə yazılmır — yalnız oxunur. e-taxes tabı açıq qalmalıdır (mal sətirləri üçün).
  v1.19.0: Excel oxuyucusunda boş xanaların növbəti xananın dəyərini «udması» xətası düzəldildi (ƏDV Analiz də daha dəqiq).
- ƏMAS paneli (YENİ, v1.18.0): eroom.e-social.gov.az saytında sağ tərəfdə «AMMO ƏMAS» düyməsi.
  Yalnız OXUYUR — heç bir sənəd yaratmır, dəyişmir, imzalamır. Sorğular portalın öz funksiyası ilə gedir.
  1. «Reyestrlər → Excel»: lazım olanları seçin və «Hamısını doldur → Excel» basın — hər reyestrin BÜTÜN səhifələri
     çəkilir, bir Excel faylında ayrı vərəqlərə yazılır (+ «Mündəricat» vərəqi). Hər reyestri tək də yükləmək olar.
     Əmək müqaviləsi: Əmək müqaviləsinə dəyişiklik (bütün dəyişiklik sənədləri + əvvəlki maaş və fərq),
     Qüvvədən düşən, Vətəndaşa təsdiq üçün göndərilən, İcrada olan, Müddəti bitən qüvvədə olan müddətli,
     Qüvvədə olan, Ləğv edilmiş (işəgötürən + sistem), İmzaya göndərilən, İşçinin köhnə əmək müqavilələri.
     Əmrlər: Etibarlı xitam əmrləri, Bütün məzuniyyət əmrləri (əmrin içindən: tarixlər, əsas/əlavə gün, iş ili,
     hüquqi əsas), Məzuniyyət əmrləri (növlər üzrə), Bütün ezamiyyə əmrləri. Əlavə: Məzuniyyət günləri,
     Geri çağırılma, Digər əmrlər, İcra gözləyən xitam əmrləri.
     İcazəniz olmayan reyestr (portal: PERMISSION_ERROR) Excel-də səbəbi ilə qeyd olunur.
  2. «Məzuniyyətdən qalan işçilər» → «Doldur»: hər işçi üçün iş illəri üzrə hüquq / istifadə / qalıq, istifadə
     etmədiyi illər, son məzuniyyət, əmr sayı və maaş tarixçəsi (nə vaxt neçə idi → indi neçədir, fərq AZN və %).
     Filtrlər: qalığı olanlar, heç istifadə etməyənlər, maaşı dəyişənlər. «Excel»: Xülasə, İş illəri üzrə,
     Maaş tarixçəsi, Qaydalar vərəqləri.
     «Hesablama dövrü»: bütün staj / son 1-2-3-5 iş ili / seçilmiş tarixdən. ƏMAS-da yalnız elektron məzuniyyət
     əmrləri olduğu üçün kağız əmrlə verilmiş köhnə məzuniyyətlər görünmür — köhnə illəri buradan çıxara bilərsiniz.
  Qeyd: Chrome 111 və ya daha yeni versiya lazımdır.
  v1.18.1: «Portal hələ yüklənməyib» xətası düzəldildi (portal «magus» obyektini window-a yazmır).
- Gömrük bəyannamələri (YENİ, v1.17.1): e.customs.gov.az saytında sağ tərəfdə «AMMO Gömrük» düyməsi.
  1. e.customs.gov.az-a Asan İmza ilə daxil olun, «AMMO Gömrük» düyməsini basın — yeni pəncərə açılır.
  2. İli seçin (və ya başlanğıc / son tarixi yazın) və «Doldur» düyməsini basın.
  3. «Excel yüklə» — hər GB bir sətir: №, əməliyyat tarixi, GB nömrəsi, göndərən, malın adı, kodu, miqdarı, ölçü vahidi,
     invoys dəyəri, valyuta, məzənnə, ödəniş kodu, nəqliyyat nömrəsi, gömrük dəyəri, statistik dəyər, daşıma xərci və
     bütün ödəniş kodları (01…19 yığımlar, 20…26 rüsumlar, 30/32 aksiz və ƏDV, 91…87 digər) — 3 sətirli başlıqla.
  Qeyd: gömrük tabı açıq qalmalıdır. Ödənişlər GB-nin 47-ci qrafasının «B» bölməsindən götürülür.
  Daşıma xərci = gömrük dəyəri (qr.12) − invoys dəyəri (qr.22) × məzənnə.
- Elektron Qaimələr: TaxPro formatında hesabat — hər mal/xidmət sətri ayrıca, 33 sütun, sonda "Cəmi" sətri.
- Elektron Qaimələrin Qaytarılması: "ƏDV qaytarmaq üçün qaimə" bölməsinin siyahısı.
- Aktlar: elektron alış aktları (status və növ filtri).
- Bəyannamələr: 7 vergi növü, il, ay aralığı, öncəki/qaralama/kameral-dəqiqləşdirilmiş seçimləri. Nəticə TaxPro formasında
  (ƏDV — bütün aylar bir geniş cədvəldə; Mənfəət, Muzdlu iş, ÖMV — bölmələr üzrə), istəyə görə PDF-lər də yüklənir.
- HF və TTA: EQF nömrələri üzrə Word (.docx) sənədləri — Təhvil-təslim aktı (_TTA), Qiymət razılaşdırma protokolu (_RP),
  Hesab-faktura (_HF), Qeydlər (_QEYD). Hamısı documents_TARİX.zip kimi yüklənir.
- Sub-uçot Köçürmələr: ödənişin əsas hesab və ƏDV depozit hesabı arasında bölgüsü (qaimə və avans üzrə).
- Sürətli təqdim etmə: portalın Qaralamalar bölməsində bütün qaralamaları seçib "Təqdim etmə"ni açır.
  İmzalama həmişə sizin tərəfinizdən ASAN İmza ilə edilir.

- Sənəd hazırla (YENİLƏNİB, v1.14.0): müqavilə hazırlama pəncərəsi (paneldə "Sənəd hazırla" → "pəncərəsini aç").
  1. Tərəflər — SOL və SAĞ tərəf yan-yana. Hər tərəf üçün 3 xana: şəxsiyyət vəsiqəsi, şirkət (və ya fərdi sahibkar)
     məlumatları, bank rekvizitləri. Mətni kor (xam) formada yapışdırın — ad/soyad/ata adı, FİN, sənəd nömrəsi,
     şirkətin adı, forma (MMC/ASC), VÖEN, ünvan, direktor, bank, kod, bankın VÖEN-i, M/h, SWIFT, H/h avtomatik
     tapılıb yerinə yazılır (yaşıl işarələrlə göstərilir). Tərəf növü: hüquqi şəxs, fərdi sahibkar, fiziki şəxs.
     Vəsiqənin şəklini atın — imza vəsiqədən götürülür; möhürü əlavə edən kimi imzanın üstünə qoyulur.
  2. Məbləğ və şərtlər — əsas məbləğ (rəqəm + sözlə), valyuta, ƏDV (daxil / xaric / cəlb edilmir), şablonun
     sahələri və "Xüsusi şərtlər" (hər sətir ayrıca bənd).
  3. Mətn — bölmə və bəndlər (alt bəndlər 1.1.1 avtomatik nömrələnir).
  4. Sənəd — nömrə, tarix, şəhər; Word (.docx) və PDF yükləmə.
  Öz müqavilənizi yükləyin (Word .docx, köhnə Word .doc, PDF, .txt): başlıq, nömrə, şəhər/tarix, rolların adları,
  preambula, bölmə/bənd/alt bəndlər avtomatik təyin olunur; məbləğlər, tarixlər və "____" boşluqları sahəyə çevrilir;
  faylın rekvizit hissəsindən tərəflərin məlumatları götürülür. Struktur şablon kimi yadda qalır.
  Rekvizitlər bütün müqavilələrdə eyni səliqəli cədvəldədir: iki sütun, sətirlər hizalı, imza və möhür altda.
  Tərəflər kitabı (★ bizim şirkət — hər yeni müqavilədə avtomatik sol tərəf). 12 hazır şablon.

- Sənəd dövriyyəsi (YENİ, v1.15.0): elektron arxiv və kargüzarlıq (paneldə "Sənəd dövriyyəsi" → "Sənəd dövriyyəsini aç").
  1. Yükləyin: PDF, Word (.docx/.doc), Excel (.xlsx), .odt, .rtf, .txt, şəkil/skan (OCR), ZIP arxivi — bir neçə faylı birdən,
     səhifənin istənilən yerinə atmaqla və ya Ctrl+V ilə.
  2. AMMO sənədi oxuyur və özü təyin edir: növü (50-yə yaxın növ — hesab-faktura, EQF, qiymət razılaşdırma protokolu,
     təhvil-təslim, görülmüş işlər və üzləşmə aktları, müqavilə, əlavə razılaşma, əmək müqaviləsi, ərizə, əmr, arayış,
     tabel, hesablama-ödəmə cədvəli, bəyannamə, vergi bildirişi, nizamnamə, etibarnamə və s.), kateqoriyanı (Kargüzarlıq,
     Müqavilələr, Maliyyə və mühasibat, Kadrlar, Vergi və hesabatlar, Təsis sənədləri), SAHİBİNİ — hüquqi və ya fiziki
     şəxs (VÖEN, FİN, ad və alternativ adlar üzrə; VÖEN-in son rəqəmi 1 — hüquqi, 2 — fiziki), kontragenti, əməkdaşı,
     nömrəni, tarixi, dövrü (ay), məbləği, valyutanı, müqavilənin bitmə tarixini, istiqaməti (daxil olan / çıxan / daxili).
  3. "Sənəd dövriyyəsinə göndərilsin?" — məlumatları yoxlayın, lazım olsa düzəldin, "Göndər" (və ya "Hamısını göndər").
     Sənəd qeydiyyat nömrəsi alır (D-2026/0001, Ç-…, X-…) və qovluğa düşür: Subyekt › Kateqoriya › Növ.
     Tanınmayan sahibkar avtomatik subyekt kimi yaradılır; bir neçə sənəddə təkrarlanan tərəf "bizim müştəri" sayılır.
     Növü düzəltsəniz AMMO öyrənir və növbəti dəfə özü düz tanıyır. Eyni fayl ikinci dəfə yüklənəndə xəbərdarlıq edir.
  4. Axtarış: iki tarix arası (sənəd tarixi və ya yüklənmə tarixi), hazır dövrlər (bu ay, keçən ay, rüb, il), ad, şirkət,
     VÖEN, nömrə, kontragent, əməkdaş, məbləğ, status, teq və sənədin İÇİNDƏKİ mətn üzrə; cədvəl və kart görünüşü.
  5. Sənəd kartı: önizləmə (PDF, şəkil, Excel, mətn), bütün rekvizitlər bir kliklə kopyalanır, versiyalar, əlaqəli
     sənədlər (eyni nömrəli HF/TTA/RP və müqavilə avtomatik bağlanır), tarixçə, saxlama müddəti.
  6. Göndərmə (vergi orqanına, banka, auditora, kontragentə…): ZIP paket — müşayiət məktubu (Word, çıxan nömrə ilə
     jurnalda qeydə alınır), sənədlərin reyestri (Excel) və fayllar; e-poçt proqramı və ya Gmail açılır. Göndərişlər jurnalı.
  7. İdarə paneli: komplektlik nəzarəti (hər ay tabel, hesablama-ödəmə cədvəli, bank çıxarışı, bəyannamə var/yox),
     müddəti bitən müqavilə/etibarnamələr, son sənədlər. Excel reyestr, ZIP yükləmə, səbət, ehtiyat nüsxə və bərpa.
  Bütün sənədlər yalnız bu brauzerdə (IndexedDB) saxlanılır; vaxtaşırı "Ayarlar → Ehtiyat nüsxəni yüklə" edin.

- Sənəd dövriyyəsi — YENİLİKLƏR (v1.16.0):
  1. Öz sənəd növləriniz: "Sənədin növü" siyahısının sonunda "➕ Yeni növ yarat…" (və ya Ayarlar → "Öz sənəd növlərim").
     Ad, qovluq (mövcud və ya yeni qovluq), ikon, saxlama müddəti, "hər ay gözlənilən" və AÇAR SÖZLƏR — mətndə bu sözlər
     olan sənədləri AMMO özü həmin növə aid edir. Öz növlər siyahıda ★ ilə işarələnir; redaktə və silmək olar
     (silinən növün sənədləri "Digər sənəd"ə keçir).
  2. Bir neçə şirkət adı olan sənəd: AMMO sənəddəki bütün şirkət/şəxsləri (ad + VÖEN) kart kimi göstərir —
     "Bu sənəd hansı şirkətə aiddir?". Seçdiyiniz şirkət sahib olur, qarşı tərəf avtomatik kontragent yazılır,
     istiqamət yenidən hesablanır. Belə sənədlər heç vaxt soruşmadan göndərilmir. Arxivdəki sənədin kartında da
     (Redaktə) tapılan şirkətlər göstərilir — birinə basmaqla sənəd həmin şirkətə keçir.
  3. Yükləmələrin tutulması (v1.16.1): İSTƏNİLƏN brauzerdən (Google Chrome, Opera, Firefox, Edge, Yandex) və ya
     proqramdan (WhatsApp, Telegram, Viber, Outlook…) PDF, Word, Excel yüklənən kimi ekranın küncündə pəncərə çıxır:
     "Bu faylı Sənəd dövriyyəsi panelinə göndərmək istəyirsiniz?" [Bəli] [Xeyr]. "Bəli" → fayl AMMO-nun Sənəd
     dövriyyəsi panelinə avtomatik düşür, oxunur və qeydə alınır (bir neçə şirkət varsa — hansına aid olduğunu soruşur).
     Bunun üçün Windows köməkçisini BİR DƏFƏ quraşdırın: AMMO_Windows_komekci.zip → QURASDIR.cmd
     (və ya Sənəd dövriyyəsi → Ayarlar → "Windows köməkçisini yüklə"). Köməkçi Windows açılanda özü işə düşür,
     saatın yanında AMMO ikonu görünür. Fayl yalnız kompüterin daxilində (127.0.0.1) ötürülür.
     Köməkçi quraşdırılmayıbsa, sual yalnız Chrome yükləmələrində çıxır.
