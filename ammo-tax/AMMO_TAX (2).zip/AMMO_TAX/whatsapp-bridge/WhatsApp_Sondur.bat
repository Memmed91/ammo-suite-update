@echo off
rem AMMO SUITE - WhatsApp korpusunu sondurur
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0install.ps1" -Uninstall
