@echo off
rem AMMO SUITE - WhatsApp korpusu (bir defelik qurasdirma, admin lazim deyil)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0install.ps1"
