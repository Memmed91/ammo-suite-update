﻿# AMMO SUITE — WhatsApp körpüsü (Chrome Native Messaging host)
#
# AMMO SUITE (Chrome) -> bu skript -> kompüterdəki WhatsApp tətbiqi (whatsapp:// protokolu).
# Əmrlər:
#   { action:'ping' }                                         -> körpü və WhatsApp vəziyyəti
#   { action:'open', phone:'', text:'' }                      -> WhatsApp-ı açır (göndərmir)
#   { action:'send', phone:'994501234567', text:'...', restoreFocus:true }
#        -> { ok:true, verified:bool, method:'url'|'paste' }
#        -> { ok:false, code:'invalid'|'noapp'|'focus'|'notready'|'nosend'|'error', detail:'' }
#
# Təhlükəsizlik: Enter yalnız WhatsApp pəncərəsi önə gələndə basılır. Mümkün olduqda (UI Automation)
# yazı sahəsində məhz bu mesajın mətni olduğu yoxlanılır — başqa söhbətdəki qaralama göndərilmir.

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$HostVersion = '1.0.0'
$LogFile = Join-Path $PSScriptRoot 'ammo-wa-host.log'
$InvalidRx = '(?i)invalid|not on whatsapp|yanl[ıi]ş|etibars[ıi]z|d[üu]zg[üu]n deyil|недейств|неверн|ge[çc]ersiz'
$SearchRx = '(?i)search|axtar|поиск|arat|ara\b'

# ------------------------------------------------------------------ jurnal (mesaj mətni yazılmır)
function Write-Log([string]$Message) {
  try {
    if ((Test-Path -LiteralPath $LogFile) -and ((Get-Item -LiteralPath $LogFile).Length -gt 512KB)) {
      Move-Item -LiteralPath $LogFile -Destination ($LogFile + '.old') -Force
    }
    Add-Content -LiteralPath $LogFile -Value ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message) -Encoding UTF8
  } catch { }
}

# ------------------------------------------------------------------ Native Messaging (4 bayt uzunluq + UTF-8 JSON)
$script:StdIn = [Console]::OpenStandardInput()
$script:StdOut = [Console]::OpenStandardOutput()

function Read-Bytes([int]$Count) {
  $buf = New-Object byte[] $Count
  $off = 0
  while ($off -lt $Count) {
    $n = $script:StdIn.Read($buf, $off, $Count - $off)
    if ($n -le 0) { break }
    $off += $n
  }
  if ($off -lt $Count) { return $null }
  return , $buf
}

function Read-NativeMessage {
  $lb = Read-Bytes 4
  if ($null -eq $lb) { return $null }
  $len = [BitConverter]::ToInt32($lb, 0)
  if ($len -le 0 -or $len -gt 4MB) { return $null }
  $body = Read-Bytes $len
  if ($null -eq $body) { return $null }
  return ([Text.Encoding]::UTF8.GetString($body) | ConvertFrom-Json)
}

function Write-NativeMessage($Object) {
  $json = ConvertTo-Json -InputObject $Object -Compress -Depth 6
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $script:StdOut.Write([BitConverter]::GetBytes([int]$bytes.Length), 0, 4)
  $script:StdOut.Write($bytes, 0, $bytes.Length)
  $script:StdOut.Flush()
}

function Fail([string]$Code, [string]$Detail) {
  Write-Log ('FAIL {0} {1}' -f $Code, $Detail)
  return @{ ok = $false; code = $Code; detail = $Detail }
}

# ------------------------------------------------------------------ Windows pəncərə köməkçiləri
$script:WinCs = @'
using System;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;

public static class AmmoWaWin {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
  [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] private static extern bool BringWindowToTop(IntPtr hWnd);
  [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
  [DllImport("user32.dll")] private static extern int GetWindowTextLength(IntPtr hWnd);
  [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool attach);
  [DllImport("kernel32.dll")] private static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] private static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);

  public static IntPtr Foreground() { return GetForegroundWindow(); }

  public static string Title(IntPtr h) {
    int n = GetWindowTextLength(h);
    if (n <= 0) return "";
    StringBuilder sb = new StringBuilder(n + 2);
    GetWindowText(h, sb, sb.Capacity);
    return sb.ToString();
  }

  public static string ProcessName(IntPtr h) {
    uint pid;
    GetWindowThreadProcessId(h, out pid);
    try { return Process.GetProcessById((int)pid).ProcessName; } catch { return ""; }
  }

  public static bool IsWhatsApp(IntPtr h) {
    if (h == IntPtr.Zero) return false;
    string p = ProcessName(h);
    if (p.StartsWith("WhatsApp", StringComparison.OrdinalIgnoreCase)) return true;
    if (p.Equals("ApplicationFrameHost", StringComparison.OrdinalIgnoreCase))
      return Title(h).IndexOf("WhatsApp", StringComparison.OrdinalIgnoreCase) >= 0;
    return false;
  }

  public static bool ForegroundIsWhatsApp() { return IsWhatsApp(GetForegroundWindow()); }

  public static IntPtr Find() {
    IntPtr found = IntPtr.Zero;
    EnumWindows(delegate (IntPtr h, IntPtr l) {
      if (!IsWindowVisible(h) || GetWindowTextLength(h) == 0) return true;
      if (IsWhatsApp(h)) { found = h; return false; }
      return true;
    }, IntPtr.Zero);
    return found;
  }

  public static bool Activate(IntPtr h) {
    if (h == IntPtr.Zero) return false;
    if (IsIconic(h)) ShowWindow(h, 9);
    if (GetForegroundWindow() == h) return true;
    keybd_event(0x12, 0, 0x1, UIntPtr.Zero);
    SetForegroundWindow(h);
    keybd_event(0x12, 0, 0x1 | 0x2, UIntPtr.Zero);
    if (GetForegroundWindow() == h) return true;
    IntPtr fg = GetForegroundWindow();
    uint pid;
    uint fgThread = GetWindowThreadProcessId(fg, out pid);
    uint me = GetCurrentThreadId();
    bool attached = fgThread != 0 && fgThread != me && AttachThreadInput(me, fgThread, true);
    BringWindowToTop(h);
    SetForegroundWindow(h);
    if (attached) AttachThreadInput(me, fgThread, false);
    return GetForegroundWindow() == h;
  }
}
'@

$script:WinReady = $false
function Initialize-Win {
  if ($script:WinReady) { return }
  Add-Type -AssemblyName System.Windows.Forms
  if (-not ('AmmoWaWin' -as [type])) { Add-Type -TypeDefinition $script:WinCs -Language CSharp }
  $script:WinReady = $true
}

# ------------------------------------------------------------------ UI Automation (yazı sahəsinin mətnini oxumaq)
$script:UiaReady = $null
function Initialize-Uia {
  if ($null -ne $script:UiaReady) { return $script:UiaReady }
  try {
    Add-Type -AssemblyName UIAutomationClient
    Add-Type -AssemblyName UIAutomationTypes
    $script:UiaReady = $true
  } catch { $script:UiaReady = $false }
  return $script:UiaReady
}

# $null -> UIA işləmir; əks halda @{ type; name; text } (fokusdakı element)
function Get-FocusedInfo {
  if (-not (Initialize-Uia)) { return $null }
  try {
    $el = [System.Windows.Automation.AutomationElement]::FocusedElement
    if ($null -eq $el) { return $null }
    $text = ''
    $pat = $null
    if ($el.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$pat)) { $text = [string]$pat.Current.Value }
    if ([string]::IsNullOrEmpty($text)) {
      $pat = $null
      if ($el.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern, [ref]$pat)) { $text = [string]$pat.DocumentRange.GetText(20000) }
    }
    $ct = ''
    try { $ct = [string]$el.Current.ControlType.ProgrammaticName } catch { }
    $nm = ''
    try { $nm = [string]$el.Current.Name } catch { }
    return @{ type = $ct; name = $nm; text = $text }
  } catch { return $null }
}

function Find-InvalidDialog {
  if (-not (Initialize-Uia)) { return '' }
  try {
    $h = [AmmoWaWin]::Find()
    if ($h -eq [IntPtr]::Zero) { return '' }
    $root = [System.Windows.Automation.AutomationElement]::FromHandle($h)
    $cond = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::Text)
    $all = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
    $n = 0
    foreach ($e in $all) {
      $n++
      if ($n -gt 3000) { break }
      $nm = ''
      try { $nm = [string]$e.Current.Name } catch { }
      if ($nm -match $InvalidRx) { return $nm.Substring(0, [Math]::Min(160, $nm.Length)) }
    }
  } catch { }
  return ''
}

# ------------------------------------------------------------------ mətn müqayisəsi
# Emoji və xüsusi simvollar atılır (WhatsApp onları şəkil kimi göstərir), boşluqlar birləşdirilir.
function Get-Plain([string]$s) {
  if ([string]::IsNullOrEmpty($s)) { return '' }
  $sb = New-Object System.Text.StringBuilder
  foreach ($ch in $s.ToCharArray()) {
    if ([char]::IsWhiteSpace($ch)) { [void]$sb.Append(' ') }
    elseif ([int]$ch -lt 0x2000) { [void]$sb.Append($ch) }
  }
  return (($sb.ToString() -replace '\s+', ' ').Trim())
}

function Get-Needle([string]$Text) {
  $p = Get-Plain $Text
  if ($p.Length -gt 28) { $p = $p.Substring(0, 28) }
  return $p.Trim()
}

function Test-HasNeedle([string]$s, [string]$Needle) {
  if ([string]::IsNullOrEmpty($Needle)) { return $false }
  return ((Get-Plain $s).IndexOf($Needle, [StringComparison]::OrdinalIgnoreCase) -ge 0)
}

# Fokus yazı sahəsindədirmi (axtarış xanası deyil) və boşdurmu
function Test-EmptyCompose($Info) {
  if ($null -eq $Info) { return $false }
  if ($Info.type -notmatch 'Edit|Document') { return $false }
  if ($Info.name -match $SearchRx) { return $false }
  return ((Get-Plain $Info.text).Length -eq 0)
}

# ------------------------------------------------------------------ WhatsApp tətbiqi
function Get-WaProcess { return @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'WhatsApp*' }) }

function Test-WaInstalled {
  try { if (Get-AppxPackage -Name '*WhatsApp*' -ErrorAction SilentlyContinue) { return 'store' } } catch { }
  if (Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA 'WhatsApp\WhatsApp.exe')) { return 'desktop' }
  if (Test-Path -LiteralPath 'Registry::HKEY_CLASSES_ROOT\whatsapp') { return 'protocol' }
  return ''
}

function Wait-WaForeground([int]$Seconds) {
  $end = (Get-Date).AddSeconds($Seconds)
  while ((Get-Date) -lt $end) {
    if ([AmmoWaWin]::ForegroundIsWhatsApp()) { return $true }
    $h = [AmmoWaWin]::Find()
    if ($h -ne [IntPtr]::Zero) {
      [void][AmmoWaWin]::Activate($h)
      if ([AmmoWaWin]::ForegroundIsWhatsApp()) { return $true }
    }
    Start-Sleep -Milliseconds 400
  }
  return $false
}

function Save-ClipText {
  try { if ([System.Windows.Forms.Clipboard]::ContainsText()) { return [System.Windows.Forms.Clipboard]::GetText() } } catch { }
  return $null
}
function Set-ClipText([string]$Text) {
  for ($i = 0; $i -lt 6; $i++) {
    try { [System.Windows.Forms.Clipboard]::SetText($Text); return } catch { Start-Sleep -Milliseconds 150 }
  }
}

# Yazı sahəsindəki mətni bu mesajla ƏVƏZ edir (Ctrl+A, Ctrl+V) — mətn iki dəfə yazılmır
function Invoke-Paste([string]$Text) {
  if ($null -eq $script:SavedClip) { $script:SavedClip = @{ text = (Save-ClipText) } }
  Set-ClipText $Text
  Start-Sleep -Milliseconds 150
  [System.Windows.Forms.SendKeys]::SendWait('^a')
  Start-Sleep -Milliseconds 100
  [System.Windows.Forms.SendKeys]::SendWait('^v')
}

# ------------------------------------------------------------------ əmrlər
function Invoke-Ping {
  Initialize-Win
  $procs = @(Get-WaProcess)
  $pname = ''
  if ($procs.Count -gt 0) { $pname = [string]$procs[0].ProcessName }
  return @{
    ok        = $true
    host      = $HostVersion
    ps        = $PSVersionTable.PSVersion.ToString()
    installed = (Test-WaInstalled)
    running   = ($procs.Count -gt 0)
    process   = $pname
    window    = ([AmmoWaWin]::Find() -ne [IntPtr]::Zero)
    uia       = (Initialize-Uia)
  }
}

function Invoke-Open([string]$Phone, [string]$Text) {
  $digits = ($Phone -replace '\D', '')
  $url = 'whatsapp://'
  if ($digits) {
    $url = "whatsapp://send?phone=$digits"
    if ($Text) { $url += '&text=' + [Uri]::EscapeDataString($Text) }
  } elseif ($Text) {
    $url = 'whatsapp://send?text=' + [Uri]::EscapeDataString($Text)
  }
  try { Start-Process $url } catch { return (Fail 'noapp' $_.Exception.Message) }
  return @{ ok = $true }
}

function Invoke-Send([string]$Phone, [string]$Text, [bool]$RestoreFocus) {
  $digits = ($Phone -replace '\D', '')
  if ($digits.Length -lt 10 -or $digits.Length -gt 15) { return (Fail 'invalid' 'phone') }
  if ([string]::IsNullOrWhiteSpace($Text)) { return (Fail 'error' 'empty text') }

  Initialize-Win
  $uia = Initialize-Uia
  $prev = [AmmoWaWin]::Foreground()
  $prevIsWa = [AmmoWaWin]::IsWhatsApp($prev)
  $running = (@(Get-WaProcess).Count -gt 0)
  $needle = Get-Needle $Text
  $enc = [Uri]::EscapeDataString($Text)
  $paste = ($enc.Length -gt 1800)        # çox uzun mətn URL-ə sığmır -> yapışdırma üsulu
  $url = "whatsapp://send?phone=$digits"
  if (-not $paste) { $url += "&text=$enc" }
  Write-Log ('send ...{0} len={1} paste={2} running={3} uia={4}' -f $digits.Substring($digits.Length - 4), $Text.Length, $paste, $running, $uia)

  $script:SavedClip = $null
  try {
    try { Start-Process $url } catch { return (Fail 'noapp' $_.Exception.Message) }

    # 1) WhatsApp pəncərəsi önə gəlsin
    $fgLimit = 20
    if (-not $running) { $fgLimit = 60 }
    if (-not (Wait-WaForeground $fgLimit)) {
      if (@(Get-WaProcess).Count -eq 0) { return (Fail 'noapp' 'WhatsApp başlamadı') }
      return (Fail 'focus' '')
    }

    # 2) Söhbət açılsın, mətn yazı sahəsində görünsün
    $readyLimit = 25; $fallbackAfter = 7
    if (-not $running) { $readyLimit = 60; $fallbackAfter = 16 }
    $t0 = Get-Date
    $sawText = $false    # UIA fokusdakı elementdən mətn oxuya bildi
    $sawEdit = $false    # UIA fokusda yazı sahəsi (Edit/Document) gördü
    $ready = $false
    $blind = $false      # UIA mətni görə bilmir — vaxta görə davam edirik
    $pasted = $false
    $pastedAt = $null
    $pasteAfter = 9
    if ($paste) { $pasteAfter = 2.5 }
    while (((Get-Date) - $t0).TotalSeconds -lt $readyLimit) {
      Start-Sleep -Milliseconds 500
      if (-not [AmmoWaWin]::ForegroundIsWhatsApp()) {
        if (-not (Wait-WaForeground 6)) { return (Fail 'focus' 'wait') }
      }
      $info = Get-FocusedInfo
      if ($null -ne $info) {
        if (-not [string]::IsNullOrEmpty($info.text)) { $sawText = $true }
        if ($info.type -match 'Edit|Document') { $sawEdit = $true }
        if (Test-HasNeedle $info.text $needle) { $ready = $true; break }
      }
      $elapsed = ((Get-Date) - $t0).TotalSeconds
      if (-not $pasted) {
        # mətn URL ilə gəlmədisə (və ya çox uzundursa) — boş yazı sahəsinə yapışdır
        if ($elapsed -ge $pasteAfter -and (Test-EmptyCompose $info)) {
          Invoke-Paste $Text
          $pasted = $true; $pastedAt = Get-Date
          continue
        }
        # UIA heç nə görmür — vaxta görə davam
        if (-not $sawText -and -not $sawEdit -and $elapsed -ge $fallbackAfter) {
          if ($paste) { Invoke-Paste $Text; $pasted = $true; Start-Sleep -Milliseconds 1200 }
          $blind = $true
          break
        }
      } elseif (-not $sawText -and ((Get-Date) - $pastedAt).TotalSeconds -ge 2.5) {
        # yapışdırdıq, amma UIA mətni oxuya bilmir — mətn yerindədir, davam
        $blind = $true
        break
      }
    }
    if (-not $ready -and -not $blind) {
      $why = Find-InvalidDialog
      if ($why) { return (Fail 'invalid' $why) }
      return (Fail 'notready' '')
    }
    if ($blind -and $uia) {
      # "nömrə yanlışdır" pəncərəsində Enter basıb "göndərildi" deməyək
      $why = Find-InvalidDialog
      if ($why) { return (Fail 'invalid' $why) }
    }

    # 3) Göndər (Enter) və yoxla
    if (-not [AmmoWaWin]::ForegroundIsWhatsApp()) {
      if (-not (Wait-WaForeground 6)) { return (Fail 'focus' 'enter') }
    }
    [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
    $verified = $false
    if ($ready) {
      for ($i = 0; $i -lt 12 -and -not $verified; $i++) {
        Start-Sleep -Milliseconds 500
        $info = Get-FocusedInfo
        if ($null -ne $info -and -not (Test-HasNeedle $info.text $needle)) { $verified = $true }
      }
      if (-not $verified) {
        if ([AmmoWaWin]::ForegroundIsWhatsApp()) { [System.Windows.Forms.SendKeys]::SendWait('{ENTER}') }
        Start-Sleep -Milliseconds 2000
        $info = Get-FocusedInfo
        if ($null -ne $info -and -not (Test-HasNeedle $info.text $needle)) { $verified = $true }
        else { return (Fail 'nosend' '') }
      }
    } else {
      Start-Sleep -Milliseconds 1500
    }

    $method = 'url'
    if ($pasted) { $method = 'paste' }
    Write-Log ('OK ...{0} verified={1} method={2}' -f $digits.Substring($digits.Length - 4), $verified, $method)

    # 4) İstifadəçinin işlədiyi pəncərəni geri qaytar
    if ($RestoreFocus -and -not $prevIsWa -and $prev -ne [IntPtr]::Zero) {
      Start-Sleep -Milliseconds 700
      [void][AmmoWaWin]::Activate($prev)
    }
    return @{ ok = $true; verified = $verified; method = $method }
  } finally {
    if ($null -ne $script:SavedClip -and $script:SavedClip.text) {
      Start-Sleep -Milliseconds 300
      Set-ClipText $script:SavedClip.text
    }
  }
}

# ------------------------------------------------------------------ əsas
$response = $null
try {
  $msg = Read-NativeMessage
  if ($null -eq $msg) { exit 0 }
  $action = [string]$msg.action
  if ($action -eq 'ping') { $response = Invoke-Ping }
  elseif ($action -eq 'open') { $response = Invoke-Open ([string]$msg.phone) ([string]$msg.text) }
  elseif ($action -eq 'send') { $response = Invoke-Send ([string]$msg.phone) ([string]$msg.text) ([bool]$msg.restoreFocus) }
  else { $response = @{ ok = $false; code = 'unknown'; detail = $action } }
} catch {
  $response = @{ ok = $false; code = 'error'; detail = $_.Exception.Message }
  Write-Log ('EXC ' + $_.Exception.ToString())
}
if ($response -is [array]) { $response = $response[-1] }   # funksiyadan təsadüfi çıxış olarsa
if ($null -eq $response) { $response = @{ ok = $false; code = 'error'; detail = 'empty' } }
Write-NativeMessage $response
