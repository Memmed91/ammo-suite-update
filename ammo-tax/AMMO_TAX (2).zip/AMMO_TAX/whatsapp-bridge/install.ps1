﻿# AMMO SUITE — WhatsApp körpüsünü quraşdırır (bir dəfəlik, administrator lazım deyil).
# Körpü AMMO SUITE-in mesajlarını kompüterdəki WhatsApp tətbiqi ilə göndərməsinə imkan verir.
#   WhatsApp_Qosul.bat   -> quraşdırır
#   WhatsApp_Sondur.bat  -> söndürür (-Uninstall)
param([switch]$Uninstall, [switch]$Quiet)

$ErrorActionPreference = 'Stop'
$HostName = 'az.ammo.whatsapp'
$ExtIds = @('bjmnogmejhnebbmgkemlflekeobladel')   # AMMO SUITE (manifest "key" ilə sabit ID)
$Src = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dst = Join-Path $env:LOCALAPPDATA 'AMMO\WhatsAppBridge'
$Keys = @(
  "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName",
  "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName"
)
Add-Type -AssemblyName System.Windows.Forms

function Say([string]$Text, [string]$Icon = 'Information') {
  Write-Host $Text
  if (-not $Quiet) { [void][System.Windows.Forms.MessageBox]::Show($Text, 'AMMO SUITE — WhatsApp körpüsü', 'OK', $Icon) }
}

# Körpünü Chrome kimi işə salıb "ping" göndərir
function Test-Bridge {
  $bat = Join-Path $Dst 'ammo-wa-host.bat'
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = 'cmd.exe'
  $psi.Arguments = '/d /s /c ""' + $bat + '""'
  $psi.UseShellExecute = $false
  $psi.RedirectStandardInput = $true
  $psi.RedirectStandardOutput = $true
  $psi.CreateNoWindow = $true
  $p = [System.Diagnostics.Process]::Start($psi)
  $body = [Text.Encoding]::UTF8.GetBytes('{"action":"ping"}')
  $in = $p.StandardInput.BaseStream
  $in.Write([BitConverter]::GetBytes([int]$body.Length), 0, 4)
  $in.Write($body, 0, $body.Length)
  $in.Flush()
  $in.Close()
  if (-not $p.WaitForExit(45000)) { try { $p.Kill() } catch { }; throw 'Körpü cavab vermədi (45 san.)' }
  $ms = New-Object System.IO.MemoryStream
  $p.StandardOutput.BaseStream.CopyTo($ms)
  $all = $ms.ToArray()
  if ($all.Length -lt 5) { throw 'Körpüdən cavab gəlmədi' }
  $len = [BitConverter]::ToInt32($all, 0)
  return ([Text.Encoding]::UTF8.GetString($all, 4, [Math]::Min($len, $all.Length - 4)) | ConvertFrom-Json)
}

try {
  if ($Uninstall) {
    foreach ($k in $Keys) { if (Test-Path $k) { Remove-Item -Path $k -Force } }
    Say 'WhatsApp körpüsü söndürüldü. AMMO SUITE yenidən WhatsApp Web ilə göndərə bilər (Borc Xatırladıcı → 📲 WhatsApp → «Göndərmə üsulu»).'
    exit 0
  }

  New-Item -ItemType Directory -Force -Path $Dst | Out-Null
  foreach ($f in @('ammo-wa-host.ps1', 'ammo-wa-host.bat')) {
    Copy-Item -LiteralPath (Join-Path $Src $f) -Destination (Join-Path $Dst $f) -Force
  }

  $manifestPath = Join-Path $Dst "$HostName.json"
  $manifest = [ordered]@{
    name            = $HostName
    description     = 'AMMO SUITE WhatsApp bridge'
    path            = (Join-Path $Dst 'ammo-wa-host.bat')
    type            = 'stdio'
    allowed_origins = @($ExtIds | ForEach-Object { "chrome-extension://$_/" })
  }
  [IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json -Depth 4), (New-Object System.Text.UTF8Encoding $false))

  foreach ($k in $Keys) {
    New-Item -Path $k -Force | Out-Null
    Set-Item -Path $k -Value $manifestPath
  }

  $r = $null
  $testErr = ''
  try { $r = Test-Bridge } catch { $testErr = $_.Exception.Message }

  if ($r -and $r.ok) {
    $wa = 'WhatsApp tətbiqi: '
    if ($r.running) { $wa += 'açıqdır ✓' }
    elseif ($r.installed) { $wa += 'quraşdırılıb (hazırda bağlıdır — göndərəndə özü açılacaq)' }
    else { $wa += 'TAPILMADI — Microsoft Store-dan «WhatsApp» quraşdırın' }
    Say ("✓ WhatsApp körpüsü quraşdırıldı və işləyir.`n`n$wa`n`nİndi AMMO SUITE → Borc Xatırladıcı → 📲 WhatsApp bölməsində «Yoxla» düyməsini basın, sonra «Test mesajı» ilə öz nömrənizə yoxlayın.")
  } else {
    Say ("Körpü qeydiyyatdan keçdi, amma yoxlama alınmadı:`n$testErr`n`nKompüteri yenidən başladıb bu faylı bir daha işə salın.") 'Warning'
  }
} catch {
  Say ('Xəta: ' + $_.Exception.Message) 'Error'
  exit 1
}
